import { S as H, i as J, s as K, c as M, m as O, k as P, n as Q, p as R } from "./index-e79f0bb2.js";
import { A as U, p as W, f as X } from "./ApexChart-fb0e9d4c.js";
function Y(l) {
  let n, t;
  return n = new U({ props: { options: (
    /*options*/
    l[0]
  ) } }), {
    c() {
      M(n.$$.fragment);
    },
    m(i, m) {
      O(n, i, m), t = !0;
    },
    p(i, [m]) {
      const s = {};
      m & /*options*/
      1 && (s.options = /*options*/
      i[0]), n.$set(s);
    },
    i(i) {
      t || (P(n.$$.fragment, i), t = !0);
    },
    o(i) {
      Q(n.$$.fragment, i), t = !1;
    },
    d(i) {
      R(n, i);
    }
  };
}
function v(l, n, t) {
  let i, m, s, I, { title: S } = n, { dataProvider: a } = n, { labelColumn: w } = n, { valueColumn: f } = n, { height: r } = n, { width: h } = n, { animate: _ } = n, { dataLabels: L } = n, { legend: F } = n, { palette: y } = n, { c1: k, c2: A, c3: D, c4: N, c5: V } = n, { onClick: g } = n;
  function q(e, c, b) {
    g == null || g({ segment: e, index: c, percentage: b });
  }
  const T = (e, c) => (e.rows ?? []).map((d) => {
    var C, x;
    const u = d == null ? void 0 : d[c];
    if (((x = (C = e == null ? void 0 : e.schema) == null ? void 0 : C[c]) == null ? void 0 : x.type) === "datetime" && u)
      return Date.parse(u);
    const o = parseFloat(u);
    return isNaN(o) ? 0 : o;
  }), Z = (e, c, b) => (e.rows ?? []).map((u) => {
    const o = u == null ? void 0 : u[c];
    if (["string", "number", "boolean"].includes(typeof o)) {
      if (b === "datetime")
        return X.Datetime(o);
    } else
      return "";
    return o;
  });
  return l.$$set = (e) => {
    "title" in e && t(1, S = e.title), "dataProvider" in e && t(2, a = e.dataProvider), "labelColumn" in e && t(3, w = e.labelColumn), "valueColumn" in e && t(4, f = e.valueColumn), "height" in e && t(5, r = e.height), "width" in e && t(6, h = e.width), "animate" in e && t(7, _ = e.animate), "dataLabels" in e && t(8, L = e.dataLabels), "legend" in e && t(9, F = e.legend), "palette" in e && t(10, y = e.palette), "c1" in e && t(11, k = e.c1), "c2" in e && t(12, A = e.c2), "c3" in e && t(13, D = e.c3), "c4" in e && t(14, N = e.c4), "c5" in e && t(15, V = e.c5), "onClick" in e && t(16, g = e.onClick);
  }, l.$$.update = () => {
    var e, c;
    l.$$.dirty & /*dataProvider, labelColumn*/
    12 && t(19, i = ((c = (e = a == null ? void 0 : a.schema) == null ? void 0 : e[w]) == null ? void 0 : c.type) === "datetime" ? "datetime" : "category"), l.$$.dirty & /*dataProvider, valueColumn*/
    20 && t(18, m = T(a, f)), l.$$.dirty & /*dataProvider, labelColumn, labelType*/
    524300 && t(17, s = Z(a, w, i)), l.$$.dirty & /*series, labels, palette, c1, c2, c3, c4, c5, legend, title, dataLabels, height, width, animate, dataProvider, valueColumn*/
    458742 && t(0, I = {
      series: m,
      labels: s,
      colors: y === "Custom" ? [k, A, D, N, V] : [],
      theme: { palette: W(y) },
      legend: {
        show: F,
        position: "right",
        horizontalAlign: "right",
        showForSingleSeries: !0,
        showForNullSeries: !0,
        showForZeroSeries: !0
      },
      title: { text: S },
      dataLabels: { enabled: L },
      chart: {
        height: r == null || r === "" ? "auto" : r,
        width: h == null || h === "" ? "100%" : h,
        type: "donut",
        animations: { enabled: _ },
        toolbar: { show: !1 },
        zoom: { enabled: !1 },
        events: {
          // Clicking on a slice of the donut
          dataPointSelection(b, d, u) {
            const o = u.dataPointIndex, C = a.rows[o], x = a.rows.map((z) => z[f]), j = 0, B = x.reduce((z, G) => z + G, j), E = (C[f] / B * 100).toFixed(1);
            q(C, o + 1, E);
          }
        }
      }
    });
  }, [
    I,
    S,
    a,
    w,
    f,
    r,
    h,
    _,
    L,
    F,
    y,
    k,
    A,
    D,
    N,
    V,
    g,
    s,
    m,
    i
  ];
}
class ee extends H {
  constructor(n) {
    super(), J(this, n, v, Y, K, {
      title: 1,
      dataProvider: 2,
      labelColumn: 3,
      valueColumn: 4,
      height: 5,
      width: 6,
      animate: 7,
      dataLabels: 8,
      legend: 9,
      palette: 10,
      c1: 11,
      c2: 12,
      c3: 13,
      c4: 14,
      c5: 15,
      onClick: 16
    });
  }
}
export {
  ee as default
};
