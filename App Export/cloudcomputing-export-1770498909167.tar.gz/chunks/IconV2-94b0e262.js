import { S as P, i as V, s as j, y as A, f as y, z as D, n as d, A as J, k as g, o as k, u as C, v as z, e as B, c as W, aD as u, m as E, q as N, h as b, p as F, b as v, aJ as S, d as I, l as G, B as q, r as H } from "./index-e79f0bb2.js";
import K from "./Placeholder-527c0fd1.js";
import { l as L } from "./phosphorIconLoader-ff92b5d5.js";
function M(l) {
  let e, t, s, r, c, o;
  return t = new K({}), {
    c() {
      e = B("div"), W(t.$$.fragment), u(
        e,
        "width",
        /*size*/
        l[1] + "px"
      ), u(
        e,
        "height",
        /*size*/
        l[1] + "px"
      );
    },
    m(n, i) {
      y(n, e, i), E(t, e, null), r = !0, c || (o = N(s = /*styleable*/
      l[6].call(
        null,
        e,
        /*styles*/
        l[4]
      )), c = !0);
    },
    p(n, i) {
      (!r || i & /*size*/
      2) && u(
        e,
        "width",
        /*size*/
        n[1] + "px"
      ), (!r || i & /*size*/
      2) && u(
        e,
        "height",
        /*size*/
        n[1] + "px"
      ), s && b(s.update) && i & /*styles*/
      16 && s.update.call(
        null,
        /*styles*/
        n[4]
      );
    },
    i(n) {
      r || (g(t.$$.fragment, n), r = !0);
    },
    o(n) {
      d(t.$$.fragment, n), r = !1;
    },
    d(n) {
      n && k(e), F(t), c = !1, o();
    }
  };
}
function O(l) {
  let e, t, s, r, c;
  return {
    c() {
      e = B("i"), v(e, "class", t = S(
        /*iconClass*/
        l[3]
      ) + " svelte-1ghy1wa"), u(
        e,
        "width",
        /*size*/
        l[1] + "px"
      ), u(
        e,
        "height",
        /*size*/
        l[1] + "px"
      ), u(e, "display", "inline-flex"), u(e, "align-items", "center"), u(e, "justify-content", "center"), I(
        e,
        "hoverable",
        /*onClick*/
        l[2] != null
      );
    },
    m(o, n) {
      y(o, e, n), r || (c = [
        N(s = /*styleable*/
        l[6].call(
          null,
          e,
          /*styles*/
          l[4]
        )),
        G(e, "click", function() {
          b(
            /*onClick*/
            l[2]
          ) && l[2].apply(this, arguments);
        })
      ], r = !0);
    },
    p(o, n) {
      l = o, n & /*iconClass*/
      8 && t !== (t = S(
        /*iconClass*/
        l[3]
      ) + " svelte-1ghy1wa") && v(e, "class", t), n & /*size*/
      2 && u(
        e,
        "width",
        /*size*/
        l[1] + "px"
      ), n & /*size*/
      2 && u(
        e,
        "height",
        /*size*/
        l[1] + "px"
      ), s && b(s.update) && n & /*styles*/
      16 && s.update.call(
        null,
        /*styles*/
        l[4]
      ), n & /*iconClass, onClick*/
      12 && I(
        e,
        "hoverable",
        /*onClick*/
        l[2] != null
      );
    },
    i: q,
    o: q,
    d(o) {
      o && k(e), r = !1, H(c);
    }
  };
}
function Q(l) {
  let e, t, s, r;
  const c = [O, M], o = [];
  function n(i, f) {
    return (
      /*icon*/
      i[0] ? 0 : (
        /*$builderStore*/
        i[5].inBuilder ? 1 : -1
      )
    );
  }
  return ~(e = n(l)) && (t = o[e] = c[e](l)), {
    c() {
      t && t.c(), s = A();
    },
    m(i, f) {
      ~e && o[e].m(i, f), y(i, s, f), r = !0;
    },
    p(i, [f]) {
      let _ = e;
      e = n(i), e === _ ? ~e && o[e].p(i, f) : (t && (D(), d(o[_], 1, 1, () => {
        o[_] = null;
      }), J()), ~e ? (t = o[e], t ? t.p(i, f) : (t = o[e] = c[e](i), t.c()), g(t, 1), t.m(s.parentNode, s)) : t = null);
    },
    i(i) {
      r || (g(t), r = !0);
    },
    o(i) {
      d(t), r = !1;
    },
    d(i) {
      i && k(s), ~e && o[e].d(i);
    }
  };
}
function R(l, e, t) {
  let s, r, c, o;
  const { styleable: n, builderStore: i } = C("sdk");
  z(l, i, (a) => t(5, o = a));
  const f = C("component");
  z(l, f, (a) => t(11, c = a));
  let { icon: _ } = e, { size: h = 24 } = e, { weight: m = "regular" } = e, { color: p } = e, { onClick: w } = e;
  return l.$$set = (a) => {
    "icon" in a && t(0, _ = a.icon), "size" in a && t(1, h = a.size), "weight" in a && t(9, m = a.weight), "color" in a && t(10, p = a.color), "onClick" in a && t(2, w = a.onClick);
  }, l.$$.update = () => {
    l.$$.dirty & /*weight, icon*/
    513 && m && _ && L(m), l.$$.dirty & /*$component, color, size*/
    3074 && t(4, s = {
      ...c.styles,
      normal: {
        ...c.styles.normal,
        color: p || "var(--spectrum-global-color-gray-900)",
        "font-size": `${h}px`
      }
    }), l.$$.dirty & /*icon, weight*/
    513 && t(3, r = _ ? (() => {
      const a = _.replace(/^ph-/, "");
      return m === "regular" ? `ph ph-${a}` : `ph-${m} ph-${a}`;
    })() : "");
  }, [
    _,
    h,
    w,
    r,
    s,
    o,
    n,
    i,
    f,
    m,
    p,
    c
  ];
}
class Y extends P {
  constructor(e) {
    super(), V(this, e, R, Q, j, {
      icon: 0,
      size: 1,
      weight: 9,
      color: 10,
      onClick: 2
    });
  }
}
export {
  Y as default
};
