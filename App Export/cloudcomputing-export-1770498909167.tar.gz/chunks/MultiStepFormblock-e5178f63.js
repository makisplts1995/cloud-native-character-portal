import { S as fe, i as ue, s as ie, c as g, m as b, k as m, n as _, p as d, v as P, au as pe, u as B, ad as me, M as w, al as _e, aT as G, cs as ge, aO as be, N as I, y as A, f as k, z as v, ce as X, cf as Y, A as F, o as h, a as z, e as de, b as $e, d as W } from "./index-e79f0bb2.js";
import { a as ke, F as he } from "./FormBlockComponent-46c07230.js";
function E(l, e, n) {
  const t = l.slice();
  return t[25] = e[n], t[27] = n, t;
}
function H(l, e, n) {
  const t = l.slice();
  return t[28] = e[n], t[30] = n, t;
}
function J(l) {
  let e, n;
  return e = new w({
    props: {
      type: "buttongroup",
      props: { buttons: (
        /*step*/
        l[25].buttons
      ) }
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, r) {
      b(e, t, r), n = !0;
    },
    p(t, r) {
      const o = {};
      r[0] & /*enrichedSteps*/
      128 && (o.props = { buttons: (
        /*step*/
        t[25].buttons
      ) }), e.$set(o);
    },
    i(t) {
      n || (m(e.$$.fragment, t), n = !0);
    },
    o(t) {
      _(e.$$.fragment, t), n = !1;
    },
    d(t) {
      d(e, t);
    }
  };
}
function we(l) {
  let e, n, t, r;
  e = new w({
    props: {
      type: "textv2",
      props: { text: `## ${/*step*/
      l[25].title}` }
    }
  });
  let o = (
    /*buttonPosition*/
    l[4] === "top" && J(l)
  );
  return {
    c() {
      g(e.$$.fragment), n = z(), o && o.c(), t = A();
    },
    m(a, s) {
      b(e, a, s), k(a, n, s), o && o.m(a, s), k(a, t, s), r = !0;
    },
    p(a, s) {
      const c = {};
      s[0] & /*enrichedSteps*/
      128 && (c.props = { text: `## ${/*step*/
      a[25].title}` }), e.$set(c), /*buttonPosition*/
      a[4] === "top" ? o ? (o.p(a, s), s[0] & /*buttonPosition*/
      16 && m(o, 1)) : (o = J(a), o.c(), m(o, 1), o.m(t.parentNode, t)) : o && (v(), _(o, 1, 1, () => {
        o = null;
      }), F());
    },
    i(a) {
      r || (m(e.$$.fragment, a), m(o), r = !0);
    },
    o(a) {
      _(e.$$.fragment, a), _(o), r = !1;
    },
    d(a) {
      a && (h(n), h(t)), d(e, a), o && o.d(a);
    }
  };
}
function Se(l) {
  let e, n;
  return e = new w({
    props: {
      type: "container",
      props: {
        direction: "row",
        hAlign: "stretch",
        vAlign: "center",
        gap: "M",
        wrap: !0
      },
      order: 0,
      $$slots: { default: [we] },
      $$scope: { ctx: l }
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, r) {
      b(e, t, r), n = !0;
    },
    p(t, r) {
      const o = {};
      r[0] & /*enrichedSteps, buttonPosition*/
      144 | r[1] & /*$$scope*/
      1 && (o.$$scope = { dirty: r, ctx: t }), e.$set(o);
    },
    i(t) {
      n || (m(e.$$.fragment, t), n = !0);
    },
    o(t) {
      _(e.$$.fragment, t), n = !1;
    },
    d(t) {
      d(e, t);
    }
  };
}
function K(l, e) {
  let n, t, r;
  return t = new he({
    props: {
      field: (
        /*field*/
        e[28]
      ),
      schema: (
        /*schema*/
        e[6]
      ),
      order: (
        /*fieldIdx*/
        e[30]
      )
    }
  }), {
    key: l,
    first: null,
    c() {
      n = A(), g(t.$$.fragment), this.first = n;
    },
    m(o, a) {
      k(o, n, a), b(t, o, a), r = !0;
    },
    p(o, a) {
      e = o;
      const s = {};
      a[0] & /*enrichedSteps*/
      128 && (s.field = /*field*/
      e[28]), a[0] & /*schema*/
      64 && (s.schema = /*schema*/
      e[6]), a[0] & /*enrichedSteps*/
      128 && (s.order = /*fieldIdx*/
      e[30]), t.$set(s);
    },
    i(o) {
      r || (m(t.$$.fragment, o), r = !0);
    },
    o(o) {
      _(t.$$.fragment, o), r = !1;
    },
    d(o) {
      o && h(n), d(t, o);
    }
  };
}
function Ce(l) {
  let e, n = [], t = /* @__PURE__ */ new Map(), r, o = I(
    /*step*/
    l[25].fields
  );
  const a = (s) => `${/*field*/
  s[28].field || /*field*/
  s[28].name}_${/*fieldIdx*/
  s[30]}`;
  for (let s = 0; s < o.length; s += 1) {
    let c = H(l, o, s), u = a(c);
    t.set(u, n[s] = K(u, c));
  }
  return {
    c() {
      e = de("div");
      for (let s = 0; s < n.length; s += 1)
        n[s].c();
      $e(e, "class", "form-block fields svelte-1gdgv0g"), W(
        e,
        "mobile",
        /*$context*/
        l[8].device.mobile
      );
    },
    m(s, c) {
      k(s, e, c);
      for (let u = 0; u < n.length; u += 1)
        n[u] && n[u].m(e, null);
      r = !0;
    },
    p(s, c) {
      c[0] & /*enrichedSteps, schema*/
      192 && (o = I(
        /*step*/
        s[25].fields
      ), v(), n = X(n, c, a, 1, s, o, t, e, Y, K, null, H), F()), (!r || c[0] & /*$context*/
      256) && W(
        e,
        "mobile",
        /*$context*/
        s[8].device.mobile
      );
    },
    i(s) {
      if (!r) {
        for (let c = 0; c < o.length; c += 1)
          m(n[c]);
        r = !0;
      }
    },
    o(s) {
      for (let c = 0; c < n.length; c += 1)
        _(n[c]);
      r = !1;
    },
    d(s) {
      s && h(e);
      for (let c = 0; c < n.length; c += 1)
        n[c].d();
    }
  };
}
function L(l) {
  let e, n;
  return e = new w({
    props: {
      type: "buttongroup",
      props: {
        buttons: (
          /*step*/
          l[25].buttons
        ),
        collapsed: (
          /*step*/
          l[25].buttonsCollapsed
        ),
        collapsedText: (
          /*step*/
          l[25].buttonsCollapsedText
        )
      },
      order: 3
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, r) {
      b(e, t, r), n = !0;
    },
    p(t, r) {
      const o = {};
      r[0] & /*enrichedSteps*/
      128 && (o.props = {
        buttons: (
          /*step*/
          t[25].buttons
        ),
        collapsed: (
          /*step*/
          t[25].buttonsCollapsed
        ),
        collapsedText: (
          /*step*/
          t[25].buttonsCollapsedText
        )
      }), e.$set(o);
    },
    i(t) {
      n || (m(e.$$.fragment, t), n = !0);
    },
    o(t) {
      _(e.$$.fragment, t), n = !1;
    },
    d(t) {
      d(e, t);
    }
  };
}
function Me(l) {
  let e, n, t, r, o, a, s, c;
  e = new w({
    props: {
      type: "container",
      props: { direction: "column", gap: "S" },
      order: 0,
      $$slots: { default: [Se] },
      $$scope: { ctx: l }
    }
  }), t = new w({
    props: {
      type: "textv2",
      props: { text: (
        /*step*/
        l[25].desc
      ) },
      order: 1
    }
  }), o = new w({
    props: {
      type: "container",
      order: 2,
      $$slots: { default: [Ce] },
      $$scope: { ctx: l }
    }
  });
  let u = (
    /*buttonPosition*/
    l[4] === "bottom" && L(l)
  );
  return {
    c() {
      g(e.$$.fragment), n = z(), g(t.$$.fragment), r = z(), g(o.$$.fragment), a = z(), u && u.c(), s = A();
    },
    m(i, p) {
      b(e, i, p), k(i, n, p), b(t, i, p), k(i, r, p), b(o, i, p), k(i, a, p), u && u.m(i, p), k(i, s, p), c = !0;
    },
    p(i, p) {
      const y = {};
      p[0] & /*enrichedSteps, buttonPosition*/
      144 | p[1] & /*$$scope*/
      1 && (y.$$scope = { dirty: p, ctx: i }), e.$set(y);
      const T = {};
      p[0] & /*enrichedSteps*/
      128 && (T.props = { text: (
        /*step*/
        i[25].desc
      ) }), t.$set(T);
      const C = {};
      p[0] & /*$context, enrichedSteps, schema*/
      448 | p[1] & /*$$scope*/
      1 && (C.$$scope = { dirty: p, ctx: i }), o.$set(C), /*buttonPosition*/
      i[4] === "bottom" ? u ? (u.p(i, p), p[0] & /*buttonPosition*/
      16 && m(u, 1)) : (u = L(i), u.c(), m(u, 1), u.m(s.parentNode, s)) : u && (v(), _(u, 1, 1, () => {
        u = null;
      }), F());
    },
    i(i) {
      c || (m(e.$$.fragment, i), m(t.$$.fragment, i), m(o.$$.fragment, i), m(u), c = !0);
    },
    o(i) {
      _(e.$$.fragment, i), _(t.$$.fragment, i), _(o.$$.fragment, i), _(u), c = !1;
    },
    d(i) {
      i && (h(n), h(r), h(a), h(s)), d(e, i), d(t, i), d(o, i), u && u.d(i);
    }
  };
}
function Te(l) {
  let e, n, t;
  return e = new w({
    props: {
      type: "container",
      props: {
        gap: "M",
        direction: "column",
        hAlign: "stretch",
        vAlign: "top",
        size: "shrink"
      },
      $$slots: { default: [Me] },
      $$scope: { ctx: l }
    }
  }), {
    c() {
      g(e.$$.fragment), n = z();
    },
    m(r, o) {
      b(e, r, o), k(r, n, o), t = !0;
    },
    p(r, o) {
      const a = {};
      o[0] & /*enrichedSteps, buttonPosition, $context, schema*/
      464 | o[1] & /*$$scope*/
      1 && (a.$$scope = { dirty: o, ctx: r }), e.$set(a);
    },
    i(r) {
      t || (m(e.$$.fragment, r), t = !0);
    },
    o(r) {
      _(e.$$.fragment, r), t = !1;
    },
    d(r) {
      r && h(n), d(e, r);
    }
  };
}
function Q(l, e) {
  let n, t, r;
  return t = new w({
    props: {
      type: "formstep",
      props: {
        step: (
          /*stepIdx*/
          e[27] + 1
        ),
        _instanceName: `Step ${/*stepIdx*/
        e[27] + 1}`
      },
      $$slots: { default: [Te] },
      $$scope: { ctx: e }
    }
  }), {
    key: l,
    first: null,
    c() {
      n = A(), g(t.$$.fragment), this.first = n;
    },
    m(o, a) {
      k(o, n, a), b(t, o, a), r = !0;
    },
    p(o, a) {
      e = o;
      const s = {};
      a[0] & /*enrichedSteps*/
      128 && (s.props = {
        step: (
          /*stepIdx*/
          e[27] + 1
        ),
        _instanceName: `Step ${/*stepIdx*/
        e[27] + 1}`
      }), a[0] & /*enrichedSteps, buttonPosition, $context, schema*/
      464 | a[1] & /*$$scope*/
      1 && (s.$$scope = { dirty: a, ctx: e }), t.$set(s);
    },
    i(o) {
      r || (m(t.$$.fragment, o), r = !0);
    },
    o(o) {
      _(t.$$.fragment, o), r = !1;
    },
    d(o) {
      o && h(n), d(t, o);
    }
  };
}
function ye(l) {
  let e = [], n = /* @__PURE__ */ new Map(), t, r, o = I(
    /*enrichedSteps*/
    l[7]
  );
  const a = (s) => (
    /*step*/
    s[25]._stepId
  );
  for (let s = 0; s < o.length; s += 1) {
    let c = E(l, o, s), u = a(c);
    n.set(u, e[s] = Q(u, c));
  }
  return {
    c() {
      for (let s = 0; s < e.length; s += 1)
        e[s].c();
      t = A();
    },
    m(s, c) {
      for (let u = 0; u < e.length; u += 1)
        e[u] && e[u].m(s, c);
      k(s, t, c), r = !0;
    },
    p(s, c) {
      c[0] & /*enrichedSteps, buttonPosition, $context, schema*/
      464 && (o = I(
        /*enrichedSteps*/
        s[7]
      ), v(), e = X(e, c, a, 1, s, o, n, t.parentNode, Y, Q, t, E), F());
    },
    i(s) {
      if (!r) {
        for (let c = 0; c < o.length; c += 1)
          m(e[c]);
        r = !0;
      }
    },
    o(s) {
      for (let c = 0; c < e.length; c += 1)
        _(e[c]);
      r = !1;
    },
    d(s) {
      s && h(t);
      for (let c = 0; c < e.length; c += 1)
        e[c].d(s);
    }
  };
}
function ze(l) {
  let e, n;
  return e = new w({
    props: {
      type: "form",
      context: "form",
      props: {
        size: (
          /*size*/
          l[5]
        ),
        dataSource: (
          /*dataSource*/
          l[3]
        ),
        actionType: (
          /*actionType*/
          l[0] === "Create" ? "Create" : "Update"
        ),
        readonly: (
          /*actionType*/
          l[0] === "View"
        )
      },
      styles: {
        normal: {
          width: "600px",
          "margin-left": "auto",
          "margin-right": "auto"
        }
      },
      $$slots: { default: [ye] },
      $$scope: { ctx: l }
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, r) {
      b(e, t, r), n = !0;
    },
    p(t, r) {
      const o = {};
      r[0] & /*size, dataSource, actionType*/
      41 && (o.props = {
        size: (
          /*size*/
          t[5]
        ),
        dataSource: (
          /*dataSource*/
          t[3]
        ),
        actionType: (
          /*actionType*/
          t[0] === "Create" ? "Create" : "Update"
        ),
        readonly: (
          /*actionType*/
          t[0] === "View"
        )
      }), r[0] & /*enrichedSteps, buttonPosition, $context, schema*/
      464 | r[1] & /*$$scope*/
      1 && (o.$$scope = { dirty: r, ctx: t }), e.$set(o);
    },
    i(t) {
      n || (m(e.$$.fragment, t), n = !0);
    },
    o(t) {
      _(e.$$.fragment, t), n = !1;
    },
    d(t) {
      d(e, t);
    }
  };
}
function Ae(l) {
  let e, n;
  return e = new ke({
    props: {
      actionType: (
        /*actionType*/
        l[0]
      ),
      dataSource: (
        /*dataSource*/
        l[3]
      ),
      rowId: (
        /*rowId*/
        l[1]
      ),
      noRowsMessage: (
        /*noRowsMessage*/
        l[2]
      ),
      $$slots: { default: [ze] },
      $$scope: { ctx: l }
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, r) {
      b(e, t, r), n = !0;
    },
    p(t, r) {
      const o = {};
      r[0] & /*actionType*/
      1 && (o.actionType = /*actionType*/
      t[0]), r[0] & /*dataSource*/
      8 && (o.dataSource = /*dataSource*/
      t[3]), r[0] & /*rowId*/
      2 && (o.rowId = /*rowId*/
      t[1]), r[0] & /*noRowsMessage*/
      4 && (o.noRowsMessage = /*noRowsMessage*/
      t[2]), r[0] & /*size, dataSource, actionType, enrichedSteps, buttonPosition, $context, schema*/
      505 | r[1] & /*$$scope*/
      1 && (o.$$scope = { dirty: r, ctx: t }), e.$set(o);
    },
    i(t) {
      n || (m(e.$$.fragment, t), n = !0);
    },
    o(t) {
      _(e.$$.fragment, t), n = !1;
    },
    d(t) {
      d(e, t);
    }
  };
}
function Ie(l, e, n) {
  let t, r, o, a, s, c, u;
  P(l, pe, (f) => n(16, s = f));
  let { actionType: i } = e, { rowId: p } = e, { noRowsMessage: y } = e, { steps: T } = e, { dataSource: C } = e, { buttonPosition: O = "bottom" } = e, { size: U } = e;
  const { fetchDatasourceSchema: Z, generateGoldenSample: x } = B("sdk"), R = B("component");
  P(l, R, (f) => n(17, c = f));
  const D = B("context");
  P(l, D, (f) => n(8, u = f));
  const V = _e(1);
  me("current-step", V);
  let N;
  const ee = () => {
    var S;
    const f = G(R).id, M = ((S = G(D)[`${f}-provider`]) == null ? void 0 : S.rows) || [], $ = x(M);
    return { [`${f}-repeater`]: $ };
  }, te = (f, M, $) => {
    if (!M)
      return;
    let S = Math.min($ || 0, f.length - 1);
    S = Math.max(S, 0), V.set(S + 1);
  }, oe = async (f) => {
    n(6, N = await Z(f) || {});
  }, ne = (f, M) => f != null && f.length ? f.filter(($) => $.active) : Object.values(M || {}).filter(($) => !$.autocolumn).map(($) => ({ name: $.name, active: !0 })), re = (f, M, $) => {
    const S = f != null && f.length ? f : [{}];
    return S.map((j, se) => {
      const { title: le, fields: ce, buttons: ae } = j, q = ge({
        _id: $,
        stepCount: S.length,
        currentStep: se,
        actionType: i,
        dataSource: C
      });
      return {
        ...j,
        _stepId: be(),
        fields: ne(ce || [], M),
        title: le ?? q.title,
        buttons: ae || q.buttons
      };
    });
  };
  return l.$$set = (f) => {
    "actionType" in f && n(0, i = f.actionType), "rowId" in f && n(1, p = f.rowId), "noRowsMessage" in f && n(2, y = f.noRowsMessage), "steps" in f && n(11, T = f.steps), "dataSource" in f && n(3, C = f.dataSource), "buttonPosition" in f && n(4, O = f.buttonPosition), "size" in f && n(5, U = f.size);
  }, l.$$.update = () => {
    var f;
    l.$$.dirty[0] & /*$component*/
    131072 && n(15, t = c.id), l.$$.dirty[0] & /*$component*/
    131072 && n(14, r = c.selected), l.$$.dirty[0] & /*$builderStore*/
    65536 && n(13, o = (f = s.metadata) == null ? void 0 : f.step), l.$$.dirty[0] & /*dataSource*/
    8 && oe(C), l.$$.dirty[0] & /*steps, schema, id*/
    34880 && n(7, a = re(T, N, t)), l.$$.dirty[0] & /*enrichedSteps, selected, builderStep*/
    24704 && te(a, r, o);
  }, [
    i,
    p,
    y,
    C,
    O,
    U,
    N,
    a,
    u,
    R,
    D,
    T,
    ee,
    o,
    r,
    t,
    s,
    c
  ];
}
class Re extends fe {
  constructor(e) {
    super(), ue(
      this,
      e,
      Ie,
      Ae,
      ie,
      {
        actionType: 0,
        rowId: 1,
        noRowsMessage: 2,
        steps: 11,
        dataSource: 3,
        buttonPosition: 4,
        size: 5,
        getAdditionalDataContext: 12
      },
      null,
      [-1, -1]
    );
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[12];
  }
}
export {
  Re as default
};
