import { S as V, i as j, s as B, c as E, m as G, k as H, n as J, p as K } from "./index-e79f0bb2.js";
import { A as M, f as P } from "./ApexChart-fb0e9d4c.js";
function O(o) {
  let e, n;
  return e = new M({ props: { options: (
    /*options*/
    o[0]
  ) } }), {
    c() {
      E(e.$$.fragment);
    },
    m(i, u) {
      G(e, i, u), n = !0;
    },
    p(i, [u]) {
      const m = {};
      u & /*options*/
      1 && (m.options = /*options*/
      i[0]), e.$set(m);
    },
    i(i) {
      n || (H(e.$$.fragment, i), n = !0);
    },
    o(i) {
      J(e.$$.fragment, i), n = !1;
    },
    d(i) {
      K(e, i);
    }
  };
}
function Q(o, e, n) {
  let i, u, { title: m } = e, { dataProvider: s } = e, { dateColumn: g } = e, { openColumn: y } = e, { highColumn: A } = e, { lowColumn: b } = e, { closeColumn: w } = e, { xAxisLabel: N } = e, { yAxisLabel: _ } = e, { height: f } = e, { width: r } = e, { animate: k } = e, { yAxisUnits: L } = e, { onClick: h } = e;
  function T(t) {
    h == null || h({ candlestick: t });
  }
  const q = (t, x, C) => {
    var d, S;
    const l = C[x];
    if (((S = (d = s == null ? void 0 : s.schema) == null ? void 0 : d[x]) == null ? void 0 : S.type) === "datetime")
      return Date.parse(l);
    if (typeof l == "number")
      return l;
    const c = typeof l == "string";
    if (c && l.includes("-")) {
      const a = Date.parse(l);
      return isNaN(a) ? null : a;
    }
    if (c) {
      const a = parseInt(l, 10);
      return isNaN(a) ? null : a;
    }
    return null;
  }, z = (t, x, C, l, c, d) => [
    {
      data: (t.rows ?? []).map((a) => {
        const U = parseFloat(a[C]), F = parseFloat(a[l]), D = parseFloat(a[c]), I = parseFloat(a[d]);
        return [
          q(t, x, a),
          isNaN(U) ? 0 : U,
          isNaN(F) ? 0 : F,
          isNaN(D) ? 0 : D,
          isNaN(I) ? 0 : I
        ];
      })
    }
  ];
  return o.$$set = (t) => {
    "title" in t && n(1, m = t.title), "dataProvider" in t && n(2, s = t.dataProvider), "dateColumn" in t && n(3, g = t.dateColumn), "openColumn" in t && n(4, y = t.openColumn), "highColumn" in t && n(5, A = t.highColumn), "lowColumn" in t && n(6, b = t.lowColumn), "closeColumn" in t && n(7, w = t.closeColumn), "xAxisLabel" in t && n(8, N = t.xAxisLabel), "yAxisLabel" in t && n(9, _ = t.yAxisLabel), "height" in t && n(10, f = t.height), "width" in t && n(11, r = t.width), "animate" in t && n(12, k = t.animate), "yAxisUnits" in t && n(13, L = t.yAxisUnits), "onClick" in t && n(14, h = t.onClick);
  }, o.$$.update = () => {
    o.$$.dirty & /*dataProvider, dateColumn, openColumn, highColumn, lowColumn, closeColumn*/
    252 && n(15, i = z(s, g, y, A, b, w)), o.$$.dirty & /*series, title, height, width, animate, dataProvider, xAxisLabel, yAxisUnits, yAxisLabel*/
    48902 && n(0, u = {
      series: i,
      title: { text: m },
      chart: {
        height: f == null || f === "" ? "auto" : f,
        width: r == null || r === "" ? "100%" : r,
        type: "candlestick",
        animations: { enabled: k },
        toolbar: { show: !1 },
        zoom: { enabled: !1 },
        events: {
          // Clicking on a Candlestick
          dataPointSelection(t, x, C) {
            const l = C.dataPointIndex, c = s.rows[l];
            T(c);
          }
        }
      },
      xaxis: {
        tooltip: { formatter: P.Datetime },
        type: "datetime",
        title: { text: N }
      },
      yaxis: {
        labels: { formatter: P[L] },
        title: { text: _ }
      }
    });
  }, [
    u,
    m,
    s,
    g,
    y,
    A,
    b,
    w,
    N,
    _,
    f,
    r,
    k,
    L,
    h,
    i
  ];
}
class X extends V {
  constructor(e) {
    super(), j(this, e, Q, O, B, {
      title: 1,
      dataProvider: 2,
      dateColumn: 3,
      openColumn: 4,
      highColumn: 5,
      lowColumn: 6,
      closeColumn: 7,
      xAxisLabel: 8,
      yAxisLabel: 9,
      height: 10,
      width: 11,
      animate: 12,
      yAxisUnits: 13,
      onClick: 14
    });
  }
}
export {
  X as default
};
