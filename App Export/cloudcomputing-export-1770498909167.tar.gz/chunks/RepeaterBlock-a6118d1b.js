import { S as F, i as H, s as I, K as J, c as d, m as b, k as u, n as m, p as k, u as p, v as K, M as v, ac as N, ai as T, aj as E, aT as P, y as L, f as Q, z as U, A as V, o as W, cc as D, B as X, F as Y, G as Z, H as x, J as $ } from "./index-e79f0bb2.js";
import ee from "./Placeholder-527c0fd1.js";
function te(r) {
  let e, n;
  return e = new v({
    props: {
      type: "repeater",
      context: "repeater",
      containsSlot: !0,
      props: {
        dataProvider: `{{ literal ${D(
          /*providerId*/
          r[12]
        )} }}`,
        noRowsMessage: (
          /*noRowsMessage*/
          r[6]
        ),
        direction: (
          /*direction*/
          r[7]
        ),
        hAlign: (
          /*hAlign*/
          r[8]
        ),
        vAlign: (
          /*vAlign*/
          r[9]
        ),
        gap: (
          /*gap*/
          r[10]
        )
      },
      $$slots: { default: [oe] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      d(e.$$.fragment);
    },
    m(t, o) {
      b(e, t, o), n = !0;
    },
    p(t, o) {
      const s = {};
      o & /*providerId, noRowsMessage, direction, hAlign, vAlign, gap*/
      6080 && (s.props = {
        dataProvider: `{{ literal ${D(
          /*providerId*/
          t[12]
        )} }}`,
        noRowsMessage: (
          /*noRowsMessage*/
          t[6]
        ),
        direction: (
          /*direction*/
          t[7]
        ),
        hAlign: (
          /*hAlign*/
          t[8]
        ),
        vAlign: (
          /*vAlign*/
          t[9]
        ),
        gap: (
          /*gap*/
          t[10]
        )
      }), o & /*$$scope*/
      262144 && (s.$$scope = { dirty: o, ctx: t }), e.$set(s);
    },
    i(t) {
      n || (u(e.$$.fragment, t), n = !0);
    },
    o(t) {
      m(e.$$.fragment, t), n = !1;
    },
    d(t) {
      k(e, t);
    }
  };
}
function ne(r) {
  let e, n;
  return e = new ee({}), {
    c() {
      d(e.$$.fragment);
    },
    m(t, o) {
      b(e, t, o), n = !0;
    },
    p: X,
    i(t) {
      n || (u(e.$$.fragment, t), n = !0);
    },
    o(t) {
      m(e.$$.fragment, t), n = !1;
    },
    d(t) {
      k(e, t);
    }
  };
}
function oe(r) {
  let e;
  const n = (
    /*#slots*/
    r[16].default
  ), t = Y(
    n,
    r,
    /*$$scope*/
    r[18],
    null
  );
  return {
    c() {
      t && t.c();
    },
    m(o, s) {
      t && t.m(o, s), e = !0;
    },
    p(o, s) {
      t && t.p && (!e || s & /*$$scope*/
      262144) && Z(
        t,
        n,
        o,
        /*$$scope*/
        o[18],
        e ? $(
          n,
          /*$$scope*/
          o[18],
          s,
          null
        ) : x(
          /*$$scope*/
          o[18]
        ),
        null
      );
    },
    i(o) {
      e || (u(t, o), e = !0);
    },
    o(o) {
      m(t, o), e = !1;
    },
    d(o) {
      t && t.d(o);
    }
  };
}
function re(r) {
  let e, n, t, o;
  const s = [ne, te], a = [];
  function c(i, f) {
    return (
      /*$component*/
      i[13].empty ? 0 : 1
    );
  }
  return e = c(r), n = a[e] = s[e](r), {
    c() {
      n.c(), t = L();
    },
    m(i, f) {
      a[e].m(i, f), Q(i, t, f), o = !0;
    },
    p(i, f) {
      let _ = e;
      e = c(i), e === _ ? a[e].p(i, f) : (U(), m(a[_], 1, 1, () => {
        a[_] = null;
      }), V(), n = a[e], n ? n.p(i, f) : (n = a[e] = s[e](i), n.c()), u(n, 1), n.m(t.parentNode, t));
    },
    i(i) {
      o || (u(n), o = !0);
    },
    o(i) {
      m(n), o = !1;
    },
    d(i) {
      i && W(t), a[e].d(i);
    }
  };
}
function le(r) {
  let e, n, t;
  function o(a) {
    r[17](a);
  }
  let s = {
    type: "dataprovider",
    context: "provider",
    props: {
      dataSource: (
        /*dataSource*/
        r[0]
      ),
      filter: (
        /*filter*/
        r[1]
      ),
      sortColumn: (
        /*sortColumn*/
        r[2]
      ),
      sortOrder: (
        /*sortOrder*/
        r[3]
      ),
      limit: (
        /*limit*/
        r[4]
      ),
      paginate: (
        /*paginate*/
        r[5]
      ),
      autoRefresh: (
        /*autoRefresh*/
        r[11]
      )
    },
    $$slots: { default: [re] },
    $$scope: { ctx: r }
  };
  return (
    /*providerId*/
    r[12] !== void 0 && (s.id = /*providerId*/
    r[12]), e = new v({ props: s }), N.push(() => T(e, "id", o)), {
      c() {
        d(e.$$.fragment);
      },
      m(a, c) {
        b(e, a, c), t = !0;
      },
      p(a, c) {
        const i = {};
        c & /*dataSource, filter, sortColumn, sortOrder, limit, paginate, autoRefresh*/
        2111 && (i.props = {
          dataSource: (
            /*dataSource*/
            a[0]
          ),
          filter: (
            /*filter*/
            a[1]
          ),
          sortColumn: (
            /*sortColumn*/
            a[2]
          ),
          sortOrder: (
            /*sortOrder*/
            a[3]
          ),
          limit: (
            /*limit*/
            a[4]
          ),
          paginate: (
            /*paginate*/
            a[5]
          ),
          autoRefresh: (
            /*autoRefresh*/
            a[11]
          )
        }), c & /*$$scope, $component, providerId, noRowsMessage, direction, hAlign, vAlign, gap*/
        276416 && (i.$$scope = { dirty: c, ctx: a }), !n && c & /*providerId*/
        4096 && (n = !0, i.id = /*providerId*/
        a[12], E(() => n = !1)), e.$set(i);
      },
      i(a) {
        t || (u(e.$$.fragment, a), t = !0);
      },
      o(a) {
        m(e.$$.fragment, a), t = !1;
      },
      d(a) {
        k(e, a);
      }
    }
  );
}
function ae(r) {
  let e, n;
  return e = new J({
    props: {
      $$slots: { default: [le] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      d(e.$$.fragment);
    },
    m(t, o) {
      b(e, t, o), n = !0;
    },
    p(t, [o]) {
      const s = {};
      o & /*$$scope, dataSource, filter, sortColumn, sortOrder, limit, paginate, autoRefresh, providerId, $component, noRowsMessage, direction, hAlign, vAlign, gap*/
      278527 && (s.$$scope = { dirty: o, ctx: t }), e.$set(s);
    },
    i(t) {
      n || (u(e.$$.fragment, t), n = !0);
    },
    o(t) {
      m(e.$$.fragment, t), n = !1;
    },
    d(t) {
      k(e, t);
    }
  };
}
function ie(r, e, n) {
  let t, { $$slots: o = {}, $$scope: s } = e, { dataSource: a } = e, { filter: c } = e, { sortColumn: i } = e, { sortOrder: f } = e, { limit: _ } = e, { paginate: A } = e, { noRowsMessage: R } = e, { direction: w } = e, { hAlign: C } = e, { vAlign: S } = e, { gap: M } = e, { autoRefresh: O } = e;
  const h = p("component");
  K(r, h, (l) => n(13, t = l));
  const y = p("context"), { generateGoldenSample: G } = p("sdk");
  let g;
  const j = () => {
    var B;
    const l = ((B = P(y)[g]) == null ? void 0 : B.rows) || [], z = G(l);
    return { [`${P(h).id}-repeater`]: z };
  };
  function q(l) {
    g = l, n(12, g);
  }
  return r.$$set = (l) => {
    "dataSource" in l && n(0, a = l.dataSource), "filter" in l && n(1, c = l.filter), "sortColumn" in l && n(2, i = l.sortColumn), "sortOrder" in l && n(3, f = l.sortOrder), "limit" in l && n(4, _ = l.limit), "paginate" in l && n(5, A = l.paginate), "noRowsMessage" in l && n(6, R = l.noRowsMessage), "direction" in l && n(7, w = l.direction), "hAlign" in l && n(8, C = l.hAlign), "vAlign" in l && n(9, S = l.vAlign), "gap" in l && n(10, M = l.gap), "autoRefresh" in l && n(11, O = l.autoRefresh), "$$scope" in l && n(18, s = l.$$scope);
  }, [
    a,
    c,
    i,
    f,
    _,
    A,
    R,
    w,
    C,
    S,
    M,
    O,
    g,
    t,
    h,
    j,
    o,
    q,
    s
  ];
}
class ue extends F {
  constructor(e) {
    super(), H(this, e, ie, ae, I, {
      dataSource: 0,
      filter: 1,
      sortColumn: 2,
      sortOrder: 3,
      limit: 4,
      paginate: 5,
      noRowsMessage: 6,
      direction: 7,
      hAlign: 8,
      vAlign: 9,
      gap: 10,
      autoRefresh: 11,
      getAdditionalDataContext: 15
    });
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[15];
  }
}
export {
  ue as default
};
