import { S as v, i as x, s as p, K as $, c as b, m as s, k as C, n as c, p as r, M as Y, ac as ee, ai as le, aj as ne, y as te, f as ue, z as ie, A as ae, o as oe, cc as W } from "./index-e79f0bb2.js";
function X(u) {
  let n, t;
  return n = new Y({
    props: {
      type: (
        /*chartType*/
        u[6]
      ),
      props: {
        dataProvider: `{{ literal ${W(
          /*dataProviderId*/
          u[36]
        )} }}`,
        height: (
          /*height*/
          u[18]
        ),
        width: (
          /*width*/
          u[19]
        ),
        title: (
          /*chartTitle*/
          u[5]
        ),
        labelColumn: (
          /*labelColumn*/
          u[14]
        ),
        valueColumn: (
          /*valueColumn*/
          u[20]
        ),
        valueColumns: (
          /*valueColumns*/
          u[23]
        ),
        palette: (
          /*palette*/
          u[8]
        ),
        dataLabels: (
          /*dataLabels*/
          u[17]
        ),
        legend: (
          /*legend*/
          u[15]
        ),
        animate: (
          /*animate*/
          u[16]
        ),
        valueUnits: (
          /*valueUnits*/
          u[24]
        ),
        yAxisLabel: (
          /*yAxisLabel*/
          u[25]
        ),
        xAxisLabel: (
          /*xAxisLabel*/
          u[26]
        ),
        yAxisUnits: (
          /*yAxisUnits*/
          u[27]
        ),
        stacked: (
          /*stacked*/
          u[21]
        ),
        horizontal: (
          /*horizontal*/
          u[22]
        ),
        curve: (
          /*curve*/
          u[28]
        ),
        gradient: (
          /*gradient*/
          u[29]
        ),
        //issue?
        closeColumn: (
          /*closeColumn*/
          u[30]
        ),
        openColumn: (
          /*openColumn*/
          u[31]
        ),
        highColumn: (
          /*highColumn*/
          u[32]
        ),
        lowColumn: (
          /*lowColumn*/
          u[33]
        ),
        dateColumn: (
          /*dateColumn*/
          u[34]
        ),
        bucketCount: (
          /*bucketCount*/
          u[35]
        ),
        c1: (
          /*c1*/
          u[9]
        ),
        c2: (
          /*c2*/
          u[10]
        ),
        c3: (
          /*c3*/
          u[11]
        ),
        c4: (
          /*c4*/
          u[12]
        ),
        c5: (
          /*c5*/
          u[13]
        )
      }
    }
  }), {
    c() {
      b(n.$$.fragment);
    },
    m(e, i) {
      s(n, e, i), t = !0;
    },
    p(e, i) {
      const o = {};
      i[0] & /*chartType*/
      64 && (o.type = /*chartType*/
      e[6]), i[0] & /*height, width, chartTitle, labelColumn, valueColumn, valueColumns, palette, dataLabels, legend, animate, valueUnits, yAxisLabel, xAxisLabel, yAxisUnits, stacked, horizontal, curve, gradient, closeColumn, c1, c2, c3, c4, c5*/
      2147483424 | i[1] & /*dataProviderId, openColumn, highColumn, lowColumn, dateColumn, bucketCount*/
      63 && (o.props = {
        dataProvider: `{{ literal ${W(
          /*dataProviderId*/
          e[36]
        )} }}`,
        height: (
          /*height*/
          e[18]
        ),
        width: (
          /*width*/
          e[19]
        ),
        title: (
          /*chartTitle*/
          e[5]
        ),
        labelColumn: (
          /*labelColumn*/
          e[14]
        ),
        valueColumn: (
          /*valueColumn*/
          e[20]
        ),
        valueColumns: (
          /*valueColumns*/
          e[23]
        ),
        palette: (
          /*palette*/
          e[8]
        ),
        dataLabels: (
          /*dataLabels*/
          e[17]
        ),
        legend: (
          /*legend*/
          e[15]
        ),
        animate: (
          /*animate*/
          e[16]
        ),
        valueUnits: (
          /*valueUnits*/
          e[24]
        ),
        yAxisLabel: (
          /*yAxisLabel*/
          e[25]
        ),
        xAxisLabel: (
          /*xAxisLabel*/
          e[26]
        ),
        yAxisUnits: (
          /*yAxisUnits*/
          e[27]
        ),
        stacked: (
          /*stacked*/
          e[21]
        ),
        horizontal: (
          /*horizontal*/
          e[22]
        ),
        curve: (
          /*curve*/
          e[28]
        ),
        gradient: (
          /*gradient*/
          e[29]
        ),
        //issue?
        closeColumn: (
          /*closeColumn*/
          e[30]
        ),
        openColumn: (
          /*openColumn*/
          e[31]
        ),
        highColumn: (
          /*highColumn*/
          e[32]
        ),
        lowColumn: (
          /*lowColumn*/
          e[33]
        ),
        dateColumn: (
          /*dateColumn*/
          e[34]
        ),
        bucketCount: (
          /*bucketCount*/
          e[35]
        ),
        c1: (
          /*c1*/
          e[9]
        ),
        c2: (
          /*c2*/
          e[10]
        ),
        c3: (
          /*c3*/
          e[11]
        ),
        c4: (
          /*c4*/
          e[12]
        ),
        c5: (
          /*c5*/
          e[13]
        )
      }), n.$set(o);
    },
    i(e) {
      t || (C(n.$$.fragment, e), t = !0);
    },
    o(e) {
      c(n.$$.fragment, e), t = !1;
    },
    d(e) {
      r(n, e);
    }
  };
}
function fe(u) {
  let n, t, e = (
    /*dataProviderId*/
    u[36] && /*chartType*/
    u[6] && X(u)
  );
  return {
    c() {
      e && e.c(), n = te();
    },
    m(i, o) {
      e && e.m(i, o), ue(i, n, o), t = !0;
    },
    p(i, o) {
      /*dataProviderId*/
      i[36] && /*chartType*/
      i[6] ? e ? (e.p(i, o), o[0] & /*chartType*/
      64 | o[1] & /*dataProviderId*/
      32 && C(e, 1)) : (e = X(i), e.c(), C(e, 1), e.m(n.parentNode, n)) : e && (ie(), c(e, 1, 1, () => {
        e = null;
      }), ae());
    },
    i(i) {
      t || (C(e), t = !0);
    },
    o(i) {
      c(e), t = !1;
    },
    d(i) {
      i && oe(n), e && e.d(i);
    }
  };
}
function me(u) {
  let n, t, e;
  function i(a) {
    u[37](a);
  }
  let o = {
    type: "dataprovider",
    context: "provider",
    props: {
      dataSource: (
        /*dataSource*/
        u[7]
      ),
      filter: (
        /*filter*/
        u[0]
      ),
      sortColumn: (
        /*sortColumn*/
        u[1]
      ),
      sortOrder: (
        /*sortOrder*/
        u[2]
      ),
      limit: (
        /*limit*/
        u[3]
      ),
      autoRefresh: (
        /*autoRefresh*/
        u[4]
      )
    },
    $$slots: { default: [fe] },
    $$scope: { ctx: u }
  };
  return (
    /*dataProviderId*/
    u[36] !== void 0 && (o.id = /*dataProviderId*/
    u[36]), n = new Y({ props: o }), ee.push(() => le(n, "id", i)), {
      c() {
        b(n.$$.fragment);
      },
      m(a, f) {
        s(n, a, f), e = !0;
      },
      p(a, f) {
        const m = {};
        f[0] & /*dataSource, filter, sortColumn, sortOrder, limit, autoRefresh*/
        159 && (m.props = {
          dataSource: (
            /*dataSource*/
            a[7]
          ),
          filter: (
            /*filter*/
            a[0]
          ),
          sortColumn: (
            /*sortColumn*/
            a[1]
          ),
          sortOrder: (
            /*sortOrder*/
            a[2]
          ),
          limit: (
            /*limit*/
            a[3]
          ),
          autoRefresh: (
            /*autoRefresh*/
            a[4]
          )
        }), f[0] & /*chartType, height, width, chartTitle, labelColumn, valueColumn, valueColumns, palette, dataLabels, legend, animate, valueUnits, yAxisLabel, xAxisLabel, yAxisUnits, stacked, horizontal, curve, gradient, closeColumn, c1, c2, c3, c4, c5*/
        2147483488 | f[1] & /*$$scope, dataProviderId, openColumn, highColumn, lowColumn, dateColumn, bucketCount*/
        191 && (m.$$scope = { dirty: f, ctx: a }), !t && f[1] & /*dataProviderId*/
        32 && (t = !0, m.id = /*dataProviderId*/
        a[36], ne(() => t = !1)), n.$set(m);
      },
      i(a) {
        e || (C(n.$$.fragment, a), e = !0);
      },
      o(a) {
        c(n.$$.fragment, a), e = !1;
      },
      d(a) {
        r(n, a);
      }
    }
  );
}
function Ce(u) {
  let n, t;
  return n = new $({
    props: {
      $$slots: { default: [me] },
      $$scope: { ctx: u }
    }
  }), {
    c() {
      b(n.$$.fragment);
    },
    m(e, i) {
      s(n, e, i), t = !0;
    },
    p(e, i) {
      const o = {};
      i[0] & /*dataSource, filter, sortColumn, sortOrder, limit, autoRefresh, chartType, height, width, chartTitle, labelColumn, valueColumn, valueColumns, palette, dataLabels, legend, animate, valueUnits, yAxisLabel, xAxisLabel, yAxisUnits, stacked, horizontal, curve, gradient, closeColumn, c1, c2, c3, c4, c5*/
      2147483647 | i[1] & /*$$scope, dataProviderId, openColumn, highColumn, lowColumn, dateColumn, bucketCount*/
      191 && (o.$$scope = { dirty: i, ctx: e }), n.$set(o);
    },
    i(e) {
      t || (C(n.$$.fragment, e), t = !0);
    },
    o(e) {
      c(n.$$.fragment, e), t = !1;
    },
    d(e) {
      r(n, e);
    }
  };
}
function ce(u, n, t) {
  let { filter: e } = n, { sortColumn: i } = n, { sortOrder: o } = n, { limit: a } = n, { autoRefresh: f } = n, { chartTitle: m } = n, { chartType: g } = n, { dataSource: d } = n, { palette: k } = n, { c1: _, c2: A, c3: L, c4: w, c5: y } = n, { labelColumn: U } = n, { legend: S } = n, { animate: T } = n, { dataLabels: z } = n, { height: O } = n, { width: R } = n, { valueColumn: P } = n, { stacked: B } = n, { horizontal: j } = n, { valueColumns: q } = n, { valueUnits: I } = n, { yAxisLabel: K } = n, { xAxisLabel: M } = n, { yAxisUnits: N } = n, { curve: D } = n, { gradient: E } = n, { closeColumn: F } = n, { openColumn: G } = n, { highColumn: H } = n, { lowColumn: J } = n, { dateColumn: Q } = n, { bucketCount: V } = n, h;
  function Z(l) {
    h = l, t(36, h);
  }
  return u.$$set = (l) => {
    "filter" in l && t(0, e = l.filter), "sortColumn" in l && t(1, i = l.sortColumn), "sortOrder" in l && t(2, o = l.sortOrder), "limit" in l && t(3, a = l.limit), "autoRefresh" in l && t(4, f = l.autoRefresh), "chartTitle" in l && t(5, m = l.chartTitle), "chartType" in l && t(6, g = l.chartType), "dataSource" in l && t(7, d = l.dataSource), "palette" in l && t(8, k = l.palette), "c1" in l && t(9, _ = l.c1), "c2" in l && t(10, A = l.c2), "c3" in l && t(11, L = l.c3), "c4" in l && t(12, w = l.c4), "c5" in l && t(13, y = l.c5), "labelColumn" in l && t(14, U = l.labelColumn), "legend" in l && t(15, S = l.legend), "animate" in l && t(16, T = l.animate), "dataLabels" in l && t(17, z = l.dataLabels), "height" in l && t(18, O = l.height), "width" in l && t(19, R = l.width), "valueColumn" in l && t(20, P = l.valueColumn), "stacked" in l && t(21, B = l.stacked), "horizontal" in l && t(22, j = l.horizontal), "valueColumns" in l && t(23, q = l.valueColumns), "valueUnits" in l && t(24, I = l.valueUnits), "yAxisLabel" in l && t(25, K = l.yAxisLabel), "xAxisLabel" in l && t(26, M = l.xAxisLabel), "yAxisUnits" in l && t(27, N = l.yAxisUnits), "curve" in l && t(28, D = l.curve), "gradient" in l && t(29, E = l.gradient), "closeColumn" in l && t(30, F = l.closeColumn), "openColumn" in l && t(31, G = l.openColumn), "highColumn" in l && t(32, H = l.highColumn), "lowColumn" in l && t(33, J = l.lowColumn), "dateColumn" in l && t(34, Q = l.dateColumn), "bucketCount" in l && t(35, V = l.bucketCount);
  }, [
    e,
    i,
    o,
    a,
    f,
    m,
    g,
    d,
    k,
    _,
    A,
    L,
    w,
    y,
    U,
    S,
    T,
    z,
    O,
    R,
    P,
    B,
    j,
    q,
    I,
    K,
    M,
    N,
    D,
    E,
    F,
    G,
    H,
    J,
    Q,
    V,
    h,
    Z
  ];
}
class be extends v {
  constructor(n) {
    super(), x(
      this,
      n,
      ce,
      Ce,
      p,
      {
        filter: 0,
        sortColumn: 1,
        sortOrder: 2,
        limit: 3,
        autoRefresh: 4,
        chartTitle: 5,
        chartType: 6,
        dataSource: 7,
        palette: 8,
        c1: 9,
        c2: 10,
        c3: 11,
        c4: 12,
        c5: 13,
        labelColumn: 14,
        legend: 15,
        animate: 16,
        dataLabels: 17,
        height: 18,
        width: 19,
        valueColumn: 20,
        stacked: 21,
        horizontal: 22,
        valueColumns: 23,
        valueUnits: 24,
        yAxisLabel: 25,
        xAxisLabel: 26,
        yAxisUnits: 27,
        curve: 28,
        gradient: 29,
        closeColumn: 30,
        openColumn: 31,
        highColumn: 32,
        lowColumn: 33,
        dateColumn: 34,
        bucketCount: 35
      },
      null,
      [-1, -1]
    );
  }
}
export {
  be as default
};
