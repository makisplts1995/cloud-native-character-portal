import { S as N, i as q, s as j, e as v, t as p, a as y, b, f as k, g as n, q as B, j as h, h as w, B as C, o as z, u as S, v as A } from "./index-e79f0bb2.js";
function D(l) {
  let e, s, c, _, o, r, m, i, u, t, d, g;
  return {
    c() {
      e = v("div"), s = v("p"), c = p(
        /*title*/
        l[0]
      ), _ = y(), o = v("h3"), r = p(
        /*value*/
        l[1]
      ), m = y(), i = v("p"), u = p(
        /*label*/
        l[2]
      ), b(s, "class", "title svelte-13s6ero"), b(o, "class", "value svelte-13s6ero"), b(i, "class", "label svelte-13s6ero"), b(e, "class", "container svelte-13s6ero");
    },
    m(a, f) {
      k(a, e, f), n(e, s), n(s, c), n(e, _), n(e, o), n(o, r), n(e, m), n(e, i), n(i, u), d || (g = B(t = /*styleable*/
      l[4].call(
        null,
        e,
        /*$component*/
        l[3].styles
      )), d = !0);
    },
    p(a, [f]) {
      f & /*title*/
      1 && h(
        c,
        /*title*/
        a[0]
      ), f & /*value*/
      2 && h(
        r,
        /*value*/
        a[1]
      ), f & /*label*/
      4 && h(
        u,
        /*label*/
        a[2]
      ), t && w(t.update) && f & /*$component*/
      8 && t.update.call(
        null,
        /*$component*/
        a[3].styles
      );
    },
    i: C,
    o: C,
    d(a) {
      a && z(e), d = !1, g();
    }
  };
}
function E(l, e, s) {
  let c;
  const { styleable: _ } = S("sdk"), o = S("component");
  A(l, o, (t) => s(3, c = t));
  const r = "";
  let { title: m = "" } = e, { value: i = "" } = e, { label: u = "" } = e;
  return l.$$set = (t) => {
    "title" in t && s(0, m = t.title), "value" in t && s(1, i = t.value), "label" in t && s(2, u = t.label);
  }, [m, i, u, c, _, o, r];
}
class G extends N {
  constructor(e) {
    super(), q(this, e, E, D, j, {
      className: 6,
      title: 0,
      value: 1,
      label: 2
    });
  }
  get className() {
    return this.$$.ctx[6];
  }
}
export {
  G as default
};
