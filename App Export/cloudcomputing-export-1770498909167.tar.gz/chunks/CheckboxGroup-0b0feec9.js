import { S as Q, i as R, s as U, e as p, a as S, b as g, aJ as z, f as G, g as b, k as v, z as L, n as j, A as T, o as O, ae as W, I as B, c as D, t as E, d as y, m as J, l as H, j as K, p as P, N as V, y as X, O as Y } from "./index-e79f0bb2.js";
function I(n, t, i) {
  const s = n.slice();
  s[16] = t[i];
  const c = (
    /*getOptionValue*/
    s[6](
      /*option*/
      s[16]
    )
  );
  s[17] = c;
  const m = (
    /*value*/
    s[1].includes(
      /*optionValue*/
      s[17]
    )
  );
  return s[18] = m, s;
}
function M(n) {
  let t, i, s, c, m, e, l, o, u, d, h, _, A;
  return l = new B({
    props: {
      name: (
        /*indeterminate*/
        n[10] ? "minus" : "check"
      ),
      weight: "bold",
      color: "var(--spectrum-global-color-gray-50)"
    }
  }), {
    c() {
      t = p("div"), i = p("label"), s = p("input"), c = S(), m = p("span"), e = p("span"), D(l.$$.fragment), o = S(), u = p("span"), d = E(
        /*selectAllText*/
        n[8]
      ), g(s, "type", "checkbox"), g(s, "class", "spectrum-Checkbox-input svelte-hnsjoe"), s.checked = /*allSelected*/
      n[9], s.disabled = /*disabled*/
      n[3], g(e, "class", "icon svelte-hnsjoe"), y(
        e,
        "checked",
        /*allSelected*/
        n[9] || /*indeterminate*/
        n[10]
      ), g(m, "class", "spectrum-Checkbox-box"), g(u, "class", "spectrum-Checkbox-label"), g(i, "class", "spectrum-Checkbox spectrum-Checkbox--sizeM spectrum-FieldGroup-item svelte-hnsjoe"), g(
        t,
        "title",
        /*selectAllText*/
        n[8]
      ), g(t, "class", "spectrum-Checkbox spectrum-FieldGroup-item select-all-checkbox svelte-hnsjoe"), y(
        t,
        "readonly",
        /*readonly*/
        n[4]
      );
    },
    m(f, r) {
      G(f, t, r), b(t, i), b(i, s), b(i, c), b(i, m), b(m, e), J(l, e, null), b(i, o), b(i, u), b(u, d), h = !0, _ || (A = H(
        s,
        "change",
        /*toggleSelectAll*/
        n[12]
      ), _ = !0);
    },
    p(f, r) {
      (!h || r & /*allSelected*/
      512) && (s.checked = /*allSelected*/
      f[9]), (!h || r & /*disabled*/
      8) && (s.disabled = /*disabled*/
      f[3]);
      const C = {};
      r & /*indeterminate*/
      1024 && (C.name = /*indeterminate*/
      f[10] ? "minus" : "check"), l.$set(C), (!h || r & /*allSelected, indeterminate*/
      1536) && y(
        e,
        "checked",
        /*allSelected*/
        f[9] || /*indeterminate*/
        f[10]
      ), (!h || r & /*selectAllText*/
      256) && K(
        d,
        /*selectAllText*/
        f[8]
      ), (!h || r & /*selectAllText*/
      256) && g(
        t,
        "title",
        /*selectAllText*/
        f[8]
      ), (!h || r & /*readonly*/
      16) && y(
        t,
        "readonly",
        /*readonly*/
        f[4]
      );
    },
    i(f) {
      h || (v(l.$$.fragment, f), h = !0);
    },
    o(f) {
      j(l.$$.fragment, f), h = !1;
    },
    d(f) {
      f && O(t), P(l), _ = !1, A();
    }
  };
}
function N(n) {
  let t, i, s = V(
    /*options*/
    n[2]
  ), c = [];
  for (let e = 0; e < s.length; e += 1)
    c[e] = q(I(n, s, e));
  const m = (e) => j(c[e], 1, 1, () => {
    c[e] = null;
  });
  return {
    c() {
      for (let e = 0; e < c.length; e += 1)
        c[e].c();
      t = X();
    },
    m(e, l) {
      for (let o = 0; o < c.length; o += 1)
        c[o] && c[o].m(e, l);
      G(e, t, l), i = !0;
    },
    p(e, l) {
      if (l & /*getOptionLabel, options, readonly, value, getOptionValue, disabled, onChange*/
      2174) {
        s = V(
          /*options*/
          e[2]
        );
        let o;
        for (o = 0; o < s.length; o += 1) {
          const u = I(e, s, o);
          c[o] ? (c[o].p(u, l), v(c[o], 1)) : (c[o] = q(u), c[o].c(), v(c[o], 1), c[o].m(t.parentNode, t));
        }
        for (L(), o = s.length; o < c.length; o += 1)
          m(o);
        T();
      }
    },
    i(e) {
      if (!i) {
        for (let l = 0; l < s.length; l += 1)
          v(c[l]);
        i = !0;
      }
    },
    o(e) {
      c = c.filter(Boolean);
      for (let l = 0; l < c.length; l += 1)
        j(c[l]);
      i = !1;
    },
    d(e) {
      e && O(t), Y(c, e);
    }
  };
}
function q(n) {
  let t, i, s, c, m, e, l, o, u, d, h = (
    /*getOptionLabel*/
    n[5](
      /*option*/
      n[16]
    ) + ""
  ), _, A, f, r, C, w;
  function F() {
    return (
      /*change_handler*/
      n[14](
        /*optionValue*/
        n[17]
      )
    );
  }
  return o = new B({
    props: {
      name: "check",
      weight: "bold",
      color: "var(--spectrum-global-color-gray-50)"
    }
  }), {
    c() {
      t = p("div"), i = p("label"), s = p("input"), m = S(), e = p("span"), l = p("span"), D(o.$$.fragment), u = S(), d = p("span"), _ = E(h), A = S(), g(s, "type", "checkbox"), g(s, "class", "spectrum-Checkbox-input svelte-hnsjoe"), s.checked = c = /*checked*/
      n[18], s.disabled = /*disabled*/
      n[3], g(l, "class", "icon svelte-hnsjoe"), y(
        l,
        "checked",
        /*checked*/
        n[18]
      ), g(e, "class", "spectrum-Checkbox-box"), g(d, "class", "spectrum-Checkbox-label"), g(i, "class", "spectrum-Checkbox spectrum-Checkbox--sizeM spectrum-FieldGroup-item svelte-hnsjoe"), g(t, "title", f = /*getOptionLabel*/
      n[5](
        /*option*/
        n[16]
      )), g(t, "class", "spectrum-Checkbox spectrum-FieldGroup-item svelte-hnsjoe"), y(
        t,
        "readonly",
        /*readonly*/
        n[4]
      );
    },
    m(a, k) {
      G(a, t, k), b(t, i), b(i, s), b(i, m), b(i, e), b(e, l), J(o, l, null), b(i, u), b(i, d), b(d, _), b(t, A), r = !0, C || (w = H(s, "change", F), C = !0);
    },
    p(a, k) {
      n = a, (!r || k & /*value, getOptionValue, options*/
      70 && c !== (c = /*checked*/
      n[18])) && (s.checked = c), (!r || k & /*disabled*/
      8) && (s.disabled = /*disabled*/
      n[3]), (!r || k & /*value, getOptionValue, options*/
      70) && y(
        l,
        "checked",
        /*checked*/
        n[18]
      ), (!r || k & /*getOptionLabel, options*/
      36) && h !== (h = /*getOptionLabel*/
      n[5](
        /*option*/
        n[16]
      ) + "") && K(_, h), (!r || k & /*getOptionLabel, options*/
      36 && f !== (f = /*getOptionLabel*/
      n[5](
        /*option*/
        n[16]
      ))) && g(t, "title", f), (!r || k & /*readonly*/
      16) && y(
        t,
        "readonly",
        /*readonly*/
        n[4]
      );
    },
    i(a) {
      r || (v(o.$$.fragment, a), r = !0);
    },
    o(a) {
      j(o.$$.fragment, a), r = !1;
    },
    d(a) {
      a && O(t), P(o), C = !1, w();
    }
  };
}
function Z(n) {
  var o;
  let t, i, s = (
    /*options*/
    n[2] && Array.isArray(
      /*options*/
      n[2]
    )
  ), c, m, e = (
    /*showSelectAll*/
    n[7] && /*options*/
    ((o = n[2]) == null ? void 0 : o.length) > 0 && M(n)
  ), l = s && N(n);
  return {
    c() {
      t = p("div"), e && e.c(), i = S(), l && l.c(), g(t, "class", c = z(`spectrum-FieldGroup spectrum-FieldGroup--${/*direction*/
      n[0]}`) + " svelte-hnsjoe");
    },
    m(u, d) {
      G(u, t, d), e && e.m(t, null), b(t, i), l && l.m(t, null), m = !0;
    },
    p(u, [d]) {
      var h;
      /*showSelectAll*/
      u[7] && /*options*/
      ((h = u[2]) == null ? void 0 : h.length) > 0 ? e ? (e.p(u, d), d & /*showSelectAll, options*/
      132 && v(e, 1)) : (e = M(u), e.c(), v(e, 1), e.m(t, i)) : e && (L(), j(e, 1, 1, () => {
        e = null;
      }), T()), d & /*options*/
      4 && (s = /*options*/
      u[2] && Array.isArray(
        /*options*/
        u[2]
      )), s ? l ? (l.p(u, d), d & /*options*/
      4 && v(l, 1)) : (l = N(u), l.c(), v(l, 1), l.m(t, null)) : l && (L(), j(l, 1, 1, () => {
        l = null;
      }), T()), (!m || d & /*direction*/
      1 && c !== (c = z(`spectrum-FieldGroup spectrum-FieldGroup--${/*direction*/
      u[0]}`) + " svelte-hnsjoe")) && g(t, "class", c);
    },
    i(u) {
      m || (v(e), v(l), m = !0);
    },
    o(u) {
      j(e), j(l), m = !1;
    },
    d(u) {
      u && O(t), e && e.d(), l && l.d();
    }
  };
}
function x(n, t, i) {
  let s, c, m, { direction: e = "vertical" } = t, { value: l = [] } = t, { options: o = [] } = t, { disabled: u = !1 } = t, { readonly: d = !1 } = t, { getOptionLabel: h = (a) => `${a}` } = t, { getOptionValue: _ = (a) => a } = t, { showSelectAll: A = !1 } = t, { selectAllText: f = "Select all" } = t;
  const r = W(), C = (a) => {
    l.includes(a) ? r("change", l.filter((k) => k !== a)) : r("change", [...l, a]);
  }, w = () => {
    if (s)
      r("change", []);
    else {
      const a = o.map((k) => _(k));
      r("change", a);
    }
  }, F = (a) => C(a);
  return n.$$set = (a) => {
    "direction" in a && i(0, e = a.direction), "value" in a && i(1, l = a.value), "options" in a && i(2, o = a.options), "disabled" in a && i(3, u = a.disabled), "readonly" in a && i(4, d = a.readonly), "getOptionLabel" in a && i(5, h = a.getOptionLabel), "getOptionValue" in a && i(6, _ = a.getOptionValue), "showSelectAll" in a && i(7, A = a.showSelectAll), "selectAllText" in a && i(8, f = a.selectAllText);
  }, n.$$.update = () => {
    n.$$.dirty & /*options, value, getOptionValue*/
    70 && i(9, s = o.length > 0 && o.every((a) => l.includes(_(a)))), n.$$.dirty & /*options, value, getOptionValue*/
    70 && i(13, c = o.length === 0 || o.every((a) => !l.includes(_(a)))), n.$$.dirty & /*allSelected, noneSelected*/
    8704 && i(10, m = !s && !c);
  }, [
    e,
    l,
    o,
    u,
    d,
    h,
    _,
    A,
    f,
    s,
    m,
    C,
    w,
    c,
    F
  ];
}
class ee extends Q {
  constructor(t) {
    super(), R(this, t, x, Z, U, {
      direction: 0,
      value: 1,
      options: 2,
      disabled: 3,
      readonly: 4,
      getOptionLabel: 5,
      getOptionValue: 6,
      showSelectAll: 7,
      selectAllText: 8
    });
  }
}
export {
  ee as C
};
