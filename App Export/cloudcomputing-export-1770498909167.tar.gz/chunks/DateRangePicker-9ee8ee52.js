import { S as k, i as q, s as A, aK as Q, e as S, c as C, f as E, m as R, q as j, h as x, k as I, n as K, o as T, p as v, aL as l, u as p, v as z, w as B } from "./index-e79f0bb2.js";
import { u as F } from "./utc-7f9d85e9.js";
function G(e) {
  let n, t, i, o, u, c;
  return t = new Q({
    props: {
      placeholder: null,
      options: (
        /*options*/
        e[4]
      ),
      value: (
        /*value*/
        e[0]
      )
    }
  }), t.$on(
    "change",
    /*change_handler*/
    e[11]
  ), {
    c() {
      n = S("div"), C(t.$$.fragment);
    },
    m(a, r) {
      E(a, n, r), R(t, n, null), o = !0, u || (c = j(i = /*styleable*/
      e[3].call(
        null,
        n,
        /*$component*/
        e[1].styles
      )), u = !0);
    },
    p(a, [r]) {
      const d = {};
      r & /*value*/
      1 && (d.value = /*value*/
      a[0]), t.$set(d), i && x(i.update) && r & /*$component*/
      2 && i.update.call(
        null,
        /*$component*/
        a[1].styles
      );
    },
    i(a) {
      o || (I(t.$$.fragment, a), o = !0);
    },
    o(a) {
      K(t.$$.fragment, a), o = !1;
    },
    d(a) {
      a && T(n), v(t), u = !1, c();
    }
  };
}
function H(e, n, t) {
  let i, o, u, c, a;
  l.extend(F);
  let { dataProvider: r } = n, { field: d } = n, { defaultValue: m } = n;
  const _ = p("component");
  z(e, _, (s) => t(1, a = s));
  const { styleable: P, ActionTypes: g, getAction: L } = p("sdk"), b = [
    "Last 1 day",
    "Last 7 days",
    "Last 30 days",
    "Last 3 months",
    "Last 6 months",
    "Last 1 year"
  ];
  let h = b.includes(m) ? m : "Last 30 days";
  const w = (s, f) => {
    if (!s || !f)
      return null;
    let y = l.utc().subtract(1, "year"), V = l.utc().add(1, "day");
    return f === "Last 1 day" ? y = l.utc().subtract(1, "day") : f === "Last 7 days" ? y = l.utc().subtract(7, "days") : f === "Last 30 days" ? y = l.utc().subtract(30, "days") : f === "Last 3 months" ? y = l.utc().subtract(3, "months") : f === "Last 6 months" && (y = l.utc().subtract(6, "months")), {
      range: {
        [s]: { low: y.format(), high: V.format() }
      }
    };
  };
  B(() => {
    u == null || u(a.id);
  });
  const D = (s) => t(0, h = s.detail);
  return e.$$set = (s) => {
    "dataProvider" in s && t(5, r = s.dataProvider), "field" in s && t(6, d = s.field), "defaultValue" in s && t(7, m = s.defaultValue);
  }, e.$$.update = () => {
    e.$$.dirty & /*dataProvider*/
    32 && t(10, i = r == null ? void 0 : r.id), e.$$.dirty & /*dataProviderId*/
    1024 && t(9, o = L(i, g.AddDataProviderQueryExtension)), e.$$.dirty & /*dataProviderId*/
    1024 && (u = L(i, g.RemoveDataProviderQueryExtension)), e.$$.dirty & /*field, value*/
    65 && t(8, c = w(d, h)), e.$$.dirty & /*addExtension, $component, queryExtension*/
    770 && (o == null || o(a.id, c));
  }, [
    h,
    a,
    _,
    P,
    b,
    r,
    d,
    m,
    c,
    o,
    i,
    D
  ];
}
class N extends k {
  constructor(n) {
    super(), q(this, n, H, G, A, {
      dataProvider: 5,
      field: 6,
      defaultValue: 7
    });
  }
}
export {
  N as default
};
