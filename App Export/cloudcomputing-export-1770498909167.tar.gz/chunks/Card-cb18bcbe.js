import { S as I, i as z, s as E, e as H, a as W, t as q, b as m, aD as v, f as B, g as c, q as N, j as y, h as F, B as S, o as D, r as G, u as w, v as J, aA as j } from "./index-e79f0bb2.js";
function A(l) {
  let e, t;
  return {
    c() {
      e = H("img"), v(
        e,
        "--imageHeight",
        /*imageHeight*/
        l[7]
      ), m(e, "class", "image svelte-9mr74r"), j(e.src, t = /*imageUrl*/
      l[0]) || m(e, "src", t), m(e, "alt", "");
    },
    m(n, f) {
      B(n, e, f);
    },
    p(n, f) {
      f & /*imageHeight*/
      128 && v(
        e,
        "--imageHeight",
        /*imageHeight*/
        n[7]
      ), f & /*imageUrl*/
      1 && !j(e.src, t = /*imageUrl*/
      n[0]) && m(e, "src", t);
    },
    d(n) {
      n && D(e);
    }
  };
}
function K(l) {
  let e, t, n, f, g, U, d, k, T, r, _, u, h, C, b, a = (
    /*showImage*/
    l[8] && A(l)
  );
  return {
    c() {
      e = H("div"), a && a.c(), t = W(), n = H("div"), f = H("h2"), g = q(
        /*heading*/
        l[1]
      ), U = W(), d = H("h4"), k = q(
        /*description*/
        l[2]
      ), T = W(), r = H("a"), _ = q(
        /*linkText*/
        l[3]
      ), m(f, "class", "heading svelte-9mr74r"), m(d, "class", "text svelte-9mr74r"), v(
        r,
        "--linkColor",
        /*linkColor*/
        l[5]
      ), v(
        r,
        "--linkHoverColor",
        /*linkHoverColor*/
        l[6]
      ), m(r, "href", u = /*linkUrl*/
      l[4] || "/"), m(r, "class", "svelte-9mr74r"), m(n, "class", "content svelte-9mr74r"), m(e, "class", "container svelte-9mr74r");
    },
    m(s, o) {
      B(s, e, o), a && a.m(e, null), c(e, t), c(e, n), c(n, f), c(f, g), c(n, U), c(n, d), c(d, k), c(n, T), c(n, r), c(r, _), C || (b = [
        N(
          /*linkable*/
          l[11].call(null, r)
        ),
        N(h = /*styleable*/
        l[10].call(
          null,
          e,
          /*cardStyles*/
          l[9]
        ))
      ], C = !0);
    },
    p(s, [o]) {
      /*showImage*/
      s[8] ? a ? a.p(s, o) : (a = A(s), a.c(), a.m(e, t)) : a && (a.d(1), a = null), o & /*heading*/
      2 && y(
        g,
        /*heading*/
        s[1]
      ), o & /*description*/
      4 && y(
        k,
        /*description*/
        s[2]
      ), o & /*linkText*/
      8 && y(
        _,
        /*linkText*/
        s[3]
      ), o & /*linkColor*/
      32 && v(
        r,
        "--linkColor",
        /*linkColor*/
        s[5]
      ), o & /*linkHoverColor*/
      64 && v(
        r,
        "--linkHoverColor",
        /*linkHoverColor*/
        s[6]
      ), o & /*linkUrl*/
      16 && u !== (u = /*linkUrl*/
      s[4] || "/") && m(r, "href", u), h && F(h.update) && o & /*cardStyles*/
      512 && h.update.call(
        null,
        /*cardStyles*/
        s[9]
      );
    },
    i: S,
    o: S,
    d(s) {
      s && D(e), a && a.d(), C = !1, G(b);
    }
  };
}
function L(l, e, t) {
  let n, f, g;
  const { styleable: U, linkable: d } = w("sdk"), k = w("component");
  J(l, k, (i) => t(15, g = i));
  const T = "";
  let { imageUrl: r = "" } = e, { heading: _ = "" } = e, { description: u = "" } = e, { linkText: h = "" } = e, { linkUrl: C } = e, { linkColor: b } = e, { linkHoverColor: a } = e, { imageHeight: s } = e, { cardWidth: o } = e;
  return l.$$set = (i) => {
    "imageUrl" in i && t(0, r = i.imageUrl), "heading" in i && t(1, _ = i.heading), "description" in i && t(2, u = i.description), "linkText" in i && t(3, h = i.linkText), "linkUrl" in i && t(4, C = i.linkUrl), "linkColor" in i && t(5, b = i.linkColor), "linkHoverColor" in i && t(6, a = i.linkHoverColor), "imageHeight" in i && t(7, s = i.imageHeight), "cardWidth" in i && t(14, o = i.cardWidth);
  }, l.$$.update = () => {
    l.$$.dirty & /*$component, cardWidth*/
    49152 && t(9, n = {
      ...g.styles,
      normal: {
        ...g.styles.normal,
        width: o
      }
    }), l.$$.dirty & /*imageUrl*/
    1 && t(8, f = !!r);
  }, [
    r,
    _,
    u,
    h,
    C,
    b,
    a,
    s,
    f,
    n,
    U,
    d,
    k,
    T,
    o,
    g
  ];
}
class O extends I {
  constructor(e) {
    super(), z(this, e, L, K, E, {
      className: 13,
      imageUrl: 0,
      heading: 1,
      description: 2,
      linkText: 3,
      linkUrl: 4,
      linkColor: 5,
      linkHoverColor: 6,
      imageHeight: 7,
      cardWidth: 14
    });
  }
  get className() {
    return this.$$.ctx[13];
  }
}
export {
  O as default
};
