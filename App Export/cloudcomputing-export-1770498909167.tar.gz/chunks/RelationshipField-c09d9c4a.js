import { S as Qe, i as We, s as Xe, ac as D, ai as I, c as ie, m as te, aj as L, k as N, n as C, p as ne, b2 as q, u as Ye, ck as Ze, ae as ve, y as Te, f as Se, z as Ee, A as De, o as Ie, B as xe, C as $e, c3 as ei, D as ii, cl as ti, by as ni, cm as ge, br as pe, bA as li, bf as ee, bg as ri, E as we } from "./index-e79f0bb2.js";
import { M as Ae } from "./Multiselect-9dd507ef.js";
import { F as ai } from "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function Oe(t) {
  let l, n, f, s, u;
  function w(i) {
    t[44](i);
  }
  function A(i) {
    t[45](i);
  }
  var m = (
    /*multiselect*/
    t[14] ? Ae : ge
  );
  function h(i, r) {
    var S, b, p, d;
    let o = {
      value: (
        /*displayValue*/
        i[19]
      ),
      id: (
        /*fieldState*/
        (S = i[10]) == null ? void 0 : S.fieldId
      ),
      disabled: (
        /*fieldState*/
        (b = i[10]) == null ? void 0 : b.disabled
      ),
      readonly: (
        /*fieldState*/
        (p = i[10]) == null ? void 0 : p.readonly
      ),
      loading: !!/*$fetch*/
      ((d = i[15]) != null && d.loading),
      getOptionLabel: si,
      getOptionValue: di,
      options: (
        /*options*/
        i[17]
      ),
      placeholder: (
        /*placeholder*/
        i[2]
      ),
      autocomplete: (
        /*autocomplete*/
        i[6]
      ),
      searchPlaceholder: (
        /*relationshipPickerPlaceholder*/
        i[21]
      )
    };
    return (
      /*searchTerm*/
      i[12] !== void 0 && (o.searchTerm = /*searchTerm*/
      i[12]), /*open*/
      i[13] !== void 0 && (o.open = /*open*/
      i[13]), { props: o }
    );
  }
  return m && (l = pe(m, h(t)), D.push(() => I(l, "searchTerm", w)), D.push(() => I(l, "open", A)), l.$on(
    "change",
    /*handleChange*/
    t[22]
  )), {
    c() {
      l && ie(l.$$.fragment), s = Te();
    },
    m(i, r) {
      l && te(l, i, r), Se(i, s, r), u = !0;
    },
    p(i, r) {
      var o, S, b, p;
      if (r[0] & /*multiselect*/
      16384 && m !== (m = /*multiselect*/
      i[14] ? Ae : ge)) {
        if (l) {
          Ee();
          const d = l;
          C(d.$$.fragment, 1, 0, () => {
            ne(d, 1);
          }), De();
        }
        m ? (l = pe(m, h(i)), D.push(() => I(l, "searchTerm", w)), D.push(() => I(l, "open", A)), l.$on(
          "change",
          /*handleChange*/
          i[22]
        ), ie(l.$$.fragment), N(l.$$.fragment, 1), te(l, s.parentNode, s)) : l = null;
      } else if (m) {
        const d = {};
        r[0] & /*displayValue*/
        524288 && (d.value = /*displayValue*/
        i[19]), r[0] & /*fieldState*/
        1024 && (d.id = /*fieldState*/
        (o = i[10]) == null ? void 0 : o.fieldId), r[0] & /*fieldState*/
        1024 && (d.disabled = /*fieldState*/
        (S = i[10]) == null ? void 0 : S.disabled), r[0] & /*fieldState*/
        1024 && (d.readonly = /*fieldState*/
        (b = i[10]) == null ? void 0 : b.readonly), r[0] & /*$fetch*/
        32768 && (d.loading = !!/*$fetch*/
        ((p = i[15]) != null && p.loading)), r[0] & /*options*/
        131072 && (d.options = /*options*/
        i[17]), r[0] & /*placeholder*/
        4 && (d.placeholder = /*placeholder*/
        i[2]), r[0] & /*autocomplete*/
        64 && (d.autocomplete = /*autocomplete*/
        i[6]), r[0] & /*relationshipPickerPlaceholder*/
        2097152 && (d.searchPlaceholder = /*relationshipPickerPlaceholder*/
        i[21]), !n && r[0] & /*searchTerm*/
        4096 && (n = !0, d.searchTerm = /*searchTerm*/
        i[12], L(() => n = !1)), !f && r[0] & /*open*/
        8192 && (f = !0, d.open = /*open*/
        i[13], L(() => f = !1)), l.$set(d);
      }
    },
    i(i) {
      u || (l && N(l.$$.fragment, i), u = !0);
    },
    o(i) {
      l && C(l.$$.fragment, i), u = !1;
    },
    d(i) {
      i && Ie(s), l && ne(l, i);
    }
  };
}
function fi(t) {
  let l, n, f = (
    /*fieldState*/
    t[10] && Oe(t)
  );
  return {
    c() {
      f && f.c(), l = Te();
    },
    m(s, u) {
      f && f.m(s, u), Se(s, l, u), n = !0;
    },
    p(s, u) {
      /*fieldState*/
      s[10] ? f ? (f.p(s, u), u[0] & /*fieldState*/
      1024 && N(f, 1)) : (f = Oe(s), f.c(), N(f, 1), f.m(l.parentNode, l)) : f && (Ee(), C(f, 1, 1, () => {
        f = null;
      }), De());
    },
    i(s) {
      n || (N(f), n = !0);
    },
    o(s) {
      C(f), n = !1;
    },
    d(s) {
      s && Ie(l), f && f.d(s);
    }
  };
}
function oi(t) {
  let l, n, f, s, u;
  function w(i) {
    t[46](i);
  }
  function A(i) {
    t[47](i);
  }
  function m(i) {
    t[48](i);
  }
  let h = {
    label: (
      /*label*/
      t[1]
    ),
    field: (
      /*field*/
      t[0]
    ),
    disabled: (
      /*disabled*/
      t[3]
    ),
    readonly: (
      /*readonly*/
      t[4]
    ),
    validation: (
      /*validation*/
      t[5]
    ),
    type: (
      /*type*/
      t[9]
    ),
    span: (
      /*span*/
      t[7]
    ),
    helpText: (
      /*helpText*/
      t[8]
    ),
    defaultValue: (
      /*enrichedDefaultValue*/
      t[20]
    ),
    $$slots: { default: [fi] },
    $$scope: { ctx: t }
  };
  return (
    /*fieldState*/
    t[10] !== void 0 && (h.fieldState = /*fieldState*/
    t[10]), /*fieldApi*/
    t[16] !== void 0 && (h.fieldApi = /*fieldApi*/
    t[16]), /*fieldSchema*/
    t[11] !== void 0 && (h.fieldSchema = /*fieldSchema*/
    t[11]), l = new ai({ props: h }), D.push(() => I(l, "fieldState", w)), D.push(() => I(l, "fieldApi", A)), D.push(() => I(l, "fieldSchema", m)), {
      c() {
        ie(l.$$.fragment);
      },
      m(i, r) {
        te(l, i, r), u = !0;
      },
      p(i, r) {
        const o = {};
        r[0] & /*label*/
        2 && (o.label = /*label*/
        i[1]), r[0] & /*field*/
        1 && (o.field = /*field*/
        i[0]), r[0] & /*disabled*/
        8 && (o.disabled = /*disabled*/
        i[3]), r[0] & /*readonly*/
        16 && (o.readonly = /*readonly*/
        i[4]), r[0] & /*validation*/
        32 && (o.validation = /*validation*/
        i[5]), r[0] & /*type*/
        512 && (o.type = /*type*/
        i[9]), r[0] & /*span*/
        128 && (o.span = /*span*/
        i[7]), r[0] & /*helpText*/
        256 && (o.helpText = /*helpText*/
        i[8]), r[0] & /*enrichedDefaultValue*/
        1048576 && (o.defaultValue = /*enrichedDefaultValue*/
        i[20]), r[0] & /*multiselect, displayValue, fieldState, $fetch, options, placeholder, autocomplete, relationshipPickerPlaceholder, searchTerm, open*/
        2815044 | r[2] & /*$$scope*/
        128 && (o.$$scope = { dirty: r, ctx: i }), !n && r[0] & /*fieldState*/
        1024 && (n = !0, o.fieldState = /*fieldState*/
        i[10], L(() => n = !1)), !f && r[0] & /*fieldApi*/
        65536 && (f = !0, o.fieldApi = /*fieldApi*/
        i[16], L(() => f = !1)), !s && r[0] & /*fieldSchema*/
        2048 && (s = !0, o.fieldSchema = /*fieldSchema*/
        i[11], L(() => s = !1)), l.$set(o);
      },
      i(i) {
        u || (N(l.$$.fragment, i), u = !0);
      },
      o(i) {
        C(l.$$.fragment, i), u = !1;
      },
      d(i) {
        ne(l, i);
      }
    }
  );
}
const si = (t) => t.primaryDisplay, di = (t) => t._id;
function ui(t, l, n) {
  let f, s, u, w, A, m, h, i, r, o, S, b, p, d, K, le, E, z = xe, ke = () => (z(), z = $e(i, (e) => n(15, E = e)), i);
  t.$$.on_destroy.push(() => z());
  let { field: re = void 0 } = l, { label: ae = void 0 } = l, { placeholder: fe = void 0 } = l, { disabled: J = !1 } = l, { readonly: H = !1 } = l, { validation: oe = void 0 } = l, { autocomplete: se = !0 } = l, { defaultValue: Q = void 0 } = l, { onChange: U } = l, { filter: R = void 0 } = l, { datasourceType: V = "table" } = l, { primaryDisplay: W = void 0 } = l, { span: de = void 0 } = l, { helpText: ue = void 0 } = l, { type: B = q.LINK } = l, { multi: X = void 0 } = l, { tableId: Y = void 0 } = l, { defaultRows: Z = [] } = l;
  const Fe = Ye("sdk") ?? {}, { API: ce } = Fe, _e = Ze("picker");
  let { workspaceUsersOnly: k = !1 } = l;
  const Ne = ve();
  let F, M, O, P, j = !1, G = [], y = {}, v = !1;
  const Re = (e, a) => a ? be(e) : be(e)[0], Le = (e, a, _, c, g) => {
    const T = a === "table" ? { type: a, tableId: c } : {
      type: g ? "table" : a,
      tableId: ei.USER_METADATA
    };
    return ii({
      API: ce,
      datasource: T,
      options: {
        filter: _,
        limit: e ? 100 : 1
      }
    });
  }, Ce = (e) => e ? Array.isArray(e) ? e : [e] : [], Ue = (e, a, _) => {
    if (e) {
      const c = Array.isArray(e) ? e : [e];
      for (let g of c) {
        const T = $(g, _);
        T && n(32, y[T._id] = T, y);
      }
    }
    for (let c of a) {
      const g = $(c, _);
      g && n(32, y[g._id] = g, y);
    }
    n(32, y), n(25, R), n(31, k);
  }, x = (e) => V === "user" && k ? e.replace(`ro_${li.USERS}_`, "") : e, $ = (e, a) => typeof e == "string" && y[e] ? y[e] : !e || typeof e != "object" || !(e != null && e._id) ? null : Object.keys(e).length === 2 && "primaryDisplay" in e ? {
    _id: x(e._id),
    primaryDisplay: me(e.primaryDisplay)
  } : a ? {
    _id: x(e._id),
    primaryDisplay: me(e[a])
  } : {
    _id: x(e._id),
    primaryDisplay: e._id
  }, Ve = async (e, a, _) => {
    if (!(v || !e.length || !a || !_)) {
      v = !0;
      try {
        const c = await ce.searchTable(a, { query: { oneOf: { _id: e } } });
        for (let g of c.rows) {
          const T = $(g, _);
          T && n(32, y[T._id] = T, y);
        }
        n(32, y), n(25, R), n(31, k), ye(y);
      } catch (c) {
        console.error("Error loading missing row IDs", c);
      } finally {
        for (let c of e)
          y[c] || n(32, y[c] = { _id: c, primaryDisplay: c }, y);
        v = !1;
      }
    }
  }, ye = (e) => {
    let a = Object.values(e);
    a.length !== G.length && (n(17, G = a), he());
  }, he = () => {
    const e = w.reduce((a, _) => ({ ...a, [_]: !0 }), {});
    G.sort((a, _) => {
      const c = !!e[a._id], g = !!e[_._id];
      return c === g ? a.primaryDisplay < _.primaryDisplay ? -1 : 1 : c ? -1 : 1;
    });
  }, me = (e) => typeof e == "string" ? e : JSON.stringify(e), Be = (e) => !e || typeof e != "string" ? e : e.includes(",") ? e.split(",") : e, Me = (e) => Array.isArray(e) ? ti(e) : e;
  async function Pe(e, a) {
    if (!a)
      return;
    let _, c = {
      logicalOperator: ee.ALL,
      filters: [
        {
          field: a,
          operator: ri.STRING,
          value: e
        }
      ]
    };
    e && h ? _ = {
      logicalOperator: ee.ALL,
      groups: [c, h],
      onEmptyFilter: we.RETURN_NONE
    } : e ? _ = {
      logicalOperator: ee.ALL,
      groups: [c],
      onEmptyFilter: we.RETURN_NONE
    } : _ = h, await (i == null ? void 0 : i.update({ filter: _ }));
  }
  const je = ni(Pe, 250), be = (e) => e ? (Array.isArray(e) || (e = [e]), e = e.map((a) => typeof a == "object" ? a._id : a), e) : [], Ge = (e) => {
    let a = e.detail;
    f || (a = a == null ? [] : [a]), B === q.BB_REFERENCE_SINGLE && a && Array.isArray(a) && (a = a[0] || null);
    const _ = M.setValue(a);
    U && _ && U({ value: a });
  };
  function qe(e) {
    P = e, n(12, P);
  }
  function Ke(e) {
    j = e, n(13, j);
  }
  function ze(e) {
    F = e, n(10, F);
  }
  function Je(e) {
    M = e, n(16, M);
  }
  function He(e) {
    O = e, n(11, O);
  }
  return t.$$set = (e) => {
    "field" in e && n(0, re = e.field), "label" in e && n(1, ae = e.label), "placeholder" in e && n(2, fe = e.placeholder), "disabled" in e && n(3, J = e.disabled), "readonly" in e && n(4, H = e.readonly), "validation" in e && n(5, oe = e.validation), "autocomplete" in e && n(6, se = e.autocomplete), "defaultValue" in e && n(23, Q = e.defaultValue), "onChange" in e && n(24, U = e.onChange), "filter" in e && n(25, R = e.filter), "datasourceType" in e && n(26, V = e.datasourceType), "primaryDisplay" in e && n(27, W = e.primaryDisplay), "span" in e && n(7, de = e.span), "helpText" in e && n(8, ue = e.helpText), "type" in e && n(9, B = e.type), "multi" in e && n(28, X = e.multi), "tableId" in e && n(29, Y = e.tableId), "defaultRows" in e && n(30, Z = e.defaultRows), "workspaceUsersOnly" in e && n(31, k = e.workspaceUsersOnly);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*filter*/
    33554432 | t.$$.dirty[1] & /*workspaceUsersOnly*/
    1 && n(32, y = {}), t.$$.dirty[0] & /*multi, type, fieldSchema*/
    268438016 && n(14, f = X ?? ([q.LINK, q.BB_REFERENCE].includes(B) && (O == null ? void 0 : O.relationshipType) !== "one-to-many")), t.$$.dirty[0] & /*fieldState*/
    1024 && n(41, s = F == null ? void 0 : F.value), t.$$.dirty[0] & /*multiselect*/
    16384 | t.$$.dirty[1] & /*realValue*/
    1024 && n(35, u = Re(s, f)), t.$$.dirty[1] & /*selectedValue*/
    16 && n(34, w = Ce(u)), t.$$.dirty[0] & /*tableId, fieldSchema*/
    536872960 && n(39, A = Y ?? (O == null ? void 0 : O.tableId)), t.$$.dirty[0] & /*disabled, readonly*/
    24 && n(43, m = !J && !H), t.$$.dirty[0] & /*filter*/
    33554432 && n(33, h = Me(R)), t.$$.dirty[0] & /*datasourceType*/
    67108864 | t.$$.dirty[1] & /*writable, migratedFilter, linkedTableId, workspaceUsersOnly*/
    4357 && ke(n(18, i = Le(m, V, h, A, k))), t.$$.dirty[0] & /*$fetch*/
    32768 && n(42, r = E == null ? void 0 : E.definition), t.$$.dirty[0] & /*primaryDisplay*/
    134217728 | t.$$.dirty[1] & /*tableDefinition*/
    2048 && n(38, o = W || (r && "primaryDisplay" in r ? r.primaryDisplay : void 0)), t.$$.dirty[1] & /*primaryDisplayField*/
    128 && n(21, S = o ? _e.searchByFieldPlaceholder.replace("{field}", o) : _e.searchPlaceholder), t.$$.dirty[0] & /*$fetch*/
    32768 && n(40, b = (E == null ? void 0 : E.rows) || []), t.$$.dirty[1] & /*rows*/
    512 && b && Ne("rows", b), t.$$.dirty[0] & /*defaultRows*/
    1073741824 | t.$$.dirty[1] & /*realValue, rows, primaryDisplayField*/
    1664 && Ue(s, [...b, ...Z || []], o), t.$$.dirty[1] & /*selectedIDs, optionsMap*/
    10 && n(37, p = w.filter((e) => !y[e])), t.$$.dirty[1] & /*missingIDs, linkedTableId, primaryDisplayField*/
    448 && Ve(p, A, o), t.$$.dirty[1] & /*optionsMap*/
    2 && ye(y), t.$$.dirty[0] & /*open*/
    8192 && !j && he(), t.$$.dirty[0] & /*searchTerm*/
    4096 | t.$$.dirty[1] & /*primaryDisplayField*/
    128 && je(P || "", o), t.$$.dirty[0] & /*defaultValue*/
    8388608 && n(20, d = Be(Q)), t.$$.dirty[0] & /*multiselect*/
    16384 && n(36, K = f ? [] : void 0), t.$$.dirty[1] & /*missingIDs, emptyValue, selectedValue*/
    112 && n(19, le = p.length ? K : u);
  }, [
    re,
    ae,
    fe,
    J,
    H,
    oe,
    se,
    de,
    ue,
    B,
    F,
    O,
    P,
    j,
    f,
    E,
    M,
    G,
    i,
    le,
    d,
    S,
    Ge,
    Q,
    U,
    R,
    V,
    W,
    X,
    Y,
    Z,
    k,
    y,
    h,
    w,
    u,
    K,
    p,
    o,
    A,
    b,
    s,
    r,
    m,
    qe,
    Ke,
    ze,
    Je,
    He
  ];
}
class bi extends Qe {
  constructor(l) {
    super(), We(
      this,
      l,
      ui,
      oi,
      Xe,
      {
        field: 0,
        label: 1,
        placeholder: 2,
        disabled: 3,
        readonly: 4,
        validation: 5,
        autocomplete: 6,
        defaultValue: 23,
        onChange: 24,
        filter: 25,
        datasourceType: 26,
        primaryDisplay: 27,
        span: 7,
        helpText: 8,
        type: 9,
        multi: 28,
        tableId: 29,
        defaultRows: 30,
        workspaceUsersOnly: 31
      },
      null,
      [-1, -1, -1]
    );
  }
}
export {
  bi as default
};
