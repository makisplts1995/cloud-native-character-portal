import { S as v, i as R, s as S, e as P, c as k, b as q, f as A, m as C, q as D, h as F, k as p, n as g, o as G, p as H, u as m, v as J, F as T, G as j, H as z, J as B } from "./index-e79f0bb2.js";
function E(a) {
  let o;
  const t = (
    /*#slots*/
    a[9].default
  ), e = T(
    t,
    a,
    /*$$scope*/
    a[10],
    null
  );
  return {
    c() {
      e && e.c();
    },
    m(s, r) {
      e && e.m(s, r), o = !0;
    },
    p(s, r) {
      e && e.p && (!o || r & /*$$scope*/
      1024) && j(
        e,
        t,
        s,
        /*$$scope*/
        s[10],
        o ? B(
          t,
          /*$$scope*/
          s[10],
          r,
          null
        ) : z(
          /*$$scope*/
          s[10]
        ),
        null
      );
    },
    i(s) {
      o || (p(e, s), o = !0);
    },
    o(s) {
      g(e, s), o = !1;
    },
    d(s) {
      e && e.d(s);
    }
  };
}
function K(a) {
  let o, t, e, s, r, i;
  return t = new /*Provider*/
  a[5]({
    props: {
      actions: (
        /*actions*/
        a[1]
      ),
      data: (
        /*row*/
        a[0] ?? null
      ),
      $$slots: { default: [E] },
      $$scope: { ctx: a }
    }
  }), {
    c() {
      o = P("div"), k(t.$$.fragment), q(o, "class", "svelte-1ccs8qd");
    },
    m(n, l) {
      A(n, o, l), C(t, o, null), s = !0, r || (i = D(e = /*styleable*/
      a[4].call(
        null,
        o,
        /*$component*/
        a[2].styles
      )), r = !0);
    },
    p(n, [l]) {
      const u = {};
      l & /*actions*/
      2 && (u.actions = /*actions*/
      n[1]), l & /*row*/
      1 && (u.data = /*row*/
      n[0] ?? null), l & /*$$scope*/
      1024 && (u.$$scope = { dirty: l, ctx: n }), t.$set(u), e && F(e.update) && l & /*$component*/
      4 && e.update.call(
        null,
        /*$component*/
        n[2].styles
      );
    },
    i(n) {
      s || (p(t.$$.fragment, n), s = !0);
    },
    o(n) {
      g(t.$$.fragment, n), s = !1;
    },
    d(n) {
      n && G(o), H(t), r = !1, i();
    }
  };
}
function L(a, o, t) {
  let e, s, r, { $$slots: i = {}, $$scope: n } = o, { datasource: l } = o, { rowId: u } = o;
  const d = m("component");
  J(a, d, (c) => t(2, r = c));
  const { styleable: y, API: w, Provider: b, ActionTypes: h } = m("sdk");
  let f;
  const _ = async (c, I) => {
    try {
      t(0, f = await w.fetchRow(c, I));
    } catch {
      t(0, f = void 0);
    }
  };
  return a.$$set = (c) => {
    "datasource" in c && t(6, l = c.datasource), "rowId" in c && t(7, u = c.rowId), "$$scope" in c && t(10, n = c.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty & /*datasource*/
    64 && t(8, e = l.type === "table" ? l.tableId : l.id), a.$$.dirty & /*datasourceId, rowId*/
    384 && _(e, u), a.$$.dirty & /*datasourceId, rowId, datasource*/
    448 && t(1, s = [
      {
        type: h.RefreshDatasource,
        callback: () => _(e, u),
        metadata: { dataSource: l }
      }
    ]);
  }, [
    f,
    s,
    r,
    d,
    y,
    b,
    l,
    u,
    e,
    i,
    n
  ];
}
class O extends v {
  constructor(o) {
    super(), R(this, o, L, K, S, { datasource: 6, rowId: 7 });
  }
}
export {
  O as default
};
