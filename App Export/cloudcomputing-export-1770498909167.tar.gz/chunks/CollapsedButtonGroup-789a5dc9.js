import { S as J, i as K, s as L, aM as Q, ac as M, ai as R, ah as T, c as k, a as S, m as w, f as d, aj as U, k as h, n as g, o as p, p as z, t as v, j, ab as b, N as B, y as V, z as W, A as X, O as Y } from "./index-e79f0bb2.js";
import { M as Z, I as $ } from "./Item-8e1549c4.js";
function C(t, n, a) {
  const l = t.slice();
  return l[19] = n[a], l;
}
function y(t) {
  let n = (
    /*text*/
    (t[1] || "Action") + ""
  ), a;
  return {
    c() {
      a = v(n);
    },
    m(l, e) {
      d(l, a, e);
    },
    p(l, e) {
      e & /*text*/
      2 && n !== (n = /*text*/
      (l[1] || "Action") + "") && j(a, n);
    },
    d(l) {
      l && p(a);
    }
  };
}
function x(t) {
  let n = (
    /*button*/
    (t[19].text || "Button") + ""
  ), a, l;
  return {
    c() {
      a = v(n), l = S();
    },
    m(e, u) {
      d(e, a, u), d(e, l, u);
    },
    p(e, u) {
      u & /*buttons*/
      1 && n !== (n = /*button*/
      (e[19].text || "Button") + "") && j(a, n);
    },
    d(e) {
      e && (p(a), p(l));
    }
  };
}
function A(t) {
  let n, a;
  function l() {
    return (
      /*click_handler_2*/
      t[13](
        /*button*/
        t[19]
      )
    );
  }
  return n = new $({
    props: {
      disabled: (
        /*button*/
        t[19].disabled
      ),
      $$slots: { default: [x] },
      $$scope: { ctx: t }
    }
  }), n.$on("click", l), {
    c() {
      k(n.$$.fragment);
    },
    m(e, u) {
      w(n, e, u), a = !0;
    },
    p(e, u) {
      t = e;
      const i = {};
      u & /*buttons*/
      1 && (i.disabled = /*button*/
      t[19].disabled), u & /*$$scope, buttons*/
      4194305 && (i.$$scope = { dirty: u, ctx: t }), n.$set(i);
    },
    i(e) {
      a || (h(n.$$.fragment, e), a = !0);
    },
    o(e) {
      g(n.$$.fragment, e), a = !1;
    },
    d(e) {
      z(n, e);
    }
  };
}
function ee(t) {
  let n, a, l = B(
    /*buttons*/
    t[0]
  ), e = [];
  for (let i = 0; i < l.length; i += 1)
    e[i] = A(C(t, l, i));
  const u = (i) => g(e[i], 1, 1, () => {
    e[i] = null;
  });
  return {
    c() {
      for (let i = 0; i < e.length; i += 1)
        e[i].c();
      n = V();
    },
    m(i, c) {
      for (let f = 0; f < e.length; f += 1)
        e[f] && e[f].m(i, c);
      d(i, n, c), a = !0;
    },
    p(i, c) {
      if (c & /*buttons, handleClick*/
      513) {
        l = B(
          /*buttons*/
          i[0]
        );
        let f;
        for (f = 0; f < l.length; f += 1) {
          const s = C(i, l, f);
          e[f] ? (e[f].p(s, c), h(e[f], 1)) : (e[f] = A(s), e[f].c(), h(e[f], 1), e[f].m(n.parentNode, n));
        }
        for (W(), f = l.length; f < e.length; f += 1)
          u(f);
        X();
      }
    },
    i(i) {
      if (!a) {
        for (let c = 0; c < l.length; c += 1)
          h(e[c]);
        a = !0;
      }
    },
    o(i) {
      e = e.filter(Boolean);
      for (let c = 0; c < e.length; c += 1)
        g(e[c]);
      a = !1;
    },
    d(i) {
      i && p(n), Y(e, i);
    }
  };
}
function ne(t) {
  let n, a;
  return n = new Z({
    props: {
      $$slots: { default: [ee] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      k(n.$$.fragment);
    },
    m(l, e) {
      w(n, l, e), a = !0;
    },
    p(l, e) {
      const u = {};
      e & /*$$scope, buttons*/
      4194305 && (u.$$scope = { dirty: e, ctx: l }), n.$set(u);
    },
    i(l) {
      a || (h(n.$$.fragment, l), a = !0);
    },
    o(l) {
      g(n.$$.fragment, l), a = !1;
    },
    d(l) {
      z(n, l);
    }
  };
}
function te(t) {
  let n, a, l, e, u;
  function i(s) {
    t[10](s);
  }
  let c = {
    size: (
      /*size*/
      t[2]
    ),
    icon: "caret-down",
    quiet: (
      /*quiet*/
      t[6]
    ),
    primary: (
      /*quiet*/
      t[6]
    ),
    cta: !/*quiet*/
    t[6],
    newStyles: !/*quiet*/
    t[6],
    reverse: !0,
    $$slots: { default: [y] },
    $$scope: { ctx: t }
  };
  /*anchor*/
  t[7] !== void 0 && (c.ref = /*anchor*/
  t[7]), n = new Q({ props: c }), M.push(() => R(n, "ref", i)), n.$on(
    "click",
    /*click_handler_1*/
    t[11]
  ), n.$on(
    "click",
    /*click_handler*/
    t[12]
  );
  let f = {
    align: (
      /*align*/
      t[3]
    ),
    anchor: (
      /*anchor*/
      t[7]
    ),
    offset: (
      /*offset*/
      t[4]
    ),
    animate: (
      /*animate*/
      t[5]
    ),
    resizable: !1,
    $$slots: { default: [ne] },
    $$scope: { ctx: t }
  };
  return e = new T({ props: f }), t[14](e), e.$on(
    "close",
    /*close_handler*/
    t[15]
  ), e.$on(
    "open",
    /*open_handler*/
    t[16]
  ), e.$on(
    "mouseenter",
    /*mouseenter_handler*/
    t[17]
  ), e.$on(
    "mouseleave",
    /*mouseleave_handler*/
    t[18]
  ), {
    c() {
      k(n.$$.fragment), l = S(), k(e.$$.fragment);
    },
    m(s, r) {
      w(n, s, r), d(s, l, r), w(e, s, r), u = !0;
    },
    p(s, [r]) {
      const _ = {};
      r & /*size*/
      4 && (_.size = /*size*/
      s[2]), r & /*quiet*/
      64 && (_.quiet = /*quiet*/
      s[6]), r & /*quiet*/
      64 && (_.primary = /*quiet*/
      s[6]), r & /*quiet*/
      64 && (_.cta = !/*quiet*/
      s[6]), r & /*quiet*/
      64 && (_.newStyles = !/*quiet*/
      s[6]), r & /*$$scope, text*/
      4194306 && (_.$$scope = { dirty: r, ctx: s }), !a && r & /*anchor*/
      128 && (a = !0, _.ref = /*anchor*/
      s[7], U(() => a = !1)), n.$set(_);
      const m = {};
      r & /*align*/
      8 && (m.align = /*align*/
      s[3]), r & /*anchor*/
      128 && (m.anchor = /*anchor*/
      s[7]), r & /*offset*/
      16 && (m.offset = /*offset*/
      s[4]), r & /*animate*/
      32 && (m.animate = /*animate*/
      s[5]), r & /*$$scope, buttons*/
      4194305 && (m.$$scope = { dirty: r, ctx: s }), e.$set(m);
    },
    i(s) {
      u || (h(n.$$.fragment, s), h(e.$$.fragment, s), u = !0);
    },
    o(s) {
      g(n.$$.fragment, s), g(e.$$.fragment, s), u = !1;
    },
    d(s) {
      s && p(l), z(n, s), t[14](null), z(e, s);
    }
  };
}
function ae(t, n, a) {
  let { buttons: l } = n, { text: e = "Action" } = n, { size: u = "M" } = n, { align: i = "left" } = n, { offset: c } = n, { animate: f } = n, { quiet: s = !1 } = n, r, _;
  const m = async (o) => {
    var q;
    _.hide(), await ((q = o.onClick) == null ? void 0 : q.call(o));
  };
  function I(o) {
    r = o, a(7, r);
  }
  const N = () => _ == null ? void 0 : _.show();
  function G(o) {
    b.call(this, t, o);
  }
  const O = (o) => m(o);
  function P(o) {
    M[o ? "unshift" : "push"](() => {
      _ = o, a(8, _);
    });
  }
  function D(o) {
    b.call(this, t, o);
  }
  function E(o) {
    b.call(this, t, o);
  }
  function F(o) {
    b.call(this, t, o);
  }
  function H(o) {
    b.call(this, t, o);
  }
  return t.$$set = (o) => {
    "buttons" in o && a(0, l = o.buttons), "text" in o && a(1, e = o.text), "size" in o && a(2, u = o.size), "align" in o && a(3, i = o.align), "offset" in o && a(4, c = o.offset), "animate" in o && a(5, f = o.animate), "quiet" in o && a(6, s = o.quiet);
  }, [
    l,
    e,
    u,
    i,
    c,
    f,
    s,
    r,
    _,
    m,
    I,
    N,
    G,
    O,
    P,
    D,
    E,
    F,
    H
  ];
}
class se extends J {
  constructor(n) {
    super(), K(this, n, ae, te, L, {
      buttons: 0,
      text: 1,
      size: 2,
      align: 3,
      offset: 4,
      animate: 5,
      quiet: 6
    });
  }
}
export {
  se as C
};
