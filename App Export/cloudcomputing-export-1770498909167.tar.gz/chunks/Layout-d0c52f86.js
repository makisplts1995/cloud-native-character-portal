import { Q as te, R as tt, _ as gl, T as yl, U as Qi, V as Xi, W as Pr, X as _l, Y as bl, Z as vl, $ as wl, a0 as kl, a1 as Ol, a2 as Sl, a3 as Tl, a4 as El, a5 as Fl, a6 as Dl, S as Te, i as Ee, s as ve, e as I, t as le, b as T, f as C, g as j, j as ue, a7 as ea, a8 as ps, a9 as gs, o as L, F as Ft, a as Y, d as W, l as fe, G as Dt, H as Mt, J as Nt, k as _, z as X, n as w, A as ee, u as Gt, aa as ta, I as Pe, c as R, m as z, p as q, ab as cn, ac as Oe, ad as In, ae as Rr, y as $e, r as Ct, af as Ml, ag as Nl, B as Se, ah as Cl, ai as ct, h as He, q as Kt, aj as dt, ak as ys, al as Er, v as pe, am as ra, an as Bt, ao as na, ap as Fr, aq as Qr, ar as Ll, as as Vl, at as Il, au as Al, C as Wl, N as Dr, O as sa, av as An, aw as Wn, ax as Ul, ay as _s, az as ia, aA as St, aB as xl, aC as Pl, aD as Rl, aE as zl, aF as ql, aG as jl, aH as $l } from "./index-e79f0bb2.js";
import { M as Zl, I as vr } from "./Item-8e1549c4.js";
import { S as qt } from "./datasources-2b52ffcb.js";
import { r as Hl } from "./___vite-browser-external_commonjs-proxy-3c538421.js";
import { U as Bl } from "./UserAvatar-97a868e1.js";
import { h as Yl } from "./users-b6137f6b.js";
function Gl(r) {
  return !!r.providerType;
}
const Qt = {
  WORKSPACES: "/builder/workspaces",
  SETTINGS_EMAIL: "/builder/settings/email",
  SETTINGS_AUTH: "/builder/settings/auth",
  SETTINGS_PEOPLE_USERS: "/builder/settings/people/users",
  APPS: "/builder/apps"
}, Un = {
  ACCOUNT: "/portal/account",
  BILLING: "/portal/billing",
  UPGRADE: "/portal/upgrade"
};
function Jl(r) {
  return r === qt.GOOGLE_SHEETS;
}
function Kl(r) {
  return !r || !r.source ? !1 : [
    qt.POSTGRES,
    qt.SQL_SERVER,
    qt.MYSQL,
    qt.ORACLE
  ].indexOf(r.source) !== -1 || r.isSQL === !0;
}
async function aa(r) {
  return new Promise((e) => setTimeout(e, r));
}
async function Ql(r, e) {
  const { times: t = 3 } = e || {};
  if (t < 1)
    throw new Error(`invalid retry count: ${t}`);
  let n;
  for (let s = 0; s < t; s++) {
    const i = 1.5 ** s * 1e3 * (Math.random() + 0.5);
    await aa(i);
    try {
      return await r();
    } catch (a) {
      n = a;
    }
  }
  throw n;
}
var sr = { exports: {} }, Re = {};
(function(r) {
  Object.defineProperty(r, "__esModule", { value: !0 }), r.Err = r.Valid = r.err = r.valid = void 0;
  const e = (i) => new n(i);
  r.valid = e;
  const t = (i) => new s(i);
  r.err = t;
  class n {
    constructor(a) {
      this.value = a;
    }
    isValid() {
      return !0;
    }
    isError() {
      return !this.isValid();
    }
    getValue() {
      return this.value;
    }
    getError() {
      throw new Error("Tried to get error from a valid.");
    }
    map(a) {
      return (0, r.valid)(a(this.value));
    }
    mapErr(a) {
      return (0, r.valid)(this.value);
    }
  }
  r.Valid = n;
  class s {
    constructor(a) {
      this.error = a;
    }
    isError() {
      return !0;
    }
    isValid() {
      return !this.isError();
    }
    getValue() {
      throw new Error("Tried to get success value from an error.");
    }
    getError() {
      return this.error;
    }
    map(a) {
      return (0, r.err)(this.error);
    }
    mapErr(a) {
      return (0, r.err)(a(this.error));
    }
  }
  r.Err = s;
})(Re);
var ir = {}, ar = {}, bs;
function ht() {
  if (bs)
    return ar;
  bs = 1, Object.defineProperty(ar, "__esModule", { value: !0 }), Be();
  const r = Re, e = [
    "jan",
    "feb",
    "mar",
    "apr",
    "may",
    "jun",
    "jul",
    "aug",
    "sep",
    "oct",
    "nov",
    "dec"
  ], t = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"], n = (u, d) => d[u].lowerLimit === d.preset[u].minValue && d[u].upperLimit === d.preset[u].maxValue, s = (u, d, h) => {
    if (d === "months" && h.useAliases && e.indexOf(u.toLowerCase()) !== -1 || d === "daysOfWeek" && h.useAliases && t.indexOf(u.toLowerCase()) !== -1)
      return (0, r.valid)(!0);
    const c = Number(u);
    if (isNaN(c))
      return (0, r.err)(`Element '${u} of ${d} field is invalid.`);
    const { lowerLimit: m } = h[d], { upperLimit: g } = h[d];
    return m && c < m ? (0, r.err)(`Number ${c} of ${d} field is smaller than lower limit '${m}'`) : g && c > g ? (0, r.err)(`Number ${c} of ${d} field is bigger than upper limit '${g}'`) : (0, r.valid)(!0);
  }, i = (u, d, h) => {
    if (u === "*")
      return n(d, h) ? (0, r.valid)(!0) : (0, r.err)(`Field ${d} uses wildcard '*', but is limited to ${h[d].lowerLimit}-${h[d].upperLimit}`);
    if (u === "")
      return (0, r.err)(`One of the elements is empty in ${d} field.`);
    if (d === "daysOfMonth" && h.useLastDayOfMonth && u === "L")
      return (0, r.valid)(!0);
    if (d === "daysOfWeek" && h.useLastDayOfWeek && u.endsWith("L")) {
      const c = u.slice(0, -1);
      return c === "" ? (0, r.valid)(!0) : s(c, d, h);
    }
    if (d === "daysOfMonth" && h.useNearestWeekday && u.endsWith("W")) {
      const c = u.slice(0, -1);
      return c === "" ? (0, r.err)("The 'W' must be preceded by a day") : h.useLastDayOfMonth && c === "L" ? (0, r.valid)(!0) : s(c, d, h);
    }
    if (d === "daysOfWeek" && h.useNthWeekdayOfMonth && u.indexOf("#") !== -1) {
      const [c, m, ...g] = u.split("#");
      if (g.length !== 0)
        return (0, r.err)(`Unexpected number of '#' in ${u}, can only be used once.`);
      const p = Number(m);
      return !m || isNaN(p) ? (0, r.err)(`Unexpected value following the '#' symbol, a positive number was expected but found ${m}.`) : p > 5 ? (0, r.err)("Number of occurrence of the day of the week cannot be greater than 5.") : s(c, d, h);
    }
    return s(u, d, h);
  }, a = (u, d, h, c) => u === "*" ? (0, r.err)(`'*' can't be part of a range in ${d} field.`) : u === "" ? (0, r.err)(`One of the range elements is empty in ${d} field.`) : h.useLastDayOfMonth && d === "daysOfMonth" && u === "L" && c === 0 ? (0, r.valid)(!0) : s(u, d, h), l = (u, d, h) => {
    const c = u.split("-");
    if (c.length > 2)
      return (0, r.err)(`List element '${u}' is not valid. (More than one '-')`);
    if (c.length === 1)
      return i(c[0], d, h);
    if (c.length === 2) {
      const m = a(c[0], d, h, 0), g = a(c[1], d, h, 1);
      return m.isError() ? m : g.isError() ? g : Number(c[0]) > Number(c[1]) ? (0, r.err)(`Lower range end '${c[0]}' is bigger than upper range end '${c[1]}' of ${d} field.`) : (0, r.valid)(!0);
    }
    return (0, r.err)("Some other error in checkFirstStepElement (rangeArray less than 1)");
  }, o = (u, d, h) => {
    const c = u.split("/");
    if (c.length > 2)
      return (0, r.err)(`List element '${u}' is not valid. (More than one '/')`);
    const m = l(c[0], d, h);
    if (m.isError())
      return m;
    if (c.length === 2) {
      const g = c[1];
      if (!g)
        return (0, r.err)(`Second step element '${g}' of '${u}' is not valid (doesnt exist).`);
      if (isNaN(Number(g)))
        return (0, r.err)(`Second step element '${g}' of '${u}' is not valid (not a number).`);
      if (Number(g) === 0)
        return (0, r.err)(`Second step element '${g}' of '${u}' cannot be zero.`);
    }
    return (0, r.valid)(!0);
  }, f = (u, d, h) => {
    if (![
      "seconds",
      "minutes",
      "hours",
      "daysOfMonth",
      "months",
      "daysOfWeek",
      "years"
    ].includes(d))
      return (0, r.err)([`Cron field type '${d}' does not exist.`]);
    if (u === "?")
      return d === "daysOfMonth" || d === "daysOfWeek" ? h.useBlankDay ? (0, r.valid)(!0) : (0, r.err)([
        `useBlankDay is not enabled, but is used in ${d} field`
      ]) : (0, r.err)([`blank notation is not allowed in ${d} field`]);
    const c = u.split(","), m = [];
    if (c.forEach((p) => {
      m.push(o(p, d, h));
    }), m.every((p) => p.isValid()))
      return (0, r.valid)(!0);
    const g = [];
    return m.forEach((p) => {
      p.isError() && g.push(p.getError());
    }), (0, r.err)(g);
  };
  return ar.default = f, ar;
}
var vs;
function Xl() {
  if (vs)
    return ir;
  vs = 1;
  var r = te && te.__importDefault || function(s) {
    return s && s.__esModule ? s : { default: s };
  };
  Object.defineProperty(ir, "__esModule", { value: !0 }), Be();
  const e = Re, t = r(ht()), n = (s, i) => {
    if (!s.seconds)
      return (0, e.err)([
        "seconds field is undefined, but useSeconds options is enabled."
      ]);
    const { seconds: a } = s;
    return (0, t.default)(a, "seconds", i);
  };
  return ir.default = n, ir;
}
var or = {}, ws;
function eu() {
  if (ws)
    return or;
  ws = 1;
  var r = te && te.__importDefault || function(s) {
    return s && s.__esModule ? s : { default: s };
  };
  Object.defineProperty(or, "__esModule", { value: !0 }), Be();
  const e = Re, t = r(ht()), n = (s, i) => {
    if (!s.minutes)
      return (0, e.err)(["minutes field is undefined."]);
    const { minutes: a } = s;
    return (0, t.default)(a, "minutes", i);
  };
  return or.default = n, or;
}
var lr = {}, ks;
function tu() {
  if (ks)
    return lr;
  ks = 1;
  var r = te && te.__importDefault || function(s) {
    return s && s.__esModule ? s : { default: s };
  };
  Object.defineProperty(lr, "__esModule", { value: !0 }), Be();
  const e = Re, t = r(ht()), n = (s, i) => {
    if (!s.hours)
      return (0, e.err)(["hours field is undefined."]);
    const { hours: a } = s;
    return (0, t.default)(a, "hours", i);
  };
  return lr.default = n, lr;
}
var ur = {}, Os;
function ru() {
  if (Os)
    return ur;
  Os = 1;
  var r = te && te.__importDefault || function(s) {
    return s && s.__esModule ? s : { default: s };
  };
  Object.defineProperty(ur, "__esModule", { value: !0 }), Be();
  const e = Re, t = r(ht()), n = (s, i) => {
    if (!s.daysOfMonth)
      return (0, e.err)(["daysOfMonth field is undefined."]);
    const { daysOfMonth: a } = s;
    return i.allowOnlyOneBlankDayField && i.useBlankDay && s.daysOfMonth === "?" && s.daysOfWeek === "?" ? (0, e.err)([
      "Cannot use blank value in daysOfMonth and daysOfWeek field when allowOnlyOneBlankDayField option is enabled."
    ]) : i.mustHaveBlankDayField && s.daysOfMonth !== "?" && s.daysOfWeek !== "?" ? (0, e.err)([
      "Cannot specify both daysOfMonth and daysOfWeek field when mustHaveBlankDayField option is enabled."
    ]) : i.useLastDayOfMonth && s.daysOfMonth.indexOf("L") !== -1 && s.daysOfMonth.match(/[,/]/) ? (0, e.err)([
      "Cannot specify last day of month with lists, or ranges (symbols ,/)."
    ]) : i.useNearestWeekday && s.daysOfMonth.indexOf("W") !== -1 && s.daysOfMonth.match(/[,/-]/) ? (0, e.err)([
      "Cannot specify nearest weekday with lists, steps or ranges (symbols ,-/)."
    ]) : (0, t.default)(a, "daysOfMonth", i);
  };
  return ur.default = n, ur;
}
var fr = {}, Ss;
function nu() {
  if (Ss)
    return fr;
  Ss = 1;
  var r = te && te.__importDefault || function(s) {
    return s && s.__esModule ? s : { default: s };
  };
  Object.defineProperty(fr, "__esModule", { value: !0 }), Be();
  const e = Re, t = r(ht()), n = (s, i) => {
    if (!s.months)
      return (0, e.err)(["months field is undefined."]);
    const { months: a } = s;
    return (0, t.default)(a, "months", i);
  };
  return fr.default = n, fr;
}
var cr = {}, Ts;
function su() {
  if (Ts)
    return cr;
  Ts = 1;
  var r = te && te.__importDefault || function(s) {
    return s && s.__esModule ? s : { default: s };
  };
  Object.defineProperty(cr, "__esModule", { value: !0 }), Be();
  const e = Re, t = r(ht()), n = (s, i) => {
    if (!s.daysOfWeek)
      return (0, e.err)(["daysOfWeek field is undefined."]);
    const { daysOfWeek: a } = s;
    return i.allowOnlyOneBlankDayField && s.daysOfMonth === "?" && s.daysOfWeek === "?" ? (0, e.err)([
      "Cannot use blank value in daysOfMonth and daysOfWeek field when allowOnlyOneBlankDayField option is enabled."
    ]) : i.mustHaveBlankDayField && s.daysOfMonth !== "?" && s.daysOfWeek !== "?" ? (0, e.err)([
      "Cannot specify both daysOfMonth and daysOfWeek field when mustHaveBlankDayField option is enabled."
    ]) : i.useLastDayOfWeek && s.daysOfWeek.indexOf("L") !== -1 && s.daysOfWeek.match(/[,/-]/) ? (0, e.err)([
      "Cannot specify last day of week with lists, steps or ranges (symbols ,-/)."
    ]) : i.useNthWeekdayOfMonth && s.daysOfWeek.indexOf("#") !== -1 && s.daysOfWeek.match(/[,/-]/) ? (0, e.err)([
      "Cannot specify Nth weekday of month with lists, steps or ranges (symbols ,-/)."
    ]) : (0, t.default)(a, "daysOfWeek", i);
  };
  return cr.default = n, cr;
}
var dr = {}, Es;
function iu() {
  if (Es)
    return dr;
  Es = 1;
  var r = te && te.__importDefault || function(s) {
    return s && s.__esModule ? s : { default: s };
  };
  Object.defineProperty(dr, "__esModule", { value: !0 }), Be();
  const e = Re, t = r(ht()), n = (s, i) => {
    if (!s.years)
      return (0, e.err)(["years field is undefined, but useYears option is enabled."]);
    const { years: a } = s;
    return (0, t.default)(a, "years", i);
  };
  return dr.default = n, dr;
}
var Ve = {}, dn;
try {
  dn = Map;
} catch {
}
var hn;
try {
  hn = Set;
} catch {
}
function oa(r, e, t) {
  if (!r || typeof r != "object" || typeof r == "function")
    return r;
  if (r.nodeType && "cloneNode" in r)
    return r.cloneNode(!0);
  if (r instanceof Date)
    return new Date(r.getTime());
  if (r instanceof RegExp)
    return new RegExp(r);
  if (Array.isArray(r))
    return r.map(mn);
  if (dn && r instanceof dn)
    return new Map(Array.from(r.entries()));
  if (hn && r instanceof hn)
    return new Set(Array.from(r.values()));
  if (r instanceof Object) {
    e.push(r);
    var n = Object.create(r);
    t.push(n);
    for (var s in r) {
      var i = e.findIndex(function(a) {
        return a === r[s];
      });
      n[s] = i > -1 ? t[i] : oa(r[s], e, t);
    }
    return n;
  }
  return r;
}
function mn(r) {
  return oa(r, [], []);
}
const au = Object.prototype.toString, ou = Error.prototype.toString, lu = RegExp.prototype.toString, uu = typeof Symbol < "u" ? Symbol.prototype.toString : () => "", fu = /^Symbol\((.*)\)(.*)$/;
function cu(r) {
  return r != +r ? "NaN" : r === 0 && 1 / r < 0 ? "-0" : "" + r;
}
function Fs(r, e = !1) {
  if (r == null || r === !0 || r === !1)
    return "" + r;
  const t = typeof r;
  if (t === "number")
    return cu(r);
  if (t === "string")
    return e ? `"${r}"` : r;
  if (t === "function")
    return "[Function " + (r.name || "anonymous") + "]";
  if (t === "symbol")
    return uu.call(r).replace(fu, "Symbol($1)");
  const n = au.call(r).slice(8, -1);
  return n === "Date" ? isNaN(r.getTime()) ? "" + r : r.toISOString(r) : n === "Error" || r instanceof Error ? "[" + ou.call(r) + "]" : n === "RegExp" ? lu.call(r) : null;
}
function Tt(r, e) {
  let t = Fs(r, e);
  return t !== null ? t : JSON.stringify(r, function(n, s) {
    let i = Fs(this[n], e);
    return i !== null ? i : s;
  }, 2);
}
let ot = {
  default: "${path} is invalid",
  required: "${path} is a required field",
  oneOf: "${path} must be one of the following values: ${values}",
  notOneOf: "${path} must not be one of the following values: ${values}",
  notType: ({
    path: r,
    type: e,
    value: t,
    originalValue: n
  }) => {
    let s = n != null && n !== t, i = `${r} must be a \`${e}\` type, but the final value was: \`${Tt(t, !0)}\`` + (s ? ` (cast from the value \`${Tt(n, !0)}\`).` : ".");
    return t === null && (i += '\n If "null" is intended as an empty value be sure to mark the schema as `.nullable()`'), i;
  },
  defined: "${path} must be defined"
}, We = {
  length: "${path} must be exactly ${length} characters",
  min: "${path} must be at least ${min} characters",
  max: "${path} must be at most ${max} characters",
  matches: '${path} must match the following: "${regex}"',
  email: "${path} must be a valid email",
  url: "${path} must be a valid URL",
  uuid: "${path} must be a valid UUID",
  trim: "${path} must be a trimmed string",
  lowercase: "${path} must be a lowercase string",
  uppercase: "${path} must be a upper case string"
}, Ge = {
  min: "${path} must be greater than or equal to ${min}",
  max: "${path} must be less than or equal to ${max}",
  lessThan: "${path} must be less than ${less}",
  moreThan: "${path} must be greater than ${more}",
  positive: "${path} must be a positive number",
  negative: "${path} must be a negative number",
  integer: "${path} must be an integer"
}, pn = {
  min: "${path} field must be later than ${min}",
  max: "${path} field must be at earlier than ${max}"
}, gn = {
  isValue: "${path} field must be ${value}"
}, yn = {
  noUnknown: "${path} field has unspecified keys: ${unknown}"
}, wr = {
  min: "${path} field must have at least ${min} items",
  max: "${path} field must have less than or equal to ${max} items",
  length: "${path} must be have ${length} items"
};
const du = Object.assign(/* @__PURE__ */ Object.create(null), {
  mixed: ot,
  string: We,
  number: Ge,
  date: pn,
  object: yn,
  array: wr,
  boolean: gn
});
var hu = Object.prototype, mu = hu.hasOwnProperty;
function pu(r, e) {
  return r != null && mu.call(r, e);
}
var gu = pu, yu = gu, _u = gl;
function bu(r, e) {
  return r != null && _u(r, e, yu);
}
var vu = bu;
const Mr = /* @__PURE__ */ tt(vu), Lt = (r) => r && r.__isYupSchema__;
class wu {
  constructor(e, t) {
    if (this.refs = e, this.refs = e, typeof t == "function") {
      this.fn = t;
      return;
    }
    if (!Mr(t, "is"))
      throw new TypeError("`is:` is required for `when()` conditions");
    if (!t.then && !t.otherwise)
      throw new TypeError("either `then:` or `otherwise:` is required for `when()` conditions");
    let {
      is: n,
      then: s,
      otherwise: i
    } = t, a = typeof n == "function" ? n : (...l) => l.every((o) => o === n);
    this.fn = function(...l) {
      let o = l.pop(), f = l.pop(), u = a(...l) ? s : i;
      if (u)
        return typeof u == "function" ? u(f) : f.concat(u.resolve(o));
    };
  }
  resolve(e, t) {
    let n = this.refs.map((i) => i.getValue(t == null ? void 0 : t.value, t == null ? void 0 : t.parent, t == null ? void 0 : t.context)), s = this.fn.apply(e, n.concat(e, t));
    if (s === void 0 || s === e)
      return e;
    if (!Lt(s))
      throw new TypeError("conditions must return a schema object");
    return s.resolve(t);
  }
}
function la(r) {
  return r == null ? [] : [].concat(r);
}
function _n() {
  return _n = Object.assign || function(r) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var n in t)
        Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, _n.apply(this, arguments);
}
let ku = /\$\{\s*(\w+)\s*\}/g;
class be extends Error {
  static formatError(e, t) {
    const n = t.label || t.path || "this";
    return n !== t.path && (t = _n({}, t, {
      path: n
    })), typeof e == "string" ? e.replace(ku, (s, i) => Tt(t[i])) : typeof e == "function" ? e(t) : e;
  }
  static isError(e) {
    return e && e.name === "ValidationError";
  }
  constructor(e, t, n, s) {
    super(), this.name = "ValidationError", this.value = t, this.path = n, this.type = s, this.errors = [], this.inner = [], la(e).forEach((i) => {
      be.isError(i) ? (this.errors.push(...i.errors), this.inner = this.inner.concat(i.inner.length ? i.inner : i)) : this.errors.push(i);
    }), this.message = this.errors.length > 1 ? `${this.errors.length} errors occurred` : this.errors[0], Error.captureStackTrace && Error.captureStackTrace(this, be);
  }
}
const Ou = (r) => {
  let e = !1;
  return (...t) => {
    e || (e = !0, r(...t));
  };
};
function Nr(r, e) {
  let {
    endEarly: t,
    tests: n,
    args: s,
    value: i,
    errors: a,
    sort: l,
    path: o
  } = r, f = Ou(e), u = n.length;
  const d = [];
  if (a = a || [], !u)
    return a.length ? f(new be(a, i, o)) : f(null, i);
  for (let h = 0; h < n.length; h++) {
    const c = n[h];
    c(s, function(g) {
      if (g) {
        if (!be.isError(g))
          return f(g, i);
        if (t)
          return g.value = i, f(g, i);
        d.push(g);
      }
      if (--u <= 0) {
        if (d.length && (l && d.sort(l), a.length && d.push(...a), a = d), a.length) {
          f(new be(a, i, o), i);
          return;
        }
        f(null, i);
      }
    });
  }
}
function Su(r) {
  return function(e, t, n) {
    for (var s = -1, i = Object(e), a = n(e), l = a.length; l--; ) {
      var o = a[r ? l : ++s];
      if (t(i[o], o, i) === !1)
        break;
    }
    return e;
  };
}
var Tu = Su, Eu = Tu, Fu = Eu(), Du = Fu, Mu = Du, Nu = yl;
function Cu(r, e) {
  return r && Mu(r, e, Nu);
}
var ua = Cu, Lu = Xi, Vu = ua, Iu = Qi;
function Au(r, e) {
  var t = {};
  return e = Iu(e), Vu(r, function(n, s, i) {
    Lu(t, s, e(n, s, i));
  }), t;
}
var Wu = Au;
const fa = /* @__PURE__ */ tt(Wu);
function mt(r) {
  this._maxSize = r, this.clear();
}
mt.prototype.clear = function() {
  this._size = 0, this._values = /* @__PURE__ */ Object.create(null);
};
mt.prototype.get = function(r) {
  return this._values[r];
};
mt.prototype.set = function(r, e) {
  return this._size >= this._maxSize && this.clear(), r in this._values || this._size++, this._values[r] = e;
};
var Uu = /[^.^\]^[]+|(?=\[\]|\.\.)/g, ca = /^\d+$/, xu = /^\d/, Pu = /[~`!#$%\^&*+=\-\[\]\\';,/{}|\\":<>\?]/g, Ru = /^\s*(['"]?)(.*?)(\1)\s*$/, xn = 512, Ds = new mt(xn), Ms = new mt(xn), Ns = new mt(xn), zr = {
  Cache: mt,
  split: bn,
  normalizePath: Xr,
  setter: function(r) {
    var e = Xr(r);
    return Ms.get(r) || Ms.set(r, function(n, s) {
      for (var i = 0, a = e.length, l = n; i < a - 1; ) {
        var o = e[i];
        if (o === "__proto__" || o === "constructor" || o === "prototype")
          return n;
        l = l[e[i++]];
      }
      l[e[i]] = s;
    });
  },
  getter: function(r, e) {
    var t = Xr(r);
    return Ns.get(r) || Ns.set(r, function(s) {
      for (var i = 0, a = t.length; i < a; )
        if (s != null || !e)
          s = s[t[i++]];
        else
          return;
      return s;
    });
  },
  join: function(r) {
    return r.reduce(function(e, t) {
      return e + (Pn(t) || ca.test(t) ? "[" + t + "]" : (e ? "." : "") + t);
    }, "");
  },
  forEach: function(r, e, t) {
    zu(Array.isArray(r) ? r : bn(r), e, t);
  }
};
function Xr(r) {
  return Ds.get(r) || Ds.set(
    r,
    bn(r).map(function(e) {
      return e.replace(Ru, "$2");
    })
  );
}
function bn(r) {
  return r.match(Uu) || [""];
}
function zu(r, e, t) {
  var n = r.length, s, i, a, l;
  for (i = 0; i < n; i++)
    s = r[i], s && ($u(s) && (s = '"' + s + '"'), l = Pn(s), a = !l && /^\d+$/.test(s), e.call(t, s, l, a, i, r));
}
function Pn(r) {
  return typeof r == "string" && r && ["'", '"'].indexOf(r.charAt(0)) !== -1;
}
function qu(r) {
  return r.match(xu) && !r.match(ca);
}
function ju(r) {
  return Pu.test(r);
}
function $u(r) {
  return !Pn(r) && (qu(r) || ju(r));
}
const hr = {
  context: "$",
  value: "."
};
function Zu(r, e) {
  return new Xe(r, e);
}
class Xe {
  constructor(e, t = {}) {
    if (typeof e != "string")
      throw new TypeError("ref must be a string, got: " + e);
    if (this.key = e.trim(), e === "")
      throw new TypeError("ref must be a non-empty string");
    this.isContext = this.key[0] === hr.context, this.isValue = this.key[0] === hr.value, this.isSibling = !this.isContext && !this.isValue;
    let n = this.isContext ? hr.context : this.isValue ? hr.value : "";
    this.path = this.key.slice(n.length), this.getter = this.path && zr.getter(this.path, !0), this.map = t.map;
  }
  getValue(e, t, n) {
    let s = this.isContext ? n : this.isValue ? e : t;
    return this.getter && (s = this.getter(s || {})), this.map && (s = this.map(s)), s;
  }
  /**
   *
   * @param {*} value
   * @param {Object} options
   * @param {Object=} options.context
   * @param {Object=} options.parent
   */
  cast(e, t) {
    return this.getValue(e, t == null ? void 0 : t.parent, t == null ? void 0 : t.context);
  }
  resolve() {
    return this;
  }
  describe() {
    return {
      type: "ref",
      key: this.key
    };
  }
  toString() {
    return `Ref(${this.key})`;
  }
  static isRef(e) {
    return e && e.__isYupRef;
  }
}
Xe.prototype.__isYupRef = !0;
function Cr() {
  return Cr = Object.assign || function(r) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var n in t)
        Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Cr.apply(this, arguments);
}
function Hu(r, e) {
  if (r == null)
    return {};
  var t = {}, n = Object.keys(r), s, i;
  for (i = 0; i < n.length; i++)
    s = n[i], !(e.indexOf(s) >= 0) && (t[s] = r[s]);
  return t;
}
function mr(r) {
  function e(t, n) {
    let {
      value: s,
      path: i = "",
      label: a,
      options: l,
      originalValue: o,
      sync: f
    } = t, u = Hu(t, ["value", "path", "label", "options", "originalValue", "sync"]);
    const {
      name: d,
      test: h,
      params: c,
      message: m
    } = r;
    let {
      parent: g,
      context: p
    } = l;
    function y(E) {
      return Xe.isRef(E) ? E.getValue(s, g, p) : E;
    }
    function b(E = {}) {
      const A = fa(Cr({
        value: s,
        originalValue: o,
        label: a,
        path: E.path || i
      }, c, E.params), y), N = new be(be.formatError(E.message || m, A), s, A.path, E.type || d);
      return N.params = A, N;
    }
    let v = Cr({
      path: i,
      parent: g,
      type: d,
      createError: b,
      resolve: y,
      options: l,
      originalValue: o
    }, u);
    if (!f) {
      try {
        Promise.resolve(h.call(v, s, v)).then((E) => {
          be.isError(E) ? n(E) : E ? n(null, E) : n(b());
        });
      } catch (E) {
        n(E);
      }
      return;
    }
    let k;
    try {
      var S;
      if (k = h.call(v, s, v), typeof ((S = k) == null ? void 0 : S.then) == "function")
        throw new Error(`Validation test of type: "${v.type}" returned a Promise during a synchronous validate. This test will finish after the validate call has returned`);
    } catch (E) {
      n(E);
      return;
    }
    be.isError(k) ? n(k) : k ? n(null, k) : n(b());
  }
  return e.OPTIONS = r, e;
}
let Bu = (r) => r.substr(0, r.length - 1).substr(1);
function da(r, e, t, n = t) {
  let s, i, a;
  return e ? (zr.forEach(e, (l, o, f) => {
    let u = o ? Bu(l) : l;
    if (r = r.resolve({
      context: n,
      parent: s,
      value: t
    }), r.innerType) {
      let d = f ? parseInt(u, 10) : 0;
      if (t && d >= t.length)
        throw new Error(`Yup.reach cannot resolve an array item at index: ${l}, in the path: ${e}. because there is no value at that index. `);
      s = t, t = t && t[d], r = r.innerType;
    }
    if (!f) {
      if (!r.fields || !r.fields[u])
        throw new Error(`The schema does not contain the path: ${e}. (failed at: ${a} which is a type: "${r._type}")`);
      s = t, t = t && t[u], r = r.fields[u];
    }
    i = u, a = o ? "[" + l + "]" : "." + l;
  }), {
    schema: r,
    parent: s,
    parentPath: i
  }) : {
    parent: s,
    parentPath: e,
    schema: r
  };
}
const Yu = (r, e, t, n) => da(r, e, t, n).schema;
class Lr {
  constructor() {
    this.list = /* @__PURE__ */ new Set(), this.refs = /* @__PURE__ */ new Map();
  }
  get size() {
    return this.list.size + this.refs.size;
  }
  describe() {
    const e = [];
    for (const t of this.list)
      e.push(t);
    for (const [, t] of this.refs)
      e.push(t.describe());
    return e;
  }
  toArray() {
    return Array.from(this.list).concat(Array.from(this.refs.values()));
  }
  add(e) {
    Xe.isRef(e) ? this.refs.set(e.key, e) : this.list.add(e);
  }
  delete(e) {
    Xe.isRef(e) ? this.refs.delete(e.key) : this.list.delete(e);
  }
  has(e, t) {
    if (this.list.has(e))
      return !0;
    let n, s = this.refs.values();
    for (; n = s.next(), !n.done; )
      if (t(n.value) === e)
        return !0;
    return !1;
  }
  clone() {
    const e = new Lr();
    return e.list = new Set(this.list), e.refs = new Map(this.refs), e;
  }
  merge(e, t) {
    const n = this.clone();
    return e.list.forEach((s) => n.add(s)), e.refs.forEach((s) => n.add(s)), t.list.forEach((s) => n.delete(s)), t.refs.forEach((s) => n.delete(s)), n;
  }
}
function Ne() {
  return Ne = Object.assign || function(r) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var n in t)
        Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Ne.apply(this, arguments);
}
class ce {
  constructor(e) {
    this.deps = [], this.conditions = [], this._whitelist = new Lr(), this._blacklist = new Lr(), this.exclusiveTests = /* @__PURE__ */ Object.create(null), this.tests = [], this.transforms = [], this.withMutation(() => {
      this.typeError(ot.notType);
    }), this.type = (e == null ? void 0 : e.type) || "mixed", this.spec = Ne({
      strip: !1,
      strict: !1,
      abortEarly: !0,
      recursive: !0,
      nullable: !1,
      presence: "optional"
    }, e == null ? void 0 : e.spec);
  }
  // TODO: remove
  get _type() {
    return this.type;
  }
  _typeCheck(e) {
    return !0;
  }
  clone(e) {
    if (this._mutate)
      return e && Object.assign(this.spec, e), this;
    const t = Object.create(Object.getPrototypeOf(this));
    return t.type = this.type, t._typeError = this._typeError, t._whitelistError = this._whitelistError, t._blacklistError = this._blacklistError, t._whitelist = this._whitelist.clone(), t._blacklist = this._blacklist.clone(), t.exclusiveTests = Ne({}, this.exclusiveTests), t.deps = [...this.deps], t.conditions = [...this.conditions], t.tests = [...this.tests], t.transforms = [...this.transforms], t.spec = mn(Ne({}, this.spec, e)), t;
  }
  label(e) {
    var t = this.clone();
    return t.spec.label = e, t;
  }
  meta(...e) {
    if (e.length === 0)
      return this.spec.meta;
    let t = this.clone();
    return t.spec.meta = Object.assign(t.spec.meta || {}, e[0]), t;
  }
  // withContext<TContext extends AnyObject>(): BaseSchema<
  //   TCast,
  //   TContext,
  //   TOutput
  // > {
  //   return this as any;
  // }
  withMutation(e) {
    let t = this._mutate;
    this._mutate = !0;
    let n = e(this);
    return this._mutate = t, n;
  }
  concat(e) {
    if (!e || e === this)
      return this;
    if (e.type !== this.type && this.type !== "mixed")
      throw new TypeError(`You cannot \`concat()\` schema's of different types: ${this.type} and ${e.type}`);
    let t = this, n = e.clone();
    const s = Ne({}, t.spec, n.spec);
    return n.spec = s, n._typeError || (n._typeError = t._typeError), n._whitelistError || (n._whitelistError = t._whitelistError), n._blacklistError || (n._blacklistError = t._blacklistError), n._whitelist = t._whitelist.merge(e._whitelist, e._blacklist), n._blacklist = t._blacklist.merge(e._blacklist, e._whitelist), n.tests = t.tests, n.exclusiveTests = t.exclusiveTests, n.withMutation((i) => {
      e.tests.forEach((a) => {
        i.test(a.OPTIONS);
      });
    }), n;
  }
  isType(e) {
    return this.spec.nullable && e === null ? !0 : this._typeCheck(e);
  }
  resolve(e) {
    let t = this;
    if (t.conditions.length) {
      let n = t.conditions;
      t = t.clone(), t.conditions = [], t = n.reduce((s, i) => i.resolve(s, e), t), t = t.resolve(e);
    }
    return t;
  }
  /**
   *
   * @param {*} value
   * @param {Object} options
   * @param {*=} options.parent
   * @param {*=} options.context
   */
  cast(e, t = {}) {
    let n = this.resolve(Ne({
      value: e
    }, t)), s = n._cast(e, t);
    if (e !== void 0 && t.assert !== !1 && n.isType(s) !== !0) {
      let i = Tt(e), a = Tt(s);
      throw new TypeError(`The value of ${t.path || "field"} could not be cast to a value that satisfies the schema type: "${n._type}". 

attempted value: ${i} 
` + (a !== i ? `result of cast: ${a}` : ""));
    }
    return s;
  }
  _cast(e, t) {
    let n = e === void 0 ? e : this.transforms.reduce((s, i) => i.call(this, s, e, this), e);
    return n === void 0 && (n = this.getDefault()), n;
  }
  _validate(e, t = {}, n) {
    let {
      sync: s,
      path: i,
      from: a = [],
      originalValue: l = e,
      strict: o = this.spec.strict,
      abortEarly: f = this.spec.abortEarly
    } = t, u = e;
    o || (u = this._cast(u, Ne({
      assert: !1
    }, t)));
    let d = {
      value: u,
      path: i,
      options: t,
      originalValue: l,
      schema: this,
      label: this.spec.label,
      sync: s,
      from: a
    }, h = [];
    this._typeError && h.push(this._typeError), this._whitelistError && h.push(this._whitelistError), this._blacklistError && h.push(this._blacklistError), Nr({
      args: d,
      value: u,
      path: i,
      sync: s,
      tests: h,
      endEarly: f
    }, (c) => {
      if (c)
        return void n(c, u);
      Nr({
        tests: this.tests,
        args: d,
        path: i,
        sync: s,
        value: u,
        endEarly: f
      }, n);
    });
  }
  validate(e, t, n) {
    let s = this.resolve(Ne({}, t, {
      value: e
    }));
    return typeof n == "function" ? s._validate(e, t, n) : new Promise((i, a) => s._validate(e, t, (l, o) => {
      l ? a(l) : i(o);
    }));
  }
  validateSync(e, t) {
    let n = this.resolve(Ne({}, t, {
      value: e
    })), s;
    return n._validate(e, Ne({}, t, {
      sync: !0
    }), (i, a) => {
      if (i)
        throw i;
      s = a;
    }), s;
  }
  isValid(e, t) {
    return this.validate(e, t).then(() => !0, (n) => {
      if (be.isError(n))
        return !1;
      throw n;
    });
  }
  isValidSync(e, t) {
    try {
      return this.validateSync(e, t), !0;
    } catch (n) {
      if (be.isError(n))
        return !1;
      throw n;
    }
  }
  _getDefault() {
    let e = this.spec.default;
    return e == null ? e : typeof e == "function" ? e.call(this) : mn(e);
  }
  getDefault(e) {
    return this.resolve(e || {})._getDefault();
  }
  default(e) {
    return arguments.length === 0 ? this._getDefault() : this.clone({
      default: e
    });
  }
  strict(e = !0) {
    var t = this.clone();
    return t.spec.strict = e, t;
  }
  _isPresent(e) {
    return e != null;
  }
  defined(e = ot.defined) {
    return this.test({
      message: e,
      name: "defined",
      exclusive: !0,
      test(t) {
        return t !== void 0;
      }
    });
  }
  required(e = ot.required) {
    return this.clone({
      presence: "required"
    }).withMutation((t) => t.test({
      message: e,
      name: "required",
      exclusive: !0,
      test(n) {
        return this.schema._isPresent(n);
      }
    }));
  }
  notRequired() {
    var e = this.clone({
      presence: "optional"
    });
    return e.tests = e.tests.filter((t) => t.OPTIONS.name !== "required"), e;
  }
  nullable(e = !0) {
    var t = this.clone({
      nullable: e !== !1
    });
    return t;
  }
  transform(e) {
    var t = this.clone();
    return t.transforms.push(e), t;
  }
  /**
   * Adds a test function to the schema's queue of tests.
   * tests can be exclusive or non-exclusive.
   *
   * - exclusive tests, will replace any existing tests of the same name.
   * - non-exclusive: can be stacked
   *
   * If a non-exclusive test is added to a schema with an exclusive test of the same name
   * the exclusive test is removed and further tests of the same name will be stacked.
   *
   * If an exclusive test is added to a schema with non-exclusive tests of the same name
   * the previous tests are removed and further tests of the same name will replace each other.
   */
  test(...e) {
    let t;
    if (e.length === 1 ? typeof e[0] == "function" ? t = {
      test: e[0]
    } : t = e[0] : e.length === 2 ? t = {
      name: e[0],
      test: e[1]
    } : t = {
      name: e[0],
      message: e[1],
      test: e[2]
    }, t.message === void 0 && (t.message = ot.default), typeof t.test != "function")
      throw new TypeError("`test` is a required parameters");
    let n = this.clone(), s = mr(t), i = t.exclusive || t.name && n.exclusiveTests[t.name] === !0;
    if (t.exclusive && !t.name)
      throw new TypeError("Exclusive tests must provide a unique `name` identifying the test");
    return t.name && (n.exclusiveTests[t.name] = !!t.exclusive), n.tests = n.tests.filter((a) => !(a.OPTIONS.name === t.name && (i || a.OPTIONS.test === s.OPTIONS.test))), n.tests.push(s), n;
  }
  when(e, t) {
    !Array.isArray(e) && typeof e != "string" && (t = e, e = ".");
    let n = this.clone(), s = la(e).map((i) => new Xe(i));
    return s.forEach((i) => {
      i.isSibling && n.deps.push(i.key);
    }), n.conditions.push(new wu(s, t)), n;
  }
  typeError(e) {
    var t = this.clone();
    return t._typeError = mr({
      message: e,
      name: "typeError",
      test(n) {
        return n !== void 0 && !this.schema.isType(n) ? this.createError({
          params: {
            type: this.schema._type
          }
        }) : !0;
      }
    }), t;
  }
  oneOf(e, t = ot.oneOf) {
    var n = this.clone();
    return e.forEach((s) => {
      n._whitelist.add(s), n._blacklist.delete(s);
    }), n._whitelistError = mr({
      message: t,
      name: "oneOf",
      test(s) {
        if (s === void 0)
          return !0;
        let i = this.schema._whitelist;
        return i.has(s, this.resolve) ? !0 : this.createError({
          params: {
            values: i.toArray().join(", ")
          }
        });
      }
    }), n;
  }
  notOneOf(e, t = ot.notOneOf) {
    var n = this.clone();
    return e.forEach((s) => {
      n._blacklist.add(s), n._whitelist.delete(s);
    }), n._blacklistError = mr({
      message: t,
      name: "notOneOf",
      test(s) {
        let i = this.schema._blacklist;
        return i.has(s, this.resolve) ? this.createError({
          params: {
            values: i.toArray().join(", ")
          }
        }) : !0;
      }
    }), n;
  }
  strip(e = !0) {
    let t = this.clone();
    return t.spec.strip = e, t;
  }
  describe() {
    const e = this.clone(), {
      label: t,
      meta: n
    } = e.spec;
    return {
      meta: n,
      label: t,
      type: e.type,
      oneOf: e._whitelist.describe(),
      notOneOf: e._blacklist.describe(),
      tests: e.tests.map((i) => ({
        name: i.OPTIONS.name,
        params: i.OPTIONS.params
      })).filter((i, a, l) => l.findIndex((o) => o.name === i.name) === a)
    };
  }
}
ce.prototype.__isYupSchema__ = !0;
for (const r of ["validate", "validateSync"])
  ce.prototype[`${r}At`] = function(e, t, n = {}) {
    const {
      parent: s,
      parentPath: i,
      schema: a
    } = da(this, e, t, n.context);
    return a[r](s && s[i], Ne({}, n, {
      parent: s,
      path: e
    }));
  };
for (const r of ["equals", "is"])
  ce.prototype[r] = ce.prototype.oneOf;
for (const r of ["not", "nope"])
  ce.prototype[r] = ce.prototype.notOneOf;
ce.prototype.optional = ce.prototype.notRequired;
const Rn = ce;
function ha() {
  return new Rn();
}
ha.prototype = Rn.prototype;
const se = (r) => r == null;
function vn() {
  return new zn();
}
class zn extends ce {
  constructor() {
    super({
      type: "boolean"
    }), this.withMutation(() => {
      this.transform(function(e) {
        if (!this.isType(e)) {
          if (/^(true|1)$/i.test(String(e)))
            return !0;
          if (/^(false|0)$/i.test(String(e)))
            return !1;
        }
        return e;
      });
    });
  }
  _typeCheck(e) {
    return e instanceof Boolean && (e = e.valueOf()), typeof e == "boolean";
  }
  isTrue(e = gn.isValue) {
    return this.test({
      message: e,
      name: "is-value",
      exclusive: !0,
      params: {
        value: "true"
      },
      test(t) {
        return se(t) || t === !0;
      }
    });
  }
  isFalse(e = gn.isValue) {
    return this.test({
      message: e,
      name: "is-value",
      exclusive: !0,
      params: {
        value: "false"
      },
      test(t) {
        return se(t) || t === !1;
      }
    });
  }
}
vn.prototype = zn.prototype;
let Gu = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i, Ju = /^((https?|ftp):)?\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i, Ku = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i, Qu = (r) => se(r) || r === r.trim(), Xu = {}.toString();
function ma() {
  return new qn();
}
class qn extends ce {
  constructor() {
    super({
      type: "string"
    }), this.withMutation(() => {
      this.transform(function(e) {
        if (this.isType(e) || Array.isArray(e))
          return e;
        const t = e != null && e.toString ? e.toString() : e;
        return t === Xu ? e : t;
      });
    });
  }
  _typeCheck(e) {
    return e instanceof String && (e = e.valueOf()), typeof e == "string";
  }
  _isPresent(e) {
    return super._isPresent(e) && !!e.length;
  }
  length(e, t = We.length) {
    return this.test({
      message: t,
      name: "length",
      exclusive: !0,
      params: {
        length: e
      },
      test(n) {
        return se(n) || n.length === this.resolve(e);
      }
    });
  }
  min(e, t = We.min) {
    return this.test({
      message: t,
      name: "min",
      exclusive: !0,
      params: {
        min: e
      },
      test(n) {
        return se(n) || n.length >= this.resolve(e);
      }
    });
  }
  max(e, t = We.max) {
    return this.test({
      name: "max",
      exclusive: !0,
      message: t,
      params: {
        max: e
      },
      test(n) {
        return se(n) || n.length <= this.resolve(e);
      }
    });
  }
  matches(e, t) {
    let n = !1, s, i;
    return t && (typeof t == "object" ? {
      excludeEmptyString: n = !1,
      message: s,
      name: i
    } = t : s = t), this.test({
      name: i || "matches",
      message: s || We.matches,
      params: {
        regex: e
      },
      test: (a) => se(a) || a === "" && n || a.search(e) !== -1
    });
  }
  email(e = We.email) {
    return this.matches(Gu, {
      name: "email",
      message: e,
      excludeEmptyString: !0
    });
  }
  url(e = We.url) {
    return this.matches(Ju, {
      name: "url",
      message: e,
      excludeEmptyString: !0
    });
  }
  uuid(e = We.uuid) {
    return this.matches(Ku, {
      name: "uuid",
      message: e,
      excludeEmptyString: !1
    });
  }
  //-- transforms --
  ensure() {
    return this.default("").transform((e) => e === null ? "" : e);
  }
  trim(e = We.trim) {
    return this.transform((t) => t != null ? t.trim() : t).test({
      message: e,
      name: "trim",
      test: Qu
    });
  }
  lowercase(e = We.lowercase) {
    return this.transform((t) => se(t) ? t : t.toLowerCase()).test({
      message: e,
      name: "string_case",
      exclusive: !0,
      test: (t) => se(t) || t === t.toLowerCase()
    });
  }
  uppercase(e = We.uppercase) {
    return this.transform((t) => se(t) ? t : t.toUpperCase()).test({
      message: e,
      name: "string_case",
      exclusive: !0,
      test: (t) => se(t) || t === t.toUpperCase()
    });
  }
}
ma.prototype = qn.prototype;
let ef = (r) => r != +r;
function pa() {
  return new jn();
}
class jn extends ce {
  constructor() {
    super({
      type: "number"
    }), this.withMutation(() => {
      this.transform(function(e) {
        let t = e;
        if (typeof t == "string") {
          if (t = t.replace(/\s/g, ""), t === "")
            return NaN;
          t = +t;
        }
        return this.isType(t) ? t : parseFloat(t);
      });
    });
  }
  _typeCheck(e) {
    return e instanceof Number && (e = e.valueOf()), typeof e == "number" && !ef(e);
  }
  min(e, t = Ge.min) {
    return this.test({
      message: t,
      name: "min",
      exclusive: !0,
      params: {
        min: e
      },
      test(n) {
        return se(n) || n >= this.resolve(e);
      }
    });
  }
  max(e, t = Ge.max) {
    return this.test({
      message: t,
      name: "max",
      exclusive: !0,
      params: {
        max: e
      },
      test(n) {
        return se(n) || n <= this.resolve(e);
      }
    });
  }
  lessThan(e, t = Ge.lessThan) {
    return this.test({
      message: t,
      name: "max",
      exclusive: !0,
      params: {
        less: e
      },
      test(n) {
        return se(n) || n < this.resolve(e);
      }
    });
  }
  moreThan(e, t = Ge.moreThan) {
    return this.test({
      message: t,
      name: "min",
      exclusive: !0,
      params: {
        more: e
      },
      test(n) {
        return se(n) || n > this.resolve(e);
      }
    });
  }
  positive(e = Ge.positive) {
    return this.moreThan(0, e);
  }
  negative(e = Ge.negative) {
    return this.lessThan(0, e);
  }
  integer(e = Ge.integer) {
    return this.test({
      name: "integer",
      message: e,
      test: (t) => se(t) || Number.isInteger(t)
    });
  }
  truncate() {
    return this.transform((e) => se(e) ? e : e | 0);
  }
  round(e) {
    var t, n = ["ceil", "floor", "round", "trunc"];
    if (e = ((t = e) == null ? void 0 : t.toLowerCase()) || "round", e === "trunc")
      return this.truncate();
    if (n.indexOf(e.toLowerCase()) === -1)
      throw new TypeError("Only valid options for round() are: " + n.join(", "));
    return this.transform((s) => se(s) ? s : Math[e](s));
  }
}
pa.prototype = jn.prototype;
var tf = /^(\d{4}|[+\-]\d{6})(?:-?(\d{2})(?:-?(\d{2}))?)?(?:[ T]?(\d{2}):?(\d{2})(?::?(\d{2})(?:[,\.](\d{1,}))?)?(?:(Z)|([+\-])(\d{2})(?::?(\d{2}))?)?)?$/;
function rf(r) {
  var e = [1, 4, 5, 6, 7, 10, 11], t = 0, n, s;
  if (s = tf.exec(r)) {
    for (var i = 0, a; a = e[i]; ++i)
      s[a] = +s[a] || 0;
    s[2] = (+s[2] || 1) - 1, s[3] = +s[3] || 1, s[7] = s[7] ? String(s[7]).substr(0, 3) : 0, (s[8] === void 0 || s[8] === "") && (s[9] === void 0 || s[9] === "") ? n = +new Date(s[1], s[2], s[3], s[4], s[5], s[6], s[7]) : (s[8] !== "Z" && s[9] !== void 0 && (t = s[10] * 60 + s[11], s[9] === "+" && (t = 0 - t)), n = Date.UTC(s[1], s[2], s[3], s[4], s[5] + t, s[6], s[7]));
  } else
    n = Date.parse ? Date.parse(r) : NaN;
  return n;
}
let $n = /* @__PURE__ */ new Date(""), nf = (r) => Object.prototype.toString.call(r) === "[object Date]";
function Zn() {
  return new qr();
}
class qr extends ce {
  constructor() {
    super({
      type: "date"
    }), this.withMutation(() => {
      this.transform(function(e) {
        return this.isType(e) ? e : (e = rf(e), isNaN(e) ? $n : new Date(e));
      });
    });
  }
  _typeCheck(e) {
    return nf(e) && !isNaN(e.getTime());
  }
  prepareParam(e, t) {
    let n;
    if (Xe.isRef(e))
      n = e;
    else {
      let s = this.cast(e);
      if (!this._typeCheck(s))
        throw new TypeError(`\`${t}\` must be a Date or a value that can be \`cast()\` to a Date`);
      n = s;
    }
    return n;
  }
  min(e, t = pn.min) {
    let n = this.prepareParam(e, "min");
    return this.test({
      message: t,
      name: "min",
      exclusive: !0,
      params: {
        min: e
      },
      test(s) {
        return se(s) || s >= this.resolve(n);
      }
    });
  }
  max(e, t = pn.max) {
    var n = this.prepareParam(e, "max");
    return this.test({
      message: t,
      name: "max",
      exclusive: !0,
      params: {
        max: e
      },
      test(s) {
        return se(s) || s <= this.resolve(n);
      }
    });
  }
}
qr.INVALID_DATE = $n;
Zn.prototype = qr.prototype;
Zn.INVALID_DATE = $n;
function sf(r, e, t, n) {
  var s = -1, i = r == null ? 0 : r.length;
  for (n && i && (t = r[++s]); ++s < i; )
    t = e(t, r[s], s, r);
  return t;
}
var af = sf;
function of(r) {
  return function(e) {
    return r == null ? void 0 : r[e];
  };
}
var lf = of, uf = lf, ff = {
  // Latin-1 Supplement block.
  À: "A",
  Á: "A",
  Â: "A",
  Ã: "A",
  Ä: "A",
  Å: "A",
  à: "a",
  á: "a",
  â: "a",
  ã: "a",
  ä: "a",
  å: "a",
  Ç: "C",
  ç: "c",
  Ð: "D",
  ð: "d",
  È: "E",
  É: "E",
  Ê: "E",
  Ë: "E",
  è: "e",
  é: "e",
  ê: "e",
  ë: "e",
  Ì: "I",
  Í: "I",
  Î: "I",
  Ï: "I",
  ì: "i",
  í: "i",
  î: "i",
  ï: "i",
  Ñ: "N",
  ñ: "n",
  Ò: "O",
  Ó: "O",
  Ô: "O",
  Õ: "O",
  Ö: "O",
  Ø: "O",
  ò: "o",
  ó: "o",
  ô: "o",
  õ: "o",
  ö: "o",
  ø: "o",
  Ù: "U",
  Ú: "U",
  Û: "U",
  Ü: "U",
  ù: "u",
  ú: "u",
  û: "u",
  ü: "u",
  Ý: "Y",
  ý: "y",
  ÿ: "y",
  Æ: "Ae",
  æ: "ae",
  Þ: "Th",
  þ: "th",
  ß: "ss",
  // Latin Extended-A block.
  Ā: "A",
  Ă: "A",
  Ą: "A",
  ā: "a",
  ă: "a",
  ą: "a",
  Ć: "C",
  Ĉ: "C",
  Ċ: "C",
  Č: "C",
  ć: "c",
  ĉ: "c",
  ċ: "c",
  č: "c",
  Ď: "D",
  Đ: "D",
  ď: "d",
  đ: "d",
  Ē: "E",
  Ĕ: "E",
  Ė: "E",
  Ę: "E",
  Ě: "E",
  ē: "e",
  ĕ: "e",
  ė: "e",
  ę: "e",
  ě: "e",
  Ĝ: "G",
  Ğ: "G",
  Ġ: "G",
  Ģ: "G",
  ĝ: "g",
  ğ: "g",
  ġ: "g",
  ģ: "g",
  Ĥ: "H",
  Ħ: "H",
  ĥ: "h",
  ħ: "h",
  Ĩ: "I",
  Ī: "I",
  Ĭ: "I",
  Į: "I",
  İ: "I",
  ĩ: "i",
  ī: "i",
  ĭ: "i",
  į: "i",
  ı: "i",
  Ĵ: "J",
  ĵ: "j",
  Ķ: "K",
  ķ: "k",
  ĸ: "k",
  Ĺ: "L",
  Ļ: "L",
  Ľ: "L",
  Ŀ: "L",
  Ł: "L",
  ĺ: "l",
  ļ: "l",
  ľ: "l",
  ŀ: "l",
  ł: "l",
  Ń: "N",
  Ņ: "N",
  Ň: "N",
  Ŋ: "N",
  ń: "n",
  ņ: "n",
  ň: "n",
  ŋ: "n",
  Ō: "O",
  Ŏ: "O",
  Ő: "O",
  ō: "o",
  ŏ: "o",
  ő: "o",
  Ŕ: "R",
  Ŗ: "R",
  Ř: "R",
  ŕ: "r",
  ŗ: "r",
  ř: "r",
  Ś: "S",
  Ŝ: "S",
  Ş: "S",
  Š: "S",
  ś: "s",
  ŝ: "s",
  ş: "s",
  š: "s",
  Ţ: "T",
  Ť: "T",
  Ŧ: "T",
  ţ: "t",
  ť: "t",
  ŧ: "t",
  Ũ: "U",
  Ū: "U",
  Ŭ: "U",
  Ů: "U",
  Ű: "U",
  Ų: "U",
  ũ: "u",
  ū: "u",
  ŭ: "u",
  ů: "u",
  ű: "u",
  ų: "u",
  Ŵ: "W",
  ŵ: "w",
  Ŷ: "Y",
  ŷ: "y",
  Ÿ: "Y",
  Ź: "Z",
  Ż: "Z",
  Ž: "Z",
  ź: "z",
  ż: "z",
  ž: "z",
  Ĳ: "IJ",
  ĳ: "ij",
  Œ: "Oe",
  œ: "oe",
  ŉ: "'n",
  ſ: "s"
}, cf = uf(ff), df = cf, hf = df, mf = Pr, pf = /[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g, gf = "\\u0300-\\u036f", yf = "\\ufe20-\\ufe2f", _f = "\\u20d0-\\u20ff", bf = gf + yf + _f, vf = "[" + bf + "]", wf = RegExp(vf, "g");
function kf(r) {
  return r = mf(r), r && r.replace(pf, hf).replace(wf, "");
}
var Of = kf, Sf = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;
function Tf(r) {
  return r.match(Sf) || [];
}
var Ef = Tf, Ff = /[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;
function Df(r) {
  return Ff.test(r);
}
var Mf = Df, ga = "\\ud800-\\udfff", Nf = "\\u0300-\\u036f", Cf = "\\ufe20-\\ufe2f", Lf = "\\u20d0-\\u20ff", Vf = Nf + Cf + Lf, ya = "\\u2700-\\u27bf", _a = "a-z\\xdf-\\xf6\\xf8-\\xff", If = "\\xac\\xb1\\xd7\\xf7", Af = "\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf", Wf = "\\u2000-\\u206f", Uf = " \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000", ba = "A-Z\\xc0-\\xd6\\xd8-\\xde", xf = "\\ufe0e\\ufe0f", va = If + Af + Wf + Uf, wa = "['’]", Cs = "[" + va + "]", Pf = "[" + Vf + "]", ka = "\\d+", Rf = "[" + ya + "]", Oa = "[" + _a + "]", Sa = "[^" + ga + va + ka + ya + _a + ba + "]", zf = "\\ud83c[\\udffb-\\udfff]", qf = "(?:" + Pf + "|" + zf + ")", jf = "[^" + ga + "]", Ta = "(?:\\ud83c[\\udde6-\\uddff]){2}", Ea = "[\\ud800-\\udbff][\\udc00-\\udfff]", bt = "[" + ba + "]", $f = "\\u200d", Ls = "(?:" + Oa + "|" + Sa + ")", Zf = "(?:" + bt + "|" + Sa + ")", Vs = "(?:" + wa + "(?:d|ll|m|re|s|t|ve))?", Is = "(?:" + wa + "(?:D|LL|M|RE|S|T|VE))?", Fa = qf + "?", Da = "[" + xf + "]?", Hf = "(?:" + $f + "(?:" + [jf, Ta, Ea].join("|") + ")" + Da + Fa + ")*", Bf = "\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])", Yf = "\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])", Gf = Da + Fa + Hf, Jf = "(?:" + [Rf, Ta, Ea].join("|") + ")" + Gf, Kf = RegExp([
  bt + "?" + Oa + "+" + Vs + "(?=" + [Cs, bt, "$"].join("|") + ")",
  Zf + "+" + Is + "(?=" + [Cs, bt + Ls, "$"].join("|") + ")",
  bt + "?" + Ls + "+" + Vs,
  bt + "+" + Is,
  Yf,
  Bf,
  ka,
  Jf
].join("|"), "g");
function Qf(r) {
  return r.match(Kf) || [];
}
var Xf = Qf, ec = Ef, tc = Mf, rc = Pr, nc = Xf;
function sc(r, e, t) {
  return r = rc(r), e = t ? void 0 : e, e === void 0 ? tc(r) ? nc(r) : ec(r) : r.match(e) || [];
}
var ic = sc, ac = af, oc = Of, lc = ic, uc = "['’]", fc = RegExp(uc, "g");
function cc(r) {
  return function(e) {
    return ac(lc(oc(e).replace(fc, "")), r, "");
  };
}
var Ma = cc, dc = Ma, hc = dc(function(r, e, t) {
  return r + (t ? "_" : "") + e.toLowerCase();
}), mc = hc;
const As = /* @__PURE__ */ tt(mc);
function pc(r, e, t) {
  var n = -1, s = r.length;
  e < 0 && (e = -e > s ? 0 : s + e), t = t > s ? s : t, t < 0 && (t += s), s = e > t ? 0 : t - e >>> 0, e >>>= 0;
  for (var i = Array(s); ++n < s; )
    i[n] = r[n + e];
  return i;
}
var gc = pc, yc = gc;
function _c(r, e, t) {
  var n = r.length;
  return t = t === void 0 ? n : t, !e && t >= n ? r : yc(r, e, t);
}
var bc = _c, vc = "\\ud800-\\udfff", wc = "\\u0300-\\u036f", kc = "\\ufe20-\\ufe2f", Oc = "\\u20d0-\\u20ff", Sc = wc + kc + Oc, Tc = "\\ufe0e\\ufe0f", Ec = "\\u200d", Fc = RegExp("[" + Ec + vc + Sc + Tc + "]");
function Dc(r) {
  return Fc.test(r);
}
var Na = Dc;
function Mc(r) {
  return r.split("");
}
var Nc = Mc, Ca = "\\ud800-\\udfff", Cc = "\\u0300-\\u036f", Lc = "\\ufe20-\\ufe2f", Vc = "\\u20d0-\\u20ff", Ic = Cc + Lc + Vc, Ac = "\\ufe0e\\ufe0f", Wc = "[" + Ca + "]", wn = "[" + Ic + "]", kn = "\\ud83c[\\udffb-\\udfff]", Uc = "(?:" + wn + "|" + kn + ")", La = "[^" + Ca + "]", Va = "(?:\\ud83c[\\udde6-\\uddff]){2}", Ia = "[\\ud800-\\udbff][\\udc00-\\udfff]", xc = "\\u200d", Aa = Uc + "?", Wa = "[" + Ac + "]?", Pc = "(?:" + xc + "(?:" + [La, Va, Ia].join("|") + ")" + Wa + Aa + ")*", Rc = Wa + Aa + Pc, zc = "(?:" + [La + wn + "?", wn, Va, Ia, Wc].join("|") + ")", qc = RegExp(kn + "(?=" + kn + ")|" + zc + Rc, "g");
function jc(r) {
  return r.match(qc) || [];
}
var $c = jc, Zc = Nc, Hc = Na, Bc = $c;
function Yc(r) {
  return Hc(r) ? Bc(r) : Zc(r);
}
var Gc = Yc, Jc = bc, Kc = Na, Qc = Gc, Xc = Pr;
function ed(r) {
  return function(e) {
    e = Xc(e);
    var t = Kc(e) ? Qc(e) : void 0, n = t ? t[0] : e.charAt(0), s = t ? Jc(t, 1).join("") : e.slice(1);
    return n[r]() + s;
  };
}
var td = ed, rd = td, nd = rd("toUpperCase"), sd = nd, id = Pr, ad = sd;
function od(r) {
  return ad(id(r).toLowerCase());
}
var ld = od, ud = ld, fd = Ma, cd = fd(function(r, e, t) {
  return e = e.toLowerCase(), r + (t ? ud(e) : e);
}), dd = cd;
const hd = /* @__PURE__ */ tt(dd);
var md = Xi, pd = ua, gd = Qi;
function yd(r, e) {
  var t = {};
  return e = gd(e), pd(r, function(n, s, i) {
    md(t, e(n, s, i), n);
  }), t;
}
var _d = yd;
const bd = /* @__PURE__ */ tt(_d);
var Hn = { exports: {} };
Hn.exports = function(r) {
  return Ua(vd(r), r);
};
Hn.exports.array = Ua;
function Ua(r, e) {
  var t = r.length, n = new Array(t), s = {}, i = t, a = wd(e), l = kd(r);
  for (e.forEach(function(f) {
    if (!l.has(f[0]) || !l.has(f[1]))
      throw new Error("Unknown node. There is an unknown node in the supplied edges.");
  }); i--; )
    s[i] || o(r[i], i, /* @__PURE__ */ new Set());
  return n;
  function o(f, u, d) {
    if (d.has(f)) {
      var h;
      try {
        h = ", node was:" + JSON.stringify(f);
      } catch {
        h = "";
      }
      throw new Error("Cyclic dependency" + h);
    }
    if (!l.has(f))
      throw new Error("Found unknown node. Make sure to provided all involved nodes. Unknown node: " + JSON.stringify(f));
    if (!s[u]) {
      s[u] = !0;
      var c = a.get(f) || /* @__PURE__ */ new Set();
      if (c = Array.from(c), u = c.length) {
        d.add(f);
        do {
          var m = c[--u];
          o(m, l.get(m), d);
        } while (u);
        d.delete(f);
      }
      n[--t] = f;
    }
  }
}
function vd(r) {
  for (var e = /* @__PURE__ */ new Set(), t = 0, n = r.length; t < n; t++) {
    var s = r[t];
    e.add(s[0]), e.add(s[1]);
  }
  return Array.from(e);
}
function wd(r) {
  for (var e = /* @__PURE__ */ new Map(), t = 0, n = r.length; t < n; t++) {
    var s = r[t];
    e.has(s[0]) || e.set(s[0], /* @__PURE__ */ new Set()), e.has(s[1]) || e.set(s[1], /* @__PURE__ */ new Set()), e.get(s[0]).add(s[1]);
  }
  return e;
}
function kd(r) {
  for (var e = /* @__PURE__ */ new Map(), t = 0, n = r.length; t < n; t++)
    e.set(r[t], t);
  return e;
}
var Od = Hn.exports;
const Sd = /* @__PURE__ */ tt(Od);
function Td(r, e = []) {
  let t = [], n = [];
  function s(i, a) {
    var l = zr.split(i)[0];
    ~n.indexOf(l) || n.push(l), ~e.indexOf(`${a}-${l}`) || t.push([a, l]);
  }
  for (const i in r)
    if (Mr(r, i)) {
      let a = r[i];
      ~n.indexOf(i) || n.push(i), Xe.isRef(a) && a.isSibling ? s(a.path, i) : Lt(a) && "deps" in a && a.deps.forEach((l) => s(l, i));
    }
  return Sd.array(n, t).reverse();
}
function Ws(r, e) {
  let t = 1 / 0;
  return r.some((n, s) => {
    var i;
    if (((i = e.path) == null ? void 0 : i.indexOf(n)) !== -1)
      return t = s, !0;
  }), t;
}
function xa(r) {
  return (e, t) => Ws(r, e) - Ws(r, t);
}
function vt() {
  return vt = Object.assign || function(r) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var n in t)
        Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, vt.apply(this, arguments);
}
let Us = (r) => Object.prototype.toString.call(r) === "[object Object]";
function Ed(r, e) {
  let t = Object.keys(r.fields);
  return Object.keys(e).filter((n) => t.indexOf(n) === -1);
}
const Fd = xa([]);
class Bn extends ce {
  constructor(e) {
    super({
      type: "object"
    }), this.fields = /* @__PURE__ */ Object.create(null), this._sortErrors = Fd, this._nodes = [], this._excludedEdges = [], this.withMutation(() => {
      this.transform(function(n) {
        if (typeof n == "string")
          try {
            n = JSON.parse(n);
          } catch {
            n = null;
          }
        return this.isType(n) ? n : null;
      }), e && this.shape(e);
    });
  }
  _typeCheck(e) {
    return Us(e) || typeof e == "function";
  }
  _cast(e, t = {}) {
    var n;
    let s = super._cast(e, t);
    if (s === void 0)
      return this.getDefault();
    if (!this._typeCheck(s))
      return s;
    let i = this.fields, a = (n = t.stripUnknown) != null ? n : this.spec.noUnknown, l = this._nodes.concat(Object.keys(s).filter((d) => this._nodes.indexOf(d) === -1)), o = {}, f = vt({}, t, {
      parent: o,
      __validating: t.__validating || !1
    }), u = !1;
    for (const d of l) {
      let h = i[d], c = Mr(s, d);
      if (h) {
        let m, g = s[d];
        f.path = (t.path ? `${t.path}.` : "") + d, h = h.resolve({
          value: g,
          context: t.context,
          parent: o
        });
        let p = "spec" in h ? h.spec : void 0, y = p == null ? void 0 : p.strict;
        if (p != null && p.strip) {
          u = u || d in s;
          continue;
        }
        m = !t.__validating || !y ? (
          // TODO: use _cast, this is double resolving
          h.cast(s[d], f)
        ) : s[d], m !== void 0 && (o[d] = m);
      } else
        c && !a && (o[d] = s[d]);
      o[d] !== s[d] && (u = !0);
    }
    return u ? o : s;
  }
  _validate(e, t = {}, n) {
    let s = [], {
      sync: i,
      from: a = [],
      originalValue: l = e,
      abortEarly: o = this.spec.abortEarly,
      recursive: f = this.spec.recursive
    } = t;
    a = [{
      schema: this,
      value: l
    }, ...a], t.__validating = !0, t.originalValue = l, t.from = a, super._validate(e, t, (u, d) => {
      if (u) {
        if (!be.isError(u) || o)
          return void n(u, d);
        s.push(u);
      }
      if (!f || !Us(d)) {
        n(s[0] || null, d);
        return;
      }
      l = l || d;
      let h = this._nodes.map((c) => (m, g) => {
        let p = c.indexOf(".") === -1 ? (t.path ? `${t.path}.` : "") + c : `${t.path || ""}["${c}"]`, y = this.fields[c];
        if (y && "validate" in y) {
          y.validate(d[c], vt({}, t, {
            // @ts-ignore
            path: p,
            from: a,
            // inner fields are always strict:
            // 1. this isn't strict so the casting will also have cast inner values
            // 2. this is strict in which case the nested values weren't cast either
            strict: !0,
            parent: d,
            originalValue: l[c]
          }), g);
          return;
        }
        g(null);
      });
      Nr({
        sync: i,
        tests: h,
        value: d,
        errors: s,
        endEarly: o,
        sort: this._sortErrors,
        path: t.path
      }, n);
    });
  }
  clone(e) {
    const t = super.clone(e);
    return t.fields = vt({}, this.fields), t._nodes = this._nodes, t._excludedEdges = this._excludedEdges, t._sortErrors = this._sortErrors, t;
  }
  concat(e) {
    let t = super.concat(e), n = t.fields;
    for (let [s, i] of Object.entries(this.fields)) {
      const a = n[s];
      a === void 0 ? n[s] = i : a instanceof ce && i instanceof ce && (n[s] = i.concat(a));
    }
    return t.withMutation(() => t.shape(n));
  }
  getDefaultFromShape() {
    let e = {};
    return this._nodes.forEach((t) => {
      const n = this.fields[t];
      e[t] = "default" in n ? n.getDefault() : void 0;
    }), e;
  }
  _getDefault() {
    if ("default" in this.spec)
      return super._getDefault();
    if (this._nodes.length)
      return this.getDefaultFromShape();
  }
  shape(e, t = []) {
    let n = this.clone(), s = Object.assign(n.fields, e);
    if (n.fields = s, n._sortErrors = xa(Object.keys(s)), t.length) {
      Array.isArray(t[0]) || (t = [t]);
      let i = t.map(([a, l]) => `${a}-${l}`);
      n._excludedEdges = n._excludedEdges.concat(i);
    }
    return n._nodes = Td(s, n._excludedEdges), n;
  }
  pick(e) {
    const t = {};
    for (const n of e)
      this.fields[n] && (t[n] = this.fields[n]);
    return this.clone().withMutation((n) => (n.fields = {}, n.shape(t)));
  }
  omit(e) {
    const t = this.clone(), n = t.fields;
    t.fields = {};
    for (const s of e)
      delete n[s];
    return t.withMutation(() => t.shape(n));
  }
  from(e, t, n) {
    let s = zr.getter(e, !0);
    return this.transform((i) => {
      if (i == null)
        return i;
      let a = i;
      return Mr(i, e) && (a = vt({}, i), n || delete a[e], a[t] = s(i)), a;
    });
  }
  noUnknown(e = !0, t = yn.noUnknown) {
    typeof e == "string" && (t = e, e = !0);
    let n = this.test({
      name: "noUnknown",
      exclusive: !0,
      message: t,
      test(s) {
        if (s == null)
          return !0;
        const i = Ed(this.schema, s);
        return !e || i.length === 0 || this.createError({
          params: {
            unknown: i.join(", ")
          }
        });
      }
    });
    return n.spec.noUnknown = e, n;
  }
  unknown(e = !0, t = yn.noUnknown) {
    return this.noUnknown(!e, t);
  }
  transformKeys(e) {
    return this.transform((t) => t && bd(t, (n, s) => e(s)));
  }
  camelCase() {
    return this.transformKeys(hd);
  }
  snakeCase() {
    return this.transformKeys(As);
  }
  constantCase() {
    return this.transformKeys((e) => As(e).toUpperCase());
  }
  describe() {
    let e = super.describe();
    return e.fields = fa(this.fields, (t) => t.describe()), e;
  }
}
function Pa(r) {
  return new Bn(r);
}
Pa.prototype = Bn.prototype;
function Vr() {
  return Vr = Object.assign || function(r) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var n in t)
        Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
    }
    return r;
  }, Vr.apply(this, arguments);
}
function Ra(r) {
  return new Yn(r);
}
class Yn extends ce {
  constructor(e) {
    super({
      type: "array"
    }), this.innerType = e, this.withMutation(() => {
      this.transform(function(t) {
        if (typeof t == "string")
          try {
            t = JSON.parse(t);
          } catch {
            t = null;
          }
        return this.isType(t) ? t : null;
      });
    });
  }
  _typeCheck(e) {
    return Array.isArray(e);
  }
  get _subType() {
    return this.innerType;
  }
  _cast(e, t) {
    const n = super._cast(e, t);
    if (!this._typeCheck(n) || !this.innerType)
      return n;
    let s = !1;
    const i = n.map((a, l) => {
      const o = this.innerType.cast(a, Vr({}, t, {
        path: `${t.path || ""}[${l}]`
      }));
      return o !== a && (s = !0), o;
    });
    return s ? i : n;
  }
  _validate(e, t = {}, n) {
    var s, i;
    let a = [], l = t.sync, o = t.path, f = this.innerType, u = (s = t.abortEarly) != null ? s : this.spec.abortEarly, d = (i = t.recursive) != null ? i : this.spec.recursive, h = t.originalValue != null ? t.originalValue : e;
    super._validate(e, t, (c, m) => {
      if (c) {
        if (!be.isError(c) || u)
          return void n(c, m);
        a.push(c);
      }
      if (!d || !f || !this._typeCheck(m)) {
        n(a[0] || null, m);
        return;
      }
      h = h || m;
      let g = new Array(m.length);
      for (let p = 0; p < m.length; p++) {
        let y = m[p], b = `${t.path || ""}[${p}]`, v = Vr({}, t, {
          path: b,
          strict: !0,
          parent: m,
          index: p,
          originalValue: h[p]
        });
        g[p] = (k, S) => f.validate(y, v, S);
      }
      Nr({
        sync: l,
        path: o,
        value: m,
        errors: a,
        endEarly: u,
        tests: g
      }, n);
    });
  }
  clone(e) {
    const t = super.clone(e);
    return t.innerType = this.innerType, t;
  }
  concat(e) {
    let t = super.concat(e);
    return t.innerType = this.innerType, e.innerType && (t.innerType = t.innerType ? (
      // @ts-expect-error Lazy doesn't have concat()
      t.innerType.concat(e.innerType)
    ) : e.innerType), t;
  }
  of(e) {
    let t = this.clone();
    if (!Lt(e))
      throw new TypeError("`array.of()` sub-schema must be a valid yup schema not: " + Tt(e));
    return t.innerType = e, t;
  }
  length(e, t = wr.length) {
    return this.test({
      message: t,
      name: "length",
      exclusive: !0,
      params: {
        length: e
      },
      test(n) {
        return se(n) || n.length === this.resolve(e);
      }
    });
  }
  min(e, t) {
    return t = t || wr.min, this.test({
      message: t,
      name: "min",
      exclusive: !0,
      params: {
        min: e
      },
      // FIXME(ts): Array<typeof T>
      test(n) {
        return se(n) || n.length >= this.resolve(e);
      }
    });
  }
  max(e, t) {
    return t = t || wr.max, this.test({
      message: t,
      name: "max",
      exclusive: !0,
      params: {
        max: e
      },
      test(n) {
        return se(n) || n.length <= this.resolve(e);
      }
    });
  }
  ensure() {
    return this.default(() => []).transform((e, t) => this._typeCheck(e) ? e : t == null ? [] : [].concat(t));
  }
  compact(e) {
    let t = e ? (n, s, i) => !e(n, s, i) : (n) => !!n;
    return this.transform((n) => n != null ? n.filter(t) : n);
  }
  describe() {
    let e = super.describe();
    return this.innerType && (e.innerType = this.innerType.describe()), e;
  }
  nullable(e = !0) {
    return super.nullable(e);
  }
  defined() {
    return super.defined();
  }
  required(e) {
    return super.required(e);
  }
}
Ra.prototype = Yn.prototype;
function Dd(r) {
  return new Md(r);
}
class Md {
  constructor(e) {
    this.type = "lazy", this.__isYupSchema__ = !0, this._resolve = (t, n = {}) => {
      let s = this.builder(t, n);
      if (!Lt(s))
        throw new TypeError("lazy() functions must return a valid schema");
      return s.resolve(n);
    }, this.builder = e;
  }
  resolve(e) {
    return this._resolve(e.value, e);
  }
  cast(e, t) {
    return this._resolve(e, t).cast(e, t);
  }
  validate(e, t, n) {
    return this._resolve(e, t).validate(e, t, n);
  }
  validateSync(e, t) {
    return this._resolve(e, t).validateSync(e, t);
  }
  validateAt(e, t, n) {
    return this._resolve(t, n).validateAt(e, t, n);
  }
  validateSyncAt(e, t, n) {
    return this._resolve(t, n).validateSyncAt(e, t, n);
  }
  describe() {
    return null;
  }
  isValid(e, t) {
    return this._resolve(e, t).isValid(e, t);
  }
  isValidSync(e, t) {
    return this._resolve(e, t).isValidSync(e, t);
  }
}
function Nd(r) {
  Object.keys(r).forEach((e) => {
    Object.keys(r[e]).forEach((t) => {
      du[e][t] = r[e][t];
    });
  });
}
function Cd(r, e, t) {
  if (!r || !Lt(r.prototype))
    throw new TypeError("You must provide a yup schema constructor function");
  if (typeof e != "string")
    throw new TypeError("A Method name must be provided");
  if (typeof t != "function")
    throw new TypeError("Method function must be provided");
  r.prototype[e] = t;
}
const Ld = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ArraySchema: Yn,
  BaseSchema: ce,
  BooleanSchema: zn,
  DateSchema: qr,
  MixedSchema: Rn,
  NumberSchema: jn,
  ObjectSchema: Bn,
  StringSchema: qn,
  ValidationError: be,
  addMethod: Cd,
  array: Ra,
  bool: vn,
  boolean: vn,
  date: Zn,
  isSchema: Lt,
  lazy: Dd,
  mixed: ha,
  number: pa,
  object: Pa,
  reach: Yu,
  ref: Zu,
  setLocale: Nd,
  string: ma
}, Symbol.toStringTag, { value: "Module" })), Vd = /* @__PURE__ */ _l(Ld);
var pr = {}, xs;
function Id() {
  if (xs)
    return pr;
  xs = 1, Object.defineProperty(pr, "__esModule", { value: !0 });
  const r = za();
  return pr.default = () => {
    (0, r.registerOptionPreset)("npm-node-cron", {
      // https://github.com/kelektiv/node-cron
      presetId: "npm-node-cron",
      useSeconds: !0,
      useYears: !1,
      useAliases: !0,
      useBlankDay: !1,
      allowOnlyOneBlankDayField: !1,
      mustHaveBlankDayField: !1,
      useLastDayOfMonth: !1,
      useLastDayOfWeek: !1,
      useNearestWeekday: !1,
      useNthWeekdayOfMonth: !1,
      seconds: {
        minValue: 0,
        maxValue: 59
      },
      minutes: {
        minValue: 0,
        maxValue: 59
      },
      hours: {
        minValue: 0,
        maxValue: 23
      },
      daysOfMonth: {
        minValue: 1,
        maxValue: 31
      },
      months: {
        minValue: 0,
        maxValue: 11
      },
      daysOfWeek: {
        minValue: 0,
        maxValue: 6
      },
      years: {
        minValue: 1970,
        maxValue: 2099
      }
    }), (0, r.registerOptionPreset)("aws-cloud-watch", {
      // https://docs.aws.amazon.com/de_de/AmazonCloudWatch/latest/events/ScheduledEvents.html
      presetId: "aws-cloud-watch",
      useSeconds: !1,
      useYears: !0,
      useAliases: !0,
      useBlankDay: !0,
      allowOnlyOneBlankDayField: !0,
      mustHaveBlankDayField: !0,
      useLastDayOfMonth: !0,
      useLastDayOfWeek: !0,
      useNearestWeekday: !0,
      useNthWeekdayOfMonth: !0,
      seconds: {
        minValue: 0,
        maxValue: 59
      },
      minutes: {
        minValue: 0,
        maxValue: 59
      },
      hours: {
        minValue: 0,
        maxValue: 23
      },
      daysOfMonth: {
        minValue: 1,
        maxValue: 31
      },
      months: {
        minValue: 1,
        maxValue: 12
      },
      daysOfWeek: {
        minValue: 1,
        maxValue: 7
      },
      years: {
        minValue: 1970,
        maxValue: 2199
      }
    }), (0, r.registerOptionPreset)("npm-cron-schedule", {
      // https://github.com/P4sca1/cron-schedule
      presetId: "npm-cron-schedule",
      useSeconds: !0,
      useYears: !1,
      useAliases: !0,
      useBlankDay: !1,
      allowOnlyOneBlankDayField: !1,
      mustHaveBlankDayField: !1,
      useLastDayOfMonth: !1,
      useLastDayOfWeek: !1,
      useNearestWeekday: !1,
      useNthWeekdayOfMonth: !1,
      seconds: {
        minValue: 0,
        maxValue: 59
      },
      minutes: {
        minValue: 0,
        maxValue: 59
      },
      hours: {
        minValue: 0,
        maxValue: 23
      },
      daysOfMonth: {
        minValue: 1,
        maxValue: 31
      },
      months: {
        minValue: 1,
        maxValue: 12
      },
      daysOfWeek: {
        minValue: 0,
        maxValue: 7
      },
      years: {
        minValue: 1970,
        maxValue: 2099
      }
    });
  }, pr;
}
var Ps;
function za() {
  if (Ps)
    return Ve;
  Ps = 1;
  var r = te && te.__createBinding || (Object.create ? function(c, m, g, p) {
    p === void 0 && (p = g);
    var y = Object.getOwnPropertyDescriptor(m, g);
    (!y || ("get" in y ? !m.__esModule : y.writable || y.configurable)) && (y = { enumerable: !0, get: function() {
      return m[g];
    } }), Object.defineProperty(c, p, y);
  } : function(c, m, g, p) {
    p === void 0 && (p = g), c[p] = m[g];
  }), e = te && te.__setModuleDefault || (Object.create ? function(c, m) {
    Object.defineProperty(c, "default", { enumerable: !0, value: m });
  } : function(c, m) {
    c.default = m;
  }), t = te && te.__importStar || function(c) {
    if (c && c.__esModule)
      return c;
    var m = {};
    if (c != null)
      for (var g in c)
        g !== "default" && Object.prototype.hasOwnProperty.call(c, g) && r(m, c, g);
    return e(m, c), m;
  }, n = te && te.__importDefault || function(c) {
    return c && c.__esModule ? c : { default: c };
  };
  Object.defineProperty(Ve, "__esModule", { value: !0 }), Ve.validateOptions = Ve.registerOptionPreset = Ve.getOptionPresets = Ve.getOptionPreset = void 0;
  const s = t(Vd), i = Re, a = n(Id()), l = {
    // http://crontab.org/
    default: {
      presetId: "default",
      useSeconds: !1,
      useYears: !1,
      useAliases: !1,
      useBlankDay: !1,
      allowOnlyOneBlankDayField: !1,
      mustHaveBlankDayField: !1,
      useLastDayOfMonth: !1,
      useLastDayOfWeek: !1,
      useNearestWeekday: !1,
      useNthWeekdayOfMonth: !1,
      seconds: {
        minValue: 0,
        maxValue: 59
      },
      minutes: {
        minValue: 0,
        maxValue: 59
      },
      hours: {
        minValue: 0,
        maxValue: 23
      },
      daysOfMonth: {
        minValue: 0,
        maxValue: 31
      },
      months: {
        minValue: 0,
        maxValue: 12
      },
      daysOfWeek: {
        minValue: 0,
        maxValue: 7
      },
      years: {
        minValue: 1970,
        maxValue: 2099
      }
    }
  }, o = s.object({
    presetId: s.string().required(),
    useSeconds: s.boolean().required(),
    useYears: s.boolean().required(),
    useAliases: s.boolean(),
    useBlankDay: s.boolean().required(),
    allowOnlyOneBlankDayField: s.boolean().required(),
    mustHaveBlankDayField: s.boolean(),
    useLastDayOfMonth: s.boolean(),
    useLastDayOfWeek: s.boolean(),
    useNearestWeekday: s.boolean(),
    useNthWeekdayOfMonth: s.boolean(),
    seconds: s.object({
      minValue: s.number().min(0).required(),
      maxValue: s.number().min(0).required(),
      lowerLimit: s.number().min(0),
      upperLimit: s.number().min(0)
    }).required(),
    minutes: s.object({
      minValue: s.number().min(0).required(),
      maxValue: s.number().min(0).required(),
      lowerLimit: s.number().min(0),
      upperLimit: s.number().min(0)
    }).required(),
    hours: s.object({
      minValue: s.number().min(0).required(),
      maxValue: s.number().min(0).required(),
      lowerLimit: s.number().min(0),
      upperLimit: s.number().min(0)
    }).required(),
    daysOfMonth: s.object({
      minValue: s.number().min(0).required(),
      maxValue: s.number().min(0).required(),
      lowerLimit: s.number().min(0),
      upperLimit: s.number().min(0)
    }).required(),
    months: s.object({
      minValue: s.number().min(0).required(),
      maxValue: s.number().min(0).required(),
      lowerLimit: s.number().min(0),
      upperLimit: s.number().min(0)
    }).required(),
    daysOfWeek: s.object({
      minValue: s.number().min(0).required(),
      maxValue: s.number().min(0).required(),
      lowerLimit: s.number().min(0),
      upperLimit: s.number().min(0)
    }).required(),
    years: s.object({
      minValue: s.number().min(0).required(),
      maxValue: s.number().min(0).required(),
      lowerLimit: s.number().min(0),
      upperLimit: s.number().min(0)
    }).required()
  }).required(), f = (c) => l[c] ? (0, i.valid)(l[c]) : (0, i.err)(`Option preset '${c}' not found.`);
  Ve.getOptionPreset = f;
  const u = () => l;
  Ve.getOptionPresets = u;
  const d = (c, m) => {
    l[c] = o.validateSync(m, {
      strict: !1,
      abortEarly: !1,
      stripUnknown: !0,
      recursive: !0
    });
  };
  Ve.registerOptionPreset = d;
  const h = (c) => {
    var m, g, p, y, b, v, k, S, E, A, N, Z, H, G, ie, V, we, U, _e, he;
    try {
      (0, a.default)();
      let F;
      if (c.preset)
        if (typeof c.preset == "string") {
          if (!l[c.preset])
            return (0, i.err)([`Option preset ${c.preset} does not exist.`]);
          F = l[c.preset];
        } else
          F = c.preset;
      else
        F = l.default;
      const B = Object.assign(Object.assign({ presetId: F.presetId, preset: F }, {
        useSeconds: F.useSeconds,
        useYears: F.useYears,
        useAliases: (m = F.useAliases) !== null && m !== void 0 ? m : !1,
        useBlankDay: F.useBlankDay,
        allowOnlyOneBlankDayField: F.allowOnlyOneBlankDayField,
        mustHaveBlankDayField: (g = F.mustHaveBlankDayField) !== null && g !== void 0 ? g : !1,
        useLastDayOfMonth: (p = F.useLastDayOfMonth) !== null && p !== void 0 ? p : !1,
        useLastDayOfWeek: (y = F.useLastDayOfWeek) !== null && y !== void 0 ? y : !1,
        useNearestWeekday: (b = F.useNearestWeekday) !== null && b !== void 0 ? b : !1,
        useNthWeekdayOfMonth: (v = F.useNthWeekdayOfMonth) !== null && v !== void 0 ? v : !1,
        seconds: {
          lowerLimit: (k = F.seconds.lowerLimit) !== null && k !== void 0 ? k : F.seconds.minValue,
          upperLimit: (S = F.seconds.upperLimit) !== null && S !== void 0 ? S : F.seconds.maxValue
        },
        minutes: {
          lowerLimit: (E = F.minutes.lowerLimit) !== null && E !== void 0 ? E : F.minutes.minValue,
          upperLimit: (A = F.minutes.upperLimit) !== null && A !== void 0 ? A : F.minutes.maxValue
        },
        hours: {
          lowerLimit: (N = F.hours.lowerLimit) !== null && N !== void 0 ? N : F.hours.minValue,
          upperLimit: (Z = F.hours.upperLimit) !== null && Z !== void 0 ? Z : F.hours.maxValue
        },
        daysOfMonth: {
          lowerLimit: (H = F.daysOfMonth.lowerLimit) !== null && H !== void 0 ? H : F.daysOfMonth.minValue,
          upperLimit: (G = F.daysOfMonth.upperLimit) !== null && G !== void 0 ? G : F.daysOfMonth.maxValue
        },
        months: {
          lowerLimit: (ie = F.months.lowerLimit) !== null && ie !== void 0 ? ie : F.months.minValue,
          upperLimit: (V = F.months.upperLimit) !== null && V !== void 0 ? V : F.months.maxValue
        },
        daysOfWeek: {
          lowerLimit: (we = F.daysOfWeek.lowerLimit) !== null && we !== void 0 ? we : F.daysOfWeek.minValue,
          upperLimit: (U = F.daysOfWeek.upperLimit) !== null && U !== void 0 ? U : F.daysOfWeek.maxValue
        },
        years: {
          lowerLimit: (_e = F.years.lowerLimit) !== null && _e !== void 0 ? _e : F.years.minValue,
          upperLimit: (he = F.years.upperLimit) !== null && he !== void 0 ? he : F.years.maxValue
        }
      }), c.override), xt = s.object({
        presetId: s.string().required(),
        preset: o.required(),
        useSeconds: s.boolean().required(),
        useYears: s.boolean().required(),
        useAliases: s.boolean(),
        useBlankDay: s.boolean().required(),
        allowOnlyOneBlankDayField: s.boolean().required(),
        mustHaveBlankDayField: s.boolean(),
        useLastDayOfMonth: s.boolean(),
        useLastDayOfWeek: s.boolean(),
        useNearestWeekday: s.boolean(),
        useNthWeekdayOfMonth: s.boolean(),
        seconds: s.object({
          lowerLimit: s.number().min(F.seconds.minValue).max(F.seconds.maxValue),
          upperLimit: s.number().min(F.seconds.minValue).max(F.seconds.maxValue)
        }).required(),
        minutes: s.object({
          lowerLimit: s.number().min(F.minutes.minValue).max(F.minutes.maxValue),
          upperLimit: s.number().min(F.minutes.minValue).max(F.minutes.maxValue)
        }).required(),
        hours: s.object({
          lowerLimit: s.number().min(F.hours.minValue).max(F.hours.maxValue),
          upperLimit: s.number().min(F.hours.minValue).max(F.hours.maxValue)
        }).required(),
        daysOfMonth: s.object({
          lowerLimit: s.number().min(F.daysOfMonth.minValue).max(F.daysOfMonth.maxValue),
          upperLimit: s.number().min(F.daysOfMonth.minValue).max(F.daysOfMonth.maxValue)
        }).required(),
        months: s.object({
          lowerLimit: s.number().min(F.months.minValue).max(F.months.maxValue),
          upperLimit: s.number().min(F.months.minValue).max(F.months.maxValue)
        }).required(),
        daysOfWeek: s.object({
          lowerLimit: s.number().min(F.daysOfWeek.minValue).max(F.daysOfWeek.maxValue),
          upperLimit: s.number().min(F.daysOfWeek.minValue).max(F.daysOfWeek.maxValue)
        }).required(),
        years: s.object({
          lowerLimit: s.number().min(F.years.minValue).max(F.years.maxValue),
          upperLimit: s.number().min(F.years.minValue).max(F.years.maxValue)
        }).required()
      }).required().validateSync(B, {
        strict: !1,
        abortEarly: !1,
        stripUnknown: !0,
        recursive: !0
      });
      return (0, i.valid)(xt);
    } catch (F) {
      return (0, i.err)(F.errors);
    }
  };
  return Ve.validateOptions = h, Ve;
}
var Rs;
function Be() {
  return Rs || (Rs = 1, function(r, e) {
    var t = te && te.__importDefault || function(m) {
      return m && m.__esModule ? m : { default: m };
    };
    Object.defineProperty(e, "__esModule", { value: !0 });
    const n = Re, s = t(Xl()), i = t(eu()), a = t(tu()), l = t(ru()), o = t(nu()), f = t(su()), u = t(iu()), d = za(), h = (m, g) => {
      const p = m.trim().split(" ");
      if (g.useSeconds && g.useYears && p.length !== 7)
        return (0, n.err)(`Expected 7 values, but got ${p.length}.`);
      if ((g.useSeconds && !g.useYears || g.useYears && !g.useSeconds) && p.length !== 6)
        return (0, n.err)(`Expected 6 values, but got ${p.length}.`);
      if (!g.useSeconds && !g.useYears && p.length !== 5)
        return (0, n.err)(`Expected 5 values, but got ${p.length}.`);
      const y = {
        seconds: g.useSeconds ? p[0] : void 0,
        minutes: p[g.useSeconds ? 1 : 0],
        hours: p[g.useSeconds ? 2 : 1],
        daysOfMonth: p[g.useSeconds ? 3 : 2],
        months: p[g.useSeconds ? 4 : 3],
        daysOfWeek: p[g.useSeconds ? 5 : 4],
        years: g.useYears ? p[g.useSeconds ? 6 : 5] : void 0
      };
      return (0, n.valid)(y);
    }, c = (m, g = {}) => {
      const p = (0, d.validateOptions)(g);
      if (p.isError())
        return p;
      const y = p.getValue(), b = h(m, y);
      if (b.isError())
        return (0, n.err)([`${b.getError()} (Input cron: '${m}')`]);
      const v = b.getValue(), k = [];
      if (y.useSeconds && k.push((0, s.default)(v, y)), k.push((0, i.default)(v, y)), k.push((0, a.default)(v, y)), k.push((0, l.default)(v, y)), k.push((0, o.default)(v, y)), k.push((0, f.default)(v, y)), y.useYears && k.push((0, u.default)(v, y)), k.every((E) => E.isValid()))
        return (0, n.valid)(v);
      const S = [];
      return k.forEach((E) => {
        E.isError() && E.getError().forEach((A) => {
          S.push(A);
        });
      }), S.forEach((E, A) => {
        S[A] = `${E} (Input cron: '${m}')`;
      }), (0, n.err)(S);
    };
    e.default = c, r.exports = c, r.exports.default = c;
  }(sr, sr.exports)), sr.exports;
}
var Ad = Be();
const Wd = /* @__PURE__ */ tt(Ad);
var Fe = {};
Object.defineProperty(Fe, "__esModule", { value: !0 });
class pt extends Error {
}
class Ud extends pt {
  constructor(e) {
    super(`Invalid DateTime: ${e.toMessage()}`);
  }
}
class xd extends pt {
  constructor(e) {
    super(`Invalid Interval: ${e.toMessage()}`);
  }
}
class Pd extends pt {
  constructor(e) {
    super(`Invalid Duration: ${e.toMessage()}`);
  }
}
class wt extends pt {
}
class qa extends pt {
  constructor(e) {
    super(`Invalid unit ${e}`);
  }
}
class me extends pt {
}
class Ye extends pt {
  constructor() {
    super("Zone is an abstract class");
  }
}
const D = "numeric", xe = "short", ke = "long", Ir = {
  year: D,
  month: D,
  day: D
}, ja = {
  year: D,
  month: xe,
  day: D
}, Rd = {
  year: D,
  month: xe,
  day: D,
  weekday: xe
}, $a = {
  year: D,
  month: ke,
  day: D
}, Za = {
  year: D,
  month: ke,
  day: D,
  weekday: ke
}, Ha = {
  hour: D,
  minute: D
}, Ba = {
  hour: D,
  minute: D,
  second: D
}, Ya = {
  hour: D,
  minute: D,
  second: D,
  timeZoneName: xe
}, Ga = {
  hour: D,
  minute: D,
  second: D,
  timeZoneName: ke
}, Ja = {
  hour: D,
  minute: D,
  hourCycle: "h23"
}, Ka = {
  hour: D,
  minute: D,
  second: D,
  hourCycle: "h23"
}, Qa = {
  hour: D,
  minute: D,
  second: D,
  hourCycle: "h23",
  timeZoneName: xe
}, Xa = {
  hour: D,
  minute: D,
  second: D,
  hourCycle: "h23",
  timeZoneName: ke
}, eo = {
  year: D,
  month: D,
  day: D,
  hour: D,
  minute: D
}, to = {
  year: D,
  month: D,
  day: D,
  hour: D,
  minute: D,
  second: D
}, ro = {
  year: D,
  month: xe,
  day: D,
  hour: D,
  minute: D
}, no = {
  year: D,
  month: xe,
  day: D,
  hour: D,
  minute: D,
  second: D
}, zd = {
  year: D,
  month: xe,
  day: D,
  weekday: xe,
  hour: D,
  minute: D
}, so = {
  year: D,
  month: ke,
  day: D,
  hour: D,
  minute: D,
  timeZoneName: xe
}, io = {
  year: D,
  month: ke,
  day: D,
  hour: D,
  minute: D,
  second: D,
  timeZoneName: xe
}, ao = {
  year: D,
  month: ke,
  day: D,
  weekday: ke,
  hour: D,
  minute: D,
  timeZoneName: ke
}, oo = {
  year: D,
  month: ke,
  day: D,
  weekday: ke,
  hour: D,
  minute: D,
  second: D,
  timeZoneName: ke
};
class Vt {
  /**
   * The type of zone
   * @abstract
   * @type {string}
   */
  get type() {
    throw new Ye();
  }
  /**
   * The name of this zone.
   * @abstract
   * @type {string}
   */
  get name() {
    throw new Ye();
  }
  /**
   * The IANA name of this zone.
   * Defaults to `name` if not overwritten by a subclass.
   * @abstract
   * @type {string}
   */
  get ianaName() {
    return this.name;
  }
  /**
   * Returns whether the offset is known to be fixed for the whole year.
   * @abstract
   * @type {boolean}
   */
  get isUniversal() {
    throw new Ye();
  }
  /**
   * Returns the offset's common name (such as EST) at the specified timestamp
   * @abstract
   * @param {number} ts - Epoch milliseconds for which to get the name
   * @param {Object} opts - Options to affect the format
   * @param {string} opts.format - What style of offset to return. Accepts 'long' or 'short'.
   * @param {string} opts.locale - What locale to return the offset name in.
   * @return {string}
   */
  offsetName(e, t) {
    throw new Ye();
  }
  /**
   * Returns the offset's value as a string
   * @abstract
   * @param {number} ts - Epoch milliseconds for which to get the offset
   * @param {string} format - What style of offset to return.
   *                          Accepts 'narrow', 'short', or 'techie'. Returning '+6', '+06:00', or '+0600' respectively
   * @return {string}
   */
  formatOffset(e, t) {
    throw new Ye();
  }
  /**
   * Return the offset in minutes for this zone at the specified timestamp.
   * @abstract
   * @param {number} ts - Epoch milliseconds for which to compute the offset
   * @return {number}
   */
  offset(e) {
    throw new Ye();
  }
  /**
   * Return whether this Zone is equal to another zone
   * @abstract
   * @param {Zone} otherZone - the zone to compare
   * @return {boolean}
   */
  equals(e) {
    throw new Ye();
  }
  /**
   * Return whether this Zone is valid.
   * @abstract
   * @type {boolean}
   */
  get isValid() {
    throw new Ye();
  }
}
let en = null;
class Xt extends Vt {
  /**
   * Get a singleton instance of the local zone
   * @return {SystemZone}
   */
  static get instance() {
    return en === null && (en = new Xt()), en;
  }
  /** @override **/
  get type() {
    return "system";
  }
  /** @override **/
  get name() {
    return new Intl.DateTimeFormat().resolvedOptions().timeZone;
  }
  /** @override **/
  get isUniversal() {
    return !1;
  }
  /** @override **/
  offsetName(e, {
    format: t,
    locale: n
  }) {
    return vo(e, t, n);
  }
  /** @override **/
  formatOffset(e, t) {
    return Yt(this.offset(e), t);
  }
  /** @override **/
  offset(e) {
    return -new Date(e).getTimezoneOffset();
  }
  /** @override **/
  equals(e) {
    return e.type === "system";
  }
  /** @override **/
  get isValid() {
    return !0;
  }
}
const On = /* @__PURE__ */ new Map();
function qd(r) {
  let e = On.get(r);
  return e === void 0 && (e = new Intl.DateTimeFormat("en-US", {
    hour12: !1,
    timeZone: r,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    era: "short"
  }), On.set(r, e)), e;
}
const jd = {
  year: 0,
  month: 1,
  day: 2,
  era: 3,
  hour: 4,
  minute: 5,
  second: 6
};
function $d(r, e) {
  const t = r.format(e).replace(/\u200E/g, ""), n = /(\d+)\/(\d+)\/(\d+) (AD|BC),? (\d+):(\d+):(\d+)/.exec(t), [, s, i, a, l, o, f, u] = n;
  return [a, s, i, l, o, f, u];
}
function Zd(r, e) {
  const t = r.formatToParts(e), n = [];
  for (let s = 0; s < t.length; s++) {
    const {
      type: i,
      value: a
    } = t[s], l = jd[i];
    i === "era" ? n[l] = a : x(l) || (n[l] = parseInt(a, 10));
  }
  return n;
}
const tn = /* @__PURE__ */ new Map();
class je extends Vt {
  /**
   * @param {string} name - Zone name
   * @return {IANAZone}
   */
  static create(e) {
    let t = tn.get(e);
    return t === void 0 && tn.set(e, t = new je(e)), t;
  }
  /**
   * Reset local caches. Should only be necessary in testing scenarios.
   * @return {void}
   */
  static resetCache() {
    tn.clear(), On.clear();
  }
  /**
   * Returns whether the provided string is a valid specifier. This only checks the string's format, not that the specifier identifies a known zone; see isValidZone for that.
   * @param {string} s - The string to check validity on
   * @example IANAZone.isValidSpecifier("America/New_York") //=> true
   * @example IANAZone.isValidSpecifier("Sport~~blorp") //=> false
   * @deprecated For backward compatibility, this forwards to isValidZone, better use `isValidZone()` directly instead.
   * @return {boolean}
   */
  static isValidSpecifier(e) {
    return this.isValidZone(e);
  }
  /**
   * Returns whether the provided string identifies a real zone
   * @param {string} zone - The string to check
   * @example IANAZone.isValidZone("America/New_York") //=> true
   * @example IANAZone.isValidZone("Fantasia/Castle") //=> false
   * @example IANAZone.isValidZone("Sport~~blorp") //=> false
   * @return {boolean}
   */
  static isValidZone(e) {
    if (!e)
      return !1;
    try {
      return new Intl.DateTimeFormat("en-US", {
        timeZone: e
      }).format(), !0;
    } catch {
      return !1;
    }
  }
  constructor(e) {
    super(), this.zoneName = e, this.valid = je.isValidZone(e);
  }
  /**
   * The type of zone. `iana` for all instances of `IANAZone`.
   * @override
   * @type {string}
   */
  get type() {
    return "iana";
  }
  /**
   * The name of this zone (i.e. the IANA zone name).
   * @override
   * @type {string}
   */
  get name() {
    return this.zoneName;
  }
  /**
   * Returns whether the offset is known to be fixed for the whole year:
   * Always returns false for all IANA zones.
   * @override
   * @type {boolean}
   */
  get isUniversal() {
    return !1;
  }
  /**
   * Returns the offset's common name (such as EST) at the specified timestamp
   * @override
   * @param {number} ts - Epoch milliseconds for which to get the name
   * @param {Object} opts - Options to affect the format
   * @param {string} opts.format - What style of offset to return. Accepts 'long' or 'short'.
   * @param {string} opts.locale - What locale to return the offset name in.
   * @return {string}
   */
  offsetName(e, {
    format: t,
    locale: n
  }) {
    return vo(e, t, n, this.name);
  }
  /**
   * Returns the offset's value as a string
   * @override
   * @param {number} ts - Epoch milliseconds for which to get the offset
   * @param {string} format - What style of offset to return.
   *                          Accepts 'narrow', 'short', or 'techie'. Returning '+6', '+06:00', or '+0600' respectively
   * @return {string}
   */
  formatOffset(e, t) {
    return Yt(this.offset(e), t);
  }
  /**
   * Return the offset in minutes for this zone at the specified timestamp.
   * @override
   * @param {number} ts - Epoch milliseconds for which to compute the offset
   * @return {number}
   */
  offset(e) {
    if (!this.valid)
      return NaN;
    const t = new Date(e);
    if (isNaN(t))
      return NaN;
    const n = qd(this.name);
    let [s, i, a, l, o, f, u] = n.formatToParts ? Zd(n, t) : $d(n, t);
    l === "BC" && (s = -Math.abs(s) + 1);
    const h = $r({
      year: s,
      month: i,
      day: a,
      hour: o === 24 ? 0 : o,
      minute: f,
      second: u,
      millisecond: 0
    });
    let c = +t;
    const m = c % 1e3;
    return c -= m >= 0 ? m : 1e3 + m, (h - c) / (60 * 1e3);
  }
  /**
   * Return whether this Zone is equal to another zone
   * @override
   * @param {Zone} otherZone - the zone to compare
   * @return {boolean}
   */
  equals(e) {
    return e.type === "iana" && e.name === this.name;
  }
  /**
   * Return whether this Zone is valid.
   * @override
   * @type {boolean}
   */
  get isValid() {
    return this.valid;
  }
}
let zs = {};
function Hd(r, e = {}) {
  const t = JSON.stringify([r, e]);
  let n = zs[t];
  return n || (n = new Intl.ListFormat(r, e), zs[t] = n), n;
}
const Sn = /* @__PURE__ */ new Map();
function Tn(r, e = {}) {
  const t = JSON.stringify([r, e]);
  let n = Sn.get(t);
  return n === void 0 && (n = new Intl.DateTimeFormat(r, e), Sn.set(t, n)), n;
}
const En = /* @__PURE__ */ new Map();
function Bd(r, e = {}) {
  const t = JSON.stringify([r, e]);
  let n = En.get(t);
  return n === void 0 && (n = new Intl.NumberFormat(r, e), En.set(t, n)), n;
}
const Fn = /* @__PURE__ */ new Map();
function Yd(r, e = {}) {
  const {
    base: t,
    ...n
  } = e, s = JSON.stringify([r, n]);
  let i = Fn.get(s);
  return i === void 0 && (i = new Intl.RelativeTimeFormat(r, e), Fn.set(s, i)), i;
}
let jt = null;
function Gd() {
  return jt || (jt = new Intl.DateTimeFormat().resolvedOptions().locale, jt);
}
const Dn = /* @__PURE__ */ new Map();
function lo(r) {
  let e = Dn.get(r);
  return e === void 0 && (e = new Intl.DateTimeFormat(r).resolvedOptions(), Dn.set(r, e)), e;
}
const Mn = /* @__PURE__ */ new Map();
function Jd(r) {
  let e = Mn.get(r);
  if (!e) {
    const t = new Intl.Locale(r);
    e = "getWeekInfo" in t ? t.getWeekInfo() : t.weekInfo, "minimalDays" in e || (e = {
      ...uo,
      ...e
    }), Mn.set(r, e);
  }
  return e;
}
function Kd(r) {
  const e = r.indexOf("-x-");
  e !== -1 && (r = r.substring(0, e));
  const t = r.indexOf("-u-");
  if (t === -1)
    return [r];
  {
    let n, s;
    try {
      n = Tn(r).resolvedOptions(), s = r;
    } catch {
      const o = r.substring(0, t);
      n = Tn(o).resolvedOptions(), s = o;
    }
    const {
      numberingSystem: i,
      calendar: a
    } = n;
    return [s, i, a];
  }
}
function Qd(r, e, t) {
  return (t || e) && (r.includes("-u-") || (r += "-u"), t && (r += `-ca-${t}`), e && (r += `-nu-${e}`)), r;
}
function Xd(r) {
  const e = [];
  for (let t = 1; t <= 12; t++) {
    const n = P.utc(2009, t, 1);
    e.push(r(n));
  }
  return e;
}
function eh(r) {
  const e = [];
  for (let t = 1; t <= 7; t++) {
    const n = P.utc(2016, 11, 13 + t);
    e.push(r(n));
  }
  return e;
}
function gr(r, e, t, n) {
  const s = r.listingMode();
  return s === "error" ? null : s === "en" ? t(e) : n(e);
}
function th(r) {
  return r.numberingSystem && r.numberingSystem !== "latn" ? !1 : r.numberingSystem === "latn" || !r.locale || r.locale.startsWith("en") || lo(r.locale).numberingSystem === "latn";
}
class rh {
  constructor(e, t, n) {
    this.padTo = n.padTo || 0, this.floor = n.floor || !1;
    const {
      padTo: s,
      floor: i,
      ...a
    } = n;
    if (!t || Object.keys(a).length > 0) {
      const l = {
        useGrouping: !1,
        ...n
      };
      n.padTo > 0 && (l.minimumIntegerDigits = n.padTo), this.inf = Bd(e, l);
    }
  }
  format(e) {
    if (this.inf) {
      const t = this.floor ? Math.floor(e) : e;
      return this.inf.format(t);
    } else {
      const t = this.floor ? Math.floor(e) : Xn(e, 3);
      return oe(t, this.padTo);
    }
  }
}
class nh {
  constructor(e, t, n) {
    this.opts = n, this.originalZone = void 0;
    let s;
    if (this.opts.timeZone)
      this.dt = e;
    else if (e.zone.type === "fixed") {
      const a = -1 * (e.offset / 60), l = a >= 0 ? `Etc/GMT+${a}` : `Etc/GMT${a}`;
      e.offset !== 0 && je.create(l).valid ? (s = l, this.dt = e) : (s = "UTC", this.dt = e.offset === 0 ? e : e.setZone("UTC").plus({
        minutes: e.offset
      }), this.originalZone = e.zone);
    } else
      e.zone.type === "system" ? this.dt = e : e.zone.type === "iana" ? (this.dt = e, s = e.zone.name) : (s = "UTC", this.dt = e.setZone("UTC").plus({
        minutes: e.offset
      }), this.originalZone = e.zone);
    const i = {
      ...this.opts
    };
    i.timeZone = i.timeZone || s, this.dtf = Tn(t, i);
  }
  format() {
    return this.originalZone ? this.formatToParts().map(({
      value: e
    }) => e).join("") : this.dtf.format(this.dt.toJSDate());
  }
  formatToParts() {
    const e = this.dtf.formatToParts(this.dt.toJSDate());
    return this.originalZone ? e.map((t) => {
      if (t.type === "timeZoneName") {
        const n = this.originalZone.offsetName(this.dt.ts, {
          locale: this.dt.locale,
          format: this.opts.timeZoneName
        });
        return {
          ...t,
          value: n
        };
      } else
        return t;
    }) : e;
  }
  resolvedOptions() {
    return this.dtf.resolvedOptions();
  }
}
class sh {
  constructor(e, t, n) {
    this.opts = {
      style: "long",
      ...n
    }, !t && _o() && (this.rtf = Yd(e, n));
  }
  format(e, t) {
    return this.rtf ? this.rtf.format(e, t) : Th(t, e, this.opts.numeric, this.opts.style !== "long");
  }
  formatToParts(e, t) {
    return this.rtf ? this.rtf.formatToParts(e, t) : [];
  }
}
const uo = {
  firstDay: 1,
  minimalDays: 4,
  weekend: [6, 7]
};
class Q {
  static fromOpts(e) {
    return Q.create(e.locale, e.numberingSystem, e.outputCalendar, e.weekSettings, e.defaultToEN);
  }
  static create(e, t, n, s, i = !1) {
    const a = e || ne.defaultLocale, l = a || (i ? "en-US" : Gd()), o = t || ne.defaultNumberingSystem, f = n || ne.defaultOutputCalendar, u = Cn(s) || ne.defaultWeekSettings;
    return new Q(l, o, f, u, a);
  }
  static resetCache() {
    jt = null, Sn.clear(), En.clear(), Fn.clear(), Dn.clear(), Mn.clear();
  }
  static fromObject({
    locale: e,
    numberingSystem: t,
    outputCalendar: n,
    weekSettings: s
  } = {}) {
    return Q.create(e, t, n, s);
  }
  constructor(e, t, n, s, i) {
    const [a, l, o] = Kd(e);
    this.locale = a, this.numberingSystem = t || l || null, this.outputCalendar = n || o || null, this.weekSettings = s, this.intl = Qd(this.locale, this.numberingSystem, this.outputCalendar), this.weekdaysCache = {
      format: {},
      standalone: {}
    }, this.monthsCache = {
      format: {},
      standalone: {}
    }, this.meridiemCache = null, this.eraCache = {}, this.specifiedLocale = i, this.fastNumbersCached = null;
  }
  get fastNumbers() {
    return this.fastNumbersCached == null && (this.fastNumbersCached = th(this)), this.fastNumbersCached;
  }
  listingMode() {
    const e = this.isEnglish(), t = (this.numberingSystem === null || this.numberingSystem === "latn") && (this.outputCalendar === null || this.outputCalendar === "gregory");
    return e && t ? "en" : "intl";
  }
  clone(e) {
    return !e || Object.getOwnPropertyNames(e).length === 0 ? this : Q.create(e.locale || this.specifiedLocale, e.numberingSystem || this.numberingSystem, e.outputCalendar || this.outputCalendar, Cn(e.weekSettings) || this.weekSettings, e.defaultToEN || !1);
  }
  redefaultToEN(e = {}) {
    return this.clone({
      ...e,
      defaultToEN: !0
    });
  }
  redefaultToSystem(e = {}) {
    return this.clone({
      ...e,
      defaultToEN: !1
    });
  }
  months(e, t = !1) {
    return gr(this, e, Oo, () => {
      const n = this.intl === "ja" || this.intl.startsWith("ja-");
      t &= !n;
      const s = t ? {
        month: e,
        day: "numeric"
      } : {
        month: e
      }, i = t ? "format" : "standalone";
      if (!this.monthsCache[i][e]) {
        const a = n ? (l) => this.dtFormatter(l, s).format() : (l) => this.extract(l, s, "month");
        this.monthsCache[i][e] = Xd(a);
      }
      return this.monthsCache[i][e];
    });
  }
  weekdays(e, t = !1) {
    return gr(this, e, Eo, () => {
      const n = t ? {
        weekday: e,
        year: "numeric",
        month: "long",
        day: "numeric"
      } : {
        weekday: e
      }, s = t ? "format" : "standalone";
      return this.weekdaysCache[s][e] || (this.weekdaysCache[s][e] = eh((i) => this.extract(i, n, "weekday"))), this.weekdaysCache[s][e];
    });
  }
  meridiems() {
    return gr(this, void 0, () => Fo, () => {
      if (!this.meridiemCache) {
        const e = {
          hour: "numeric",
          hourCycle: "h12"
        };
        this.meridiemCache = [P.utc(2016, 11, 13, 9), P.utc(2016, 11, 13, 19)].map((t) => this.extract(t, e, "dayperiod"));
      }
      return this.meridiemCache;
    });
  }
  eras(e) {
    return gr(this, e, Do, () => {
      const t = {
        era: e
      };
      return this.eraCache[e] || (this.eraCache[e] = [P.utc(-40, 1, 1), P.utc(2017, 1, 1)].map((n) => this.extract(n, t, "era"))), this.eraCache[e];
    });
  }
  extract(e, t, n) {
    const s = this.dtFormatter(e, t), i = s.formatToParts(), a = i.find((l) => l.type.toLowerCase() === n);
    return a ? a.value : null;
  }
  numberFormatter(e = {}) {
    return new rh(this.intl, e.forceSimple || this.fastNumbers, e);
  }
  dtFormatter(e, t = {}) {
    return new nh(e, this.intl, t);
  }
  relFormatter(e = {}) {
    return new sh(this.intl, this.isEnglish(), e);
  }
  listFormatter(e = {}) {
    return Hd(this.intl, e);
  }
  isEnglish() {
    return this.locale === "en" || this.locale.toLowerCase() === "en-us" || lo(this.intl).locale.startsWith("en-us");
  }
  getWeekSettings() {
    return this.weekSettings ? this.weekSettings : bo() ? Jd(this.locale) : uo;
  }
  getStartOfWeek() {
    return this.getWeekSettings().firstDay;
  }
  getMinDaysInFirstWeek() {
    return this.getWeekSettings().minimalDays;
  }
  getWeekendDays() {
    return this.getWeekSettings().weekend;
  }
  equals(e) {
    return this.locale === e.locale && this.numberingSystem === e.numberingSystem && this.outputCalendar === e.outputCalendar;
  }
  toString() {
    return `Locale(${this.locale}, ${this.numberingSystem}, ${this.outputCalendar})`;
  }
}
let rn = null;
class ye extends Vt {
  /**
   * Get a singleton instance of UTC
   * @return {FixedOffsetZone}
   */
  static get utcInstance() {
    return rn === null && (rn = new ye(0)), rn;
  }
  /**
   * Get an instance with a specified offset
   * @param {number} offset - The offset in minutes
   * @return {FixedOffsetZone}
   */
  static instance(e) {
    return e === 0 ? ye.utcInstance : new ye(e);
  }
  /**
   * Get an instance of FixedOffsetZone from a UTC offset string, like "UTC+6"
   * @param {string} s - The offset string to parse
   * @example FixedOffsetZone.parseSpecifier("UTC+6")
   * @example FixedOffsetZone.parseSpecifier("UTC+06")
   * @example FixedOffsetZone.parseSpecifier("UTC-6:00")
   * @return {FixedOffsetZone}
   */
  static parseSpecifier(e) {
    if (e) {
      const t = e.match(/^utc(?:([+-]\d{1,2})(?::(\d{2}))?)?$/i);
      if (t)
        return new ye(Zr(t[1], t[2]));
    }
    return null;
  }
  constructor(e) {
    super(), this.fixed = e;
  }
  /**
   * The type of zone. `fixed` for all instances of `FixedOffsetZone`.
   * @override
   * @type {string}
   */
  get type() {
    return "fixed";
  }
  /**
   * The name of this zone.
   * All fixed zones' names always start with "UTC" (plus optional offset)
   * @override
   * @type {string}
   */
  get name() {
    return this.fixed === 0 ? "UTC" : `UTC${Yt(this.fixed, "narrow")}`;
  }
  /**
   * The IANA name of this zone, i.e. `Etc/UTC` or `Etc/GMT+/-nn`
   *
   * @override
   * @type {string}
   */
  get ianaName() {
    return this.fixed === 0 ? "Etc/UTC" : `Etc/GMT${Yt(-this.fixed, "narrow")}`;
  }
  /**
   * Returns the offset's common name at the specified timestamp.
   *
   * For fixed offset zones this equals to the zone name.
   * @override
   */
  offsetName() {
    return this.name;
  }
  /**
   * Returns the offset's value as a string
   * @override
   * @param {number} ts - Epoch milliseconds for which to get the offset
   * @param {string} format - What style of offset to return.
   *                          Accepts 'narrow', 'short', or 'techie'. Returning '+6', '+06:00', or '+0600' respectively
   * @return {string}
   */
  formatOffset(e, t) {
    return Yt(this.fixed, t);
  }
  /**
   * Returns whether the offset is known to be fixed for the whole year:
   * Always returns true for all fixed offset zones.
   * @override
   * @type {boolean}
   */
  get isUniversal() {
    return !0;
  }
  /**
   * Return the offset in minutes for this zone at the specified timestamp.
   *
   * For fixed offset zones, this is constant and does not depend on a timestamp.
   * @override
   * @return {number}
   */
  offset() {
    return this.fixed;
  }
  /**
   * Return whether this Zone is equal to another zone (i.e. also fixed and same offset)
   * @override
   * @param {Zone} otherZone - the zone to compare
   * @return {boolean}
   */
  equals(e) {
    return e.type === "fixed" && e.fixed === this.fixed;
  }
  /**
   * Return whether this Zone is valid:
   * All fixed offset zones are valid.
   * @override
   * @type {boolean}
   */
  get isValid() {
    return !0;
  }
}
class fo extends Vt {
  constructor(e) {
    super(), this.zoneName = e;
  }
  /** @override **/
  get type() {
    return "invalid";
  }
  /** @override **/
  get name() {
    return this.zoneName;
  }
  /** @override **/
  get isUniversal() {
    return !1;
  }
  /** @override **/
  offsetName() {
    return null;
  }
  /** @override **/
  formatOffset() {
    return "";
  }
  /** @override **/
  offset() {
    return NaN;
  }
  /** @override **/
  equals() {
    return !1;
  }
  /** @override **/
  get isValid() {
    return !1;
  }
}
function Ke(r, e) {
  if (x(r) || r === null)
    return e;
  if (r instanceof Vt)
    return r;
  if (fh(r)) {
    const t = r.toLowerCase();
    return t === "default" ? e : t === "local" || t === "system" ? Xt.instance : t === "utc" || t === "gmt" ? ye.utcInstance : ye.parseSpecifier(t) || je.create(r);
  } else
    return Qe(r) ? ye.instance(r) : typeof r == "object" && "offset" in r && typeof r.offset == "function" ? r : new fo(r);
}
const Gn = {
  arab: "[٠-٩]",
  arabext: "[۰-۹]",
  bali: "[᭐-᭙]",
  beng: "[০-৯]",
  deva: "[०-९]",
  fullwide: "[０-９]",
  gujr: "[૦-૯]",
  hanidec: "[〇|一|二|三|四|五|六|七|八|九]",
  khmr: "[០-៩]",
  knda: "[೦-೯]",
  laoo: "[໐-໙]",
  limb: "[᥆-᥏]",
  mlym: "[൦-൯]",
  mong: "[᠐-᠙]",
  mymr: "[၀-၉]",
  orya: "[୦-୯]",
  tamldec: "[௦-௯]",
  telu: "[౦-౯]",
  thai: "[๐-๙]",
  tibt: "[༠-༩]",
  latn: "\\d"
}, qs = {
  arab: [1632, 1641],
  arabext: [1776, 1785],
  bali: [6992, 7001],
  beng: [2534, 2543],
  deva: [2406, 2415],
  fullwide: [65296, 65303],
  gujr: [2790, 2799],
  khmr: [6112, 6121],
  knda: [3302, 3311],
  laoo: [3792, 3801],
  limb: [6470, 6479],
  mlym: [3430, 3439],
  mong: [6160, 6169],
  mymr: [4160, 4169],
  orya: [2918, 2927],
  tamldec: [3046, 3055],
  telu: [3174, 3183],
  thai: [3664, 3673],
  tibt: [3872, 3881]
}, ih = Gn.hanidec.replace(/[\[|\]]/g, "").split("");
function ah(r) {
  let e = parseInt(r, 10);
  if (isNaN(e)) {
    e = "";
    for (let t = 0; t < r.length; t++) {
      const n = r.charCodeAt(t);
      if (r[t].search(Gn.hanidec) !== -1)
        e += ih.indexOf(r[t]);
      else
        for (const s in qs) {
          const [i, a] = qs[s];
          n >= i && n <= a && (e += n - i);
        }
    }
    return parseInt(e, 10);
  } else
    return e;
}
const Nn = /* @__PURE__ */ new Map();
function oh() {
  Nn.clear();
}
function Ie({
  numberingSystem: r
}, e = "") {
  const t = r || "latn";
  let n = Nn.get(t);
  n === void 0 && (n = /* @__PURE__ */ new Map(), Nn.set(t, n));
  let s = n.get(e);
  return s === void 0 && (s = new RegExp(`${Gn[t]}${e}`), n.set(e, s)), s;
}
let js = () => Date.now(), $s = "system", Zs = null, Hs = null, Bs = null, Ys = 60, Gs, Js = null;
class ne {
  /**
   * Get the callback for returning the current timestamp.
   * @type {function}
   */
  static get now() {
    return js;
  }
  /**
   * Set the callback for returning the current timestamp.
   * The function should return a number, which will be interpreted as an Epoch millisecond count
   * @type {function}
   * @example Settings.now = () => Date.now() + 3000 // pretend it is 3 seconds in the future
   * @example Settings.now = () => 0 // always pretend it's Jan 1, 1970 at midnight in UTC time
   */
  static set now(e) {
    js = e;
  }
  /**
   * Set the default time zone to create DateTimes in. Does not affect existing instances.
   * Use the value "system" to reset this value to the system's time zone.
   * @type {string}
   */
  static set defaultZone(e) {
    $s = e;
  }
  /**
   * Get the default time zone object currently used to create DateTimes. Does not affect existing instances.
   * The default value is the system's time zone (the one set on the machine that runs this code).
   * @type {Zone}
   */
  static get defaultZone() {
    return Ke($s, Xt.instance);
  }
  /**
   * Get the default locale to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static get defaultLocale() {
    return Zs;
  }
  /**
   * Set the default locale to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static set defaultLocale(e) {
    Zs = e;
  }
  /**
   * Get the default numbering system to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static get defaultNumberingSystem() {
    return Hs;
  }
  /**
   * Set the default numbering system to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static set defaultNumberingSystem(e) {
    Hs = e;
  }
  /**
   * Get the default output calendar to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static get defaultOutputCalendar() {
    return Bs;
  }
  /**
   * Set the default output calendar to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static set defaultOutputCalendar(e) {
    Bs = e;
  }
  /**
   * @typedef {Object} WeekSettings
   * @property {number} firstDay
   * @property {number} minimalDays
   * @property {number[]} weekend
   */
  /**
   * @return {WeekSettings|null}
   */
  static get defaultWeekSettings() {
    return Js;
  }
  /**
   * Allows overriding the default locale week settings, i.e. the start of the week, the weekend and
   * how many days are required in the first week of a year.
   * Does not affect existing instances.
   *
   * @param {WeekSettings|null} weekSettings
   */
  static set defaultWeekSettings(e) {
    Js = Cn(e);
  }
  /**
   * Get the cutoff year for whether a 2-digit year string is interpreted in the current or previous century. Numbers higher than the cutoff will be considered to mean 19xx and numbers lower or equal to the cutoff will be considered 20xx.
   * @type {number}
   */
  static get twoDigitCutoffYear() {
    return Ys;
  }
  /**
   * Set the cutoff year for whether a 2-digit year string is interpreted in the current or previous century. Numbers higher than the cutoff will be considered to mean 19xx and numbers lower or equal to the cutoff will be considered 20xx.
   * @type {number}
   * @example Settings.twoDigitCutoffYear = 0 // all 'yy' are interpreted as 20th century
   * @example Settings.twoDigitCutoffYear = 99 // all 'yy' are interpreted as 21st century
   * @example Settings.twoDigitCutoffYear = 50 // '49' -> 2049; '50' -> 1950
   * @example Settings.twoDigitCutoffYear = 1950 // interpreted as 50
   * @example Settings.twoDigitCutoffYear = 2050 // ALSO interpreted as 50
   */
  static set twoDigitCutoffYear(e) {
    Ys = e % 100;
  }
  /**
   * Get whether Luxon will throw when it encounters invalid DateTimes, Durations, or Intervals
   * @type {boolean}
   */
  static get throwOnInvalid() {
    return Gs;
  }
  /**
   * Set whether Luxon will throw when it encounters invalid DateTimes, Durations, or Intervals
   * @type {boolean}
   */
  static set throwOnInvalid(e) {
    Gs = e;
  }
  /**
   * Reset Luxon's global caches. Should only be necessary in testing scenarios.
   * @return {void}
   */
  static resetCaches() {
    Q.resetCache(), je.resetCache(), P.resetCache(), oh();
  }
}
class Ue {
  constructor(e, t) {
    this.reason = e, this.explanation = t;
  }
  toMessage() {
    return this.explanation ? `${this.reason}: ${this.explanation}` : this.reason;
  }
}
const co = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334], ho = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335];
function Ce(r, e) {
  return new Ue("unit out of range", `you specified ${e} (of type ${typeof e}) as a ${r}, which is invalid`);
}
function Jn(r, e, t) {
  const n = new Date(Date.UTC(r, e - 1, t));
  r < 100 && r >= 0 && n.setUTCFullYear(n.getUTCFullYear() - 1900);
  const s = n.getUTCDay();
  return s === 0 ? 7 : s;
}
function mo(r, e, t) {
  return t + (er(r) ? ho : co)[e - 1];
}
function po(r, e) {
  const t = er(r) ? ho : co, n = t.findIndex((i) => i < e), s = e - t[n];
  return {
    month: n + 1,
    day: s
  };
}
function Kn(r, e) {
  return (r - e + 7) % 7 + 1;
}
function Ar(r, e = 4, t = 1) {
  const {
    year: n,
    month: s,
    day: i
  } = r, a = mo(n, s, i), l = Kn(Jn(n, s, i), t);
  let o = Math.floor((a - l + 14 - e) / 7), f;
  return o < 1 ? (f = n - 1, o = Jt(f, e, t)) : o > Jt(n, e, t) ? (f = n + 1, o = 1) : f = n, {
    weekYear: f,
    weekNumber: o,
    weekday: l,
    ...Hr(r)
  };
}
function Ks(r, e = 4, t = 1) {
  const {
    weekYear: n,
    weekNumber: s,
    weekday: i
  } = r, a = Kn(Jn(n, 1, e), t), l = kt(n);
  let o = s * 7 + i - a - 7 + e, f;
  o < 1 ? (f = n - 1, o += kt(f)) : o > l ? (f = n + 1, o -= kt(n)) : f = n;
  const {
    month: u,
    day: d
  } = po(f, o);
  return {
    year: f,
    month: u,
    day: d,
    ...Hr(r)
  };
}
function nn(r) {
  const {
    year: e,
    month: t,
    day: n
  } = r, s = mo(e, t, n);
  return {
    year: e,
    ordinal: s,
    ...Hr(r)
  };
}
function Qs(r) {
  const {
    year: e,
    ordinal: t
  } = r, {
    month: n,
    day: s
  } = po(e, t);
  return {
    year: e,
    month: n,
    day: s,
    ...Hr(r)
  };
}
function Xs(r, e) {
  if (!x(r.localWeekday) || !x(r.localWeekNumber) || !x(r.localWeekYear)) {
    if (!x(r.weekday) || !x(r.weekNumber) || !x(r.weekYear))
      throw new wt("Cannot mix locale-based week fields with ISO-based week fields");
    return x(r.localWeekday) || (r.weekday = r.localWeekday), x(r.localWeekNumber) || (r.weekNumber = r.localWeekNumber), x(r.localWeekYear) || (r.weekYear = r.localWeekYear), delete r.localWeekday, delete r.localWeekNumber, delete r.localWeekYear, {
      minDaysInFirstWeek: e.getMinDaysInFirstWeek(),
      startOfWeek: e.getStartOfWeek()
    };
  } else
    return {
      minDaysInFirstWeek: 4,
      startOfWeek: 1
    };
}
function lh(r, e = 4, t = 1) {
  const n = jr(r.weekYear), s = Le(r.weekNumber, 1, Jt(r.weekYear, e, t)), i = Le(r.weekday, 1, 7);
  return n ? s ? i ? !1 : Ce("weekday", r.weekday) : Ce("week", r.weekNumber) : Ce("weekYear", r.weekYear);
}
function uh(r) {
  const e = jr(r.year), t = Le(r.ordinal, 1, kt(r.year));
  return e ? t ? !1 : Ce("ordinal", r.ordinal) : Ce("year", r.year);
}
function go(r) {
  const e = jr(r.year), t = Le(r.month, 1, 12), n = Le(r.day, 1, Wr(r.year, r.month));
  return e ? t ? n ? !1 : Ce("day", r.day) : Ce("month", r.month) : Ce("year", r.year);
}
function yo(r) {
  const {
    hour: e,
    minute: t,
    second: n,
    millisecond: s
  } = r, i = Le(e, 0, 23) || e === 24 && t === 0 && n === 0 && s === 0, a = Le(t, 0, 59), l = Le(n, 0, 59), o = Le(s, 0, 999);
  return i ? a ? l ? o ? !1 : Ce("millisecond", s) : Ce("second", n) : Ce("minute", t) : Ce("hour", e);
}
function x(r) {
  return typeof r > "u";
}
function Qe(r) {
  return typeof r == "number";
}
function jr(r) {
  return typeof r == "number" && r % 1 === 0;
}
function fh(r) {
  return typeof r == "string";
}
function ch(r) {
  return Object.prototype.toString.call(r) === "[object Date]";
}
function _o() {
  try {
    return typeof Intl < "u" && !!Intl.RelativeTimeFormat;
  } catch {
    return !1;
  }
}
function bo() {
  try {
    return typeof Intl < "u" && !!Intl.Locale && ("weekInfo" in Intl.Locale.prototype || "getWeekInfo" in Intl.Locale.prototype);
  } catch {
    return !1;
  }
}
function dh(r) {
  return Array.isArray(r) ? r : [r];
}
function ei(r, e, t) {
  if (r.length !== 0)
    return r.reduce((n, s) => {
      const i = [e(s), s];
      return n && t(n[0], i[0]) === n[0] ? n : i;
    }, null)[1];
}
function hh(r, e) {
  return e.reduce((t, n) => (t[n] = r[n], t), {});
}
function Et(r, e) {
  return Object.prototype.hasOwnProperty.call(r, e);
}
function Cn(r) {
  if (r == null)
    return null;
  if (typeof r != "object")
    throw new me("Week settings must be an object");
  if (!Le(r.firstDay, 1, 7) || !Le(r.minimalDays, 1, 7) || !Array.isArray(r.weekend) || r.weekend.some((e) => !Le(e, 1, 7)))
    throw new me("Invalid week settings");
  return {
    firstDay: r.firstDay,
    minimalDays: r.minimalDays,
    weekend: Array.from(r.weekend)
  };
}
function Le(r, e, t) {
  return jr(r) && r >= e && r <= t;
}
function mh(r, e) {
  return r - e * Math.floor(r / e);
}
function oe(r, e = 2) {
  const t = r < 0;
  let n;
  return t ? n = "-" + ("" + -r).padStart(e, "0") : n = ("" + r).padStart(e, "0"), n;
}
function Je(r) {
  if (!(x(r) || r === null || r === ""))
    return parseInt(r, 10);
}
function st(r) {
  if (!(x(r) || r === null || r === ""))
    return parseFloat(r);
}
function Qn(r) {
  if (!(x(r) || r === null || r === "")) {
    const e = parseFloat("0." + r) * 1e3;
    return Math.floor(e);
  }
}
function Xn(r, e, t = "round") {
  const n = 10 ** e;
  switch (t) {
    case "expand":
      return r > 0 ? Math.ceil(r * n) / n : Math.floor(r * n) / n;
    case "trunc":
      return Math.trunc(r * n) / n;
    case "round":
      return Math.round(r * n) / n;
    case "floor":
      return Math.floor(r * n) / n;
    case "ceil":
      return Math.ceil(r * n) / n;
    default:
      throw new RangeError(`Value rounding ${t} is out of range`);
  }
}
function er(r) {
  return r % 4 === 0 && (r % 100 !== 0 || r % 400 === 0);
}
function kt(r) {
  return er(r) ? 366 : 365;
}
function Wr(r, e) {
  const t = mh(e - 1, 12) + 1, n = r + (e - t) / 12;
  return t === 2 ? er(n) ? 29 : 28 : [31, null, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][t - 1];
}
function $r(r) {
  let e = Date.UTC(r.year, r.month - 1, r.day, r.hour, r.minute, r.second, r.millisecond);
  return r.year < 100 && r.year >= 0 && (e = new Date(e), e.setUTCFullYear(r.year, r.month - 1, r.day)), +e;
}
function ti(r, e, t) {
  return -Kn(Jn(r, 1, e), t) + e - 1;
}
function Jt(r, e = 4, t = 1) {
  const n = ti(r, e, t), s = ti(r + 1, e, t);
  return (kt(r) - n + s) / 7;
}
function Ln(r) {
  return r > 99 ? r : r > ne.twoDigitCutoffYear ? 1900 + r : 2e3 + r;
}
function vo(r, e, t, n = null) {
  const s = new Date(r), i = {
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  };
  n && (i.timeZone = n);
  const a = {
    timeZoneName: e,
    ...i
  }, l = new Intl.DateTimeFormat(t, a).formatToParts(s).find((o) => o.type.toLowerCase() === "timezonename");
  return l ? l.value : null;
}
function Zr(r, e) {
  let t = parseInt(r, 10);
  Number.isNaN(t) && (t = 0);
  const n = parseInt(e, 10) || 0, s = t < 0 || Object.is(t, -0) ? -n : n;
  return t * 60 + s;
}
function wo(r) {
  const e = Number(r);
  if (typeof r == "boolean" || r === "" || !Number.isFinite(e))
    throw new me(`Invalid unit value ${r}`);
  return e;
}
function Ur(r, e) {
  const t = {};
  for (const n in r)
    if (Et(r, n)) {
      const s = r[n];
      if (s == null)
        continue;
      t[e(n)] = wo(s);
    }
  return t;
}
function Yt(r, e) {
  const t = Math.trunc(Math.abs(r / 60)), n = Math.trunc(Math.abs(r % 60)), s = r >= 0 ? "+" : "-";
  switch (e) {
    case "short":
      return `${s}${oe(t, 2)}:${oe(n, 2)}`;
    case "narrow":
      return `${s}${t}${n > 0 ? `:${n}` : ""}`;
    case "techie":
      return `${s}${oe(t, 2)}${oe(n, 2)}`;
    default:
      throw new RangeError(`Value format ${e} is out of range for property format`);
  }
}
function Hr(r) {
  return hh(r, ["hour", "minute", "second", "millisecond"]);
}
const ph = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], ko = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], gh = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];
function Oo(r) {
  switch (r) {
    case "narrow":
      return [...gh];
    case "short":
      return [...ko];
    case "long":
      return [...ph];
    case "numeric":
      return ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"];
    case "2-digit":
      return ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
    default:
      return null;
  }
}
const So = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"], To = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], yh = ["M", "T", "W", "T", "F", "S", "S"];
function Eo(r) {
  switch (r) {
    case "narrow":
      return [...yh];
    case "short":
      return [...To];
    case "long":
      return [...So];
    case "numeric":
      return ["1", "2", "3", "4", "5", "6", "7"];
    default:
      return null;
  }
}
const Fo = ["AM", "PM"], _h = ["Before Christ", "Anno Domini"], bh = ["BC", "AD"], vh = ["B", "A"];
function Do(r) {
  switch (r) {
    case "narrow":
      return [...vh];
    case "short":
      return [...bh];
    case "long":
      return [..._h];
    default:
      return null;
  }
}
function wh(r) {
  return Fo[r.hour < 12 ? 0 : 1];
}
function kh(r, e) {
  return Eo(e)[r.weekday - 1];
}
function Oh(r, e) {
  return Oo(e)[r.month - 1];
}
function Sh(r, e) {
  return Do(e)[r.year < 0 ? 0 : 1];
}
function Th(r, e, t = "always", n = !1) {
  const s = {
    years: ["year", "yr."],
    quarters: ["quarter", "qtr."],
    months: ["month", "mo."],
    weeks: ["week", "wk."],
    days: ["day", "day", "days"],
    hours: ["hour", "hr."],
    minutes: ["minute", "min."],
    seconds: ["second", "sec."]
  }, i = ["hours", "minutes", "seconds"].indexOf(r) === -1;
  if (t === "auto" && i) {
    const d = r === "days";
    switch (e) {
      case 1:
        return d ? "tomorrow" : `next ${s[r][0]}`;
      case -1:
        return d ? "yesterday" : `last ${s[r][0]}`;
      case 0:
        return d ? "today" : `this ${s[r][0]}`;
    }
  }
  const a = Object.is(e, -0) || e < 0, l = Math.abs(e), o = l === 1, f = s[r], u = n ? o ? f[1] : f[2] || f[1] : o ? s[r][0] : r;
  return a ? `${l} ${u} ago` : `in ${l} ${u}`;
}
function ri(r, e) {
  let t = "";
  for (const n of r)
    n.literal ? t += n.val : t += e(n.val);
  return t;
}
const Eh = {
  D: Ir,
  DD: ja,
  DDD: $a,
  DDDD: Za,
  t: Ha,
  tt: Ba,
  ttt: Ya,
  tttt: Ga,
  T: Ja,
  TT: Ka,
  TTT: Qa,
  TTTT: Xa,
  f: eo,
  ff: ro,
  fff: so,
  ffff: ao,
  F: to,
  FF: no,
  FFF: io,
  FFFF: oo
};
class ge {
  static create(e, t = {}) {
    return new ge(e, t);
  }
  static parseFormat(e) {
    let t = null, n = "", s = !1;
    const i = [];
    for (let a = 0; a < e.length; a++) {
      const l = e.charAt(a);
      l === "'" ? ((n.length > 0 || s) && i.push({
        literal: s || /^\s+$/.test(n),
        val: n === "" ? "'" : n
      }), t = null, n = "", s = !s) : s || l === t ? n += l : (n.length > 0 && i.push({
        literal: /^\s+$/.test(n),
        val: n
      }), n = l, t = l);
    }
    return n.length > 0 && i.push({
      literal: s || /^\s+$/.test(n),
      val: n
    }), i;
  }
  static macroTokenToFormatOpts(e) {
    return Eh[e];
  }
  constructor(e, t) {
    this.opts = t, this.loc = e, this.systemLoc = null;
  }
  formatWithSystemDefault(e, t) {
    return this.systemLoc === null && (this.systemLoc = this.loc.redefaultToSystem()), this.systemLoc.dtFormatter(e, {
      ...this.opts,
      ...t
    }).format();
  }
  dtFormatter(e, t = {}) {
    return this.loc.dtFormatter(e, {
      ...this.opts,
      ...t
    });
  }
  formatDateTime(e, t) {
    return this.dtFormatter(e, t).format();
  }
  formatDateTimeParts(e, t) {
    return this.dtFormatter(e, t).formatToParts();
  }
  formatInterval(e, t) {
    return this.dtFormatter(e.start, t).dtf.formatRange(e.start.toJSDate(), e.end.toJSDate());
  }
  resolvedOptions(e, t) {
    return this.dtFormatter(e, t).resolvedOptions();
  }
  num(e, t = 0, n = void 0) {
    if (this.opts.forceSimple)
      return oe(e, t);
    const s = {
      ...this.opts
    };
    return t > 0 && (s.padTo = t), n && (s.signDisplay = n), this.loc.numberFormatter(s).format(e);
  }
  formatDateTimeFromString(e, t) {
    const n = this.loc.listingMode() === "en", s = this.loc.outputCalendar && this.loc.outputCalendar !== "gregory", i = (c, m) => this.loc.extract(e, c, m), a = (c) => e.isOffsetFixed && e.offset === 0 && c.allowZ ? "Z" : e.isValid ? e.zone.formatOffset(e.ts, c.format) : "", l = () => n ? wh(e) : i({
      hour: "numeric",
      hourCycle: "h12"
    }, "dayperiod"), o = (c, m) => n ? Oh(e, c) : i(m ? {
      month: c
    } : {
      month: c,
      day: "numeric"
    }, "month"), f = (c, m) => n ? kh(e, c) : i(m ? {
      weekday: c
    } : {
      weekday: c,
      month: "long",
      day: "numeric"
    }, "weekday"), u = (c) => {
      const m = ge.macroTokenToFormatOpts(c);
      return m ? this.formatWithSystemDefault(e, m) : c;
    }, d = (c) => n ? Sh(e, c) : i({
      era: c
    }, "era"), h = (c) => {
      switch (c) {
        case "S":
          return this.num(e.millisecond);
        case "u":
        case "SSS":
          return this.num(e.millisecond, 3);
        case "s":
          return this.num(e.second);
        case "ss":
          return this.num(e.second, 2);
        case "uu":
          return this.num(Math.floor(e.millisecond / 10), 2);
        case "uuu":
          return this.num(Math.floor(e.millisecond / 100));
        case "m":
          return this.num(e.minute);
        case "mm":
          return this.num(e.minute, 2);
        case "h":
          return this.num(e.hour % 12 === 0 ? 12 : e.hour % 12);
        case "hh":
          return this.num(e.hour % 12 === 0 ? 12 : e.hour % 12, 2);
        case "H":
          return this.num(e.hour);
        case "HH":
          return this.num(e.hour, 2);
        case "Z":
          return a({
            format: "narrow",
            allowZ: this.opts.allowZ
          });
        case "ZZ":
          return a({
            format: "short",
            allowZ: this.opts.allowZ
          });
        case "ZZZ":
          return a({
            format: "techie",
            allowZ: this.opts.allowZ
          });
        case "ZZZZ":
          return e.zone.offsetName(e.ts, {
            format: "short",
            locale: this.loc.locale
          });
        case "ZZZZZ":
          return e.zone.offsetName(e.ts, {
            format: "long",
            locale: this.loc.locale
          });
        case "z":
          return e.zoneName;
        case "a":
          return l();
        case "d":
          return s ? i({
            day: "numeric"
          }, "day") : this.num(e.day);
        case "dd":
          return s ? i({
            day: "2-digit"
          }, "day") : this.num(e.day, 2);
        case "c":
          return this.num(e.weekday);
        case "ccc":
          return f("short", !0);
        case "cccc":
          return f("long", !0);
        case "ccccc":
          return f("narrow", !0);
        case "E":
          return this.num(e.weekday);
        case "EEE":
          return f("short", !1);
        case "EEEE":
          return f("long", !1);
        case "EEEEE":
          return f("narrow", !1);
        case "L":
          return s ? i({
            month: "numeric",
            day: "numeric"
          }, "month") : this.num(e.month);
        case "LL":
          return s ? i({
            month: "2-digit",
            day: "numeric"
          }, "month") : this.num(e.month, 2);
        case "LLL":
          return o("short", !0);
        case "LLLL":
          return o("long", !0);
        case "LLLLL":
          return o("narrow", !0);
        case "M":
          return s ? i({
            month: "numeric"
          }, "month") : this.num(e.month);
        case "MM":
          return s ? i({
            month: "2-digit"
          }, "month") : this.num(e.month, 2);
        case "MMM":
          return o("short", !1);
        case "MMMM":
          return o("long", !1);
        case "MMMMM":
          return o("narrow", !1);
        case "y":
          return s ? i({
            year: "numeric"
          }, "year") : this.num(e.year);
        case "yy":
          return s ? i({
            year: "2-digit"
          }, "year") : this.num(e.year.toString().slice(-2), 2);
        case "yyyy":
          return s ? i({
            year: "numeric"
          }, "year") : this.num(e.year, 4);
        case "yyyyyy":
          return s ? i({
            year: "numeric"
          }, "year") : this.num(e.year, 6);
        case "G":
          return d("short");
        case "GG":
          return d("long");
        case "GGGGG":
          return d("narrow");
        case "kk":
          return this.num(e.weekYear.toString().slice(-2), 2);
        case "kkkk":
          return this.num(e.weekYear, 4);
        case "W":
          return this.num(e.weekNumber);
        case "WW":
          return this.num(e.weekNumber, 2);
        case "n":
          return this.num(e.localWeekNumber);
        case "nn":
          return this.num(e.localWeekNumber, 2);
        case "ii":
          return this.num(e.localWeekYear.toString().slice(-2), 2);
        case "iiii":
          return this.num(e.localWeekYear, 4);
        case "o":
          return this.num(e.ordinal);
        case "ooo":
          return this.num(e.ordinal, 3);
        case "q":
          return this.num(e.quarter);
        case "qq":
          return this.num(e.quarter, 2);
        case "X":
          return this.num(Math.floor(e.ts / 1e3));
        case "x":
          return this.num(e.ts);
        default:
          return u(c);
      }
    };
    return ri(ge.parseFormat(t), h);
  }
  formatDurationFromString(e, t) {
    const n = this.opts.signMode === "negativeLargestOnly" ? -1 : 1, s = (u) => {
      switch (u[0]) {
        case "S":
          return "milliseconds";
        case "s":
          return "seconds";
        case "m":
          return "minutes";
        case "h":
          return "hours";
        case "d":
          return "days";
        case "w":
          return "weeks";
        case "M":
          return "months";
        case "y":
          return "years";
        default:
          return null;
      }
    }, i = (u, d) => (h) => {
      const c = s(h);
      if (c) {
        const m = d.isNegativeDuration && c !== d.largestUnit ? n : 1;
        let g;
        return this.opts.signMode === "negativeLargestOnly" && c !== d.largestUnit ? g = "never" : this.opts.signMode === "all" ? g = "always" : g = "auto", this.num(u.get(c) * m, h.length, g);
      } else
        return h;
    }, a = ge.parseFormat(t), l = a.reduce((u, {
      literal: d,
      val: h
    }) => d ? u : u.concat(h), []), o = e.shiftTo(...l.map(s).filter((u) => u)), f = {
      isNegativeDuration: o < 0,
      // this relies on "collapsed" being based on "shiftTo", which builds up the object
      // in order
      largestUnit: Object.keys(o.values)[0]
    };
    return ri(a, i(o, f));
  }
}
const Mo = /[A-Za-z_+-]{1,256}(?::?\/[A-Za-z0-9_+-]{1,256}(?:\/[A-Za-z0-9_+-]{1,256})?)?/;
function It(...r) {
  const e = r.reduce((t, n) => t + n.source, "");
  return RegExp(`^${e}$`);
}
function At(...r) {
  return (e) => r.reduce(([t, n, s], i) => {
    const [a, l, o] = i(e, s);
    return [{
      ...t,
      ...a
    }, l || n, o];
  }, [{}, null, 1]).slice(0, 2);
}
function Wt(r, ...e) {
  if (r == null)
    return [null, null];
  for (const [t, n] of e) {
    const s = t.exec(r);
    if (s)
      return n(s);
  }
  return [null, null];
}
function No(...r) {
  return (e, t) => {
    const n = {};
    let s;
    for (s = 0; s < r.length; s++)
      n[r[s]] = Je(e[t + s]);
    return [n, null, t + s];
  };
}
const Co = /(?:([Zz])|([+-]\d\d)(?::?(\d\d))?)/, Fh = `(?:${Co.source}?(?:\\[(${Mo.source})\\])?)?`, es = /(\d\d)(?::?(\d\d)(?::?(\d\d)(?:[.,](\d{1,30}))?)?)?/, Lo = RegExp(`${es.source}${Fh}`), ts = RegExp(`(?:[Tt]${Lo.source})?`), Dh = /([+-]\d{6}|\d{4})(?:-?(\d\d)(?:-?(\d\d))?)?/, Mh = /(\d{4})-?W(\d\d)(?:-?(\d))?/, Nh = /(\d{4})-?(\d{3})/, Ch = No("weekYear", "weekNumber", "weekDay"), Lh = No("year", "ordinal"), Vh = /(\d{4})-(\d\d)-(\d\d)/, Vo = RegExp(`${es.source} ?(?:${Co.source}|(${Mo.source}))?`), Ih = RegExp(`(?: ${Vo.source})?`);
function Ot(r, e, t) {
  const n = r[e];
  return x(n) ? t : Je(n);
}
function Ah(r, e) {
  return [{
    year: Ot(r, e),
    month: Ot(r, e + 1, 1),
    day: Ot(r, e + 2, 1)
  }, null, e + 3];
}
function Ut(r, e) {
  return [{
    hours: Ot(r, e, 0),
    minutes: Ot(r, e + 1, 0),
    seconds: Ot(r, e + 2, 0),
    milliseconds: Qn(r[e + 3])
  }, null, e + 4];
}
function tr(r, e) {
  const t = !r[e] && !r[e + 1], n = Zr(r[e + 1], r[e + 2]), s = t ? null : ye.instance(n);
  return [{}, s, e + 3];
}
function rr(r, e) {
  const t = r[e] ? je.create(r[e]) : null;
  return [{}, t, e + 1];
}
const Wh = RegExp(`^T?${es.source}$`), Uh = /^-?P(?:(?:(-?\d{1,20}(?:\.\d{1,20})?)Y)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20}(?:\.\d{1,20})?)W)?(?:(-?\d{1,20}(?:\.\d{1,20})?)D)?(?:T(?:(-?\d{1,20}(?:\.\d{1,20})?)H)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20})(?:[.,](-?\d{1,20}))?S)?)?)$/;
function xh(r) {
  const [e, t, n, s, i, a, l, o, f] = r, u = e[0] === "-", d = o && o[0] === "-", h = (c, m = !1) => c !== void 0 && (m || c && u) ? -c : c;
  return [{
    years: h(st(t)),
    months: h(st(n)),
    weeks: h(st(s)),
    days: h(st(i)),
    hours: h(st(a)),
    minutes: h(st(l)),
    seconds: h(st(o), o === "-0"),
    milliseconds: h(Qn(f), d)
  }];
}
const Ph = {
  GMT: 0,
  EDT: -4 * 60,
  EST: -5 * 60,
  CDT: -5 * 60,
  CST: -6 * 60,
  MDT: -6 * 60,
  MST: -7 * 60,
  PDT: -7 * 60,
  PST: -8 * 60
};
function rs(r, e, t, n, s, i, a) {
  const l = {
    year: e.length === 2 ? Ln(Je(e)) : Je(e),
    month: ko.indexOf(t) + 1,
    day: Je(n),
    hour: Je(s),
    minute: Je(i)
  };
  return a && (l.second = Je(a)), r && (l.weekday = r.length > 3 ? So.indexOf(r) + 1 : To.indexOf(r) + 1), l;
}
const Rh = /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|(?:([+-]\d\d)(\d\d)))$/;
function zh(r) {
  const [, e, t, n, s, i, a, l, o, f, u, d] = r, h = rs(e, s, n, t, i, a, l);
  let c;
  return o ? c = Ph[o] : f ? c = 0 : c = Zr(u, d), [h, new ye(c)];
}
function qh(r) {
  return r.replace(/\([^()]*\)|[\n\t]/g, " ").replace(/(\s\s+)/g, " ").trim();
}
const jh = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), (\d\d) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4}) (\d\d):(\d\d):(\d\d) GMT$/, $h = /^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), (\d\d)-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-(\d\d) (\d\d):(\d\d):(\d\d) GMT$/, Zh = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ( \d|\d\d) (\d\d):(\d\d):(\d\d) (\d{4})$/;
function ni(r) {
  const [, e, t, n, s, i, a, l] = r;
  return [rs(e, s, n, t, i, a, l), ye.utcInstance];
}
function Hh(r) {
  const [, e, t, n, s, i, a, l] = r;
  return [rs(e, l, t, n, s, i, a), ye.utcInstance];
}
const Bh = It(Dh, ts), Yh = It(Mh, ts), Gh = It(Nh, ts), Jh = It(Lo), Io = At(Ah, Ut, tr, rr), Kh = At(Ch, Ut, tr, rr), Qh = At(Lh, Ut, tr, rr), Xh = At(Ut, tr, rr);
function em(r) {
  return Wt(r, [Bh, Io], [Yh, Kh], [Gh, Qh], [Jh, Xh]);
}
function tm(r) {
  return Wt(qh(r), [Rh, zh]);
}
function rm(r) {
  return Wt(r, [jh, ni], [$h, ni], [Zh, Hh]);
}
function nm(r) {
  return Wt(r, [Uh, xh]);
}
const sm = At(Ut);
function im(r) {
  return Wt(r, [Wh, sm]);
}
const am = It(Vh, Ih), om = It(Vo), lm = At(Ut, tr, rr);
function um(r) {
  return Wt(r, [am, Io], [om, lm]);
}
const si = "Invalid Duration", Ao = {
  weeks: {
    days: 7,
    hours: 7 * 24,
    minutes: 7 * 24 * 60,
    seconds: 7 * 24 * 60 * 60,
    milliseconds: 7 * 24 * 60 * 60 * 1e3
  },
  days: {
    hours: 24,
    minutes: 24 * 60,
    seconds: 24 * 60 * 60,
    milliseconds: 24 * 60 * 60 * 1e3
  },
  hours: {
    minutes: 60,
    seconds: 60 * 60,
    milliseconds: 60 * 60 * 1e3
  },
  minutes: {
    seconds: 60,
    milliseconds: 60 * 1e3
  },
  seconds: {
    milliseconds: 1e3
  }
}, fm = {
  years: {
    quarters: 4,
    months: 12,
    weeks: 52,
    days: 365,
    hours: 365 * 24,
    minutes: 365 * 24 * 60,
    seconds: 365 * 24 * 60 * 60,
    milliseconds: 365 * 24 * 60 * 60 * 1e3
  },
  quarters: {
    months: 3,
    weeks: 13,
    days: 91,
    hours: 91 * 24,
    minutes: 91 * 24 * 60,
    seconds: 91 * 24 * 60 * 60,
    milliseconds: 91 * 24 * 60 * 60 * 1e3
  },
  months: {
    weeks: 4,
    days: 30,
    hours: 30 * 24,
    minutes: 30 * 24 * 60,
    seconds: 30 * 24 * 60 * 60,
    milliseconds: 30 * 24 * 60 * 60 * 1e3
  },
  ...Ao
}, Me = 146097 / 400, gt = 146097 / 4800, cm = {
  years: {
    quarters: 4,
    months: 12,
    weeks: Me / 7,
    days: Me,
    hours: Me * 24,
    minutes: Me * 24 * 60,
    seconds: Me * 24 * 60 * 60,
    milliseconds: Me * 24 * 60 * 60 * 1e3
  },
  quarters: {
    months: 3,
    weeks: Me / 28,
    days: Me / 4,
    hours: Me * 24 / 4,
    minutes: Me * 24 * 60 / 4,
    seconds: Me * 24 * 60 * 60 / 4,
    milliseconds: Me * 24 * 60 * 60 * 1e3 / 4
  },
  months: {
    weeks: gt / 7,
    days: gt,
    hours: gt * 24,
    minutes: gt * 24 * 60,
    seconds: gt * 24 * 60 * 60,
    milliseconds: gt * 24 * 60 * 60 * 1e3
  },
  ...Ao
}, ut = ["years", "quarters", "months", "weeks", "days", "hours", "minutes", "seconds", "milliseconds"], dm = ut.slice(0).reverse();
function Ze(r, e, t = !1) {
  const n = {
    values: t ? e.values : {
      ...r.values,
      ...e.values || {}
    },
    loc: r.loc.clone(e.loc),
    conversionAccuracy: e.conversionAccuracy || r.conversionAccuracy,
    matrix: e.matrix || r.matrix
  };
  return new J(n);
}
function Wo(r, e) {
  var t;
  let n = (t = e.milliseconds) != null ? t : 0;
  for (const s of dm.slice(1))
    e[s] && (n += e[s] * r[s].milliseconds);
  return n;
}
function ii(r, e) {
  const t = Wo(r, e) < 0 ? -1 : 1;
  ut.reduceRight((n, s) => {
    if (x(e[s]))
      return n;
    if (n) {
      const i = e[n] * t, a = r[s][n], l = Math.floor(i / a);
      e[s] += l * t, e[n] -= l * a * t;
    }
    return s;
  }, null), ut.reduce((n, s) => {
    if (x(e[s]))
      return n;
    if (n) {
      const i = e[n] % 1;
      e[n] -= i, e[s] += i * r[n][s];
    }
    return s;
  }, null);
}
function ai(r) {
  const e = {};
  for (const [t, n] of Object.entries(r))
    n !== 0 && (e[t] = n);
  return e;
}
class J {
  /**
   * @private
   */
  constructor(e) {
    const t = e.conversionAccuracy === "longterm" || !1;
    let n = t ? cm : fm;
    e.matrix && (n = e.matrix), this.values = e.values, this.loc = e.loc || Q.create(), this.conversionAccuracy = t ? "longterm" : "casual", this.invalid = e.invalid || null, this.matrix = n, this.isLuxonDuration = !0;
  }
  /**
   * Create Duration from a number of milliseconds.
   * @param {number} count of milliseconds
   * @param {Object} opts - options for parsing
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @return {Duration}
   */
  static fromMillis(e, t) {
    return J.fromObject({
      milliseconds: e
    }, t);
  }
  /**
   * Create a Duration from a JavaScript object with keys like 'years' and 'hours'.
   * If this object is empty then a zero milliseconds duration is returned.
   * @param {Object} obj - the object to create the DateTime from
   * @param {number} obj.years
   * @param {number} obj.quarters
   * @param {number} obj.months
   * @param {number} obj.weeks
   * @param {number} obj.days
   * @param {number} obj.hours
   * @param {number} obj.minutes
   * @param {number} obj.seconds
   * @param {number} obj.milliseconds
   * @param {Object} [opts=[]] - options for creating this Duration
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the preset conversion system to use
   * @param {string} [opts.matrix=Object] - the custom conversion system to use
   * @return {Duration}
   */
  static fromObject(e, t = {}) {
    if (e == null || typeof e != "object")
      throw new me(`Duration.fromObject: argument expected to be an object, got ${e === null ? "null" : typeof e}`);
    return new J({
      values: Ur(e, J.normalizeUnit),
      loc: Q.fromObject(t),
      conversionAccuracy: t.conversionAccuracy,
      matrix: t.matrix
    });
  }
  /**
   * Create a Duration from DurationLike.
   *
   * @param {Object | number | Duration} durationLike
   * One of:
   * - object with keys like 'years' and 'hours'.
   * - number representing milliseconds
   * - Duration instance
   * @return {Duration}
   */
  static fromDurationLike(e) {
    if (Qe(e))
      return J.fromMillis(e);
    if (J.isDuration(e))
      return e;
    if (typeof e == "object")
      return J.fromObject(e);
    throw new me(`Unknown duration argument ${e} of type ${typeof e}`);
  }
  /**
   * Create a Duration from an ISO 8601 duration string.
   * @param {string} text - text to parse
   * @param {Object} opts - options for parsing
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the preset conversion system to use
   * @param {string} [opts.matrix=Object] - the preset conversion system to use
   * @see https://en.wikipedia.org/wiki/ISO_8601#Durations
   * @example Duration.fromISO('P3Y6M1W4DT12H30M5S').toObject() //=> { years: 3, months: 6, weeks: 1, days: 4, hours: 12, minutes: 30, seconds: 5 }
   * @example Duration.fromISO('PT23H').toObject() //=> { hours: 23 }
   * @example Duration.fromISO('P5Y3M').toObject() //=> { years: 5, months: 3 }
   * @return {Duration}
   */
  static fromISO(e, t) {
    const [n] = nm(e);
    return n ? J.fromObject(n, t) : J.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
  }
  /**
   * Create a Duration from an ISO 8601 time string.
   * @param {string} text - text to parse
   * @param {Object} opts - options for parsing
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the preset conversion system to use
   * @param {string} [opts.matrix=Object] - the conversion system to use
   * @see https://en.wikipedia.org/wiki/ISO_8601#Times
   * @example Duration.fromISOTime('11:22:33.444').toObject() //=> { hours: 11, minutes: 22, seconds: 33, milliseconds: 444 }
   * @example Duration.fromISOTime('11:00').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @example Duration.fromISOTime('T11:00').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @example Duration.fromISOTime('1100').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @example Duration.fromISOTime('T1100').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @return {Duration}
   */
  static fromISOTime(e, t) {
    const [n] = im(e);
    return n ? J.fromObject(n, t) : J.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
  }
  /**
   * Create an invalid Duration.
   * @param {string} reason - simple string of why this datetime is invalid. Should not contain parameters or anything else data-dependent
   * @param {string} [explanation=null] - longer explanation, may include parameters and other useful debugging information
   * @return {Duration}
   */
  static invalid(e, t = null) {
    if (!e)
      throw new me("need to specify a reason the Duration is invalid");
    const n = e instanceof Ue ? e : new Ue(e, t);
    if (ne.throwOnInvalid)
      throw new Pd(n);
    return new J({
      invalid: n
    });
  }
  /**
   * @private
   */
  static normalizeUnit(e) {
    const t = {
      year: "years",
      years: "years",
      quarter: "quarters",
      quarters: "quarters",
      month: "months",
      months: "months",
      week: "weeks",
      weeks: "weeks",
      day: "days",
      days: "days",
      hour: "hours",
      hours: "hours",
      minute: "minutes",
      minutes: "minutes",
      second: "seconds",
      seconds: "seconds",
      millisecond: "milliseconds",
      milliseconds: "milliseconds"
    }[e && e.toLowerCase()];
    if (!t)
      throw new qa(e);
    return t;
  }
  /**
   * Check if an object is a Duration. Works across context boundaries
   * @param {object} o
   * @return {boolean}
   */
  static isDuration(e) {
    return e && e.isLuxonDuration || !1;
  }
  /**
   * Get  the locale of a Duration, such 'en-GB'
   * @type {string}
   */
  get locale() {
    return this.isValid ? this.loc.locale : null;
  }
  /**
   * Get the numbering system of a Duration, such 'beng'. The numbering system is used when formatting the Duration
   *
   * @type {string}
   */
  get numberingSystem() {
    return this.isValid ? this.loc.numberingSystem : null;
  }
  /**
   * Returns a string representation of this Duration formatted according to the specified format string. You may use these tokens:
   * * `S` for milliseconds
   * * `s` for seconds
   * * `m` for minutes
   * * `h` for hours
   * * `d` for days
   * * `w` for weeks
   * * `M` for months
   * * `y` for years
   * Notes:
   * * Add padding by repeating the token, e.g. "yy" pads the years to two digits, "hhhh" pads the hours out to four digits
   * * Tokens can be escaped by wrapping with single quotes.
   * * The duration will be converted to the set of units in the format string using {@link Duration#shiftTo} and the Durations's conversion accuracy setting.
   * @param {string} fmt - the format string
   * @param {Object} opts - options
   * @param {boolean} [opts.floor=true] - floor numerical values
   * @param {'negative'|'all'|'negativeLargestOnly'} [opts.signMode=negative] - How to handle signs
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toFormat("y d s") //=> "1 6 2"
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toFormat("yy dd sss") //=> "01 06 002"
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toFormat("M S") //=> "12 518402000"
   * @example Duration.fromObject({ days: 6, seconds: 2 }).toFormat("d s", { signMode: "all" }) //=> "+6 +2"
   * @example Duration.fromObject({ days: -6, seconds: -2 }).toFormat("d s", { signMode: "all" }) //=> "-6 -2"
   * @example Duration.fromObject({ days: -6, seconds: -2 }).toFormat("d s", { signMode: "negativeLargestOnly" }) //=> "-6 2"
   * @return {string}
   */
  toFormat(e, t = {}) {
    const n = {
      ...t,
      floor: t.round !== !1 && t.floor !== !1
    };
    return this.isValid ? ge.create(this.loc, n).formatDurationFromString(this, e) : si;
  }
  /**
   * Returns a string representation of a Duration with all units included.
   * To modify its behavior, use `listStyle` and any Intl.NumberFormat option, though `unitDisplay` is especially relevant.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/NumberFormat/NumberFormat#options
   * @param {Object} opts - Formatting options. Accepts the same keys as the options parameter of the native `Intl.NumberFormat` constructor, as well as `listStyle`.
   * @param {string} [opts.listStyle='narrow'] - How to format the merged list. Corresponds to the `style` property of the options parameter of the native `Intl.ListFormat` constructor.
   * @param {boolean} [opts.showZeros=true] - Show all units previously used by the duration even if they are zero
   * @example
   * ```js
   * var dur = Duration.fromObject({ months: 1, weeks: 0, hours: 5, minutes: 6 })
   * dur.toHuman() //=> '1 month, 0 weeks, 5 hours, 6 minutes'
   * dur.toHuman({ listStyle: "long" }) //=> '1 month, 0 weeks, 5 hours, and 6 minutes'
   * dur.toHuman({ unitDisplay: "short" }) //=> '1 mth, 0 wks, 5 hr, 6 min'
   * dur.toHuman({ showZeros: false }) //=> '1 month, 5 hours, 6 minutes'
   * ```
   */
  toHuman(e = {}) {
    if (!this.isValid)
      return si;
    const t = e.showZeros !== !1, n = ut.map((s) => {
      const i = this.values[s];
      return x(i) || i === 0 && !t ? null : this.loc.numberFormatter({
        style: "unit",
        unitDisplay: "long",
        ...e,
        unit: s.slice(0, -1)
      }).format(i);
    }).filter((s) => s);
    return this.loc.listFormatter({
      type: "conjunction",
      style: e.listStyle || "narrow",
      ...e
    }).format(n);
  }
  /**
   * Returns a JavaScript object with this Duration's values.
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toObject() //=> { years: 1, days: 6, seconds: 2 }
   * @return {Object}
   */
  toObject() {
    return this.isValid ? {
      ...this.values
    } : {};
  }
  /**
   * Returns an ISO 8601-compliant string representation of this Duration.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Durations
   * @example Duration.fromObject({ years: 3, seconds: 45 }).toISO() //=> 'P3YT45S'
   * @example Duration.fromObject({ months: 4, seconds: 45 }).toISO() //=> 'P4MT45S'
   * @example Duration.fromObject({ months: 5 }).toISO() //=> 'P5M'
   * @example Duration.fromObject({ minutes: 5 }).toISO() //=> 'PT5M'
   * @example Duration.fromObject({ milliseconds: 6 }).toISO() //=> 'PT0.006S'
   * @return {string}
   */
  toISO() {
    if (!this.isValid)
      return null;
    let e = "P";
    return this.years !== 0 && (e += this.years + "Y"), (this.months !== 0 || this.quarters !== 0) && (e += this.months + this.quarters * 3 + "M"), this.weeks !== 0 && (e += this.weeks + "W"), this.days !== 0 && (e += this.days + "D"), (this.hours !== 0 || this.minutes !== 0 || this.seconds !== 0 || this.milliseconds !== 0) && (e += "T"), this.hours !== 0 && (e += this.hours + "H"), this.minutes !== 0 && (e += this.minutes + "M"), (this.seconds !== 0 || this.milliseconds !== 0) && (e += Xn(this.seconds + this.milliseconds / 1e3, 3) + "S"), e === "P" && (e += "T0S"), e;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this Duration, formatted as a time of day.
   * Note that this will return null if the duration is invalid, negative, or equal to or greater than 24 hours.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Times
   * @param {Object} opts - options
   * @param {boolean} [opts.suppressMilliseconds=false] - exclude milliseconds from the format if they're 0
   * @param {boolean} [opts.suppressSeconds=false] - exclude seconds from the format if they're 0
   * @param {boolean} [opts.includePrefix=false] - include the `T` prefix
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example Duration.fromObject({ hours: 11 }).toISOTime() //=> '11:00:00.000'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ suppressMilliseconds: true }) //=> '11:00:00'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ suppressSeconds: true }) //=> '11:00'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ includePrefix: true }) //=> 'T11:00:00.000'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ format: 'basic' }) //=> '110000.000'
   * @return {string}
   */
  toISOTime(e = {}) {
    if (!this.isValid)
      return null;
    const t = this.toMillis();
    return t < 0 || t >= 864e5 ? null : (e = {
      suppressMilliseconds: !1,
      suppressSeconds: !1,
      includePrefix: !1,
      format: "extended",
      ...e,
      includeOffset: !1
    }, P.fromMillis(t, {
      zone: "UTC"
    }).toISOTime(e));
  }
  /**
   * Returns an ISO 8601 representation of this Duration appropriate for use in JSON.
   * @return {string}
   */
  toJSON() {
    return this.toISO();
  }
  /**
   * Returns an ISO 8601 representation of this Duration appropriate for use in debugging.
   * @return {string}
   */
  toString() {
    return this.toISO();
  }
  /**
   * Returns a string representation of this Duration appropriate for the REPL.
   * @return {string}
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return this.isValid ? `Duration { values: ${JSON.stringify(this.values)} }` : `Duration { Invalid, reason: ${this.invalidReason} }`;
  }
  /**
   * Returns an milliseconds value of this Duration.
   * @return {number}
   */
  toMillis() {
    return this.isValid ? Wo(this.matrix, this.values) : NaN;
  }
  /**
   * Returns an milliseconds value of this Duration. Alias of {@link toMillis}
   * @return {number}
   */
  valueOf() {
    return this.toMillis();
  }
  /**
   * Make this Duration longer by the specified amount. Return a newly-constructed Duration.
   * @param {Duration|Object|number} duration - The amount to add. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   * @return {Duration}
   */
  plus(e) {
    if (!this.isValid)
      return this;
    const t = J.fromDurationLike(e), n = {};
    for (const s of ut)
      (Et(t.values, s) || Et(this.values, s)) && (n[s] = t.get(s) + this.get(s));
    return Ze(this, {
      values: n
    }, !0);
  }
  /**
   * Make this Duration shorter by the specified amount. Return a newly-constructed Duration.
   * @param {Duration|Object|number} duration - The amount to subtract. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   * @return {Duration}
   */
  minus(e) {
    if (!this.isValid)
      return this;
    const t = J.fromDurationLike(e);
    return this.plus(t.negate());
  }
  /**
   * Scale this Duration by the specified amount. Return a newly-constructed Duration.
   * @param {function} fn - The function to apply to each unit. Arity is 1 or 2: the value of the unit and, optionally, the unit name. Must return a number.
   * @example Duration.fromObject({ hours: 1, minutes: 30 }).mapUnits(x => x * 2) //=> { hours: 2, minutes: 60 }
   * @example Duration.fromObject({ hours: 1, minutes: 30 }).mapUnits((x, u) => u === "hours" ? x * 2 : x) //=> { hours: 2, minutes: 30 }
   * @return {Duration}
   */
  mapUnits(e) {
    if (!this.isValid)
      return this;
    const t = {};
    for (const n of Object.keys(this.values))
      t[n] = wo(e(this.values[n], n));
    return Ze(this, {
      values: t
    }, !0);
  }
  /**
   * Get the value of unit.
   * @param {string} unit - a unit such as 'minute' or 'day'
   * @example Duration.fromObject({years: 2, days: 3}).get('years') //=> 2
   * @example Duration.fromObject({years: 2, days: 3}).get('months') //=> 0
   * @example Duration.fromObject({years: 2, days: 3}).get('days') //=> 3
   * @return {number}
   */
  get(e) {
    return this[J.normalizeUnit(e)];
  }
  /**
   * "Set" the values of specified units. Return a newly-constructed Duration.
   * @param {Object} values - a mapping of units to numbers
   * @example dur.set({ years: 2017 })
   * @example dur.set({ hours: 8, minutes: 30 })
   * @return {Duration}
   */
  set(e) {
    if (!this.isValid)
      return this;
    const t = {
      ...this.values,
      ...Ur(e, J.normalizeUnit)
    };
    return Ze(this, {
      values: t
    });
  }
  /**
   * "Set" the locale and/or numberingSystem.  Returns a newly-constructed Duration.
   * @example dur.reconfigure({ locale: 'en-GB' })
   * @return {Duration}
   */
  reconfigure({
    locale: e,
    numberingSystem: t,
    conversionAccuracy: n,
    matrix: s
  } = {}) {
    const a = {
      loc: this.loc.clone({
        locale: e,
        numberingSystem: t
      }),
      matrix: s,
      conversionAccuracy: n
    };
    return Ze(this, a);
  }
  /**
   * Return the length of the duration in the specified unit.
   * @param {string} unit - a unit such as 'minutes' or 'days'
   * @example Duration.fromObject({years: 1}).as('days') //=> 365
   * @example Duration.fromObject({years: 1}).as('months') //=> 12
   * @example Duration.fromObject({hours: 60}).as('days') //=> 2.5
   * @return {number}
   */
  as(e) {
    return this.isValid ? this.shiftTo(e).get(e) : NaN;
  }
  /**
   * Reduce this Duration to its canonical representation in its current units.
   * Assuming the overall value of the Duration is positive, this means:
   * - excessive values for lower-order units are converted to higher-order units (if possible, see first and second example)
   * - negative lower-order units are converted to higher order units (there must be such a higher order unit, otherwise
   *   the overall value would be negative, see third example)
   * - fractional values for higher-order units are converted to lower-order units (if possible, see fourth example)
   *
   * If the overall value is negative, the result of this method is equivalent to `this.negate().normalize().negate()`.
   * @example Duration.fromObject({ years: 2, days: 5000 }).normalize().toObject() //=> { years: 15, days: 255 }
   * @example Duration.fromObject({ days: 5000 }).normalize().toObject() //=> { days: 5000 }
   * @example Duration.fromObject({ hours: 12, minutes: -45 }).normalize().toObject() //=> { hours: 11, minutes: 15 }
   * @example Duration.fromObject({ years: 2.5, days: 0, hours: 0 }).normalize().toObject() //=> { years: 2, days: 182, hours: 12 }
   * @return {Duration}
   */
  normalize() {
    if (!this.isValid)
      return this;
    const e = this.toObject();
    return ii(this.matrix, e), Ze(this, {
      values: e
    }, !0);
  }
  /**
   * Rescale units to its largest representation
   * @example Duration.fromObject({ milliseconds: 90000 }).rescale().toObject() //=> { minutes: 1, seconds: 30 }
   * @return {Duration}
   */
  rescale() {
    if (!this.isValid)
      return this;
    const e = ai(this.normalize().shiftToAll().toObject());
    return Ze(this, {
      values: e
    }, !0);
  }
  /**
   * Convert this Duration into its representation in a different set of units.
   * @example Duration.fromObject({ hours: 1, seconds: 30 }).shiftTo('minutes', 'milliseconds').toObject() //=> { minutes: 60, milliseconds: 30000 }
   * @return {Duration}
   */
  shiftTo(...e) {
    if (!this.isValid)
      return this;
    if (e.length === 0)
      return this;
    e = e.map((a) => J.normalizeUnit(a));
    const t = {}, n = {}, s = this.toObject();
    let i;
    for (const a of ut)
      if (e.indexOf(a) >= 0) {
        i = a;
        let l = 0;
        for (const f in n)
          l += this.matrix[f][a] * n[f], n[f] = 0;
        Qe(s[a]) && (l += s[a]);
        const o = Math.trunc(l);
        t[a] = o, n[a] = (l * 1e3 - o * 1e3) / 1e3;
      } else
        Qe(s[a]) && (n[a] = s[a]);
    for (const a in n)
      n[a] !== 0 && (t[i] += a === i ? n[a] : n[a] / this.matrix[i][a]);
    return ii(this.matrix, t), Ze(this, {
      values: t
    }, !0);
  }
  /**
   * Shift this Duration to all available units.
   * Same as shiftTo("years", "months", "weeks", "days", "hours", "minutes", "seconds", "milliseconds")
   * @return {Duration}
   */
  shiftToAll() {
    return this.isValid ? this.shiftTo("years", "months", "weeks", "days", "hours", "minutes", "seconds", "milliseconds") : this;
  }
  /**
   * Return the negative of this Duration.
   * @example Duration.fromObject({ hours: 1, seconds: 30 }).negate().toObject() //=> { hours: -1, seconds: -30 }
   * @return {Duration}
   */
  negate() {
    if (!this.isValid)
      return this;
    const e = {};
    for (const t of Object.keys(this.values))
      e[t] = this.values[t] === 0 ? 0 : -this.values[t];
    return Ze(this, {
      values: e
    }, !0);
  }
  /**
   * Removes all units with values equal to 0 from this Duration.
   * @example Duration.fromObject({ years: 2, days: 0, hours: 0, minutes: 0 }).removeZeros().toObject() //=> { years: 2 }
   * @return {Duration}
   */
  removeZeros() {
    if (!this.isValid)
      return this;
    const e = ai(this.values);
    return Ze(this, {
      values: e
    }, !0);
  }
  /**
   * Get the years.
   * @type {number}
   */
  get years() {
    return this.isValid ? this.values.years || 0 : NaN;
  }
  /**
   * Get the quarters.
   * @type {number}
   */
  get quarters() {
    return this.isValid ? this.values.quarters || 0 : NaN;
  }
  /**
   * Get the months.
   * @type {number}
   */
  get months() {
    return this.isValid ? this.values.months || 0 : NaN;
  }
  /**
   * Get the weeks
   * @type {number}
   */
  get weeks() {
    return this.isValid ? this.values.weeks || 0 : NaN;
  }
  /**
   * Get the days.
   * @type {number}
   */
  get days() {
    return this.isValid ? this.values.days || 0 : NaN;
  }
  /**
   * Get the hours.
   * @type {number}
   */
  get hours() {
    return this.isValid ? this.values.hours || 0 : NaN;
  }
  /**
   * Get the minutes.
   * @type {number}
   */
  get minutes() {
    return this.isValid ? this.values.minutes || 0 : NaN;
  }
  /**
   * Get the seconds.
   * @return {number}
   */
  get seconds() {
    return this.isValid ? this.values.seconds || 0 : NaN;
  }
  /**
   * Get the milliseconds.
   * @return {number}
   */
  get milliseconds() {
    return this.isValid ? this.values.milliseconds || 0 : NaN;
  }
  /**
   * Returns whether the Duration is invalid. Invalid durations are returned by diff operations
   * on invalid DateTimes or Intervals.
   * @return {boolean}
   */
  get isValid() {
    return this.invalid === null;
  }
  /**
   * Returns an error code if this Duration became invalid, or null if the Duration is valid
   * @return {string}
   */
  get invalidReason() {
    return this.invalid ? this.invalid.reason : null;
  }
  /**
   * Returns an explanation of why this Duration became invalid, or null if the Duration is valid
   * @type {string}
   */
  get invalidExplanation() {
    return this.invalid ? this.invalid.explanation : null;
  }
  /**
   * Equality check
   * Two Durations are equal iff they have the same units and the same values for each unit.
   * @param {Duration} other
   * @return {boolean}
   */
  equals(e) {
    if (!this.isValid || !e.isValid || !this.loc.equals(e.loc))
      return !1;
    function t(n, s) {
      return n === void 0 || n === 0 ? s === void 0 || s === 0 : n === s;
    }
    for (const n of ut)
      if (!t(this.values[n], e.values[n]))
        return !1;
    return !0;
  }
}
const yt = "Invalid Interval";
function hm(r, e) {
  return !r || !r.isValid ? re.invalid("missing or invalid start") : !e || !e.isValid ? re.invalid("missing or invalid end") : e < r ? re.invalid("end before start", `The end of an interval must be after its start, but you had start=${r.toISO()} and end=${e.toISO()}`) : null;
}
class re {
  /**
   * @private
   */
  constructor(e) {
    this.s = e.start, this.e = e.end, this.invalid = e.invalid || null, this.isLuxonInterval = !0;
  }
  /**
   * Create an invalid Interval.
   * @param {string} reason - simple string of why this Interval is invalid. Should not contain parameters or anything else data-dependent
   * @param {string} [explanation=null] - longer explanation, may include parameters and other useful debugging information
   * @return {Interval}
   */
  static invalid(e, t = null) {
    if (!e)
      throw new me("need to specify a reason the Interval is invalid");
    const n = e instanceof Ue ? e : new Ue(e, t);
    if (ne.throwOnInvalid)
      throw new xd(n);
    return new re({
      invalid: n
    });
  }
  /**
   * Create an Interval from a start DateTime and an end DateTime. Inclusive of the start but not the end.
   * @param {DateTime|Date|Object} start
   * @param {DateTime|Date|Object} end
   * @return {Interval}
   */
  static fromDateTimes(e, t) {
    const n = zt(e), s = zt(t), i = hm(n, s);
    return i ?? new re({
      start: n,
      end: s
    });
  }
  /**
   * Create an Interval from a start DateTime and a Duration to extend to.
   * @param {DateTime|Date|Object} start
   * @param {Duration|Object|number} duration - the length of the Interval.
   * @return {Interval}
   */
  static after(e, t) {
    const n = J.fromDurationLike(t), s = zt(e);
    return re.fromDateTimes(s, s.plus(n));
  }
  /**
   * Create an Interval from an end DateTime and a Duration to extend backwards to.
   * @param {DateTime|Date|Object} end
   * @param {Duration|Object|number} duration - the length of the Interval.
   * @return {Interval}
   */
  static before(e, t) {
    const n = J.fromDurationLike(t), s = zt(e);
    return re.fromDateTimes(s.minus(n), s);
  }
  /**
   * Create an Interval from an ISO 8601 string.
   * Accepts `<start>/<end>`, `<start>/<duration>`, and `<duration>/<end>` formats.
   * @param {string} text - the ISO string to parse
   * @param {Object} [opts] - options to pass {@link DateTime#fromISO} and optionally {@link Duration#fromISO}
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @return {Interval}
   */
  static fromISO(e, t) {
    const [n, s] = (e || "").split("/", 2);
    if (n && s) {
      let i, a;
      try {
        i = P.fromISO(n, t), a = i.isValid;
      } catch {
        a = !1;
      }
      let l, o;
      try {
        l = P.fromISO(s, t), o = l.isValid;
      } catch {
        o = !1;
      }
      if (a && o)
        return re.fromDateTimes(i, l);
      if (a) {
        const f = J.fromISO(s, t);
        if (f.isValid)
          return re.after(i, f);
      } else if (o) {
        const f = J.fromISO(n, t);
        if (f.isValid)
          return re.before(l, f);
      }
    }
    return re.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
  }
  /**
   * Check if an object is an Interval. Works across context boundaries
   * @param {object} o
   * @return {boolean}
   */
  static isInterval(e) {
    return e && e.isLuxonInterval || !1;
  }
  /**
   * Returns the start of the Interval
   * @type {DateTime}
   */
  get start() {
    return this.isValid ? this.s : null;
  }
  /**
   * Returns the end of the Interval. This is the first instant which is not part of the interval
   * (Interval is half-open).
   * @type {DateTime}
   */
  get end() {
    return this.isValid ? this.e : null;
  }
  /**
   * Returns the last DateTime included in the interval (since end is not part of the interval)
   * @type {DateTime}
   */
  get lastDateTime() {
    return this.isValid && this.e ? this.e.minus(1) : null;
  }
  /**
   * Returns whether this Interval's end is at least its start, meaning that the Interval isn't 'backwards'.
   * @type {boolean}
   */
  get isValid() {
    return this.invalidReason === null;
  }
  /**
   * Returns an error code if this Interval is invalid, or null if the Interval is valid
   * @type {string}
   */
  get invalidReason() {
    return this.invalid ? this.invalid.reason : null;
  }
  /**
   * Returns an explanation of why this Interval became invalid, or null if the Interval is valid
   * @type {string}
   */
  get invalidExplanation() {
    return this.invalid ? this.invalid.explanation : null;
  }
  /**
   * Returns the length of the Interval in the specified unit.
   * @param {string} unit - the unit (such as 'hours' or 'days') to return the length in.
   * @return {number}
   */
  length(e = "milliseconds") {
    return this.isValid ? this.toDuration(e).get(e) : NaN;
  }
  /**
   * Returns the count of minutes, hours, days, months, or years included in the Interval, even in part.
   * Unlike {@link Interval#length} this counts sections of the calendar, not periods of time, e.g. specifying 'day'
   * asks 'what dates are included in this interval?', not 'how many days long is this interval?'
   * @param {string} [unit='milliseconds'] - the unit of time to count.
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week; this operation will always use the locale of the start DateTime
   * @return {number}
   */
  count(e = "milliseconds", t) {
    if (!this.isValid)
      return NaN;
    const n = this.start.startOf(e, t);
    let s;
    return t != null && t.useLocaleWeeks ? s = this.end.reconfigure({
      locale: n.locale
    }) : s = this.end, s = s.startOf(e, t), Math.floor(s.diff(n, e).get(e)) + (s.valueOf() !== this.end.valueOf());
  }
  /**
   * Returns whether this Interval's start and end are both in the same unit of time
   * @param {string} unit - the unit of time to check sameness on
   * @return {boolean}
   */
  hasSame(e) {
    return this.isValid ? this.isEmpty() || this.e.minus(1).hasSame(this.s, e) : !1;
  }
  /**
   * Return whether this Interval has the same start and end DateTimes.
   * @return {boolean}
   */
  isEmpty() {
    return this.s.valueOf() === this.e.valueOf();
  }
  /**
   * Return whether this Interval's start is after the specified DateTime.
   * @param {DateTime} dateTime
   * @return {boolean}
   */
  isAfter(e) {
    return this.isValid ? this.s > e : !1;
  }
  /**
   * Return whether this Interval's end is before the specified DateTime.
   * @param {DateTime} dateTime
   * @return {boolean}
   */
  isBefore(e) {
    return this.isValid ? this.e <= e : !1;
  }
  /**
   * Return whether this Interval contains the specified DateTime.
   * @param {DateTime} dateTime
   * @return {boolean}
   */
  contains(e) {
    return this.isValid ? this.s <= e && this.e > e : !1;
  }
  /**
   * "Sets" the start and/or end dates. Returns a newly-constructed Interval.
   * @param {Object} values - the values to set
   * @param {DateTime} values.start - the starting DateTime
   * @param {DateTime} values.end - the ending DateTime
   * @return {Interval}
   */
  set({
    start: e,
    end: t
  } = {}) {
    return this.isValid ? re.fromDateTimes(e || this.s, t || this.e) : this;
  }
  /**
   * Split this Interval at each of the specified DateTimes
   * @param {...DateTime} dateTimes - the unit of time to count.
   * @return {Array}
   */
  splitAt(...e) {
    if (!this.isValid)
      return [];
    const t = e.map(zt).filter((a) => this.contains(a)).sort((a, l) => a.toMillis() - l.toMillis()), n = [];
    let {
      s
    } = this, i = 0;
    for (; s < this.e; ) {
      const a = t[i] || this.e, l = +a > +this.e ? this.e : a;
      n.push(re.fromDateTimes(s, l)), s = l, i += 1;
    }
    return n;
  }
  /**
   * Split this Interval into smaller Intervals, each of the specified length.
   * Left over time is grouped into a smaller interval
   * @param {Duration|Object|number} duration - The length of each resulting interval.
   * @return {Array}
   */
  splitBy(e) {
    const t = J.fromDurationLike(e);
    if (!this.isValid || !t.isValid || t.as("milliseconds") === 0)
      return [];
    let {
      s: n
    } = this, s = 1, i;
    const a = [];
    for (; n < this.e; ) {
      const l = this.start.plus(t.mapUnits((o) => o * s));
      i = +l > +this.e ? this.e : l, a.push(re.fromDateTimes(n, i)), n = i, s += 1;
    }
    return a;
  }
  /**
   * Split this Interval into the specified number of smaller intervals.
   * @param {number} numberOfParts - The number of Intervals to divide the Interval into.
   * @return {Array}
   */
  divideEqually(e) {
    return this.isValid ? this.splitBy(this.length() / e).slice(0, e) : [];
  }
  /**
   * Return whether this Interval overlaps with the specified Interval
   * @param {Interval} other
   * @return {boolean}
   */
  overlaps(e) {
    return this.e > e.s && this.s < e.e;
  }
  /**
   * Return whether this Interval's end is adjacent to the specified Interval's start.
   * @param {Interval} other
   * @return {boolean}
   */
  abutsStart(e) {
    return this.isValid ? +this.e == +e.s : !1;
  }
  /**
   * Return whether this Interval's start is adjacent to the specified Interval's end.
   * @param {Interval} other
   * @return {boolean}
   */
  abutsEnd(e) {
    return this.isValid ? +e.e == +this.s : !1;
  }
  /**
   * Returns true if this Interval fully contains the specified Interval, specifically if the intersect (of this Interval and the other Interval) is equal to the other Interval; false otherwise.
   * @param {Interval} other
   * @return {boolean}
   */
  engulfs(e) {
    return this.isValid ? this.s <= e.s && this.e >= e.e : !1;
  }
  /**
   * Return whether this Interval has the same start and end as the specified Interval.
   * @param {Interval} other
   * @return {boolean}
   */
  equals(e) {
    return !this.isValid || !e.isValid ? !1 : this.s.equals(e.s) && this.e.equals(e.e);
  }
  /**
   * Return an Interval representing the intersection of this Interval and the specified Interval.
   * Specifically, the resulting Interval has the maximum start time and the minimum end time of the two Intervals.
   * Returns null if the intersection is empty, meaning, the intervals don't intersect.
   * @param {Interval} other
   * @return {Interval}
   */
  intersection(e) {
    if (!this.isValid)
      return this;
    const t = this.s > e.s ? this.s : e.s, n = this.e < e.e ? this.e : e.e;
    return t >= n ? null : re.fromDateTimes(t, n);
  }
  /**
   * Return an Interval representing the union of this Interval and the specified Interval.
   * Specifically, the resulting Interval has the minimum start time and the maximum end time of the two Intervals.
   * @param {Interval} other
   * @return {Interval}
   */
  union(e) {
    if (!this.isValid)
      return this;
    const t = this.s < e.s ? this.s : e.s, n = this.e > e.e ? this.e : e.e;
    return re.fromDateTimes(t, n);
  }
  /**
   * Merge an array of Intervals into an equivalent minimal set of Intervals.
   * Combines overlapping and adjacent Intervals.
   * The resulting array will contain the Intervals in ascending order, that is, starting with the earliest Interval
   * and ending with the latest.
   *
   * @param {Array} intervals
   * @return {Array}
   */
  static merge(e) {
    const [t, n] = e.sort((s, i) => s.s - i.s).reduce(([s, i], a) => i ? i.overlaps(a) || i.abutsStart(a) ? [s, i.union(a)] : [s.concat([i]), a] : [s, a], [[], null]);
    return n && t.push(n), t;
  }
  /**
   * Return an array of Intervals representing the spans of time that only appear in one of the specified Intervals.
   * @param {Array} intervals
   * @return {Array}
   */
  static xor(e) {
    let t = null, n = 0;
    const s = [], i = e.map((o) => [{
      time: o.s,
      type: "s"
    }, {
      time: o.e,
      type: "e"
    }]), a = Array.prototype.concat(...i), l = a.sort((o, f) => o.time - f.time);
    for (const o of l)
      n += o.type === "s" ? 1 : -1, n === 1 ? t = o.time : (t && +t != +o.time && s.push(re.fromDateTimes(t, o.time)), t = null);
    return re.merge(s);
  }
  /**
   * Return an Interval representing the span of time in this Interval that doesn't overlap with any of the specified Intervals.
   * @param {...Interval} intervals
   * @return {Array}
   */
  difference(...e) {
    return re.xor([this].concat(e)).map((t) => this.intersection(t)).filter((t) => t && !t.isEmpty());
  }
  /**
   * Returns a string representation of this Interval appropriate for debugging.
   * @return {string}
   */
  toString() {
    return this.isValid ? `[${this.s.toISO()} – ${this.e.toISO()})` : yt;
  }
  /**
   * Returns a string representation of this Interval appropriate for the REPL.
   * @return {string}
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return this.isValid ? `Interval { start: ${this.s.toISO()}, end: ${this.e.toISO()} }` : `Interval { Invalid, reason: ${this.invalidReason} }`;
  }
  /**
   * Returns a localized string representing this Interval. Accepts the same options as the
   * Intl.DateTimeFormat constructor and any presets defined by Luxon, such as
   * {@link DateTime.DATE_FULL} or {@link DateTime.TIME_SIMPLE}. The exact behavior of this method
   * is browser-specific, but in general it will return an appropriate representation of the
   * Interval in the assigned locale. Defaults to the system's locale if no locale has been
   * specified.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param {Object} [formatOpts=DateTime.DATE_SHORT] - Either a DateTime preset or
   * Intl.DateTimeFormat constructor options.
   * @param {Object} opts - Options to override the configuration of the start DateTime.
   * @example Interval.fromISO('2022-11-07T09:00Z/2022-11-08T09:00Z').toLocaleString(); //=> 11/7/2022 – 11/8/2022
   * @example Interval.fromISO('2022-11-07T09:00Z/2022-11-08T09:00Z').toLocaleString(DateTime.DATE_FULL); //=> November 7 – 8, 2022
   * @example Interval.fromISO('2022-11-07T09:00Z/2022-11-08T09:00Z').toLocaleString(DateTime.DATE_FULL, { locale: 'fr-FR' }); //=> 7–8 novembre 2022
   * @example Interval.fromISO('2022-11-07T17:00Z/2022-11-07T19:00Z').toLocaleString(DateTime.TIME_SIMPLE); //=> 6:00 – 8:00 PM
   * @example Interval.fromISO('2022-11-07T17:00Z/2022-11-07T19:00Z').toLocaleString({ weekday: 'short', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }); //=> Mon, Nov 07, 6:00 – 8:00 p
   * @return {string}
   */
  toLocaleString(e = Ir, t = {}) {
    return this.isValid ? ge.create(this.s.loc.clone(t), e).formatInterval(this) : yt;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this Interval.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @param {Object} opts - The same options as {@link DateTime#toISO}
   * @return {string}
   */
  toISO(e) {
    return this.isValid ? `${this.s.toISO(e)}/${this.e.toISO(e)}` : yt;
  }
  /**
   * Returns an ISO 8601-compliant string representation of date of this Interval.
   * The time components are ignored.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @return {string}
   */
  toISODate() {
    return this.isValid ? `${this.s.toISODate()}/${this.e.toISODate()}` : yt;
  }
  /**
   * Returns an ISO 8601-compliant string representation of time of this Interval.
   * The date components are ignored.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @param {Object} opts - The same options as {@link DateTime#toISO}
   * @return {string}
   */
  toISOTime(e) {
    return this.isValid ? `${this.s.toISOTime(e)}/${this.e.toISOTime(e)}` : yt;
  }
  /**
   * Returns a string representation of this Interval formatted according to the specified format
   * string. **You may not want this.** See {@link Interval#toLocaleString} for a more flexible
   * formatting tool.
   * @param {string} dateFormat - The format string. This string formats the start and end time.
   * See {@link DateTime#toFormat} for details.
   * @param {Object} opts - Options.
   * @param {string} [opts.separator =  ' – '] - A separator to place between the start and end
   * representations.
   * @return {string}
   */
  toFormat(e, {
    separator: t = " – "
  } = {}) {
    return this.isValid ? `${this.s.toFormat(e)}${t}${this.e.toFormat(e)}` : yt;
  }
  /**
   * Return a Duration representing the time spanned by this interval.
   * @param {string|string[]} [unit=['milliseconds']] - the unit or units (such as 'hours' or 'days') to include in the duration.
   * @param {Object} opts - options that affect the creation of the Duration
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @example Interval.fromDateTimes(dt1, dt2).toDuration().toObject() //=> { milliseconds: 88489257 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration('days').toObject() //=> { days: 1.0241812152777778 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration(['hours', 'minutes']).toObject() //=> { hours: 24, minutes: 34.82095 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration(['hours', 'minutes', 'seconds']).toObject() //=> { hours: 24, minutes: 34, seconds: 49.257 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration('seconds').toObject() //=> { seconds: 88489.257 }
   * @return {Duration}
   */
  toDuration(e, t) {
    return this.isValid ? this.e.diff(this.s, e, t) : J.invalid(this.invalidReason);
  }
  /**
   * Run mapFn on the interval start and end, returning a new Interval from the resulting DateTimes
   * @param {function} mapFn
   * @return {Interval}
   * @example Interval.fromDateTimes(dt1, dt2).mapEndpoints(endpoint => endpoint.toUTC())
   * @example Interval.fromDateTimes(dt1, dt2).mapEndpoints(endpoint => endpoint.plus({ hours: 2 }))
   */
  mapEndpoints(e) {
    return re.fromDateTimes(e(this.s), e(this.e));
  }
}
class $t {
  /**
   * Return whether the specified zone contains a DST.
   * @param {string|Zone} [zone='local'] - Zone to check. Defaults to the environment's local zone.
   * @return {boolean}
   */
  static hasDST(e = ne.defaultZone) {
    const t = P.now().setZone(e).set({
      month: 12
    });
    return !e.isUniversal && t.offset !== t.set({
      month: 6
    }).offset;
  }
  /**
   * Return whether the specified zone is a valid IANA specifier.
   * @param {string} zone - Zone to check
   * @return {boolean}
   */
  static isValidIANAZone(e) {
    return je.isValidZone(e);
  }
  /**
   * Converts the input into a {@link Zone} instance.
   *
   * * If `input` is already a Zone instance, it is returned unchanged.
   * * If `input` is a string containing a valid time zone name, a Zone instance
   *   with that name is returned.
   * * If `input` is a string that doesn't refer to a known time zone, a Zone
   *   instance with {@link Zone#isValid} == false is returned.
   * * If `input is a number, a Zone instance with the specified fixed offset
   *   in minutes is returned.
   * * If `input` is `null` or `undefined`, the default zone is returned.
   * @param {string|Zone|number} [input] - the value to be converted
   * @return {Zone}
   */
  static normalizeZone(e) {
    return Ke(e, ne.defaultZone);
  }
  /**
   * Get the weekday on which the week starts according to the given locale.
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @returns {number} the start of the week, 1 for Monday through 7 for Sunday
   */
  static getStartOfWeek({
    locale: e = null,
    locObj: t = null
  } = {}) {
    return (t || Q.create(e)).getStartOfWeek();
  }
  /**
   * Get the minimum number of days necessary in a week before it is considered part of the next year according
   * to the given locale.
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @returns {number}
   */
  static getMinimumDaysInFirstWeek({
    locale: e = null,
    locObj: t = null
  } = {}) {
    return (t || Q.create(e)).getMinDaysInFirstWeek();
  }
  /**
   * Get the weekdays, which are considered the weekend according to the given locale
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @returns {number[]} an array of weekdays, 1 for Monday through 7 for Sunday
   */
  static getWeekendWeekdays({
    locale: e = null,
    locObj: t = null
  } = {}) {
    return (t || Q.create(e)).getWeekendDays().slice();
  }
  /**
   * Return an array of standalone month names.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param {string} [length='long'] - the length of the month representation, such as "numeric", "2-digit", "narrow", "short", "long"
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @param {string} [opts.outputCalendar='gregory'] - the calendar
   * @example Info.months()[0] //=> 'January'
   * @example Info.months('short')[0] //=> 'Jan'
   * @example Info.months('numeric')[0] //=> '1'
   * @example Info.months('short', { locale: 'fr-CA' } )[0] //=> 'janv.'
   * @example Info.months('numeric', { locale: 'ar' })[0] //=> '١'
   * @example Info.months('long', { outputCalendar: 'islamic' })[0] //=> 'Rabiʻ I'
   * @return {Array}
   */
  static months(e = "long", {
    locale: t = null,
    numberingSystem: n = null,
    locObj: s = null,
    outputCalendar: i = "gregory"
  } = {}) {
    return (s || Q.create(t, n, i)).months(e);
  }
  /**
   * Return an array of format month names.
   * Format months differ from standalone months in that they're meant to appear next to the day of the month. In some languages, that
   * changes the string.
   * See {@link Info#months}
   * @param {string} [length='long'] - the length of the month representation, such as "numeric", "2-digit", "narrow", "short", "long"
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @param {string} [opts.outputCalendar='gregory'] - the calendar
   * @return {Array}
   */
  static monthsFormat(e = "long", {
    locale: t = null,
    numberingSystem: n = null,
    locObj: s = null,
    outputCalendar: i = "gregory"
  } = {}) {
    return (s || Q.create(t, n, i)).months(e, !0);
  }
  /**
   * Return an array of standalone week names.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param {string} [length='long'] - the length of the weekday representation, such as "narrow", "short", "long".
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @example Info.weekdays()[0] //=> 'Monday'
   * @example Info.weekdays('short')[0] //=> 'Mon'
   * @example Info.weekdays('short', { locale: 'fr-CA' })[0] //=> 'lun.'
   * @example Info.weekdays('short', { locale: 'ar' })[0] //=> 'الاثنين'
   * @return {Array}
   */
  static weekdays(e = "long", {
    locale: t = null,
    numberingSystem: n = null,
    locObj: s = null
  } = {}) {
    return (s || Q.create(t, n, null)).weekdays(e);
  }
  /**
   * Return an array of format week names.
   * Format weekdays differ from standalone weekdays in that they're meant to appear next to more date information. In some languages, that
   * changes the string.
   * See {@link Info#weekdays}
   * @param {string} [length='long'] - the length of the month representation, such as "narrow", "short", "long".
   * @param {Object} opts - options
   * @param {string} [opts.locale=null] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @return {Array}
   */
  static weekdaysFormat(e = "long", {
    locale: t = null,
    numberingSystem: n = null,
    locObj: s = null
  } = {}) {
    return (s || Q.create(t, n, null)).weekdays(e, !0);
  }
  /**
   * Return an array of meridiems.
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @example Info.meridiems() //=> [ 'AM', 'PM' ]
   * @example Info.meridiems({ locale: 'my' }) //=> [ 'နံနက်', 'ညနေ' ]
   * @return {Array}
   */
  static meridiems({
    locale: e = null
  } = {}) {
    return Q.create(e).meridiems();
  }
  /**
   * Return an array of eras, such as ['BC', 'AD']. The locale can be specified, but the calendar system is always Gregorian.
   * @param {string} [length='short'] - the length of the era representation, such as "short" or "long".
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @example Info.eras() //=> [ 'BC', 'AD' ]
   * @example Info.eras('long') //=> [ 'Before Christ', 'Anno Domini' ]
   * @example Info.eras('long', { locale: 'fr' }) //=> [ 'avant Jésus-Christ', 'après Jésus-Christ' ]
   * @return {Array}
   */
  static eras(e = "short", {
    locale: t = null
  } = {}) {
    return Q.create(t, null, "gregory").eras(e);
  }
  /**
   * Return the set of available features in this environment.
   * Some features of Luxon are not available in all environments. For example, on older browsers, relative time formatting support is not available. Use this function to figure out if that's the case.
   * Keys:
   * * `relative`: whether this environment supports relative time formatting
   * * `localeWeek`: whether this environment supports different weekdays for the start of the week based on the locale
   * @example Info.features() //=> { relative: false, localeWeek: true }
   * @return {Object}
   */
  static features() {
    return {
      relative: _o(),
      localeWeek: bo()
    };
  }
}
function oi(r, e) {
  const t = (s) => s.toUTC(0, {
    keepLocalTime: !0
  }).startOf("day").valueOf(), n = t(e) - t(r);
  return Math.floor(J.fromMillis(n).as("days"));
}
function mm(r, e, t) {
  const n = [["years", (o, f) => f.year - o.year], ["quarters", (o, f) => f.quarter - o.quarter + (f.year - o.year) * 4], ["months", (o, f) => f.month - o.month + (f.year - o.year) * 12], ["weeks", (o, f) => {
    const u = oi(o, f);
    return (u - u % 7) / 7;
  }], ["days", oi]], s = {}, i = r;
  let a, l;
  for (const [o, f] of n)
    t.indexOf(o) >= 0 && (a = o, s[o] = f(r, e), l = i.plus(s), l > e ? (s[o]--, r = i.plus(s), r > e && (l = r, s[o]--, r = i.plus(s))) : r = l);
  return [r, s, l, a];
}
function pm(r, e, t, n) {
  let [s, i, a, l] = mm(r, e, t);
  const o = e - s, f = t.filter((d) => ["hours", "minutes", "seconds", "milliseconds"].indexOf(d) >= 0);
  f.length === 0 && (a < e && (a = s.plus({
    [l]: 1
  })), a !== s && (i[l] = (i[l] || 0) + o / (a - s)));
  const u = J.fromObject(i, n);
  return f.length > 0 ? J.fromMillis(o, n).shiftTo(...f).plus(u) : u;
}
const gm = "missing Intl.DateTimeFormat.formatToParts support";
function K(r, e = (t) => t) {
  return {
    regex: r,
    deser: ([t]) => e(ah(t))
  };
}
const ym = String.fromCharCode(160), Uo = `[ ${ym}]`, xo = new RegExp(Uo, "g");
function _m(r) {
  return r.replace(/\./g, "\\.?").replace(xo, Uo);
}
function li(r) {
  return r.replace(/\./g, "").replace(xo, " ").toLowerCase();
}
function Ae(r, e) {
  return r === null ? null : {
    regex: RegExp(r.map(_m).join("|")),
    deser: ([t]) => r.findIndex((n) => li(t) === li(n)) + e
  };
}
function ui(r, e) {
  return {
    regex: r,
    deser: ([, t, n]) => Zr(t, n),
    groups: e
  };
}
function yr(r) {
  return {
    regex: r,
    deser: ([e]) => e
  };
}
function bm(r) {
  return r.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
}
function vm(r, e) {
  const t = Ie(e), n = Ie(e, "{2}"), s = Ie(e, "{3}"), i = Ie(e, "{4}"), a = Ie(e, "{6}"), l = Ie(e, "{1,2}"), o = Ie(e, "{1,3}"), f = Ie(e, "{1,6}"), u = Ie(e, "{1,9}"), d = Ie(e, "{2,4}"), h = Ie(e, "{4,6}"), c = (p) => ({
    regex: RegExp(bm(p.val)),
    deser: ([y]) => y,
    literal: !0
  }), g = ((p) => {
    if (r.literal)
      return c(p);
    switch (p.val) {
      case "G":
        return Ae(e.eras("short"), 0);
      case "GG":
        return Ae(e.eras("long"), 0);
      case "y":
        return K(f);
      case "yy":
        return K(d, Ln);
      case "yyyy":
        return K(i);
      case "yyyyy":
        return K(h);
      case "yyyyyy":
        return K(a);
      case "M":
        return K(l);
      case "MM":
        return K(n);
      case "MMM":
        return Ae(e.months("short", !0), 1);
      case "MMMM":
        return Ae(e.months("long", !0), 1);
      case "L":
        return K(l);
      case "LL":
        return K(n);
      case "LLL":
        return Ae(e.months("short", !1), 1);
      case "LLLL":
        return Ae(e.months("long", !1), 1);
      case "d":
        return K(l);
      case "dd":
        return K(n);
      case "o":
        return K(o);
      case "ooo":
        return K(s);
      case "HH":
        return K(n);
      case "H":
        return K(l);
      case "hh":
        return K(n);
      case "h":
        return K(l);
      case "mm":
        return K(n);
      case "m":
        return K(l);
      case "q":
        return K(l);
      case "qq":
        return K(n);
      case "s":
        return K(l);
      case "ss":
        return K(n);
      case "S":
        return K(o);
      case "SSS":
        return K(s);
      case "u":
        return yr(u);
      case "uu":
        return yr(l);
      case "uuu":
        return K(t);
      case "a":
        return Ae(e.meridiems(), 0);
      case "kkkk":
        return K(i);
      case "kk":
        return K(d, Ln);
      case "W":
        return K(l);
      case "WW":
        return K(n);
      case "E":
      case "c":
        return K(t);
      case "EEE":
        return Ae(e.weekdays("short", !1), 1);
      case "EEEE":
        return Ae(e.weekdays("long", !1), 1);
      case "ccc":
        return Ae(e.weekdays("short", !0), 1);
      case "cccc":
        return Ae(e.weekdays("long", !0), 1);
      case "Z":
      case "ZZ":
        return ui(new RegExp(`([+-]${l.source})(?::(${n.source}))?`), 2);
      case "ZZZ":
        return ui(new RegExp(`([+-]${l.source})(${n.source})?`), 2);
      case "z":
        return yr(/[a-z_+-/]{1,256}?/i);
      case " ":
        return yr(/[^\S\n\r]/);
      default:
        return c(p);
    }
  })(r) || {
    invalidReason: gm
  };
  return g.token = r, g;
}
const wm = {
  year: {
    "2-digit": "yy",
    numeric: "yyyyy"
  },
  month: {
    numeric: "M",
    "2-digit": "MM",
    short: "MMM",
    long: "MMMM"
  },
  day: {
    numeric: "d",
    "2-digit": "dd"
  },
  weekday: {
    short: "EEE",
    long: "EEEE"
  },
  dayperiod: "a",
  dayPeriod: "a",
  hour12: {
    numeric: "h",
    "2-digit": "hh"
  },
  hour24: {
    numeric: "H",
    "2-digit": "HH"
  },
  minute: {
    numeric: "m",
    "2-digit": "mm"
  },
  second: {
    numeric: "s",
    "2-digit": "ss"
  },
  timeZoneName: {
    long: "ZZZZZ",
    short: "ZZZ"
  }
};
function km(r, e, t) {
  const {
    type: n,
    value: s
  } = r;
  if (n === "literal") {
    const o = /^\s+$/.test(s);
    return {
      literal: !o,
      val: o ? " " : s
    };
  }
  const i = e[n];
  let a = n;
  n === "hour" && (e.hour12 != null ? a = e.hour12 ? "hour12" : "hour24" : e.hourCycle != null ? e.hourCycle === "h11" || e.hourCycle === "h12" ? a = "hour12" : a = "hour24" : a = t.hour12 ? "hour12" : "hour24");
  let l = wm[a];
  if (typeof l == "object" && (l = l[i]), l)
    return {
      literal: !1,
      val: l
    };
}
function Om(r) {
  return [`^${r.map((t) => t.regex).reduce((t, n) => `${t}(${n.source})`, "")}$`, r];
}
function Sm(r, e, t) {
  const n = r.match(e);
  if (n) {
    const s = {};
    let i = 1;
    for (const a in t)
      if (Et(t, a)) {
        const l = t[a], o = l.groups ? l.groups + 1 : 1;
        !l.literal && l.token && (s[l.token.val[0]] = l.deser(n.slice(i, i + o))), i += o;
      }
    return [n, s];
  } else
    return [n, {}];
}
function Tm(r) {
  const e = (i) => {
    switch (i) {
      case "S":
        return "millisecond";
      case "s":
        return "second";
      case "m":
        return "minute";
      case "h":
      case "H":
        return "hour";
      case "d":
        return "day";
      case "o":
        return "ordinal";
      case "L":
      case "M":
        return "month";
      case "y":
        return "year";
      case "E":
      case "c":
        return "weekday";
      case "W":
        return "weekNumber";
      case "k":
        return "weekYear";
      case "q":
        return "quarter";
      default:
        return null;
    }
  };
  let t = null, n;
  return x(r.z) || (t = je.create(r.z)), x(r.Z) || (t || (t = new ye(r.Z)), n = r.Z), x(r.q) || (r.M = (r.q - 1) * 3 + 1), x(r.h) || (r.h < 12 && r.a === 1 ? r.h += 12 : r.h === 12 && r.a === 0 && (r.h = 0)), r.G === 0 && r.y && (r.y = -r.y), x(r.u) || (r.S = Qn(r.u)), [Object.keys(r).reduce((i, a) => {
    const l = e(a);
    return l && (i[l] = r[a]), i;
  }, {}), t, n];
}
let sn = null;
function Em() {
  return sn || (sn = P.fromMillis(1555555555555)), sn;
}
function Fm(r, e) {
  if (r.literal)
    return r;
  const t = ge.macroTokenToFormatOpts(r.val), n = qo(t, e);
  return n == null || n.includes(void 0) ? r : n;
}
function Po(r, e) {
  return Array.prototype.concat(...r.map((t) => Fm(t, e)));
}
class Ro {
  constructor(e, t) {
    if (this.locale = e, this.format = t, this.tokens = Po(ge.parseFormat(t), e), this.units = this.tokens.map((n) => vm(n, e)), this.disqualifyingUnit = this.units.find((n) => n.invalidReason), !this.disqualifyingUnit) {
      const [n, s] = Om(this.units);
      this.regex = RegExp(n, "i"), this.handlers = s;
    }
  }
  explainFromTokens(e) {
    if (this.isValid) {
      const [t, n] = Sm(e, this.regex, this.handlers), [s, i, a] = n ? Tm(n) : [null, null, void 0];
      if (Et(n, "a") && Et(n, "H"))
        throw new wt("Can't include meridiem when specifying 24-hour format");
      return {
        input: e,
        tokens: this.tokens,
        regex: this.regex,
        rawMatches: t,
        matches: n,
        result: s,
        zone: i,
        specificOffset: a
      };
    } else
      return {
        input: e,
        tokens: this.tokens,
        invalidReason: this.invalidReason
      };
  }
  get isValid() {
    return !this.disqualifyingUnit;
  }
  get invalidReason() {
    return this.disqualifyingUnit ? this.disqualifyingUnit.invalidReason : null;
  }
}
function zo(r, e, t) {
  return new Ro(r, t).explainFromTokens(e);
}
function Dm(r, e, t) {
  const {
    result: n,
    zone: s,
    specificOffset: i,
    invalidReason: a
  } = zo(r, e, t);
  return [n, s, i, a];
}
function qo(r, e) {
  if (!r)
    return null;
  const n = ge.create(e, r).dtFormatter(Em()), s = n.formatToParts(), i = n.resolvedOptions();
  return s.map((a) => km(a, r, i));
}
const an = "Invalid DateTime", fi = 864e13;
function Zt(r) {
  return new Ue("unsupported zone", `the zone "${r.name}" is not supported`);
}
function on(r) {
  return r.weekData === null && (r.weekData = Ar(r.c)), r.weekData;
}
function ln(r) {
  return r.localWeekData === null && (r.localWeekData = Ar(r.c, r.loc.getMinDaysInFirstWeek(), r.loc.getStartOfWeek())), r.localWeekData;
}
function it(r, e) {
  const t = {
    ts: r.ts,
    zone: r.zone,
    c: r.c,
    o: r.o,
    loc: r.loc,
    invalid: r.invalid
  };
  return new P({
    ...t,
    ...e,
    old: t
  });
}
function jo(r, e, t) {
  let n = r - e * 60 * 1e3;
  const s = t.offset(n);
  if (e === s)
    return [n, e];
  n -= (s - e) * 60 * 1e3;
  const i = t.offset(n);
  return s === i ? [n, s] : [r - Math.min(s, i) * 60 * 1e3, Math.max(s, i)];
}
function _r(r, e) {
  r += e * 60 * 1e3;
  const t = new Date(r);
  return {
    year: t.getUTCFullYear(),
    month: t.getUTCMonth() + 1,
    day: t.getUTCDate(),
    hour: t.getUTCHours(),
    minute: t.getUTCMinutes(),
    second: t.getUTCSeconds(),
    millisecond: t.getUTCMilliseconds()
  };
}
function kr(r, e, t) {
  return jo($r(r), e, t);
}
function ci(r, e) {
  const t = r.o, n = r.c.year + Math.trunc(e.years), s = r.c.month + Math.trunc(e.months) + Math.trunc(e.quarters) * 3, i = {
    ...r.c,
    year: n,
    month: s,
    day: Math.min(r.c.day, Wr(n, s)) + Math.trunc(e.days) + Math.trunc(e.weeks) * 7
  }, a = J.fromObject({
    years: e.years - Math.trunc(e.years),
    quarters: e.quarters - Math.trunc(e.quarters),
    months: e.months - Math.trunc(e.months),
    weeks: e.weeks - Math.trunc(e.weeks),
    days: e.days - Math.trunc(e.days),
    hours: e.hours,
    minutes: e.minutes,
    seconds: e.seconds,
    milliseconds: e.milliseconds
  }).as("milliseconds"), l = $r(i);
  let [o, f] = jo(l, t, r.zone);
  return a !== 0 && (o += a, f = r.zone.offset(o)), {
    ts: o,
    o: f
  };
}
function _t(r, e, t, n, s, i) {
  const {
    setZone: a,
    zone: l
  } = t;
  if (r && Object.keys(r).length !== 0 || e) {
    const o = e || l, f = P.fromObject(r, {
      ...t,
      zone: o,
      specificOffset: i
    });
    return a ? f : f.setZone(l);
  } else
    return P.invalid(new Ue("unparsable", `the input "${s}" can't be parsed as ${n}`));
}
function br(r, e, t = !0) {
  return r.isValid ? ge.create(Q.create("en-US"), {
    allowZ: t,
    forceSimple: !0
  }).formatDateTimeFromString(r, e) : null;
}
function un(r, e, t) {
  const n = r.c.year > 9999 || r.c.year < 0;
  let s = "";
  if (n && r.c.year >= 0 && (s += "+"), s += oe(r.c.year, n ? 6 : 4), t === "year")
    return s;
  if (e) {
    if (s += "-", s += oe(r.c.month), t === "month")
      return s;
    s += "-";
  } else if (s += oe(r.c.month), t === "month")
    return s;
  return s += oe(r.c.day), s;
}
function di(r, e, t, n, s, i, a) {
  let l = !t || r.c.millisecond !== 0 || r.c.second !== 0, o = "";
  switch (a) {
    case "day":
    case "month":
    case "year":
      break;
    default:
      if (o += oe(r.c.hour), a === "hour")
        break;
      if (e) {
        if (o += ":", o += oe(r.c.minute), a === "minute")
          break;
        l && (o += ":", o += oe(r.c.second));
      } else {
        if (o += oe(r.c.minute), a === "minute")
          break;
        l && (o += oe(r.c.second));
      }
      if (a === "second")
        break;
      l && (!n || r.c.millisecond !== 0) && (o += ".", o += oe(r.c.millisecond, 3));
  }
  return s && (r.isOffsetFixed && r.offset === 0 && !i ? o += "Z" : r.o < 0 ? (o += "-", o += oe(Math.trunc(-r.o / 60)), o += ":", o += oe(Math.trunc(-r.o % 60))) : (o += "+", o += oe(Math.trunc(r.o / 60)), o += ":", o += oe(Math.trunc(r.o % 60)))), i && (o += "[" + r.zone.ianaName + "]"), o;
}
const $o = {
  month: 1,
  day: 1,
  hour: 0,
  minute: 0,
  second: 0,
  millisecond: 0
}, Mm = {
  weekNumber: 1,
  weekday: 1,
  hour: 0,
  minute: 0,
  second: 0,
  millisecond: 0
}, Nm = {
  ordinal: 1,
  hour: 0,
  minute: 0,
  second: 0,
  millisecond: 0
}, Or = ["year", "month", "day", "hour", "minute", "second", "millisecond"], Cm = ["weekYear", "weekNumber", "weekday", "hour", "minute", "second", "millisecond"], Lm = ["year", "ordinal", "hour", "minute", "second", "millisecond"];
function Sr(r) {
  const e = {
    year: "year",
    years: "year",
    month: "month",
    months: "month",
    day: "day",
    days: "day",
    hour: "hour",
    hours: "hour",
    minute: "minute",
    minutes: "minute",
    quarter: "quarter",
    quarters: "quarter",
    second: "second",
    seconds: "second",
    millisecond: "millisecond",
    milliseconds: "millisecond",
    weekday: "weekday",
    weekdays: "weekday",
    weeknumber: "weekNumber",
    weeksnumber: "weekNumber",
    weeknumbers: "weekNumber",
    weekyear: "weekYear",
    weekyears: "weekYear",
    ordinal: "ordinal"
  }[r.toLowerCase()];
  if (!e)
    throw new qa(r);
  return e;
}
function hi(r) {
  switch (r.toLowerCase()) {
    case "localweekday":
    case "localweekdays":
      return "localWeekday";
    case "localweeknumber":
    case "localweeknumbers":
      return "localWeekNumber";
    case "localweekyear":
    case "localweekyears":
      return "localWeekYear";
    default:
      return Sr(r);
  }
}
function Vm(r) {
  if (Ht === void 0 && (Ht = ne.now()), r.type !== "iana")
    return r.offset(Ht);
  const e = r.name;
  let t = Vn.get(e);
  return t === void 0 && (t = r.offset(Ht), Vn.set(e, t)), t;
}
function mi(r, e) {
  const t = Ke(e.zone, ne.defaultZone);
  if (!t.isValid)
    return P.invalid(Zt(t));
  const n = Q.fromObject(e);
  let s, i;
  if (x(r.year))
    s = ne.now();
  else {
    for (const o of Or)
      x(r[o]) && (r[o] = $o[o]);
    const a = go(r) || yo(r);
    if (a)
      return P.invalid(a);
    const l = Vm(t);
    [s, i] = kr(r, l, t);
  }
  return new P({
    ts: s,
    zone: t,
    loc: n,
    o: i
  });
}
function pi(r, e, t) {
  const n = x(t.round) ? !0 : t.round, s = x(t.rounding) ? "trunc" : t.rounding, i = (l, o) => (l = Xn(l, n || t.calendary ? 0 : 2, t.calendary ? "round" : s), e.loc.clone(t).relFormatter(t).format(l, o)), a = (l) => t.calendary ? e.hasSame(r, l) ? 0 : e.startOf(l).diff(r.startOf(l), l).get(l) : e.diff(r, l).get(l);
  if (t.unit)
    return i(a(t.unit), t.unit);
  for (const l of t.units) {
    const o = a(l);
    if (Math.abs(o) >= 1)
      return i(o, l);
  }
  return i(r > e ? -0 : 0, t.units[t.units.length - 1]);
}
function gi(r) {
  let e = {}, t;
  return r.length > 0 && typeof r[r.length - 1] == "object" ? (e = r[r.length - 1], t = Array.from(r).slice(0, r.length - 1)) : t = Array.from(r), [e, t];
}
let Ht;
const Vn = /* @__PURE__ */ new Map();
class P {
  /**
   * @access private
   */
  constructor(e) {
    const t = e.zone || ne.defaultZone;
    let n = e.invalid || (Number.isNaN(e.ts) ? new Ue("invalid input") : null) || (t.isValid ? null : Zt(t));
    this.ts = x(e.ts) ? ne.now() : e.ts;
    let s = null, i = null;
    if (!n)
      if (e.old && e.old.ts === this.ts && e.old.zone.equals(t))
        [s, i] = [e.old.c, e.old.o];
      else {
        const l = Qe(e.o) && !e.old ? e.o : t.offset(this.ts);
        s = _r(this.ts, l), n = Number.isNaN(s.year) ? new Ue("invalid input") : null, s = n ? null : s, i = n ? null : l;
      }
    this._zone = t, this.loc = e.loc || Q.create(), this.invalid = n, this.weekData = null, this.localWeekData = null, this.c = s, this.o = i, this.isLuxonDateTime = !0;
  }
  // CONSTRUCT
  /**
   * Create a DateTime for the current instant, in the system's time zone.
   *
   * Use Settings to override these default values if needed.
   * @example DateTime.now().toISO() //~> now in the ISO format
   * @return {DateTime}
   */
  static now() {
    return new P({});
  }
  /**
   * Create a local DateTime
   * @param {number} [year] - The calendar year. If omitted (as in, call `local()` with no arguments), the current time will be used
   * @param {number} [month=1] - The month, 1-indexed
   * @param {number} [day=1] - The day of the month, 1-indexed
   * @param {number} [hour=0] - The hour of the day, in 24-hour time
   * @param {number} [minute=0] - The minute of the hour, meaning a number between 0 and 59
   * @param {number} [second=0] - The second of the minute, meaning a number between 0 and 59
   * @param {number} [millisecond=0] - The millisecond of the second, meaning a number between 0 and 999
   * @example DateTime.local()                                  //~> now
   * @example DateTime.local({ zone: "America/New_York" })      //~> now, in US east coast time
   * @example DateTime.local(2017)                              //~> 2017-01-01T00:00:00
   * @example DateTime.local(2017, 3)                           //~> 2017-03-01T00:00:00
   * @example DateTime.local(2017, 3, 12, { locale: "fr" })     //~> 2017-03-12T00:00:00, with a French locale
   * @example DateTime.local(2017, 3, 12, 5)                    //~> 2017-03-12T05:00:00
   * @example DateTime.local(2017, 3, 12, 5, { zone: "utc" })   //~> 2017-03-12T05:00:00, in UTC
   * @example DateTime.local(2017, 3, 12, 5, 45)                //~> 2017-03-12T05:45:00
   * @example DateTime.local(2017, 3, 12, 5, 45, 10)            //~> 2017-03-12T05:45:10
   * @example DateTime.local(2017, 3, 12, 5, 45, 10, 765)       //~> 2017-03-12T05:45:10.765
   * @return {DateTime}
   */
  static local() {
    const [e, t] = gi(arguments), [n, s, i, a, l, o, f] = t;
    return mi({
      year: n,
      month: s,
      day: i,
      hour: a,
      minute: l,
      second: o,
      millisecond: f
    }, e);
  }
  /**
   * Create a DateTime in UTC
   * @param {number} [year] - The calendar year. If omitted (as in, call `utc()` with no arguments), the current time will be used
   * @param {number} [month=1] - The month, 1-indexed
   * @param {number} [day=1] - The day of the month
   * @param {number} [hour=0] - The hour of the day, in 24-hour time
   * @param {number} [minute=0] - The minute of the hour, meaning a number between 0 and 59
   * @param {number} [second=0] - The second of the minute, meaning a number between 0 and 59
   * @param {number} [millisecond=0] - The millisecond of the second, meaning a number between 0 and 999
   * @param {Object} options - configuration options for the DateTime
   * @param {string} [options.locale] - a locale to set on the resulting DateTime instance
   * @param {string} [options.outputCalendar] - the output calendar to set on the resulting DateTime instance
   * @param {string} [options.numberingSystem] - the numbering system to set on the resulting DateTime instance
   * @param {string} [options.weekSettings] - the week settings to set on the resulting DateTime instance
   * @example DateTime.utc()                                              //~> now
   * @example DateTime.utc(2017)                                          //~> 2017-01-01T00:00:00Z
   * @example DateTime.utc(2017, 3)                                       //~> 2017-03-01T00:00:00Z
   * @example DateTime.utc(2017, 3, 12)                                   //~> 2017-03-12T00:00:00Z
   * @example DateTime.utc(2017, 3, 12, 5)                                //~> 2017-03-12T05:00:00Z
   * @example DateTime.utc(2017, 3, 12, 5, 45)                            //~> 2017-03-12T05:45:00Z
   * @example DateTime.utc(2017, 3, 12, 5, 45, { locale: "fr" })          //~> 2017-03-12T05:45:00Z with a French locale
   * @example DateTime.utc(2017, 3, 12, 5, 45, 10)                        //~> 2017-03-12T05:45:10Z
   * @example DateTime.utc(2017, 3, 12, 5, 45, 10, 765, { locale: "fr" }) //~> 2017-03-12T05:45:10.765Z with a French locale
   * @return {DateTime}
   */
  static utc() {
    const [e, t] = gi(arguments), [n, s, i, a, l, o, f] = t;
    return e.zone = ye.utcInstance, mi({
      year: n,
      month: s,
      day: i,
      hour: a,
      minute: l,
      second: o,
      millisecond: f
    }, e);
  }
  /**
   * Create a DateTime from a JavaScript Date object. Uses the default zone.
   * @param {Date} date - a JavaScript Date object
   * @param {Object} options - configuration options for the DateTime
   * @param {string|Zone} [options.zone='local'] - the zone to place the DateTime into
   * @return {DateTime}
   */
  static fromJSDate(e, t = {}) {
    const n = ch(e) ? e.valueOf() : NaN;
    if (Number.isNaN(n))
      return P.invalid("invalid input");
    const s = Ke(t.zone, ne.defaultZone);
    return s.isValid ? new P({
      ts: n,
      zone: s,
      loc: Q.fromObject(t)
    }) : P.invalid(Zt(s));
  }
  /**
   * Create a DateTime from a number of milliseconds since the epoch (meaning since 1 January 1970 00:00:00 UTC). Uses the default zone.
   * @param {number} milliseconds - a number of milliseconds since 1970 UTC
   * @param {Object} options - configuration options for the DateTime
   * @param {string|Zone} [options.zone='local'] - the zone to place the DateTime into
   * @param {string} [options.locale] - a locale to set on the resulting DateTime instance
   * @param {string} options.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} options.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} options.weekSettings - the week settings to set on the resulting DateTime instance
   * @return {DateTime}
   */
  static fromMillis(e, t = {}) {
    if (Qe(e))
      return e < -fi || e > fi ? P.invalid("Timestamp out of range") : new P({
        ts: e,
        zone: Ke(t.zone, ne.defaultZone),
        loc: Q.fromObject(t)
      });
    throw new me(`fromMillis requires a numerical input, but received a ${typeof e} with value ${e}`);
  }
  /**
   * Create a DateTime from a number of seconds since the epoch (meaning since 1 January 1970 00:00:00 UTC). Uses the default zone.
   * @param {number} seconds - a number of seconds since 1970 UTC
   * @param {Object} options - configuration options for the DateTime
   * @param {string|Zone} [options.zone='local'] - the zone to place the DateTime into
   * @param {string} [options.locale] - a locale to set on the resulting DateTime instance
   * @param {string} options.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} options.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} options.weekSettings - the week settings to set on the resulting DateTime instance
   * @return {DateTime}
   */
  static fromSeconds(e, t = {}) {
    if (Qe(e))
      return new P({
        ts: e * 1e3,
        zone: Ke(t.zone, ne.defaultZone),
        loc: Q.fromObject(t)
      });
    throw new me("fromSeconds requires a numerical input");
  }
  /**
   * Create a DateTime from a JavaScript object with keys like 'year' and 'hour' with reasonable defaults.
   * @param {Object} obj - the object to create the DateTime from
   * @param {number} obj.year - a year, such as 1987
   * @param {number} obj.month - a month, 1-12
   * @param {number} obj.day - a day of the month, 1-31, depending on the month
   * @param {number} obj.ordinal - day of the year, 1-365 or 366
   * @param {number} obj.weekYear - an ISO week year
   * @param {number} obj.weekNumber - an ISO week number, between 1 and 52 or 53, depending on the year
   * @param {number} obj.weekday - an ISO weekday, 1-7, where 1 is Monday and 7 is Sunday
   * @param {number} obj.localWeekYear - a week year, according to the locale
   * @param {number} obj.localWeekNumber - a week number, between 1 and 52 or 53, depending on the year, according to the locale
   * @param {number} obj.localWeekday - a weekday, 1-7, where 1 is the first and 7 is the last day of the week, according to the locale
   * @param {number} obj.hour - hour of the day, 0-23
   * @param {number} obj.minute - minute of the hour, 0-59
   * @param {number} obj.second - second of the minute, 0-59
   * @param {number} obj.millisecond - millisecond of the second, 0-999
   * @param {Object} opts - options for creating this DateTime
   * @param {string|Zone} [opts.zone='local'] - interpret the numbers in the context of a particular zone. Can take any value taken as the first argument to setZone()
   * @param {string} [opts.locale='system\'s locale'] - a locale to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} opts.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromObject({ year: 1982, month: 5, day: 25}).toISODate() //=> '1982-05-25'
   * @example DateTime.fromObject({ year: 1982 }).toISODate() //=> '1982-01-01'
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }) //~> today at 10:26:06
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }, { zone: 'utc' }),
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }, { zone: 'local' })
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }, { zone: 'America/New_York' })
   * @example DateTime.fromObject({ weekYear: 2016, weekNumber: 2, weekday: 3 }).toISODate() //=> '2016-01-13'
   * @example DateTime.fromObject({ localWeekYear: 2022, localWeekNumber: 1, localWeekday: 1 }, { locale: "en-US" }).toISODate() //=> '2021-12-26'
   * @return {DateTime}
   */
  static fromObject(e, t = {}) {
    e = e || {};
    const n = Ke(t.zone, ne.defaultZone);
    if (!n.isValid)
      return P.invalid(Zt(n));
    const s = Q.fromObject(t), i = Ur(e, hi), {
      minDaysInFirstWeek: a,
      startOfWeek: l
    } = Xs(i, s), o = ne.now(), f = x(t.specificOffset) ? n.offset(o) : t.specificOffset, u = !x(i.ordinal), d = !x(i.year), h = !x(i.month) || !x(i.day), c = d || h, m = i.weekYear || i.weekNumber;
    if ((c || u) && m)
      throw new wt("Can't mix weekYear/weekNumber units with year/month/day or ordinals");
    if (h && u)
      throw new wt("Can't mix ordinal dates with month/day");
    const g = m || i.weekday && !c;
    let p, y, b = _r(o, f);
    g ? (p = Cm, y = Mm, b = Ar(b, a, l)) : u ? (p = Lm, y = Nm, b = nn(b)) : (p = Or, y = $o);
    let v = !1;
    for (const H of p) {
      const G = i[H];
      x(G) ? v ? i[H] = y[H] : i[H] = b[H] : v = !0;
    }
    const k = g ? lh(i, a, l) : u ? uh(i) : go(i), S = k || yo(i);
    if (S)
      return P.invalid(S);
    const E = g ? Ks(i, a, l) : u ? Qs(i) : i, [A, N] = kr(E, f, n), Z = new P({
      ts: A,
      zone: n,
      o: N,
      loc: s
    });
    return i.weekday && c && e.weekday !== Z.weekday ? P.invalid("mismatched weekday", `you can't specify both a weekday of ${i.weekday} and a date of ${Z.toISO()}`) : Z.isValid ? Z : P.invalid(Z.invalid);
  }
  /**
   * Create a DateTime from an ISO 8601 string
   * @param {string} text - the ISO string
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - use this zone if no offset is specified in the input string itself. Will also convert the time to this zone
   * @param {boolean} [opts.setZone=false] - override the zone with a fixed-offset zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='system's locale'] - a locale to set on the resulting DateTime instance
   * @param {string} [opts.outputCalendar] - the output calendar to set on the resulting DateTime instance
   * @param {string} [opts.numberingSystem] - the numbering system to set on the resulting DateTime instance
   * @param {string} [opts.weekSettings] - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromISO('2016-05-25T09:08:34.123')
   * @example DateTime.fromISO('2016-05-25T09:08:34.123+06:00')
   * @example DateTime.fromISO('2016-05-25T09:08:34.123+06:00', {setZone: true})
   * @example DateTime.fromISO('2016-05-25T09:08:34.123', {zone: 'utc'})
   * @example DateTime.fromISO('2016-W05-4')
   * @return {DateTime}
   */
  static fromISO(e, t = {}) {
    const [n, s] = em(e);
    return _t(n, s, t, "ISO 8601", e);
  }
  /**
   * Create a DateTime from an RFC 2822 string
   * @param {string} text - the RFC 2822 string
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - convert the time to this zone. Since the offset is always specified in the string itself, this has no effect on the interpretation of string, merely the zone the resulting DateTime is expressed in.
   * @param {boolean} [opts.setZone=false] - override the zone with a fixed-offset zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='system's locale'] - a locale to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} opts.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromRFC2822('25 Nov 2016 13:23:12 GMT')
   * @example DateTime.fromRFC2822('Fri, 25 Nov 2016 13:23:12 +0600')
   * @example DateTime.fromRFC2822('25 Nov 2016 13:23 Z')
   * @return {DateTime}
   */
  static fromRFC2822(e, t = {}) {
    const [n, s] = tm(e);
    return _t(n, s, t, "RFC 2822", e);
  }
  /**
   * Create a DateTime from an HTTP header date
   * @see https://www.w3.org/Protocols/rfc2616/rfc2616-sec3.html#sec3.3.1
   * @param {string} text - the HTTP header date
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - convert the time to this zone. Since HTTP dates are always in UTC, this has no effect on the interpretation of string, merely the zone the resulting DateTime is expressed in.
   * @param {boolean} [opts.setZone=false] - override the zone with the fixed-offset zone specified in the string. For HTTP dates, this is always UTC, so this option is equivalent to setting the `zone` option to 'utc', but this option is included for consistency with similar methods.
   * @param {string} [opts.locale='system's locale'] - a locale to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} opts.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromHTTP('Sun, 06 Nov 1994 08:49:37 GMT')
   * @example DateTime.fromHTTP('Sunday, 06-Nov-94 08:49:37 GMT')
   * @example DateTime.fromHTTP('Sun Nov  6 08:49:37 1994')
   * @return {DateTime}
   */
  static fromHTTP(e, t = {}) {
    const [n, s] = rm(e);
    return _t(n, s, t, "HTTP", t);
  }
  /**
   * Create a DateTime from an input string and format string.
   * Defaults to en-US if no locale has been specified, regardless of the system's locale. For a table of tokens and their interpretations, see [here](https://moment.github.io/luxon/#/parsing?id=table-of-tokens).
   * @param {string} text - the string to parse
   * @param {string} fmt - the format the string is expected to be in (see the link below for the formats)
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - use this zone if no offset is specified in the input string itself. Will also convert the DateTime to this zone
   * @param {boolean} [opts.setZone=false] - override the zone with a zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='en-US'] - a locale string to use when parsing. Will also set the DateTime to this locale
   * @param {string} opts.numberingSystem - the numbering system to use when parsing. Will also set the resulting DateTime to this numbering system
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @return {DateTime}
   */
  static fromFormat(e, t, n = {}) {
    if (x(e) || x(t))
      throw new me("fromFormat requires an input string and a format");
    const {
      locale: s = null,
      numberingSystem: i = null
    } = n, a = Q.fromOpts({
      locale: s,
      numberingSystem: i,
      defaultToEN: !0
    }), [l, o, f, u] = Dm(a, e, t);
    return u ? P.invalid(u) : _t(l, o, n, `format ${t}`, e, f);
  }
  /**
   * @deprecated use fromFormat instead
   */
  static fromString(e, t, n = {}) {
    return P.fromFormat(e, t, n);
  }
  /**
   * Create a DateTime from a SQL date, time, or datetime
   * Defaults to en-US if no locale has been specified, regardless of the system's locale
   * @param {string} text - the string to parse
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - use this zone if no offset is specified in the input string itself. Will also convert the DateTime to this zone
   * @param {boolean} [opts.setZone=false] - override the zone with a zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='en-US'] - a locale string to use when parsing. Will also set the DateTime to this locale
   * @param {string} opts.numberingSystem - the numbering system to use when parsing. Will also set the resulting DateTime to this numbering system
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @example DateTime.fromSQL('2017-05-15')
   * @example DateTime.fromSQL('2017-05-15 09:12:34')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342+06:00')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342 America/Los_Angeles')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342 America/Los_Angeles', { setZone: true })
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342', { zone: 'America/Los_Angeles' })
   * @example DateTime.fromSQL('09:12:34.342')
   * @return {DateTime}
   */
  static fromSQL(e, t = {}) {
    const [n, s] = um(e);
    return _t(n, s, t, "SQL", e);
  }
  /**
   * Create an invalid DateTime.
   * @param {string} reason - simple string of why this DateTime is invalid. Should not contain parameters or anything else data-dependent.
   * @param {string} [explanation=null] - longer explanation, may include parameters and other useful debugging information
   * @return {DateTime}
   */
  static invalid(e, t = null) {
    if (!e)
      throw new me("need to specify a reason the DateTime is invalid");
    const n = e instanceof Ue ? e : new Ue(e, t);
    if (ne.throwOnInvalid)
      throw new Ud(n);
    return new P({
      invalid: n
    });
  }
  /**
   * Check if an object is an instance of DateTime. Works across context boundaries
   * @param {object} o
   * @return {boolean}
   */
  static isDateTime(e) {
    return e && e.isLuxonDateTime || !1;
  }
  /**
   * Produce the format string for a set of options
   * @param formatOpts
   * @param localeOpts
   * @returns {string}
   */
  static parseFormatForOpts(e, t = {}) {
    const n = qo(e, Q.fromObject(t));
    return n ? n.map((s) => s ? s.val : null).join("") : null;
  }
  /**
   * Produce the the fully expanded format token for the locale
   * Does NOT quote characters, so quoted tokens will not round trip correctly
   * @param fmt
   * @param localeOpts
   * @returns {string}
   */
  static expandFormat(e, t = {}) {
    return Po(ge.parseFormat(e), Q.fromObject(t)).map((s) => s.val).join("");
  }
  static resetCache() {
    Ht = void 0, Vn.clear();
  }
  // INFO
  /**
   * Get the value of unit.
   * @param {string} unit - a unit such as 'minute' or 'day'
   * @example DateTime.local(2017, 7, 4).get('month'); //=> 7
   * @example DateTime.local(2017, 7, 4).get('day'); //=> 4
   * @return {number}
   */
  get(e) {
    return this[e];
  }
  /**
   * Returns whether the DateTime is valid. Invalid DateTimes occur when:
   * * The DateTime was created from invalid calendar information, such as the 13th month or February 30
   * * The DateTime was created by an operation on another invalid date
   * @type {boolean}
   */
  get isValid() {
    return this.invalid === null;
  }
  /**
   * Returns an error code if this DateTime is invalid, or null if the DateTime is valid
   * @type {string}
   */
  get invalidReason() {
    return this.invalid ? this.invalid.reason : null;
  }
  /**
   * Returns an explanation of why this DateTime became invalid, or null if the DateTime is valid
   * @type {string}
   */
  get invalidExplanation() {
    return this.invalid ? this.invalid.explanation : null;
  }
  /**
   * Get the locale of a DateTime, such 'en-GB'. The locale is used when formatting the DateTime
   *
   * @type {string}
   */
  get locale() {
    return this.isValid ? this.loc.locale : null;
  }
  /**
   * Get the numbering system of a DateTime, such 'beng'. The numbering system is used when formatting the DateTime
   *
   * @type {string}
   */
  get numberingSystem() {
    return this.isValid ? this.loc.numberingSystem : null;
  }
  /**
   * Get the output calendar of a DateTime, such 'islamic'. The output calendar is used when formatting the DateTime
   *
   * @type {string}
   */
  get outputCalendar() {
    return this.isValid ? this.loc.outputCalendar : null;
  }
  /**
   * Get the time zone associated with this DateTime.
   * @type {Zone}
   */
  get zone() {
    return this._zone;
  }
  /**
   * Get the name of the time zone.
   * @type {string}
   */
  get zoneName() {
    return this.isValid ? this.zone.name : null;
  }
  /**
   * Get the year
   * @example DateTime.local(2017, 5, 25).year //=> 2017
   * @type {number}
   */
  get year() {
    return this.isValid ? this.c.year : NaN;
  }
  /**
   * Get the quarter
   * @example DateTime.local(2017, 5, 25).quarter //=> 2
   * @type {number}
   */
  get quarter() {
    return this.isValid ? Math.ceil(this.c.month / 3) : NaN;
  }
  /**
   * Get the month (1-12).
   * @example DateTime.local(2017, 5, 25).month //=> 5
   * @type {number}
   */
  get month() {
    return this.isValid ? this.c.month : NaN;
  }
  /**
   * Get the day of the month (1-30ish).
   * @example DateTime.local(2017, 5, 25).day //=> 25
   * @type {number}
   */
  get day() {
    return this.isValid ? this.c.day : NaN;
  }
  /**
   * Get the hour of the day (0-23).
   * @example DateTime.local(2017, 5, 25, 9).hour //=> 9
   * @type {number}
   */
  get hour() {
    return this.isValid ? this.c.hour : NaN;
  }
  /**
   * Get the minute of the hour (0-59).
   * @example DateTime.local(2017, 5, 25, 9, 30).minute //=> 30
   * @type {number}
   */
  get minute() {
    return this.isValid ? this.c.minute : NaN;
  }
  /**
   * Get the second of the minute (0-59).
   * @example DateTime.local(2017, 5, 25, 9, 30, 52).second //=> 52
   * @type {number}
   */
  get second() {
    return this.isValid ? this.c.second : NaN;
  }
  /**
   * Get the millisecond of the second (0-999).
   * @example DateTime.local(2017, 5, 25, 9, 30, 52, 654).millisecond //=> 654
   * @type {number}
   */
  get millisecond() {
    return this.isValid ? this.c.millisecond : NaN;
  }
  /**
   * Get the week year
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2014, 12, 31).weekYear //=> 2015
   * @type {number}
   */
  get weekYear() {
    return this.isValid ? on(this).weekYear : NaN;
  }
  /**
   * Get the week number of the week year (1-52ish).
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2017, 5, 25).weekNumber //=> 21
   * @type {number}
   */
  get weekNumber() {
    return this.isValid ? on(this).weekNumber : NaN;
  }
  /**
   * Get the day of the week.
   * 1 is Monday and 7 is Sunday
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2014, 11, 31).weekday //=> 4
   * @type {number}
   */
  get weekday() {
    return this.isValid ? on(this).weekday : NaN;
  }
  /**
   * Returns true if this date is on a weekend according to the locale, false otherwise
   * @returns {boolean}
   */
  get isWeekend() {
    return this.isValid && this.loc.getWeekendDays().includes(this.weekday);
  }
  /**
   * Get the day of the week according to the locale.
   * 1 is the first day of the week and 7 is the last day of the week.
   * If the locale assigns Sunday as the first day of the week, then a date which is a Sunday will return 1,
   * @returns {number}
   */
  get localWeekday() {
    return this.isValid ? ln(this).weekday : NaN;
  }
  /**
   * Get the week number of the week year according to the locale. Different locales assign week numbers differently,
   * because the week can start on different days of the week (see localWeekday) and because a different number of days
   * is required for a week to count as the first week of a year.
   * @returns {number}
   */
  get localWeekNumber() {
    return this.isValid ? ln(this).weekNumber : NaN;
  }
  /**
   * Get the week year according to the locale. Different locales assign week numbers (and therefor week years)
   * differently, see localWeekNumber.
   * @returns {number}
   */
  get localWeekYear() {
    return this.isValid ? ln(this).weekYear : NaN;
  }
  /**
   * Get the ordinal (meaning the day of the year)
   * @example DateTime.local(2017, 5, 25).ordinal //=> 145
   * @type {number|DateTime}
   */
  get ordinal() {
    return this.isValid ? nn(this.c).ordinal : NaN;
  }
  /**
   * Get the human readable short month name, such as 'Oct'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).monthShort //=> Oct
   * @type {string}
   */
  get monthShort() {
    return this.isValid ? $t.months("short", {
      locObj: this.loc
    })[this.month - 1] : null;
  }
  /**
   * Get the human readable long month name, such as 'October'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).monthLong //=> October
   * @type {string}
   */
  get monthLong() {
    return this.isValid ? $t.months("long", {
      locObj: this.loc
    })[this.month - 1] : null;
  }
  /**
   * Get the human readable short weekday, such as 'Mon'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).weekdayShort //=> Mon
   * @type {string}
   */
  get weekdayShort() {
    return this.isValid ? $t.weekdays("short", {
      locObj: this.loc
    })[this.weekday - 1] : null;
  }
  /**
   * Get the human readable long weekday, such as 'Monday'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).weekdayLong //=> Monday
   * @type {string}
   */
  get weekdayLong() {
    return this.isValid ? $t.weekdays("long", {
      locObj: this.loc
    })[this.weekday - 1] : null;
  }
  /**
   * Get the UTC offset of this DateTime in minutes
   * @example DateTime.now().offset //=> -240
   * @example DateTime.utc().offset //=> 0
   * @type {number}
   */
  get offset() {
    return this.isValid ? +this.o : NaN;
  }
  /**
   * Get the short human name for the zone's current offset, for example "EST" or "EDT".
   * Defaults to the system's locale if no locale has been specified
   * @type {string}
   */
  get offsetNameShort() {
    return this.isValid ? this.zone.offsetName(this.ts, {
      format: "short",
      locale: this.locale
    }) : null;
  }
  /**
   * Get the long human name for the zone's current offset, for example "Eastern Standard Time" or "Eastern Daylight Time".
   * Defaults to the system's locale if no locale has been specified
   * @type {string}
   */
  get offsetNameLong() {
    return this.isValid ? this.zone.offsetName(this.ts, {
      format: "long",
      locale: this.locale
    }) : null;
  }
  /**
   * Get whether this zone's offset ever changes, as in a DST.
   * @type {boolean}
   */
  get isOffsetFixed() {
    return this.isValid ? this.zone.isUniversal : null;
  }
  /**
   * Get whether the DateTime is in a DST.
   * @type {boolean}
   */
  get isInDST() {
    return this.isOffsetFixed ? !1 : this.offset > this.set({
      month: 1,
      day: 1
    }).offset || this.offset > this.set({
      month: 5
    }).offset;
  }
  /**
   * Get those DateTimes which have the same local time as this DateTime, but a different offset from UTC
   * in this DateTime's zone. During DST changes local time can be ambiguous, for example
   * `2023-10-29T02:30:00` in `Europe/Berlin` can have offset `+01:00` or `+02:00`.
   * This method will return both possible DateTimes if this DateTime's local time is ambiguous.
   * @returns {DateTime[]}
   */
  getPossibleOffsets() {
    if (!this.isValid || this.isOffsetFixed)
      return [this];
    const e = 864e5, t = 6e4, n = $r(this.c), s = this.zone.offset(n - e), i = this.zone.offset(n + e), a = this.zone.offset(n - s * t), l = this.zone.offset(n - i * t);
    if (a === l)
      return [this];
    const o = n - a * t, f = n - l * t, u = _r(o, a), d = _r(f, l);
    return u.hour === d.hour && u.minute === d.minute && u.second === d.second && u.millisecond === d.millisecond ? [it(this, {
      ts: o
    }), it(this, {
      ts: f
    })] : [this];
  }
  /**
   * Returns true if this DateTime is in a leap year, false otherwise
   * @example DateTime.local(2016).isInLeapYear //=> true
   * @example DateTime.local(2013).isInLeapYear //=> false
   * @type {boolean}
   */
  get isInLeapYear() {
    return er(this.year);
  }
  /**
   * Returns the number of days in this DateTime's month
   * @example DateTime.local(2016, 2).daysInMonth //=> 29
   * @example DateTime.local(2016, 3).daysInMonth //=> 31
   * @type {number}
   */
  get daysInMonth() {
    return Wr(this.year, this.month);
  }
  /**
   * Returns the number of days in this DateTime's year
   * @example DateTime.local(2016).daysInYear //=> 366
   * @example DateTime.local(2013).daysInYear //=> 365
   * @type {number}
   */
  get daysInYear() {
    return this.isValid ? kt(this.year) : NaN;
  }
  /**
   * Returns the number of weeks in this DateTime's year
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2004).weeksInWeekYear //=> 53
   * @example DateTime.local(2013).weeksInWeekYear //=> 52
   * @type {number}
   */
  get weeksInWeekYear() {
    return this.isValid ? Jt(this.weekYear) : NaN;
  }
  /**
   * Returns the number of weeks in this DateTime's local week year
   * @example DateTime.local(2020, 6, {locale: 'en-US'}).weeksInLocalWeekYear //=> 52
   * @example DateTime.local(2020, 6, {locale: 'de-DE'}).weeksInLocalWeekYear //=> 53
   * @type {number}
   */
  get weeksInLocalWeekYear() {
    return this.isValid ? Jt(this.localWeekYear, this.loc.getMinDaysInFirstWeek(), this.loc.getStartOfWeek()) : NaN;
  }
  /**
   * Returns the resolved Intl options for this DateTime.
   * This is useful in understanding the behavior of formatting methods
   * @param {Object} opts - the same options as toLocaleString
   * @return {Object}
   */
  resolvedLocaleOptions(e = {}) {
    const {
      locale: t,
      numberingSystem: n,
      calendar: s
    } = ge.create(this.loc.clone(e), e).resolvedOptions(this);
    return {
      locale: t,
      numberingSystem: n,
      outputCalendar: s
    };
  }
  // TRANSFORM
  /**
   * "Set" the DateTime's zone to UTC. Returns a newly-constructed DateTime.
   *
   * Equivalent to {@link DateTime#setZone}('utc')
   * @param {number} [offset=0] - optionally, an offset from UTC in minutes
   * @param {Object} [opts={}] - options to pass to `setZone()`
   * @return {DateTime}
   */
  toUTC(e = 0, t = {}) {
    return this.setZone(ye.instance(e), t);
  }
  /**
   * "Set" the DateTime's zone to the host's local zone. Returns a newly-constructed DateTime.
   *
   * Equivalent to `setZone('local')`
   * @return {DateTime}
   */
  toLocal() {
    return this.setZone(ne.defaultZone);
  }
  /**
   * "Set" the DateTime's zone to specified zone. Returns a newly-constructed DateTime.
   *
   * By default, the setter keeps the underlying time the same (as in, the same timestamp), but the new instance will report different local times and consider DSTs when making computations, as with {@link DateTime#plus}. You may wish to use {@link DateTime#toLocal} and {@link DateTime#toUTC} which provide simple convenience wrappers for commonly used zones.
   * @param {string|Zone} [zone='local'] - a zone identifier. As a string, that can be any IANA zone supported by the host environment, or a fixed-offset name of the form 'UTC+3', or the strings 'local' or 'utc'. You may also supply an instance of a {@link DateTime#Zone} class.
   * @param {Object} opts - options
   * @param {boolean} [opts.keepLocalTime=false] - If true, adjust the underlying time so that the local time stays the same, but in the target zone. You should rarely need this.
   * @return {DateTime}
   */
  setZone(e, {
    keepLocalTime: t = !1,
    keepCalendarTime: n = !1
  } = {}) {
    if (e = Ke(e, ne.defaultZone), e.equals(this.zone))
      return this;
    if (e.isValid) {
      let s = this.ts;
      if (t || n) {
        const i = e.offset(this.ts), a = this.toObject();
        [s] = kr(a, i, e);
      }
      return it(this, {
        ts: s,
        zone: e
      });
    } else
      return P.invalid(Zt(e));
  }
  /**
   * "Set" the locale, numberingSystem, or outputCalendar. Returns a newly-constructed DateTime.
   * @param {Object} properties - the properties to set
   * @example DateTime.local(2017, 5, 25).reconfigure({ locale: 'en-GB' })
   * @return {DateTime}
   */
  reconfigure({
    locale: e,
    numberingSystem: t,
    outputCalendar: n
  } = {}) {
    const s = this.loc.clone({
      locale: e,
      numberingSystem: t,
      outputCalendar: n
    });
    return it(this, {
      loc: s
    });
  }
  /**
   * "Set" the locale. Returns a newly-constructed DateTime.
   * Just a convenient alias for reconfigure({ locale })
   * @example DateTime.local(2017, 5, 25).setLocale('en-GB')
   * @return {DateTime}
   */
  setLocale(e) {
    return this.reconfigure({
      locale: e
    });
  }
  /**
   * "Set" the values of specified units. Returns a newly-constructed DateTime.
   * You can only set units with this method; for "setting" metadata, see {@link DateTime#reconfigure} and {@link DateTime#setZone}.
   *
   * This method also supports setting locale-based week units, i.e. `localWeekday`, `localWeekNumber` and `localWeekYear`.
   * They cannot be mixed with ISO-week units like `weekday`.
   * @param {Object} values - a mapping of units to numbers
   * @example dt.set({ year: 2017 })
   * @example dt.set({ hour: 8, minute: 30 })
   * @example dt.set({ weekday: 5 })
   * @example dt.set({ year: 2005, ordinal: 234 })
   * @return {DateTime}
   */
  set(e) {
    if (!this.isValid)
      return this;
    const t = Ur(e, hi), {
      minDaysInFirstWeek: n,
      startOfWeek: s
    } = Xs(t, this.loc), i = !x(t.weekYear) || !x(t.weekNumber) || !x(t.weekday), a = !x(t.ordinal), l = !x(t.year), o = !x(t.month) || !x(t.day), f = l || o, u = t.weekYear || t.weekNumber;
    if ((f || a) && u)
      throw new wt("Can't mix weekYear/weekNumber units with year/month/day or ordinals");
    if (o && a)
      throw new wt("Can't mix ordinal dates with month/day");
    let d;
    i ? d = Ks({
      ...Ar(this.c, n, s),
      ...t
    }, n, s) : x(t.ordinal) ? (d = {
      ...this.toObject(),
      ...t
    }, x(t.day) && (d.day = Math.min(Wr(d.year, d.month), d.day))) : d = Qs({
      ...nn(this.c),
      ...t
    });
    const [h, c] = kr(d, this.o, this.zone);
    return it(this, {
      ts: h,
      o: c
    });
  }
  /**
   * Add a period of time to this DateTime and return the resulting DateTime
   *
   * Adding hours, minutes, seconds, or milliseconds increases the timestamp by the right number of milliseconds. Adding days, months, or years shifts the calendar, accounting for DSTs and leap years along the way. Thus, `dt.plus({ hours: 24 })` may result in a different time than `dt.plus({ days: 1 })` if there's a DST shift in between.
   * @param {Duration|Object|number} duration - The amount to add. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   * @example DateTime.now().plus(123) //~> in 123 milliseconds
   * @example DateTime.now().plus({ minutes: 15 }) //~> in 15 minutes
   * @example DateTime.now().plus({ days: 1 }) //~> this time tomorrow
   * @example DateTime.now().plus({ days: -1 }) //~> this time yesterday
   * @example DateTime.now().plus({ hours: 3, minutes: 13 }) //~> in 3 hr, 13 min
   * @example DateTime.now().plus(Duration.fromObject({ hours: 3, minutes: 13 })) //~> in 3 hr, 13 min
   * @return {DateTime}
   */
  plus(e) {
    if (!this.isValid)
      return this;
    const t = J.fromDurationLike(e);
    return it(this, ci(this, t));
  }
  /**
   * Subtract a period of time to this DateTime and return the resulting DateTime
   * See {@link DateTime#plus}
   * @param {Duration|Object|number} duration - The amount to subtract. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   @return {DateTime}
   */
  minus(e) {
    if (!this.isValid)
      return this;
    const t = J.fromDurationLike(e).negate();
    return it(this, ci(this, t));
  }
  /**
   * "Set" this DateTime to the beginning of a unit of time.
   * @param {string} unit - The unit to go to the beginning of. Can be 'year', 'quarter', 'month', 'week', 'day', 'hour', 'minute', 'second', or 'millisecond'.
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week
   * @example DateTime.local(2014, 3, 3).startOf('month').toISODate(); //=> '2014-03-01'
   * @example DateTime.local(2014, 3, 3).startOf('year').toISODate(); //=> '2014-01-01'
   * @example DateTime.local(2014, 3, 3).startOf('week').toISODate(); //=> '2014-03-03', weeks always start on Mondays
   * @example DateTime.local(2014, 3, 3, 5, 30).startOf('day').toISOTime(); //=> '00:00.000-05:00'
   * @example DateTime.local(2014, 3, 3, 5, 30).startOf('hour').toISOTime(); //=> '05:00:00.000-05:00'
   * @return {DateTime}
   */
  startOf(e, {
    useLocaleWeeks: t = !1
  } = {}) {
    if (!this.isValid)
      return this;
    const n = {}, s = J.normalizeUnit(e);
    switch (s) {
      case "years":
        n.month = 1;
      case "quarters":
      case "months":
        n.day = 1;
      case "weeks":
      case "days":
        n.hour = 0;
      case "hours":
        n.minute = 0;
      case "minutes":
        n.second = 0;
      case "seconds":
        n.millisecond = 0;
        break;
    }
    if (s === "weeks")
      if (t) {
        const i = this.loc.getStartOfWeek(), {
          weekday: a
        } = this;
        a < i && (n.weekNumber = this.weekNumber - 1), n.weekday = i;
      } else
        n.weekday = 1;
    if (s === "quarters") {
      const i = Math.ceil(this.month / 3);
      n.month = (i - 1) * 3 + 1;
    }
    return this.set(n);
  }
  /**
   * "Set" this DateTime to the end (meaning the last millisecond) of a unit of time
   * @param {string} unit - The unit to go to the end of. Can be 'year', 'quarter', 'month', 'week', 'day', 'hour', 'minute', 'second', or 'millisecond'.
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week
   * @example DateTime.local(2014, 3, 3).endOf('month').toISO(); //=> '2014-03-31T23:59:59.999-05:00'
   * @example DateTime.local(2014, 3, 3).endOf('year').toISO(); //=> '2014-12-31T23:59:59.999-05:00'
   * @example DateTime.local(2014, 3, 3).endOf('week').toISO(); // => '2014-03-09T23:59:59.999-05:00', weeks start on Mondays
   * @example DateTime.local(2014, 3, 3, 5, 30).endOf('day').toISO(); //=> '2014-03-03T23:59:59.999-05:00'
   * @example DateTime.local(2014, 3, 3, 5, 30).endOf('hour').toISO(); //=> '2014-03-03T05:59:59.999-05:00'
   * @return {DateTime}
   */
  endOf(e, t) {
    return this.isValid ? this.plus({
      [e]: 1
    }).startOf(e, t).minus(1) : this;
  }
  // OUTPUT
  /**
   * Returns a string representation of this DateTime formatted according to the specified format string.
   * **You may not want this.** See {@link DateTime#toLocaleString} for a more flexible formatting tool. For a table of tokens and their interpretations, see [here](https://moment.github.io/luxon/#/formatting?id=table-of-tokens).
   * Defaults to en-US if no locale has been specified, regardless of the system's locale.
   * @param {string} fmt - the format string
   * @param {Object} opts - opts to override the configuration options on this DateTime
   * @example DateTime.now().toFormat('yyyy LLL dd') //=> '2017 Apr 22'
   * @example DateTime.now().setLocale('fr').toFormat('yyyy LLL dd') //=> '2017 avr. 22'
   * @example DateTime.now().toFormat('yyyy LLL dd', { locale: "fr" }) //=> '2017 avr. 22'
   * @example DateTime.now().toFormat("HH 'hours and' mm 'minutes'") //=> '20 hours and 55 minutes'
   * @return {string}
   */
  toFormat(e, t = {}) {
    return this.isValid ? ge.create(this.loc.redefaultToEN(t)).formatDateTimeFromString(this, e) : an;
  }
  /**
   * Returns a localized string representing this date. Accepts the same options as the Intl.DateTimeFormat constructor and any presets defined by Luxon, such as `DateTime.DATE_FULL` or `DateTime.TIME_SIMPLE`.
   * The exact behavior of this method is browser-specific, but in general it will return an appropriate representation
   * of the DateTime in the assigned locale.
   * Defaults to the system's locale if no locale has been specified
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param formatOpts {Object} - Intl.DateTimeFormat constructor options and configuration options
   * @param {Object} opts - opts to override the configuration options on this DateTime
   * @example DateTime.now().toLocaleString(); //=> 4/20/2017
   * @example DateTime.now().setLocale('en-gb').toLocaleString(); //=> '20/04/2017'
   * @example DateTime.now().toLocaleString(DateTime.DATE_FULL); //=> 'April 20, 2017'
   * @example DateTime.now().toLocaleString(DateTime.DATE_FULL, { locale: 'fr' }); //=> '28 août 2022'
   * @example DateTime.now().toLocaleString(DateTime.TIME_SIMPLE); //=> '11:32 AM'
   * @example DateTime.now().toLocaleString(DateTime.DATETIME_SHORT); //=> '4/20/2017, 11:32 AM'
   * @example DateTime.now().toLocaleString({ weekday: 'long', month: 'long', day: '2-digit' }); //=> 'Thursday, April 20'
   * @example DateTime.now().toLocaleString({ weekday: 'short', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }); //=> 'Thu, Apr 20, 11:27 AM'
   * @example DateTime.now().toLocaleString({ hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }); //=> '11:32'
   * @return {string}
   */
  toLocaleString(e = Ir, t = {}) {
    return this.isValid ? ge.create(this.loc.clone(t), e).formatDateTime(this) : an;
  }
  /**
   * Returns an array of format "parts", meaning individual tokens along with metadata. This is allows callers to post-process individual sections of the formatted output.
   * Defaults to the system's locale if no locale has been specified
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat/formatToParts
   * @param opts {Object} - Intl.DateTimeFormat constructor options, same as `toLocaleString`.
   * @example DateTime.now().toLocaleParts(); //=> [
   *                                   //=>   { type: 'day', value: '25' },
   *                                   //=>   { type: 'literal', value: '/' },
   *                                   //=>   { type: 'month', value: '05' },
   *                                   //=>   { type: 'literal', value: '/' },
   *                                   //=>   { type: 'year', value: '1982' }
   *                                   //=> ]
   */
  toLocaleParts(e = {}) {
    return this.isValid ? ge.create(this.loc.clone(e), e).formatDateTimeParts(this) : [];
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime
   * @param {Object} opts - options
   * @param {boolean} [opts.suppressMilliseconds=false] - exclude milliseconds from the format if they're 0
   * @param {boolean} [opts.suppressSeconds=false] - exclude seconds from the format if they're 0
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.extendedZone=false] - add the time zone format extension
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @param {string} [opts.precision='milliseconds'] - truncate output to desired presicion: 'years', 'months', 'days', 'hours', 'minutes', 'seconds' or 'milliseconds'. When precision and suppressSeconds or suppressMilliseconds are used together, precision sets the maximum unit shown in the output, however seconds or milliseconds will still be suppressed if they are 0.
   * @example DateTime.utc(1983, 5, 25).toISO() //=> '1982-05-25T00:00:00.000Z'
   * @example DateTime.now().toISO() //=> '2017-04-22T20:47:05.335-04:00'
   * @example DateTime.now().toISO({ includeOffset: false }) //=> '2017-04-22T20:47:05.335'
   * @example DateTime.now().toISO({ format: 'basic' }) //=> '20170422T204705.335-0400'
   * @example DateTime.now().toISO({ precision: 'day' }) //=> '2017-04-22Z'
   * @example DateTime.now().toISO({ precision: 'minute' }) //=> '2017-04-22T20:47Z'
   * @return {string|null}
   */
  toISO({
    format: e = "extended",
    suppressSeconds: t = !1,
    suppressMilliseconds: n = !1,
    includeOffset: s = !0,
    extendedZone: i = !1,
    precision: a = "milliseconds"
  } = {}) {
    if (!this.isValid)
      return null;
    a = Sr(a);
    const l = e === "extended";
    let o = un(this, l, a);
    return Or.indexOf(a) >= 3 && (o += "T"), o += di(this, l, t, n, s, i, a), o;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime's date component
   * @param {Object} opts - options
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @param {string} [opts.precision='day'] - truncate output to desired precision: 'years', 'months', or 'days'.
   * @example DateTime.utc(1982, 5, 25).toISODate() //=> '1982-05-25'
   * @example DateTime.utc(1982, 5, 25).toISODate({ format: 'basic' }) //=> '19820525'
   * @example DateTime.utc(1982, 5, 25).toISODate({ precision: 'month' }) //=> '1982-05'
   * @return {string|null}
   */
  toISODate({
    format: e = "extended",
    precision: t = "day"
  } = {}) {
    return this.isValid ? un(this, e === "extended", Sr(t)) : null;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime's week date
   * @example DateTime.utc(1982, 5, 25).toISOWeekDate() //=> '1982-W21-2'
   * @return {string}
   */
  toISOWeekDate() {
    return br(this, "kkkk-'W'WW-c");
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime's time component
   * @param {Object} opts - options
   * @param {boolean} [opts.suppressMilliseconds=false] - exclude milliseconds from the format if they're 0
   * @param {boolean} [opts.suppressSeconds=false] - exclude seconds from the format if they're 0
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.extendedZone=true] - add the time zone format extension
   * @param {boolean} [opts.includePrefix=false] - include the `T` prefix
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @param {string} [opts.precision='milliseconds'] - truncate output to desired presicion: 'hours', 'minutes', 'seconds' or 'milliseconds'. When precision and suppressSeconds or suppressMilliseconds are used together, precision sets the maximum unit shown in the output, however seconds or milliseconds will still be suppressed if they are 0.
   * @example DateTime.utc().set({ hour: 7, minute: 34 }).toISOTime() //=> '07:34:19.361Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34, seconds: 0, milliseconds: 0 }).toISOTime({ suppressSeconds: true }) //=> '07:34Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34 }).toISOTime({ format: 'basic' }) //=> '073419.361Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34 }).toISOTime({ includePrefix: true }) //=> 'T07:34:19.361Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34, second: 56 }).toISOTime({ precision: 'minute' }) //=> '07:34Z'
   * @return {string}
   */
  toISOTime({
    suppressMilliseconds: e = !1,
    suppressSeconds: t = !1,
    includeOffset: n = !0,
    includePrefix: s = !1,
    extendedZone: i = !1,
    format: a = "extended",
    precision: l = "milliseconds"
  } = {}) {
    return this.isValid ? (l = Sr(l), (s && Or.indexOf(l) >= 3 ? "T" : "") + di(this, a === "extended", t, e, n, i, l)) : null;
  }
  /**
   * Returns an RFC 2822-compatible string representation of this DateTime
   * @example DateTime.utc(2014, 7, 13).toRFC2822() //=> 'Sun, 13 Jul 2014 00:00:00 +0000'
   * @example DateTime.local(2014, 7, 13).toRFC2822() //=> 'Sun, 13 Jul 2014 00:00:00 -0400'
   * @return {string}
   */
  toRFC2822() {
    return br(this, "EEE, dd LLL yyyy HH:mm:ss ZZZ", !1);
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in HTTP headers. The output is always expressed in GMT.
   * Specifically, the string conforms to RFC 1123.
   * @see https://www.w3.org/Protocols/rfc2616/rfc2616-sec3.html#sec3.3.1
   * @example DateTime.utc(2014, 7, 13).toHTTP() //=> 'Sun, 13 Jul 2014 00:00:00 GMT'
   * @example DateTime.utc(2014, 7, 13, 19).toHTTP() //=> 'Sun, 13 Jul 2014 19:00:00 GMT'
   * @return {string}
   */
  toHTTP() {
    return br(this.toUTC(), "EEE, dd LLL yyyy HH:mm:ss 'GMT'");
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in SQL Date
   * @example DateTime.utc(2014, 7, 13).toSQLDate() //=> '2014-07-13'
   * @return {string|null}
   */
  toSQLDate() {
    return this.isValid ? un(this, !0) : null;
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in SQL Time
   * @param {Object} opts - options
   * @param {boolean} [opts.includeZone=false] - include the zone, such as 'America/New_York'. Overrides includeOffset.
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.includeOffsetSpace=true] - include the space between the time and the offset, such as '05:15:16.345 -04:00'
   * @example DateTime.utc().toSQL() //=> '05:15:16.345'
   * @example DateTime.now().toSQL() //=> '05:15:16.345 -04:00'
   * @example DateTime.now().toSQL({ includeOffset: false }) //=> '05:15:16.345'
   * @example DateTime.now().toSQL({ includeZone: false }) //=> '05:15:16.345 America/New_York'
   * @return {string}
   */
  toSQLTime({
    includeOffset: e = !0,
    includeZone: t = !1,
    includeOffsetSpace: n = !0
  } = {}) {
    let s = "HH:mm:ss.SSS";
    return (t || e) && (n && (s += " "), t ? s += "z" : e && (s += "ZZ")), br(this, s, !0);
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in SQL DateTime
   * @param {Object} opts - options
   * @param {boolean} [opts.includeZone=false] - include the zone, such as 'America/New_York'. Overrides includeOffset.
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.includeOffsetSpace=true] - include the space between the time and the offset, such as '05:15:16.345 -04:00'
   * @example DateTime.utc(2014, 7, 13).toSQL() //=> '2014-07-13 00:00:00.000 Z'
   * @example DateTime.local(2014, 7, 13).toSQL() //=> '2014-07-13 00:00:00.000 -04:00'
   * @example DateTime.local(2014, 7, 13).toSQL({ includeOffset: false }) //=> '2014-07-13 00:00:00.000'
   * @example DateTime.local(2014, 7, 13).toSQL({ includeZone: true }) //=> '2014-07-13 00:00:00.000 America/New_York'
   * @return {string}
   */
  toSQL(e = {}) {
    return this.isValid ? `${this.toSQLDate()} ${this.toSQLTime(e)}` : null;
  }
  /**
   * Returns a string representation of this DateTime appropriate for debugging
   * @return {string}
   */
  toString() {
    return this.isValid ? this.toISO() : an;
  }
  /**
   * Returns a string representation of this DateTime appropriate for the REPL.
   * @return {string}
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return this.isValid ? `DateTime { ts: ${this.toISO()}, zone: ${this.zone.name}, locale: ${this.locale} }` : `DateTime { Invalid, reason: ${this.invalidReason} }`;
  }
  /**
   * Returns the epoch milliseconds of this DateTime. Alias of {@link DateTime#toMillis}
   * @return {number}
   */
  valueOf() {
    return this.toMillis();
  }
  /**
   * Returns the epoch milliseconds of this DateTime.
   * @return {number}
   */
  toMillis() {
    return this.isValid ? this.ts : NaN;
  }
  /**
   * Returns the epoch seconds (including milliseconds in the fractional part) of this DateTime.
   * @return {number}
   */
  toSeconds() {
    return this.isValid ? this.ts / 1e3 : NaN;
  }
  /**
   * Returns the epoch seconds (as a whole number) of this DateTime.
   * @return {number}
   */
  toUnixInteger() {
    return this.isValid ? Math.floor(this.ts / 1e3) : NaN;
  }
  /**
   * Returns an ISO 8601 representation of this DateTime appropriate for use in JSON.
   * @return {string}
   */
  toJSON() {
    return this.toISO();
  }
  /**
   * Returns a BSON serializable equivalent to this DateTime.
   * @return {Date}
   */
  toBSON() {
    return this.toJSDate();
  }
  /**
   * Returns a JavaScript object with this DateTime's year, month, day, and so on.
   * @param opts - options for generating the object
   * @param {boolean} [opts.includeConfig=false] - include configuration attributes in the output
   * @example DateTime.now().toObject() //=> { year: 2017, month: 4, day: 22, hour: 20, minute: 49, second: 42, millisecond: 268 }
   * @return {Object}
   */
  toObject(e = {}) {
    if (!this.isValid)
      return {};
    const t = {
      ...this.c
    };
    return e.includeConfig && (t.outputCalendar = this.outputCalendar, t.numberingSystem = this.loc.numberingSystem, t.locale = this.loc.locale), t;
  }
  /**
   * Returns a JavaScript Date equivalent to this DateTime.
   * @return {Date}
   */
  toJSDate() {
    return new Date(this.isValid ? this.ts : NaN);
  }
  // COMPARE
  /**
   * Return the difference between two DateTimes as a Duration.
   * @param {DateTime} otherDateTime - the DateTime to compare this one to
   * @param {string|string[]} [unit=['milliseconds']] - the unit or array of units (such as 'hours' or 'days') to include in the duration.
   * @param {Object} opts - options that affect the creation of the Duration
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @example
   * var i1 = DateTime.fromISO('1982-05-25T09:45'),
   *     i2 = DateTime.fromISO('1983-10-14T10:30');
   * i2.diff(i1).toObject() //=> { milliseconds: 43807500000 }
   * i2.diff(i1, 'hours').toObject() //=> { hours: 12168.75 }
   * i2.diff(i1, ['months', 'days']).toObject() //=> { months: 16, days: 19.03125 }
   * i2.diff(i1, ['months', 'days', 'hours']).toObject() //=> { months: 16, days: 19, hours: 0.75 }
   * @return {Duration}
   */
  diff(e, t = "milliseconds", n = {}) {
    if (!this.isValid || !e.isValid)
      return J.invalid("created by diffing an invalid DateTime");
    const s = {
      locale: this.locale,
      numberingSystem: this.numberingSystem,
      ...n
    }, i = dh(t).map(J.normalizeUnit), a = e.valueOf() > this.valueOf(), l = a ? this : e, o = a ? e : this, f = pm(l, o, i, s);
    return a ? f.negate() : f;
  }
  /**
   * Return the difference between this DateTime and right now.
   * See {@link DateTime#diff}
   * @param {string|string[]} [unit=['milliseconds']] - the unit or units units (such as 'hours' or 'days') to include in the duration
   * @param {Object} opts - options that affect the creation of the Duration
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @return {Duration}
   */
  diffNow(e = "milliseconds", t = {}) {
    return this.diff(P.now(), e, t);
  }
  /**
   * Return an Interval spanning between this DateTime and another DateTime
   * @param {DateTime} otherDateTime - the other end point of the Interval
   * @return {Interval|DateTime}
   */
  until(e) {
    return this.isValid ? re.fromDateTimes(this, e) : this;
  }
  /**
   * Return whether this DateTime is in the same unit of time as another DateTime.
   * Higher-order units must also be identical for this function to return `true`.
   * Note that time zones are **ignored** in this comparison, which compares the **local** calendar time. Use {@link DateTime#setZone} to convert one of the dates if needed.
   * @param {DateTime} otherDateTime - the other DateTime
   * @param {string} unit - the unit of time to check sameness on
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week; only the locale of this DateTime is used
   * @example DateTime.now().hasSame(otherDT, 'day'); //~> true if otherDT is in the same current calendar day
   * @return {boolean}
   */
  hasSame(e, t, n) {
    if (!this.isValid)
      return !1;
    const s = e.valueOf(), i = this.setZone(e.zone, {
      keepLocalTime: !0
    });
    return i.startOf(t, n) <= s && s <= i.endOf(t, n);
  }
  /**
   * Equality check
   * Two DateTimes are equal if and only if they represent the same millisecond, have the same zone and location, and are both valid.
   * To compare just the millisecond values, use `+dt1 === +dt2`.
   * @param {DateTime} other - the other DateTime
   * @return {boolean}
   */
  equals(e) {
    return this.isValid && e.isValid && this.valueOf() === e.valueOf() && this.zone.equals(e.zone) && this.loc.equals(e.loc);
  }
  /**
   * Returns a string representation of a this time relative to now, such as "in two days". Can only internationalize if your
   * platform supports Intl.RelativeTimeFormat. Rounds towards zero by default.
   * @param {Object} options - options that affect the output
   * @param {DateTime} [options.base=DateTime.now()] - the DateTime to use as the basis to which this time is compared. Defaults to now.
   * @param {string} [options.style="long"] - the style of units, must be "long", "short", or "narrow"
   * @param {string|string[]} options.unit - use a specific unit or array of units; if omitted, or an array, the method will pick the best unit. Use an array or one of "years", "quarters", "months", "weeks", "days", "hours", "minutes", or "seconds"
   * @param {boolean} [options.round=true] - whether to round the numbers in the output.
   * @param {string} [options.rounding="trunc"] - rounding method to use when rounding the numbers in the output. Can be "trunc" (toward zero), "expand" (away from zero), "round", "floor", or "ceil".
   * @param {number} [options.padding=0] - padding in milliseconds. This allows you to round up the result if it fits inside the threshold. Don't use in combination with {round: false} because the decimal output will include the padding.
   * @param {string} options.locale - override the locale of this DateTime
   * @param {string} options.numberingSystem - override the numberingSystem of this DateTime. The Intl system may choose not to honor this
   * @example DateTime.now().plus({ days: 1 }).toRelative() //=> "in 1 day"
   * @example DateTime.now().setLocale("es").toRelative({ days: 1 }) //=> "dentro de 1 día"
   * @example DateTime.now().plus({ days: 1 }).toRelative({ locale: "fr" }) //=> "dans 23 heures"
   * @example DateTime.now().minus({ days: 2 }).toRelative() //=> "2 days ago"
   * @example DateTime.now().minus({ days: 2 }).toRelative({ unit: "hours" }) //=> "48 hours ago"
   * @example DateTime.now().minus({ hours: 36 }).toRelative({ round: false }) //=> "1.5 days ago"
   */
  toRelative(e = {}) {
    if (!this.isValid)
      return null;
    const t = e.base || P.fromObject({}, {
      zone: this.zone
    }), n = e.padding ? this < t ? -e.padding : e.padding : 0;
    let s = ["years", "months", "days", "hours", "minutes", "seconds"], i = e.unit;
    return Array.isArray(e.unit) && (s = e.unit, i = void 0), pi(t, this.plus(n), {
      ...e,
      numeric: "always",
      units: s,
      unit: i
    });
  }
  /**
   * Returns a string representation of this date relative to today, such as "yesterday" or "next month".
   * Only internationalizes on platforms that supports Intl.RelativeTimeFormat.
   * @param {Object} options - options that affect the output
   * @param {DateTime} [options.base=DateTime.now()] - the DateTime to use as the basis to which this time is compared. Defaults to now.
   * @param {string} options.locale - override the locale of this DateTime
   * @param {string} options.unit - use a specific unit; if omitted, the method will pick the unit. Use one of "years", "quarters", "months", "weeks", or "days"
   * @param {string} options.numberingSystem - override the numberingSystem of this DateTime. The Intl system may choose not to honor this
   * @example DateTime.now().plus({ days: 1 }).toRelativeCalendar() //=> "tomorrow"
   * @example DateTime.now().setLocale("es").plus({ days: 1 }).toRelative() //=> ""mañana"
   * @example DateTime.now().plus({ days: 1 }).toRelativeCalendar({ locale: "fr" }) //=> "demain"
   * @example DateTime.now().minus({ days: 2 }).toRelativeCalendar() //=> "2 days ago"
   */
  toRelativeCalendar(e = {}) {
    return this.isValid ? pi(e.base || P.fromObject({}, {
      zone: this.zone
    }), this, {
      ...e,
      numeric: "auto",
      units: ["years", "months", "days"],
      calendary: !0
    }) : null;
  }
  /**
   * Return the min of several date times
   * @param {...DateTime} dateTimes - the DateTimes from which to choose the minimum
   * @return {DateTime} the min DateTime, or undefined if called with no argument
   */
  static min(...e) {
    if (!e.every(P.isDateTime))
      throw new me("min requires all arguments be DateTimes");
    return ei(e, (t) => t.valueOf(), Math.min);
  }
  /**
   * Return the max of several date times
   * @param {...DateTime} dateTimes - the DateTimes from which to choose the maximum
   * @return {DateTime} the max DateTime, or undefined if called with no argument
   */
  static max(...e) {
    if (!e.every(P.isDateTime))
      throw new me("max requires all arguments be DateTimes");
    return ei(e, (t) => t.valueOf(), Math.max);
  }
  // MISC
  /**
   * Explain how a string would be parsed by fromFormat()
   * @param {string} text - the string to parse
   * @param {string} fmt - the format the string is expected to be in (see description)
   * @param {Object} options - options taken by fromFormat()
   * @return {Object}
   */
  static fromFormatExplain(e, t, n = {}) {
    const {
      locale: s = null,
      numberingSystem: i = null
    } = n, a = Q.fromOpts({
      locale: s,
      numberingSystem: i,
      defaultToEN: !0
    });
    return zo(a, e, t);
  }
  /**
   * @deprecated use fromFormatExplain instead
   */
  static fromStringExplain(e, t, n = {}) {
    return P.fromFormatExplain(e, t, n);
  }
  /**
   * Build a parser for `fmt` using the given locale. This parser can be passed
   * to {@link DateTime.fromFormatParser} to a parse a date in this format. This
   * can be used to optimize cases where many dates need to be parsed in a
   * specific format.
   *
   * @param {String} fmt - the format the string is expected to be in (see
   * description)
   * @param {Object} options - options used to set locale and numberingSystem
   * for parser
   * @returns {TokenParser} - opaque object to be used
   */
  static buildFormatParser(e, t = {}) {
    const {
      locale: n = null,
      numberingSystem: s = null
    } = t, i = Q.fromOpts({
      locale: n,
      numberingSystem: s,
      defaultToEN: !0
    });
    return new Ro(i, e);
  }
  /**
   * Create a DateTime from an input string and format parser.
   *
   * The format parser must have been created with the same locale as this call.
   *
   * @param {String} text - the string to parse
   * @param {TokenParser} formatParser - parser from {@link DateTime.buildFormatParser}
   * @param {Object} opts - options taken by fromFormat()
   * @returns {DateTime}
   */
  static fromFormatParser(e, t, n = {}) {
    if (x(e) || x(t))
      throw new me("fromFormatParser requires an input string and a format parser");
    const {
      locale: s = null,
      numberingSystem: i = null
    } = n, a = Q.fromOpts({
      locale: s,
      numberingSystem: i,
      defaultToEN: !0
    });
    if (!a.equals(t.locale))
      throw new me(`fromFormatParser called with a locale of ${a}, but the format parser was created for ${t.locale}`);
    const {
      result: l,
      zone: o,
      specificOffset: f,
      invalidReason: u
    } = t.explainFromTokens(e);
    return u ? P.invalid(u) : _t(l, o, n, `format ${t.format}`, e, f);
  }
  // FORMAT PRESETS
  /**
   * {@link DateTime#toLocaleString} format like 10/14/1983
   * @type {Object}
   */
  static get DATE_SHORT() {
    return Ir;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Oct 14, 1983'
   * @type {Object}
   */
  static get DATE_MED() {
    return ja;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Fri, Oct 14, 1983'
   * @type {Object}
   */
  static get DATE_MED_WITH_WEEKDAY() {
    return Rd;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'October 14, 1983'
   * @type {Object}
   */
  static get DATE_FULL() {
    return $a;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Tuesday, October 14, 1983'
   * @type {Object}
   */
  static get DATE_HUGE() {
    return Za;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_SIMPLE() {
    return Ha;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_WITH_SECONDS() {
    return Ba;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 AM EDT'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_WITH_SHORT_OFFSET() {
    return Ya;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 AM Eastern Daylight Time'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_WITH_LONG_OFFSET() {
    return Ga;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_SIMPLE() {
    return Ja;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_WITH_SECONDS() {
    return Ka;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 EDT', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_WITH_SHORT_OFFSET() {
    return Qa;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 Eastern Daylight Time', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_WITH_LONG_OFFSET() {
    return Xa;
  }
  /**
   * {@link DateTime#toLocaleString} format like '10/14/1983, 9:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_SHORT() {
    return eo;
  }
  /**
   * {@link DateTime#toLocaleString} format like '10/14/1983, 9:30:33 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_SHORT_WITH_SECONDS() {
    return to;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Oct 14, 1983, 9:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_MED() {
    return ro;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Oct 14, 1983, 9:30:33 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_MED_WITH_SECONDS() {
    return no;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Fri, 14 Oct 1983, 9:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_MED_WITH_WEEKDAY() {
    return zd;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'October 14, 1983, 9:30 AM EDT'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_FULL() {
    return so;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'October 14, 1983, 9:30:33 AM EDT'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_FULL_WITH_SECONDS() {
    return io;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Friday, October 14, 1983, 9:30 AM Eastern Daylight Time'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_HUGE() {
    return ao;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Friday, October 14, 1983, 9:30:33 AM Eastern Daylight Time'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_HUGE_WITH_SECONDS() {
    return oo;
  }
}
function zt(r) {
  if (P.isDateTime(r))
    return r;
  if (r && r.valueOf && Qe(r.valueOf()))
    return P.fromJSDate(r);
  if (r && typeof r == "object")
    return P.fromObject(r);
  throw new me(`Unknown datetime argument: ${r}, of type ${typeof r}`);
}
const Im = "3.7.1";
Fe.DateTime = P;
Fe.Duration = J;
Fe.FixedOffsetZone = ye;
Fe.IANAZone = je;
Fe.Info = $t;
Fe.Interval = re;
Fe.InvalidZone = fo;
Fe.Settings = ne;
Fe.SystemZone = Xt;
Fe.VERSION = Im;
Fe.Zone = Vt;
var at = Fe;
$.prototype.addYear = function() {
  this._date = this._date.plus({ years: 1 });
};
$.prototype.addMonth = function() {
  this._date = this._date.plus({ months: 1 }).startOf("month");
};
$.prototype.addDay = function() {
  this._date = this._date.plus({ days: 1 }).startOf("day");
};
$.prototype.addHour = function() {
  var r = this._date;
  this._date = this._date.plus({ hours: 1 }).startOf("hour"), this._date <= r && (this._date = this._date.plus({ hours: 1 }));
};
$.prototype.addMinute = function() {
  var r = this._date;
  this._date = this._date.plus({ minutes: 1 }).startOf("minute"), this._date < r && (this._date = this._date.plus({ hours: 1 }));
};
$.prototype.addSecond = function() {
  var r = this._date;
  this._date = this._date.plus({ seconds: 1 }).startOf("second"), this._date < r && (this._date = this._date.plus({ hours: 1 }));
};
$.prototype.subtractYear = function() {
  this._date = this._date.minus({ years: 1 });
};
$.prototype.subtractMonth = function() {
  this._date = this._date.minus({ months: 1 }).endOf("month").startOf("second");
};
$.prototype.subtractDay = function() {
  this._date = this._date.minus({ days: 1 }).endOf("day").startOf("second");
};
$.prototype.subtractHour = function() {
  var r = this._date;
  this._date = this._date.minus({ hours: 1 }).endOf("hour").startOf("second"), this._date >= r && (this._date = this._date.minus({ hours: 1 }));
};
$.prototype.subtractMinute = function() {
  var r = this._date;
  this._date = this._date.minus({ minutes: 1 }).endOf("minute").startOf("second"), this._date > r && (this._date = this._date.minus({ hours: 1 }));
};
$.prototype.subtractSecond = function() {
  var r = this._date;
  this._date = this._date.minus({ seconds: 1 }).startOf("second"), this._date > r && (this._date = this._date.minus({ hours: 1 }));
};
$.prototype.getDate = function() {
  return this._date.day;
};
$.prototype.getFullYear = function() {
  return this._date.year;
};
$.prototype.getDay = function() {
  var r = this._date.weekday;
  return r == 7 ? 0 : r;
};
$.prototype.getMonth = function() {
  return this._date.month - 1;
};
$.prototype.getHours = function() {
  return this._date.hour;
};
$.prototype.getMinutes = function() {
  return this._date.minute;
};
$.prototype.getSeconds = function() {
  return this._date.second;
};
$.prototype.getMilliseconds = function() {
  return this._date.millisecond;
};
$.prototype.getTime = function() {
  return this._date.valueOf();
};
$.prototype.getUTCDate = function() {
  return this._getUTC().day;
};
$.prototype.getUTCFullYear = function() {
  return this._getUTC().year;
};
$.prototype.getUTCDay = function() {
  var r = this._getUTC().weekday;
  return r == 7 ? 0 : r;
};
$.prototype.getUTCMonth = function() {
  return this._getUTC().month - 1;
};
$.prototype.getUTCHours = function() {
  return this._getUTC().hour;
};
$.prototype.getUTCMinutes = function() {
  return this._getUTC().minute;
};
$.prototype.getUTCSeconds = function() {
  return this._getUTC().second;
};
$.prototype.toISOString = function() {
  return this._date.toUTC().toISO();
};
$.prototype.toJSON = function() {
  return this._date.toJSON();
};
$.prototype.setDate = function(r) {
  this._date = this._date.set({ day: r });
};
$.prototype.setFullYear = function(r) {
  this._date = this._date.set({ year: r });
};
$.prototype.setDay = function(r) {
  this._date = this._date.set({ weekday: r });
};
$.prototype.setMonth = function(r) {
  this._date = this._date.set({ month: r + 1 });
};
$.prototype.setHours = function(r) {
  this._date = this._date.set({ hour: r });
};
$.prototype.setMinutes = function(r) {
  this._date = this._date.set({ minute: r });
};
$.prototype.setSeconds = function(r) {
  this._date = this._date.set({ second: r });
};
$.prototype.setMilliseconds = function(r) {
  this._date = this._date.set({ millisecond: r });
};
$.prototype._getUTC = function() {
  return this._date.toUTC();
};
$.prototype.toString = function() {
  return this.toDate().toString();
};
$.prototype.toDate = function() {
  return this._date.toJSDate();
};
$.prototype.isLastDayOfMonth = function() {
  var r = this._date.plus({ days: 1 }).startOf("day");
  return this._date.month !== r.month;
};
$.prototype.isLastWeekdayOfMonth = function() {
  var r = this._date.plus({ days: 7 }).startOf("day");
  return this._date.month !== r.month;
};
function $(r, e) {
  var t = { zone: e };
  if (r ? r instanceof $ ? this._date = r._date : r instanceof Date ? this._date = at.DateTime.fromJSDate(r, t) : typeof r == "number" ? this._date = at.DateTime.fromMillis(r, t) : typeof r == "string" && (this._date = at.DateTime.fromISO(r, t), this._date.isValid || (this._date = at.DateTime.fromRFC2822(r, t)), this._date.isValid || (this._date = at.DateTime.fromSQL(r, t)), this._date.isValid || (this._date = at.DateTime.fromFormat(r, "EEE, d MMM yyyy HH:mm:ss", t))) : this._date = at.DateTime.local(), !this._date || !this._date.isValid)
    throw new Error("CronDate: unhandled timestamp: " + JSON.stringify(r));
  e && e !== this._date.zoneName && (this._date = this._date.setZone(e));
}
var Am = $;
function lt(r) {
  return {
    start: r,
    count: 1
  };
}
function yi(r, e) {
  r.end = e, r.step = e - r.start, r.count = 2;
}
function fn(r, e, t) {
  e && (e.count === 2 ? (r.push(lt(e.start)), r.push(lt(e.end))) : r.push(e)), t && r.push(t);
}
function Wm(r) {
  for (var e = [], t = void 0, n = 0; n < r.length; n++) {
    var s = r[n];
    typeof s != "number" ? (fn(e, t, lt(s)), t = void 0) : t ? t.count === 1 ? yi(t, s) : t.step === s - t.end ? (t.count++, t.end = s) : t.count === 2 ? (e.push(lt(t.start)), t = lt(t.end), yi(t, s)) : (fn(e, t), t = lt(s)) : t = lt(s);
  }
  return fn(e, t), e;
}
var Um = Wm, xm = Um;
function Pm(r, e, t) {
  var n = xm(r);
  if (n.length === 1) {
    var s = n[0], i = s.step;
    if (i === 1 && s.start === e && s.end === t)
      return "*";
    if (i !== 1 && s.start === e && s.end === t - i + 1)
      return "*/" + i;
  }
  for (var a = [], l = 0, o = n.length; l < o; ++l) {
    var f = n[l];
    if (f.count === 1) {
      a.push(f.start);
      continue;
    }
    var i = f.step;
    if (f.step === 1) {
      a.push(f.start + "-" + f.end);
      continue;
    }
    var u = f.start == 0 ? f.count - 1 : f.count;
    f.step * u > f.end ? a = a.concat(
      Array.from({ length: f.end - f.start + 1 }).map(function(h, c) {
        var m = f.start + c;
        return (m - f.start) % f.step === 0 ? m : null;
      }).filter(function(h) {
        return h != null;
      })
    ) : f.end === t - f.step + 1 ? a.push(f.start + "/" + f.step) : a.push(f.start + "-" + f.end + "/" + f.step);
  }
  return a.join(",");
}
var Rm = Pm, ft = Am, zm = Rm, _i = 1e4;
function M(r, e) {
  this._options = e, this._utc = e.utc || !1, this._tz = this._utc ? "UTC" : e.tz, this._currentDate = new ft(e.currentDate, this._tz), this._startDate = e.startDate ? new ft(e.startDate, this._tz) : null, this._endDate = e.endDate ? new ft(e.endDate, this._tz) : null, this._isIterator = e.iterator || !1, this._hasIterated = !1, this._nthDayOfWeek = e.nthDayOfWeek || 0, this.fields = M._freezeFields(r);
}
M.map = ["second", "minute", "hour", "dayOfMonth", "month", "dayOfWeek"];
M.predefined = {
  "@yearly": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@hourly": "0 * * * *"
};
M.constraints = [
  { min: 0, max: 59, chars: [] },
  // Second
  { min: 0, max: 59, chars: [] },
  // Minute
  { min: 0, max: 23, chars: [] },
  // Hour
  { min: 1, max: 31, chars: ["L"] },
  // Day of month
  { min: 1, max: 12, chars: [] },
  // Month
  { min: 0, max: 7, chars: ["L"] }
  // Day of week
];
M.daysInMonth = [
  31,
  29,
  31,
  30,
  31,
  30,
  31,
  31,
  30,
  31,
  30,
  31
];
M.aliases = {
  month: {
    jan: 1,
    feb: 2,
    mar: 3,
    apr: 4,
    may: 5,
    jun: 6,
    jul: 7,
    aug: 8,
    sep: 9,
    oct: 10,
    nov: 11,
    dec: 12
  },
  dayOfWeek: {
    sun: 0,
    mon: 1,
    tue: 2,
    wed: 3,
    thu: 4,
    fri: 5,
    sat: 6
  }
};
M.parseDefaults = ["0", "*", "*", "*", "*", "*"];
M.standardValidCharacters = /^[,*\d/-]+$/;
M.dayOfWeekValidCharacters = /^[?,*\dL#/-]+$/;
M.dayOfMonthValidCharacters = /^[?,*\dL/-]+$/;
M.validCharacters = {
  second: M.standardValidCharacters,
  minute: M.standardValidCharacters,
  hour: M.standardValidCharacters,
  dayOfMonth: M.dayOfMonthValidCharacters,
  month: M.standardValidCharacters,
  dayOfWeek: M.dayOfWeekValidCharacters
};
M._isValidConstraintChar = function(e, t) {
  return typeof t != "string" ? !1 : e.chars.some(function(n) {
    return t.indexOf(n) > -1;
  });
};
M._parseField = function(e, t, n) {
  switch (e) {
    case "month":
    case "dayOfWeek":
      var s = M.aliases[e];
      t = t.replace(/[a-z]{3}/gi, function(o) {
        if (o = o.toLowerCase(), typeof s[o] < "u")
          return s[o];
        throw new Error('Validation error, cannot resolve alias "' + o + '"');
      });
      break;
  }
  if (!M.validCharacters[e].test(t))
    throw new Error("Invalid characters, got value: " + t);
  t.indexOf("*") !== -1 ? t = t.replace(/\*/g, n.min + "-" + n.max) : t.indexOf("?") !== -1 && (t = t.replace(/\?/g, n.min + "-" + n.max));
  function i(o) {
    var f = [];
    function u(m) {
      if (m instanceof Array)
        for (var g = 0, p = m.length; g < p; g++) {
          var y = m[g];
          if (M._isValidConstraintChar(n, y)) {
            f.push(y);
            continue;
          }
          if (typeof y != "number" || Number.isNaN(y) || y < n.min || y > n.max)
            throw new Error(
              "Constraint error, got value " + y + " expected range " + n.min + "-" + n.max
            );
          f.push(y);
        }
      else {
        if (M._isValidConstraintChar(n, m)) {
          f.push(m);
          return;
        }
        var b = +m;
        if (Number.isNaN(b) || b < n.min || b > n.max)
          throw new Error(
            "Constraint error, got value " + m + " expected range " + n.min + "-" + n.max
          );
        e === "dayOfWeek" && (b = b % 7), f.push(b);
      }
    }
    var d = o.split(",");
    if (!d.every(function(m) {
      return m.length > 0;
    }))
      throw new Error("Invalid list value format");
    if (d.length > 1)
      for (var h = 0, c = d.length; h < c; h++)
        u(a(d[h]));
    else
      u(a(o));
    return f.sort(M._sortCompareFn), f;
  }
  function a(o) {
    var f = 1, u = o.split("/");
    if (u.length > 2)
      throw new Error("Invalid repeat: " + o);
    return u.length > 1 ? (u[0] == +u[0] && (u = [u[0] + "-" + n.max, u[1]]), l(u[0], u[u.length - 1])) : l(o, f);
  }
  function l(o, f) {
    var u = [], d = o.split("-");
    if (d.length > 1) {
      if (d.length < 2)
        return +o;
      if (!d[0].length) {
        if (!d[1].length)
          throw new Error("Invalid range: " + o);
        return +o;
      }
      var h = +d[0], c = +d[1];
      if (Number.isNaN(h) || Number.isNaN(c) || h < n.min || c > n.max)
        throw new Error(
          "Constraint error, got range " + h + "-" + c + " expected range " + n.min + "-" + n.max
        );
      if (h > c)
        throw new Error("Invalid range: " + o);
      var m = +f;
      if (Number.isNaN(m) || m <= 0)
        throw new Error("Constraint error, cannot repeat at every " + m + " time.");
      e === "dayOfWeek" && c % 7 === 0 && u.push(0);
      for (var g = h, p = c; g <= p; g++) {
        var y = u.indexOf(g) !== -1;
        !y && m > 0 && m % f === 0 ? (m = 1, u.push(g)) : m++;
      }
      return u;
    }
    return Number.isNaN(+o) ? o : +o;
  }
  return i(t);
};
M._sortCompareFn = function(r, e) {
  var t = typeof r == "number", n = typeof e == "number";
  return t && n ? r - e : !t && n ? 1 : t && !n ? -1 : r.localeCompare(e);
};
M._handleMaxDaysInMonth = function(r) {
  if (r.month.length === 1) {
    var e = M.daysInMonth[r.month[0] - 1];
    if (r.dayOfMonth[0] > e)
      throw new Error("Invalid explicit day of month definition");
    return r.dayOfMonth.filter(function(t) {
      return t === "L" ? !0 : t <= e;
    }).sort(M._sortCompareFn);
  }
};
M._freezeFields = function(r) {
  for (var e = 0, t = M.map.length; e < t; ++e) {
    var n = M.map[e], s = r[n];
    r[n] = Object.freeze(s);
  }
  return Object.freeze(r);
};
M.prototype._applyTimezoneShift = function(r, e, t) {
  if (t === "Month" || t === "Day") {
    var n = r.getTime();
    r[e + t]();
    var s = r.getTime();
    n === s && (r.getMinutes() === 0 && r.getSeconds() === 0 ? r.addHour() : r.getMinutes() === 59 && r.getSeconds() === 59 && r.subtractHour());
  } else {
    var i = r.getHours();
    r[e + t]();
    var a = r.getHours(), l = a - i;
    l === 2 ? this.fields.hour.length !== 24 && (this._dstStart = a) : l === 0 && r.getMinutes() === 0 && r.getSeconds() === 0 && this.fields.hour.length !== 24 && (this._dstEnd = a);
  }
};
M.prototype._findSchedule = function(e) {
  function t(y, b) {
    for (var v = 0, k = b.length; v < k; v++)
      if (b[v] >= y)
        return b[v] === y;
    return b[0] === y;
  }
  function n(y, b) {
    if (b < 6) {
      if (y.getDate() < 8 && b === 1)
        return !0;
      var v = y.getDate() % 7 ? 1 : 0, k = y.getDate() - y.getDate() % 7, S = Math.floor(k / 7) + v;
      return S === b;
    }
    return !1;
  }
  function s(y) {
    return y.length > 0 && y.some(function(b) {
      return typeof b == "string" && b.indexOf("L") >= 0;
    });
  }
  e = e || !1;
  var i = e ? "subtract" : "add", a = new ft(this._currentDate, this._tz), l = this._startDate, o = this._endDate, f = a.getTime(), u = 0;
  function d(y) {
    return y.some(function(b) {
      if (!s([b]))
        return !1;
      var v = Number.parseInt(b[0]) % 7;
      if (Number.isNaN(v))
        throw new Error("Invalid last weekday of the month expression: " + b);
      return a.getDay() === v && a.isLastWeekdayOfMonth();
    });
  }
  for (; u < _i; ) {
    if (u++, e) {
      if (l && a.getTime() - l.getTime() < 0)
        throw new Error("Out of the timespan range");
    } else if (o && o.getTime() - a.getTime() < 0)
      throw new Error("Out of the timespan range");
    var h = t(a.getDate(), this.fields.dayOfMonth);
    s(this.fields.dayOfMonth) && (h = h || a.isLastDayOfMonth());
    var c = t(a.getDay(), this.fields.dayOfWeek);
    s(this.fields.dayOfWeek) && (c = c || d(this.fields.dayOfWeek));
    var m = this.fields.dayOfMonth.length >= M.daysInMonth[a.getMonth()], g = this.fields.dayOfWeek.length === M.constraints[5].max - M.constraints[5].min + 1, p = a.getHours();
    if (!h && (!c || g)) {
      this._applyTimezoneShift(a, i, "Day");
      continue;
    }
    if (!m && g && !h) {
      this._applyTimezoneShift(a, i, "Day");
      continue;
    }
    if (m && !g && !c) {
      this._applyTimezoneShift(a, i, "Day");
      continue;
    }
    if (this._nthDayOfWeek > 0 && !n(a, this._nthDayOfWeek)) {
      this._applyTimezoneShift(a, i, "Day");
      continue;
    }
    if (!t(a.getMonth() + 1, this.fields.month)) {
      this._applyTimezoneShift(a, i, "Month");
      continue;
    }
    if (t(p, this.fields.hour)) {
      if (this._dstEnd === p && !e) {
        this._dstEnd = null, this._applyTimezoneShift(a, "add", "Hour");
        continue;
      }
    } else if (this._dstStart !== p) {
      this._dstStart = null, this._applyTimezoneShift(a, i, "Hour");
      continue;
    } else if (!t(p - 1, this.fields.hour)) {
      a[i + "Hour"]();
      continue;
    }
    if (!t(a.getMinutes(), this.fields.minute)) {
      this._applyTimezoneShift(a, i, "Minute");
      continue;
    }
    if (!t(a.getSeconds(), this.fields.second)) {
      this._applyTimezoneShift(a, i, "Second");
      continue;
    }
    if (f === a.getTime()) {
      i === "add" || a.getMilliseconds() === 0 ? this._applyTimezoneShift(a, i, "Second") : a.setMilliseconds(0);
      continue;
    }
    break;
  }
  if (u >= _i)
    throw new Error("Invalid expression, loop limit exceeded");
  return this._currentDate = new ft(a, this._tz), this._hasIterated = !0, a;
};
M.prototype.next = function() {
  var e = this._findSchedule();
  return this._isIterator ? {
    value: e,
    done: !this.hasNext()
  } : e;
};
M.prototype.prev = function() {
  var e = this._findSchedule(!0);
  return this._isIterator ? {
    value: e,
    done: !this.hasPrev()
  } : e;
};
M.prototype.hasNext = function() {
  var r = this._currentDate, e = this._hasIterated;
  try {
    return this._findSchedule(), !0;
  } catch {
    return !1;
  } finally {
    this._currentDate = r, this._hasIterated = e;
  }
};
M.prototype.hasPrev = function() {
  var r = this._currentDate, e = this._hasIterated;
  try {
    return this._findSchedule(!0), !0;
  } catch {
    return !1;
  } finally {
    this._currentDate = r, this._hasIterated = e;
  }
};
M.prototype.iterate = function(e, t) {
  var n = [];
  if (e >= 0)
    for (var s = 0, i = e; s < i; s++)
      try {
        var a = this.next();
        n.push(a), t && t(a, s);
      } catch {
        break;
      }
  else
    for (var s = 0, i = e; s > i; s--)
      try {
        var a = this.prev();
        n.push(a), t && t(a, s);
      } catch {
        break;
      }
  return n;
};
M.prototype.reset = function(e) {
  this._currentDate = new ft(e || this._options.currentDate);
};
M.prototype.stringify = function(e) {
  for (var t = [], n = e ? 0 : 1, s = M.map.length; n < s; ++n) {
    var i = M.map[n], a = this.fields[i], l = M.constraints[n];
    i === "dayOfMonth" && this.fields.month.length === 1 ? l = { min: 1, max: M.daysInMonth[this.fields.month[0] - 1] } : i === "dayOfWeek" && (l = { min: 0, max: 6 }, a = a[a.length - 1] === 7 ? a.slice(0, -1) : a), t.push(zm(a, l.min, l.max));
  }
  return t.join(" ");
};
M.parse = function(e, t) {
  var n = this;
  typeof t == "function" && (t = {});
  function s(i, a) {
    a || (a = {}), typeof a.currentDate > "u" && (a.currentDate = new ft(void 0, n._tz)), M.predefined[i] && (i = M.predefined[i]);
    var l = [], o = (i + "").trim().split(/\s+/);
    if (o.length > 6)
      throw new Error("Invalid cron expression");
    for (var f = M.map.length - o.length, u = 0, d = M.map.length; u < d; ++u) {
      var h = M.map[u], c = o[o.length > d ? u : u - f];
      if (u < f || !c)
        l.push(
          M._parseField(
            h,
            M.parseDefaults[u],
            M.constraints[u]
          )
        );
      else {
        var m = h === "dayOfWeek" ? b(c) : c;
        l.push(
          M._parseField(
            h,
            m,
            M.constraints[u]
          )
        );
      }
    }
    for (var g = {}, u = 0, d = M.map.length; u < d; u++) {
      var p = M.map[u];
      g[p] = l[u];
    }
    var y = M._handleMaxDaysInMonth(g);
    return g.dayOfMonth = y || g.dayOfMonth, new M(g, a);
    function b(v) {
      var k = v.split("#");
      if (k.length > 1) {
        var S = +k[k.length - 1];
        if (/,/.test(v))
          throw new Error("Constraint error, invalid dayOfWeek `#` and `,` special characters are incompatible");
        if (/\//.test(v))
          throw new Error("Constraint error, invalid dayOfWeek `#` and `/` special characters are incompatible");
        if (/-/.test(v))
          throw new Error("Constraint error, invalid dayOfWeek `#` and `-` special characters are incompatible");
        if (k.length > 2 || Number.isNaN(S) || S < 1 || S > 5)
          throw new Error("Constraint error, invalid dayOfWeek occurrence number (#)");
        return a.nthDayOfWeek = S, k[0];
      }
      return v;
    }
  }
  return s(e, t);
};
M.fieldsToExpression = function(e, t) {
  function n(h, c, m) {
    if (!c)
      throw new Error("Validation error, Field " + h + " is missing");
    if (c.length === 0)
      throw new Error("Validation error, Field " + h + " contains no values");
    for (var g = 0, p = c.length; g < p; g++) {
      var y = c[g];
      if (!M._isValidConstraintChar(m, y) && (typeof y != "number" || Number.isNaN(y) || y < m.min || y > m.max))
        throw new Error(
          "Constraint error, got value " + y + " expected range " + m.min + "-" + m.max
        );
    }
  }
  for (var s = {}, i = 0, a = M.map.length; i < a; ++i) {
    var l = M.map[i], o = e[l];
    n(
      l,
      o,
      M.constraints[i]
    );
    for (var f = [], u = -1; ++u < o.length; )
      f[u] = o[u];
    if (o = f.sort(M._sortCompareFn).filter(function(h, c, m) {
      return !c || h !== m[c - 1];
    }), o.length !== f.length)
      throw new Error("Validation error, Field " + l + " contains duplicate values");
    s[l] = o;
  }
  var d = M._handleMaxDaysInMonth(s);
  return s.dayOfMonth = d || s.dayOfMonth, new M(s, t || {});
};
var qm = M, xr = qm;
function et() {
}
et._parseEntry = function(e) {
  var t = e.split(" ");
  if (t.length === 6)
    return {
      interval: xr.parse(e)
    };
  if (t.length > 6)
    return {
      interval: xr.parse(
        t.slice(0, 6).join(" ")
      ),
      command: t.slice(6, t.length)
    };
  throw new Error("Invalid entry: " + e);
};
et.parseExpression = function(e, t) {
  return xr.parse(e, t);
};
et.fieldsToExpression = function(e, t) {
  return xr.fieldsToExpression(e, t);
};
et.parseString = function(e) {
  for (var t = e.split(`
`), n = {
    variables: {},
    expressions: [],
    errors: {}
  }, s = 0, i = t.length; s < i; s++) {
    var a = t[s], l = null, o = a.trim();
    if (o.length > 0) {
      if (o.match(/^#/))
        continue;
      if (l = o.match(/^(.*)=(.*)$/))
        n.variables[l[1]] = l[2];
      else {
        var f = null;
        try {
          f = et._parseEntry("0 " + o), n.expressions.push(f.interval);
        } catch (u) {
          n.errors[o] = u;
        }
      }
    }
  }
  return n;
};
et.parseFile = function(e, t) {
  Hl.readFile(e, function(n, s) {
    if (n) {
      t(n);
      return;
    }
    return t(null, et.parseString(s.toString()));
  });
};
var jm = et;
const $m = /* @__PURE__ */ tt(jm), bi = "(Input cron: ", Zm = {
  "smaller than lower limit": "less than",
  "bigger than upper limit": "greater than",
  daysOfMonth: "'days of the month'",
  daysOfWeek: "'days of the week'",
  years: "'years'",
  months: "'months'",
  hours: "'hours'",
  minutes: "'minutes'",
  seconds: "'seconds'"
};
function Hm(r) {
  const e = [];
  for (let t of r) {
    t.includes(bi) && (t = t.split(bi)[0].trim());
    for (let [n, s] of Object.entries(Zm))
      t.includes(n) && (t = t.replace(new RegExp(n, "g"), s));
    e.push(t);
  }
  return e;
}
function Bm(r, e = 4) {
  const t = $m.parseExpression(r), n = [];
  for (let s = 0; s < e; s++)
    n.push(t.next().toString());
  return n;
}
function Ym(r) {
  const e = Wd(r, {
    preset: "npm-cron-schedule",
    override: {
      useSeconds: !1
    }
  });
  return e.isValid() ? { valid: !0 } : { valid: !1, err: Hm(e.getError()) };
}
function Gm(r) {
  return `${bl.ROLE}${vl}${r}`;
}
function Jm(r) {
  const e = /* @__PURE__ */ new Map();
  r.forEach((i) => {
    e.set(i._id, i);
  });
  const t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set();
  function s(i) {
    const a = Gm(i);
    if (n.has(i) || n.has(a))
      return !0;
    if (t.has(i) || t.has(a))
      return !1;
    n.add(i);
    const l = e.get(a) || e.get(i);
    if (!l)
      return n.delete(i), !1;
    const o = Array.isArray(l.inherits) ? l.inherits : [l.inherits];
    for (const f of o)
      if (f && s(f))
        return !0;
    return n.delete(i), t.add(i), !1;
  }
  return !!r.find((i) => s(i._id));
}
const Km = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  checkForRoleInheritanceLoops: Jm
}, Symbol.toStringTag, { value: "Module" }));
function Qm(r) {
  return r.length === 0 ? "" : r.length === 1 ? r[0] : r.length === 2 ? r.join(" and ") : r.slice(0, -1).join(", ") + " and " + r[r.length - 1];
}
const Xm = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  punctuateList: Qm
}, Symbol.toStringTag, { value: "Module" })), e0 = (r, e) => {
  const t = new RegExp("\\s(\\d+)$"), n = r.split(t)[0], s = new RegExp(`${n}\\s(\\d+)$`), i = [];
  e.filter((l) => {
    if (l === n)
      return !0;
    const o = l.match(s);
    return o ? (i.push(parseInt(o[1])), !0) : !1;
  }), i.sort((l, o) => l - o);
  let a;
  if (i.length === 0)
    a = 1;
  else {
    for (let l = 0; l < i.length; l++)
      if (i[l] !== l + 1) {
        a = l + 1;
        break;
      }
    a || (a = i.length + 1);
  }
  return `${n} ${a}`;
}, t0 = (r, e, {
  getName: t,
  numberFirstItem: n,
  separator: s = ""
} = {}) => {
  if (!(e != null && e.length))
    return "";
  const i = e.trim(), a = n ? `${e}1` : i;
  if (!(r != null && r.length))
    return a;
  let l = 0;
  return r.forEach((o) => {
    const f = (t == null ? void 0 : t(o)) ?? o;
    if (typeof f != "string" || !f.startsWith(i))
      return;
    const u = f.split(i);
    if (u.length !== 2)
      return;
    u[1].trim() === "" && (u[1] = "1");
    const d = parseInt(u[1]);
    d > l && (l = d);
  }), l === 0 ? a : `${e}${s}${l + 1}`;
}, r0 = (r) => r ? r.startsWith("/") ? r : `/${r}` : "", n0 = (r) => r ? r.endsWith("/") ? r.slice(0, -1) : r : "", rt = (r, e) => {
  const t = r0(e);
  if (!r)
    return t;
  const n = n0(r);
  return t ? `${n}${t}` : n;
}, Zo = (r) => rt(r, Un.ACCOUNT), Ho = (r) => rt(r, Un.BILLING), Bo = (r) => rt(r, Un.UPGRADE), Yo = (r) => rt(r, Qt.WORKSPACES), Go = (r) => rt(r, Qt.SETTINGS_EMAIL), Jo = (r) => rt(r, Qt.SETTINGS_AUTH), Ko = (r) => rt(r, Qt.SETTINGS_PEOPLE_USERS), Qo = (r) => rt(r, Qt.APPS), s0 = {
  accountPortalAccountUrl: Zo,
  accountPortalBillingUrl: Ho,
  accountPortalUpgradeUrl: Bo,
  builderWorkspacesUrl: Yo,
  builderSettingsEmailUrl: Go,
  builderSettingsAuthUrl: Jo,
  builderSettingsPeopleUsersUrl: Ko,
  builderAppsUrl: Qo
}, i0 = { getNextExecutionDates: Bm, validate: Ym }, a0 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  accountPortalAccountUrl: Zo,
  accountPortalBillingUrl: Ho,
  accountPortalUpgradeUrl: Bo,
  builderAppsUrl: Qo,
  builderSettingsAuthUrl: Jo,
  builderSettingsEmailUrl: Go,
  builderSettingsPeopleUsersUrl: Ko,
  builderWorkspacesUrl: Yo,
  cancelableTimeout: wl,
  cron: i0,
  deepGet: kl,
  duplicateName: e0,
  getSequentialName: t0,
  getUserColor: Ol,
  getUserInitials: Sl,
  getUserLabel: Tl,
  isGoogleSheets: Jl,
  isSQL: Kl,
  lists: Xm,
  retry: Ql,
  roles: Km,
  schema: El,
  urlHelpers: s0,
  views: Fl,
  wait: aa,
  withTimeout: Dl
}, Symbol.toStringTag, { value: "Module" }));
function o0(r) {
  let e, t, n, s;
  return {
    c() {
      e = I("div"), t = le(
        /*error*/
        r[0]
      ), T(e, "class", "error-message svelte-wciay3");
    },
    m(i, a) {
      C(i, e, a), j(e, t), s = !0;
    },
    p(i, [a]) {
      (!s || a & /*error*/
      1) && ue(
        t,
        /*error*/
        i[0]
      );
    },
    i(i) {
      s || (i && ea(() => {
        s && (n || (n = ps(e, gs, { duration: 130 }, !0)), n.run(1));
      }), s = !0);
    },
    o(i) {
      i && (n || (n = ps(e, gs, { duration: 130 }, !1)), n.run(0)), s = !1;
    },
    d(i) {
      i && L(e), i && n && n.end();
    }
  };
}
function l0(r, e, t) {
  let { error: n = null } = e;
  return r.$$set = (s) => {
    "error" in s && t(0, n = s.error);
  }, [n];
}
class u0 extends Te {
  constructor(e) {
    super(), Ee(this, e, l0, o0, ve, { error: 0 });
  }
}
function vi(r) {
  let e, t, n;
  return t = new Pe({ props: { name: "warning" } }), {
    c() {
      e = I("div"), R(t.$$.fragment), T(e, "class", "error-icon svelte-1nk7anx");
    },
    m(s, i) {
      C(s, e, i), z(t, e, null), n = !0;
    },
    i(s) {
      n || (_(t.$$.fragment, s), n = !0);
    },
    o(s) {
      w(t.$$.fragment, s), n = !1;
    },
    d(s) {
      s && L(e), q(t);
    }
  };
}
function wi(r) {
  let e, t;
  return e = new u0({ props: { error: (
    /*error*/
    r[0]
  ) } }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s & /*error*/
      1 && (i.error = /*error*/
      n[0]), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function f0(r) {
  let e, t, n, s, i, a, l, o;
  const f = (
    /*#slots*/
    r[10].default
  ), u = Ft(
    f,
    r,
    /*$$scope*/
    r[9],
    null
  );
  let d = (
    /*error*/
    r[0] && vi()
  ), h = (
    /*error*/
    r[0] && wi(r)
  );
  return {
    c() {
      e = I("div"), t = I("div"), n = I("div"), u && u.c(), s = Y(), d && d.c(), i = Y(), h && h.c(), T(n, "class", "field svelte-1nk7anx"), T(t, "class", "content svelte-1nk7anx"), T(e, "class", "fancy-field svelte-1nk7anx"), W(
        e,
        "error",
        /*error*/
        r[0]
      ), W(
        e,
        "disabled",
        /*disabled*/
        r[2]
      ), W(
        e,
        "focused",
        /*focused*/
        r[3]
      ), W(
        e,
        "clickable",
        /*clickable*/
        r[4]
      ), W(
        e,
        "compact",
        /*compact*/
        r[6]
      ), W(
        e,
        "auto-height",
        /*autoHeight*/
        r[5]
      );
    },
    m(c, m) {
      C(c, e, m), j(e, t), j(t, n), u && u.m(n, null), j(t, s), d && d.m(t, null), j(e, i), h && h.m(e, null), r[12](e), a = !0, l || (o = fe(
        t,
        "click",
        /*click_handler*/
        r[11]
      ), l = !0);
    },
    p(c, [m]) {
      u && u.p && (!a || m & /*$$scope*/
      512) && Dt(
        u,
        f,
        c,
        /*$$scope*/
        c[9],
        a ? Nt(
          f,
          /*$$scope*/
          c[9],
          m,
          null
        ) : Mt(
          /*$$scope*/
          c[9]
        ),
        null
      ), /*error*/
      c[0] ? d ? m & /*error*/
      1 && _(d, 1) : (d = vi(), d.c(), _(d, 1), d.m(t, null)) : d && (X(), w(d, 1, 1, () => {
        d = null;
      }), ee()), /*error*/
      c[0] ? h ? (h.p(c, m), m & /*error*/
      1 && _(h, 1)) : (h = wi(c), h.c(), _(h, 1), h.m(e, null)) : h && (X(), w(h, 1, 1, () => {
        h = null;
      }), ee()), (!a || m & /*error*/
      1) && W(
        e,
        "error",
        /*error*/
        c[0]
      ), (!a || m & /*disabled*/
      4) && W(
        e,
        "disabled",
        /*disabled*/
        c[2]
      ), (!a || m & /*focused*/
      8) && W(
        e,
        "focused",
        /*focused*/
        c[3]
      ), (!a || m & /*clickable*/
      16) && W(
        e,
        "clickable",
        /*clickable*/
        c[4]
      ), (!a || m & /*compact*/
      64) && W(
        e,
        "compact",
        /*compact*/
        c[6]
      ), (!a || m & /*autoHeight*/
      32) && W(
        e,
        "auto-height",
        /*autoHeight*/
        c[5]
      );
    },
    i(c) {
      a || (_(u, c), _(d), _(h), a = !0);
    },
    o(c) {
      w(u, c), w(d), w(h), a = !1;
    },
    d(c) {
      c && L(e), u && u.d(c), d && d.d(), h && h.d(), r[12](null), l = !1, o();
    }
  };
}
function c0(r, e, t) {
  let { $$slots: n = {}, $$scope: s } = e, { disabled: i = !1 } = e, { error: a = null } = e, { focused: l = !1 } = e, { clickable: o = !1 } = e, { validate: f } = e, { value: u } = e, { ref: d = void 0 } = e, { autoHeight: h = void 0 } = e, { compact: c = !1 } = e;
  const m = Gt("fancy-form"), g = Math.random().toString(), p = {
    validate: () => (f && t(0, a = f(u)), !a)
  };
  ta(() => (m && m.registerField(g, p), () => {
    m && m.unregisterField(g);
  }));
  function y(v) {
    cn.call(this, r, v);
  }
  function b(v) {
    Oe[v ? "unshift" : "push"](() => {
      d = v, t(1, d);
    });
  }
  return r.$$set = (v) => {
    "disabled" in v && t(2, i = v.disabled), "error" in v && t(0, a = v.error), "focused" in v && t(3, l = v.focused), "clickable" in v && t(4, o = v.clickable), "validate" in v && t(7, f = v.validate), "value" in v && t(8, u = v.value), "ref" in v && t(1, d = v.ref), "autoHeight" in v && t(5, h = v.autoHeight), "compact" in v && t(6, c = v.compact), "$$scope" in v && t(9, s = v.$$scope);
  }, [
    a,
    d,
    i,
    l,
    o,
    h,
    c,
    f,
    u,
    s,
    n,
    y,
    b
  ];
}
class d0 extends Te {
  constructor(e) {
    super(), Ee(this, e, c0, f0, ve, {
      disabled: 2,
      error: 0,
      focused: 3,
      clickable: 4,
      validate: 7,
      value: 8,
      ref: 1,
      autoHeight: 5,
      compact: 6
    });
  }
}
function h0(r) {
  let e, t;
  const n = (
    /*#slots*/
    r[2].default
  ), s = Ft(
    n,
    r,
    /*$$scope*/
    r[1],
    null
  );
  return {
    c() {
      e = I("div"), s && s.c(), T(e, "class", "svelte-wcobo1"), W(
        e,
        "placeholder",
        /*placeholder*/
        r[0]
      );
    },
    m(i, a) {
      C(i, e, a), s && s.m(e, null), t = !0;
    },
    p(i, [a]) {
      s && s.p && (!t || a & /*$$scope*/
      2) && Dt(
        s,
        n,
        i,
        /*$$scope*/
        i[1],
        t ? Nt(
          n,
          /*$$scope*/
          i[1],
          a,
          null
        ) : Mt(
          /*$$scope*/
          i[1]
        ),
        null
      ), (!t || a & /*placeholder*/
      1) && W(
        e,
        "placeholder",
        /*placeholder*/
        i[0]
      );
    },
    i(i) {
      t || (_(s, i), t = !0);
    },
    o(i) {
      w(s, i), t = !1;
    },
    d(i) {
      i && L(e), s && s.d(i);
    }
  };
}
function m0(r, e, t) {
  let { $$slots: n = {}, $$scope: s } = e, { placeholder: i = !0 } = e;
  return r.$$set = (a) => {
    "placeholder" in a && t(0, i = a.placeholder), "$$scope" in a && t(1, s = a.$$scope);
  }, [i, s, n];
}
class p0 extends Te {
  constructor(e) {
    super(), Ee(this, e, m0, h0, ve, { placeholder: 0 });
  }
}
function g0(r) {
  let e, t;
  const n = (
    /*#slots*/
    r[2].default
  ), s = Ft(
    n,
    r,
    /*$$scope*/
    r[1],
    null
  );
  return {
    c() {
      e = I("div"), s && s.c(), T(e, "class", "fancy-form svelte-1wjd4hl");
    },
    m(i, a) {
      C(i, e, a), s && s.m(e, null), t = !0;
    },
    p(i, [a]) {
      s && s.p && (!t || a & /*$$scope*/
      2) && Dt(
        s,
        n,
        i,
        /*$$scope*/
        i[1],
        t ? Nt(
          n,
          /*$$scope*/
          i[1],
          a,
          null
        ) : Mt(
          /*$$scope*/
          i[1]
        ),
        null
      );
    },
    i(i) {
      t || (_(s, i), t = !0);
    },
    o(i) {
      w(s, i), t = !1;
    },
    d(i) {
      i && L(e), s && s.d(i);
    }
  };
}
function y0(r, e, t) {
  let { $$slots: n = {}, $$scope: s } = e, i = {};
  In("fancy-form", {
    registerField: (l, o) => {
      i = { ...i, [l]: o };
    },
    unregisterField: (l) => {
      delete i[l], i = i;
    }
  });
  const a = () => {
    let l = !0;
    return Object.values(i).forEach((o) => {
      o.validate() || (l = !1);
    }), l;
  };
  return r.$$set = (l) => {
    "$$scope" in l && t(1, s = l.$$scope);
  }, [a, s, n];
}
class _0 extends Te {
  constructor(e) {
    super(), Ee(this, e, y0, g0, ve, { validate: 0 });
  }
  get validate() {
    return this.$$.ctx[0];
  }
}
function ki(r) {
  let e, t;
  return e = new p0({
    props: {
      placeholder: (
        /*placeholder*/
        r[9]
      ),
      $$slots: { default: [b0] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s & /*placeholder*/
      512 && (i.placeholder = /*placeholder*/
      n[9]), s & /*$$scope, label*/
      131076 && (i.$$scope = { dirty: s, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function b0(r) {
  let e;
  return {
    c() {
      e = le(
        /*label*/
        r[2]
      );
    },
    m(t, n) {
      C(t, e, n);
    },
    p(t, n) {
      n & /*label*/
      4 && ue(
        e,
        /*label*/
        t[2]
      );
    },
    d(t) {
      t && L(e);
    }
  };
}
function Oi(r) {
  let e, t, n;
  return {
    c() {
      e = I("div"), t = le(
        /*suffix*/
        r[6]
      ), T(e, "class", "suffix svelte-2823mm");
    },
    m(s, i) {
      C(s, e, i), j(e, t);
    },
    p(s, i) {
      i & /*suffix*/
      64 && ue(
        t,
        /*suffix*/
        s[6]
      );
    },
    i(s) {
      s && (n || ea(() => {
        n = Ml(e, Nl, { duration: 130 }), n.start();
      }));
    },
    o: Se,
    d(s) {
      s && L(e);
    }
  };
}
function v0(r) {
  let e, t, n, s, i, a, l, o, f, u = (
    /*label*/
    r[2] && ki(r)
  ), d = (
    /*suffix*/
    r[6] && !/*placeholder*/
    r[9] && Oi(r)
  );
  return {
    c() {
      u && u.c(), e = Y(), t = I("input"), i = Y(), d && d.c(), a = $e(), t.disabled = /*disabled*/
      r[4], t.value = n = /*value*/
      r[0] || "", T(t, "type", s = /*type*/
      r[3] || "text"), T(t, "class", "svelte-2823mm"), W(
        t,
        "placeholder",
        /*placeholder*/
        r[9]
      );
    },
    m(h, c) {
      u && u.m(h, c), C(h, e, c), C(h, t, c), r[15](t), C(h, i, c), d && d.m(h, c), C(h, a, c), l = !0, o || (f = [
        fe(
          t,
          "input",
          /*onChange*/
          r[10]
        ),
        fe(
          t,
          "focus",
          /*focus_handler*/
          r[14]
        ),
        fe(
          t,
          "blur",
          /*onBlur*/
          r[11]
        )
      ], o = !0);
    },
    p(h, c) {
      /*label*/
      h[2] ? u ? (u.p(h, c), c & /*label*/
      4 && _(u, 1)) : (u = ki(h), u.c(), _(u, 1), u.m(e.parentNode, e)) : u && (X(), w(u, 1, 1, () => {
        u = null;
      }), ee()), (!l || c & /*disabled*/
      16) && (t.disabled = /*disabled*/
      h[4]), (!l || c & /*value*/
      1 && n !== (n = /*value*/
      h[0] || "") && t.value !== n) && (t.value = n), (!l || c & /*type*/
      8 && s !== (s = /*type*/
      h[3] || "text")) && T(t, "type", s), (!l || c & /*placeholder*/
      512) && W(
        t,
        "placeholder",
        /*placeholder*/
        h[9]
      ), /*suffix*/
      h[6] && !/*placeholder*/
      h[9] ? d ? (d.p(h, c), c & /*suffix, placeholder*/
      576 && _(d, 1)) : (d = Oi(h), d.c(), _(d, 1), d.m(a.parentNode, a)) : d && (d.d(1), d = null);
    },
    i(h) {
      l || (_(u), _(d), l = !0);
    },
    o(h) {
      w(u), l = !1;
    },
    d(h) {
      h && (L(e), L(t), L(i), L(a)), u && u.d(h), r[15](null), d && d.d(h), o = !1, Ct(f);
    }
  };
}
function w0(r) {
  let e, t;
  return e = new d0({
    props: {
      error: (
        /*error*/
        r[1]
      ),
      value: (
        /*value*/
        r[0]
      ),
      validate: (
        /*validate*/
        r[5]
      ),
      disabled: (
        /*disabled*/
        r[4]
      ),
      focused: (
        /*focused*/
        r[7]
      ),
      $$slots: { default: [v0] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, [s]) {
      const i = {};
      s & /*error*/
      2 && (i.error = /*error*/
      n[1]), s & /*value*/
      1 && (i.value = /*value*/
      n[0]), s & /*validate*/
      32 && (i.validate = /*validate*/
      n[5]), s & /*disabled*/
      16 && (i.disabled = /*disabled*/
      n[4]), s & /*focused*/
      128 && (i.focused = /*focused*/
      n[7]), s & /*$$scope, suffix, placeholder, disabled, value, type, ref, focused, label*/
      132061 && (i.$$scope = { dirty: s, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function k0(r, e, t) {
  let n, { label: s } = e, { value: i } = e, { type: a = "text" } = e, { disabled: l = !1 } = e, { error: o = null } = e, { validate: f = null } = e, { suffix: u = null } = e, { validateOn: d = "change" } = e;
  const h = Rr();
  let c, m = !1, g = !1;
  const p = (k) => {
    const S = k.target.value;
    h("change", S), t(0, i = S), f && (o || d === "change") && t(1, o = f(S));
  }, y = (k) => {
    t(7, m = !1);
    const S = k.target.value;
    h("blur", S), f && d === "blur" && t(1, o = f(S));
  };
  ta(() => {
    const k = setInterval(
      () => {
        t(13, g = c == null ? void 0 : c.matches(":-webkit-autofill")), g && clearInterval(k);
      },
      100
    ), S = setTimeout(
      () => {
        clearInterval(k);
      },
      2e3
    );
    return () => {
      clearInterval(k), clearTimeout(S);
    };
  });
  const b = () => t(7, m = !0);
  function v(k) {
    Oe[k ? "unshift" : "push"](() => {
      c = k, t(8, c);
    });
  }
  return r.$$set = (k) => {
    "label" in k && t(2, s = k.label), "value" in k && t(0, i = k.value), "type" in k && t(3, a = k.type), "disabled" in k && t(4, l = k.disabled), "error" in k && t(1, o = k.error), "validate" in k && t(5, f = k.validate), "suffix" in k && t(6, u = k.suffix), "validateOn" in k && t(12, d = k.validateOn);
  }, r.$$.update = () => {
    r.$$.dirty & /*autofilled, focused, value*/
    8321 && t(9, n = !g && !m && !i);
  }, [
    i,
    o,
    s,
    a,
    l,
    f,
    u,
    m,
    c,
    n,
    p,
    y,
    d,
    g,
    b,
    v
  ];
}
class Si extends Te {
  constructor(e) {
    super(), Ee(this, e, k0, w0, ve, {
      label: 2,
      value: 0,
      type: 3,
      disabled: 4,
      error: 1,
      validate: 5,
      suffix: 6,
      validateOn: 12
    });
  }
}
const O0 = (r) => ({ open: r & /*open*/
1024 }), Ti = (r) => ({ open: (
  /*open*/
  r[10]
) });
function S0(r) {
  let e;
  const t = (
    /*#slots*/
    r[17].default
  ), n = Ft(
    t,
    r,
    /*$$scope*/
    r[22],
    null
  );
  return {
    c() {
      n && n.c();
    },
    m(s, i) {
      n && n.m(s, i), e = !0;
    },
    p(s, i) {
      n && n.p && (!e || i & /*$$scope*/
      4194304) && Dt(
        n,
        t,
        s,
        /*$$scope*/
        s[22],
        e ? Nt(
          t,
          /*$$scope*/
          s[22],
          i,
          null
        ) : Mt(
          /*$$scope*/
          s[22]
        ),
        null
      );
    },
    i(s) {
      e || (_(n, s), e = !0);
    },
    o(s) {
      w(n, s), e = !1;
    },
    d(s) {
      n && n.d(s);
    }
  };
}
function T0(r) {
  let e, t;
  return e = new Zl({
    props: {
      $$slots: { default: [S0] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s & /*$$scope*/
      4194304 && (i.$$scope = { dirty: s, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function E0(r) {
  let e, t, n, s, i, a, l;
  const o = (
    /*#slots*/
    r[17].control
  ), f = Ft(
    o,
    r,
    /*$$scope*/
    r[22],
    Ti
  );
  function u(h) {
    r[19](h);
  }
  let d = {
    anchor: (
      /*anchor*/
      r[8]
    ),
    align: (
      /*align*/
      r[0]
    ),
    portalTarget: (
      /*portalTarget*/
      r[1]
    ),
    animate: (
      /*animate*/
      r[3]
    ),
    offset: (
      /*offset*/
      r[4]
    ),
    useAnchorWidth: (
      /*useAnchorWidth*/
      r[5]
    ),
    resizable: !1,
    borderRadius: (
      /*roundedPopover*/
      r[6] ? "12px" : void 0
    ),
    $$slots: { default: [T0] },
    $$scope: { ctx: r }
  };
  return (
    /*open*/
    r[10] !== void 0 && (d.open = /*open*/
    r[10]), n = new Cl({ props: d }), r[18](n), Oe.push(() => ct(n, "open", u)), n.$on(
      "open",
      /*open_handler*/
      r[20]
    ), n.$on(
      "close",
      /*close_handler*/
      r[21]
    ), n.$on("mouseenter", function() {
      He(
        /*openOnHover*/
        r[2] ? (
          /*cancelHide*/
          r[14]
        ) : null
      ) && /*openOnHover*/
      (r[2] ? (
        /*cancelHide*/
        r[14]
      ) : null).apply(this, arguments);
    }), n.$on("mouseleave", function() {
      He(
        /*openOnHover*/
        r[2] ? (
          /*queueHide*/
          r[13]
        ) : null
      ) && /*openOnHover*/
      (r[2] ? (
        /*queueHide*/
        r[13]
      ) : null).apply(this, arguments);
    }), {
      c() {
        e = I("div"), f && f.c(), t = Y(), R(n.$$.fragment);
      },
      m(h, c) {
        C(h, e, c), f && f.m(e, null), C(h, t, c), z(n, h, c), i = !0, a || (l = [
          Kt(
            /*getAnchor*/
            r[11].call(null, e)
          ),
          fe(e, "click", function() {
            He(
              /*openOnHover*/
              r[2] ? null : (
                /*openMenu*/
                r[12]
              )
            ) && /*openOnHover*/
            (r[2] ? null : (
              /*openMenu*/
              r[12]
            )).apply(this, arguments);
          }),
          fe(e, "mouseenter", function() {
            He(
              /*openOnHover*/
              r[2] ? (
                /*show*/
                r[7]
              ) : null
            ) && /*openOnHover*/
            (r[2] ? (
              /*show*/
              r[7]
            ) : null).apply(this, arguments);
          }),
          fe(e, "mouseleave", function() {
            He(
              /*openOnHover*/
              r[2] ? (
                /*queueHide*/
                r[13]
              ) : null
            ) && /*openOnHover*/
            (r[2] ? (
              /*queueHide*/
              r[13]
            ) : null).apply(this, arguments);
          })
        ], a = !0);
      },
      p(h, [c]) {
        r = h, f && f.p && (!i || c & /*$$scope, open*/
        4195328) && Dt(
          f,
          o,
          r,
          /*$$scope*/
          r[22],
          i ? Nt(
            o,
            /*$$scope*/
            r[22],
            c,
            O0
          ) : Mt(
            /*$$scope*/
            r[22]
          ),
          Ti
        );
        const m = {};
        c & /*anchor*/
        256 && (m.anchor = /*anchor*/
        r[8]), c & /*align*/
        1 && (m.align = /*align*/
        r[0]), c & /*portalTarget*/
        2 && (m.portalTarget = /*portalTarget*/
        r[1]), c & /*animate*/
        8 && (m.animate = /*animate*/
        r[3]), c & /*offset*/
        16 && (m.offset = /*offset*/
        r[4]), c & /*useAnchorWidth*/
        32 && (m.useAnchorWidth = /*useAnchorWidth*/
        r[5]), c & /*roundedPopover*/
        64 && (m.borderRadius = /*roundedPopover*/
        r[6] ? "12px" : void 0), c & /*$$scope*/
        4194304 && (m.$$scope = { dirty: c, ctx: r }), !s && c & /*open*/
        1024 && (s = !0, m.open = /*open*/
        r[10], dt(() => s = !1)), n.$set(m);
      },
      i(h) {
        i || (_(f, h), _(n.$$.fragment, h), i = !0);
      },
      o(h) {
        w(f, h), w(n.$$.fragment, h), i = !1;
      },
      d(h) {
        h && (L(e), L(t)), f && f.d(h), r[18](null), q(n, h), a = !1, Ct(l);
      }
    }
  );
}
function F0(r, e, t) {
  let { $$slots: n = {}, $$scope: s } = e, { disabled: i = !1 } = e, { align: a = "left" } = e, { portalTarget: l = void 0 } = e, { openOnHover: o = !1 } = e, { animate: f = !0 } = e, { offset: u = void 0 } = e, { useAnchorWidth: d = !1 } = e, { roundedPopover: h = !1 } = e;
  const c = Gt("actionMenu");
  let m, g, p, y = !1;
  function b(V) {
    t(8, m = V.firstChild ?? void 0);
  }
  const v = () => {
    N(), g.show();
  }, k = () => {
    g.hide();
  }, S = () => {
    k(), c == null || c.hide();
  }, E = (V) => {
    i || (V.stopPropagation(), v());
  }, A = () => {
    p = setTimeout(k, 10);
  }, N = () => {
    clearTimeout(p);
  };
  In("actionMenu", { show: v, hide: k, hideAll: S });
  function Z(V) {
    Oe[V ? "unshift" : "push"](() => {
      g = V, t(9, g);
    });
  }
  function H(V) {
    y = V, t(10, y);
  }
  function G(V) {
    cn.call(this, r, V);
  }
  function ie(V) {
    cn.call(this, r, V);
  }
  return r.$$set = (V) => {
    "disabled" in V && t(15, i = V.disabled), "align" in V && t(0, a = V.align), "portalTarget" in V && t(1, l = V.portalTarget), "openOnHover" in V && t(2, o = V.openOnHover), "animate" in V && t(3, f = V.animate), "offset" in V && t(4, u = V.offset), "useAnchorWidth" in V && t(5, d = V.useAnchorWidth), "roundedPopover" in V && t(6, h = V.roundedPopover), "$$scope" in V && t(22, s = V.$$scope);
  }, [
    a,
    l,
    o,
    f,
    u,
    d,
    h,
    v,
    m,
    g,
    y,
    b,
    E,
    A,
    N,
    i,
    k,
    n,
    Z,
    H,
    G,
    ie,
    s
  ];
}
class D0 extends Te {
  constructor(e) {
    super(), Ee(this, e, F0, E0, ve, {
      disabled: 15,
      align: 0,
      portalTarget: 1,
      openOnHover: 2,
      animate: 3,
      offset: 4,
      useAnchorWidth: 5,
      roundedPopover: 6,
      show: 7,
      hide: 16
    });
  }
  get show() {
    return this.$$.ctx[7];
  }
  get hide() {
    return this.$$.ctx[16];
  }
}
function Ei(r) {
  return r != null && r !== "" || "This field is required";
}
function Fi(r, ...e) {
  let t = !1;
  const n = Er(r || ""), s = ys(n, () => t || (t = !0, !1)), i = ys(
    [n, s],
    ([a, l]) => l && M0(a, e)
  );
  return [n, i, s];
}
function M0(r, e) {
  const t = e.find((n) => n(r) !== !0);
  return t && t(r);
}
function N0(r) {
  var d, h, c;
  let e, t, n, s, i, a;
  function l(m) {
    r[16](m);
  }
  let o = {
    label: (
      /*labels*/
      ((d = r[1]) == null ? void 0 : d.passwordLabel) ?? "Password"
    ),
    type: "password",
    error: (
      /*firstPasswordError*/
      r[2]
    )
  };
  /*$firstPassword*/
  r[4] !== void 0 && (o.value = /*$firstPassword*/
  r[4]), e = new Si({ props: o }), Oe.push(() => ct(e, "value", l));
  function f(m) {
    r[17](m);
  }
  let u = {
    label: (
      /*labels*/
      ((h = r[1]) == null ? void 0 : h.repeatLabel) ?? "Repeat password"
    ),
    type: "password",
    error: (
      /*$repeatTouched*/
      r[5] && /*$firstPassword*/
      r[4] !== /*$repeatPassword*/
      r[3] && /*labels*/
      (((c = r[1]) == null ? void 0 : c.mismatchText) ?? "Passwords must match")
    )
  };
  return (
    /*$repeatPassword*/
    r[3] !== void 0 && (u.value = /*$repeatPassword*/
    r[3]), s = new Si({ props: u }), Oe.push(() => ct(s, "value", f)), {
      c() {
        R(e.$$.fragment), n = Y(), R(s.$$.fragment);
      },
      m(m, g) {
        z(e, m, g), C(m, n, g), z(s, m, g), a = !0;
      },
      p(m, g) {
        var b, v, k;
        const p = {};
        g & /*labels*/
        2 && (p.label = /*labels*/
        ((b = m[1]) == null ? void 0 : b.passwordLabel) ?? "Password"), g & /*firstPasswordError*/
        4 && (p.error = /*firstPasswordError*/
        m[2]), !t && g & /*$firstPassword*/
        16 && (t = !0, p.value = /*$firstPassword*/
        m[4], dt(() => t = !1)), e.$set(p);
        const y = {};
        g & /*labels*/
        2 && (y.label = /*labels*/
        ((v = m[1]) == null ? void 0 : v.repeatLabel) ?? "Repeat password"), g & /*$repeatTouched, $firstPassword, $repeatPassword, labels*/
        58 && (y.error = /*$repeatTouched*/
        m[5] && /*$firstPassword*/
        m[4] !== /*$repeatPassword*/
        m[3] && /*labels*/
        (((k = m[1]) == null ? void 0 : k.mismatchText) ?? "Passwords must match")), !i && g & /*$repeatPassword*/
        8 && (i = !0, y.value = /*$repeatPassword*/
        m[3], dt(() => i = !1)), s.$set(y);
      },
      i(m) {
        a || (_(e.$$.fragment, m), _(s.$$.fragment, m), a = !0);
      },
      o(m) {
        w(e.$$.fragment, m), w(s.$$.fragment, m), a = !1;
      },
      d(m) {
        m && L(n), q(e, m), q(s, m);
      }
    }
  );
}
function C0(r) {
  let e, t, n = {
    $$slots: { default: [N0] },
    $$scope: { ctx: r }
  };
  return e = new _0({ props: n }), r[18](e), {
    c() {
      R(e.$$.fragment);
    },
    m(s, i) {
      z(e, s, i), t = !0;
    },
    p(s, [i]) {
      const a = {};
      i & /*$$scope, labels, $repeatTouched, $firstPassword, $repeatPassword, firstPasswordError*/
      2097214 && (a.$$scope = { dirty: i, ctx: s }), e.$set(a);
    },
    i(s) {
      t || (_(e.$$.fragment, s), t = !0);
    },
    o(s) {
      w(e.$$.fragment, s), t = !1;
    },
    d(s) {
      r[18](null), q(e, s);
    }
  };
}
function L0(r, e, t) {
  let n, s, i, a, l, o, { passwordForm: f = void 0 } = e, { password: u } = e, { error: d } = e, { minLength: h = "12" } = e, { labels: c = {} } = e;
  const m = (N) => {
    var Z;
    return !N || N.length < parseInt(h) ? ((Z = c == null ? void 0 : c.minLengthText) == null ? void 0 : Z.replace("{minLength}", h)) || `Please enter at least ${h} characters. We recommend using machine generated or random passwords.` : null;
  }, [g, p, y] = Fi("", Ei);
  pe(r, g, (N) => t(4, i = N)), pe(r, p, (N) => t(15, o = N)), pe(r, y, (N) => t(14, l = N));
  const [b, v, k] = Fi("", Ei, m);
  pe(r, b, (N) => t(3, s = N)), pe(r, k, (N) => t(5, a = N));
  function S(N) {
    i = N, g.set(i);
  }
  function E(N) {
    s = N, b.set(s);
  }
  function A(N) {
    Oe[N ? "unshift" : "push"](() => {
      f = N, t(0, f);
    });
  }
  return r.$$set = (N) => {
    "passwordForm" in N && t(0, f = N.passwordForm), "password" in N && t(11, u = N.password), "error" in N && t(12, d = N.error), "minLength" in N && t(13, h = N.minLength), "labels" in N && t(1, c = N.labels);
  }, r.$$.update = () => {
    r.$$.dirty & /*$firstPassword*/
    16 && t(11, u = i), r.$$.dirty & /*$firstTouched, $passwordError, $repeatTouched, password*/
    51232 && t(2, n = l && o || a && m(u)), r.$$.dirty & /*$firstPassword, $firstTouched, $repeatTouched, $repeatPassword, firstPasswordError*/
    16444 && t(12, d = !i || !l || !a || i !== s || n);
  }, [
    f,
    c,
    n,
    s,
    i,
    a,
    g,
    p,
    y,
    b,
    k,
    u,
    d,
    h,
    l,
    o,
    S,
    E,
    A
  ];
}
class V0 extends Te {
  constructor(e) {
    super(), Ee(this, e, L0, C0, ve, {
      passwordForm: 0,
      password: 11,
      error: 12,
      minLength: 13,
      labels: 1
    });
  }
}
function I0(r) {
  let e = (
    /*resolvedLabels*/
    r[3].body + ""
  ), t;
  return {
    c() {
      t = le(e);
    },
    m(n, s) {
      C(n, t, s);
    },
    p(n, s) {
      s & /*resolvedLabels*/
      8 && e !== (e = /*resolvedLabels*/
      n[3].body + "") && ue(t, e);
    },
    d(n) {
      n && L(t);
    }
  };
}
function A0(r) {
  let e, t, n, s, i, a;
  e = new na({
    props: {
      size: "S",
      $$slots: { default: [I0] },
      $$scope: { ctx: r }
    }
  });
  function l(u) {
    r[10](u);
  }
  function o(u) {
    r[11](u);
  }
  let f = {
    minLength: (
      /*passwordMinLength*/
      r[0]
    ),
    labels: (
      /*resolvedLabels*/
      r[3]
    )
  };
  return (
    /*password*/
    r[1] !== void 0 && (f.password = /*password*/
    r[1]), /*error*/
    r[2] !== void 0 && (f.error = /*error*/
    r[2]), n = new V0({ props: f }), Oe.push(() => ct(n, "password", l)), Oe.push(() => ct(n, "error", o)), {
      c() {
        R(e.$$.fragment), t = Y(), R(n.$$.fragment);
      },
      m(u, d) {
        z(e, u, d), C(u, t, d), z(n, u, d), a = !0;
      },
      p(u, d) {
        const h = {};
        d & /*$$scope, resolvedLabels*/
        16392 && (h.$$scope = { dirty: d, ctx: u }), e.$set(h);
        const c = {};
        d & /*passwordMinLength*/
        1 && (c.minLength = /*passwordMinLength*/
        u[0]), d & /*resolvedLabels*/
        8 && (c.labels = /*resolvedLabels*/
        u[3]), !s && d & /*password*/
        2 && (s = !0, c.password = /*password*/
        u[1], dt(() => s = !1)), !i && d & /*error*/
        4 && (i = !0, c.error = /*error*/
        u[2], dt(() => i = !1)), n.$set(c);
      },
      i(u) {
        a || (_(e.$$.fragment, u), _(n.$$.fragment, u), a = !0);
      },
      o(u) {
        w(e.$$.fragment, u), w(n.$$.fragment, u), a = !1;
      },
      d(u) {
        u && L(t), q(e, u), q(n, u);
      }
    }
  );
}
function W0(r) {
  let e, t, n, s;
  return e = new ra({
    props: {
      title: (
        /*resolvedLabels*/
        r[3].title
      ),
      confirmText: (
        /*resolvedLabels*/
        r[3].saveText
      ),
      cancelText: (
        /*resolvedLabels*/
        r[3].cancelText
      ),
      onConfirm: (
        /*updatePassword*/
        r[4]
      ),
      disabled: !!/*error*/
      r[2] || !/*password*/
      r[1],
      $$slots: { default: [A0] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(i, a) {
      z(e, i, a), t = !0, n || (s = fe(
        window,
        "keydown",
        /*handleKeydown*/
        r[5]
      ), n = !0);
    },
    p(i, [a]) {
      const l = {};
      a & /*resolvedLabels*/
      8 && (l.title = /*resolvedLabels*/
      i[3].title), a & /*resolvedLabels*/
      8 && (l.confirmText = /*resolvedLabels*/
      i[3].saveText), a & /*resolvedLabels*/
      8 && (l.cancelText = /*resolvedLabels*/
      i[3].cancelText), a & /*error, password*/
      6 && (l.disabled = !!/*error*/
      i[2] || !/*password*/
      i[1]), a & /*$$scope, passwordMinLength, resolvedLabels, password, error*/
      16399 && (l.$$scope = { dirty: a, ctx: i }), e.$set(l);
    },
    i(i) {
      t || (_(e.$$.fragment, i), t = !0);
    },
    o(i) {
      w(e.$$.fragment, i), t = !1;
    },
    d(i) {
      q(e, i), n = !1, s();
    }
  };
}
function U0(r, e, t) {
  let n, { API: s } = e, { passwordMinLength: i = void 0 } = e, { notifySuccess: a = Fr.success } = e, { notifyError: l = Fr.error } = e;
  const o = Bt("passwordModal");
  let { labels: f = {} } = e;
  const u = Rr();
  let d = "", h = "";
  const c = async () => {
    try {
      await s.updateSelf({ password: d }), a(n.successText), u("save");
    } catch {
      l(n.errorText);
    }
  }, m = (y) => {
    y.key === "Enter" && !h && d && c();
  };
  function g(y) {
    d = y, t(1, d);
  }
  function p(y) {
    h = y, t(2, h);
  }
  return r.$$set = (y) => {
    "API" in y && t(6, s = y.API), "passwordMinLength" in y && t(0, i = y.passwordMinLength), "notifySuccess" in y && t(7, a = y.notifySuccess), "notifyError" in y && t(8, l = y.notifyError), "labels" in y && t(9, f = y.labels);
  }, r.$$.update = () => {
    r.$$.dirty & /*labels*/
    512 && t(3, n = { ...o, ...f });
  }, [
    i,
    d,
    h,
    n,
    c,
    m,
    s,
    a,
    l,
    f,
    g,
    p
  ];
}
class x0 extends Te {
  constructor(e) {
    super(), Ee(this, e, U0, W0, ve, {
      API: 6,
      passwordMinLength: 0,
      notifySuccess: 7,
      notifyError: 8,
      labels: 9
    });
  }
}
function P0(r) {
  let e = (
    /*resolvedLabels*/
    r[1].body + ""
  ), t;
  return {
    c() {
      t = le(e);
    },
    m(n, s) {
      C(n, t, s);
    },
    p(n, s) {
      s & /*resolvedLabels*/
      2 && e !== (e = /*resolvedLabels*/
      n[1].body + "") && ue(t, e);
    },
    d(n) {
      n && L(t);
    }
  };
}
function R0(r) {
  var g;
  let e, t, n, s, i, a, l, o, f, u;
  e = new na({
    props: {
      size: "S",
      $$slots: { default: [P0] },
      $$scope: { ctx: r }
    }
  }), n = new Qr({
    props: {
      disabled: !0,
      value: (
        /*user*/
        ((g = r[0]) == null ? void 0 : g.email) || ""
      ),
      label: (
        /*resolvedLabels*/
        r[1].emailLabel
      )
    }
  });
  function d(p) {
    r[9](p);
  }
  let h = {
    label: (
      /*resolvedLabels*/
      r[1].firstNameLabel
    )
  };
  /*$values*/
  r[2].firstName !== void 0 && (h.value = /*$values*/
  r[2].firstName), i = new Qr({ props: h }), Oe.push(() => ct(i, "value", d));
  function c(p) {
    r[10](p);
  }
  let m = {
    label: (
      /*resolvedLabels*/
      r[1].lastNameLabel
    )
  };
  return (
    /*$values*/
    r[2].lastName !== void 0 && (m.value = /*$values*/
    r[2].lastName), o = new Qr({ props: m }), Oe.push(() => ct(o, "value", c)), {
      c() {
        R(e.$$.fragment), t = Y(), R(n.$$.fragment), s = Y(), R(i.$$.fragment), l = Y(), R(o.$$.fragment);
      },
      m(p, y) {
        z(e, p, y), C(p, t, y), z(n, p, y), C(p, s, y), z(i, p, y), C(p, l, y), z(o, p, y), u = !0;
      },
      p(p, y) {
        var E;
        const b = {};
        y & /*$$scope, resolvedLabels*/
        8194 && (b.$$scope = { dirty: y, ctx: p }), e.$set(b);
        const v = {};
        y & /*user*/
        1 && (v.value = /*user*/
        ((E = p[0]) == null ? void 0 : E.email) || ""), y & /*resolvedLabels*/
        2 && (v.label = /*resolvedLabels*/
        p[1].emailLabel), n.$set(v);
        const k = {};
        y & /*resolvedLabels*/
        2 && (k.label = /*resolvedLabels*/
        p[1].firstNameLabel), !a && y & /*$values*/
        4 && (a = !0, k.value = /*$values*/
        p[2].firstName, dt(() => a = !1)), i.$set(k);
        const S = {};
        y & /*resolvedLabels*/
        2 && (S.label = /*resolvedLabels*/
        p[1].lastNameLabel), !f && y & /*$values*/
        4 && (f = !0, S.value = /*$values*/
        p[2].lastName, dt(() => f = !1)), o.$set(S);
      },
      i(p) {
        u || (_(e.$$.fragment, p), _(n.$$.fragment, p), _(i.$$.fragment, p), _(o.$$.fragment, p), u = !0);
      },
      o(p) {
        w(e.$$.fragment, p), w(n.$$.fragment, p), w(i.$$.fragment, p), w(o.$$.fragment, p), u = !1;
      },
      d(p) {
        p && (L(t), L(s), L(l)), q(e, p), q(n, p), q(i, p), q(o, p);
      }
    }
  );
}
function z0(r) {
  let e, t;
  return e = new ra({
    props: {
      title: (
        /*resolvedLabels*/
        r[1].title
      ),
      confirmText: (
        /*resolvedLabels*/
        r[1].saveText
      ),
      cancelText: (
        /*resolvedLabels*/
        r[1].cancelText
      ),
      onConfirm: (
        /*updateInfo*/
        r[4]
      ),
      $$slots: { default: [R0] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, [s]) {
      const i = {};
      s & /*resolvedLabels*/
      2 && (i.title = /*resolvedLabels*/
      n[1].title), s & /*resolvedLabels*/
      2 && (i.confirmText = /*resolvedLabels*/
      n[1].saveText), s & /*resolvedLabels*/
      2 && (i.cancelText = /*resolvedLabels*/
      n[1].cancelText), s & /*$$scope, resolvedLabels, $values, user*/
      8199 && (i.$$scope = { dirty: s, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function q0(r, e, t) {
  let n, s, { user: i = void 0 } = e, { API: a } = e, { notifySuccess: l = Fr.success } = e, { notifyError: o = Fr.error } = e;
  const f = Bt("profileModal");
  let { labels: u = {} } = e;
  const d = Rr(), h = Er({
    firstName: i == null ? void 0 : i.firstName,
    lastName: i == null ? void 0 : i.lastName
  });
  pe(r, h, (p) => t(2, s = p));
  const c = async () => {
    try {
      await a.updateSelf(s), l(n.successText), d("save");
    } catch (p) {
      console.error(p), o(n.errorText);
    }
  };
  function m(p) {
    r.$$.not_equal(s.firstName, p) && (s.firstName = p, h.set(s));
  }
  function g(p) {
    r.$$.not_equal(s.lastName, p) && (s.lastName = p, h.set(s));
  }
  return r.$$set = (p) => {
    "user" in p && t(0, i = p.user), "API" in p && t(5, a = p.API), "notifySuccess" in p && t(6, l = p.notifySuccess), "notifyError" in p && t(7, o = p.notifyError), "labels" in p && t(8, u = p.labels);
  }, r.$$.update = () => {
    r.$$.dirty & /*labels*/
    256 && t(1, n = { ...f, ...u });
  }, [
    i,
    n,
    s,
    h,
    c,
    a,
    l,
    o,
    u,
    m,
    g
  ];
}
class j0 extends Te {
  constructor(e) {
    super(), Ee(this, e, q0, z0, ve, {
      user: 0,
      API: 5,
      notifySuccess: 6,
      notifyError: 7,
      labels: 8
    });
  }
}
const Tr = [];
let Xo;
function el(r) {
  const e = r.pattern.test(Xo);
  Di(r, r.className, e), Di(r, r.inactiveClassName, !e);
}
function Di(r, e, t) {
  (e || "").split(" ").forEach((n) => {
    n && (r.node.classList.remove(n), t && r.node.classList.add(n));
  });
}
Ll.subscribe((r) => {
  Xo = r.location + (r.querystring ? "?" + r.querystring : ""), Tr.map(el);
});
function tl(r, e) {
  if (e && (typeof e == "string" || typeof e == "object" && e instanceof RegExp) ? e = {
    path: e
  } : e = e || {}, !e.path && r.hasAttribute("href") && (e.path = r.getAttribute("href"), e.path && e.path.length > 1 && e.path.charAt(0) == "#" && (e.path = e.path.substring(1))), e.className || (e.className = "active"), !e.path || typeof e.path == "string" && (e.path.length < 1 || e.path.charAt(0) != "/" && e.path.charAt(0) != "*"))
    throw Error('Invalid value for "path" argument');
  const { pattern: t } = typeof e.path == "string" ? Vl(e.path) : { pattern: e.path }, n = {
    node: r,
    className: e.className,
    inactiveClassName: e.inactiveClassName,
    pattern: t
  };
  return Tr.push(n), el(n), {
    // When the element is destroyed, remove it from the list
    destroy() {
      Tr.splice(Tr.indexOf(n), 1);
    }
  };
}
function Mi(r, e, t) {
  const n = r.slice();
  return n[26] = e[t], n;
}
function $0(r) {
  let e = (
    /*renderKey*/
    r[12]
  ), t, n, s = Li(r);
  return {
    c() {
      s.c(), t = $e();
    },
    m(i, a) {
      s.m(i, a), C(i, t, a), n = !0;
    },
    p(i, a) {
      a & /*renderKey*/
      4096 && ve(e, e = /*renderKey*/
      i[12]) ? (X(), w(s, 1, 1, Se), ee(), s = Li(i), s.c(), _(s, 1), s.m(t.parentNode, t)) : s.p(i, a);
    },
    i(i) {
      n || (_(s), n = !0);
    },
    o(i) {
      w(s), n = !1;
    },
    d(i) {
      i && L(t), s.d(i);
    }
  };
}
function Z0(r) {
  let e, t, n, s;
  const i = [ep, X0], a = [];
  function l(o, f) {
    return (
      /*internalLink*/
      o[5] ? 0 : 1
    );
  }
  return t = l(r), n = a[t] = i[t](r), {
    c() {
      e = I("div"), n.c(), T(e, "class", "link");
    },
    m(o, f) {
      C(o, e, f), a[t].m(e, null), s = !0;
    },
    p(o, f) {
      let u = t;
      t = l(o), t === u ? a[t].p(o, f) : (X(), w(a[u], 1, 1, () => {
        a[u] = null;
      }), ee(), n = a[t], n ? n.p(o, f) : (n = a[t] = i[t](o), n.c()), _(n, 1), n.m(e, null));
    },
    i(o) {
      s || (_(n), s = !0);
    },
    o(o) {
      w(n), s = !1;
    },
    d(o) {
      o && L(e), a[t].d();
    }
  };
}
function H0(r) {
  let e, t, n, s, i, a, l = (
    /*icon*/
    r[4] && Ni(r)
  );
  return i = new Pe({
    props: {
      name: (
        /*caret*/
        r[14]
      ),
      color: "var(--navTextColor)",
      size: "S"
    }
  }), {
    c() {
      l && l.c(), e = Y(), t = I("span"), n = le(
        /*text*/
        r[2]
      ), s = Y(), R(i.$$.fragment), T(t, "class", "svelte-b449hq");
    },
    m(o, f) {
      l && l.m(o, f), C(o, e, f), C(o, t, f), j(t, n), C(o, s, f), z(i, o, f), a = !0;
    },
    p(o, f) {
      /*icon*/
      o[4] ? l ? (l.p(o, f), f & /*icon*/
      16 && _(l, 1)) : (l = Ni(o), l.c(), _(l, 1), l.m(e.parentNode, e)) : l && (X(), w(l, 1, 1, () => {
        l = null;
      }), ee()), (!a || f & /*text*/
      4) && ue(
        n,
        /*text*/
        o[2]
      );
      const u = {};
      f & /*caret*/
      16384 && (u.name = /*caret*/
      o[14]), i.$set(u);
    },
    i(o) {
      a || (_(l), _(i.$$.fragment, o), a = !0);
    },
    o(o) {
      w(l), w(i.$$.fragment, o), a = !1;
    },
    d(o) {
      o && (L(e), L(t), L(s)), l && l.d(o), q(i, o);
    }
  };
}
function B0(r) {
  let e, t;
  return e = new An({
    props: {
      text: (
        /*text*/
        r[2]
      ),
      position: Wn.Right,
      $$slots: { default: [J0] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s & /*text*/
      4 && (i.text = /*text*/
      n[2]), s & /*$$scope, icon, collapsedText*/
      536879120 && (i.$$scope = { dirty: s, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function Ni(r) {
  let e, t;
  return e = new Pe({
    props: {
      name: (
        /*icon*/
        r[4]
      ),
      color: "var(--navTextColor)",
      size: "S"
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s & /*icon*/
      16 && (i.name = /*icon*/
      n[4]), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function Y0(r) {
  let e, t;
  return {
    c() {
      e = I("span"), t = le(
        /*collapsedText*/
        r[13]
      ), T(e, "class", "nav-item-letter svelte-b449hq");
    },
    m(n, s) {
      C(n, e, s), j(e, t);
    },
    p(n, s) {
      s & /*collapsedText*/
      8192 && ue(
        t,
        /*collapsedText*/
        n[13]
      );
    },
    i: Se,
    o: Se,
    d(n) {
      n && L(e);
    }
  };
}
function G0(r) {
  let e, t;
  return e = new Pe({
    props: {
      name: (
        /*icon*/
        r[4]
      ),
      color: "var(--navTextColor)",
      size: "S"
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s & /*icon*/
      16 && (i.name = /*icon*/
      n[4]), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function J0(r) {
  let e, t, n, s;
  const i = [G0, Y0], a = [];
  function l(o, f) {
    return (
      /*icon*/
      o[4] ? 0 : 1
    );
  }
  return e = l(r), t = a[e] = i[e](r), {
    c() {
      t.c(), n = $e();
    },
    m(o, f) {
      a[e].m(o, f), C(o, n, f), s = !0;
    },
    p(o, f) {
      let u = e;
      e = l(o), e === u ? a[e].p(o, f) : (X(), w(a[u], 1, 1, () => {
        a[u] = null;
      }), ee(), t = a[e], t ? t.p(o, f) : (t = a[e] = i[e](o), t.c()), _(t, 1), t.m(n.parentNode, n));
    },
    i(o) {
      s || (_(t), s = !0);
    },
    o(o) {
      w(t), s = !1;
    },
    d(o) {
      o && L(n), a[e].d(o);
    }
  };
}
function K0(r) {
  let e, t = (
    /*subLink*/
    r[26].text + ""
  ), n, s, i, a, l;
  return {
    c() {
      e = I("a"), n = le(t), s = Y(), T(e, "href", i = /*subLink*/
      r[26].url), T(e, "class", "svelte-b449hq");
    },
    m(o, f) {
      C(o, e, f), j(e, n), j(e, s), a || (l = fe(
        e,
        "click",
        /*onClickLink*/
        r[16]
      ), a = !0);
    },
    p(o, f) {
      f & /*subLinks*/
      8 && t !== (t = /*subLink*/
      o[26].text + "") && ue(n, t), f & /*subLinks*/
      8 && i !== (i = /*subLink*/
      o[26].url) && T(e, "href", i);
    },
    d(o) {
      o && L(e), a = !1, l();
    }
  };
}
function Q0(r) {
  let e, t = (
    /*subLink*/
    r[26].text + ""
  ), n, s, i, a, l, o;
  return {
    c() {
      e = I("a"), n = le(t), s = Y(), T(e, "href", i = "#" + /*subLink*/
      r[26].url), T(e, "class", "sublink svelte-b449hq"), W(e, "active", !1), W(
        e,
        "builderActive",
        /*isBuilderActive*/
        r[11](
          /*subLink*/
          r[26].url
        )
      );
    },
    m(f, u) {
      C(f, e, u), j(e, n), j(e, s), l || (o = [
        fe(
          e,
          "click",
          /*onClickLink*/
          r[16]
        ),
        Kt(a = tl.call(
          null,
          e,
          /*subLink*/
          r[26].url
        ))
      ], l = !0);
    },
    p(f, u) {
      r = f, u & /*subLinks*/
      8 && t !== (t = /*subLink*/
      r[26].text + "") && ue(n, t), u & /*subLinks*/
      8 && i !== (i = "#" + /*subLink*/
      r[26].url) && T(e, "href", i), a && He(a.update) && u & /*subLinks*/
      8 && a.update.call(
        null,
        /*subLink*/
        r[26].url
      ), u & /*isBuilderActive, subLinks*/
      2056 && W(
        e,
        "builderActive",
        /*isBuilderActive*/
        r[11](
          /*subLink*/
          r[26].url
        )
      );
    },
    d(f) {
      f && L(e), l = !1, Ct(o);
    }
  };
}
function Ci(r) {
  let e;
  function t(i, a) {
    return (
      /*subLink*/
      i[26].internalLink ? Q0 : K0
    );
  }
  let n = t(r), s = n(r);
  return {
    c() {
      s.c(), e = $e();
    },
    m(i, a) {
      s.m(i, a), C(i, e, a);
    },
    p(i, a) {
      n === (n = t(i)) && s ? s.p(i, a) : (s.d(1), s = n(i), s && (s.c(), s.m(e.parentNode, e)));
    },
    d(i) {
      i && L(e), s.d(i);
    }
  };
}
function Li(r) {
  let e, t, n, s, i, a, l, o, f, u;
  const d = [B0, H0], h = [];
  function c(p, y) {
    return (
      /*collapsed*/
      p[8] ? 0 : 1
    );
  }
  n = c(r), s = h[n] = d[n](r);
  let m = Dr(
    /*subLinks*/
    r[3] || []
  ), g = [];
  for (let p = 0; p < m.length; p += 1)
    g[p] = Ci(Mi(r, m, p));
  return {
    c() {
      e = I("div"), t = I("div"), s.c(), i = Y(), a = I("div"), l = I("div");
      for (let p = 0; p < g.length; p += 1)
        g[p].c();
      T(t, "class", "text svelte-b449hq"), T(l, "class", "sublinks svelte-b449hq"), T(a, "class", "sublinks-wrapper svelte-b449hq"), T(e, "class", "dropdown svelte-b449hq"), W(
        e,
        "left",
        /*renderLeftNav*/
        r[9]
      ), W(
        e,
        "expanded",
        /*expanded*/
        r[10]
      );
    },
    m(p, y) {
      C(p, e, y), j(e, t), h[n].m(t, null), j(e, i), j(e, a), j(a, l);
      for (let b = 0; b < g.length; b += 1)
        g[b] && g[b].m(l, null);
      o = !0, f || (u = fe(
        t,
        "click",
        /*onClickDropdown*/
        r[17]
      ), f = !0);
    },
    p(p, y) {
      let b = n;
      if (n = c(p), n === b ? h[n].p(p, y) : (X(), w(h[b], 1, 1, () => {
        h[b] = null;
      }), ee(), s = h[n], s ? s.p(p, y) : (s = h[n] = d[n](p), s.c()), _(s, 1), s.m(t, null)), y & /*subLinks, isBuilderActive, onClickLink*/
      67592) {
        m = Dr(
          /*subLinks*/
          p[3] || []
        );
        let v;
        for (v = 0; v < m.length; v += 1) {
          const k = Mi(p, m, v);
          g[v] ? g[v].p(k, y) : (g[v] = Ci(k), g[v].c(), g[v].m(l, null));
        }
        for (; v < g.length; v += 1)
          g[v].d(1);
        g.length = m.length;
      }
      (!o || y & /*renderLeftNav*/
      512) && W(
        e,
        "left",
        /*renderLeftNav*/
        p[9]
      ), (!o || y & /*expanded*/
      1024) && W(
        e,
        "expanded",
        /*expanded*/
        p[10]
      );
    },
    i(p) {
      o || (_(s), o = !0);
    },
    o(p) {
      w(s), o = !1;
    },
    d(p) {
      p && L(e), h[n].d(), sa(g, p), f = !1, u();
    }
  };
}
function X0(r) {
  let e, t, n, s, i, a;
  const l = [rp, tp], o = [];
  function f(u, d) {
    return (
      /*collapsed*/
      u[8] ? 0 : 1
    );
  }
  return t = f(r), n = o[t] = l[t](r), {
    c() {
      e = I("a"), n.c(), T(
        e,
        "href",
        /*url*/
        r[1]
      ), T(e, "class", "svelte-b449hq");
    },
    m(u, d) {
      C(u, e, d), o[t].m(e, null), s = !0, i || (a = fe(
        e,
        "click",
        /*onClickLink*/
        r[16]
      ), i = !0);
    },
    p(u, d) {
      let h = t;
      t = f(u), t === h ? o[t].p(u, d) : (X(), w(o[h], 1, 1, () => {
        o[h] = null;
      }), ee(), n = o[t], n ? n.p(u, d) : (n = o[t] = l[t](u), n.c()), _(n, 1), n.m(e, null)), (!s || d & /*url*/
      2) && T(
        e,
        "href",
        /*url*/
        u[1]
      );
    },
    i(u) {
      s || (_(n), s = !0);
    },
    o(u) {
      w(n), s = !1;
    },
    d(u) {
      u && L(e), o[t].d(), i = !1, a();
    }
  };
}
function ep(r) {
  let e, t, n, s, i, a, l, o;
  const f = [op, ap], u = [];
  function d(h, c) {
    return (
      /*collapsed*/
      h[8] ? 0 : 1
    );
  }
  return t = d(r), n = u[t] = f[t](r), {
    c() {
      e = I("a"), n.c(), T(e, "href", s = "#" + /*url*/
      r[1]), T(
        e,
        "style",
        /*customStyles*/
        r[6]
      ), T(e, "class", "svelte-b449hq"), W(
        e,
        "builderActive",
        /*builderActive*/
        r[15]
      );
    },
    m(h, c) {
      C(h, e, c), u[t].m(e, null), a = !0, l || (o = [
        fe(
          e,
          "click",
          /*onClickLink*/
          r[16]
        ),
        Kt(i = tl.call(
          null,
          e,
          /*url*/
          r[1]
        ))
      ], l = !0);
    },
    p(h, c) {
      let m = t;
      t = d(h), t === m ? u[t].p(h, c) : (X(), w(u[m], 1, 1, () => {
        u[m] = null;
      }), ee(), n = u[t], n ? n.p(h, c) : (n = u[t] = f[t](h), n.c()), _(n, 1), n.m(e, null)), (!a || c & /*url*/
      2 && s !== (s = "#" + /*url*/
      h[1])) && T(e, "href", s), (!a || c & /*customStyles*/
      64) && T(
        e,
        "style",
        /*customStyles*/
        h[6]
      ), i && He(i.update) && c & /*url*/
      2 && i.update.call(
        null,
        /*url*/
        h[1]
      ), (!a || c & /*builderActive*/
      32768) && W(
        e,
        "builderActive",
        /*builderActive*/
        h[15]
      );
    },
    i(h) {
      a || (_(n), a = !0);
    },
    o(h) {
      w(n), a = !1;
    },
    d(h) {
      h && L(e), u[t].d(), l = !1, Ct(o);
    }
  };
}
function tp(r) {
  let e, t, n, s = (
    /*icon*/
    r[4] && Vi(r)
  );
  return {
    c() {
      s && s.c(), e = Y(), t = le(
        /*text*/
        r[2]
      );
    },
    m(i, a) {
      s && s.m(i, a), C(i, e, a), C(i, t, a), n = !0;
    },
    p(i, a) {
      /*icon*/
      i[4] ? s ? (s.p(i, a), a & /*icon*/
      16 && _(s, 1)) : (s = Vi(i), s.c(), _(s, 1), s.m(e.parentNode, e)) : s && (X(), w(s, 1, 1, () => {
        s = null;
      }), ee()), (!n || a & /*text*/
      4) && ue(
        t,
        /*text*/
        i[2]
      );
    },
    i(i) {
      n || (_(s), n = !0);
    },
    o(i) {
      w(s), n = !1;
    },
    d(i) {
      i && (L(e), L(t)), s && s.d(i);
    }
  };
}
function rp(r) {
  let e, t;
  return e = new An({
    props: {
      text: (
        /*text*/
        r[2]
      ),
      position: Wn.Right,
      $$slots: { default: [ip] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s & /*text*/
      4 && (i.text = /*text*/
      n[2]), s & /*$$scope, icon, collapsedText*/
      536879120 && (i.$$scope = { dirty: s, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function Vi(r) {
  let e, t;
  return e = new Pe({
    props: {
      name: (
        /*icon*/
        r[4]
      ),
      color: "var(--navTextColor)",
      size: "S"
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s & /*icon*/
      16 && (i.name = /*icon*/
      n[4]), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function np(r) {
  let e;
  return {
    c() {
      e = le(
        /*collapsedText*/
        r[13]
      );
    },
    m(t, n) {
      C(t, e, n);
    },
    p(t, n) {
      n & /*collapsedText*/
      8192 && ue(
        e,
        /*collapsedText*/
        t[13]
      );
    },
    i: Se,
    o: Se,
    d(t) {
      t && L(e);
    }
  };
}
function sp(r) {
  let e, t;
  return e = new Pe({
    props: {
      name: (
        /*icon*/
        r[4]
      ),
      color: "var(--navTextColor)",
      size: "L"
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s & /*icon*/
      16 && (i.name = /*icon*/
      n[4]), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function ip(r) {
  let e, t, n, s;
  const i = [sp, np], a = [];
  function l(o, f) {
    return (
      /*icon*/
      o[4] ? 0 : 1
    );
  }
  return t = l(r), n = a[t] = i[t](r), {
    c() {
      e = I("span"), n.c(), T(e, "class", "nav-item-letter svelte-b449hq");
    },
    m(o, f) {
      C(o, e, f), a[t].m(e, null), s = !0;
    },
    p(o, f) {
      let u = t;
      t = l(o), t === u ? a[t].p(o, f) : (X(), w(a[u], 1, 1, () => {
        a[u] = null;
      }), ee(), n = a[t], n ? n.p(o, f) : (n = a[t] = i[t](o), n.c()), _(n, 1), n.m(e, null));
    },
    i(o) {
      s || (_(n), s = !0);
    },
    o(o) {
      w(n), s = !1;
    },
    d(o) {
      o && L(e), a[t].d();
    }
  };
}
function ap(r) {
  let e, t, n, s = (
    /*icon*/
    r[4] && Ii(r)
  );
  return {
    c() {
      s && s.c(), e = Y(), t = le(
        /*text*/
        r[2]
      );
    },
    m(i, a) {
      s && s.m(i, a), C(i, e, a), C(i, t, a), n = !0;
    },
    p(i, a) {
      /*icon*/
      i[4] ? s ? (s.p(i, a), a & /*icon*/
      16 && _(s, 1)) : (s = Ii(i), s.c(), _(s, 1), s.m(e.parentNode, e)) : s && (X(), w(s, 1, 1, () => {
        s = null;
      }), ee()), (!n || a & /*text*/
      4) && ue(
        t,
        /*text*/
        i[2]
      );
    },
    i(i) {
      n || (_(s), n = !0);
    },
    o(i) {
      w(s), n = !1;
    },
    d(i) {
      i && (L(e), L(t)), s && s.d(i);
    }
  };
}
function op(r) {
  let e, t;
  return e = new An({
    props: {
      text: (
        /*text*/
        r[2]
      ),
      position: Wn.Right,
      $$slots: { default: [fp] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s & /*text*/
      4 && (i.text = /*text*/
      n[2]), s & /*$$scope, icon, collapsedText*/
      536879120 && (i.$$scope = { dirty: s, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function Ii(r) {
  let e, t;
  return e = new Pe({
    props: {
      name: (
        /*icon*/
        r[4]
      ),
      color: "var(--navTextColor)",
      size: "S"
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s & /*icon*/
      16 && (i.name = /*icon*/
      n[4]), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function lp(r) {
  let e;
  return {
    c() {
      e = le(
        /*collapsedText*/
        r[13]
      );
    },
    m(t, n) {
      C(t, e, n);
    },
    p(t, n) {
      n & /*collapsedText*/
      8192 && ue(
        e,
        /*collapsedText*/
        t[13]
      );
    },
    i: Se,
    o: Se,
    d(t) {
      t && L(e);
    }
  };
}
function up(r) {
  let e, t;
  return e = new Pe({
    props: {
      name: (
        /*icon*/
        r[4]
      ),
      color: "var(--navTextColor)",
      size: "XS"
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s & /*icon*/
      16 && (i.name = /*icon*/
      n[4]), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function fp(r) {
  let e, t, n, s;
  const i = [up, lp], a = [];
  function l(o, f) {
    return (
      /*icon*/
      o[4] ? 0 : 1
    );
  }
  return t = l(r), n = a[t] = i[t](r), {
    c() {
      e = I("span"), n.c(), T(e, "class", "nav-item-letter svelte-b449hq");
    },
    m(o, f) {
      C(o, e, f), a[t].m(e, null), s = !0;
    },
    p(o, f) {
      let u = t;
      t = l(o), t === u ? a[t].p(o, f) : (X(), w(a[u], 1, 1, () => {
        a[u] = null;
      }), ee(), n = a[t], n ? n.p(o, f) : (n = a[t] = i[t](o), n.c()), _(n, 1), n.m(e, null));
    },
    i(o) {
      s || (_(n), s = !0);
    },
    o(o) {
      w(n), s = !1;
    },
    d(o) {
      o && L(e), a[t].d();
    }
  };
}
function cp(r) {
  let e, t, n, s;
  const i = [Z0, $0], a = [];
  function l(o, f) {
    return !/*type*/
    o[0] || /*type*/
    o[0] === "link" ? 0 : 1;
  }
  return e = l(r), t = a[e] = i[e](r), {
    c() {
      t.c(), n = $e();
    },
    m(o, f) {
      a[e].m(o, f), C(o, n, f), s = !0;
    },
    p(o, [f]) {
      let u = e;
      e = l(o), e === u ? a[e].p(o, f) : (X(), w(a[u], 1, 1, () => {
        a[u] = null;
      }), ee(), t = a[e], t ? t.p(o, f) : (t = a[e] = i[e](o), t.c()), _(t, 1), t.m(n.parentNode, n));
    },
    i(o) {
      s || (_(t), s = !0);
    },
    o(o) {
      w(t), s = !1;
    },
    d(o) {
      o && L(n), a[e].d(o);
    }
  };
}
function dp(r, e, t) {
  let n, s, i, a, l, o, f, u, d = Se, h = () => (d(), d = Wl(N, (U) => t(21, u = U)), N), c, m;
  pe(r, Il, (U) => t(22, c = U)), pe(r, Al, (U) => t(23, m = U)), r.$$.on_destroy.push(() => d());
  let { type: g } = e, { url: p } = e, { text: y } = e, { subLinks: b } = e, { icon: v } = e, { internalLink: k } = e, { customStyles: S } = e, { leftNav: E = !1 } = e, { mobile: A = !1 } = e, { navStateStore: N } = e;
  h();
  let { collapsed: Z = !1 } = e;
  const H = Rr();
  let G;
  const ie = (U) => {
    if (!U)
      return "";
    const _e = U.trim().split(/\s+/);
    return _e.length === 1 ? _e[0].charAt(0).toUpperCase() : _e.slice(0, 2).map((he) => he.charAt(0).toUpperCase()).join("");
  }, V = () => {
    H("clickLink"), t(12, G = Math.random());
  }, we = () => {
    l && N.update((U) => ({ ...U, [y]: !U[y] }));
  };
  return r.$$set = (U) => {
    "type" in U && t(0, g = U.type), "url" in U && t(1, p = U.url), "text" in U && t(2, y = U.text), "subLinks" in U && t(3, b = U.subLinks), "icon" in U && t(4, v = U.icon), "internalLink" in U && t(5, k = U.internalLink), "customStyles" in U && t(6, S = U.customStyles), "leftNav" in U && t(18, E = U.leftNav), "mobile" in U && t(19, A = U.mobile), "navStateStore" in U && h(t(7, N = U.navStateStore)), "collapsed" in U && t(8, Z = U.collapsed);
  }, r.$$.update = () => {
    r.$$.dirty & /*$builderStore, $screenStore*/
    12582912 && t(11, n = (U) => {
      var _e, he;
      return m.inBuilder && U && U === ((he = (_e = c.activeScreen) == null ? void 0 : _e.routing) == null ? void 0 : he.route);
    }), r.$$.dirty & /*isBuilderActive, url*/
    2050 && t(15, s = n(p)), r.$$.dirty & /*subLinks, isBuilderActive*/
    2056 && t(20, i = (b || []).some((U) => n(U.url))), r.$$.dirty & /*$navStateStore, text, containsActiveLink*/
    3145732 && t(10, a = !!u[y] || i), r.$$.dirty & /*leftNav, mobile*/
    786432 && t(9, l = E || A), r.$$.dirty & /*renderLeftNav, expanded*/
    1536 && t(14, o = !l || a ? "caret-down" : "caret-right"), r.$$.dirty & /*text*/
    4 && t(13, f = ie(y));
  }, [
    g,
    p,
    y,
    b,
    v,
    k,
    S,
    N,
    Z,
    l,
    a,
    n,
    G,
    f,
    o,
    s,
    V,
    we,
    E,
    A,
    i,
    u,
    c,
    m
  ];
}
class hp extends Te {
  constructor(e) {
    super(), Ee(this, e, dp, cp, ve, {
      type: 0,
      url: 1,
      text: 2,
      subLinks: 3,
      icon: 4,
      internalLink: 5,
      customStyles: 6,
      leftNav: 18,
      mobile: 19,
      navStateStore: 7,
      collapsed: 8
    });
  }
}
function Ai(r) {
  let e, t, n, s, i, a;
  e = new D0({
    props: {
      align: (
        /*compact*/
        r[0] ? "right" : "left"
      ),
      $$slots: {
        control: [bp],
        default: [_p]
      },
      $$scope: { ctx: r }
    }
  });
  let l = {
    $$slots: { default: [vp] },
    $$scope: { ctx: r }
  };
  n = new _s({ props: l }), r[25](n);
  let o = {
    $$slots: { default: [wp] },
    $$scope: { ctx: r }
  };
  return i = new _s({ props: o }), r[27](i), {
    c() {
      R(e.$$.fragment), t = Y(), R(n.$$.fragment), s = Y(), R(i.$$.fragment);
    },
    m(f, u) {
      z(e, f, u), C(f, t, u), z(n, f, u), C(f, s, u), z(i, f, u), a = !0;
    },
    p(f, u) {
      const d = {};
      u[0] & /*compact*/
      1 && (d.align = /*compact*/
      f[0] ? "right" : "left"), u[0] & /*text, compact, collapsed, user, embedded, userMenuLabels, isOwner, $environmentStore, changePasswordModal, isSSO, profileModal*/
      15995 | u[1] & /*$$scope*/
      2 && (d.$$scope = { dirty: u, ctx: f }), e.$set(d);
      const h = {};
      u[0] & /*$authStore, profileLabels*/
      260 | u[1] & /*$$scope*/
      2 && (h.$$scope = { dirty: u, ctx: f }), n.$set(h);
      const c = {};
      u[0] & /*$environmentStore, passwordLabels*/
      136 | u[1] & /*$$scope*/
      2 && (c.$$scope = { dirty: u, ctx: f }), i.$set(c);
    },
    i(f) {
      a || (_(e.$$.fragment, f), _(n.$$.fragment, f), _(i.$$.fragment, f), a = !0);
    },
    o(f) {
      w(e.$$.fragment, f), w(n.$$.fragment, f), w(i.$$.fragment, f), a = !1;
    },
    d(f) {
      f && (L(t), L(s)), q(e, f), r[25](null), q(n, f), r[27](null), q(i, f);
    }
  };
}
function mp(r) {
  let e = (
    /*userMenuLabels*/
    r[9].profile + ""
  ), t;
  return {
    c() {
      t = le(e);
    },
    m(n, s) {
      C(n, t, s);
    },
    p(n, s) {
      s[0] & /*userMenuLabels*/
      512 && e !== (e = /*userMenuLabels*/
      n[9].profile + "") && ue(t, e);
    },
    d(n) {
      n && L(t);
    }
  };
}
function Wi(r) {
  let e, t;
  return e = new vr({
    props: {
      icon: "lock",
      $$slots: { default: [pp] },
      $$scope: { ctx: r }
    }
  }), e.$on(
    "click",
    /*click_handler_1*/
    r[23]
  ), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s[0] & /*userMenuLabels*/
      512 | s[1] & /*$$scope*/
      2 && (i.$$scope = { dirty: s, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function pp(r) {
  let e = (
    /*userMenuLabels*/
    r[9].password + ""
  ), t;
  return {
    c() {
      t = le(e);
    },
    m(n, s) {
      C(n, t, s);
    },
    p(n, s) {
      s[0] & /*userMenuLabels*/
      512 && e !== (e = /*userMenuLabels*/
      n[9].password + "") && ue(t, e);
    },
    d(n) {
      n && L(t);
    }
  };
}
function gp(r) {
  let e = (
    /*userMenuLabels*/
    r[9].portal + ""
  ), t;
  return {
    c() {
      t = le(e);
    },
    m(n, s) {
      C(n, t, s);
    },
    p(n, s) {
      s[0] & /*userMenuLabels*/
      512 && e !== (e = /*userMenuLabels*/
      n[9].portal + "") && ue(t, e);
    },
    d(n) {
      n && L(t);
    }
  };
}
function yp(r) {
  let e = (
    /*userMenuLabels*/
    r[9].logout + ""
  ), t;
  return {
    c() {
      t = le(e);
    },
    m(n, s) {
      C(n, t, s);
    },
    p(n, s) {
      s[0] & /*userMenuLabels*/
      512 && e !== (e = /*userMenuLabels*/
      n[9].logout + "") && ue(t, e);
    },
    d(n) {
      n && L(t);
    }
  };
}
function _p(r) {
  let e, t, n, s, i, a, l;
  e = new vr({
    props: {
      icon: "user-gear",
      $$slots: { default: [mp] },
      $$scope: { ctx: r }
    }
  }), e.$on(
    "click",
    /*click_handler*/
    r[22]
  );
  let o = !/*isSSO*/
  r[12] && Wi(r);
  return s = new vr({
    props: {
      icon: "squares-four",
      disabled: (
        /*embedded*/
        r[10]
      ),
      $$slots: { default: [gp] },
      $$scope: { ctx: r }
    }
  }), s.$on(
    "click",
    /*goToPortal*/
    r[19]
  ), a = new vr({
    props: {
      icon: "sign-out",
      disabled: (
        /*embedded*/
        r[10]
      ),
      $$slots: { default: [yp] },
      $$scope: { ctx: r }
    }
  }), a.$on(
    "click",
    /*authStore*/
    r[14].actions.logOut
  ), {
    c() {
      R(e.$$.fragment), t = Y(), o && o.c(), n = Y(), R(s.$$.fragment), i = Y(), R(a.$$.fragment);
    },
    m(f, u) {
      z(e, f, u), C(f, t, u), o && o.m(f, u), C(f, n, u), z(s, f, u), C(f, i, u), z(a, f, u), l = !0;
    },
    p(f, u) {
      const d = {};
      u[0] & /*userMenuLabels*/
      512 | u[1] & /*$$scope*/
      2 && (d.$$scope = { dirty: u, ctx: f }), e.$set(d), /*isSSO*/
      f[12] ? o && (X(), w(o, 1, 1, () => {
        o = null;
      }), ee()) : o ? (o.p(f, u), u[0] & /*isSSO*/
      4096 && _(o, 1)) : (o = Wi(f), o.c(), _(o, 1), o.m(n.parentNode, n));
      const h = {};
      u[0] & /*embedded*/
      1024 && (h.disabled = /*embedded*/
      f[10]), u[0] & /*userMenuLabels*/
      512 | u[1] & /*$$scope*/
      2 && (h.$$scope = { dirty: u, ctx: f }), s.$set(h);
      const c = {};
      u[0] & /*embedded*/
      1024 && (c.disabled = /*embedded*/
      f[10]), u[0] & /*userMenuLabels*/
      512 | u[1] & /*$$scope*/
      2 && (c.$$scope = { dirty: u, ctx: f }), a.$set(c);
    },
    i(f) {
      l || (_(e.$$.fragment, f), _(o), _(s.$$.fragment, f), _(a.$$.fragment, f), l = !0);
    },
    o(f) {
      w(e.$$.fragment, f), w(o), w(s.$$.fragment, f), w(a.$$.fragment, f), l = !1;
    },
    d(f) {
      f && (L(t), L(n), L(i)), q(e, f), o && o.d(f), q(s, f), q(a, f);
    }
  };
}
function Ui(r) {
  let e, t, n, s = !/*compact*/
  r[0] && xi(r);
  return t = new Pe({
    props: {
      size: "S",
      name: "caret-down",
      color: "var(--navTextColor)"
    }
  }), {
    c() {
      s && s.c(), e = Y(), R(t.$$.fragment);
    },
    m(i, a) {
      s && s.m(i, a), C(i, e, a), z(t, i, a), n = !0;
    },
    p(i, a) {
      /*compact*/
      i[0] ? s && (s.d(1), s = null) : s ? s.p(i, a) : (s = xi(i), s.c(), s.m(e.parentNode, e));
    },
    i(i) {
      n || (_(t.$$.fragment, i), n = !0);
    },
    o(i) {
      w(t.$$.fragment, i), n = !1;
    },
    d(i) {
      i && L(e), s && s.d(i), q(t, i);
    }
  };
}
function xi(r) {
  let e, t, n;
  return {
    c() {
      e = I("div"), t = I("div"), n = le(
        /*text*/
        r[13]
      ), T(t, "class", "name svelte-1f32c0v"), T(e, "class", "text svelte-1f32c0v");
    },
    m(s, i) {
      C(s, e, i), j(e, t), j(t, n);
    },
    p(s, i) {
      i[0] & /*text*/
      8192 && ue(
        n,
        /*text*/
        s[13]
      );
    },
    d(s) {
      s && L(e);
    }
  };
}
function bp(r) {
  let e, t, n, s;
  t = new Bl({
    props: {
      user: (
        /*user*/
        r[6]
      ),
      size: "M",
      showTooltip: !1
    }
  });
  let i = !/*collapsed*/
  r[1] && Ui(r);
  return {
    c() {
      e = I("div"), R(t.$$.fragment), n = Y(), i && i.c(), T(e, "class", "container svelte-1f32c0v");
    },
    m(a, l) {
      C(a, e, l), z(t, e, null), j(e, n), i && i.m(e, null), s = !0;
    },
    p(a, l) {
      const o = {};
      l[0] & /*user*/
      64 && (o.user = /*user*/
      a[6]), t.$set(o), /*collapsed*/
      a[1] ? i && (X(), w(i, 1, 1, () => {
        i = null;
      }), ee()) : i ? (i.p(a, l), l[0] & /*collapsed*/
      2 && _(i, 1)) : (i = Ui(a), i.c(), _(i, 1), i.m(e, null));
    },
    i(a) {
      s || (_(t.$$.fragment, a), _(i), s = !0);
    },
    o(a) {
      w(t.$$.fragment, a), w(i), s = !1;
    },
    d(a) {
      a && L(e), q(t), i && i.d();
    }
  };
}
function vp(r) {
  let e, t;
  return e = new j0({
    props: {
      API: ia,
      user: (
        /*$authStore*/
        r[2]
      ),
      notifySuccess: (
        /*notificationStore*/
        r[16].actions.success
      ),
      notifyError: (
        /*notificationStore*/
        r[16].actions.error
      ),
      labels: (
        /*profileLabels*/
        r[8]
      )
    }
  }), e.$on(
    "save",
    /*save_handler*/
    r[24]
  ), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s[0] & /*$authStore*/
      4 && (i.user = /*$authStore*/
      n[2]), s[0] & /*profileLabels*/
      256 && (i.labels = /*profileLabels*/
      n[8]), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function wp(r) {
  let e, t;
  return e = new x0({
    props: {
      API: ia,
      passwordMinLength: (
        /*$environmentStore*/
        r[3].passwordMinLength
      ),
      notifySuccess: (
        /*notificationStore*/
        r[16].actions.success
      ),
      notifyError: (
        /*notificationStore*/
        r[16].actions.error
      ),
      labels: (
        /*passwordLabels*/
        r[7]
      )
    }
  }), e.$on(
    "save",
    /*save_handler_1*/
    r[26]
  ), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s[0] & /*$environmentStore*/
      8 && (i.passwordMinLength = /*$environmentStore*/
      n[3].passwordMinLength), s[0] & /*passwordLabels*/
      128 && (i.labels = /*passwordLabels*/
      n[7]), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function kp(r) {
  let e, t, n = (
    /*$authStore*/
    r[2] && Ai(r)
  );
  return {
    c() {
      n && n.c(), e = $e();
    },
    m(s, i) {
      n && n.m(s, i), C(s, e, i), t = !0;
    },
    p(s, i) {
      /*$authStore*/
      s[2] ? n ? (n.p(s, i), i[0] & /*$authStore*/
      4 && _(n, 1)) : (n = Ai(s), n.c(), _(n, 1), n.m(e.parentNode, e)) : n && (X(), w(n, 1, 1, () => {
        n = null;
      }), ee());
    },
    i(s) {
      t || (_(n), t = !0);
    },
    o(s) {
      w(n), t = !1;
    },
    d(s) {
      s && L(e), n && n.d(s);
    }
  };
}
function Op(r, e, t) {
  let n, s, i, a, l, o, f, u, d, h, c, m, g, { compact: p = !1 } = e, { collapsed: y = !1 } = e;
  const { authStore: b, environmentStore: v, notificationStore: k, appStore: S } = Gt("sdk");
  pe(r, b, (B) => t(2, c = B)), pe(r, v, (B) => t(3, m = B)), pe(r, S, (B) => t(21, g = B));
  let E, A;
  const { accountPortalAccountUrl: N, builderWorkspacesUrl: Z, builderAppsUrl: H } = a0, G = (B) => {
    if (!B)
      return "";
    if (B.firstName) {
      let ze = B.firstName;
      return B.lastName && (ze += ` ${B.lastName}`), ze;
    } else
      return B.email;
  }, ie = () => {
    const B = m.accountPortalUrl, ze = s ? Z(B) : H(B);
    window.location.href = ze;
  }, V = () => E == null ? void 0 : E.show(), we = () => {
    a ? window.location.href = N(m.accountPortalUrl) : A == null || A.show();
  }, U = () => b.actions.fetchUser();
  function _e(B) {
    Oe[B ? "unshift" : "push"](() => {
      E = B, t(4, E);
    });
  }
  const he = () => b.actions.logOut();
  function F(B) {
    Oe[B ? "unshift" : "push"](() => {
      A = B, t(5, A);
    });
  }
  return r.$$set = (B) => {
    "compact" in B && t(0, p = B.compact), "collapsed" in B && t(1, y = B.collapsed);
  }, r.$$.update = () => {
    var B;
    r.$$.dirty[0] & /*$authStore*/
    4 && t(13, n = G(c)), r.$$.dirty[0] & /*$authStore*/
    4 && (s = Yl(c)), r.$$.dirty[0] & /*$authStore*/
    4 && t(12, i = c != null && Gl(c)), r.$$.dirty[0] & /*$authStore, $environmentStore*/
    12 && t(11, a = (c == null ? void 0 : c.accountPortalAccess) && m.cloud), r.$$.dirty[0] & /*$appStore*/
    2097152 && t(10, l = g.embedded || g.inIframe), r.$$.dirty[0] & /*$appStore*/
    2097152 && t(20, o = Ul((B = g.application) == null ? void 0 : B.translationOverrides)), r.$$.dirty[0] & /*translationOverrides*/
    1048576 && t(9, f = Bt("userMenu", o)), r.$$.dirty[0] & /*translationOverrides*/
    1048576 && t(8, u = Bt("profileModal", o)), r.$$.dirty[0] & /*translationOverrides*/
    1048576 && t(7, d = Bt("passwordModal", o)), r.$$.dirty[0] & /*$authStore*/
    4 && t(6, h = c);
  }, [
    p,
    y,
    c,
    m,
    E,
    A,
    h,
    d,
    u,
    f,
    l,
    a,
    i,
    n,
    b,
    v,
    k,
    S,
    N,
    ie,
    o,
    g,
    V,
    we,
    U,
    _e,
    he,
    F
  ];
}
class rl extends Te {
  constructor(e) {
    super(), Ee(this, e, Op, kp, ve, { compact: 0, collapsed: 1 }, null, [-1, -1]);
  }
}
function Pi(r) {
  let e, t;
  function n(a, l) {
    return l & /*logoLinkUrl, isInternal, openLogoLinkInNewTab*/
    38 && (e = null), e == null && (e = !!/*logoLinkUrl*/
    (a[1] && /*isInternal*/
    a[5](
      /*logoLinkUrl*/
      a[1]
    ) && !/*openLogoLinkInNewTab*/
    a[2])), e ? Ep : (
      /*logoLinkUrl*/
      a[1] ? Tp : Sp
    );
  }
  let s = n(r, -1), i = s(r);
  return {
    c() {
      i.c(), t = $e();
    },
    m(a, l) {
      i.m(a, l), C(a, t, l);
    },
    p(a, l) {
      s === (s = n(a, l)) && i ? i.p(a, l) : (i.d(1), i = s(a), i && (i.c(), i.m(t.parentNode, t)));
    },
    d(a) {
      a && L(t), i.d(a);
    }
  };
}
function Sp(r) {
  let e, t;
  return {
    c() {
      e = I("img"), St(e.src, t = /*logoUrl*/
      r[0] || "/builder/bblogo.png") || T(e, "src", t), T(
        e,
        "alt",
        /*title*/
        r[4]
      ), T(e, "class", "svelte-17w40j6");
    },
    m(n, s) {
      C(n, e, s);
    },
    p(n, s) {
      s & /*logoUrl*/
      1 && !St(e.src, t = /*logoUrl*/
      n[0] || "/builder/bblogo.png") && T(e, "src", t), s & /*title*/
      16 && T(
        e,
        "alt",
        /*title*/
        n[4]
      );
    },
    d(n) {
      n && L(e);
    }
  };
}
function Tp(r) {
  let e, t, n, s, i;
  return {
    c() {
      e = I("a"), t = I("img"), St(t.src, n = /*logoUrl*/
      r[0] || "/builder/bblogo.png") || T(t, "src", n), T(
        t,
        "alt",
        /*title*/
        r[4]
      ), T(t, "class", "svelte-17w40j6"), T(e, "target", s = /*openLogoLinkInNewTab*/
      r[2] ? "_blank" : "_self"), T(e, "href", i = /*getSanitizedUrl*/
      r[6](
        /*logoLinkUrl*/
        r[1],
        /*openLogoLinkInNewTab*/
        r[2]
      ));
    },
    m(a, l) {
      C(a, e, l), j(e, t);
    },
    p(a, l) {
      l & /*logoUrl*/
      1 && !St(t.src, n = /*logoUrl*/
      a[0] || "/builder/bblogo.png") && T(t, "src", n), l & /*title*/
      16 && T(
        t,
        "alt",
        /*title*/
        a[4]
      ), l & /*openLogoLinkInNewTab*/
      4 && s !== (s = /*openLogoLinkInNewTab*/
      a[2] ? "_blank" : "_self") && T(e, "target", s), l & /*getSanitizedUrl, logoLinkUrl, openLogoLinkInNewTab*/
      70 && i !== (i = /*getSanitizedUrl*/
      a[6](
        /*logoLinkUrl*/
        a[1],
        /*openLogoLinkInNewTab*/
        a[2]
      )) && T(e, "href", i);
    },
    d(a) {
      a && L(e);
    }
  };
}
function Ep(r) {
  let e, t, n, s, i, a;
  return {
    c() {
      e = I("a"), t = I("img"), St(t.src, n = /*logoUrl*/
      r[0] || "/builder/bblogo.png") || T(t, "src", n), T(
        t,
        "alt",
        /*title*/
        r[4]
      ), T(t, "class", "svelte-17w40j6"), T(e, "href", s = /*getSanitizedUrl*/
      r[6](
        /*logoLinkUrl*/
        r[1],
        /*openLogoLinkInNewTab*/
        r[2]
      ));
    },
    m(l, o) {
      C(l, e, o), j(e, t), i || (a = Kt(
        /*linkable*/
        r[7].call(null, e)
      ), i = !0);
    },
    p(l, o) {
      o & /*logoUrl*/
      1 && !St(t.src, n = /*logoUrl*/
      l[0] || "/builder/bblogo.png") && T(t, "src", n), o & /*title*/
      16 && T(
        t,
        "alt",
        /*title*/
        l[4]
      ), o & /*getSanitizedUrl, logoLinkUrl, openLogoLinkInNewTab*/
      70 && s !== (s = /*getSanitizedUrl*/
      l[6](
        /*logoLinkUrl*/
        l[1],
        /*openLogoLinkInNewTab*/
        l[2]
      )) && T(e, "href", s);
    },
    d(l) {
      l && L(e), i = !1, a();
    }
  };
}
function Fp(r) {
  let e, t = !/*hideLogo*/
  r[3] && Pi(r);
  return {
    c() {
      t && t.c(), e = $e();
    },
    m(n, s) {
      t && t.m(n, s), C(n, e, s);
    },
    p(n, [s]) {
      /*hideLogo*/
      n[3] ? t && (t.d(1), t = null) : t ? t.p(n, s) : (t = Pi(n), t.c(), t.m(e.parentNode, e));
    },
    i: Se,
    o: Se,
    d(n) {
      n && L(e), t && t.d(n);
    }
  };
}
function Dp(r, e, t) {
  let { logoUrl: n } = e, { logoLinkUrl: s } = e, { openLogoLinkInNewTab: i } = e, { hideLogo: a = !1 } = e, { title: l } = e, { isInternal: o } = e, { getSanitizedUrl: f } = e, { linkable: u } = e;
  return r.$$set = (d) => {
    "logoUrl" in d && t(0, n = d.logoUrl), "logoLinkUrl" in d && t(1, s = d.logoLinkUrl), "openLogoLinkInNewTab" in d && t(2, i = d.openLogoLinkInNewTab), "hideLogo" in d && t(3, a = d.hideLogo), "title" in d && t(4, l = d.title), "isInternal" in d && t(5, o = d.isInternal), "getSanitizedUrl" in d && t(6, f = d.getSanitizedUrl), "linkable" in d && t(7, u = d.linkable);
  }, [
    n,
    s,
    i,
    a,
    l,
    o,
    f,
    u
  ];
}
class nl extends Te {
  constructor(e) {
    super(), Ee(this, e, Dp, Fp, ve, {
      logoUrl: 0,
      logoLinkUrl: 1,
      openLogoLinkInNewTab: 2,
      hideLogo: 3,
      title: 4,
      isInternal: 5,
      getSanitizedUrl: 6,
      linkable: 7
    });
  }
}
function Ri(r, e, t) {
  const n = r.slice();
  return n[67] = e[t], n;
}
function zi(r) {
  let e, t, n, s, i, a, l, o, f, u, d, h, c, m, g, p, y, b, v, k, S = (
    /*enrichedNavItems*/
    r[26].length && qi(r)
  ), E = (
    /*logoPosition*/
    r[11] === "top" && ji(r)
  ), A = !/*hideTitle*/
  r[1] && /*title*/
  r[0] && !/*navCollapsed*/
  r[18] && $i(r), N = (
    /*navigation*/
    r[4] === "Left" && /*collapsible*/
    r[10] && !/*navCollapsed*/
    r[18] && !/*mobile*/
    r[14] && Zi(r)
  ), Z = !/*embedded*/
  r[9] && Hi(), H = (
    /*enrichedNavItems*/
    r[26].length && Bi(r)
  ), G = !/*embedded*/
  r[9] && Ji(r);
  return {
    c() {
      var ie;
      e = I("div"), t = I("div"), n = I("div"), s = I("div"), S && S.c(), i = Y(), a = I("div"), E && E.c(), l = Y(), A && A.c(), o = Y(), N && N.c(), f = Y(), Z && Z.c(), u = Y(), d = I("div"), h = Y(), c = I("div"), H && H.c(), m = Y(), G && G.c(), T(a, "class", "logo svelte-1vjkj2i"), W(
        a,
        "collapsed-logo",
        /*navCollapsed*/
        r[18]
      ), T(s, "class", "nav-header svelte-1vjkj2i"), T(d, "class", "mobile-click-handler svelte-1vjkj2i"), W(
        d,
        "visible",
        /*mobileOpen*/
        r[17]
      ), T(c, "class", "links svelte-1vjkj2i"), W(
        c,
        "visible",
        /*mobileOpen*/
        r[17]
      ), T(n, "class", g = "nav nav--" + /*typeClass*/
      r[25] + " size--" + /*navWidthClass*/
      r[24] + " svelte-1vjkj2i"), W(
        n,
        "collapsed",
        /*navCollapsed*/
        r[18]
      ), T(t, "class", p = "nav-wrapper " + /*navigationId*/
      r[19] + "-dom svelte-1vjkj2i"), T(
        t,
        "style",
        /*navStyle*/
        r[22]
      ), W(
        t,
        "sticky",
        /*sticky*/
        r[5]
      ), W(
        t,
        "hidden",
        /*$routeStore*/
        (ie = r[27].queryParams) == null ? void 0 : ie.peek
      ), W(
        t,
        "clickable",
        /*$builderStore*/
        r[15].inBuilder
      ), T(e, "class", y = "interactive component " + /*navigationId*/
      r[19] + " svelte-1vjkj2i"), T(
        e,
        "data-id",
        /*navigationId*/
        r[19]
      ), T(e, "data-name", "Navigation"), T(e, "data-icon", "eye");
    },
    m(ie, V) {
      C(ie, e, V), j(e, t), j(t, n), j(n, s), S && S.m(s, null), j(s, i), j(s, a), E && E.m(a, null), j(a, l), A && A.m(a, null), j(a, o), N && N.m(a, null), j(s, f), Z && Z.m(s, null), j(n, u), j(n, d), j(n, h), j(n, c), H && H.m(c, null), j(n, m), G && G.m(n, null), b = !0, v || (k = [
        fe(
          d,
          "click",
          /*click_handler_2*/
          r[52]
        ),
        fe(
          n,
          "click",
          /*click_handler_3*/
          r[53]
        ),
        fe(t, "click", function() {
          He(
            /*$builderStore*/
            r[15].inBuilder ? (
              /*builderStore*/
              r[31].actions.selectComponent(
                /*navigationId*/
                r[19]
              )
            ) : null
          ) && /*$builderStore*/
          (r[15].inBuilder ? (
            /*builderStore*/
            r[31].actions.selectComponent(
              /*navigationId*/
              r[19]
            )
          ) : null).apply(this, arguments);
        })
      ], v = !0);
    },
    p(ie, V) {
      var we;
      r = ie, /*enrichedNavItems*/
      r[26].length ? S ? (S.p(r, V), V[0] & /*enrichedNavItems*/
      67108864 && _(S, 1)) : (S = qi(r), S.c(), _(S, 1), S.m(s, i)) : S && (X(), w(S, 1, 1, () => {
        S = null;
      }), ee()), /*logoPosition*/
      r[11] === "top" ? E ? (E.p(r, V), V[0] & /*logoPosition*/
      2048 && _(E, 1)) : (E = ji(r), E.c(), _(E, 1), E.m(a, l)) : E && (X(), w(E, 1, 1, () => {
        E = null;
      }), ee()), !/*hideTitle*/
      r[1] && /*title*/
      r[0] && !/*navCollapsed*/
      r[18] ? A ? (A.p(r, V), V[0] & /*hideTitle, title, navCollapsed*/
      262147 && _(A, 1)) : (A = $i(r), A.c(), _(A, 1), A.m(a, o)) : A && (X(), w(A, 1, 1, () => {
        A = null;
      }), ee()), /*navigation*/
      r[4] === "Left" && /*collapsible*/
      r[10] && !/*navCollapsed*/
      r[18] && !/*mobile*/
      r[14] ? N ? N.p(r, V) : (N = Zi(r), N.c(), N.m(a, null)) : N && (N.d(1), N = null), (!b || V[0] & /*navCollapsed*/
      262144) && W(
        a,
        "collapsed-logo",
        /*navCollapsed*/
        r[18]
      ), /*embedded*/
      r[9] ? Z && (X(), w(Z, 1, 1, () => {
        Z = null;
      }), ee()) : Z ? V[0] & /*embedded*/
      512 && _(Z, 1) : (Z = Hi(), Z.c(), _(Z, 1), Z.m(s, null)), (!b || V[0] & /*mobileOpen*/
      131072) && W(
        d,
        "visible",
        /*mobileOpen*/
        r[17]
      ), /*enrichedNavItems*/
      r[26].length ? H ? (H.p(r, V), V[0] & /*enrichedNavItems*/
      67108864 && _(H, 1)) : (H = Bi(r), H.c(), _(H, 1), H.m(c, null)) : H && (X(), w(H, 1, 1, () => {
        H = null;
      }), ee()), (!b || V[0] & /*mobileOpen*/
      131072) && W(
        c,
        "visible",
        /*mobileOpen*/
        r[17]
      ), /*embedded*/
      r[9] ? G && (X(), w(G, 1, 1, () => {
        G = null;
      }), ee()) : G ? (G.p(r, V), V[0] & /*embedded*/
      512 && _(G, 1)) : (G = Ji(r), G.c(), _(G, 1), G.m(n, null)), (!b || V[0] & /*typeClass, navWidthClass*/
      50331648 && g !== (g = "nav nav--" + /*typeClass*/
      r[25] + " size--" + /*navWidthClass*/
      r[24] + " svelte-1vjkj2i")) && T(n, "class", g), (!b || V[0] & /*typeClass, navWidthClass, navCollapsed*/
      50593792) && W(
        n,
        "collapsed",
        /*navCollapsed*/
        r[18]
      ), (!b || V[0] & /*navigationId*/
      524288 && p !== (p = "nav-wrapper " + /*navigationId*/
      r[19] + "-dom svelte-1vjkj2i")) && T(t, "class", p), (!b || V[0] & /*navStyle*/
      4194304) && T(
        t,
        "style",
        /*navStyle*/
        r[22]
      ), (!b || V[0] & /*navigationId, sticky*/
      524320) && W(
        t,
        "sticky",
        /*sticky*/
        r[5]
      ), (!b || V[0] & /*navigationId, $routeStore*/
      134742016) && W(
        t,
        "hidden",
        /*$routeStore*/
        (we = r[27].queryParams) == null ? void 0 : we.peek
      ), (!b || V[0] & /*navigationId, $builderStore*/
      557056) && W(
        t,
        "clickable",
        /*$builderStore*/
        r[15].inBuilder
      ), (!b || V[0] & /*navigationId*/
      524288 && y !== (y = "interactive component " + /*navigationId*/
      r[19] + " svelte-1vjkj2i")) && T(e, "class", y), (!b || V[0] & /*navigationId*/
      524288) && T(
        e,
        "data-id",
        /*navigationId*/
        r[19]
      );
    },
    i(ie) {
      b || (_(S), _(E), _(A), _(Z), _(H), _(G), b = !0);
    },
    o(ie) {
      w(S), w(E), w(A), w(Z), w(H), w(G), b = !1;
    },
    d(ie) {
      ie && L(e), S && S.d(), E && E.d(), A && A.d(), N && N.d(), Z && Z.d(), H && H.d(), G && G.d(), v = !1, Ct(k);
    }
  };
}
function qi(r) {
  let e, t, n;
  return t = new Pe({
    props: {
      hoverable: !0,
      name: "list",
      color: "var(--navTextColor)"
    }
  }), t.$on(
    "click",
    /*click_handler*/
    r[50]
  ), {
    c() {
      e = I("div"), R(t.$$.fragment), T(e, "class", "burger svelte-1vjkj2i");
    },
    m(s, i) {
      C(s, e, i), z(t, e, null), n = !0;
    },
    p: Se,
    i(s) {
      n || (_(t.$$.fragment, s), n = !0);
    },
    o(s) {
      w(t.$$.fragment, s), n = !1;
    },
    d(s) {
      s && L(e), q(t);
    }
  };
}
function ji(r) {
  let e, t;
  return e = new nl({
    props: {
      logoUrl: (
        /*logoUrl*/
        r[2]
      ),
      logoLinkUrl: (
        /*logoLinkUrl*/
        r[6]
      ),
      openLogoLinkInNewTab: (
        /*openLogoLinkInNewTab*/
        r[7]
      ),
      hideLogo: (
        /*hideLogo*/
        r[3] && !/*navCollapsed*/
        r[18]
      ),
      title: (
        /*title*/
        r[0]
      ),
      linkable: (
        /*linkable*/
        r[30]
      ),
      isInternal: (
        /*isInternal*/
        r[36]
      ),
      getSanitizedUrl: (
        /*getSanitizedUrl*/
        r[37]
      )
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s[0] & /*logoUrl*/
      4 && (i.logoUrl = /*logoUrl*/
      n[2]), s[0] & /*logoLinkUrl*/
      64 && (i.logoLinkUrl = /*logoLinkUrl*/
      n[6]), s[0] & /*openLogoLinkInNewTab*/
      128 && (i.openLogoLinkInNewTab = /*openLogoLinkInNewTab*/
      n[7]), s[0] & /*hideLogo, navCollapsed*/
      262152 && (i.hideLogo = /*hideLogo*/
      n[3] && !/*navCollapsed*/
      n[18]), s[0] & /*title*/
      1 && (i.title = /*title*/
      n[0]), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function $i(r) {
  let e, t;
  return e = new Pl({
    props: {
      size: (
        /*titleSize*/
        r[12]
      ),
      textAlign: (
        /*textAlign*/
        r[8]
      ),
      color: (
        /*titleColor*/
        r[13]
      ),
      $$slots: { default: [Mp] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      R(e.$$.fragment);
    },
    m(n, s) {
      z(e, n, s), t = !0;
    },
    p(n, s) {
      const i = {};
      s[0] & /*titleSize*/
      4096 && (i.size = /*titleSize*/
      n[12]), s[0] & /*textAlign*/
      256 && (i.textAlign = /*textAlign*/
      n[8]), s[0] & /*titleColor*/
      8192 && (i.color = /*titleColor*/
      n[13]), s[0] & /*title*/
      1 | s[1] & /*$$scope*/
      16777216 && (i.$$scope = { dirty: s, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (_(e.$$.fragment, n), t = !0);
    },
    o(n) {
      w(e.$$.fragment, n), t = !1;
    },
    d(n) {
      q(e, n);
    }
  };
}
function Mp(r) {
  let e;
  return {
    c() {
      e = le(
        /*title*/
        r[0]
      );
    },
    m(t, n) {
      C(t, e, n);
    },
    p(t, n) {
      n[0] & /*title*/
      1 && ue(
        e,
        /*title*/
        t[0]
      );
    },
    d(t) {
      t && L(e);
    }
  };
}
function Zi(r) {
  let e, t, n, s;
  return {
    c() {
      e = I("div"), t = I("i"), T(t, "class", "ph ph-sidebar-simple"), Rl(t, "color", "var(--navTextColor)"), T(e, "class", "nav-toggle svelte-1vjkj2i");
    },
    m(i, a) {
      C(i, e, a), j(e, t), n || (s = fe(e, "click", zl(
        /*click_handler_1*/
        r[51]
      )), n = !0);
    },
    p: Se,
    d(i) {
      i && L(e), n = !1, s();
    }
  };
}
function Hi(r) {
  let e, t, n;
  return t = new rl({ props: { compact: !0 } }), {
    c() {
      e = I("div"), R(t.$$.fragment), T(e, "class", "user top svelte-1vjkj2i");
    },
    m(s, i) {
      C(s, e, i), z(t, e, null), n = !0;
    },
    i(s) {
      n || (_(t.$$.fragment, s), n = !0);
    },
    o(s) {
      w(t.$$.fragment, s), n = !1;
    },
    d(s) {
      s && L(e), q(t);
    }
  };
}
function Bi(r) {
  let e, t, n = Dr(
    /*enrichedNavItems*/
    r[26]
  ), s = [];
  for (let a = 0; a < n.length; a += 1)
    s[a] = Gi(Ri(r, n, a));
  const i = (a) => w(s[a], 1, 1, () => {
    s[a] = null;
  });
  return {
    c() {
      for (let a = 0; a < s.length; a += 1)
        s[a].c();
      e = $e();
    },
    m(a, l) {
      for (let o = 0; o < s.length; o += 1)
        s[o] && s[o].m(a, l);
      C(a, e, l), t = !0;
    },
    p(a, l) {
      if (l[0] & /*enrichedNavItems, navigation, mobile, navCollapsed*/
      67387408 | l[1] & /*navStateStore, handleClickLink, evaluateNavItemConditions*/
      152) {
        n = Dr(
          /*enrichedNavItems*/
          a[26]
        );
        let o;
        for (o = 0; o < n.length; o += 1) {
          const f = Ri(a, n, o);
          s[o] ? (s[o].p(f, l), _(s[o], 1)) : (s[o] = Gi(f), s[o].c(), _(s[o], 1), s[o].m(e.parentNode, e));
        }
        for (X(), o = n.length; o < s.length; o += 1)
          i(o);
        ee();
      }
    },
    i(a) {
      if (!t) {
        for (let l = 0; l < n.length; l += 1)
          _(s[l]);
        t = !0;
      }
    },
    o(a) {
      s = s.filter(Boolean);
      for (let l = 0; l < s.length; l += 1)
        w(s[l]);
      t = !1;
    },
    d(a) {
      a && L(e), sa(s, a);
    }
  };
}
function Yi(r) {
  var n;
  let e, t;
  return e = new hp({
    props: {
      type: (
        /*navItem*/
        r[67].type
      ),
      text: (
        /*navItem*/
        r[67].text
      ),
      url: (
        /*navItem*/
        r[67].url
      ),
      subLinks: (
        /*navItem*/
        r[67].subLinks
      ),
      icon: (
        /*navItem*/
        r[67].icon
      ),
      internalLink: (
        /*navItem*/
        r[67].internalLink
      ),
      customStyles: (
        /*navItem*/
        (n = r[67]._styles) == null ? void 0 : n.custom
      ),
      leftNav: (
        /*navigation*/
        r[4] === "Left"
      ),
      mobile: (
        /*mobile*/
        r[14]
      ),
      navStateStore: (
        /*navStateStore*/
        r[34]
      ),
      collapsed: (
        /*navCollapsed*/
        r[18]
      )
    }
  }), e.$on(
    "clickLink",
    /*handleClickLink*/
    r[38]
  ), {
    c() {
      R(e.$$.fragment);
    },
    m(s, i) {
      z(e, s, i), t = !0;
    },
    p(s, i) {
      var l;
      const a = {};
      i[0] & /*enrichedNavItems*/
      67108864 && (a.type = /*navItem*/
      s[67].type), i[0] & /*enrichedNavItems*/
      67108864 && (a.text = /*navItem*/
      s[67].text), i[0] & /*enrichedNavItems*/
      67108864 && (a.url = /*navItem*/
      s[67].url), i[0] & /*enrichedNavItems*/
      67108864 && (a.subLinks = /*navItem*/
      s[67].subLinks), i[0] & /*enrichedNavItems*/
      67108864 && (a.icon = /*navItem*/
      s[67].icon), i[0] & /*enrichedNavItems*/
      67108864 && (a.internalLink = /*navItem*/
      s[67].internalLink), i[0] & /*enrichedNavItems*/
      67108864 && (a.customStyles = /*navItem*/
      (l = s[67]._styles) == null ? void 0 : l.custom), i[0] & /*navigation*/
      16 && (a.leftNav = /*navigation*/
      s[4] === "Left"), i[0] & /*mobile*/
      16384 && (a.mobile = /*mobile*/
      s[14]), i[0] & /*navCollapsed*/
      262144 && (a.collapsed = /*navCollapsed*/
      s[18]), e.$set(a);
    },
    i(s) {
      t || (_(e.$$.fragment, s), t = !0);
    },
    o(s) {
      w(e.$$.fragment, s), t = !1;
    },
    d(s) {
      q(e, s);
    }
  };
}
function Gi(r) {
  let e = (
    /*evaluateNavItemConditions*/
    r[35](
      /*navItem*/
      r[67]._conditions
    )
  ), t, n, s = e && Yi(r);
  return {
    c() {
      s && s.c(), t = $e();
    },
    m(i, a) {
      s && s.m(i, a), C(i, t, a), n = !0;
    },
    p(i, a) {
      a[0] & /*enrichedNavItems*/
      67108864 && (e = /*evaluateNavItemConditions*/
      i[35](
        /*navItem*/
        i[67]._conditions
      )), e ? s ? (s.p(i, a), a[0] & /*enrichedNavItems*/
      67108864 && _(s, 1)) : (s = Yi(i), s.c(), _(s, 1), s.m(t.parentNode, t)) : s && (X(), w(s, 1, 1, () => {
        s = null;
      }), ee());
    },
    i(i) {
      n || (_(s), n = !0);
    },
    o(i) {
      w(s), n = !1;
    },
    d(i) {
      i && L(t), s && s.d(i);
    }
  };
}
function Ji(r) {
  let e, t, n, s;
  t = new rl({
    props: { collapsed: (
      /*navCollapsed*/
      r[18]
    ) }
  });
  let i = (
    /*logoPosition*/
    r[11] === "bottom" && Ki(r)
  );
  return {
    c() {
      e = I("div"), R(t.$$.fragment), n = Y(), i && i.c(), T(e, "class", "user left svelte-1vjkj2i"), W(
        e,
        "collapsed",
        /*navCollapsed*/
        r[18]
      );
    },
    m(a, l) {
      C(a, e, l), z(t, e, null), j(e, n), i && i.m(e, null), s = !0;
    },
    p(a, l) {
      const o = {};
      l[0] & /*navCollapsed*/
      262144 && (o.collapsed = /*navCollapsed*/
      a[18]), t.$set(o), /*logoPosition*/
      a[11] === "bottom" ? i ? (i.p(a, l), l[0] & /*logoPosition*/
      2048 && _(i, 1)) : (i = Ki(a), i.c(), _(i, 1), i.m(e, null)) : i && (X(), w(i, 1, 1, () => {
        i = null;
      }), ee()), (!s || l[0] & /*navCollapsed*/
      262144) && W(
        e,
        "collapsed",
        /*navCollapsed*/
        a[18]
      );
    },
    i(a) {
      s || (_(t.$$.fragment, a), _(i), s = !0);
    },
    o(a) {
      w(t.$$.fragment, a), w(i), s = !1;
    },
    d(a) {
      a && L(e), q(t), i && i.d();
    }
  };
}
function Ki(r) {
  let e, t, n;
  return t = new nl({
    props: {
      logoUrl: (
        /*logoUrl*/
        r[2]
      ),
      logoLinkUrl: (
        /*logoLinkUrl*/
        r[6]
      ),
      openLogoLinkInNewTab: (
        /*openLogoLinkInNewTab*/
        r[7]
      ),
      hideLogo: (
        /*hideLogo*/
        r[3]
      ),
      title: (
        /*title*/
        r[0]
      ),
      linkable: (
        /*linkable*/
        r[30]
      ),
      isInternal: (
        /*isInternal*/
        r[36]
      ),
      getSanitizedUrl: (
        /*getSanitizedUrl*/
        r[37]
      )
    }
  }), {
    c() {
      e = I("div"), R(t.$$.fragment);
    },
    m(s, i) {
      C(s, e, i), z(t, e, null), n = !0;
    },
    p(s, i) {
      const a = {};
      i[0] & /*logoUrl*/
      4 && (a.logoUrl = /*logoUrl*/
      s[2]), i[0] & /*logoLinkUrl*/
      64 && (a.logoLinkUrl = /*logoLinkUrl*/
      s[6]), i[0] & /*openLogoLinkInNewTab*/
      128 && (a.openLogoLinkInNewTab = /*openLogoLinkInNewTab*/
      s[7]), i[0] & /*hideLogo*/
      8 && (a.hideLogo = /*hideLogo*/
      s[3]), i[0] & /*title*/
      1 && (a.title = /*title*/
      s[0]), t.$set(a);
    },
    i(s) {
      n || (_(t.$$.fragment, s), n = !0);
    },
    o(s) {
      w(t.$$.fragment, s), n = !1;
    },
    d(s) {
      s && L(e), q(t);
    }
  };
}
function Np(r) {
  let e, t, n, s, i, a, l, o, f, u, d, h, c, m, g, p, y, b = (
    /*typeClass*/
    r[25] !== "none" && zi(r)
  );
  const v = (
    /*#slots*/
    r[49].default
  ), k = Ft(
    v,
    r,
    /*$$scope*/
    r[55],
    null
  );
  return u = new Pe({
    props: {
      color: "var(--spectrum-global-color-gray-600)",
      name: "caret-line-right",
      hoverable: !0
    }
  }), u.$on(
    "click",
    /*sidePanelStore*/
    r[32].actions.close
  ), {
    c() {
      e = I("div"), t = I("div"), b && b.c(), n = Y(), s = I("div"), i = I("div"), k && k.c(), l = Y(), o = I("div"), f = I("div"), R(u.$$.fragment), h = Y(), c = I("div"), T(i, "class", a = "main size--" + /*pageWidthClass*/
      r[23] + " svelte-1vjkj2i"), T(s, "class", "main-wrapper svelte-1vjkj2i"), T(t, "class", "screen-wrapper layout-body svelte-1vjkj2i"), T(f, "class", "side-panel-header svelte-1vjkj2i"), T(o, "id", "side-panel-container"), T(o, "class", "svelte-1vjkj2i"), W(
        o,
        "open",
        /*$sidePanelStore*/
        r[16].open
      ), W(
        o,
        "builder",
        /*$builderStore*/
        r[15].inBuilder
      ), T(c, "class", "modal-container"), T(e, "class", m = "component layout layout--" + /*typeClass*/
      r[25] + " svelte-1vjkj2i"), T(
        e,
        "data-id",
        /*screenId*/
        r[20]
      ), T(e, "data-name", "Screen"), T(e, "data-icon", "browser"), W(e, "desktop", !/*mobile*/
      r[14]), W(e, "mobile", !!/*mobile*/
      r[14]);
    },
    m(S, E) {
      C(S, e, E), j(e, t), b && b.m(t, null), j(t, n), j(t, s), j(s, i), k && k.m(i, null), j(e, l), j(e, o), j(o, f), z(u, f, null), j(e, h), j(e, c), g = !0, p || (y = [
        fe(
          s,
          "click",
          /*click_handler_4*/
          r[54]
        ),
        Kt(d = xl.call(
          null,
          o,
          /*autoCloseSidePanel*/
          r[21] ? (
            /*sidePanelStore*/
            r[32].actions.close
          ) : null
        ))
      ], p = !0);
    },
    p(S, E) {
      /*typeClass*/
      S[25] !== "none" ? b ? (b.p(S, E), E[0] & /*typeClass*/
      33554432 && _(b, 1)) : (b = zi(S), b.c(), _(b, 1), b.m(t, n)) : b && (X(), w(b, 1, 1, () => {
        b = null;
      }), ee()), k && k.p && (!g || E[1] & /*$$scope*/
      16777216) && Dt(
        k,
        v,
        S,
        /*$$scope*/
        S[55],
        g ? Nt(
          v,
          /*$$scope*/
          S[55],
          E,
          null
        ) : Mt(
          /*$$scope*/
          S[55]
        ),
        null
      ), (!g || E[0] & /*pageWidthClass*/
      8388608 && a !== (a = "main size--" + /*pageWidthClass*/
      S[23] + " svelte-1vjkj2i")) && T(i, "class", a), d && He(d.update) && E[0] & /*autoCloseSidePanel*/
      2097152 && d.update.call(
        null,
        /*autoCloseSidePanel*/
        S[21] ? (
          /*sidePanelStore*/
          S[32].actions.close
        ) : null
      ), (!g || E[0] & /*$sidePanelStore*/
      65536) && W(
        o,
        "open",
        /*$sidePanelStore*/
        S[16].open
      ), (!g || E[0] & /*$builderStore*/
      32768) && W(
        o,
        "builder",
        /*$builderStore*/
        S[15].inBuilder
      ), (!g || E[0] & /*typeClass*/
      33554432 && m !== (m = "component layout layout--" + /*typeClass*/
      S[25] + " svelte-1vjkj2i")) && T(e, "class", m), (!g || E[0] & /*screenId*/
      1048576) && T(
        e,
        "data-id",
        /*screenId*/
        S[20]
      ), (!g || E[0] & /*typeClass, mobile*/
      33570816) && W(e, "desktop", !/*mobile*/
      S[14]), (!g || E[0] & /*typeClass, mobile*/
      33570816) && W(e, "mobile", !!/*mobile*/
      S[14]);
    },
    i(S) {
      g || (_(b), _(k, S), _(u.$$.fragment, S), g = !0);
    },
    o(S) {
      w(b), w(k, S), w(u.$$.fragment, S), g = !1;
    },
    d(S) {
      S && L(e), b && b.d(), k && k.d(S), q(u), p = !1, Ct(y);
    }
  };
}
function Cp(r, e, t) {
  let n, s, i, a, l, o, f, u, d, h, c, m, g, p, y, { $$slots: b = {}, $$scope: v } = e;
  const k = Gt("sdk"), { routeStore: S, roleStore: E, linkable: A, builderStore: N, sidePanelStore: Z, modalStore: H } = k;
  pe(r, S, (O) => t(27, y = O)), pe(r, E, (O) => t(48, p = O)), pe(r, N, (O) => t(15, c = O)), pe(r, Z, (O) => t(16, m = O));
  const G = Gt("context");
  pe(r, G, (O) => t(47, g = O));
  const ie = Er({});
  let { title: V } = e, { hideTitle: we = !1 } = e, { logoUrl: U } = e, { hideLogo: _e = !1 } = e, { navigation: he = "Top" } = e, { sticky: F = !1 } = e, { links: B } = e, { width: ze = "Large" } = e, { navBackground: xt } = e, { navTextColor: Br } = e, { navWidth: Yr } = e, { pageWidth: Gr } = e, { logoLinkUrl: ns } = e, { logoHeight: Jr } = e, { openLogoLinkInNewTab: ss } = e, { textAlign: is } = e, { embedded: as = !1 } = e, { collapsible: os = !1 } = e;
  const ls = { Top: "top", Left: "left", None: "none" }, nr = {
    Max: "max",
    Large: "l",
    Medium: "m",
    Small: "s",
    "Extra small": "xs"
  };
  let { logoPosition: us = "top" } = e, { titleSize: fs = "S" } = e, { titleColor: cs } = e, Pt = !1, Rt = !1;
  const ds = Er({ headerHeight: 0 });
  In("layout", ds);
  const hs = (O) => {
    const ae = Kr(O.url);
    return {
      ...O,
      internalLink: ae,
      url: ae ? O.url : ms(O.url)
    };
  }, sl = (O, ae) => O != null && O.length ? O.filter((de) => {
    if (!de.text || de.type !== "sublinks" && !de.url)
      return !1;
    const qe = de.roleId || ql.BASIC;
    return ae == null ? void 0 : ae.find((De) => De === qe);
  }).map((de) => {
    var De;
    const qe = hs(de);
    return de.type === "sublinks" && ((De = de.subLinks) != null && De.length) && (qe.subLinks = de.subLinks.filter((nt) => nt.text && nt.url).map(hs)), qe;
  }) : [];
  function il(O = []) {
    if (!(O != null && O.length))
      return !0;
    const ae = jl(O), { visible: de } = $l(ae);
    return de ?? !O.some((De) => De.action === "show");
  }
  const Kr = (O) => O == null ? void 0 : O.startsWith("/"), ms = (O) => O != null && O.length ? O.startsWith("http") ? O : `http://${O}` : O, al = (O, ae) => O !== "Left" ? 0 : ae ? "0px" : "250px", ol = (O, ae) => ae ? !O || O === "None" ? 0 : "61px" : O === "Top" ? "137px" : "0px", ll = (O, ae, de, qe, De) => {
    let nt = `--width:${qe}px; --height:${De}px;`;
    return O && (nt += `--navBackground:${O};`), ae && (nt += `--navTextColor:${ae};`), nt += `--logoHeight:${de || 24}px;`, nt;
  }, ul = (O, ae) => Kr(O) ? ae ? `#${O}` : O : ms(O), fl = () => {
    t(17, Pt = !1), Z.actions.close(), H.actions.close();
  }, cl = () => t(17, Pt = !Pt), dl = () => t(18, Rt = !Rt), hl = () => t(17, Pt = !1), ml = () => {
    Rt && t(18, Rt = !1);
  }, pl = () => {
    c.inBuilder && N.actions.selectComponent(u);
  };
  return r.$$set = (O) => {
    "title" in O && t(0, V = O.title), "hideTitle" in O && t(1, we = O.hideTitle), "logoUrl" in O && t(2, U = O.logoUrl), "hideLogo" in O && t(3, _e = O.hideLogo), "navigation" in O && t(4, he = O.navigation), "sticky" in O && t(5, F = O.sticky), "links" in O && t(39, B = O.links), "width" in O && t(40, ze = O.width), "navBackground" in O && t(41, xt = O.navBackground), "navTextColor" in O && t(42, Br = O.navTextColor), "navWidth" in O && t(43, Yr = O.navWidth), "pageWidth" in O && t(44, Gr = O.pageWidth), "logoLinkUrl" in O && t(6, ns = O.logoLinkUrl), "logoHeight" in O && t(45, Jr = O.logoHeight), "openLogoLinkInNewTab" in O && t(7, ss = O.openLogoLinkInNewTab), "textAlign" in O && t(8, is = O.textAlign), "embedded" in O && t(9, as = O.embedded), "collapsible" in O && t(10, os = O.collapsible), "logoPosition" in O && t(11, us = O.logoPosition), "titleSize" in O && t(12, fs = O.titleSize), "titleColor" in O && t(13, cs = O.titleColor), "$$scope" in O && t(55, v = O.$$scope);
  }, r.$$.update = () => {
    var O, ae, de, qe;
    if (r.$$.dirty[1] & /*$context*/
    65536 && t(14, n = g.device.mobile), r.$$.dirty[0] & /*navigation, mobile*/
    16400 && ds.set({
      screenXOffset: al(he, n),
      screenYOffset: ol(he, n)
    }), r.$$.dirty[1] & /*links, $roleStore*/
    131328 && t(26, s = sl(B, p)), r.$$.dirty[0] & /*navigation*/
    16 && t(25, i = ls[he] || ls.None), r.$$.dirty[1] & /*navWidth, width*/
    4608 && t(24, a = nr[Yr || ze] || nr.Large), r.$$.dirty[1] & /*pageWidth, width*/
    8704 && t(23, l = nr[Gr || ze] || nr.Large), r.$$.dirty[1] & /*navBackground, navTextColor, logoHeight, $context*/
    84992 && t(22, o = ll(xt, Br, Jr, g.device.width, g.device.height)), r.$$.dirty[0] & /*$builderStore, $sidePanelStore*/
    98304 && t(21, f = !c.inBuilder && m.open && !m.ignoreClicksOutside), r.$$.dirty[0] & /*$builderStore*/
    32768 && t(20, u = c.inBuilder ? `${(O = c.screen) == null ? void 0 : O._id}-screen` : "screen"), r.$$.dirty[0] & /*$builderStore*/
    32768 && t(19, d = c.inBuilder ? `${(ae = c.screen) == null ? void 0 : ae._id}-navigation` : "navigation"), r.$$.dirty[0] & /*$builderStore*/
    32768 && t(46, h = c.inBuilder && ((de = c.selectedComponentId) == null ? void 0 : de.endsWith("-navigation"))), r.$$.dirty[1] & /*selected*/
    32768 && h) {
      const De = (qe = document.getElementsByClassName("nav-wrapper")) == null ? void 0 : qe[0];
      De && (De.style.scrollMargin = "100px", De.scrollIntoView({
        behavior: "smooth",
        block: "nearest",
        inline: "start"
      }));
    }
  }, [
    V,
    we,
    U,
    _e,
    he,
    F,
    ns,
    ss,
    is,
    as,
    os,
    us,
    fs,
    cs,
    n,
    c,
    m,
    Pt,
    Rt,
    d,
    u,
    f,
    o,
    l,
    a,
    i,
    s,
    y,
    S,
    E,
    A,
    N,
    Z,
    G,
    ie,
    il,
    Kr,
    ul,
    fl,
    B,
    ze,
    xt,
    Br,
    Yr,
    Gr,
    Jr,
    h,
    g,
    p,
    b,
    cl,
    dl,
    hl,
    ml,
    pl,
    v
  ];
}
class xp extends Te {
  constructor(e) {
    super(), Ee(
      this,
      e,
      Cp,
      Np,
      ve,
      {
        title: 0,
        hideTitle: 1,
        logoUrl: 2,
        hideLogo: 3,
        navigation: 4,
        sticky: 5,
        links: 39,
        width: 40,
        navBackground: 41,
        navTextColor: 42,
        navWidth: 43,
        pageWidth: 44,
        logoLinkUrl: 6,
        logoHeight: 45,
        openLogoLinkInNewTab: 7,
        textAlign: 8,
        embedded: 9,
        collapsible: 10,
        logoPosition: 11,
        titleSize: 12,
        titleColor: 13
      },
      null,
      [-1, -1, -1]
    );
  }
}
export {
  xp as default
};
