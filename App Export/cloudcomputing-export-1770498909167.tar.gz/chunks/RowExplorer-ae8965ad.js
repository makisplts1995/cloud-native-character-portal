import { S as N, i as O, s as V, K as j, c as m, m as g, k as $, n as b, p as _, cb as q, u as z, M as k, aT as E, cc as i, ac as F, ai as B, a as h, f as S, aj as D, o as v, B as I } from "./index-e79f0bb2.js";
function G(r) {
  let e, n;
  return e = new k({
    props: {
      type: "stringfield",
      props: {
        placeholder: "Search...",
        field: `${/*stateKey*/
        r[13]}-search`,
        onChange: [
          {
            parameters: {
              key: `${/*stateKey*/
              r[13]}-search`,
              type: "set",
              persist: null,
              value: `{{ ${i("eventContext")}.${i("value")} }}`
            },
            "##eventHandlerType": "Update State",
            id: 0
          }
        ]
      }
    }
  }), {
    c() {
      m(e.$$.fragment);
    },
    m(t, a) {
      g(e, t, a), n = !0;
    },
    p: I,
    i(t) {
      n || ($(e.$$.fragment, t), n = !0);
    },
    o(t) {
      b(e.$$.fragment, t), n = !1;
    },
    d(t) {
      _(e, t);
    }
  };
}
function J(r) {
  let e, n;
  return e = new k({
    props: {
      type: "spectrumcard",
      context: "repeater",
      props: {
        title: (
          /*cardTitle*/
          r[2]
        ),
        subtitle: (
          /*cardSubtitle*/
          r[3]
        ),
        description: (
          /*cardDescription*/
          r[4]
        ),
        imageURL: (
          /*cardImageURL*/
          r[5]
        ),
        horizontal: !0,
        buttonOnClick: [
          {
            parameters: {
              key: (
                /*stateKey*/
                r[13]
              ),
              type: "set",
              persist: null,
              value: `{{ ${i(
                /*listRepeaterId*/
                r[12]
              )}.${i("_id")} }}`
            },
            "##eventHandlerType": "Update State",
            id: 0
          }
        ]
      },
      styles: { normal: { width: "auto" } }
    }
  }), {
    c() {
      m(e.$$.fragment);
    },
    m(t, a) {
      g(e, t, a), n = !0;
    },
    p(t, a) {
      const o = {};
      a & /*cardTitle, cardSubtitle, cardDescription, cardImageURL, listRepeaterId*/
      4156 && (o.props = {
        title: (
          /*cardTitle*/
          t[2]
        ),
        subtitle: (
          /*cardSubtitle*/
          t[3]
        ),
        description: (
          /*cardDescription*/
          t[4]
        ),
        imageURL: (
          /*cardImageURL*/
          t[5]
        ),
        horizontal: !0,
        buttonOnClick: [
          {
            parameters: {
              key: (
                /*stateKey*/
                t[13]
              ),
              type: "set",
              persist: null,
              value: `{{ ${i(
                /*listRepeaterId*/
                t[12]
              )}.${i("_id")} }}`
            },
            "##eventHandlerType": "Update State",
            id: 0
          }
        ]
      }), e.$set(o);
    },
    i(t) {
      n || ($(e.$$.fragment, t), n = !0);
    },
    o(t) {
      b(e.$$.fragment, t), n = !1;
    },
    d(t) {
      _(e, t);
    }
  };
}
function Q(r) {
  let e, n, t, a, o;
  e = new k({
    props: {
      type: "form",
      order: 0,
      styles: { normal: { "margin-bottom": "12px" } },
      $$slots: { default: [G] },
      $$scope: { ctx: r }
    }
  });
  function f(c) {
    r[15](c);
  }
  let p = {
    type: "repeater",
    order: 1,
    context: "repeater",
    props: {
      dataProvider: `{{ literal ${i(
        /*listDataProviderId*/
        r[11]
      )} }}`,
      direction: "column",
      gap: "S",
      noRowsMessage: (
        /*noRowsMessage*/
        r[9] || "No data"
      )
    },
    $$slots: { default: [J] },
    $$scope: { ctx: r }
  };
  return (
    /*listRepeaterId*/
    r[12] !== void 0 && (p.id = /*listRepeaterId*/
    r[12]), t = new k({ props: p }), F.push(() => B(t, "id", f)), {
      c() {
        m(e.$$.fragment), n = h(), m(t.$$.fragment);
      },
      m(c, d) {
        g(e, c, d), S(c, n, d), g(t, c, d), o = !0;
      },
      p(c, d) {
        const s = {};
        d & /*$$scope*/
        524288 && (s.$$scope = { dirty: d, ctx: c }), e.$set(s);
        const u = {};
        d & /*listDataProviderId, noRowsMessage*/
        2560 && (u.props = {
          dataProvider: `{{ literal ${i(
            /*listDataProviderId*/
            c[11]
          )} }}`,
          direction: "column",
          gap: "S",
          noRowsMessage: (
            /*noRowsMessage*/
            c[9] || "No data"
          )
        }), d & /*$$scope, cardTitle, cardSubtitle, cardDescription, cardImageURL, listRepeaterId*/
        528444 && (u.$$scope = { dirty: d, ctx: c }), !a && d & /*listRepeaterId*/
        4096 && (a = !0, u.id = /*listRepeaterId*/
        c[12], D(() => a = !1)), t.$set(u);
      },
      i(c) {
        o || ($(e.$$.fragment, c), $(t.$$.fragment, c), o = !0);
      },
      o(c) {
        b(e.$$.fragment, c), b(t.$$.fragment, c), o = !1;
      },
      d(c) {
        c && v(n), _(e, c), _(t, c);
      }
    }
  );
}
function W(r) {
  let e, n, t, a;
  return e = new k({
    props: {
      type: "icon",
      order: 0,
      props: {
        icon: "ri-list-check-2",
        size: "ri-2x",
        color: "var(--spectrum-global-color-gray-700)"
      },
      styles: { normal: { "margin-bottom": "12px" } }
    }
  }), t = new k({
    props: {
      type: "textv2",
      order: 1,
      props: {
        text: "Select a row to view its fields",
        color: "var(--spectrum-global-color-gray-700)"
      }
    }
  }), {
    c() {
      m(e.$$.fragment), n = h(), m(t.$$.fragment);
    },
    m(o, f) {
      g(e, o, f), S(o, n, f), g(t, o, f), a = !0;
    },
    p: I,
    i(o) {
      a || ($(e.$$.fragment, o), $(t.$$.fragment, o), a = !0);
    },
    o(o) {
      b(e.$$.fragment, o), b(t.$$.fragment, o), a = !1;
    },
    d(o) {
      o && v(n), _(e, o), _(t, o);
    }
  };
}
function X(r) {
  let e, n, t, a;
  return e = new k({
    props: {
      type: "button",
      order: 0,
      props: {
        text: "← Back",
        onClick: [
          {
            parameters: {
              key: (
                /*stateKey*/
                r[13]
              ),
              type: "set",
              persist: null,
              value: ""
            },
            "##eventHandlerType": "Update State",
            id: 0
          }
        ]
      },
      styles: {
        custom: `
            align-self: flex-end;
            margin-bottom: 16px;
            {{#if (not ${i("device")}.${i("mobile")}) }}
              display: none;
            {{/if}}
            `
      }
    }
  }), t = new k({
    props: {
      type: "formblock",
      order: 1,
      props: {
        showSaveButton: !0,
        dataSource: (
          /*dataSource*/
          r[0]
        ),
        actionType: "Update",
        rowId: `{{ ${i("state")}.${i(
          /*stateKey*/
          r[13]
        )} }}`,
        fields: (
          /*detailFields*/
          r[7]
        ),
        title: (
          /*detailTitle*/
          r[8]
        )
      }
    }
  }), {
    c() {
      m(e.$$.fragment), n = h(), m(t.$$.fragment);
    },
    m(o, f) {
      g(e, o, f), S(o, n, f), g(t, o, f), a = !0;
    },
    p(o, f) {
      const p = {};
      f & /*dataSource, detailFields, detailTitle*/
      385 && (p.props = {
        showSaveButton: !0,
        dataSource: (
          /*dataSource*/
          o[0]
        ),
        actionType: "Update",
        rowId: `{{ ${i("state")}.${i(
          /*stateKey*/
          o[13]
        )} }}`,
        fields: (
          /*detailFields*/
          o[7]
        ),
        title: (
          /*detailTitle*/
          o[8]
        )
      }), t.$set(p);
    },
    i(o) {
      a || ($(e.$$.fragment, o), $(t.$$.fragment, o), a = !0);
    },
    o(o) {
      b(e.$$.fragment, o), b(t.$$.fragment, o), a = !1;
    },
    d(o) {
      o && v(n), _(e, o), _(t, o);
    }
  };
}
function Y(r) {
  let e, n, t, a, o, f, p;
  function c(s) {
    r[16](s);
  }
  let d = {
    type: "dataprovider",
    order: 0,
    props: {
      dataSource: (
        /*dataSource*/
        r[0]
      ),
      paginate: !0,
      limit: 10,
      filter: [
        {
          id: 0,
          field: (
            /*cardSearchField*/
            r[6]
          ),
          operator: "fuzzy",
          type: "string",
          value: `{{ ${i("state")}.${i(
            /*stateKey*/
            r[13] + "-search"
          )} }}`,
          valueType: "Binding",
          noValue: !1
        }
      ],
      autoRefresh: (
        /*autoRefresh*/
        r[10]
      )
    },
    styles: {
      custom: `
          flex: 3;
          overflow: scroll;
          {{#if (and ${i("state")}.${i(
        /*stateKey*/
        r[13]
      )} ${i("device")}.${i("mobile")}) }}
            display: none;
          {{/if}}
        `
    },
    $$slots: { default: [Q] },
    $$scope: { ctx: r }
  };
  return (
    /*listDataProviderId*/
    r[11] !== void 0 && (d.id = /*listDataProviderId*/
    r[11]), e = new k({ props: d }), F.push(() => B(e, "id", c)), a = new k({
      props: {
        type: "container",
        order: 1,
        props: {
          hAlign: "center",
          vAlign: "middle",
          size: "grow",
          direction: "column"
        },
        styles: {
          custom: `
          padding: 20px;
          background-color: var(--spectrum-global-color-gray-50));
          border: 1px solid var(--spectrum-global-color-gray-300);
          border-radius: 4px;
          flex: 4;
          {{#if (or ${i("state")}.${i(
            /*stateKey*/
            r[13]
          )} ${i("device")}.${i("mobile")}) }}
            display: none;
          {{/if}}
          `
        },
        $$slots: { default: [W] },
        $$scope: { ctx: r }
      }
    }), f = new k({
      props: {
        type: "container",
        order: 2,
        props: {
          hAlign: "center",
          vAlign: "top",
          size: "grow",
          direction: "column"
        },
        styles: {
          custom: `
          background-color: var(--spectrum-global-color-gray-50));
          border: 1px solid var(--spectrum-global-color-gray-300);
          border-radius: 4px;
          padding: 20px;
          overflow-y: scroll;
          flex: 4;
          {{#if (isFalsey ${i("state")}.${i(
            /*stateKey*/
            r[13]
          )}) }}
            display: none;
          {{/if}}
          `
        },
        $$slots: { default: [X] },
        $$scope: { ctx: r }
      }
    }), {
      c() {
        m(e.$$.fragment), t = h(), m(a.$$.fragment), o = h(), m(f.$$.fragment);
      },
      m(s, u) {
        g(e, s, u), S(s, t, u), g(a, s, u), S(s, o, u), g(f, s, u), p = !0;
      },
      p(s, u) {
        const y = {};
        u & /*dataSource, cardSearchField, autoRefresh*/
        1089 && (y.props = {
          dataSource: (
            /*dataSource*/
            s[0]
          ),
          paginate: !0,
          limit: 10,
          filter: [
            {
              id: 0,
              field: (
                /*cardSearchField*/
                s[6]
              ),
              operator: "fuzzy",
              type: "string",
              value: `{{ ${i("state")}.${i(
                /*stateKey*/
                s[13] + "-search"
              )} }}`,
              valueType: "Binding",
              noValue: !1
            }
          ],
          autoRefresh: (
            /*autoRefresh*/
            s[10]
          )
        }), u & /*$$scope, listDataProviderId, noRowsMessage, listRepeaterId, cardTitle, cardSubtitle, cardDescription, cardImageURL*/
        531004 && (y.$$scope = { dirty: u, ctx: s }), !n && u & /*listDataProviderId*/
        2048 && (n = !0, y.id = /*listDataProviderId*/
        s[11], D(() => n = !1)), e.$set(y);
        const w = {};
        u & /*$$scope*/
        524288 && (w.$$scope = { dirty: u, ctx: s }), a.$set(w);
        const R = {};
        u & /*$$scope, dataSource, detailFields, detailTitle*/
        524673 && (R.$$scope = { dirty: u, ctx: s }), f.$set(R);
      },
      i(s) {
        p || ($(e.$$.fragment, s), $(a.$$.fragment, s), $(f.$$.fragment, s), p = !0);
      },
      o(s) {
        b(e.$$.fragment, s), b(a.$$.fragment, s), b(f.$$.fragment, s), p = !1;
      },
      d(s) {
        s && (v(t), v(o)), _(e, s), _(a, s), _(f, s);
      }
    }
  );
}
function Z(r) {
  let e, n;
  return e = new k({
    props: {
      type: "container",
      props: { direction: "row", gap: "M" },
      styles: {
        custom: `
        height: ${/*height*/
        r[1]} !important;
      `
      },
      $$slots: { default: [Y] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      m(e.$$.fragment);
    },
    m(t, a) {
      g(e, t, a), n = !0;
    },
    p(t, a) {
      const o = {};
      a & /*height*/
      2 && (o.styles = {
        custom: `
        height: ${/*height*/
        t[1]} !important;
      `
      }), a & /*$$scope, dataSource, detailFields, detailTitle, cardSearchField, autoRefresh, listDataProviderId, noRowsMessage, listRepeaterId, cardTitle, cardSubtitle, cardDescription, cardImageURL*/
      532477 && (o.$$scope = { dirty: a, ctx: t }), e.$set(o);
    },
    i(t) {
      n || ($(e.$$.fragment, t), n = !0);
    },
    o(t) {
      b(e.$$.fragment, t), n = !1;
    },
    d(t) {
      _(e, t);
    }
  };
}
function x(r) {
  let e, n;
  return e = new j({
    props: {
      $$slots: { default: [Z] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      m(e.$$.fragment);
    },
    m(t, a) {
      g(e, t, a), n = !0;
    },
    p(t, [a]) {
      const o = {};
      a & /*$$scope, height, dataSource, detailFields, detailTitle, cardSearchField, autoRefresh, listDataProviderId, noRowsMessage, listRepeaterId, cardTitle, cardSubtitle, cardDescription, cardImageURL*/
      532479 && (o.$$scope = { dirty: a, ctx: t }), e.$set(o);
    },
    i(t) {
      n || ($(e.$$.fragment, t), n = !0);
    },
    o(t) {
      b(e.$$.fragment, t), n = !1;
    },
    d(t) {
      _(e, t);
    }
  };
}
function ee(r, e, n) {
  let { dataSource: t } = e, { height: a } = e, { cardTitle: o } = e, { cardSubtitle: f } = e, { cardDescription: p } = e, { cardImageURL: c } = e, { cardSearchField: d } = e, { detailFields: s } = e, { detailTitle: u } = e, { noRowsMessage: y } = e, { autoRefresh: w } = e;
  const R = q.generate(), M = z("context"), { generateGoldenSample: A } = z("sdk");
  let T, U;
  const L = () => {
    var C;
    const l = ((C = E(M)[T]) == null ? void 0 : C.rows) || [], K = A(l);
    return { [U]: K };
  };
  function H(l) {
    U = l, n(12, U);
  }
  function P(l) {
    T = l, n(11, T);
  }
  return r.$$set = (l) => {
    "dataSource" in l && n(0, t = l.dataSource), "height" in l && n(1, a = l.height), "cardTitle" in l && n(2, o = l.cardTitle), "cardSubtitle" in l && n(3, f = l.cardSubtitle), "cardDescription" in l && n(4, p = l.cardDescription), "cardImageURL" in l && n(5, c = l.cardImageURL), "cardSearchField" in l && n(6, d = l.cardSearchField), "detailFields" in l && n(7, s = l.detailFields), "detailTitle" in l && n(8, u = l.detailTitle), "noRowsMessage" in l && n(9, y = l.noRowsMessage), "autoRefresh" in l && n(10, w = l.autoRefresh);
  }, [
    t,
    a,
    o,
    f,
    p,
    c,
    d,
    s,
    u,
    y,
    w,
    T,
    U,
    R,
    L,
    H,
    P
  ];
}
class oe extends N {
  constructor(e) {
    super(), O(this, e, ee, x, V, {
      dataSource: 0,
      height: 1,
      cardTitle: 2,
      cardSubtitle: 3,
      cardDescription: 4,
      cardImageURL: 5,
      cardSearchField: 6,
      detailFields: 7,
      detailTitle: 8,
      noRowsMessage: 9,
      autoRefresh: 10,
      getAdditionalDataContext: 14
    });
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[14];
  }
}
export {
  oe as default
};
