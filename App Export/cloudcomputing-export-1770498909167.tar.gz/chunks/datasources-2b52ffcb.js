var O = /* @__PURE__ */ ((E) => (E.AIRTABLE = "AIRTABLE", E.ARANGODB = "ARANGODB", E.BUDIBASE = "BUDIBASE", E.COUCHDB = "COUCHDB", E.DYNAMODB = "DYNAMODB", E.ELASTICSEARCH = "ELASTICSEARCH", E.FIRESTORE = "FIRESTORE", E.GOOGLE_SHEETS = "GOOGLE_SHEETS", E.MONGODB = "MONGODB", E.MYSQL = "MYSQL", E.ORACLE = "ORACLE", E.POSTGRES = "POSTGRES", E.REDIS = "REDIS", E.REST = "REST", E.S3 = "S3", E.SNOWFLAKE = "SNOWFLAKE", E.SQL_SERVER = "SQL_SERVER", E))(O || {}), R = /* @__PURE__ */ ((E) => (E.STRING = "string", E.FUZZY = "fuzzy", E.RANGE = "range", E.EQUAL = "equal", E.NOT_EQUAL = "notEqual", E.EMPTY = "empty", E.NOT_EMPTY = "notEmpty", E.ONE_OF = "oneOf", E))(R || {});
export {
  R as F,
  O as S
};
