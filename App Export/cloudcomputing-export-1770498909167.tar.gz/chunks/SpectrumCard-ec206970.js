import { S as E, i as F, s as G, e as k, a as S, t as T, b as d, d as y, f as z, g as m, l as O, q as I, h as B, j as w, k as P, z as J, n as D, A as K, o as L, r as N, u as q, v as Q, aD as H, aM as W, c as Y, m as Z, p as x } from "./index-e79f0bb2.js";
function A(t) {
  let e;
  return {
    c() {
      e = k("div"), d(e, "class", "spectrum-Card-coverPhoto svelte-1jgsopy"), H(e, "background-image", "url(" + /*imageURL*/
      t[3] + ")");
    },
    m(l, n) {
      z(l, e, n);
    },
    p(l, n) {
      n & /*imageURL*/
      8 && H(e, "background-image", "url(" + /*imageURL*/
      l[3] + ")");
    },
    d(l) {
      l && L(e);
    }
  };
}
function M(t) {
  let e, l, n;
  return {
    c() {
      e = k("div"), l = k("div"), n = T(
        /*subtitle*/
        t[1]
      ), d(l, "class", "spectrum-Card-subtitle spectrum-Detail spectrum-Detail--sizeS svelte-1jgsopy"), d(e, "class", "spectrum-Card-content");
    },
    m(s, u) {
      z(s, e, u), m(e, l), m(l, n);
    },
    p(s, u) {
      u & /*subtitle*/
      2 && w(
        n,
        /*subtitle*/
        s[1]
      );
    },
    d(s) {
      s && L(e);
    }
  };
}
function V(t) {
  let e, l;
  return {
    c() {
      e = k("div"), l = T(
        /*description*/
        t[2]
      ), d(e, "class", "spectrum-Card-footer svelte-1jgsopy");
    },
    m(n, s) {
      z(n, e, s), m(e, l);
    },
    p(n, s) {
      s & /*description*/
      4 && w(
        l,
        /*description*/
        n[2]
      );
    },
    d(n) {
      n && L(e);
    }
  };
}
function X(t) {
  let e, l, n;
  return l = new W({
    props: {
      secondary: !0,
      $$slots: { default: [$] },
      $$scope: { ctx: t }
    }
  }), l.$on("click", function() {
    B(
      /*buttonOnClick*/
      t[8]
    ) && t[8].apply(this, arguments);
  }), {
    c() {
      e = k("div"), Y(l.$$.fragment), d(e, "class", "spectrum-Card-footer button-container svelte-1jgsopy");
    },
    m(s, u) {
      z(s, e, u), Z(l, e, null), n = !0;
    },
    p(s, u) {
      t = s;
      const c = {};
      u & /*$$scope, buttonText*/
      32896 && (c.$$scope = { dirty: u, ctx: t }), l.$set(c);
    },
    i(s) {
      n || (P(l.$$.fragment, s), n = !0);
    },
    o(s) {
      D(l.$$.fragment, s), n = !1;
    },
    d(s) {
      s && L(e), x(l);
    }
  };
}
function $(t) {
  let e = (
    /*buttonText*/
    (t[7] || "Click me") + ""
  ), l;
  return {
    c() {
      l = T(e);
    },
    m(n, s) {
      z(n, l, s);
    },
    p(n, s) {
      s & /*buttonText*/
      128 && e !== (e = /*buttonText*/
      (n[7] || "Click me") + "") && w(l, e);
    },
    d(n) {
      n && L(l);
    }
  };
}
function ee(t) {
  let e, l, n, s, u, c, g = (
    /*title*/
    (t[0] || "Card Title") + ""
  ), b, h, j, p, v, _, R, U, o = (
    /*imageURL*/
    t[3] && A(t)
  ), f = (
    /*subtitle*/
    t[1] && M(t)
  ), i = (
    /*description*/
    t[2] && V(t)
  ), a = (
    /*showButton*/
    t[6] && X(t)
  );
  return {
    c() {
      e = k("div"), o && o.c(), l = S(), n = k("div"), s = k("div"), u = k("div"), c = k("div"), b = T(g), h = S(), f && f.c(), j = S(), i && i.c(), p = S(), a && a.c(), d(c, "class", "spectrum-Card-title spectrum-Heading spectrum-Heading--sizeXS svelte-1jgsopy"), y(
        c,
        "link",
        /*linkURL*/
        t[4]
      ), d(u, "class", "spectrum-Card-header"), d(s, "class", "spectrum-Card-body"), d(n, "class", "spectrum-Card-container svelte-1jgsopy"), d(e, "class", "spectrum-Card svelte-1jgsopy"), d(e, "tabindex", "0"), d(e, "role", "figure"), y(
        e,
        "horizontal",
        /*horizontal*/
        t[5]
      ), y(
        e,
        "clickable",
        /*buttonOnClick*/
        t[8] && !/*showButton*/
        t[6]
      );
    },
    m(C, r) {
      z(C, e, r), o && o.m(e, null), m(e, l), m(e, n), m(n, s), m(s, u), m(u, c), m(c, b), m(s, h), f && f.m(s, null), m(n, j), i && i.m(n, null), m(n, p), a && a.m(n, null), _ = !0, R || (U = [
        O(
          c,
          "click",
          /*handleLink*/
          t[12]
        ),
        I(v = /*styleable*/
        t[10].call(
          null,
          e,
          /*$component*/
          t[9].styles
        )),
        O(e, "click", function() {
          B(
            /*showButton*/
            t[6] ? null : (
              /*buttonOnClick*/
              t[8]
            )
          ) && /*showButton*/
          (t[6] ? null : (
            /*buttonOnClick*/
            t[8]
          )).apply(this, arguments);
        })
      ], R = !0);
    },
    p(C, [r]) {
      t = C, /*imageURL*/
      t[3] ? o ? o.p(t, r) : (o = A(t), o.c(), o.m(e, l)) : o && (o.d(1), o = null), (!_ || r & /*title*/
      1) && g !== (g = /*title*/
      (t[0] || "Card Title") + "") && w(b, g), (!_ || r & /*linkURL*/
      16) && y(
        c,
        "link",
        /*linkURL*/
        t[4]
      ), /*subtitle*/
      t[1] ? f ? f.p(t, r) : (f = M(t), f.c(), f.m(s, null)) : f && (f.d(1), f = null), /*description*/
      t[2] ? i ? i.p(t, r) : (i = V(t), i.c(), i.m(n, p)) : i && (i.d(1), i = null), /*showButton*/
      t[6] ? a ? (a.p(t, r), r & /*showButton*/
      64 && P(a, 1)) : (a = X(t), a.c(), P(a, 1), a.m(n, null)) : a && (J(), D(a, 1, 1, () => {
        a = null;
      }), K()), v && B(v.update) && r & /*$component*/
      512 && v.update.call(
        null,
        /*$component*/
        t[9].styles
      ), (!_ || r & /*horizontal*/
      32) && y(
        e,
        "horizontal",
        /*horizontal*/
        t[5]
      ), (!_ || r & /*buttonOnClick, showButton*/
      320) && y(
        e,
        "clickable",
        /*buttonOnClick*/
        t[8] && !/*showButton*/
        t[6]
      );
    },
    i(C) {
      _ || (P(a), _ = !0);
    },
    o(C) {
      D(a), _ = !1;
    },
    d(C) {
      C && L(e), o && o.d(), f && f.d(), i && i.d(), a && a.d(), R = !1, N(U);
    }
  };
}
function te(t, e, l) {
  let n, { title: s } = e, { subtitle: u } = e, { description: c } = e, { imageURL: g } = e, { linkURL: b } = e, { linkPeek: h } = e, { horizontal: j } = e, { showButton: p } = e, { buttonText: v } = e, { buttonOnClick: _ } = e;
  const { styleable: R, routeStore: U } = q("sdk"), o = q("component");
  Q(t, o, (i) => l(9, n = i));
  const f = (i) => {
    if (!b)
      return !1;
    i.preventDefault(), i.stopPropagation(), U.actions.navigate(b, h);
  };
  return t.$$set = (i) => {
    "title" in i && l(0, s = i.title), "subtitle" in i && l(1, u = i.subtitle), "description" in i && l(2, c = i.description), "imageURL" in i && l(3, g = i.imageURL), "linkURL" in i && l(4, b = i.linkURL), "linkPeek" in i && l(13, h = i.linkPeek), "horizontal" in i && l(5, j = i.horizontal), "showButton" in i && l(6, p = i.showButton), "buttonText" in i && l(7, v = i.buttonText), "buttonOnClick" in i && l(8, _ = i.buttonOnClick);
  }, [
    s,
    u,
    c,
    g,
    b,
    j,
    p,
    v,
    _,
    n,
    R,
    o,
    f,
    h
  ];
}
class ie extends E {
  constructor(e) {
    super(), F(this, e, te, ee, G, {
      title: 0,
      subtitle: 1,
      description: 2,
      imageURL: 3,
      linkURL: 4,
      linkPeek: 13,
      horizontal: 5,
      showButton: 6,
      buttonText: 7,
      buttonOnClick: 8
    });
  }
}
export {
  ie as default
};
