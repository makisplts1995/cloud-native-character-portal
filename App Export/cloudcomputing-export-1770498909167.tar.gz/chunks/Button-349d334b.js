import { S as Y, i as Z, s as H, y as v, f as P, B as J, o as S, u as L, v as j, e as K, a as x, t as $, b as y, aJ as A, d as g, g as D, q as ee, l as z, h as E, cg as te, r as ne, ac as ie } from "./index-e79f0bb2.js";
import { l as le } from "./phosphorIconLoader-ff92b5d5.js";
function F(e) {
  let t, n;
  return {
    c() {
      t = K("i"), y(t, "class", n = /*iconClass*/
      e[13] + " " + /*size*/
      e[1] + " svelte-1033xd6");
    },
    m(l, s) {
      P(l, t, s);
    },
    p(l, s) {
      s & /*iconClass, size*/
      8194 && n !== (n = /*iconClass*/
      l[13] + " " + /*size*/
      l[1] + " svelte-1033xd6") && y(t, "class", n);
    },
    d(l) {
      l && S(t);
    }
  };
}
function G(e) {
  let t, n, l, s, o, m, r, c, _, u = (
    /*icon*/
    e[4] && F(e)
  );
  return {
    c() {
      t = K("button"), u && u.c(), n = x(), l = $(
        /*componentText*/
        e[12]
      ), y(t, "class", s = A(`spectrum-Button spectrum-Button--size${/*size*/
      e[1]} spectrum-Button--${/*type*/
      e[2]} gap-${/*gap*/
      e[5]}`) + " svelte-1033xd6"), t.disabled = o = /*disabled*/
      e[0] || /*handlingOnClick*/
      e[10], y(t, "contenteditable", m = /*$component*/
      e[8].editing && !/*icon*/
      e[4]), g(
        t,
        "spectrum-Button--quiet",
        /*quiet*/
        e[3]
      ), g(
        t,
        "custom",
        /*customBg*/
        e[11]
      ), g(
        t,
        "active",
        /*active*/
        e[6]
      );
    },
    m(f, a) {
      P(f, t, a), u && u.m(t, null), D(t, n), D(t, l), e[24](t), c || (_ = [
        ee(r = /*styleable*/
        e[14].call(
          null,
          t,
          /*$component*/
          e[8].styles
        )),
        z(
          t,
          "click",
          /*handleOnClick*/
          e[18]
        ),
        z(t, "blur", function() {
          E(
            /*$component*/
            e[8].editing ? (
              /*updateText*/
              e[17]
            ) : null
          ) && /*$component*/
          (e[8].editing ? (
            /*updateText*/
            e[17]
          ) : null).apply(this, arguments);
        }),
        z(
          t,
          "input",
          /*input_handler*/
          e[25]
        )
      ], c = !0);
    },
    p(f, a) {
      e = f, /*icon*/
      e[4] ? u ? u.p(e, a) : (u = F(e), u.c(), u.m(t, n)) : u && (u.d(1), u = null), a & /*componentText*/
      4096 && te(
        l,
        /*componentText*/
        e[12],
        /*$component*/
        e[8].editing && !/*icon*/
        e[4]
      ), a & /*size, type, gap*/
      38 && s !== (s = A(`spectrum-Button spectrum-Button--size${/*size*/
      e[1]} spectrum-Button--${/*type*/
      e[2]} gap-${/*gap*/
      e[5]}`) + " svelte-1033xd6") && y(t, "class", s), a & /*disabled, handlingOnClick*/
      1025 && o !== (o = /*disabled*/
      e[0] || /*handlingOnClick*/
      e[10]) && (t.disabled = o), a & /*$component, icon*/
      272 && m !== (m = /*$component*/
      e[8].editing && !/*icon*/
      e[4]) && y(t, "contenteditable", m), r && E(r.update) && a & /*$component*/
      256 && r.update.call(
        null,
        /*$component*/
        e[8].styles
      ), a & /*size, type, gap, quiet*/
      46 && g(
        t,
        "spectrum-Button--quiet",
        /*quiet*/
        e[3]
      ), a & /*size, type, gap, customBg*/
      2086 && g(
        t,
        "custom",
        /*customBg*/
        e[11]
      ), a & /*size, type, gap, active*/
      102 && g(
        t,
        "active",
        /*active*/
        e[6]
      );
    },
    d(f) {
      f && S(t), u && u.d(), e[24](null), c = !1, ne(_);
    }
  };
}
function se(e) {
  let t = (
    /*$component*/
    e[8].editing
  ), n, l = G(e);
  return {
    c() {
      l.c(), n = v();
    },
    m(s, o) {
      l.m(s, o), P(s, n, o);
    },
    p(s, [o]) {
      o & /*$component*/
      256 && H(t, t = /*$component*/
      s[8].editing) ? (l.d(1), l = G(s), l.c(), l.m(n.parentNode, n)) : l.p(s, o);
    },
    i: J,
    o: J,
    d(s) {
      s && S(n), l.d(s);
    }
  };
}
function ue(e, t, n) {
  let l, s, o, m, r, c, _;
  const { styleable: u, builderStore: f } = L("sdk");
  j(e, f, (i) => n(23, _ = i));
  const a = L("component");
  j(e, a, (i) => n(8, c = i));
  let { disabled: I = !1 } = t, { text: C = "" } = t, { onClick: h } = t, { size: N = "M" } = t, { type: T = "cta" } = t, { quiet: M = !1 } = t, { icon: d = null } = t, { gap: O = "M" } = t, { active: W = !1 } = t, b, B = !1, p = !1;
  const Q = (i, q, k) => k.editing ? i || " " : i || k.name || "Placeholder text", R = (i) => {
    B && f.actions.updateProp("text", i.target.textContent), n(9, B = !1);
  }, U = async () => {
    n(10, p = !0), h && await h(), n(10, p = !1);
  };
  function V(i) {
    ie[i ? "unshift" : "push"](() => {
      b = i, n(7, b);
    });
  }
  const X = () => n(9, B = !0);
  return e.$$set = (i) => {
    "disabled" in i && n(0, I = i.disabled), "text" in i && n(19, C = i.text), "onClick" in i && n(20, h = i.onClick), "size" in i && n(1, N = i.size), "type" in i && n(2, T = i.type), "quiet" in i && n(3, M = i.quiet), "icon" in i && n(4, d = i.icon), "gap" in i && n(5, O = i.gap), "active" in i && n(6, W = i.active);
  }, e.$$.update = () => {
    var i, q, k, w;
    e.$$.dirty & /*icon*/
    16 && n(22, l = d && (d.startsWith("ri-") || d.includes("remix"))), e.$$.dirty & /*icon, isLegacyIcon*/
    4194320 && n(21, s = d && !l), e.$$.dirty & /*isPhosphorIcon*/
    2097152 && s && le("regular"), e.$$.dirty & /*isPhosphorIcon, icon*/
    2097168 && n(13, o = s ? (() => `ph ph-${d.replace(/^ph-/, "")}`)() : d), e.$$.dirty & /*$component, node*/
    384 && c.editing && (b == null || b.focus()), e.$$.dirty & /*text, $builderStore, $component*/
    8913152 && n(12, m = Q(C, _, c)), e.$$.dirty & /*$component*/
    256 && n(11, r = ((q = (i = c.styles) == null ? void 0 : i.normal) == null ? void 0 : q.background) || ((w = (k = c.styles) == null ? void 0 : k.normal) == null ? void 0 : w["background-image"]));
  }, [
    I,
    N,
    T,
    M,
    d,
    O,
    W,
    b,
    c,
    B,
    p,
    r,
    m,
    o,
    u,
    f,
    a,
    R,
    U,
    C,
    h,
    s,
    l,
    _,
    V,
    X
  ];
}
class fe extends Y {
  constructor(t) {
    super(), Z(this, t, ue, se, H, {
      disabled: 0,
      text: 19,
      onClick: 20,
      size: 1,
      type: 2,
      quiet: 3,
      icon: 4,
      gap: 5,
      active: 6
    });
  }
}
export {
  fe as default
};
