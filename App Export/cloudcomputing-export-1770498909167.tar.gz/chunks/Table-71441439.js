import { S as Q, i as U, s as X, F as me, e as A, b as w, d as b, f as v, l as Ne, G as ge, H as he, J as be, k as d, n as m, o as C, ab as De, t as M, g as y, j as Z, B as ie, I as de, a as V, c as O, m as I, p as j, aL as Ve, N as $, y as fe, z as D, A as N, O as ve, ae as Tl, cN as ql, aA as Je, aE as Ql, ba as Ul, ap as Xe, br as We, aD as Ke, bO as Zl, bC as Al, cv as $l, h as Bl, aa as xl, bV as et, ac as Fe, P as lt, ai as zl, aj as Dl, cq as Qe, u as Ie, cO as tt, aJ as Ue, q as nt, v as Ze, w as ot } from "./index-e79f0bb2.js";
import { c as it } from "./table-87f82d38.js";
function rt(n) {
  let e, l, t, o, i;
  const s = (
    /*#slots*/
    n[12].default
  ), f = me(
    s,
    n,
    /*$$scope*/
    n[11],
    null
  );
  return {
    c() {
      e = A("span"), f && f.c(), w(e, "class", "spectrum-Label svelte-35zeo5"), w(e, "style", l = /*outlineColor*/
      n[10] ? `border: 2px solid ${/*outlineColor*/
      n[10]}` : ""), b(
        e,
        "hoverable",
        /*hoverable*/
        n[9]
      ), b(
        e,
        "spectrum-Label--small",
        /*size*/
        n[0] === "S"
      ), b(
        e,
        "spectrum-Label--large",
        /*size*/
        n[0] === "L"
      ), b(
        e,
        "spectrum-Label--grey",
        /*grey*/
        n[1]
      ), b(
        e,
        "spectrum-Label--red",
        /*red*/
        n[2]
      ), b(
        e,
        "spectrum-Label--green",
        /*green*/
        n[6]
      ), b(
        e,
        "spectrum-Label--orange",
        /*orange*/
        n[3]
      ), b(
        e,
        "spectrum-Label--yellow",
        /*yellow*/
        n[4]
      ), b(
        e,
        "spectrum-Label--seafoam",
        /*seafoam*/
        n[5]
      ), b(
        e,
        "spectrum-Label--active",
        /*active*/
        n[7]
      ), b(
        e,
        "spectrum-Label--inactive",
        /*inactive*/
        n[8]
      );
    },
    m(r, u) {
      v(r, e, u), f && f.m(e, null), t = !0, o || (i = Ne(
        e,
        "click",
        /*click_handler*/
        n[13]
      ), o = !0);
    },
    p(r, [u]) {
      f && f.p && (!t || u & /*$$scope*/
      2048) && ge(
        f,
        s,
        r,
        /*$$scope*/
        r[11],
        t ? be(
          s,
          /*$$scope*/
          r[11],
          u,
          null
        ) : he(
          /*$$scope*/
          r[11]
        ),
        null
      ), (!t || u & /*outlineColor*/
      1024 && l !== (l = /*outlineColor*/
      r[10] ? `border: 2px solid ${/*outlineColor*/
      r[10]}` : "")) && w(e, "style", l), (!t || u & /*hoverable*/
      512) && b(
        e,
        "hoverable",
        /*hoverable*/
        r[9]
      ), (!t || u & /*size*/
      1) && b(
        e,
        "spectrum-Label--small",
        /*size*/
        r[0] === "S"
      ), (!t || u & /*size*/
      1) && b(
        e,
        "spectrum-Label--large",
        /*size*/
        r[0] === "L"
      ), (!t || u & /*grey*/
      2) && b(
        e,
        "spectrum-Label--grey",
        /*grey*/
        r[1]
      ), (!t || u & /*red*/
      4) && b(
        e,
        "spectrum-Label--red",
        /*red*/
        r[2]
      ), (!t || u & /*green*/
      64) && b(
        e,
        "spectrum-Label--green",
        /*green*/
        r[6]
      ), (!t || u & /*orange*/
      8) && b(
        e,
        "spectrum-Label--orange",
        /*orange*/
        r[3]
      ), (!t || u & /*yellow*/
      16) && b(
        e,
        "spectrum-Label--yellow",
        /*yellow*/
        r[4]
      ), (!t || u & /*seafoam*/
      32) && b(
        e,
        "spectrum-Label--seafoam",
        /*seafoam*/
        r[5]
      ), (!t || u & /*active*/
      128) && b(
        e,
        "spectrum-Label--active",
        /*active*/
        r[7]
      ), (!t || u & /*inactive*/
      256) && b(
        e,
        "spectrum-Label--inactive",
        /*inactive*/
        r[8]
      );
    },
    i(r) {
      t || (d(f, r), t = !0);
    },
    o(r) {
      m(f, r), t = !1;
    },
    d(r) {
      r && C(e), f && f.d(r), o = !1, i();
    }
  };
}
function st(n, e, l) {
  let { $$slots: t = {}, $$scope: o } = e, { size: i = "M" } = e, { grey: s = !1 } = e, { red: f = !1 } = e, { orange: r = !1 } = e, { yellow: u = !1 } = e, { seafoam: c = !1 } = e, { green: _ = !1 } = e, { active: E = !1 } = e, { inactive: S = !1 } = e, { hoverable: T = !1 } = e, { outlineColor: L = null } = e;
  function H(R) {
    De.call(this, n, R);
  }
  return n.$$set = (R) => {
    "size" in R && l(0, i = R.size), "grey" in R && l(1, s = R.grey), "red" in R && l(2, f = R.red), "orange" in R && l(3, r = R.orange), "yellow" in R && l(4, u = R.yellow), "seafoam" in R && l(5, c = R.seafoam), "green" in R && l(6, _ = R.green), "active" in R && l(7, E = R.active), "inactive" in R && l(8, S = R.inactive), "hoverable" in R && l(9, T = R.hoverable), "outlineColor" in R && l(10, L = R.outlineColor), "$$scope" in R && l(11, o = R.$$scope);
  }, [
    i,
    s,
    f,
    r,
    u,
    c,
    _,
    E,
    S,
    T,
    L,
    o,
    t,
    H
  ];
}
class Nl extends Q {
  constructor(e) {
    super(), U(this, e, st, rt, X, {
      size: 0,
      grey: 1,
      red: 2,
      orange: 3,
      yellow: 4,
      seafoam: 5,
      green: 6,
      active: 7,
      inactive: 8,
      hoverable: 9,
      outlineColor: 10
    });
  }
}
function ft(n) {
  let e, l = (typeof /*value*/
  n[0] == "object" ? JSON.stringify(
    /*value*/
    n[0]
  ) : (
    /*value*/
    n[0]
  )) + "", t;
  return {
    c() {
      var o;
      e = A("div"), t = M(l), w(e, "class", "svelte-1acrdjg"), b(
        e,
        "capitalise",
        /*schema*/
        (o = n[1]) == null ? void 0 : o.capitalise
      );
    },
    m(o, i) {
      v(o, e, i), y(e, t);
    },
    p(o, [i]) {
      var s;
      i & /*value*/
      1 && l !== (l = (typeof /*value*/
      o[0] == "object" ? JSON.stringify(
        /*value*/
        o[0]
      ) : (
        /*value*/
        o[0]
      )) + "") && Z(t, l), i & /*schema*/
      2 && b(
        e,
        "capitalise",
        /*schema*/
        (s = o[1]) == null ? void 0 : s.capitalise
      );
    },
    i: ie,
    o: ie,
    d(o) {
      o && C(e);
    }
  };
}
function ut(n, e, l) {
  let { value: t } = e, { schema: o } = e;
  return n.$$set = (i) => {
    "value" in i && l(0, t = i.value), "schema" in i && l(1, o = i.schema);
  }, [t, o];
}
class ze extends Q {
  constructor(e) {
    super(), U(this, e, ut, ft, X, { value: 0, schema: 1 });
  }
}
function ct(n) {
  let e, l, t, o, i, s, f, r, u;
  return s = new de({ props: { name: "check", size: "S" } }), r = new de({ props: { name: "minus", size: "S" } }), {
    c() {
      e = A("label"), l = A("input"), o = V(), i = A("span"), O(s.$$.fragment), f = V(), O(r.$$.fragment), w(l, "type", "checkbox"), w(l, "class", "spectrum-Checkbox-input"), w(l, "id", "checkbox-1"), l.disabled = !0, l.checked = t = !!/*value*/
      n[0], w(i, "class", "spectrum-Checkbox-box svelte-ww1lnr"), w(e, "class", "spectrum-Checkbox spectrum-Checkbox--sizeM spectrum-Checkbox--emphasized svelte-ww1lnr");
    },
    m(c, _) {
      v(c, e, _), y(e, l), y(e, o), y(e, i), I(s, i, null), y(i, f), I(r, i, null), u = !0;
    },
    p(c, [_]) {
      (!u || _ & /*value*/
      1 && t !== (t = !!/*value*/
      c[0])) && (l.checked = t);
    },
    i(c) {
      u || (d(s.$$.fragment, c), d(r.$$.fragment, c), u = !0);
    },
    o(c) {
      m(s.$$.fragment, c), m(r.$$.fragment, c), u = !1;
    },
    d(c) {
      c && C(e), j(s), j(r);
    }
  };
}
function at(n, e, l) {
  let { value: t } = e;
  return n.$$set = (o) => {
    "value" in o && l(0, t = o.value);
  }, [t];
}
class _t extends Q {
  constructor(e) {
    super(), U(this, e, at, ct, X, { value: 0 });
  }
}
function dt(n) {
  let e, l = Ve(
    /*isTimeOnly*/
    n[1] ? (
      /*time*/
      n[2]
    ) : (
      /*value*/
      n[0]
    )
  ).format(
    /*format*/
    n[3]
  ) + "", t;
  return {
    c() {
      e = A("div"), t = M(l), w(e, "class", "svelte-1abuiv5");
    },
    m(o, i) {
      v(o, e, i), y(e, t);
    },
    p(o, [i]) {
      i & /*isTimeOnly, time, value, format*/
      15 && l !== (l = Ve(
        /*isTimeOnly*/
        o[1] ? (
          /*time*/
          o[2]
        ) : (
          /*value*/
          o[0]
        )
      ).format(
        /*format*/
        o[3]
      ) + "") && Z(t, l);
    },
    i: ie,
    o: ie,
    d(o) {
      o && C(e);
    }
  };
}
function mt(n, e, l) {
  let t, o, i, s, { value: f } = e, { schema: r } = e;
  return n.$$set = (u) => {
    "value" in u && l(0, f = u.value), "schema" in u && l(4, r = u.schema);
  }, n.$$.update = () => {
    n.$$.dirty & /*value*/
    1 && l(2, t = /* @__PURE__ */ new Date(`0-${f}`)), n.$$.dirty & /*time, schema*/
    20 && l(1, o = !isNaN(t) || (r == null ? void 0 : r.timeOnly)), n.$$.dirty & /*schema*/
    16 && l(5, i = r == null ? void 0 : r.dateOnly), n.$$.dirty & /*isTimeOnly, isDateOnly*/
    34 && l(3, s = o ? "HH:mm:ss" : i ? "MMMM D YYYY" : "MMMM D YYYY, HH:mm");
  }, [f, o, t, s, r, i];
}
class gt extends Q {
  constructor(e) {
    super(), U(this, e, mt, dt, X, { value: 0, schema: 4 });
  }
}
function $e(n, e, l) {
  const t = n.slice();
  return t[7] = e[l], t;
}
function xe(n) {
  let e, l;
  return e = new Nl({
    props: {
      hoverable: !0,
      grey: !0,
      $$slots: { default: [ht] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "click",
    /*onClick*/
    n[2]
  ), {
    c() {
      O(e.$$.fragment);
    },
    m(t, o) {
      I(e, t, o), l = !0;
    },
    p(t, o) {
      const i = {};
      o & /*$$scope, relationships*/
      1025 && (i.$$scope = { dirty: o, ctx: t }), e.$set(i);
    },
    i(t) {
      l || (d(e.$$.fragment, t), l = !0);
    },
    o(t) {
      m(e.$$.fragment, t), l = !1;
    },
    d(t) {
      j(e, t);
    }
  };
}
function ht(n) {
  let e = (
    /*relationship*/
    n[7].primaryDisplay + ""
  ), l;
  return {
    c() {
      l = M(e);
    },
    m(t, o) {
      v(t, l, o);
    },
    p(t, o) {
      o & /*relationships*/
      1 && e !== (e = /*relationship*/
      t[7].primaryDisplay + "") && Z(l, e);
    },
    d(t) {
      t && C(l);
    }
  };
}
function el(n) {
  var o;
  let e, l, t = (
    /*relationship*/
    ((o = n[7]) == null ? void 0 : o.primaryDisplay) && xe(n)
  );
  return {
    c() {
      t && t.c(), e = fe();
    },
    m(i, s) {
      t && t.m(i, s), v(i, e, s), l = !0;
    },
    p(i, s) {
      var f;
      /*relationship*/
      (f = i[7]) != null && f.primaryDisplay ? t ? (t.p(i, s), s & /*relationships*/
      1 && d(t, 1)) : (t = xe(i), t.c(), d(t, 1), t.m(e.parentNode, e)) : t && (D(), m(t, 1, 1, () => {
        t = null;
      }), N());
    },
    i(i) {
      l || (d(t), l = !0);
    },
    o(i) {
      m(t), l = !1;
    },
    d(i) {
      i && C(e), t && t.d(i);
    }
  };
}
function ll(n) {
  let e, l, t, o;
  return {
    c() {
      e = A("div"), l = M("+"), t = M(
        /*leftover*/
        n[1]
      ), o = M(" more");
    },
    m(i, s) {
      v(i, e, s), y(e, l), y(e, t), y(e, o);
    },
    p(i, s) {
      s & /*leftover*/
      2 && Z(
        t,
        /*leftover*/
        i[1]
      );
    },
    d(i) {
      i && C(e);
    }
  };
}
function bt(n) {
  let e, l, t, o = $(
    /*relationships*/
    n[0]
  ), i = [];
  for (let r = 0; r < o.length; r += 1)
    i[r] = el($e(n, o, r));
  const s = (r) => m(i[r], 1, 1, () => {
    i[r] = null;
  });
  let f = (
    /*leftover*/
    n[1] && ll(n)
  );
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = V(), f && f.c(), l = fe();
    },
    m(r, u) {
      for (let c = 0; c < i.length; c += 1)
        i[c] && i[c].m(r, u);
      v(r, e, u), f && f.m(r, u), v(r, l, u), t = !0;
    },
    p(r, [u]) {
      if (u & /*onClick, relationships*/
      5) {
        o = $(
          /*relationships*/
          r[0]
        );
        let c;
        for (c = 0; c < o.length; c += 1) {
          const _ = $e(r, o, c);
          i[c] ? (i[c].p(_, u), d(i[c], 1)) : (i[c] = el(_), i[c].c(), d(i[c], 1), i[c].m(e.parentNode, e));
        }
        for (D(), c = o.length; c < i.length; c += 1)
          s(c);
        N();
      }
      /*leftover*/
      r[1] ? f ? f.p(r, u) : (f = ll(r), f.c(), f.m(l.parentNode, l)) : f && (f.d(1), f = null);
    },
    i(r) {
      if (!t) {
        for (let u = 0; u < o.length; u += 1)
          d(i[u]);
        t = !0;
      }
    },
    o(r) {
      i = i.filter(Boolean);
      for (let u = 0; u < i.length; u += 1)
        m(i[u]);
      t = !1;
    },
    d(r) {
      r && (C(e), C(l)), ve(i, r), f && f.d(r);
    }
  };
}
const wt = 5;
function kt(n, e, l) {
  let t, o, { row: i } = e, { value: s } = e, { schema: f } = e;
  const r = Tl(), u = (c) => {
    c.stopPropagation(), r("clickrelationship", {
      tableId: i.tableId,
      rowId: i._id,
      fieldName: f == null ? void 0 : f.name
    });
  };
  return n.$$set = (c) => {
    "row" in c && l(3, i = c.row), "value" in c && l(4, s = c.value), "schema" in c && l(5, f = c.schema);
  }, n.$$.update = () => {
    n.$$.dirty & /*value*/
    16 && l(0, t = (s == null ? void 0 : s.slice(0, wt)) ?? []), n.$$.dirty & /*value, relationships*/
    17 && l(1, o = ((s == null ? void 0 : s.length) ?? 0) - t.length);
  }, [t, o, u, i, s, f];
}
class tl extends Q {
  constructor(e) {
    super(), U(this, e, kt, bt, X, { row: 3, value: 4, schema: 5 });
  }
}
function nl(n, e, l) {
  const t = n.slice();
  return t[5] = e[l], t;
}
function pt(n) {
  let e, l, t, o;
  return l = new ql({
    props: {
      quiet: !0,
      target: "_blank",
      download: (
        /*attachment*/
        n[5].name
      ),
      href: (
        /*attachment*/
        n[5].url
      ),
      $$slots: { default: [Ct] },
      $$scope: { ctx: n }
    }
  }), l.$on("click", Lt), {
    c() {
      e = A("div"), O(l.$$.fragment), w(e, "class", "file svelte-1abirxi"), w(e, "title", t = /*attachment*/
      n[5].name);
    },
    m(i, s) {
      v(i, e, s), I(l, e, null), o = !0;
    },
    p(i, s) {
      const f = {};
      s & /*attachments*/
      1 && (f.download = /*attachment*/
      i[5].name), s & /*attachments*/
      1 && (f.href = /*attachment*/
      i[5].url), s & /*$$scope, attachments*/
      257 && (f.$$scope = { dirty: s, ctx: i }), l.$set(f), (!o || s & /*attachments*/
      1 && t !== (t = /*attachment*/
      i[5].name)) && w(e, "title", t);
    },
    i(i) {
      o || (d(l.$$.fragment, i), o = !0);
    },
    o(i) {
      m(l.$$.fragment, i), o = !1;
    },
    d(i) {
      i && C(e), j(l);
    }
  };
}
function vt(n) {
  let e, l;
  return e = new ql({
    props: {
      quiet: !0,
      target: "_blank",
      download: (
        /*attachment*/
        n[5].name
      ),
      href: (
        /*attachment*/
        n[5].url
      ),
      $$slots: { default: [Rt] },
      $$scope: { ctx: n }
    }
  }), e.$on("click", Et), {
    c() {
      O(e.$$.fragment);
    },
    m(t, o) {
      I(e, t, o), l = !0;
    },
    p(t, o) {
      const i = {};
      o & /*attachments*/
      1 && (i.download = /*attachment*/
      t[5].name), o & /*attachments*/
      1 && (i.href = /*attachment*/
      t[5].url), o & /*$$scope, attachments*/
      257 && (i.$$scope = { dirty: o, ctx: t }), e.$set(i);
    },
    i(t) {
      l || (d(e.$$.fragment, t), l = !0);
    },
    o(t) {
      m(e.$$.fragment, t), l = !1;
    },
    d(t) {
      j(e, t);
    }
  };
}
function Ct(n) {
  let e = (
    /*attachment*/
    n[5].extension + ""
  ), l;
  return {
    c() {
      l = M(e);
    },
    m(t, o) {
      v(t, l, o);
    },
    p(t, o) {
      o & /*attachments*/
      1 && e !== (e = /*attachment*/
      t[5].extension + "") && Z(l, e);
    },
    d(t) {
      t && C(l);
    }
  };
}
function Rt(n) {
  let e, l, t, o, i;
  return {
    c() {
      e = A("div"), l = A("img"), Je(l.src, t = /*attachment*/
      n[5].url) || w(l, "src", t), w(l, "alt", o = /*attachment*/
      n[5].extension), w(l, "class", "svelte-1abirxi"), w(e, "class", "center svelte-1abirxi"), w(e, "title", i = /*attachment*/
      n[5].name);
    },
    m(s, f) {
      v(s, e, f), y(e, l);
    },
    p(s, f) {
      f & /*attachments*/
      1 && !Je(l.src, t = /*attachment*/
      s[5].url) && w(l, "src", t), f & /*attachments*/
      1 && o !== (o = /*attachment*/
      s[5].extension) && w(l, "alt", o), f & /*attachments*/
      1 && i !== (i = /*attachment*/
      s[5].name) && w(e, "title", i);
    },
    d(s) {
      s && C(e);
    }
  };
}
function ol(n) {
  let e, l, t, o, i;
  const s = [vt, pt], f = [];
  function r(u, c) {
    return c & /*attachments*/
    1 && (e = null), e == null && (e = !!/*isImage*/
    u[2](
      /*attachment*/
      u[5].extension
    )), e ? 0 : 1;
  }
  return l = r(n, -1), t = f[l] = s[l](n), {
    c() {
      t.c(), o = fe();
    },
    m(u, c) {
      f[l].m(u, c), v(u, o, c), i = !0;
    },
    p(u, c) {
      let _ = l;
      l = r(u, c), l === _ ? f[l].p(u, c) : (D(), m(f[_], 1, 1, () => {
        f[_] = null;
      }), N(), t = f[l], t ? t.p(u, c) : (t = f[l] = s[l](u), t.c()), d(t, 1), t.m(o.parentNode, o));
    },
    i(u) {
      i || (d(t), i = !0);
    },
    o(u) {
      m(t), i = !1;
    },
    d(u) {
      u && C(o), f[l].d(u);
    }
  };
}
function il(n) {
  let e, l, t, o;
  return {
    c() {
      e = A("div"), l = M("+"), t = M(
        /*leftover*/
        n[1]
      ), o = M(" more");
    },
    m(i, s) {
      v(i, e, s), y(e, l), y(e, t), y(e, o);
    },
    p(i, s) {
      s & /*leftover*/
      2 && Z(
        t,
        /*leftover*/
        i[1]
      );
    },
    d(i) {
      i && C(e);
    }
  };
}
function St(n) {
  let e, l, t, o = $(
    /*attachments*/
    n[0]
  ), i = [];
  for (let r = 0; r < o.length; r += 1)
    i[r] = ol(nl(n, o, r));
  const s = (r) => m(i[r], 1, 1, () => {
    i[r] = null;
  });
  let f = (
    /*leftover*/
    n[1] && il(n)
  );
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = V(), f && f.c(), l = fe();
    },
    m(r, u) {
      for (let c = 0; c < i.length; c += 1)
        i[c] && i[c].m(r, u);
      v(r, e, u), f && f.m(r, u), v(r, l, u), t = !0;
    },
    p(r, [u]) {
      if (u & /*attachments, isImage*/
      5) {
        o = $(
          /*attachments*/
          r[0]
        );
        let c;
        for (c = 0; c < o.length; c += 1) {
          const _ = nl(r, o, c);
          i[c] ? (i[c].p(_, u), d(i[c], 1)) : (i[c] = ol(_), i[c].c(), d(i[c], 1), i[c].m(e.parentNode, e));
        }
        for (D(), c = o.length; c < i.length; c += 1)
          s(c);
        N();
      }
      /*leftover*/
      r[1] ? f ? f.p(r, u) : (f = il(r), f.c(), f.m(l.parentNode, l)) : f && (f.d(1), f = null);
    },
    i(r) {
      if (!t) {
        for (let u = 0; u < o.length; u += 1)
          d(i[u]);
        t = !0;
      }
    },
    o(r) {
      i = i.filter(Boolean);
      for (let u = 0; u < i.length; u += 1)
        m(i[u]);
      t = !1;
    },
    d(r) {
      r && (C(e), C(l)), ve(i, r), f && f.d(r);
    }
  };
}
const yt = 5, Et = (n) => {
  n.stopPropagation();
}, Lt = (n) => {
  n.stopPropagation();
};
function Tt(n, e, l) {
  let t, o, { value: i } = e;
  const s = ["png", "tiff", "gif", "raw", "jpg", "jpeg"], f = (r) => s.includes((r == null ? void 0 : r.toLowerCase()) ?? "");
  return n.$$set = (r) => {
    "value" in r && l(3, i = r.value);
  }, n.$$.update = () => {
    n.$$.dirty & /*value*/
    8 && l(0, t = (i == null ? void 0 : i.slice(0, yt)) ?? []), n.$$.dirty & /*value, attachments*/
    9 && l(1, o = ((i == null ? void 0 : i.length) ?? 0) - t.length);
  }, [t, o, f, i];
}
class qt extends Q {
  constructor(e) {
    super(), U(this, e, Tt, St, X, { value: 3 });
  }
}
function rl(n, e, l) {
  const t = n.slice();
  return t[4] = e[l], t;
}
function At(n) {
  let e = (
    /*badge*/
    n[4] + ""
  ), l;
  return {
    c() {
      l = M(e);
    },
    m(t, o) {
      v(t, l, o);
    },
    p(t, o) {
      o & /*badges*/
      1 && e !== (e = /*badge*/
      t[4] + "") && Z(l, e);
    },
    d(t) {
      t && C(l);
    }
  };
}
function sl(n) {
  let e, l;
  return e = new Nl({
    props: {
      size: "S",
      grey: !0,
      $$slots: { default: [At] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      O(e.$$.fragment);
    },
    m(t, o) {
      I(e, t, o), l = !0;
    },
    p(t, o) {
      const i = {};
      o & /*$$scope, badges*/
      129 && (i.$$scope = { dirty: o, ctx: t }), e.$set(i);
    },
    i(t) {
      l || (d(e.$$.fragment, t), l = !0);
    },
    o(t) {
      m(e.$$.fragment, t), l = !1;
    },
    d(t) {
      j(e, t);
    }
  };
}
function fl(n) {
  let e, l, t, o;
  return {
    c() {
      e = A("div"), l = M("+"), t = M(
        /*leftover*/
        n[1]
      ), o = M(" more");
    },
    m(i, s) {
      v(i, e, s), y(e, l), y(e, t), y(e, o);
    },
    p(i, s) {
      s & /*leftover*/
      2 && Z(
        t,
        /*leftover*/
        i[1]
      );
    },
    d(i) {
      i && C(e);
    }
  };
}
function Bt(n) {
  let e, l, t, o = $(
    /*badges*/
    n[0]
  ), i = [];
  for (let r = 0; r < o.length; r += 1)
    i[r] = sl(rl(n, o, r));
  const s = (r) => m(i[r], 1, 1, () => {
    i[r] = null;
  });
  let f = (
    /*leftover*/
    n[1] && fl(n)
  );
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = V(), f && f.c(), l = fe();
    },
    m(r, u) {
      for (let c = 0; c < i.length; c += 1)
        i[c] && i[c].m(r, u);
      v(r, e, u), f && f.m(r, u), v(r, l, u), t = !0;
    },
    p(r, [u]) {
      if (u & /*badges*/
      1) {
        o = $(
          /*badges*/
          r[0]
        );
        let c;
        for (c = 0; c < o.length; c += 1) {
          const _ = rl(r, o, c);
          i[c] ? (i[c].p(_, u), d(i[c], 1)) : (i[c] = sl(_), i[c].c(), d(i[c], 1), i[c].m(e.parentNode, e));
        }
        for (D(), c = o.length; c < i.length; c += 1)
          s(c);
        N();
      }
      /*leftover*/
      r[1] ? f ? f.p(r, u) : (f = fl(r), f.c(), f.m(l.parentNode, l)) : f && (f.d(1), f = null);
    },
    i(r) {
      if (!t) {
        for (let u = 0; u < o.length; u += 1)
          d(i[u]);
        t = !0;
      }
    },
    o(r) {
      i = i.filter(Boolean);
      for (let u = 0; u < i.length; u += 1)
        m(i[u]);
      t = !1;
    },
    d(r) {
      r && (C(e), C(l)), ve(i, r), f && f.d(r);
    }
  };
}
const zt = 5;
function Dt(n, e, l) {
  let t, o, i, { value: s } = e;
  return n.$$set = (f) => {
    "value" in f && l(2, s = f.value);
  }, n.$$.update = () => {
    n.$$.dirty & /*value*/
    4 && l(3, t = Array.isArray(s) ? s : [s].filter((f) => !!f)), n.$$.dirty & /*arrayValue*/
    8 && l(0, o = t.slice(0, zt)), n.$$.dirty & /*arrayValue, badges*/
    9 && l(1, i = t.length - o.length);
  }, [o, i, s, t];
}
class Nt extends Q {
  constructor(e) {
    super(), U(this, e, Dt, Bt, X, { value: 2 });
  }
}
function Mt(n) {
  let e, l, t, o, i;
  return l = new de({ props: { size: "S", name: "copy" } }), {
    c() {
      e = A("div"), O(l.$$.fragment);
    },
    m(s, f) {
      v(s, e, f), I(l, e, null), t = !0, o || (i = Ne(e, "click", Ql(
        /*onClick*/
        n[0]
      )), o = !0);
    },
    p: ie,
    i(s) {
      t || (d(l.$$.fragment, s), t = !0);
    },
    o(s) {
      m(l.$$.fragment, s), t = !1;
    },
    d(s) {
      s && C(e), j(l), o = !1, i();
    }
  };
}
function Ot(n, e, l) {
  let { value: t } = e;
  const o = async (i) => {
    i.stopPropagation();
    try {
      await Ul(t), Xe.success("Copied to clipboard");
    } catch {
      Xe.error("Failed to copy to clipboard. Check the dev console for the value."), console.warn("Failed to copy the value", t);
    }
  };
  return n.$$set = (i) => {
    "value" in i && l(1, t = i.value);
  }, [o, t];
}
class It extends Q {
  constructor(e) {
    super(), U(this, e, Ot, Mt, X, { value: 1 });
  }
}
function ul(n) {
  let e, l, t;
  var o = (
    /*renderer*/
    n[3]
  );
  function i(s, f) {
    return {
      props: {
        row: (
          /*row*/
          s[0]
        ),
        schema: (
          /*schema*/
          s[1]
        ),
        value: (
          /*cellValue*/
          s[4]
        ),
        $$slots: { default: [jt] },
        $$scope: { ctx: s }
      }
    };
  }
  return o && (l = We(o, i(n)), l.$on(
    "clickrelationship",
    /*clickrelationship_handler*/
    n[10]
  ), l.$on(
    "buttonclick",
    /*buttonclick_handler*/
    n[11]
  )), {
    c() {
      e = A("div"), l && O(l.$$.fragment), Ke(
        e,
        "--max-cell-width",
        /*schema*/
        n[1].width ? "none" : "200px"
      ), w(e, "class", "svelte-16j2cvj");
    },
    m(s, f) {
      v(s, e, f), l && I(l, e, null), t = !0;
    },
    p(s, f) {
      if (f & /*renderer*/
      8 && o !== (o = /*renderer*/
      s[3])) {
        if (l) {
          D();
          const r = l;
          m(r.$$.fragment, 1, 0, () => {
            j(r, 1);
          }), N();
        }
        o ? (l = We(o, i(s)), l.$on(
          "clickrelationship",
          /*clickrelationship_handler*/
          s[10]
        ), l.$on(
          "buttonclick",
          /*buttonclick_handler*/
          s[11]
        ), O(l.$$.fragment), d(l.$$.fragment, 1), I(l, e, null)) : l = null;
      } else if (o) {
        const r = {};
        f & /*row*/
        1 && (r.row = /*row*/
        s[0]), f & /*schema*/
        2 && (r.schema = /*schema*/
        s[1]), f & /*cellValue*/
        16 && (r.value = /*cellValue*/
        s[4]), f & /*$$scope*/
        4096 && (r.$$scope = { dirty: f, ctx: s }), l.$set(r);
      }
      (!t || f & /*schema*/
      2) && Ke(
        e,
        "--max-cell-width",
        /*schema*/
        s[1].width ? "none" : "200px"
      );
    },
    i(s) {
      t || (l && d(l.$$.fragment, s), t = !0);
    },
    o(s) {
      l && m(l.$$.fragment, s), t = !1;
    },
    d(s) {
      s && C(e), l && j(l);
    }
  };
}
function jt(n) {
  let e;
  const l = (
    /*#slots*/
    n[9].default
  ), t = me(
    l,
    n,
    /*$$scope*/
    n[12],
    null
  );
  return {
    c() {
      t && t.c();
    },
    m(o, i) {
      t && t.m(o, i), e = !0;
    },
    p(o, i) {
      t && t.p && (!e || i & /*$$scope*/
      4096) && ge(
        t,
        l,
        o,
        /*$$scope*/
        o[12],
        e ? be(
          l,
          /*$$scope*/
          o[12],
          i,
          null
        ) : he(
          /*$$scope*/
          o[12]
        ),
        null
      );
    },
    i(o) {
      e || (d(t, o), e = !0);
    },
    o(o) {
      m(t, o), e = !1;
    },
    d(o) {
      t && t.d(o);
    }
  };
}
function Ht(n) {
  let e, l, t = (
    /*renderer*/
    n[3] && /*customRenderer*/
    (n[2] || /*cellValue*/
    n[4] != null && /*cellValue*/
    n[4] !== "") && ul(n)
  );
  return {
    c() {
      t && t.c(), e = fe();
    },
    m(o, i) {
      t && t.m(o, i), v(o, e, i), l = !0;
    },
    p(o, [i]) {
      /*renderer*/
      o[3] && /*customRenderer*/
      (o[2] || /*cellValue*/
      o[4] != null && /*cellValue*/
      o[4] !== "") ? t ? (t.p(o, i), i & /*renderer, customRenderer, cellValue*/
      28 && d(t, 1)) : (t = ul(o), t.c(), d(t, 1), t.m(e.parentNode, e)) : t && (D(), m(t, 1, 1, () => {
        t = null;
      }), N());
    },
    i(o) {
      l || (d(t), l = !0);
    },
    o(o) {
      m(t), l = !1;
    },
    d(o) {
      o && C(e), t && t.d(o);
    }
  };
}
function Ft(n, e, l) {
  let t, o, i, { $$slots: s = {}, $$scope: f } = e, { row: r } = e, { schema: u } = e, { value: c } = e, { customRenderers: _ = [] } = e, { snippets: E } = e, S;
  const T = {
    boolean: _t,
    datetime: gt,
    link: tl,
    attachment: qt,
    string: ze,
    options: ze,
    number: ze,
    longform: ze,
    array: Nt,
    internal: It,
    bb_reference: tl
  }, L = (k) => (k == null ? void 0 : k.type) === "datetime" && (k != null && k.template) ? "string" : (k == null ? void 0 : k.type) || "string", H = (k, z) => z ? Zl(z, { value: k, snippets: E }) : k;
  function R(k) {
    De.call(this, n, k);
  }
  function q(k) {
    De.call(this, n, k);
  }
  return n.$$set = (k) => {
    "row" in k && l(0, r = k.row), "schema" in k && l(1, u = k.schema), "value" in k && l(5, c = k.value), "customRenderers" in k && l(6, _ = k.customRenderers), "snippets" in k && l(7, E = k.snippets), "$$scope" in k && l(12, f = k.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*schema*/
    2 && l(8, t = L(u)), n.$$.dirty & /*customRenderers, schema*/
    66 && l(2, o = _ == null ? void 0 : _.find((k) => k.column === (u == null ? void 0 : u.name))), n.$$.dirty & /*customRenderer, type*/
    260 && l(3, S = (o == null ? void 0 : o.component) ?? T[t] ?? ze), n.$$.dirty & /*value, schema*/
    34 && l(4, i = H(c, u.template));
  }, [
    r,
    u,
    o,
    S,
    i,
    c,
    _,
    E,
    t,
    s,
    R,
    q,
    f
  ];
}
class Pt extends Q {
  constructor(e) {
    super(), U(this, e, Ft, Ht, X, {
      row: 0,
      schema: 1,
      value: 5,
      customRenderers: 6,
      snippets: 7
    });
  }
}
function cl(n) {
  let e, l;
  return e = new Al({
    props: {
      value: (
        /*selected*/
        n[0]
      ),
      disabled: (
        /*data*/
        n[4].__disabled
      )
    }
  }), {
    c() {
      O(e.$$.fragment);
    },
    m(t, o) {
      I(e, t, o), l = !0;
    },
    p(t, o) {
      const i = {};
      o & /*selected*/
      1 && (i.value = /*selected*/
      t[0]), o & /*data*/
      16 && (i.disabled = /*data*/
      t[4].__disabled), e.$set(i);
    },
    i(t) {
      l || (d(e.$$.fragment, t), l = !0);
    },
    o(t) {
      m(e.$$.fragment, t), l = !1;
    },
    d(t) {
      j(e, t);
    }
  };
}
function al(n) {
  let e, l;
  return e = new $l({
    props: {
      size: "S",
      $$slots: { default: [Yt] },
      $$scope: { ctx: n }
    }
  }), e.$on("click", function() {
    Bl(
      /*onEdit*/
      n[1]
    ) && n[1].apply(this, arguments);
  }), {
    c() {
      O(e.$$.fragment);
    },
    m(t, o) {
      I(e, t, o), l = !0;
    },
    p(t, o) {
      n = t;
      const i = {};
      o & /*$$scope*/
      32 && (i.$$scope = { dirty: o, ctx: n }), e.$set(i);
    },
    i(t) {
      l || (d(e.$$.fragment, t), l = !0);
    },
    o(t) {
      m(e.$$.fragment, t), l = !1;
    },
    d(t) {
      j(e, t);
    }
  };
}
function Yt(n) {
  let e;
  return {
    c() {
      e = M("Edit");
    },
    m(l, t) {
      v(l, e, t);
    },
    d(l) {
      l && C(e);
    }
  };
}
function Gt(n) {
  let e, l, t, o = (
    /*allowSelectRows*/
    n[2] && /*data*/
    n[4].__selectable !== !1 && cl(n)
  ), i = (
    /*allowEditRows*/
    n[3] && al(n)
  );
  return {
    c() {
      e = A("div"), o && o.c(), l = V(), i && i.c(), w(e, "class", "svelte-1fa8hd3");
    },
    m(s, f) {
      v(s, e, f), o && o.m(e, null), y(e, l), i && i.m(e, null), t = !0;
    },
    p(s, [f]) {
      /*allowSelectRows*/
      s[2] && /*data*/
      s[4].__selectable !== !1 ? o ? (o.p(s, f), f & /*allowSelectRows, data*/
      20 && d(o, 1)) : (o = cl(s), o.c(), d(o, 1), o.m(e, l)) : o && (D(), m(o, 1, 1, () => {
        o = null;
      }), N()), /*allowEditRows*/
      s[3] ? i ? (i.p(s, f), f & /*allowEditRows*/
      8 && d(i, 1)) : (i = al(s), i.c(), d(i, 1), i.m(e, null)) : i && (D(), m(i, 1, 1, () => {
        i = null;
      }), N());
    },
    i(s) {
      t || (d(o), d(i), t = !0);
    },
    o(s) {
      m(o), m(i), t = !1;
    },
    d(s) {
      s && C(e), o && o.d(), i && i.d();
    }
  };
}
function Vt(n, e, l) {
  let { selected: t } = e, { onEdit: o } = e, { allowSelectRows: i = !1 } = e, { allowEditRows: s = !1 } = e, { data: f } = e;
  return n.$$set = (r) => {
    "selected" in r && l(0, t = r.selected), "onEdit" in r && l(1, o = r.onEdit), "allowSelectRows" in r && l(2, i = r.allowSelectRows), "allowEditRows" in r && l(3, s = r.allowEditRows), "data" in r && l(4, f = r.data);
  }, [t, o, i, s, f];
}
class Jt extends Q {
  constructor(e) {
    super(), U(this, e, Vt, Gt, X, {
      selected: 0,
      onEdit: 1,
      allowSelectRows: 2,
      allowEditRows: 3,
      data: 4
    });
  }
}
const Xt = (n) => ({}), _l = (n) => ({});
function dl(n, e, l) {
  const t = n.slice();
  return t[64] = e[l], t;
}
function ml(n, e, l) {
  const t = n.slice();
  return t[67] = e[l], t;
}
function gl(n, e, l) {
  const t = n.slice();
  return t[67] = e[l], t;
}
const Wt = (n) => ({}), hl = (n) => ({});
function Kt(n) {
  let e, l, t, o, i, s, f = (
    /*fields*/
    n[18].length && bl(n)
  );
  const r = [xt, $t], u = [];
  function c(_, E) {
    var S;
    return (
      /*sortedRows*/
      (S = _[24]) != null && S.length ? 0 : 1
    );
  }
  return t = c(n), o = u[t] = r[t](n), {
    c() {
      e = A("div"), f && f.c(), l = V(), o.c(), w(e, "class", "spectrum-Table svelte-qx6w80"), w(e, "style", i = `${/*heightStyle*/
      n[25]}${/*gridStyle*/
      n[23]}`), b(e, "no-scroll", !/*rowCount*/
      n[2]);
    },
    m(_, E) {
      v(_, e, E), f && f.m(e, null), y(e, l), u[t].m(e, null), s = !0;
    },
    p(_, E) {
      /*fields*/
      _[18].length ? f ? (f.p(_, E), E[0] & /*fields*/
      262144 && d(f, 1)) : (f = bl(_), f.c(), d(f, 1), f.m(e, l)) : f && (D(), m(f, 1, 1, () => {
        f = null;
      }), N());
      let S = t;
      t = c(_), t === S ? u[t].p(_, E) : (D(), m(u[S], 1, 1, () => {
        u[S] = null;
      }), N(), o = u[t], o ? o.p(_, E) : (o = u[t] = r[t](_), o.c()), d(o, 1), o.m(e, null)), (!s || E[0] & /*heightStyle, gridStyle*/
      41943040 && i !== (i = `${/*heightStyle*/
      _[25]}${/*gridStyle*/
      _[23]}`)) && w(e, "style", i), (!s || E[0] & /*rowCount*/
      4) && b(e, "no-scroll", !/*rowCount*/
      _[2]);
    },
    i(_) {
      s || (d(f), d(o), s = !0);
    },
    o(_) {
      m(f), m(o), s = !1;
    },
    d(_) {
      _ && C(e), f && f.d(), u[t].d();
    }
  };
}
function Qt(n) {
  let e, l;
  const t = (
    /*#slots*/
    n[44].loadingIndicator
  ), o = me(
    t,
    n,
    /*$$scope*/
    n[55],
    hl
  ), i = o || nn();
  return {
    c() {
      e = A("div"), i && i.c(), w(e, "class", "loading svelte-qx6w80"), w(
        e,
        "style",
        /*heightStyle*/
        n[25]
      );
    },
    m(s, f) {
      v(s, e, f), i && i.m(e, null), l = !0;
    },
    p(s, f) {
      o && o.p && (!l || f[1] & /*$$scope*/
      16777216) && ge(
        o,
        t,
        s,
        /*$$scope*/
        s[55],
        l ? be(
          t,
          /*$$scope*/
          s[55],
          f,
          Wt
        ) : he(
          /*$$scope*/
          s[55]
        ),
        hl
      ), (!l || f[0] & /*heightStyle*/
      33554432) && w(
        e,
        "style",
        /*heightStyle*/
        s[25]
      );
    },
    i(s) {
      l || (d(i, s), l = !0);
    },
    o(s) {
      m(i, s), l = !1;
    },
    d(s) {
      s && C(e), i && i.d(s);
    }
  };
}
function bl(n) {
  let e, l, t, o = (
    /*showEditColumn*/
    n[17] && wl(n)
  ), i = $(
    /*fields*/
    n[18]
  ), s = [];
  for (let r = 0; r < i.length; r += 1)
    s[r] = Cl(gl(n, i, r));
  const f = (r) => m(s[r], 1, 1, () => {
    s[r] = null;
  });
  return {
    c() {
      e = A("div"), o && o.c(), l = V();
      for (let r = 0; r < s.length; r += 1)
        s[r].c();
      w(e, "class", "spectrum-Table-head svelte-qx6w80");
    },
    m(r, u) {
      v(r, e, u), o && o.m(e, null), y(e, l);
      for (let c = 0; c < s.length; c += 1)
        s[c] && s[c].m(e, null);
      t = !0;
    },
    p(r, u) {
      if (/*showEditColumn*/
      r[17] ? o ? (o.p(r, u), u[0] & /*showEditColumn*/
      131072 && d(o, 1)) : (o = wl(r), o.c(), d(o, 1), o.m(e, l)) : o && (D(), m(o, 1, 1, () => {
        o = null;
      }), N()), u[0] & /*showHeaderBorder, schema, fields, sortColumn, sortOrder, sortBy, editColumn, allowEditColumns, getDisplayName*/
      939888769) {
        i = $(
          /*fields*/
          r[18]
        );
        let c;
        for (c = 0; c < i.length; c += 1) {
          const _ = gl(r, i, c);
          s[c] ? (s[c].p(_, u), d(s[c], 1)) : (s[c] = Cl(_), s[c].c(), d(s[c], 1), s[c].m(e, null));
        }
        for (D(), c = i.length; c < s.length; c += 1)
          f(c);
        N();
      }
    },
    i(r) {
      if (!t) {
        d(o);
        for (let u = 0; u < i.length; u += 1)
          d(s[u]);
        t = !0;
      }
    },
    o(r) {
      m(o), s = s.filter(Boolean);
      for (let u = 0; u < s.length; u += 1)
        m(s[u]);
      t = !1;
    },
    d(r) {
      r && C(e), o && o.d(), ve(s, r);
    }
  };
}
function wl(n) {
  let e, l, t, o;
  const i = [Zt, Ut], s = [];
  function f(r, u) {
    return (
      /*allowSelectRows*/
      r[5] ? 0 : 1
    );
  }
  return l = f(n), t = s[l] = i[l](n), {
    c() {
      e = A("div"), t.c(), w(e, "class", "spectrum-Table-headCell spectrum-Table-headCell--divider spectrum-Table-headCell--edit svelte-qx6w80"), b(e, "noBorderHeader", !/*showHeaderBorder*/
      n[12]);
    },
    m(r, u) {
      v(r, e, u), s[l].m(e, null), o = !0;
    },
    p(r, u) {
      let c = l;
      l = f(r), l === c ? s[l].p(r, u) : (D(), m(s[c], 1, 1, () => {
        s[c] = null;
      }), N(), t = s[l], t ? t.p(r, u) : (t = s[l] = i[l](r), t.c()), d(t, 1), t.m(e, null)), (!o || u[0] & /*showHeaderBorder*/
      4096) && b(e, "noBorderHeader", !/*showHeaderBorder*/
      r[12]);
    },
    i(r) {
      o || (d(t), o = !0);
    },
    o(r) {
      m(t), o = !1;
    },
    d(r) {
      r && C(e), s[l].d();
    }
  };
}
function Ut(n) {
  let e;
  return {
    c() {
      e = M("Edit");
    },
    m(l, t) {
      v(l, e, t);
    },
    p: ie,
    i: ie,
    o: ie,
    d(l) {
      l && C(e);
    }
  };
}
function Zt(n) {
  let e, l, t;
  function o(s) {
    n[45](s);
  }
  let i = {};
  return (
    /*checkboxStatus*/
    n[21] !== void 0 && (i.value = /*checkboxStatus*/
    n[21]), e = new Al({ props: i }), Fe.push(() => zl(e, "value", o)), e.$on(
      "change",
      /*toggleSelectAll*/
      n[32]
    ), {
      c() {
        O(e.$$.fragment);
      },
      m(s, f) {
        I(e, s, f), t = !0;
      },
      p(s, f) {
        const r = {};
        !l && f[0] & /*checkboxStatus*/
        2097152 && (l = !0, r.value = /*checkboxStatus*/
        s[21], Dl(() => l = !1)), e.$set(r);
      },
      i(s) {
        t || (d(e.$$.fragment, s), t = !0);
      },
      o(s) {
        m(e.$$.fragment, s), t = !1;
      },
      d(s) {
        j(e, s);
      }
    }
  );
}
function kl(n) {
  let e, l;
  return e = new de({
    props: {
      name: "magic-wand",
      size: "S",
      color: "var(--spectrum-global-color-gray-600)"
    }
  }), {
    c() {
      O(e.$$.fragment);
    },
    m(t, o) {
      I(e, t, o), l = !0;
    },
    i(t) {
      l || (d(e.$$.fragment, t), l = !0);
    },
    o(t) {
      m(e.$$.fragment, t), l = !1;
    },
    d(t) {
      j(e, t);
    }
  };
}
function pl(n) {
  let e, l;
  return e = new de({
    props: {
      name: "caret-down",
      size: "S",
      color: "var(--spectrum-global-color-gray-700)"
    }
  }), {
    c() {
      O(e.$$.fragment);
    },
    m(t, o) {
      I(e, t, o), l = !0;
    },
    i(t) {
      l || (d(e.$$.fragment, t), l = !0);
    },
    o(t) {
      m(e.$$.fragment, t), l = !1;
    },
    d(t) {
      j(e, t);
    }
  };
}
function vl(n) {
  let e, l;
  function t(...o) {
    return (
      /*click_handler*/
      n[46](
        /*field*/
        n[67],
        ...o
      )
    );
  }
  return e = new de({
    props: {
      name: "pencil",
      size: "S",
      hoverable: !0,
      color: "var(--spectrum-global-color-gray-600)",
      hoverColor: "var(--spectrum-global-color-gray-900)"
    }
  }), e.$on("click", t), {
    c() {
      O(e.$$.fragment);
    },
    m(o, i) {
      I(e, o, i), l = !0;
    },
    p(o, i) {
      n = o;
    },
    i(o) {
      l || (d(e.$$.fragment, o), l = !0);
    },
    o(o) {
      m(e.$$.fragment, o), l = !1;
    },
    d(o) {
      j(e, o);
    }
  };
}
function Cl(n) {
  var R, q;
  let e, l, t = (
    /*getDisplayName*/
    n[28](
      /*schema*/
      n[0][
        /*field*/
        n[67]
      ]
    ) + ""
  ), o, i, s, f, r, u, c, _, E, S = (
    /*schema*/
    ((R = n[0][
      /*field*/
      n[67]
    ]) == null ? void 0 : R.autocolumn) && kl()
  ), T = (
    /*sortColumn*/
    n[15] === /*field*/
    n[67] && pl()
  ), L = (
    /*allowEditColumns*/
    n[7] && /*schema*/
    ((q = n[0][
      /*field*/
      n[67]
    ]) == null ? void 0 : q.editable) !== !1 && vl(n)
  );
  function H() {
    return (
      /*click_handler_1*/
      n[47](
        /*field*/
        n[67]
      )
    );
  }
  return {
    c() {
      e = A("div"), l = A("div"), o = M(t), i = V(), S && S.c(), s = V(), T && T.c(), f = V(), L && L.c(), u = V(), w(l, "class", "title svelte-qx6w80"), w(l, "title", r = /*field*/
      n[67]), w(e, "class", "spectrum-Table-headCell svelte-qx6w80"), b(e, "noBorderHeader", !/*showHeaderBorder*/
      n[12]), b(
        e,
        "spectrum-Table-headCell--alignCenter",
        /*schema*/
        n[0][
          /*field*/
          n[67]
        ].align === "Center"
      ), b(
        e,
        "spectrum-Table-headCell--alignRight",
        /*schema*/
        n[0][
          /*field*/
          n[67]
        ].align === "Right"
      ), b(
        e,
        "is-sortable",
        /*schema*/
        n[0][
          /*field*/
          n[67]
        ].sortable !== !1
      ), b(
        e,
        "is-sorted-desc",
        /*sortColumn*/
        n[15] === /*field*/
        n[67] && /*sortOrder*/
        n[16] === "Descending"
      ), b(
        e,
        "is-sorted-asc",
        /*sortColumn*/
        n[15] === /*field*/
        n[67] && /*sortOrder*/
        n[16] === "Ascending"
      );
    },
    m(k, z) {
      v(k, e, z), y(e, l), y(l, o), y(l, i), S && S.m(l, null), y(l, s), T && T.m(l, null), y(l, f), L && L.m(l, null), y(e, u), c = !0, _ || (E = Ne(e, "click", H), _ = !0);
    },
    p(k, z) {
      var le, ne;
      n = k, (!c || z[0] & /*schema, fields*/
      262145) && t !== (t = /*getDisplayName*/
      n[28](
        /*schema*/
        n[0][
          /*field*/
          n[67]
        ]
      ) + "") && Z(o, t), /*schema*/
      (le = n[0][
        /*field*/
        n[67]
      ]) != null && le.autocolumn ? S ? z[0] & /*schema, fields*/
      262145 && d(S, 1) : (S = kl(), S.c(), d(S, 1), S.m(l, s)) : S && (D(), m(S, 1, 1, () => {
        S = null;
      }), N()), /*sortColumn*/
      n[15] === /*field*/
      n[67] ? T ? z[0] & /*sortColumn, fields*/
      294912 && d(T, 1) : (T = pl(), T.c(), d(T, 1), T.m(l, f)) : T && (D(), m(T, 1, 1, () => {
        T = null;
      }), N()), /*allowEditColumns*/
      n[7] && /*schema*/
      ((ne = n[0][
        /*field*/
        n[67]
      ]) == null ? void 0 : ne.editable) !== !1 ? L ? (L.p(n, z), z[0] & /*allowEditColumns, schema, fields*/
      262273 && d(L, 1)) : (L = vl(n), L.c(), d(L, 1), L.m(l, null)) : L && (D(), m(L, 1, 1, () => {
        L = null;
      }), N()), (!c || z[0] & /*fields*/
      262144 && r !== (r = /*field*/
      n[67])) && w(l, "title", r), (!c || z[0] & /*showHeaderBorder*/
      4096) && b(e, "noBorderHeader", !/*showHeaderBorder*/
      n[12]), (!c || z[0] & /*schema, fields*/
      262145) && b(
        e,
        "spectrum-Table-headCell--alignCenter",
        /*schema*/
        n[0][
          /*field*/
          n[67]
        ].align === "Center"
      ), (!c || z[0] & /*schema, fields*/
      262145) && b(
        e,
        "spectrum-Table-headCell--alignRight",
        /*schema*/
        n[0][
          /*field*/
          n[67]
        ].align === "Right"
      ), (!c || z[0] & /*schema, fields*/
      262145) && b(
        e,
        "is-sortable",
        /*schema*/
        n[0][
          /*field*/
          n[67]
        ].sortable !== !1
      ), (!c || z[0] & /*sortColumn, fields, sortOrder*/
      360448) && b(
        e,
        "is-sorted-desc",
        /*sortColumn*/
        n[15] === /*field*/
        n[67] && /*sortOrder*/
        n[16] === "Descending"
      ), (!c || z[0] & /*sortColumn, fields, sortOrder*/
      360448) && b(
        e,
        "is-sorted-asc",
        /*sortColumn*/
        n[15] === /*field*/
        n[67] && /*sortOrder*/
        n[16] === "Ascending"
      );
    },
    i(k) {
      c || (d(S), d(T), d(L), c = !0);
    },
    o(k) {
      m(S), m(T), m(L), c = !1;
    },
    d(k) {
      k && C(e), S && S.d(), T && T.d(), L && L.d(), _ = !1, E();
    }
  };
}
function $t(n) {
  let e, l, t, o;
  const i = [ln, en], s = [];
  function f(r, u) {
    return (
      /*customPlaceholder*/
      r[11] ? 0 : 1
    );
  }
  return l = f(n), t = s[l] = i[l](n), {
    c() {
      var r;
      e = A("div"), t.c(), w(e, "class", "placeholder svelte-qx6w80"), b(
        e,
        "placeholder--custom",
        /*customPlaceholder*/
        n[11]
      ), b(e, "placeholder--no-fields", !/*fields*/
      ((r = n[18]) != null && r.length));
    },
    m(r, u) {
      v(r, e, u), s[l].m(e, null), o = !0;
    },
    p(r, u) {
      var _;
      let c = l;
      l = f(r), l === c ? s[l].p(r, u) : (D(), m(s[c], 1, 1, () => {
        s[c] = null;
      }), N(), t = s[l], t ? t.p(r, u) : (t = s[l] = i[l](r), t.c()), d(t, 1), t.m(e, null)), (!o || u[0] & /*customPlaceholder*/
      2048) && b(
        e,
        "placeholder--custom",
        /*customPlaceholder*/
        r[11]
      ), (!o || u[0] & /*fields*/
      262144) && b(e, "placeholder--no-fields", !/*fields*/
      ((_ = r[18]) != null && _.length));
    },
    i(r) {
      o || (d(t), o = !0);
    },
    o(r) {
      m(t), o = !1;
    },
    d(r) {
      r && C(e), s[l].d();
    }
  };
}
function xt(n) {
  let e, l, t = $(
    /*sortedRows*/
    n[24]
  ), o = [];
  for (let s = 0; s < t.length; s += 1)
    o[s] = yl(dl(n, t, s));
  const i = (s) => m(o[s], 1, 1, () => {
    o[s] = null;
  });
  return {
    c() {
      for (let s = 0; s < o.length; s += 1)
        o[s].c();
      e = fe();
    },
    m(s, f) {
      for (let r = 0; r < o.length; r += 1)
        o[r] && o[r].m(s, f);
      v(s, e, f), l = !0;
    },
    p(s, f) {
      if (f[0] & /*allowClickRows, fields, cellStyles, schema, dispatch, sortedRows, customRenderers, snippets, showHeaderBorder, selectedRows, editRow, allowSelectRows, allowEditRows, showEditColumn*/
      1162236771 | f[1] & /*toggleSelectRow, $$scope*/
      16777217) {
        t = $(
          /*sortedRows*/
          s[24]
        );
        let r;
        for (r = 0; r < t.length; r += 1) {
          const u = dl(s, t, r);
          o[r] ? (o[r].p(u, f), d(o[r], 1)) : (o[r] = yl(u), o[r].c(), d(o[r], 1), o[r].m(e.parentNode, e));
        }
        for (D(), r = t.length; r < o.length; r += 1)
          i(r);
        N();
      }
    },
    i(s) {
      if (!l) {
        for (let f = 0; f < t.length; f += 1)
          d(o[f]);
        l = !0;
      }
    },
    o(s) {
      o = o.filter(Boolean);
      for (let f = 0; f < o.length; f += 1)
        m(o[f]);
      l = !1;
    },
    d(s) {
      s && C(e), ve(o, s);
    }
  };
}
function en(n) {
  let e, l, t, o, i, s;
  return l = new de({
    props: {
      name: "table",
      size: "XXL",
      color: "var(--spectrum-global-color-gray-600)"
    }
  }), {
    c() {
      e = A("div"), O(l.$$.fragment), t = V(), o = A("div"), i = M(
        /*placeholderText*/
        n[13]
      ), w(o, "class", "svelte-qx6w80"), w(e, "class", "placeholder-content svelte-qx6w80");
    },
    m(f, r) {
      v(f, e, r), I(l, e, null), y(e, t), y(e, o), y(o, i), s = !0;
    },
    p(f, r) {
      (!s || r[0] & /*placeholderText*/
      8192) && Z(
        i,
        /*placeholderText*/
        f[13]
      );
    },
    i(f) {
      s || (d(l.$$.fragment, f), s = !0);
    },
    o(f) {
      m(l.$$.fragment, f), s = !1;
    },
    d(f) {
      f && C(e), j(l);
    }
  };
}
function ln(n) {
  let e;
  const l = (
    /*#slots*/
    n[44].placeholder
  ), t = me(
    l,
    n,
    /*$$scope*/
    n[55],
    _l
  );
  return {
    c() {
      t && t.c();
    },
    m(o, i) {
      t && t.m(o, i), e = !0;
    },
    p(o, i) {
      t && t.p && (!e || i[1] & /*$$scope*/
      16777216) && ge(
        t,
        l,
        o,
        /*$$scope*/
        o[55],
        e ? be(
          l,
          /*$$scope*/
          o[55],
          i,
          Xt
        ) : he(
          /*$$scope*/
          o[55]
        ),
        _l
      );
    },
    i(o) {
      e || (d(t, o), e = !0);
    },
    o(o) {
      m(t, o), e = !1;
    },
    d(o) {
      t && t.d(o);
    }
  };
}
function Rl(n) {
  let e, l, t, o, i;
  function s(...u) {
    return (
      /*func*/
      n[48](
        /*row*/
        n[64],
        ...u
      )
    );
  }
  function f(...u) {
    return (
      /*func_1*/
      n[49](
        /*row*/
        n[64],
        ...u
      )
    );
  }
  l = new Jt({
    props: {
      data: (
        /*row*/
        n[64]
      ),
      selected: (
        /*selectedRows*/
        n[1].findIndex(s) !== -1
      ),
      onEdit: f,
      allowSelectRows: (
        /*allowSelectRows*/
        n[5]
      ),
      allowEditRows: (
        /*allowEditRows*/
        n[6]
      )
    }
  });
  function r(...u) {
    return (
      /*click_handler_2*/
      n[50](
        /*row*/
        n[64],
        ...u
      )
    );
  }
  return {
    c() {
      e = A("div"), O(l.$$.fragment), w(e, "class", "spectrum-Table-cell spectrum-Table-cell--divider spectrum-Table-cell--edit svelte-qx6w80"), b(e, "noBorderCheckbox", !/*showHeaderBorder*/
      n[12]);
    },
    m(u, c) {
      v(u, e, c), I(l, e, null), t = !0, o || (i = Ne(e, "click", r), o = !0);
    },
    p(u, c) {
      n = u;
      const _ = {};
      c[0] & /*sortedRows*/
      16777216 && (_.data = /*row*/
      n[64]), c[0] & /*selectedRows, sortedRows*/
      16777218 && (_.selected = /*selectedRows*/
      n[1].findIndex(s) !== -1), c[0] & /*sortedRows*/
      16777216 && (_.onEdit = f), c[0] & /*allowSelectRows*/
      32 && (_.allowSelectRows = /*allowSelectRows*/
      n[5]), c[0] & /*allowEditRows*/
      64 && (_.allowEditRows = /*allowEditRows*/
      n[6]), l.$set(_), (!t || c[0] & /*showHeaderBorder*/
      4096) && b(e, "noBorderCheckbox", !/*showHeaderBorder*/
      n[12]);
    },
    i(u) {
      t || (d(l.$$.fragment, u), t = !0);
    },
    o(u) {
      m(l.$$.fragment, u), t = !1;
    },
    d(u) {
      u && C(e), j(l), o = !1, i();
    }
  };
}
function tn(n) {
  let e;
  const l = (
    /*#slots*/
    n[44].default
  ), t = me(
    l,
    n,
    /*$$scope*/
    n[55],
    null
  );
  return {
    c() {
      t && t.c();
    },
    m(o, i) {
      t && t.m(o, i), e = !0;
    },
    p(o, i) {
      t && t.p && (!e || i[1] & /*$$scope*/
      16777216) && ge(
        t,
        l,
        o,
        /*$$scope*/
        o[55],
        e ? be(
          l,
          /*$$scope*/
          o[55],
          i,
          null
        ) : he(
          /*$$scope*/
          o[55]
        ),
        null
      );
    },
    i(o) {
      e || (d(t, o), e = !0);
    },
    o(o) {
      m(t, o), e = !1;
    },
    d(o) {
      t && t.d(o);
    }
  };
}
function Sl(n) {
  let e, l, t, o, i, s;
  l = new Pt({
    props: {
      customRenderers: (
        /*customRenderers*/
        n[9]
      ),
      row: (
        /*row*/
        n[64]
      ),
      snippets: (
        /*snippets*/
        n[14]
      ),
      schema: (
        /*schema*/
        n[0][
          /*field*/
          n[67]
        ]
      ),
      value: Qe(
        /*row*/
        n[64],
        /*field*/
        n[67]
      ),
      $$slots: { default: [tn] },
      $$scope: { ctx: n }
    }
  }), l.$on(
    "clickrelationship",
    /*clickrelationship_handler*/
    n[51]
  ), l.$on(
    "buttonclick",
    /*buttonclick_handler*/
    n[52]
  );
  function f() {
    return (
      /*click_handler_3*/
      n[53](
        /*field*/
        n[67],
        /*row*/
        n[64]
      )
    );
  }
  return {
    c() {
      e = A("div"), O(l.$$.fragment), w(e, "class", "spectrum-Table-cell svelte-qx6w80"), w(e, "style", t = /*cellStyles*/
      n[22][
        /*field*/
        n[67]
      ]), b(e, "spectrum-Table-cell--divider", !!/*schema*/
      n[0][
        /*field*/
        n[67]
      ].divider);
    },
    m(r, u) {
      v(r, e, u), I(l, e, null), o = !0, i || (s = Ne(e, "click", f), i = !0);
    },
    p(r, u) {
      n = r;
      const c = {};
      u[0] & /*customRenderers*/
      512 && (c.customRenderers = /*customRenderers*/
      n[9]), u[0] & /*sortedRows*/
      16777216 && (c.row = /*row*/
      n[64]), u[0] & /*snippets*/
      16384 && (c.snippets = /*snippets*/
      n[14]), u[0] & /*schema, fields*/
      262145 && (c.schema = /*schema*/
      n[0][
        /*field*/
        n[67]
      ]), u[0] & /*sortedRows, fields*/
      17039360 && (c.value = Qe(
        /*row*/
        n[64],
        /*field*/
        n[67]
      )), u[1] & /*$$scope*/
      16777216 && (c.$$scope = { dirty: u, ctx: n }), l.$set(c), (!o || u[0] & /*cellStyles, fields*/
      4456448 && t !== (t = /*cellStyles*/
      n[22][
        /*field*/
        n[67]
      ])) && w(e, "style", t), (!o || u[0] & /*schema, fields*/
      262145) && b(e, "spectrum-Table-cell--divider", !!/*schema*/
      n[0][
        /*field*/
        n[67]
      ].divider);
    },
    i(r) {
      o || (d(l.$$.fragment, r), o = !0);
    },
    o(r) {
      m(l.$$.fragment, r), o = !1;
    },
    d(r) {
      r && C(e), j(l), i = !1, s();
    }
  };
}
function yl(n) {
  let e, l, t, o, i = (
    /*showEditColumn*/
    n[17] && Rl(n)
  ), s = $(
    /*fields*/
    n[18]
  ), f = [];
  for (let u = 0; u < s.length; u += 1)
    f[u] = Sl(ml(n, s, u));
  const r = (u) => m(f[u], 1, 1, () => {
    f[u] = null;
  });
  return {
    c() {
      e = A("div"), i && i.c(), l = V();
      for (let u = 0; u < f.length; u += 1)
        f[u].c();
      t = V(), w(e, "class", "spectrum-Table-row svelte-qx6w80"), b(
        e,
        "clickable",
        /*allowClickRows*/
        n[8]
      );
    },
    m(u, c) {
      v(u, e, c), i && i.m(e, null), y(e, l);
      for (let _ = 0; _ < f.length; _ += 1)
        f[_] && f[_].m(e, null);
      y(e, t), o = !0;
    },
    p(u, c) {
      if (/*showEditColumn*/
      u[17] ? i ? (i.p(u, c), c[0] & /*showEditColumn*/
      131072 && d(i, 1)) : (i = Rl(u), i.c(), d(i, 1), i.m(e, l)) : i && (D(), m(i, 1, 1, () => {
        i = null;
      }), N()), c[0] & /*cellStyles, fields, schema, dispatch, sortedRows, customRenderers, snippets*/
      88359425 | c[1] & /*toggleSelectRow, $$scope*/
      16777217) {
        s = $(
          /*fields*/
          u[18]
        );
        let _;
        for (_ = 0; _ < s.length; _ += 1) {
          const E = ml(u, s, _);
          f[_] ? (f[_].p(E, c), d(f[_], 1)) : (f[_] = Sl(E), f[_].c(), d(f[_], 1), f[_].m(e, t));
        }
        for (D(), _ = s.length; _ < f.length; _ += 1)
          r(_);
        N();
      }
      (!o || c[0] & /*allowClickRows*/
      256) && b(
        e,
        "clickable",
        /*allowClickRows*/
        u[8]
      );
    },
    i(u) {
      if (!o) {
        d(i);
        for (let c = 0; c < s.length; c += 1)
          d(f[c]);
        o = !0;
      }
    },
    o(u) {
      m(i), f = f.filter(Boolean);
      for (let c = 0; c < f.length; c += 1)
        m(f[c]);
      o = !1;
    },
    d(u) {
      u && C(e), i && i.d(), ve(f, u);
    }
  };
}
function nn(n) {
  let e, l;
  return e = new lt({}), {
    c() {
      O(e.$$.fragment);
    },
    m(t, o) {
      I(e, t, o), l = !0;
    },
    i(t) {
      l || (d(e.$$.fragment, t), l = !0);
    },
    o(t) {
      m(e.$$.fragment, t), l = !1;
    },
    d(t) {
      j(e, t);
    }
  };
}
function El(n) {
  let e, l, t, o, i;
  const s = [Qt, Kt], f = [];
  function r(u, c) {
    return (
      /*loading*/
      u[4] ? 0 : 1
    );
  }
  return l = r(n), t = f[l] = s[l](n), {
    c() {
      e = A("div"), t.c(), w(e, "class", "wrapper svelte-qx6w80"), w(e, "style", o = `--row-height: ${/*rowHeight*/
      n[19]}px; --header-height: ${je}px;`), b(
        e,
        "wrapper--quiet",
        /*quiet*/
        n[3]
      ), b(
        e,
        "wrapper--compact",
        /*compact*/
        n[10]
      );
    },
    m(u, c) {
      v(u, e, c), f[l].m(e, null), n[54](e), i = !0;
    },
    p(u, c) {
      let _ = l;
      l = r(u), l === _ ? f[l].p(u, c) : (D(), m(f[_], 1, 1, () => {
        f[_] = null;
      }), N(), t = f[l], t ? t.p(u, c) : (t = f[l] = s[l](u), t.c()), d(t, 1), t.m(e, null)), (!i || c[0] & /*rowHeight*/
      524288 && o !== (o = `--row-height: ${/*rowHeight*/
      u[19]}px; --header-height: ${je}px;`)) && w(e, "style", o), (!i || c[0] & /*quiet*/
      8) && b(
        e,
        "wrapper--quiet",
        /*quiet*/
        u[3]
      ), (!i || c[0] & /*compact*/
      1024) && b(
        e,
        "wrapper--compact",
        /*compact*/
        u[10]
      );
    },
    i(u) {
      i || (d(t), i = !0);
    },
    o(u) {
      m(t), i = !1;
    },
    d(u) {
      u && C(e), f[l].d(), n[54](null);
    }
  };
}
function on(n) {
  var i;
  let e = (
    /*fields*/
    (i = n[18]) == null ? void 0 : i.length
  ), l, t, o = El(n);
  return {
    c() {
      o.c(), l = fe();
    },
    m(s, f) {
      o.m(s, f), v(s, l, f), t = !0;
    },
    p(s, f) {
      var r;
      f[0] & /*fields*/
      262144 && X(e, e = /*fields*/
      (r = s[18]) == null ? void 0 : r.length) ? (D(), m(o, 1, 1, ie), N(), o = El(s), o.c(), d(o, 1), o.m(l.parentNode, l)) : o.p(s, f);
    },
    i(s) {
      t || (d(o), t = !0);
    },
    o(s) {
      m(o), t = !1;
    },
    d(s) {
      s && C(l), o.d(s);
    }
  };
}
const je = 36;
function rn(n, e, l) {
  let t, o, i, s, f, r, u, c, _, E, { $$slots: S = {}, $$scope: T } = e, { data: L = [] } = e, { schema: H = {} } = e, { showAutoColumns: R = !1 } = e, { rowCount: q = 0 } = e, { quiet: k = !1 } = e, { loading: z = !1 } = e, { allowSelectRows: le = !1 } = e, { allowEditRows: ne = !0 } = e, { allowEditColumns: Ce = !0 } = e, { allowClickRows: Re = !0 } = e, { selectedRows: F = [] } = e, { customRenderers: Se = [] } = e, { disableSorting: ue = !1 } = e, { autoSortColumns: ce = !0 } = e, { compact: ye = !1 } = e, { customPlaceholder: Me = !1 } = e, { showHeaderBorder: Ee = !0 } = e, { placeholderText: Le = "No rows found" } = e, { snippets: Oe = [] } = e, { defaultSortColumn: we = void 0 } = e, { defaultSortOrder: Te = "Ascending" } = e;
  const Y = Tl();
  let ke, ae, re, qe = 0, Ae = !1, pe = !1;
  const He = (a) => {
    let g = {};
    return Object.entries(a || {}).forEach(([h, B]) => {
      typeof B == "string" ? g[h] = { type: B, name: h } : g[h] = { ...B, name: h };
      const K = g[h].width;
      K != null && `${K}`.trim().match(/^[0-9]+$/) && delete g[h].width;
    }), g;
  }, p = (a, g, h, B, K) => a ? B ? Math.min(h, B) : Math.min(h, Math.ceil(g / K)) : B || 0, W = (a, g, h, B, K) => K ? `height: ${je + a * B}px;` : !g || !a || h <= g ? "" : `height: ${je + a * B}px;`, oe = (a, g, h) => {
    let B = "grid-template-columns:";
    return h && (B += " auto"), a == null || a.forEach((K) => {
      const P = g[K];
      P.width && typeof P.width == "string" ? B += ` ${P.width}` : B += " minmax(auto, 1fr)";
    }), B += ";", B;
  }, x = (a, g, h) => (g = g ?? we, h = h ?? Te, !g || !h || ue ? a : a.slice().sort((B, K) => {
    const P = B[g], G = K[g];
    return h === "Descending" ? P > G ? -1 : 1 : P > G ? 1 : -1;
  })), ee = (a) => {
    ue || a.sortable !== !1 && (a.name === ae ? l(16, re = re === "Descending" ? "Ascending" : "Descending") : (l(15, ae = a.name), l(16, re = "Descending")), Y("sort", { column: ae, order: re }));
  }, J = (a) => {
    let g = a == null ? void 0 : a.displayName;
    return a && g === void 0 && (g = a.name), g || "";
  }, Pe = (a, g, h) => {
    let B = [], K = [];
    return Object.entries(a || {}).forEach(([P, G]) => {
      !P || !G || (!h || !(G != null && G.autocolumn) ? B.push(G) : g && K.push(G));
    }), B.sort((P, G) => {
      if (P.divider)
        return P;
      if (G.divider)
        return G;
      const Ye = P.order || Number.MAX_SAFE_INTEGER, Ge = G.order || Number.MAX_SAFE_INTEGER, Wl = J(P), Kl = J(G);
      return Ye !== Ge ? Ye < Ge ? P : G : Wl < Kl ? P : G;
    }).concat(K).map((P) => P.name);
  }, se = (a, g) => {
    a.stopPropagation(), Y("editcolumn", g);
  }, te = (a, g) => {
    a.stopPropagation(), Y("editrow", et(g));
  }, _e = (a) => {
    le && (F.some((g) => g._id === a._id) ? l(1, F = F.filter((g) => g._id !== a._id)) : l(1, F = [...F, a]));
  }, Be = (a) => {
    !!a.detail ? i.forEach((h) => {
      h.__selectable !== !1 && F.findIndex((B) => B._id === h._id) === -1 && F.push(h);
    }) : l(1, F = F.filter((h) => i.every((B) => B._id !== h._id)));
  }, Ml = (a) => {
    let g = {};
    return Object.keys(a || {}).forEach((h) => {
      g[h] = "", a[h].color && (g[h] += `color: ${a[h].color};`), a[h].background && (g[h] += `background-color: ${a[h].background};`), a[h].align === "Center" && (g[h] += "justify-content: center; text-align: center;"), a[h].align === "Right" && (g[h] += "justify-content: flex-end; text-align: right;"), a[h].borderLeft && (g[h] += "border-left: 1px solid var(--spectrum-global-color-gray-200);"), a[h].borderLeft && (g[h] += "border-right: 1px solid var(--spectrum-global-color-gray-200);"), a[h].minWidth && (g[h] += `min-width: ${a[h].minWidth};`);
    }), g;
  }, Ol = (a) => {
    const g = new ResizeObserver((h) => {
      if (!(h != null && h[0]))
        return;
      const B = h[0].target.getBoundingClientRect();
      l(39, qe = B.height);
    });
    return g.observe(a), g;
  };
  xl(() => {
    let a = Ol(ke);
    return () => {
      a.disconnect();
    };
  });
  function Il(a) {
    pe = a, l(21, pe), l(41, i), l(1, F), l(18, o), l(33, L), l(0, H), l(34, R), l(36, ce);
  }
  const jl = (a, g) => se(g, a), Hl = (a) => ee(H[a]), Fl = (a, g) => g._id === a._id, Pl = (a, g) => te(g, a), Yl = (a, g) => {
    a.__selectable !== !1 && (_e(a), g.stopPropagation());
  };
  function Gl(a) {
    De.call(this, n, a);
  }
  function Vl(a) {
    De.call(this, n, a);
  }
  const Jl = (a, g) => {
    var h;
    (h = H[a]) != null && h.preventSelectRow || (Y("click", g), _e(g));
  };
  function Xl(a) {
    Fe[a ? "unshift" : "push"](() => {
      ke = a, l(20, ke);
    });
  }
  return n.$$set = (a) => {
    "data" in a && l(33, L = a.data), "schema" in a && l(0, H = a.schema), "showAutoColumns" in a && l(34, R = a.showAutoColumns), "rowCount" in a && l(2, q = a.rowCount), "quiet" in a && l(3, k = a.quiet), "loading" in a && l(4, z = a.loading), "allowSelectRows" in a && l(5, le = a.allowSelectRows), "allowEditRows" in a && l(6, ne = a.allowEditRows), "allowEditColumns" in a && l(7, Ce = a.allowEditColumns), "allowClickRows" in a && l(8, Re = a.allowClickRows), "selectedRows" in a && l(1, F = a.selectedRows), "customRenderers" in a && l(9, Se = a.customRenderers), "disableSorting" in a && l(35, ue = a.disableSorting), "autoSortColumns" in a && l(36, ce = a.autoSortColumns), "compact" in a && l(10, ye = a.compact), "customPlaceholder" in a && l(11, Me = a.customPlaceholder), "showHeaderBorder" in a && l(12, Ee = a.showHeaderBorder), "placeholderText" in a && l(13, Le = a.placeholderText), "snippets" in a && l(14, Oe = a.snippets), "defaultSortColumn" in a && l(37, we = a.defaultSortColumn), "defaultSortOrder" in a && l(38, Te = a.defaultSortOrder), "$$scope" in a && l(55, T = a.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*compact*/
    1024 && l(19, t = ye ? 46 : 55), n.$$.dirty[0] & /*schema*/
    1 && l(0, H = He(H)), n.$$.dirty[0] & /*loading*/
    16 && (z || l(40, Ae = !0)), n.$$.dirty[0] & /*schema*/
    1 | n.$$.dirty[1] & /*showAutoColumns, autoSortColumns*/
    40 && l(18, o = Pe(H, R, ce)), n.$$.dirty[0] & /*fields*/
    262144 | n.$$.dirty[1] & /*data*/
    4 && l(41, i = o != null && o.length ? L || [] : []), n.$$.dirty[1] & /*rows*/
    1024 && l(42, s = (i == null ? void 0 : i.length) || 0), n.$$.dirty[0] & /*rowCount, rowHeight*/
    524292 | n.$$.dirty[1] & /*loaded, height, rows*/
    1792 && l(43, f = p(Ae, qe, i.length, q, t)), n.$$.dirty[0] & /*rowCount, rowHeight, loading*/
    524308 | n.$$.dirty[1] & /*visibleRowCount, totalRowCount*/
    6144 && l(25, r = W(f, q, s, t, z)), n.$$.dirty[0] & /*sortColumn, sortOrder*/
    98304 | n.$$.dirty[1] & /*rows*/
    1024 && l(24, u = x(i, ae, re)), n.$$.dirty[0] & /*allowEditRows, allowSelectRows*/
    96 && l(17, _ = ne || le), n.$$.dirty[0] & /*fields, schema, showEditColumn*/
    393217 && l(23, c = oe(o, H, _)), n.$$.dirty[0] & /*schema*/
    1 && l(22, E = Ml(H)), n.$$.dirty[0] & /*selectedRows*/
    2 | n.$$.dirty[1] & /*rows*/
    1024 && i.filter((g) => F.some((h) => g._id === h._id)).length === 0 && l(21, pe = !1);
  }, [
    H,
    F,
    q,
    k,
    z,
    le,
    ne,
    Ce,
    Re,
    Se,
    ye,
    Me,
    Ee,
    Le,
    Oe,
    ae,
    re,
    _,
    o,
    t,
    ke,
    pe,
    E,
    c,
    u,
    r,
    Y,
    ee,
    J,
    se,
    te,
    _e,
    Be,
    L,
    R,
    ue,
    ce,
    we,
    Te,
    qe,
    Ae,
    i,
    s,
    f,
    S,
    Il,
    jl,
    Hl,
    Fl,
    Pl,
    Yl,
    Gl,
    Vl,
    Jl,
    Xl,
    T
  ];
}
class sn extends Q {
  constructor(e) {
    super(), U(
      this,
      e,
      rn,
      on,
      X,
      {
        data: 33,
        schema: 0,
        showAutoColumns: 34,
        rowCount: 2,
        quiet: 3,
        loading: 4,
        allowSelectRows: 5,
        allowEditRows: 6,
        allowEditColumns: 7,
        allowClickRows: 8,
        selectedRows: 1,
        customRenderers: 9,
        disableSorting: 35,
        autoSortColumns: 36,
        compact: 10,
        customPlaceholder: 11,
        showHeaderBorder: 12,
        placeholderText: 13,
        snippets: 14,
        defaultSortColumn: 37,
        defaultSortOrder: 38
      },
      null,
      [-1, -1, -1]
    );
  }
}
function fn(n) {
  let e;
  const l = (
    /*#slots*/
    n[3].default
  ), t = me(
    l,
    n,
    /*$$scope*/
    n[4],
    null
  );
  return {
    c() {
      t && t.c();
    },
    m(o, i) {
      t && t.m(o, i), e = !0;
    },
    p(o, i) {
      t && t.p && (!e || i & /*$$scope*/
      16) && ge(
        t,
        l,
        o,
        /*$$scope*/
        o[4],
        e ? be(
          l,
          /*$$scope*/
          o[4],
          i,
          null
        ) : he(
          /*$$scope*/
          o[4]
        ),
        null
      );
    },
    i(o) {
      e || (d(t, o), e = !0);
    },
    o(o) {
      m(t, o), e = !1;
    },
    d(o) {
      t && t.d(o);
    }
  };
}
function un(n) {
  let e, l;
  return e = new /*Provider*/
  n[1]({
    props: {
      data: (
        /*row*/
        n[0]
      ),
      scope: (
        /*ContextScopes*/
        n[2].Local
      ),
      $$slots: { default: [fn] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      O(e.$$.fragment);
    },
    m(t, o) {
      I(e, t, o), l = !0;
    },
    p(t, [o]) {
      const i = {};
      o & /*row*/
      1 && (i.data = /*row*/
      t[0]), o & /*$$scope*/
      16 && (i.$$scope = { dirty: o, ctx: t }), e.$set(i);
    },
    i(t) {
      l || (d(e.$$.fragment, t), l = !0);
    },
    o(t) {
      m(e.$$.fragment, t), l = !1;
    },
    d(t) {
      j(e, t);
    }
  };
}
function cn(n, e, l) {
  let { $$slots: t = {}, $$scope: o } = e, { row: i } = e;
  const { Provider: s, ContextScopes: f } = Ie("sdk");
  return n.$$set = (r) => {
    "row" in r && l(0, i = r.row), "$$scope" in r && l(4, o = r.$$scope);
  }, [i, s, f, t, o];
}
class an extends Q {
  constructor(e) {
    super(), U(this, e, cn, un, X, { row: 0 });
  }
}
function _n(n) {
  let e;
  const l = (
    /*#slots*/
    n[30].default
  ), t = me(
    l,
    n,
    /*$$scope*/
    n[32],
    null
  );
  return {
    c() {
      t && t.c();
    },
    m(o, i) {
      t && t.m(o, i), e = !0;
    },
    p(o, i) {
      t && t.p && (!e || i[1] & /*$$scope*/
      2) && ge(
        t,
        l,
        o,
        /*$$scope*/
        o[32],
        e ? be(
          l,
          /*$$scope*/
          o[32],
          i,
          null
        ) : he(
          /*$$scope*/
          o[32]
        ),
        null
      );
    },
    i(o) {
      e || (d(t, o), e = !0);
    },
    o(o) {
      m(t, o), e = !1;
    },
    d(o) {
      t && t.d(o);
    }
  };
}
function dn(n) {
  var s;
  let e, l, t;
  function o(f) {
    n[31](f);
  }
  let i = {
    data: (
      /*data*/
      n[8]
    ),
    schema: (
      /*schema*/
      n[12]
    ),
    loading: (
      /*loading*/
      n[13]
    ),
    rowCount: (
      /*rowCount*/
      n[1]
    ),
    quiet: (
      /*quiet*/
      n[2]
    ),
    compact: (
      /*compact*/
      n[5]
    ),
    customRenderers: (
      /*customRenderers*/
      n[18]
    ),
    snippets: (
      /*snippets*/
      n[14]
    ),
    allowSelectRows: (
      /*allowSelectRows*/
      n[4] && /*table*/
      n[11]
    ),
    allowEditRows: !1,
    allowEditColumns: !1,
    showAutoColumns: !0,
    disableSorting: !0,
    autoSortColumns: !/*columns*/
    ((s = n[0]) != null && s.length),
    placeholderText: (
      /*noRowsMessage*/
      n[6] || "No rows found"
    ),
    $$slots: { default: [_n] },
    $$scope: { ctx: n }
  };
  return (
    /*selectedRows*/
    n[7] !== void 0 && (i.selectedRows = /*selectedRows*/
    n[7]), e = new sn({ props: i }), Fe.push(() => zl(e, "selectedRows", o)), e.$on(
      "sort",
      /*onSort*/
      n[19]
    ), e.$on(
      "click",
      /*handleClick*/
      n[20]
    ), {
      c() {
        O(e.$$.fragment);
      },
      m(f, r) {
        I(e, f, r), t = !0;
      },
      p(f, r) {
        var c;
        const u = {};
        r[0] & /*data*/
        256 && (u.data = /*data*/
        f[8]), r[0] & /*schema*/
        4096 && (u.schema = /*schema*/
        f[12]), r[0] & /*loading*/
        8192 && (u.loading = /*loading*/
        f[13]), r[0] & /*rowCount*/
        2 && (u.rowCount = /*rowCount*/
        f[1]), r[0] & /*quiet*/
        4 && (u.quiet = /*quiet*/
        f[2]), r[0] & /*compact*/
        32 && (u.compact = /*compact*/
        f[5]), r[0] & /*snippets*/
        16384 && (u.snippets = /*snippets*/
        f[14]), r[0] & /*allowSelectRows, table*/
        2064 && (u.allowSelectRows = /*allowSelectRows*/
        f[4] && /*table*/
        f[11]), r[0] & /*columns*/
        1 && (u.autoSortColumns = !/*columns*/
        ((c = f[0]) != null && c.length)), r[0] & /*noRowsMessage*/
        64 && (u.placeholderText = /*noRowsMessage*/
        f[6] || "No rows found"), r[1] & /*$$scope*/
        2 && (u.$$scope = { dirty: r, ctx: f }), !l && r[0] & /*selectedRows*/
        128 && (l = !0, u.selectedRows = /*selectedRows*/
        f[7], Dl(() => l = !1)), e.$set(u);
      },
      i(f) {
        t || (d(e.$$.fragment, f), t = !0);
      },
      o(f) {
        m(e.$$.fragment, f), t = !1;
      },
      d(f) {
        j(e, f);
      }
    }
  );
}
function Ll(n) {
  let e, l = (
    /*selectedRows*/
    n[7].length + ""
  ), t, o, i = (
    /*selectedRows*/
    n[7].length === 1 ? "" : "s"
  ), s, f;
  return {
    c() {
      e = A("div"), t = M(l), o = M(" row"), s = M(i), f = M(" selected"), w(e, "class", "row-count svelte-9e4ofs");
    },
    m(r, u) {
      v(r, e, u), y(e, t), y(e, o), y(e, s), y(e, f);
    },
    p(r, u) {
      u[0] & /*selectedRows*/
      128 && l !== (l = /*selectedRows*/
      r[7].length + "") && Z(t, l), u[0] & /*selectedRows*/
      128 && i !== (i = /*selectedRows*/
      r[7].length === 1 ? "" : "s") && Z(s, i);
    },
    d(r) {
      r && C(e);
    }
  };
}
function mn(n) {
  let e, l, t, o, i, s, f, r;
  l = new tt({
    props: {
      actions: (
        /*actions*/
        n[21]
      ),
      data: (
        /*dataContext*/
        n[10]
      ),
      $$slots: { default: [dn] },
      $$scope: { ctx: n }
    }
  });
  let u = (
    /*allowSelectRows*/
    n[4] && /*selectedRows*/
    n[7].length && Ll(n)
  );
  return {
    c() {
      e = A("div"), O(l.$$.fragment), t = V(), u && u.c(), w(e, "class", o = Ue(
        /*size*/
        n[3]
      ) + " svelte-9e4ofs");
    },
    m(c, _) {
      v(c, e, _), I(l, e, null), y(e, t), u && u.m(e, null), s = !0, f || (r = nt(i = /*styleable*/
      n[17].call(
        null,
        e,
        /*$component*/
        n[9].styles
      )), f = !0);
    },
    p(c, _) {
      const E = {};
      _[0] & /*dataContext*/
      1024 && (E.data = /*dataContext*/
      c[10]), _[0] & /*data, schema, loading, rowCount, quiet, compact, snippets, allowSelectRows, table, columns, noRowsMessage, selectedRows*/
      31223 | _[1] & /*$$scope*/
      2 && (E.$$scope = { dirty: _, ctx: c }), l.$set(E), /*allowSelectRows*/
      c[4] && /*selectedRows*/
      c[7].length ? u ? u.p(c, _) : (u = Ll(c), u.c(), u.m(e, null)) : u && (u.d(1), u = null), (!s || _[0] & /*size*/
      8 && o !== (o = Ue(
        /*size*/
        c[3]
      ) + " svelte-9e4ofs")) && w(e, "class", o), i && Bl(i.update) && _[0] & /*$component*/
      512 && i.update.call(
        null,
        /*$component*/
        c[9].styles
      );
    },
    i(c) {
      s || (d(l.$$.fragment, c), s = !0);
    },
    o(c) {
      m(l.$$.fragment, c), s = !1;
    },
    d(c) {
      c && C(e), j(l), u && u.d(), f = !1, r();
    }
  };
}
function gn(n, e, l) {
  let t, o, i, s, f, r, u, c, _, E, S, T, L, { $$slots: H = {}, $$scope: R } = e, { dataProvider: q } = e, { columns: k } = e, { rowCount: z } = e, { quiet: le } = e, { size: ne } = e, { allowSelectRows: Ce } = e, { compact: Re } = e, { onClick: F } = e, { noRowsMessage: Se } = e;
  const ue = Ie("component");
  Ze(n, ue, (p) => l(9, T = p));
  const ce = Ie("context");
  Ze(n, ce, (p) => l(29, L = p));
  const { styleable: ye, getAction: Me, ActionTypes: Ee, rowSelectionStore: Le, generateGoldenSample: Oe } = Ie("sdk"), we = `custom-${Math.random()}`, Te = [
    {
      column: we,
      component: an
    }
  ];
  let Y = [];
  const ke = () => ({ eventContext: { row: Oe(s) } }), ae = (p, W, oe, x) => {
    if (W != null && W.length)
      return W;
    let ee = [], J = [];
    return Object.entries(p).forEach(([se, te]) => {
      te.visible !== !1 && (te != null && te.autocolumn ? oe && J.push(se) : ee.push(se));
    }), ee.concat(J).sort((se, te) => {
      if (se === x)
        return -1;
      if (te === x)
        return 1;
      const _e = p[se].order, Be = p[te].order;
      return _e === Be ? 0 : _e == null ? 1 : Be == null || _e < Be ? -1 : 1;
    });
  }, re = (p, W, oe) => {
    let x = {};
    return oe && (x[we] = {
      displayName: null,
      order: 0,
      sortable: !1,
      divider: !0,
      width: "auto",
      preventSelectRow: !0
    }), W.forEach((ee) => {
      const J = typeof ee == "string" ? ee : ee.name;
      p[J] && (x[J] = p[J], it(p[J]) || (x[J].sortable = !1), typeof ee == "object" && (x[J] = { ...x[J], ...ee }));
    }), x;
  }, qe = (p) => {
    _({
      column: p.detail.column,
      order: p.detail.order
    });
  }, Ae = (p) => {
    F && F({ row: p.detail });
  }, pe = [
    {
      type: Ee.ClearRowSelection,
      callback: () => l(7, Y = [])
    }
  ];
  ot(() => {
    Le.actions.updateSelection(T.id, []);
  });
  function He(p) {
    Y = p, l(7, Y), l(8, s), l(22, q);
  }
  return n.$$set = (p) => {
    "dataProvider" in p && l(22, q = p.dataProvider), "columns" in p && l(0, k = p.columns), "rowCount" in p && l(1, z = p.rowCount), "quiet" in p && l(2, le = p.quiet), "size" in p && l(3, ne = p.size), "allowSelectRows" in p && l(4, Ce = p.allowSelectRows), "compact" in p && l(5, Re = p.compact), "onClick" in p && l(23, F = p.onClick), "noRowsMessage" in p && l(6, Se = p.noRowsMessage), "$$scope" in p && l(32, R = p.$$scope);
  }, n.$$.update = () => {
    var p;
    if (n.$$.dirty[0] & /*$context*/
    536870912 && l(14, t = L.snippets), n.$$.dirty[0] & /*$component*/
    512 && l(25, o = T.children), n.$$.dirty[0] & /*dataProvider*/
    4194304 && l(13, i = (q == null ? void 0 : q.loading) ?? !1), n.$$.dirty[0] & /*dataProvider*/
    4194304 && l(8, s = (q == null ? void 0 : q.rows) || []), n.$$.dirty[0] & /*dataProvider*/
    4194304 && l(27, f = (q == null ? void 0 : q.schema) ?? {}), n.$$.dirty[0] & /*dataProvider*/
    4194304 && l(28, r = q == null ? void 0 : q.primaryDisplay), n.$$.dirty[0] & /*fullSchema, columns, primaryDisplay*/
    402653185 && l(26, u = ae(f, k, !1, r)), n.$$.dirty[0] & /*fullSchema, fields, hasChildren*/
    234881024 && l(12, c = re(f, u, o)), n.$$.dirty[0] & /*dataProvider*/
    4194304 && (_ = Me(q == null ? void 0 : q.id, Ee.SetDataProviderSorting)), n.$$.dirty[0] & /*dataProvider*/
    4194304 && l(11, E = ((p = q == null ? void 0 : q.datasource) == null ? void 0 : p.type) === "table"), n.$$.dirty[0] & /*data, selectedRows*/
    384 && s) {
      let W = s.map((oe) => oe._id);
      W.length && l(7, Y = Y.filter((oe) => W.includes(oe._id)));
    }
    n.$$.dirty[0] & /*$component, selectedRows*/
    640 && Le.actions.updateSelection(T.id, Y.length ? Y[0].tableId : "", Y.map((W) => W._id)), n.$$.dirty[0] & /*selectedRows*/
    128 && l(10, S = { selectedRows: Y });
  }, [
    k,
    z,
    le,
    ne,
    Ce,
    Re,
    Se,
    Y,
    s,
    T,
    S,
    E,
    c,
    i,
    t,
    ue,
    ce,
    ye,
    Te,
    qe,
    Ae,
    pe,
    q,
    F,
    ke,
    o,
    u,
    f,
    r,
    L,
    H,
    He,
    R
  ];
}
class wn extends Q {
  constructor(e) {
    super(), U(
      this,
      e,
      gn,
      mn,
      X,
      {
        dataProvider: 22,
        columns: 0,
        rowCount: 1,
        quiet: 2,
        size: 3,
        allowSelectRows: 4,
        compact: 5,
        onClick: 23,
        noRowsMessage: 6,
        getAdditionalDataContext: 24
      },
      null,
      [-1, -1]
    );
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[24];
  }
}
export {
  wn as default
};
