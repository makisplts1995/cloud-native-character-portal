import { S as X, i as Y, s as Z, e as L, a as ye, b as m, c5 as D, d as k, f as y, g as Oe, q as we, l as Ce, h as W, k as w, z as Re, n as q, A as ve, o as C, r as ze, u as j, v as G, bd as Se, aa as Fe, c6 as U, N as V, O as ae, B as Ae, F as x, G as $, H as ee, J as te, al as He, ac as je, aJ as ce, br as re, c as ue, y as Be, m as fe, p as de, c7 as _e, c8 as me, bL as K, bM as he } from "./index-e79f0bb2.js";
function Ie(t, e, l) {
  const i = t.slice();
  return i[31] = e[l], i;
}
function ge(t, e, l) {
  const i = t.slice();
  return i[31] = e[l], i;
}
function be(t) {
  let e, l, i, s = V({ length: (
    /*rows*/
    t[2]
  ) }), a = [];
  for (let n = 0; n < s.length; n += 1)
    a[n] = pe(ge(t, s, n));
  let f = V({ length: D }), o = [];
  for (let n = 0; n < f.length; n += 1)
    o[n] = Je(Ie(t, f, n));
  return {
    c() {
      e = L("div");
      for (let n = 0; n < a.length; n += 1)
        a[n].c();
      l = ye(), i = L("div");
      for (let n = 0; n < o.length; n += 1)
        o[n].c();
      m(e, "class", "underlay-h svelte-ch5mko"), m(i, "class", "underlay-v svelte-ch5mko");
    },
    m(n, r) {
      y(n, e, r);
      for (let c = 0; c < a.length; c += 1)
        a[c] && a[c].m(e, null);
      y(n, l, r), y(n, i, r);
      for (let c = 0; c < o.length; c += 1)
        o[c] && o[c].m(i, null);
    },
    p(n, r) {
      if (r[0] & /*rows*/
      4) {
        s = V({ length: (
          /*rows*/
          n[2]
        ) });
        let c;
        for (c = 0; c < s.length; c += 1) {
          const h = ge(n, s, c);
          a[c] ? a[c].p(h, r) : (a[c] = pe(), a[c].c(), a[c].m(e, null));
        }
        for (; c < a.length; c += 1)
          a[c].d(1);
        a.length = s.length;
      }
    },
    d(n) {
      n && (C(e), C(l), C(i)), ae(a, n), ae(o, n);
    }
  };
}
function pe(t) {
  let e;
  return {
    c() {
      e = L("div"), m(e, "class", "placeholder-h svelte-ch5mko");
    },
    m(l, i) {
      y(l, e, i);
    },
    p: Ae,
    d(l) {
      l && C(e);
    }
  };
}
function Je(t) {
  let e;
  return {
    c() {
      e = L("div"), m(e, "class", "placeholder-v svelte-ch5mko");
    },
    m(l, i) {
      y(l, e, i);
    },
    p: Ae,
    d(l) {
      l && C(e);
    }
  };
}
function ke(t) {
  let e;
  const l = (
    /*#slots*/
    t[25].default
  ), i = x(
    l,
    t,
    /*$$scope*/
    t[24],
    null
  );
  return {
    c() {
      i && i.c();
    },
    m(s, a) {
      i && i.m(s, a), e = !0;
    },
    p(s, a) {
      i && i.p && (!e || a[0] & /*$$scope*/
      16777216) && $(
        i,
        l,
        s,
        /*$$scope*/
        s[24],
        e ? te(
          l,
          /*$$scope*/
          s[24],
          a,
          null
        ) : ee(
          /*$$scope*/
          s[24]
        ),
        null
      );
    },
    i(s) {
      e || (w(i, s), e = !0);
    },
    o(s) {
      q(i, s), e = !1;
    },
    d(s) {
      i && i.d(s);
    }
  };
}
function De(t) {
  let e, l, i, s, a, f, o = (
    /*inBuilder*/
    t[5] && be(t)
  ), n = (
    /*mounted*/
    t[7] && ke(t)
  );
  return {
    c() {
      e = L("div"), o && o.c(), l = ye(), n && n.c(), m(e, "class", "grid svelte-ch5mko"), m(e, "data-cols", D), m(
        e,
        "data-col-size",
        /*colSize*/
        t[1]
      ), m(
        e,
        "data-required-rows",
        /*requiredRows*/
        t[4]
      ), k(
        e,
        "mobile",
        /*mobile*/
        t[3]
      ), k(e, "clickable", !!/*onClick*/
      t[0]);
    },
    m(r, c) {
      y(r, e, c), o && o.m(e, null), Oe(e, l), n && n.m(e, null), t[26](e), s = !0, a || (f = [
        we(i = /*styleable*/
        t[10].call(
          null,
          e,
          /*$styles*/
          t[8]
        )),
        Ce(e, "click", function() {
          W(
            /*onClick*/
            t[0]
          ) && t[0].apply(this, arguments);
        })
      ], a = !0);
    },
    p(r, c) {
      t = r, /*inBuilder*/
      t[5] ? o ? o.p(t, c) : (o = be(t), o.c(), o.m(e, l)) : o && (o.d(1), o = null), /*mounted*/
      t[7] ? n ? (n.p(t, c), c[0] & /*mounted*/
      128 && w(n, 1)) : (n = ke(t), n.c(), w(n, 1), n.m(e, null)) : n && (Re(), q(n, 1, 1, () => {
        n = null;
      }), ve()), (!s || c[0] & /*colSize*/
      2) && m(
        e,
        "data-col-size",
        /*colSize*/
        t[1]
      ), (!s || c[0] & /*requiredRows*/
      16) && m(
        e,
        "data-required-rows",
        /*requiredRows*/
        t[4]
      ), i && W(i.update) && c[0] & /*$styles*/
      256 && i.update.call(
        null,
        /*$styles*/
        t[8]
      ), (!s || c[0] & /*mobile*/
      8) && k(
        e,
        "mobile",
        /*mobile*/
        t[3]
      ), (!s || c[0] & /*onClick*/
      1) && k(e, "clickable", !!/*onClick*/
      t[0]);
    },
    i(r) {
      s || (w(n), s = !0);
    },
    o(r) {
      q(n), s = !1;
    },
    d(r) {
      r && C(e), o && o.d(), n && n.d(), t[26](null), a = !1, ze(f);
    }
  };
}
function We(t, e, l) {
  let i, s, a, f, o, n, r, c, h, O, E, b, R, { $$slots: M = {}, $$scope: v } = e, { onClick: z } = e;
  const S = j("component");
  G(t, S, (u) => l(20, h = u));
  const { styleable: B, builderStore: d } = j("sdk");
  G(t, d, (u) => l(23, b = u));
  const le = j("context");
  G(t, le, (u) => l(21, O = u));
  let P, Q, A, I = He({});
  G(t, I, (u) => l(22, E = u));
  let ne = !1, T = Se({});
  G(t, T, (u) => l(8, R = u));
  const qe = (u, _, g) => {
    const p = _ ? "mobileRowEnd" : "desktopRowEnd";
    let N = 2;
    for (let H of Object.keys(u))
      u[H][p] > N && (N = u[H][p]);
    let F = N - 1;
    return g ? Math.ceil((F + 10) / 10) * 10 : F;
  }, se = (u) => {
    I.update((_) => ({
      ..._,
      [u.dataset.id]: {
        desktopRowEnd: parseInt(u.dataset.gridDesktopRowEnd),
        mobileRowEnd: parseInt(u.dataset.gridMobileRowEnd)
      }
    }));
  }, Ee = (u) => {
    I.update((_) => (delete _[u.dataset.id], { ..._ }));
  }, Me = (u) => {
    const _ = new ResizeObserver((g) => {
      if (!(g != null && g[0]))
        return;
      const p = g[0].target;
      l(15, P = p.clientWidth), l(16, Q = p.clientHeight);
    });
    return _.observe(u), _;
  };
  Fe(() => {
    let u, _;
    return _ = Me(A), u = new MutationObserver((g) => {
      var p, N, F, H;
      for (let Ge of g) {
        const { target: J, type: Le, addedNodes: ie, removedNodes: oe } = Ge;
        J === A ? (N = (p = ie[0]) == null ? void 0 : p.classList) != null && N.contains("component") ? se(ie[0]) : (H = (F = oe[0]) == null ? void 0 : F.classList) != null && H.contains("component") && Ee(oe[0]) : Le === "attributes" && J.parentNode === A && J.classList.contains("component") && se(J);
      }
    }), u.observe(A, {
      childList: !0,
      attributes: !0,
      subtree: !0,
      attributeFilter: ["data-grid-desktop-row-end", "data-grid-mobile-row-end"]
    }), l(7, ne = !0), () => {
      u == null || u.disconnect(), _ == null || _.disconnect();
    };
  });
  function Ne(u) {
    je[u ? "unshift" : "push"](() => {
      A = u, l(6, A);
    });
  }
  return t.$$set = (u) => {
    "onClick" in u && l(0, z = u.onClick), "$$scope" in u && l(24, v = u.$$scope);
  }, t.$$.update = () => {
    var u, _, g;
    t.$$.dirty[0] & /*$builderStore*/
    8388608 && l(5, i = b.inBuilder), t.$$.dirty[0] & /*$component, inBuilder*/
    1048608 && l(19, s = h.isRoot && i), t.$$.dirty[0] & /*$context*/
    2097152 && l(3, r = O.device.mobile), t.$$.dirty[0] & /*$children, mobile, addEmptyRows*/
    4718600 && l(4, a = qe(E, r, s)), t.$$.dirty[0] & /*requiredRows*/
    16 && l(17, f = a * U), t.$$.dirty[0] & /*height*/
    65536 && l(18, o = Math.floor(Q / U)), t.$$.dirty[0] & /*requiredRows, availableRows*/
    262160 && l(2, n = Math.max(a, o)), t.$$.dirty[0] & /*width*/
    32768 && l(1, c = P / D), t.$$.dirty[0] & /*$component, requiredHeight, rows, colSize*/
    1179654 && T.set({
      ...h.styles,
      normal: {
        ...(u = h.styles) == null ? void 0 : u.normal,
        "--height": `${f}px`,
        "--min-height": ((g = (_ = h.styles) == null ? void 0 : _.normal) == null ? void 0 : g.height) || 0,
        "--cols": D,
        "--rows": n,
        "--col-size": c,
        "--row-size": U
      }
    });
  }, [
    z,
    c,
    n,
    r,
    a,
    i,
    A,
    ne,
    R,
    S,
    B,
    d,
    le,
    I,
    T,
    P,
    Q,
    f,
    o,
    s,
    h,
    O,
    E,
    b,
    v,
    M,
    Ne
  ];
}
class Ke extends X {
  constructor(e) {
    super(), Y(this, e, We, De, Z, { onClick: 0 }, null, [-1, -1]);
  }
}
function Pe(t) {
  let e, l, i, s, a, f;
  const o = (
    /*#slots*/
    t[17].default
  ), n = x(
    o,
    t,
    /*$$scope*/
    t[16],
    null
  );
  return {
    c() {
      e = L("div"), n && n.c(), m(e, "class", l = ce(
        /*classNames*/
        t[2]
      ) + " svelte-h3y7aq"), k(e, "clickable", !!/*onClick*/
      t[1]), k(
        e,
        "wrap",
        /*wrap*/
        t[0]
      );
    },
    m(r, c) {
      y(r, e, c), n && n.m(e, null), s = !0, a || (f = [
        we(i = /*styleable*/
        t[4].call(
          null,
          e,
          /*$component*/
          t[3].styles
        )),
        Ce(e, "click", function() {
          W(
            /*onClick*/
            t[1]
          ) && t[1].apply(this, arguments);
        })
      ], a = !0);
    },
    p(r, [c]) {
      t = r, n && n.p && (!s || c & /*$$scope*/
      65536) && $(
        n,
        o,
        t,
        /*$$scope*/
        t[16],
        s ? te(
          o,
          /*$$scope*/
          t[16],
          c,
          null
        ) : ee(
          /*$$scope*/
          t[16]
        ),
        null
      ), (!s || c & /*classNames*/
      4 && l !== (l = ce(
        /*classNames*/
        t[2]
      ) + " svelte-h3y7aq")) && m(e, "class", l), i && W(i.update) && c & /*$component*/
      8 && i.update.call(
        null,
        /*$component*/
        t[3].styles
      ), (!s || c & /*classNames, onClick*/
      6) && k(e, "clickable", !!/*onClick*/
      t[1]), (!s || c & /*classNames, wrap*/
      5) && k(
        e,
        "wrap",
        /*wrap*/
        t[0]
      );
    },
    i(r) {
      s || (w(n, r), s = !0);
    },
    o(r) {
      q(n, r), s = !1;
    },
    d(r) {
      r && C(e), n && n.d(r), a = !1, ze(f);
    }
  };
}
function Qe(t, e, l) {
  let i, s, a, f, o, n, r, { $$slots: c = {}, $$scope: h } = e;
  const { styleable: O } = j("sdk"), E = j("component");
  G(t, E, (d) => l(3, r = d));
  let { direction: b } = e, { hAlign: R } = e, { vAlign: M } = e, { size: v } = e, { gap: z } = e, { wrap: S } = e, { onClick: B } = e;
  return t.$$set = (d) => {
    "direction" in d && l(6, b = d.direction), "hAlign" in d && l(7, R = d.hAlign), "vAlign" in d && l(8, M = d.vAlign), "size" in d && l(9, v = d.size), "gap" in d && l(10, z = d.gap), "wrap" in d && l(0, S = d.wrap), "onClick" in d && l(1, B = d.onClick), "$$scope" in d && l(16, h = d.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty & /*direction*/
    64 && l(15, i = b ? `flex-container direction-${b}` : ""), t.$$.dirty & /*hAlign*/
    128 && l(14, s = R ? `hAlign-${R}` : ""), t.$$.dirty & /*vAlign*/
    256 && l(13, a = M ? `vAlign-${M}` : ""), t.$$.dirty & /*size*/
    512 && l(12, f = v ? `size-${v}` : ""), t.$$.dirty & /*gap*/
    1024 && l(11, o = z ? `gap-${z}` : ""), t.$$.dirty & /*directionClass, hAlignClass, vAlignClass, sizeClass, gapClass*/
    63488 && l(2, n = [i, s, a, f, o].join(" "));
  }, [
    S,
    B,
    n,
    r,
    O,
    E,
    b,
    R,
    M,
    v,
    z,
    o,
    f,
    a,
    s,
    i,
    h,
    c
  ];
}
class Te extends X {
  constructor(e) {
    super(), Y(this, e, Qe, Pe, Z, {
      direction: 6,
      hAlign: 7,
      vAlign: 8,
      size: 9,
      gap: 10,
      wrap: 0,
      onClick: 1
    });
  }
}
function Ue(t) {
  let e;
  const l = (
    /*#slots*/
    t[3].default
  ), i = x(
    l,
    t,
    /*$$scope*/
    t[4],
    null
  );
  return {
    c() {
      i && i.c();
    },
    m(s, a) {
      i && i.m(s, a), e = !0;
    },
    p(s, a) {
      i && i.p && (!e || a & /*$$scope*/
      16) && $(
        i,
        l,
        s,
        /*$$scope*/
        s[4],
        e ? te(
          l,
          /*$$scope*/
          s[4],
          a,
          null
        ) : ee(
          /*$$scope*/
          s[4]
        ),
        null
      );
    },
    i(s) {
      e || (w(i, s), e = !0);
    },
    o(s) {
      q(i, s), e = !1;
    },
    d(s) {
      i && i.d(s);
    }
  };
}
function Ve(t) {
  let e, l, i;
  const s = [
    /*$$props*/
    t[1]
  ];
  var a = (
    /*component*/
    t[0]
  );
  function f(o, n) {
    let r = {
      $$slots: { default: [Ue] },
      $$scope: { ctx: o }
    };
    for (let c = 0; c < s.length; c += 1)
      r = K(r, s[c]);
    return n !== void 0 && n & /*$$props*/
    2 && (r = K(r, _e(s, [me(
      /*$$props*/
      o[1]
    )]))), { props: r };
  }
  return a && (e = re(a, f(t))), {
    c() {
      e && ue(e.$$.fragment), l = Be();
    },
    m(o, n) {
      e && fe(e, o, n), y(o, l, n), i = !0;
    },
    p(o, [n]) {
      if (n & /*component*/
      1 && a !== (a = /*component*/
      o[0])) {
        if (e) {
          Re();
          const r = e;
          q(r.$$.fragment, 1, 0, () => {
            de(r, 1);
          }), ve();
        }
        a ? (e = re(a, f(o, n)), ue(e.$$.fragment), w(e.$$.fragment, 1), fe(e, l.parentNode, l)) : e = null;
      } else if (a) {
        const r = n & /*$$props*/
        2 ? _e(s, [me(
          /*$$props*/
          o[1]
        )]) : {};
        n & /*$$scope*/
        16 && (r.$$scope = { dirty: n, ctx: o }), e.$set(r);
      }
    },
    i(o) {
      i || (e && w(e.$$.fragment, o), i = !0);
    },
    o(o) {
      e && q(e.$$.fragment, o), i = !1;
    },
    d(o) {
      o && C(l), e && de(e, o);
    }
  };
}
function Xe(t, e, l) {
  let i, { $$slots: s = {}, $$scope: a } = e, { layout: f = "flex" } = e;
  return t.$$set = (o) => {
    l(1, e = K(K({}, e), he(o))), "layout" in o && l(2, f = o.layout), "$$scope" in o && l(4, a = o.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty & /*layout*/
    4 && l(0, i = f === "grid" ? Ke : Te);
  }, e = he(e), [i, e, f, s, a];
}
class Ze extends X {
  constructor(e) {
    super(), Y(this, e, Xe, Ve, Z, { layout: 2 });
  }
}
export {
  Ze as default
};
