import { Q as vf, R as mf } from "./index-e79f0bb2.js";
import { c as xf } from "./_commonjs-dynamic-modules-bed80856.js";
import { r as yf } from "./___vite-browser-external_commonjs-proxy-3c538421.js";
var Qo = { exports: {} };
(function(s, b) {
  (function(c, v) {
    s.exports = v();
  })(vf, function() {
    var c = navigator.userAgent, v = navigator.platform, m = /gecko\/\d/i.test(c), C = /MSIE \d/.test(c), g = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(c), y = /Edge\/(\d+)/.exec(c), x = C || g || y, A = x && (C ? document.documentMode || 6 : +(y || g)[1]), z = !y && /WebKit\//.test(c), P = z && /Qt\/\d+\.\d+/.test(c), N = !y && /Chrome\/(\d+)/.exec(c), G = N && +N[1], X = /Opera\//.test(c), le = /Apple Computer/.test(navigator.vendor), J = /Mac OS X 1\d\D([8-9]|\d\d)\D/.test(c), Q = /PhantomJS/.test(c), H = le && (/Mobile\/\w+/.test(c) || navigator.maxTouchPoints > 2), q = /Android/.test(c), R = H || q || /webOS|BlackBerry|Opera Mini|Opera Mobi|IEMobile/i.test(c), _ = H || /Mac/.test(v), te = /\bCrOS\b/.test(c), Y = /win/i.test(v), oe = X && c.match(/Version\/(\d*\.\d*)/);
    oe && (oe = Number(oe[1])), oe && oe >= 15 && (X = !1, z = !0);
    var pe = _ && (P || X && (oe == null || oe < 12.11)), qe = m || x && A >= 9;
    function ae(e) {
      return new RegExp("(^|\\s)" + e + "(?:$|\\s)\\s*");
    }
    var Se = function(e, t) {
      var i = e.className, r = ae(t).exec(i);
      if (r) {
        var n = i.slice(r.index + r[0].length);
        e.className = i.slice(0, r.index) + (n ? r[1] + n : "");
      }
    };
    function ke(e) {
      for (var t = e.childNodes.length; t > 0; --t)
        e.removeChild(e.firstChild);
      return e;
    }
    function De(e, t) {
      return ke(e).appendChild(t);
    }
    function T(e, t, i, r) {
      var n = document.createElement(e);
      if (i && (n.className = i), r && (n.style.cssText = r), typeof t == "string")
        n.appendChild(document.createTextNode(t));
      else if (t)
        for (var a = 0; a < t.length; ++a)
          n.appendChild(t[a]);
      return n;
    }
    function V(e, t, i, r) {
      var n = T(e, t, i, r);
      return n.setAttribute("role", "presentation"), n;
    }
    var Z;
    document.createRange ? Z = function(e, t, i, r) {
      var n = document.createRange();
      return n.setEnd(r || e, i), n.setStart(e, t), n;
    } : Z = function(e, t, i) {
      var r = document.body.createTextRange();
      try {
        r.moveToElementText(e.parentNode);
      } catch {
        return r;
      }
      return r.collapse(!0), r.moveEnd("character", i), r.moveStart("character", t), r;
    };
    function ge(e, t) {
      if (t.nodeType == 3 && (t = t.parentNode), e.contains)
        return e.contains(t);
      do
        if (t.nodeType == 11 && (t = t.host), t == e)
          return !0;
      while (t = t.parentNode);
    }
    function Me(e) {
      var t = e.ownerDocument || e, i;
      try {
        i = e.activeElement;
      } catch {
        i = t.body || null;
      }
      for (; i && i.shadowRoot && i.shadowRoot.activeElement; )
        i = i.shadowRoot.activeElement;
      return i;
    }
    function et(e, t) {
      var i = e.className;
      ae(t).test(i) || (e.className += (i ? " " : "") + t);
    }
    function Pt(e, t) {
      for (var i = e.split(" "), r = 0; r < i.length; r++)
        i[r] && !ae(i[r]).test(t) && (t += " " + i[r]);
      return t;
    }
    var S = function(e) {
      e.select();
    };
    H ? S = function(e) {
      e.selectionStart = 0, e.selectionEnd = e.value.length;
    } : x && (S = function(e) {
      try {
        e.select();
      } catch {
      }
    });
    function d(e) {
      return e.display.wrapper.ownerDocument;
    }
    function j(e) {
      return Ne(e.display.wrapper);
    }
    function Ne(e) {
      return e.getRootNode ? e.getRootNode() : e.ownerDocument;
    }
    function Ee(e) {
      return d(e).defaultView;
    }
    function $e(e) {
      var t = Array.prototype.slice.call(arguments, 1);
      return function() {
        return e.apply(null, t);
      };
    }
    function ht(e, t, i) {
      t || (t = {});
      for (var r in e)
        e.hasOwnProperty(r) && (i !== !1 || !t.hasOwnProperty(r)) && (t[r] = e[r]);
      return t;
    }
    function Xe(e, t, i, r, n) {
      t == null && (t = e.search(/[^\s\u00a0]/), t == -1 && (t = e.length));
      for (var a = r || 0, l = n || 0; ; ) {
        var o = e.indexOf("	", a);
        if (o < 0 || o >= t)
          return l + (t - a);
        l += o - a, l += i - l % i, a = o + 1;
      }
    }
    var nt = function() {
      this.id = null, this.f = null, this.time = 0, this.handler = $e(this.onTimeout, this);
    };
    nt.prototype.onTimeout = function(e) {
      e.id = 0, e.time <= +/* @__PURE__ */ new Date() ? e.f() : setTimeout(e.handler, e.time - +/* @__PURE__ */ new Date());
    }, nt.prototype.set = function(e, t) {
      this.f = t;
      var i = +/* @__PURE__ */ new Date() + e;
      (!this.id || i < this.time) && (clearTimeout(this.id), this.id = setTimeout(this.handler, e), this.time = i);
    };
    function Ie(e, t) {
      for (var i = 0; i < e.length; ++i)
        if (e[i] == t)
          return i;
      return -1;
    }
    var _e = 50, Je = { toString: function() {
      return "CodeMirror.Pass";
    } }, dt = { scroll: !1 }, ye = { origin: "*mouse" }, Bt = { origin: "+move" };
    function Mt(e, t, i) {
      for (var r = 0, n = 0; ; ) {
        var a = e.indexOf("	", r);
        a == -1 && (a = e.length);
        var l = a - r;
        if (a == e.length || n + l >= t)
          return r + Math.min(l, t - n);
        if (n += a - r, n += i - n % i, r = a + 1, n >= t)
          return r;
      }
    }
    var At = [""];
    function Wt(e) {
      for (; At.length <= e; )
        At.push(Be(At) + " ");
      return At[e];
    }
    function Be(e) {
      return e[e.length - 1];
    }
    function Et(e, t) {
      for (var i = [], r = 0; r < e.length; r++)
        i[r] = t(e[r], r);
      return i;
    }
    function _t(e, t, i) {
      for (var r = 0, n = i(t); r < e.length && i(e[r]) <= n; )
        r++;
      e.splice(r, 0, t);
    }
    function Tr() {
    }
    function I(e, t) {
      var i;
      return Object.create ? i = Object.create(e) : (Tr.prototype = e, i = new Tr()), t && ht(t, i), i;
    }
    var O = /[\u00df\u0587\u0590-\u05f4\u0600-\u06ff\u3040-\u309f\u30a0-\u30ff\u3400-\u4db5\u4e00-\u9fcc\uac00-\ud7af]/;
    function B(e) {
      return /\w/.test(e) || e > "" && (e.toUpperCase() != e.toLowerCase() || O.test(e));
    }
    function h(e, t) {
      return t ? t.source.indexOf("\\w") > -1 && B(e) ? !0 : t.test(e) : B(e);
    }
    function p(e) {
      for (var t in e)
        if (e.hasOwnProperty(t) && e[t])
          return !1;
      return !0;
    }
    var F = /[\u0300-\u036f\u0483-\u0489\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7\u0610-\u061a\u064b-\u065e\u0670\u06d6-\u06dc\u06de-\u06e4\u06e7\u06e8\u06ea-\u06ed\u0711\u0730-\u074a\u07a6-\u07b0\u07eb-\u07f3\u0816-\u0819\u081b-\u0823\u0825-\u0827\u0829-\u082d\u0900-\u0902\u093c\u0941-\u0948\u094d\u0951-\u0955\u0962\u0963\u0981\u09bc\u09be\u09c1-\u09c4\u09cd\u09d7\u09e2\u09e3\u0a01\u0a02\u0a3c\u0a41\u0a42\u0a47\u0a48\u0a4b-\u0a4d\u0a51\u0a70\u0a71\u0a75\u0a81\u0a82\u0abc\u0ac1-\u0ac5\u0ac7\u0ac8\u0acd\u0ae2\u0ae3\u0b01\u0b3c\u0b3e\u0b3f\u0b41-\u0b44\u0b4d\u0b56\u0b57\u0b62\u0b63\u0b82\u0bbe\u0bc0\u0bcd\u0bd7\u0c3e-\u0c40\u0c46-\u0c48\u0c4a-\u0c4d\u0c55\u0c56\u0c62\u0c63\u0cbc\u0cbf\u0cc2\u0cc6\u0ccc\u0ccd\u0cd5\u0cd6\u0ce2\u0ce3\u0d3e\u0d41-\u0d44\u0d4d\u0d57\u0d62\u0d63\u0dca\u0dcf\u0dd2-\u0dd4\u0dd6\u0ddf\u0e31\u0e34-\u0e3a\u0e47-\u0e4e\u0eb1\u0eb4-\u0eb9\u0ebb\u0ebc\u0ec8-\u0ecd\u0f18\u0f19\u0f35\u0f37\u0f39\u0f71-\u0f7e\u0f80-\u0f84\u0f86\u0f87\u0f90-\u0f97\u0f99-\u0fbc\u0fc6\u102d-\u1030\u1032-\u1037\u1039\u103a\u103d\u103e\u1058\u1059\u105e-\u1060\u1071-\u1074\u1082\u1085\u1086\u108d\u109d\u135f\u1712-\u1714\u1732-\u1734\u1752\u1753\u1772\u1773\u17b7-\u17bd\u17c6\u17c9-\u17d3\u17dd\u180b-\u180d\u18a9\u1920-\u1922\u1927\u1928\u1932\u1939-\u193b\u1a17\u1a18\u1a56\u1a58-\u1a5e\u1a60\u1a62\u1a65-\u1a6c\u1a73-\u1a7c\u1a7f\u1b00-\u1b03\u1b34\u1b36-\u1b3a\u1b3c\u1b42\u1b6b-\u1b73\u1b80\u1b81\u1ba2-\u1ba5\u1ba8\u1ba9\u1c2c-\u1c33\u1c36\u1c37\u1cd0-\u1cd2\u1cd4-\u1ce0\u1ce2-\u1ce8\u1ced\u1dc0-\u1de6\u1dfd-\u1dff\u200c\u200d\u20d0-\u20f0\u2cef-\u2cf1\u2de0-\u2dff\u302a-\u302f\u3099\u309a\ua66f-\ua672\ua67c\ua67d\ua6f0\ua6f1\ua802\ua806\ua80b\ua825\ua826\ua8c4\ua8e0-\ua8f1\ua926-\ua92d\ua947-\ua951\ua980-\ua982\ua9b3\ua9b6-\ua9b9\ua9bc\uaa29-\uaa2e\uaa31\uaa32\uaa35\uaa36\uaa43\uaa4c\uaab0\uaab2-\uaab4\uaab7\uaab8\uaabe\uaabf\uaac1\uabe5\uabe8\uabed\udc00-\udfff\ufb1e\ufe00-\ufe0f\ufe20-\ufe26\uff9e\uff9f]/;
    function k(e) {
      return e.charCodeAt(0) >= 768 && F.test(e);
    }
    function E(e, t, i) {
      for (; (i < 0 ? t > 0 : t < e.length) && k(e.charAt(t)); )
        t += i;
      return t;
    }
    function re(e, t, i) {
      for (var r = t > i ? -1 : 1; ; ) {
        if (t == i)
          return t;
        var n = (t + i) / 2, a = r < 0 ? Math.ceil(n) : Math.floor(n);
        if (a == t)
          return e(a) ? t : i;
        e(a) ? i = a : t = a + r;
      }
    }
    function de(e, t, i, r) {
      if (!e)
        return r(t, i, "ltr", 0);
      for (var n = !1, a = 0; a < e.length; ++a) {
        var l = e[a];
        (l.from < i && l.to > t || t == i && l.to == t) && (r(Math.max(l.from, t), Math.min(l.to, i), l.level == 1 ? "rtl" : "ltr", a), n = !0);
      }
      n || r(t, i, "ltr");
    }
    var fe = null;
    function ve(e, t, i) {
      var r;
      fe = null;
      for (var n = 0; n < e.length; ++n) {
        var a = e[n];
        if (a.from < t && a.to > t)
          return n;
        a.to == t && (a.from != a.to && i == "before" ? r = n : fe = n), a.from == t && (a.from != a.to && i != "before" ? r = n : fe = n);
      }
      return r ?? fe;
    }
    var we = function() {
      var e = "bbbbbbbbbtstwsbbbbbbbbbbbbbbssstwNN%%%NNNNNN,N,N1111111111NNNNNNNLLLLLLLLLLLLLLLLLLLLLLLLLLNNNNNNLLLLLLLLLLLLLLLLLLLLLLLLLLNNNNbbbbbbsbbbbbbbbbbbbbbbbbbbbbbbbbb,N%%%%NNNNLNNNNN%%11NLNNN1LNNNNNLLLLLLLLLLLLLLLLLLLLLLLNLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLN", t = "nnnnnnNNr%%r,rNNmmmmmmmmmmmrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrmmmmmmmmmmmmmmmmmmmmmnnnnnnnnnn%nnrrrmrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrmmmmmmmnNmmmmmmrrmmNmmmmrr1111111111";
      function i(f) {
        return f <= 247 ? e.charAt(f) : 1424 <= f && f <= 1524 ? "R" : 1536 <= f && f <= 1785 ? t.charAt(f - 1536) : 1774 <= f && f <= 2220 ? "r" : 8192 <= f && f <= 8203 ? "w" : f == 8204 ? "b" : "L";
      }
      var r = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac]/, n = /[stwN]/, a = /[LRr]/, l = /[Lb1n]/, o = /[1n]/;
      function u(f, D, w) {
        this.level = f, this.from = D, this.to = w;
      }
      return function(f, D) {
        var w = D == "ltr" ? "L" : "R";
        if (f.length == 0 || D == "ltr" && !r.test(f))
          return !1;
        for (var M = f.length, L = [], W = 0; W < M; ++W)
          L.push(i(f.charCodeAt(W)));
        for (var K = 0, ee = w; K < M; ++K) {
          var ie = L[K];
          ie == "m" ? L[K] = ee : ee = ie;
        }
        for (var se = 0, ne = w; se < M; ++se) {
          var he = L[se];
          he == "1" && ne == "r" ? L[se] = "n" : a.test(he) && (ne = he, he == "r" && (L[se] = "R"));
        }
        for (var be = 1, xe = L[0]; be < M - 1; ++be) {
          var Te = L[be];
          Te == "+" && xe == "1" && L[be + 1] == "1" ? L[be] = "1" : Te == "," && xe == L[be + 1] && (xe == "1" || xe == "n") && (L[be] = xe), xe = Te;
        }
        for (var Ue = 0; Ue < M; ++Ue) {
          var ft = L[Ue];
          if (ft == ",")
            L[Ue] = "N";
          else if (ft == "%") {
            var Ze = void 0;
            for (Ze = Ue + 1; Ze < M && L[Ze] == "%"; ++Ze)
              ;
            for (var Ft = Ue && L[Ue - 1] == "!" || Ze < M && L[Ze] == "1" ? "1" : "N", Ct = Ue; Ct < Ze; ++Ct)
              L[Ct] = Ft;
            Ue = Ze - 1;
          }
        }
        for (var rt = 0, wt = w; rt < M; ++rt) {
          var gt = L[rt];
          wt == "L" && gt == "1" ? L[rt] = "L" : a.test(gt) && (wt = gt);
        }
        for (var lt = 0; lt < M; ++lt)
          if (n.test(L[lt])) {
            var it = void 0;
            for (it = lt + 1; it < M && n.test(L[it]); ++it)
              ;
            for (var Qe = (lt ? L[lt - 1] : w) == "L", kt = (it < M ? L[it] : w) == "L", Qr = Qe == kt ? Qe ? "L" : "R" : w, cr = lt; cr < it; ++cr)
              L[cr] = Qr;
            lt = it - 1;
          }
        for (var mt = [], Kt, ct = 0; ct < M; )
          if (l.test(L[ct])) {
            var Ia = ct;
            for (++ct; ct < M && l.test(L[ct]); ++ct)
              ;
            mt.push(new u(0, Ia, ct));
          } else {
            var er = ct, Sr = mt.length, Fr = D == "rtl" ? 1 : 0;
            for (++ct; ct < M && L[ct] != "L"; ++ct)
              ;
            for (var yt = er; yt < ct; )
              if (o.test(L[yt])) {
                er < yt && (mt.splice(Sr, 0, new u(1, er, yt)), Sr += Fr);
                var $r = yt;
                for (++yt; yt < ct && o.test(L[yt]); ++yt)
                  ;
                mt.splice(Sr, 0, new u(2, $r, yt)), Sr += Fr, er = yt;
              } else
                ++yt;
            er < ct && mt.splice(Sr, 0, new u(1, er, ct));
          }
        return D == "ltr" && (mt[0].level == 1 && (Kt = f.match(/^\s+/)) && (mt[0].from = Kt[0].length, mt.unshift(new u(0, 0, Kt[0].length))), Be(mt).level == 1 && (Kt = f.match(/\s+$/)) && (Be(mt).to -= Kt[0].length, mt.push(new u(0, M - Kt[0].length, M)))), D == "rtl" ? mt.reverse() : mt;
      };
    }();
    function ue(e, t) {
      var i = e.order;
      return i == null && (i = e.order = we(e.text, t)), i;
    }
    var Ce = [], U = function(e, t, i) {
      if (e.addEventListener)
        e.addEventListener(t, i, !1);
      else if (e.attachEvent)
        e.attachEvent("on" + t, i);
      else {
        var r = e._handlers || (e._handlers = {});
        r[t] = (r[t] || Ce).concat(i);
      }
    };
    function ze(e, t) {
      return e._handlers && e._handlers[t] || Ce;
    }
    function Oe(e, t, i) {
      if (e.removeEventListener)
        e.removeEventListener(t, i, !1);
      else if (e.detachEvent)
        e.detachEvent("on" + t, i);
      else {
        var r = e._handlers, n = r && r[t];
        if (n) {
          var a = Ie(n, i);
          a > -1 && (r[t] = n.slice(0, a).concat(n.slice(a + 1)));
        }
      }
    }
    function He(e, t) {
      var i = ze(e, t);
      if (i.length)
        for (var r = Array.prototype.slice.call(arguments, 2), n = 0; n < i.length; ++n)
          i[n].apply(null, r);
    }
    function Le(e, t, i) {
      return typeof t == "string" && (t = { type: t, preventDefault: function() {
        this.defaultPrevented = !0;
      } }), He(e, i || t.type, e, t), Yt(t) || t.codemirrorIgnore;
    }
    function at(e) {
      var t = e._handlers && e._handlers.cursorActivity;
      if (t)
        for (var i = e.curOp.cursorActivityHandlers || (e.curOp.cursorActivityHandlers = []), r = 0; r < t.length; ++r)
          Ie(i, t[r]) == -1 && i.push(t[r]);
    }
    function pt(e, t) {
      return ze(e, t).length > 0;
    }
    function Nt(e) {
      e.prototype.on = function(t, i) {
        U(this, t, i);
      }, e.prototype.off = function(t, i) {
        Oe(this, t, i);
      };
    }
    function Ye(e) {
      e.preventDefault ? e.preventDefault() : e.returnValue = !1;
    }
    function Xt(e) {
      e.stopPropagation ? e.stopPropagation() : e.cancelBubble = !0;
    }
    function Yt(e) {
      return e.defaultPrevented != null ? e.defaultPrevented : e.returnValue == !1;
    }
    function It(e) {
      Ye(e), Xt(e);
    }
    function ei(e) {
      return e.target || e.srcElement;
    }
    function rr(e) {
      var t = e.which;
      return t == null && (e.button & 1 ? t = 1 : e.button & 2 ? t = 3 : e.button & 4 && (t = 2)), _ && e.ctrlKey && t == 1 && (t = 3), t;
    }
    var ou = function() {
      if (x && A < 9)
        return !1;
      var e = T("div");
      return "draggable" in e || "dragDrop" in e;
    }(), Mn;
    function uu(e) {
      if (Mn == null) {
        var t = T("span", "​");
        De(e, T("span", [t, document.createTextNode("x")])), e.firstChild.offsetHeight != 0 && (Mn = t.offsetWidth <= 1 && t.offsetHeight > 2 && !(x && A < 8));
      }
      var i = Mn ? T("span", "​") : T("span", " ", null, "display: inline-block; width: 1px; margin-right: -1px");
      return i.setAttribute("cm-text", ""), i;
    }
    var Nn;
    function su(e) {
      if (Nn != null)
        return Nn;
      var t = De(e, document.createTextNode("AخA")), i = Z(t, 0, 1).getBoundingClientRect(), r = Z(t, 1, 2).getBoundingClientRect();
      return ke(e), !i || i.left == i.right ? !1 : Nn = r.right - i.right < 3;
    }
    var In = `

b`.split(/\n/).length != 3 ? function(e) {
      for (var t = 0, i = [], r = e.length; t <= r; ) {
        var n = e.indexOf(`
`, t);
        n == -1 && (n = e.length);
        var a = e.slice(t, e.charAt(n - 1) == "\r" ? n - 1 : n), l = a.indexOf("\r");
        l != -1 ? (i.push(a.slice(0, l)), t += l + 1) : (i.push(a), t = n + 1);
      }
      return i;
    } : function(e) {
      return e.split(/\r\n?|\n/);
    }, fu = window.getSelection ? function(e) {
      try {
        return e.selectionStart != e.selectionEnd;
      } catch {
        return !1;
      }
    } : function(e) {
      var t;
      try {
        t = e.ownerDocument.selection.createRange();
      } catch {
      }
      return !t || t.parentElement() != e ? !1 : t.compareEndPoints("StartToEnd", t) != 0;
    }, cu = function() {
      var e = T("div");
      return "oncopy" in e ? !0 : (e.setAttribute("oncopy", "return;"), typeof e.oncopy == "function");
    }(), On = null;
    function hu(e) {
      if (On != null)
        return On;
      var t = De(e, T("span", "x")), i = t.getBoundingClientRect(), r = Z(t, 0, 1).getBoundingClientRect();
      return On = Math.abs(i.left - r.left) > 1;
    }
    var Hn = {}, Br = {};
    function du(e, t) {
      arguments.length > 2 && (t.dependencies = Array.prototype.slice.call(arguments, 2)), Hn[e] = t;
    }
    function pu(e, t) {
      Br[e] = t;
    }
    function Bi(e) {
      if (typeof e == "string" && Br.hasOwnProperty(e))
        e = Br[e];
      else if (e && typeof e.name == "string" && Br.hasOwnProperty(e.name)) {
        var t = Br[e.name];
        typeof t == "string" && (t = { name: t }), e = I(t, e), e.name = t.name;
      } else {
        if (typeof e == "string" && /^[\w\-]+\/[\w\-]+\+xml$/.test(e))
          return Bi("application/xml");
        if (typeof e == "string" && /^[\w\-]+\/[\w\-]+\+json$/.test(e))
          return Bi("application/json");
      }
      return typeof e == "string" ? { name: e } : e || { name: "null" };
    }
    function Rn(e, t) {
      t = Bi(t);
      var i = Hn[t.name];
      if (!i)
        return Rn(e, "text/plain");
      var r = i(e, t);
      if (Mr.hasOwnProperty(t.name)) {
        var n = Mr[t.name];
        for (var a in n)
          n.hasOwnProperty(a) && (r.hasOwnProperty(a) && (r["_" + a] = r[a]), r[a] = n[a]);
      }
      if (r.name = t.name, t.helperType && (r.helperType = t.helperType), t.modeProps)
        for (var l in t.modeProps)
          r[l] = t.modeProps[l];
      return r;
    }
    var Mr = {};
    function gu(e, t) {
      var i = Mr.hasOwnProperty(e) ? Mr[e] : Mr[e] = {};
      ht(t, i);
    }
    function pr(e, t) {
      if (t === !0)
        return t;
      if (e.copyState)
        return e.copyState(t);
      var i = {};
      for (var r in t) {
        var n = t[r];
        n instanceof Array && (n = n.concat([])), i[r] = n;
      }
      return i;
    }
    function zn(e, t) {
      for (var i; e.innerMode && (i = e.innerMode(t), !(!i || i.mode == e)); )
        t = i.state, e = i.mode;
      return i || { mode: e, state: t };
    }
    function Ga(e, t, i) {
      return e.startState ? e.startState(t, i) : !0;
    }
    var tt = function(e, t, i) {
      this.pos = this.start = 0, this.string = e, this.tabSize = t || 8, this.lastColumnPos = this.lastColumnValue = 0, this.lineStart = 0, this.lineOracle = i;
    };
    tt.prototype.eol = function() {
      return this.pos >= this.string.length;
    }, tt.prototype.sol = function() {
      return this.pos == this.lineStart;
    }, tt.prototype.peek = function() {
      return this.string.charAt(this.pos) || void 0;
    }, tt.prototype.next = function() {
      if (this.pos < this.string.length)
        return this.string.charAt(this.pos++);
    }, tt.prototype.eat = function(e) {
      var t = this.string.charAt(this.pos), i;
      if (typeof e == "string" ? i = t == e : i = t && (e.test ? e.test(t) : e(t)), i)
        return ++this.pos, t;
    }, tt.prototype.eatWhile = function(e) {
      for (var t = this.pos; this.eat(e); )
        ;
      return this.pos > t;
    }, tt.prototype.eatSpace = function() {
      for (var e = this.pos; /[\s\u00a0]/.test(this.string.charAt(this.pos)); )
        ++this.pos;
      return this.pos > e;
    }, tt.prototype.skipToEnd = function() {
      this.pos = this.string.length;
    }, tt.prototype.skipTo = function(e) {
      var t = this.string.indexOf(e, this.pos);
      if (t > -1)
        return this.pos = t, !0;
    }, tt.prototype.backUp = function(e) {
      this.pos -= e;
    }, tt.prototype.column = function() {
      return this.lastColumnPos < this.start && (this.lastColumnValue = Xe(this.string, this.start, this.tabSize, this.lastColumnPos, this.lastColumnValue), this.lastColumnPos = this.start), this.lastColumnValue - (this.lineStart ? Xe(this.string, this.lineStart, this.tabSize) : 0);
    }, tt.prototype.indentation = function() {
      return Xe(this.string, null, this.tabSize) - (this.lineStart ? Xe(this.string, this.lineStart, this.tabSize) : 0);
    }, tt.prototype.match = function(e, t, i) {
      if (typeof e == "string") {
        var r = function(l) {
          return i ? l.toLowerCase() : l;
        }, n = this.string.substr(this.pos, e.length);
        if (r(n) == r(e))
          return t !== !1 && (this.pos += e.length), !0;
      } else {
        var a = this.string.slice(this.pos).match(e);
        return a && a.index > 0 ? null : (a && t !== !1 && (this.pos += a[0].length), a);
      }
    }, tt.prototype.current = function() {
      return this.string.slice(this.start, this.pos);
    }, tt.prototype.hideFirstChars = function(e, t) {
      this.lineStart += e;
      try {
        return t();
      } finally {
        this.lineStart -= e;
      }
    }, tt.prototype.lookAhead = function(e) {
      var t = this.lineOracle;
      return t && t.lookAhead(e);
    }, tt.prototype.baseToken = function() {
      var e = this.lineOracle;
      return e && e.baseToken(this.pos);
    };
    function me(e, t) {
      if (t -= e.first, t < 0 || t >= e.size)
        throw new Error("There is no line " + (t + e.first) + " in the document.");
      for (var i = e; !i.lines; )
        for (var r = 0; ; ++r) {
          var n = i.children[r], a = n.chunkSize();
          if (t < a) {
            i = n;
            break;
          }
          t -= a;
        }
      return i.lines[t];
    }
    function gr(e, t, i) {
      var r = [], n = t.line;
      return e.iter(t.line, i.line + 1, function(a) {
        var l = a.text;
        n == i.line && (l = l.slice(0, i.ch)), n == t.line && (l = l.slice(t.ch)), r.push(l), ++n;
      }), r;
    }
    function Pn(e, t, i) {
      var r = [];
      return e.iter(t, i, function(n) {
        r.push(n.text);
      }), r;
    }
    function Ut(e, t) {
      var i = t - e.height;
      if (i)
        for (var r = e; r; r = r.parent)
          r.height += i;
    }
    function Pe(e) {
      if (e.parent == null)
        return null;
      for (var t = e.parent, i = Ie(t.lines, e), r = t.parent; r; t = r, r = r.parent)
        for (var n = 0; r.children[n] != t; ++n)
          i += r.children[n].chunkSize();
      return i + t.first;
    }
    function vr(e, t) {
      var i = e.first;
      e:
        do {
          for (var r = 0; r < e.children.length; ++r) {
            var n = e.children[r], a = n.height;
            if (t < a) {
              e = n;
              continue e;
            }
            t -= a, i += n.chunkSize();
          }
          return i;
        } while (!e.lines);
      for (var l = 0; l < e.lines.length; ++l) {
        var o = e.lines[l], u = o.height;
        if (t < u)
          break;
        t -= u;
      }
      return i + l;
    }
    function ti(e, t) {
      return t >= e.first && t < e.first + e.size;
    }
    function Wn(e, t) {
      return String(e.lineNumberFormatter(t + e.firstLineNumber));
    }
    function $(e, t, i) {
      if (i === void 0 && (i = null), !(this instanceof $))
        return new $(e, t, i);
      this.line = e, this.ch = t, this.sticky = i;
    }
    function Fe(e, t) {
      return e.line - t.line || e.ch - t.ch;
    }
    function _n(e, t) {
      return e.sticky == t.sticky && Fe(e, t) == 0;
    }
    function Un(e) {
      return $(e.line, e.ch);
    }
    function Mi(e, t) {
      return Fe(e, t) < 0 ? t : e;
    }
    function Ni(e, t) {
      return Fe(e, t) < 0 ? e : t;
    }
    function ja(e, t) {
      return Math.max(e.first, Math.min(t, e.first + e.size - 1));
    }
    function Ae(e, t) {
      if (t.line < e.first)
        return $(e.first, 0);
      var i = e.first + e.size - 1;
      return t.line > i ? $(i, me(e, i).text.length) : vu(t, me(e, t.line).text.length);
    }
    function vu(e, t) {
      var i = e.ch;
      return i == null || i > t ? $(e.line, t) : i < 0 ? $(e.line, 0) : e;
    }
    function Ka(e, t) {
      for (var i = [], r = 0; r < t.length; r++)
        i[r] = Ae(e, t[r]);
      return i;
    }
    var Ii = function(e, t) {
      this.state = e, this.lookAhead = t;
    }, qt = function(e, t, i, r) {
      this.state = t, this.doc = e, this.line = i, this.maxLookAhead = r || 0, this.baseTokens = null, this.baseTokenPos = 1;
    };
    qt.prototype.lookAhead = function(e) {
      var t = this.doc.getLine(this.line + e);
      return t != null && e > this.maxLookAhead && (this.maxLookAhead = e), t;
    }, qt.prototype.baseToken = function(e) {
      if (!this.baseTokens)
        return null;
      for (; this.baseTokens[this.baseTokenPos] <= e; )
        this.baseTokenPos += 2;
      var t = this.baseTokens[this.baseTokenPos + 1];
      return {
        type: t && t.replace(/( |^)overlay .*/, ""),
        size: this.baseTokens[this.baseTokenPos] - e
      };
    }, qt.prototype.nextLine = function() {
      this.line++, this.maxLookAhead > 0 && this.maxLookAhead--;
    }, qt.fromSaved = function(e, t, i) {
      return t instanceof Ii ? new qt(e, pr(e.mode, t.state), i, t.lookAhead) : new qt(e, pr(e.mode, t), i);
    }, qt.prototype.save = function(e) {
      var t = e !== !1 ? pr(this.doc.mode, this.state) : this.state;
      return this.maxLookAhead > 0 ? new Ii(t, this.maxLookAhead) : t;
    };
    function Xa(e, t, i, r) {
      var n = [e.state.modeGen], a = {};
      Va(
        e,
        t.text,
        e.doc.mode,
        i,
        function(f, D) {
          return n.push(f, D);
        },
        a,
        r
      );
      for (var l = i.state, o = function(f) {
        i.baseTokens = n;
        var D = e.state.overlays[f], w = 1, M = 0;
        i.state = !0, Va(e, t.text, D.mode, i, function(L, W) {
          for (var K = w; M < L; ) {
            var ee = n[w];
            ee > L && n.splice(w, 1, L, n[w + 1], ee), w += 2, M = Math.min(L, ee);
          }
          if (W)
            if (D.opaque)
              n.splice(K, w - K, L, "overlay " + W), w = K + 2;
            else
              for (; K < w; K += 2) {
                var ie = n[K + 1];
                n[K + 1] = (ie ? ie + " " : "") + "overlay " + W;
              }
        }, a), i.state = l, i.baseTokens = null, i.baseTokenPos = 1;
      }, u = 0; u < e.state.overlays.length; ++u)
        o(u);
      return { styles: n, classes: a.bgClass || a.textClass ? a : null };
    }
    function Ya(e, t, i) {
      if (!t.styles || t.styles[0] != e.state.modeGen) {
        var r = ri(e, Pe(t)), n = t.text.length > e.options.maxHighlightLength && pr(e.doc.mode, r.state), a = Xa(e, t, r);
        n && (r.state = n), t.stateAfter = r.save(!n), t.styles = a.styles, a.classes ? t.styleClasses = a.classes : t.styleClasses && (t.styleClasses = null), i === e.doc.highlightFrontier && (e.doc.modeFrontier = Math.max(e.doc.modeFrontier, ++e.doc.highlightFrontier));
      }
      return t.styles;
    }
    function ri(e, t, i) {
      var r = e.doc, n = e.display;
      if (!r.mode.startState)
        return new qt(r, !0, t);
      var a = mu(e, t, i), l = a > r.first && me(r, a - 1).stateAfter, o = l ? qt.fromSaved(r, l, a) : new qt(r, Ga(r.mode), a);
      return r.iter(a, t, function(u) {
        qn(e, u.text, o);
        var f = o.line;
        u.stateAfter = f == t - 1 || f % 5 == 0 || f >= n.viewFrom && f < n.viewTo ? o.save() : null, o.nextLine();
      }), i && (r.modeFrontier = o.line), o;
    }
    function qn(e, t, i, r) {
      var n = e.doc.mode, a = new tt(t, e.options.tabSize, i);
      for (a.start = a.pos = r || 0, t == "" && Za(n, i.state); !a.eol(); )
        Gn(n, a, i.state), a.start = a.pos;
    }
    function Za(e, t) {
      if (e.blankLine)
        return e.blankLine(t);
      if (e.innerMode) {
        var i = zn(e, t);
        if (i.mode.blankLine)
          return i.mode.blankLine(i.state);
      }
    }
    function Gn(e, t, i, r) {
      for (var n = 0; n < 10; n++) {
        r && (r[0] = zn(e, i).mode);
        var a = e.token(t, i);
        if (t.pos > t.start)
          return a;
      }
      throw new Error("Mode " + e.name + " failed to advance stream.");
    }
    var Qa = function(e, t, i) {
      this.start = e.start, this.end = e.pos, this.string = e.current(), this.type = t || null, this.state = i;
    };
    function $a(e, t, i, r) {
      var n = e.doc, a = n.mode, l;
      t = Ae(n, t);
      var o = me(n, t.line), u = ri(e, t.line, i), f = new tt(o.text, e.options.tabSize, u), D;
      for (r && (D = []); (r || f.pos < t.ch) && !f.eol(); )
        f.start = f.pos, l = Gn(a, f, u.state), r && D.push(new Qa(f, l, pr(n.mode, u.state)));
      return r ? D : new Qa(f, l, u.state);
    }
    function Ja(e, t) {
      if (e)
        for (; ; ) {
          var i = e.match(/(?:^|\s+)line-(background-)?(\S+)/);
          if (!i)
            break;
          e = e.slice(0, i.index) + e.slice(i.index + i[0].length);
          var r = i[1] ? "bgClass" : "textClass";
          t[r] == null ? t[r] = i[2] : new RegExp("(?:^|\\s)" + i[2] + "(?:$|\\s)").test(t[r]) || (t[r] += " " + i[2]);
        }
      return e;
    }
    function Va(e, t, i, r, n, a, l) {
      var o = i.flattenSpans;
      o == null && (o = e.options.flattenSpans);
      var u = 0, f = null, D = new tt(t, e.options.tabSize, r), w, M = e.options.addModeClass && [null];
      for (t == "" && Ja(Za(i, r.state), a); !D.eol(); ) {
        if (D.pos > e.options.maxHighlightLength ? (o = !1, l && qn(e, t, r, D.pos), D.pos = t.length, w = null) : w = Ja(Gn(i, D, r.state, M), a), M) {
          var L = M[0].name;
          L && (w = "m-" + (w ? L + " " + w : L));
        }
        if (!o || f != w) {
          for (; u < D.start; )
            u = Math.min(D.start, u + 5e3), n(u, f);
          f = w;
        }
        D.start = D.pos;
      }
      for (; u < D.pos; ) {
        var W = Math.min(D.pos, u + 5e3);
        n(W, f), u = W;
      }
    }
    function mu(e, t, i) {
      for (var r, n, a = e.doc, l = i ? -1 : t - (e.doc.mode.innerMode ? 1e3 : 100), o = t; o > l; --o) {
        if (o <= a.first)
          return a.first;
        var u = me(a, o - 1), f = u.stateAfter;
        if (f && (!i || o + (f instanceof Ii ? f.lookAhead : 0) <= a.modeFrontier))
          return o;
        var D = Xe(u.text, null, e.options.tabSize);
        (n == null || r > D) && (n = o - 1, r = D);
      }
      return n;
    }
    function xu(e, t) {
      if (e.modeFrontier = Math.min(e.modeFrontier, t), !(e.highlightFrontier < t - 10)) {
        for (var i = e.first, r = t - 1; r > i; r--) {
          var n = me(e, r).stateAfter;
          if (n && (!(n instanceof Ii) || r + n.lookAhead < t)) {
            i = r + 1;
            break;
          }
        }
        e.highlightFrontier = Math.min(e.highlightFrontier, i);
      }
    }
    var el = !1, Zt = !1;
    function yu() {
      el = !0;
    }
    function Du() {
      Zt = !0;
    }
    function Oi(e, t, i) {
      this.marker = e, this.from = t, this.to = i;
    }
    function ii(e, t) {
      if (e)
        for (var i = 0; i < e.length; ++i) {
          var r = e[i];
          if (r.marker == t)
            return r;
        }
    }
    function bu(e, t) {
      for (var i, r = 0; r < e.length; ++r)
        e[r] != t && (i || (i = [])).push(e[r]);
      return i;
    }
    function Cu(e, t, i) {
      var r = i && window.WeakSet && (i.markedSpans || (i.markedSpans = /* @__PURE__ */ new WeakSet()));
      r && e.markedSpans && r.has(e.markedSpans) ? e.markedSpans.push(t) : (e.markedSpans = e.markedSpans ? e.markedSpans.concat([t]) : [t], r && r.add(e.markedSpans)), t.marker.attachLine(e);
    }
    function wu(e, t, i) {
      var r;
      if (e)
        for (var n = 0; n < e.length; ++n) {
          var a = e[n], l = a.marker, o = a.from == null || (l.inclusiveLeft ? a.from <= t : a.from < t);
          if (o || a.from == t && l.type == "bookmark" && (!i || !a.marker.insertLeft)) {
            var u = a.to == null || (l.inclusiveRight ? a.to >= t : a.to > t);
            (r || (r = [])).push(new Oi(l, a.from, u ? null : a.to));
          }
        }
      return r;
    }
    function ku(e, t, i) {
      var r;
      if (e)
        for (var n = 0; n < e.length; ++n) {
          var a = e[n], l = a.marker, o = a.to == null || (l.inclusiveRight ? a.to >= t : a.to > t);
          if (o || a.from == t && l.type == "bookmark" && (!i || a.marker.insertLeft)) {
            var u = a.from == null || (l.inclusiveLeft ? a.from <= t : a.from < t);
            (r || (r = [])).push(new Oi(
              l,
              u ? null : a.from - t,
              a.to == null ? null : a.to - t
            ));
          }
        }
      return r;
    }
    function jn(e, t) {
      if (t.full)
        return null;
      var i = ti(e, t.from.line) && me(e, t.from.line).markedSpans, r = ti(e, t.to.line) && me(e, t.to.line).markedSpans;
      if (!i && !r)
        return null;
      var n = t.from.ch, a = t.to.ch, l = Fe(t.from, t.to) == 0, o = wu(i, n, l), u = ku(r, a, l), f = t.text.length == 1, D = Be(t.text).length + (f ? n : 0);
      if (o)
        for (var w = 0; w < o.length; ++w) {
          var M = o[w];
          if (M.to == null) {
            var L = ii(u, M.marker);
            L ? f && (M.to = L.to == null ? null : L.to + D) : M.to = n;
          }
        }
      if (u)
        for (var W = 0; W < u.length; ++W) {
          var K = u[W];
          if (K.to != null && (K.to += D), K.from == null) {
            var ee = ii(o, K.marker);
            ee || (K.from = D, f && (o || (o = [])).push(K));
          } else
            K.from += D, f && (o || (o = [])).push(K);
        }
      o && (o = tl(o)), u && u != o && (u = tl(u));
      var ie = [o];
      if (!f) {
        var se = t.text.length - 2, ne;
        if (se > 0 && o)
          for (var he = 0; he < o.length; ++he)
            o[he].to == null && (ne || (ne = [])).push(new Oi(o[he].marker, null, null));
        for (var be = 0; be < se; ++be)
          ie.push(ne);
        ie.push(u);
      }
      return ie;
    }
    function tl(e) {
      for (var t = 0; t < e.length; ++t) {
        var i = e[t];
        i.from != null && i.from == i.to && i.marker.clearWhenEmpty !== !1 && e.splice(t--, 1);
      }
      return e.length ? e : null;
    }
    function Su(e, t, i) {
      var r = null;
      if (e.iter(t.line, i.line + 1, function(L) {
        if (L.markedSpans)
          for (var W = 0; W < L.markedSpans.length; ++W) {
            var K = L.markedSpans[W].marker;
            K.readOnly && (!r || Ie(r, K) == -1) && (r || (r = [])).push(K);
          }
      }), !r)
        return null;
      for (var n = [{ from: t, to: i }], a = 0; a < r.length; ++a)
        for (var l = r[a], o = l.find(0), u = 0; u < n.length; ++u) {
          var f = n[u];
          if (!(Fe(f.to, o.from) < 0 || Fe(f.from, o.to) > 0)) {
            var D = [u, 1], w = Fe(f.from, o.from), M = Fe(f.to, o.to);
            (w < 0 || !l.inclusiveLeft && !w) && D.push({ from: f.from, to: o.from }), (M > 0 || !l.inclusiveRight && !M) && D.push({ from: o.to, to: f.to }), n.splice.apply(n, D), u += D.length - 3;
          }
        }
      return n;
    }
    function rl(e) {
      var t = e.markedSpans;
      if (t) {
        for (var i = 0; i < t.length; ++i)
          t[i].marker.detachLine(e);
        e.markedSpans = null;
      }
    }
    function il(e, t) {
      if (t) {
        for (var i = 0; i < t.length; ++i)
          t[i].marker.attachLine(e);
        e.markedSpans = t;
      }
    }
    function Hi(e) {
      return e.inclusiveLeft ? -1 : 0;
    }
    function Ri(e) {
      return e.inclusiveRight ? 1 : 0;
    }
    function Kn(e, t) {
      var i = e.lines.length - t.lines.length;
      if (i != 0)
        return i;
      var r = e.find(), n = t.find(), a = Fe(r.from, n.from) || Hi(e) - Hi(t);
      if (a)
        return -a;
      var l = Fe(r.to, n.to) || Ri(e) - Ri(t);
      return l || t.id - e.id;
    }
    function nl(e, t) {
      var i = Zt && e.markedSpans, r;
      if (i)
        for (var n = void 0, a = 0; a < i.length; ++a)
          n = i[a], n.marker.collapsed && (t ? n.from : n.to) == null && (!r || Kn(r, n.marker) < 0) && (r = n.marker);
      return r;
    }
    function al(e) {
      return nl(e, !0);
    }
    function zi(e) {
      return nl(e, !1);
    }
    function Fu(e, t) {
      var i = Zt && e.markedSpans, r;
      if (i)
        for (var n = 0; n < i.length; ++n) {
          var a = i[n];
          a.marker.collapsed && (a.from == null || a.from < t) && (a.to == null || a.to > t) && (!r || Kn(r, a.marker) < 0) && (r = a.marker);
        }
      return r;
    }
    function ll(e, t, i, r, n) {
      var a = me(e, t), l = Zt && a.markedSpans;
      if (l)
        for (var o = 0; o < l.length; ++o) {
          var u = l[o];
          if (u.marker.collapsed) {
            var f = u.marker.find(0), D = Fe(f.from, i) || Hi(u.marker) - Hi(n), w = Fe(f.to, r) || Ri(u.marker) - Ri(n);
            if (!(D >= 0 && w <= 0 || D <= 0 && w >= 0) && (D <= 0 && (u.marker.inclusiveRight && n.inclusiveLeft ? Fe(f.to, i) >= 0 : Fe(f.to, i) > 0) || D >= 0 && (u.marker.inclusiveRight && n.inclusiveLeft ? Fe(f.from, r) <= 0 : Fe(f.from, r) < 0)))
              return !0;
          }
        }
    }
    function Ot(e) {
      for (var t; t = al(e); )
        e = t.find(-1, !0).line;
      return e;
    }
    function Au(e) {
      for (var t; t = zi(e); )
        e = t.find(1, !0).line;
      return e;
    }
    function Eu(e) {
      for (var t, i; t = zi(e); )
        e = t.find(1, !0).line, (i || (i = [])).push(e);
      return i;
    }
    function Xn(e, t) {
      var i = me(e, t), r = Ot(i);
      return i == r ? t : Pe(r);
    }
    function ol(e, t) {
      if (t > e.lastLine())
        return t;
      var i = me(e, t), r;
      if (!ir(e, i))
        return t;
      for (; r = zi(i); )
        i = r.find(1, !0).line;
      return Pe(i) + 1;
    }
    function ir(e, t) {
      var i = Zt && t.markedSpans;
      if (i) {
        for (var r = void 0, n = 0; n < i.length; ++n)
          if (r = i[n], !!r.marker.collapsed) {
            if (r.from == null)
              return !0;
            if (!r.marker.widgetNode && r.from == 0 && r.marker.inclusiveLeft && Yn(e, t, r))
              return !0;
          }
      }
    }
    function Yn(e, t, i) {
      if (i.to == null) {
        var r = i.marker.find(1, !0);
        return Yn(e, r.line, ii(r.line.markedSpans, i.marker));
      }
      if (i.marker.inclusiveRight && i.to == t.text.length)
        return !0;
      for (var n = void 0, a = 0; a < t.markedSpans.length; ++a)
        if (n = t.markedSpans[a], n.marker.collapsed && !n.marker.widgetNode && n.from == i.to && (n.to == null || n.to != i.from) && (n.marker.inclusiveLeft || i.marker.inclusiveRight) && Yn(e, t, n))
          return !0;
    }
    function Qt(e) {
      e = Ot(e);
      for (var t = 0, i = e.parent, r = 0; r < i.lines.length; ++r) {
        var n = i.lines[r];
        if (n == e)
          break;
        t += n.height;
      }
      for (var a = i.parent; a; i = a, a = i.parent)
        for (var l = 0; l < a.children.length; ++l) {
          var o = a.children[l];
          if (o == i)
            break;
          t += o.height;
        }
      return t;
    }
    function Pi(e) {
      if (e.height == 0)
        return 0;
      for (var t = e.text.length, i, r = e; i = al(r); ) {
        var n = i.find(0, !0);
        r = n.from.line, t += n.from.ch - n.to.ch;
      }
      for (r = e; i = zi(r); ) {
        var a = i.find(0, !0);
        t -= r.text.length - a.from.ch, r = a.to.line, t += r.text.length - a.to.ch;
      }
      return t;
    }
    function Zn(e) {
      var t = e.display, i = e.doc;
      t.maxLine = me(i, i.first), t.maxLineLength = Pi(t.maxLine), t.maxLineChanged = !0, i.iter(function(r) {
        var n = Pi(r);
        n > t.maxLineLength && (t.maxLineLength = n, t.maxLine = r);
      });
    }
    var Nr = function(e, t, i) {
      this.text = e, il(this, t), this.height = i ? i(this) : 1;
    };
    Nr.prototype.lineNo = function() {
      return Pe(this);
    }, Nt(Nr);
    function Lu(e, t, i, r) {
      e.text = t, e.stateAfter && (e.stateAfter = null), e.styles && (e.styles = null), e.order != null && (e.order = null), rl(e), il(e, i);
      var n = r ? r(e) : 1;
      n != e.height && Ut(e, n);
    }
    function Tu(e) {
      e.parent = null, rl(e);
    }
    var Bu = {}, Mu = {};
    function ul(e, t) {
      if (!e || /^\s*$/.test(e))
        return null;
      var i = t.addModeClass ? Mu : Bu;
      return i[e] || (i[e] = e.replace(/\S+/g, "cm-$&"));
    }
    function sl(e, t) {
      var i = V("span", null, null, z ? "padding-right: .1px" : null), r = {
        pre: V("pre", [i], "CodeMirror-line"),
        content: i,
        col: 0,
        pos: 0,
        cm: e,
        trailingSpace: !1,
        splitSpaces: e.getOption("lineWrapping")
      };
      t.measure = {};
      for (var n = 0; n <= (t.rest ? t.rest.length : 0); n++) {
        var a = n ? t.rest[n - 1] : t.line, l = void 0;
        r.pos = 0, r.addToken = Iu, su(e.display.measure) && (l = ue(a, e.doc.direction)) && (r.addToken = Hu(r.addToken, l)), r.map = [];
        var o = t != e.display.externalMeasured && Pe(a);
        Ru(a, r, Ya(e, a, o)), a.styleClasses && (a.styleClasses.bgClass && (r.bgClass = Pt(a.styleClasses.bgClass, r.bgClass || "")), a.styleClasses.textClass && (r.textClass = Pt(a.styleClasses.textClass, r.textClass || ""))), r.map.length == 0 && r.map.push(0, 0, r.content.appendChild(uu(e.display.measure))), n == 0 ? (t.measure.map = r.map, t.measure.cache = {}) : ((t.measure.maps || (t.measure.maps = [])).push(r.map), (t.measure.caches || (t.measure.caches = [])).push({}));
      }
      if (z) {
        var u = r.content.lastChild;
        (/\bcm-tab\b/.test(u.className) || u.querySelector && u.querySelector(".cm-tab")) && (r.content.className = "cm-tab-wrap-hack");
      }
      return He(e, "renderLine", e, t.line, r.pre), r.pre.className && (r.textClass = Pt(r.pre.className, r.textClass || "")), r;
    }
    function Nu(e) {
      var t = T("span", "•", "cm-invalidchar");
      return t.title = "\\u" + e.charCodeAt(0).toString(16), t.setAttribute("aria-label", t.title), t;
    }
    function Iu(e, t, i, r, n, a, l) {
      if (t) {
        var o = e.splitSpaces ? Ou(t, e.trailingSpace) : t, u = e.cm.state.specialChars, f = !1, D;
        if (!u.test(t))
          e.col += t.length, D = document.createTextNode(o), e.map.push(e.pos, e.pos + t.length, D), x && A < 9 && (f = !0), e.pos += t.length;
        else {
          D = document.createDocumentFragment();
          for (var w = 0; ; ) {
            u.lastIndex = w;
            var M = u.exec(t), L = M ? M.index - w : t.length - w;
            if (L) {
              var W = document.createTextNode(o.slice(w, w + L));
              x && A < 9 ? D.appendChild(T("span", [W])) : D.appendChild(W), e.map.push(e.pos, e.pos + L, W), e.col += L, e.pos += L;
            }
            if (!M)
              break;
            w += L + 1;
            var K = void 0;
            if (M[0] == "	") {
              var ee = e.cm.options.tabSize, ie = ee - e.col % ee;
              K = D.appendChild(T("span", Wt(ie), "cm-tab")), K.setAttribute("role", "presentation"), K.setAttribute("cm-text", "	"), e.col += ie;
            } else
              M[0] == "\r" || M[0] == `
` ? (K = D.appendChild(T("span", M[0] == "\r" ? "␍" : "␤", "cm-invalidchar")), K.setAttribute("cm-text", M[0]), e.col += 1) : (K = e.cm.options.specialCharPlaceholder(M[0]), K.setAttribute("cm-text", M[0]), x && A < 9 ? D.appendChild(T("span", [K])) : D.appendChild(K), e.col += 1);
            e.map.push(e.pos, e.pos + 1, K), e.pos++;
          }
        }
        if (e.trailingSpace = o.charCodeAt(t.length - 1) == 32, i || r || n || f || a || l) {
          var se = i || "";
          r && (se += r), n && (se += n);
          var ne = T("span", [D], se, a);
          if (l)
            for (var he in l)
              l.hasOwnProperty(he) && he != "style" && he != "class" && ne.setAttribute(he, l[he]);
          return e.content.appendChild(ne);
        }
        e.content.appendChild(D);
      }
    }
    function Ou(e, t) {
      if (e.length > 1 && !/  /.test(e))
        return e;
      for (var i = t, r = "", n = 0; n < e.length; n++) {
        var a = e.charAt(n);
        a == " " && i && (n == e.length - 1 || e.charCodeAt(n + 1) == 32) && (a = " "), r += a, i = a == " ";
      }
      return r;
    }
    function Hu(e, t) {
      return function(i, r, n, a, l, o, u) {
        n = n ? n + " cm-force-border" : "cm-force-border";
        for (var f = i.pos, D = f + r.length; ; ) {
          for (var w = void 0, M = 0; M < t.length && (w = t[M], !(w.to > f && w.from <= f)); M++)
            ;
          if (w.to >= D)
            return e(i, r, n, a, l, o, u);
          e(i, r.slice(0, w.to - f), n, a, null, o, u), a = null, r = r.slice(w.to - f), f = w.to;
        }
      };
    }
    function fl(e, t, i, r) {
      var n = !r && i.widgetNode;
      n && e.map.push(e.pos, e.pos + t, n), !r && e.cm.display.input.needsContentAttribute && (n || (n = e.content.appendChild(document.createElement("span"))), n.setAttribute("cm-marker", i.id)), n && (e.cm.display.input.setUneditable(n), e.content.appendChild(n)), e.pos += t, e.trailingSpace = !1;
    }
    function Ru(e, t, i) {
      var r = e.markedSpans, n = e.text, a = 0;
      if (!r) {
        for (var l = 1; l < i.length; l += 2)
          t.addToken(t, n.slice(a, a = i[l]), ul(i[l + 1], t.cm.options));
        return;
      }
      for (var o = n.length, u = 0, f = 1, D = "", w, M, L = 0, W, K, ee, ie, se; ; ) {
        if (L == u) {
          W = K = ee = M = "", se = null, ie = null, L = 1 / 0;
          for (var ne = [], he = void 0, be = 0; be < r.length; ++be) {
            var xe = r[be], Te = xe.marker;
            if (Te.type == "bookmark" && xe.from == u && Te.widgetNode)
              ne.push(Te);
            else if (xe.from <= u && (xe.to == null || xe.to > u || Te.collapsed && xe.to == u && xe.from == u)) {
              if (xe.to != null && xe.to != u && L > xe.to && (L = xe.to, K = ""), Te.className && (W += " " + Te.className), Te.css && (M = (M ? M + ";" : "") + Te.css), Te.startStyle && xe.from == u && (ee += " " + Te.startStyle), Te.endStyle && xe.to == L && (he || (he = [])).push(Te.endStyle, xe.to), Te.title && ((se || (se = {})).title = Te.title), Te.attributes)
                for (var Ue in Te.attributes)
                  (se || (se = {}))[Ue] = Te.attributes[Ue];
              Te.collapsed && (!ie || Kn(ie.marker, Te) < 0) && (ie = xe);
            } else
              xe.from > u && L > xe.from && (L = xe.from);
          }
          if (he)
            for (var ft = 0; ft < he.length; ft += 2)
              he[ft + 1] == L && (K += " " + he[ft]);
          if (!ie || ie.from == u)
            for (var Ze = 0; Ze < ne.length; ++Ze)
              fl(t, 0, ne[Ze]);
          if (ie && (ie.from || 0) == u) {
            if (fl(
              t,
              (ie.to == null ? o + 1 : ie.to) - u,
              ie.marker,
              ie.from == null
            ), ie.to == null)
              return;
            ie.to == u && (ie = !1);
          }
        }
        if (u >= o)
          break;
        for (var Ft = Math.min(o, L); ; ) {
          if (D) {
            var Ct = u + D.length;
            if (!ie) {
              var rt = Ct > Ft ? D.slice(0, Ft - u) : D;
              t.addToken(
                t,
                rt,
                w ? w + W : W,
                ee,
                u + rt.length == L ? K : "",
                M,
                se
              );
            }
            if (Ct >= Ft) {
              D = D.slice(Ft - u), u = Ft;
              break;
            }
            u = Ct, ee = "";
          }
          D = n.slice(a, a = i[f++]), w = ul(i[f++], t.cm.options);
        }
      }
    }
    function cl(e, t, i) {
      this.line = t, this.rest = Eu(t), this.size = this.rest ? Pe(Be(this.rest)) - i + 1 : 1, this.node = this.text = null, this.hidden = ir(e, t);
    }
    function Wi(e, t, i) {
      for (var r = [], n, a = t; a < i; a = n) {
        var l = new cl(e.doc, me(e.doc, a), a);
        n = a + l.size, r.push(l);
      }
      return r;
    }
    var Ir = null;
    function zu(e) {
      Ir ? Ir.ops.push(e) : e.ownsGroup = Ir = {
        ops: [e],
        delayedCallbacks: []
      };
    }
    function Pu(e) {
      var t = e.delayedCallbacks, i = 0;
      do {
        for (; i < t.length; i++)
          t[i].call(null);
        for (var r = 0; r < e.ops.length; r++) {
          var n = e.ops[r];
          if (n.cursorActivityHandlers)
            for (; n.cursorActivityCalled < n.cursorActivityHandlers.length; )
              n.cursorActivityHandlers[n.cursorActivityCalled++].call(null, n.cm);
        }
      } while (i < t.length);
    }
    function Wu(e, t) {
      var i = e.ownsGroup;
      if (i)
        try {
          Pu(i);
        } finally {
          Ir = null, t(i);
        }
    }
    var ni = null;
    function ot(e, t) {
      var i = ze(e, t);
      if (i.length) {
        var r = Array.prototype.slice.call(arguments, 2), n;
        Ir ? n = Ir.delayedCallbacks : ni ? n = ni : (n = ni = [], setTimeout(_u, 0));
        for (var a = function(o) {
          n.push(function() {
            return i[o].apply(null, r);
          });
        }, l = 0; l < i.length; ++l)
          a(l);
      }
    }
    function _u() {
      var e = ni;
      ni = null;
      for (var t = 0; t < e.length; ++t)
        e[t]();
    }
    function hl(e, t, i, r) {
      for (var n = 0; n < t.changes.length; n++) {
        var a = t.changes[n];
        a == "text" ? qu(e, t) : a == "gutter" ? pl(e, t, i, r) : a == "class" ? Qn(e, t) : a == "widget" && Gu(e, t, r);
      }
      t.changes = null;
    }
    function ai(e) {
      return e.node == e.text && (e.node = T("div", null, null, "position: relative"), e.text.parentNode && e.text.parentNode.replaceChild(e.node, e.text), e.node.appendChild(e.text), x && A < 8 && (e.node.style.zIndex = 2)), e.node;
    }
    function Uu(e, t) {
      var i = t.bgClass ? t.bgClass + " " + (t.line.bgClass || "") : t.line.bgClass;
      if (i && (i += " CodeMirror-linebackground"), t.background)
        i ? t.background.className = i : (t.background.parentNode.removeChild(t.background), t.background = null);
      else if (i) {
        var r = ai(t);
        t.background = r.insertBefore(T("div", null, i), r.firstChild), e.display.input.setUneditable(t.background);
      }
    }
    function dl(e, t) {
      var i = e.display.externalMeasured;
      return i && i.line == t.line ? (e.display.externalMeasured = null, t.measure = i.measure, i.built) : sl(e, t);
    }
    function qu(e, t) {
      var i = t.text.className, r = dl(e, t);
      t.text == t.node && (t.node = r.pre), t.text.parentNode.replaceChild(r.pre, t.text), t.text = r.pre, r.bgClass != t.bgClass || r.textClass != t.textClass ? (t.bgClass = r.bgClass, t.textClass = r.textClass, Qn(e, t)) : i && (t.text.className = i);
    }
    function Qn(e, t) {
      Uu(e, t), t.line.wrapClass ? ai(t).className = t.line.wrapClass : t.node != t.text && (t.node.className = "");
      var i = t.textClass ? t.textClass + " " + (t.line.textClass || "") : t.line.textClass;
      t.text.className = i || "";
    }
    function pl(e, t, i, r) {
      if (t.gutter && (t.node.removeChild(t.gutter), t.gutter = null), t.gutterBackground && (t.node.removeChild(t.gutterBackground), t.gutterBackground = null), t.line.gutterClass) {
        var n = ai(t);
        t.gutterBackground = T(
          "div",
          null,
          "CodeMirror-gutter-background " + t.line.gutterClass,
          "left: " + (e.options.fixedGutter ? r.fixedPos : -r.gutterTotalWidth) + "px; width: " + r.gutterTotalWidth + "px"
        ), e.display.input.setUneditable(t.gutterBackground), n.insertBefore(t.gutterBackground, t.text);
      }
      var a = t.line.gutterMarkers;
      if (e.options.lineNumbers || a) {
        var l = ai(t), o = t.gutter = T("div", null, "CodeMirror-gutter-wrapper", "left: " + (e.options.fixedGutter ? r.fixedPos : -r.gutterTotalWidth) + "px");
        if (o.setAttribute("aria-hidden", "true"), e.display.input.setUneditable(o), l.insertBefore(o, t.text), t.line.gutterClass && (o.className += " " + t.line.gutterClass), e.options.lineNumbers && (!a || !a["CodeMirror-linenumbers"]) && (t.lineNumber = o.appendChild(
          T(
            "div",
            Wn(e.options, i),
            "CodeMirror-linenumber CodeMirror-gutter-elt",
            "left: " + r.gutterLeft["CodeMirror-linenumbers"] + "px; width: " + e.display.lineNumInnerWidth + "px"
          )
        )), a)
          for (var u = 0; u < e.display.gutterSpecs.length; ++u) {
            var f = e.display.gutterSpecs[u].className, D = a.hasOwnProperty(f) && a[f];
            D && o.appendChild(T(
              "div",
              [D],
              "CodeMirror-gutter-elt",
              "left: " + r.gutterLeft[f] + "px; width: " + r.gutterWidth[f] + "px"
            ));
          }
      }
    }
    function Gu(e, t, i) {
      t.alignable && (t.alignable = null);
      for (var r = ae("CodeMirror-linewidget"), n = t.node.firstChild, a = void 0; n; n = a)
        a = n.nextSibling, r.test(n.className) && t.node.removeChild(n);
      gl(e, t, i);
    }
    function ju(e, t, i, r) {
      var n = dl(e, t);
      return t.text = t.node = n.pre, n.bgClass && (t.bgClass = n.bgClass), n.textClass && (t.textClass = n.textClass), Qn(e, t), pl(e, t, i, r), gl(e, t, r), t.node;
    }
    function gl(e, t, i) {
      if (vl(e, t.line, t, i, !0), t.rest)
        for (var r = 0; r < t.rest.length; r++)
          vl(e, t.rest[r], t, i, !1);
    }
    function vl(e, t, i, r, n) {
      if (t.widgets)
        for (var a = ai(i), l = 0, o = t.widgets; l < o.length; ++l) {
          var u = o[l], f = T("div", [u.node], "CodeMirror-linewidget" + (u.className ? " " + u.className : ""));
          u.handleMouseEvents || f.setAttribute("cm-ignore-events", "true"), Ku(u, f, i, r), e.display.input.setUneditable(f), n && u.above ? a.insertBefore(f, i.gutter || i.text) : a.appendChild(f), ot(u, "redraw");
        }
    }
    function Ku(e, t, i, r) {
      if (e.noHScroll) {
        (i.alignable || (i.alignable = [])).push(t);
        var n = r.wrapperWidth;
        t.style.left = r.fixedPos + "px", e.coverGutter || (n -= r.gutterTotalWidth, t.style.paddingLeft = r.gutterTotalWidth + "px"), t.style.width = n + "px";
      }
      e.coverGutter && (t.style.zIndex = 5, t.style.position = "relative", e.noHScroll || (t.style.marginLeft = -r.gutterTotalWidth + "px"));
    }
    function li(e) {
      if (e.height != null)
        return e.height;
      var t = e.doc.cm;
      if (!t)
        return 0;
      if (!ge(document.body, e.node)) {
        var i = "position: relative;";
        e.coverGutter && (i += "margin-left: -" + t.display.gutters.offsetWidth + "px;"), e.noHScroll && (i += "width: " + t.display.wrapper.clientWidth + "px;"), De(t.display.measure, T("div", [e.node], null, i));
      }
      return e.height = e.node.parentNode.offsetHeight;
    }
    function $t(e, t) {
      for (var i = ei(t); i != e.wrapper; i = i.parentNode)
        if (!i || i.nodeType == 1 && i.getAttribute("cm-ignore-events") == "true" || i.parentNode == e.sizer && i != e.mover)
          return !0;
    }
    function _i(e) {
      return e.lineSpace.offsetTop;
    }
    function $n(e) {
      return e.mover.offsetHeight - e.lineSpace.offsetHeight;
    }
    function ml(e) {
      if (e.cachedPaddingH)
        return e.cachedPaddingH;
      var t = De(e.measure, T("pre", "x", "CodeMirror-line-like")), i = window.getComputedStyle ? window.getComputedStyle(t) : t.currentStyle, r = { left: parseInt(i.paddingLeft), right: parseInt(i.paddingRight) };
      return !isNaN(r.left) && !isNaN(r.right) && (e.cachedPaddingH = r), r;
    }
    function Gt(e) {
      return _e - e.display.nativeBarWidth;
    }
    function mr(e) {
      return e.display.scroller.clientWidth - Gt(e) - e.display.barWidth;
    }
    function Jn(e) {
      return e.display.scroller.clientHeight - Gt(e) - e.display.barHeight;
    }
    function Xu(e, t, i) {
      var r = e.options.lineWrapping, n = r && mr(e);
      if (!t.measure.heights || r && t.measure.width != n) {
        var a = t.measure.heights = [];
        if (r) {
          t.measure.width = n;
          for (var l = t.text.firstChild.getClientRects(), o = 0; o < l.length - 1; o++) {
            var u = l[o], f = l[o + 1];
            Math.abs(u.bottom - f.bottom) > 2 && a.push((u.bottom + f.top) / 2 - i.top);
          }
        }
        a.push(i.bottom - i.top);
      }
    }
    function xl(e, t, i) {
      if (e.line == t)
        return { map: e.measure.map, cache: e.measure.cache };
      if (e.rest) {
        for (var r = 0; r < e.rest.length; r++)
          if (e.rest[r] == t)
            return { map: e.measure.maps[r], cache: e.measure.caches[r] };
        for (var n = 0; n < e.rest.length; n++)
          if (Pe(e.rest[n]) > i)
            return { map: e.measure.maps[n], cache: e.measure.caches[n], before: !0 };
      }
    }
    function Yu(e, t) {
      t = Ot(t);
      var i = Pe(t), r = e.display.externalMeasured = new cl(e.doc, t, i);
      r.lineN = i;
      var n = r.built = sl(e, r);
      return r.text = n.pre, De(e.display.lineMeasure, n.pre), r;
    }
    function yl(e, t, i, r) {
      return jt(e, Or(e, t), i, r);
    }
    function Vn(e, t) {
      if (t >= e.display.viewFrom && t < e.display.viewTo)
        return e.display.view[Dr(e, t)];
      var i = e.display.externalMeasured;
      if (i && t >= i.lineN && t < i.lineN + i.size)
        return i;
    }
    function Or(e, t) {
      var i = Pe(t), r = Vn(e, i);
      r && !r.text ? r = null : r && r.changes && (hl(e, r, i, na(e)), e.curOp.forceUpdate = !0), r || (r = Yu(e, t));
      var n = xl(r, t, i);
      return {
        line: t,
        view: r,
        rect: null,
        map: n.map,
        cache: n.cache,
        before: n.before,
        hasHeights: !1
      };
    }
    function jt(e, t, i, r, n) {
      t.before && (i = -1);
      var a = i + (r || ""), l;
      return t.cache.hasOwnProperty(a) ? l = t.cache[a] : (t.rect || (t.rect = t.view.text.getBoundingClientRect()), t.hasHeights || (Xu(e, t.view, t.rect), t.hasHeights = !0), l = Qu(e, t, i, r), l.bogus || (t.cache[a] = l)), {
        left: l.left,
        right: l.right,
        top: n ? l.rtop : l.top,
        bottom: n ? l.rbottom : l.bottom
      };
    }
    var Dl = { left: 0, right: 0, top: 0, bottom: 0 };
    function bl(e, t, i) {
      for (var r, n, a, l, o, u, f = 0; f < e.length; f += 3)
        if (o = e[f], u = e[f + 1], t < o ? (n = 0, a = 1, l = "left") : t < u ? (n = t - o, a = n + 1) : (f == e.length - 3 || t == u && e[f + 3] > t) && (a = u - o, n = a - 1, t >= u && (l = "right")), n != null) {
          if (r = e[f + 2], o == u && i == (r.insertLeft ? "left" : "right") && (l = i), i == "left" && n == 0)
            for (; f && e[f - 2] == e[f - 3] && e[f - 1].insertLeft; )
              r = e[(f -= 3) + 2], l = "left";
          if (i == "right" && n == u - o)
            for (; f < e.length - 3 && e[f + 3] == e[f + 4] && !e[f + 5].insertLeft; )
              r = e[(f += 3) + 2], l = "right";
          break;
        }
      return { node: r, start: n, end: a, collapse: l, coverStart: o, coverEnd: u };
    }
    function Zu(e, t) {
      var i = Dl;
      if (t == "left")
        for (var r = 0; r < e.length && (i = e[r]).left == i.right; r++)
          ;
      else
        for (var n = e.length - 1; n >= 0 && (i = e[n]).left == i.right; n--)
          ;
      return i;
    }
    function Qu(e, t, i, r) {
      var n = bl(t.map, i, r), a = n.node, l = n.start, o = n.end, u = n.collapse, f;
      if (a.nodeType == 3) {
        for (var D = 0; D < 4; D++) {
          for (; l && k(t.line.text.charAt(n.coverStart + l)); )
            --l;
          for (; n.coverStart + o < n.coverEnd && k(t.line.text.charAt(n.coverStart + o)); )
            ++o;
          if (x && A < 9 && l == 0 && o == n.coverEnd - n.coverStart ? f = a.parentNode.getBoundingClientRect() : f = Zu(Z(a, l, o).getClientRects(), r), f.left || f.right || l == 0)
            break;
          o = l, l = l - 1, u = "right";
        }
        x && A < 11 && (f = $u(e.display.measure, f));
      } else {
        l > 0 && (u = r = "right");
        var w;
        e.options.lineWrapping && (w = a.getClientRects()).length > 1 ? f = w[r == "right" ? w.length - 1 : 0] : f = a.getBoundingClientRect();
      }
      if (x && A < 9 && !l && (!f || !f.left && !f.right)) {
        var M = a.parentNode.getClientRects()[0];
        M ? f = { left: M.left, right: M.left + Rr(e.display), top: M.top, bottom: M.bottom } : f = Dl;
      }
      for (var L = f.top - t.rect.top, W = f.bottom - t.rect.top, K = (L + W) / 2, ee = t.view.measure.heights, ie = 0; ie < ee.length - 1 && !(K < ee[ie]); ie++)
        ;
      var se = ie ? ee[ie - 1] : 0, ne = ee[ie], he = {
        left: (u == "right" ? f.right : f.left) - t.rect.left,
        right: (u == "left" ? f.left : f.right) - t.rect.left,
        top: se,
        bottom: ne
      };
      return !f.left && !f.right && (he.bogus = !0), e.options.singleCursorHeightPerLine || (he.rtop = L, he.rbottom = W), he;
    }
    function $u(e, t) {
      if (!window.screen || screen.logicalXDPI == null || screen.logicalXDPI == screen.deviceXDPI || !hu(e))
        return t;
      var i = screen.logicalXDPI / screen.deviceXDPI, r = screen.logicalYDPI / screen.deviceYDPI;
      return {
        left: t.left * i,
        right: t.right * i,
        top: t.top * r,
        bottom: t.bottom * r
      };
    }
    function Cl(e) {
      if (e.measure && (e.measure.cache = {}, e.measure.heights = null, e.rest))
        for (var t = 0; t < e.rest.length; t++)
          e.measure.caches[t] = {};
    }
    function wl(e) {
      e.display.externalMeasure = null, ke(e.display.lineMeasure);
      for (var t = 0; t < e.display.view.length; t++)
        Cl(e.display.view[t]);
    }
    function oi(e) {
      wl(e), e.display.cachedCharWidth = e.display.cachedTextHeight = e.display.cachedPaddingH = null, e.options.lineWrapping || (e.display.maxLineChanged = !0), e.display.lineNumChars = null;
    }
    function kl(e) {
      return N && q ? -(e.body.getBoundingClientRect().left - parseInt(getComputedStyle(e.body).marginLeft)) : e.defaultView.pageXOffset || (e.documentElement || e.body).scrollLeft;
    }
    function Sl(e) {
      return N && q ? -(e.body.getBoundingClientRect().top - parseInt(getComputedStyle(e.body).marginTop)) : e.defaultView.pageYOffset || (e.documentElement || e.body).scrollTop;
    }
    function ea(e) {
      var t = Ot(e), i = t.widgets, r = 0;
      if (i)
        for (var n = 0; n < i.length; ++n)
          i[n].above && (r += li(i[n]));
      return r;
    }
    function Ui(e, t, i, r, n) {
      if (!n) {
        var a = ea(t);
        i.top += a, i.bottom += a;
      }
      if (r == "line")
        return i;
      r || (r = "local");
      var l = Qt(t);
      if (r == "local" ? l += _i(e.display) : l -= e.display.viewOffset, r == "page" || r == "window") {
        var o = e.display.lineSpace.getBoundingClientRect();
        l += o.top + (r == "window" ? 0 : Sl(d(e)));
        var u = o.left + (r == "window" ? 0 : kl(d(e)));
        i.left += u, i.right += u;
      }
      return i.top += l, i.bottom += l, i;
    }
    function Fl(e, t, i) {
      if (i == "div")
        return t;
      var r = t.left, n = t.top;
      if (i == "page")
        r -= kl(d(e)), n -= Sl(d(e));
      else if (i == "local" || !i) {
        var a = e.display.sizer.getBoundingClientRect();
        r += a.left, n += a.top;
      }
      var l = e.display.lineSpace.getBoundingClientRect();
      return { left: r - l.left, top: n - l.top };
    }
    function qi(e, t, i, r, n) {
      return r || (r = me(e.doc, t.line)), Ui(e, r, yl(e, r, t.ch, n), i);
    }
    function Ht(e, t, i, r, n, a) {
      r = r || me(e.doc, t.line), n || (n = Or(e, r));
      function l(W, K) {
        var ee = jt(e, n, W, K ? "right" : "left", a);
        return K ? ee.left = ee.right : ee.right = ee.left, Ui(e, r, ee, i);
      }
      var o = ue(r, e.doc.direction), u = t.ch, f = t.sticky;
      if (u >= r.text.length ? (u = r.text.length, f = "before") : u <= 0 && (u = 0, f = "after"), !o)
        return l(f == "before" ? u - 1 : u, f == "before");
      function D(W, K, ee) {
        var ie = o[K], se = ie.level == 1;
        return l(ee ? W - 1 : W, se != ee);
      }
      var w = ve(o, u, f), M = fe, L = D(u, w, f == "before");
      return M != null && (L.other = D(u, M, f != "before")), L;
    }
    function Al(e, t) {
      var i = 0;
      t = Ae(e.doc, t), e.options.lineWrapping || (i = Rr(e.display) * t.ch);
      var r = me(e.doc, t.line), n = Qt(r) + _i(e.display);
      return { left: i, right: i, top: n, bottom: n + r.height };
    }
    function ta(e, t, i, r, n) {
      var a = $(e, t, i);
      return a.xRel = n, r && (a.outside = r), a;
    }
    function ra(e, t, i) {
      var r = e.doc;
      if (i += e.display.viewOffset, i < 0)
        return ta(r.first, 0, null, -1, -1);
      var n = vr(r, i), a = r.first + r.size - 1;
      if (n > a)
        return ta(r.first + r.size - 1, me(r, a).text.length, null, 1, 1);
      t < 0 && (t = 0);
      for (var l = me(r, n); ; ) {
        var o = Ju(e, l, n, t, i), u = Fu(l, o.ch + (o.xRel > 0 || o.outside > 0 ? 1 : 0));
        if (!u)
          return o;
        var f = u.find(1);
        if (f.line == n)
          return f;
        l = me(r, n = f.line);
      }
    }
    function El(e, t, i, r) {
      r -= ea(t);
      var n = t.text.length, a = re(function(l) {
        return jt(e, i, l - 1).bottom <= r;
      }, n, 0);
      return n = re(function(l) {
        return jt(e, i, l).top > r;
      }, a, n), { begin: a, end: n };
    }
    function Ll(e, t, i, r) {
      i || (i = Or(e, t));
      var n = Ui(e, t, jt(e, i, r), "line").top;
      return El(e, t, i, n);
    }
    function ia(e, t, i, r) {
      return e.bottom <= i ? !1 : e.top > i ? !0 : (r ? e.left : e.right) > t;
    }
    function Ju(e, t, i, r, n) {
      n -= Qt(t);
      var a = Or(e, t), l = ea(t), o = 0, u = t.text.length, f = !0, D = ue(t, e.doc.direction);
      if (D) {
        var w = (e.options.lineWrapping ? es : Vu)(e, t, i, a, D, r, n);
        f = w.level != 1, o = f ? w.from : w.to - 1, u = f ? w.to : w.from - 1;
      }
      var M = null, L = null, W = re(function(be) {
        var xe = jt(e, a, be);
        return xe.top += l, xe.bottom += l, ia(xe, r, n, !1) ? (xe.top <= n && xe.left <= r && (M = be, L = xe), !0) : !1;
      }, o, u), K, ee, ie = !1;
      if (L) {
        var se = r - L.left < L.right - r, ne = se == f;
        W = M + (ne ? 0 : 1), ee = ne ? "after" : "before", K = se ? L.left : L.right;
      } else {
        !f && (W == u || W == o) && W++, ee = W == 0 ? "after" : W == t.text.length ? "before" : jt(e, a, W - (f ? 1 : 0)).bottom + l <= n == f ? "after" : "before";
        var he = Ht(e, $(i, W, ee), "line", t, a);
        K = he.left, ie = n < he.top ? -1 : n >= he.bottom ? 1 : 0;
      }
      return W = E(t.text, W, 1), ta(i, W, ee, ie, r - K);
    }
    function Vu(e, t, i, r, n, a, l) {
      var o = re(function(w) {
        var M = n[w], L = M.level != 1;
        return ia(Ht(
          e,
          $(i, L ? M.to : M.from, L ? "before" : "after"),
          "line",
          t,
          r
        ), a, l, !0);
      }, 0, n.length - 1), u = n[o];
      if (o > 0) {
        var f = u.level != 1, D = Ht(
          e,
          $(i, f ? u.from : u.to, f ? "after" : "before"),
          "line",
          t,
          r
        );
        ia(D, a, l, !0) && D.top > l && (u = n[o - 1]);
      }
      return u;
    }
    function es(e, t, i, r, n, a, l) {
      var o = El(e, t, r, l), u = o.begin, f = o.end;
      /\s/.test(t.text.charAt(f - 1)) && f--;
      for (var D = null, w = null, M = 0; M < n.length; M++) {
        var L = n[M];
        if (!(L.from >= f || L.to <= u)) {
          var W = L.level != 1, K = jt(e, r, W ? Math.min(f, L.to) - 1 : Math.max(u, L.from)).right, ee = K < a ? a - K + 1e9 : K - a;
          (!D || w > ee) && (D = L, w = ee);
        }
      }
      return D || (D = n[n.length - 1]), D.from < u && (D = { from: u, to: D.to, level: D.level }), D.to > f && (D = { from: D.from, to: f, level: D.level }), D;
    }
    var xr;
    function Hr(e) {
      if (e.cachedTextHeight != null)
        return e.cachedTextHeight;
      if (xr == null) {
        xr = T("pre", null, "CodeMirror-line-like");
        for (var t = 0; t < 49; ++t)
          xr.appendChild(document.createTextNode("x")), xr.appendChild(T("br"));
        xr.appendChild(document.createTextNode("x"));
      }
      De(e.measure, xr);
      var i = xr.offsetHeight / 50;
      return i > 3 && (e.cachedTextHeight = i), ke(e.measure), i || 1;
    }
    function Rr(e) {
      if (e.cachedCharWidth != null)
        return e.cachedCharWidth;
      var t = T("span", "xxxxxxxxxx"), i = T("pre", [t], "CodeMirror-line-like");
      De(e.measure, i);
      var r = t.getBoundingClientRect(), n = (r.right - r.left) / 10;
      return n > 2 && (e.cachedCharWidth = n), n || 10;
    }
    function na(e) {
      for (var t = e.display, i = {}, r = {}, n = t.gutters.clientLeft, a = t.gutters.firstChild, l = 0; a; a = a.nextSibling, ++l) {
        var o = e.display.gutterSpecs[l].className;
        i[o] = a.offsetLeft + a.clientLeft + n, r[o] = a.clientWidth;
      }
      return {
        fixedPos: aa(t),
        gutterTotalWidth: t.gutters.offsetWidth,
        gutterLeft: i,
        gutterWidth: r,
        wrapperWidth: t.wrapper.clientWidth
      };
    }
    function aa(e) {
      return e.scroller.getBoundingClientRect().left - e.sizer.getBoundingClientRect().left;
    }
    function Tl(e) {
      var t = Hr(e.display), i = e.options.lineWrapping, r = i && Math.max(5, e.display.scroller.clientWidth / Rr(e.display) - 3);
      return function(n) {
        if (ir(e.doc, n))
          return 0;
        var a = 0;
        if (n.widgets)
          for (var l = 0; l < n.widgets.length; l++)
            n.widgets[l].height && (a += n.widgets[l].height);
        return i ? a + (Math.ceil(n.text.length / r) || 1) * t : a + t;
      };
    }
    function la(e) {
      var t = e.doc, i = Tl(e);
      t.iter(function(r) {
        var n = i(r);
        n != r.height && Ut(r, n);
      });
    }
    function yr(e, t, i, r) {
      var n = e.display;
      if (!i && ei(t).getAttribute("cm-not-content") == "true")
        return null;
      var a, l, o = n.lineSpace.getBoundingClientRect();
      try {
        a = t.clientX - o.left, l = t.clientY - o.top;
      } catch {
        return null;
      }
      var u = ra(e, a, l), f;
      if (r && u.xRel > 0 && (f = me(e.doc, u.line).text).length == u.ch) {
        var D = Xe(f, f.length, e.options.tabSize) - f.length;
        u = $(u.line, Math.max(0, Math.round((a - ml(e.display).left) / Rr(e.display)) - D));
      }
      return u;
    }
    function Dr(e, t) {
      if (t >= e.display.viewTo || (t -= e.display.viewFrom, t < 0))
        return null;
      for (var i = e.display.view, r = 0; r < i.length; r++)
        if (t -= i[r].size, t < 0)
          return r;
    }
    function Dt(e, t, i, r) {
      t == null && (t = e.doc.first), i == null && (i = e.doc.first + e.doc.size), r || (r = 0);
      var n = e.display;
      if (r && i < n.viewTo && (n.updateLineNumbers == null || n.updateLineNumbers > t) && (n.updateLineNumbers = t), e.curOp.viewChanged = !0, t >= n.viewTo)
        Zt && Xn(e.doc, t) < n.viewTo && ar(e);
      else if (i <= n.viewFrom)
        Zt && ol(e.doc, i + r) > n.viewFrom ? ar(e) : (n.viewFrom += r, n.viewTo += r);
      else if (t <= n.viewFrom && i >= n.viewTo)
        ar(e);
      else if (t <= n.viewFrom) {
        var a = Gi(e, i, i + r, 1);
        a ? (n.view = n.view.slice(a.index), n.viewFrom = a.lineN, n.viewTo += r) : ar(e);
      } else if (i >= n.viewTo) {
        var l = Gi(e, t, t, -1);
        l ? (n.view = n.view.slice(0, l.index), n.viewTo = l.lineN) : ar(e);
      } else {
        var o = Gi(e, t, t, -1), u = Gi(e, i, i + r, 1);
        o && u ? (n.view = n.view.slice(0, o.index).concat(Wi(e, o.lineN, u.lineN)).concat(n.view.slice(u.index)), n.viewTo += r) : ar(e);
      }
      var f = n.externalMeasured;
      f && (i < f.lineN ? f.lineN += r : t < f.lineN + f.size && (n.externalMeasured = null));
    }
    function nr(e, t, i) {
      e.curOp.viewChanged = !0;
      var r = e.display, n = e.display.externalMeasured;
      if (n && t >= n.lineN && t < n.lineN + n.size && (r.externalMeasured = null), !(t < r.viewFrom || t >= r.viewTo)) {
        var a = r.view[Dr(e, t)];
        if (a.node != null) {
          var l = a.changes || (a.changes = []);
          Ie(l, i) == -1 && l.push(i);
        }
      }
    }
    function ar(e) {
      e.display.viewFrom = e.display.viewTo = e.doc.first, e.display.view = [], e.display.viewOffset = 0;
    }
    function Gi(e, t, i, r) {
      var n = Dr(e, t), a, l = e.display.view;
      if (!Zt || i == e.doc.first + e.doc.size)
        return { index: n, lineN: i };
      for (var o = e.display.viewFrom, u = 0; u < n; u++)
        o += l[u].size;
      if (o != t) {
        if (r > 0) {
          if (n == l.length - 1)
            return null;
          a = o + l[n].size - t, n++;
        } else
          a = o - t;
        t += a, i += a;
      }
      for (; Xn(e.doc, i) != i; ) {
        if (n == (r < 0 ? 0 : l.length - 1))
          return null;
        i += r * l[n - (r < 0 ? 1 : 0)].size, n += r;
      }
      return { index: n, lineN: i };
    }
    function ts(e, t, i) {
      var r = e.display, n = r.view;
      n.length == 0 || t >= r.viewTo || i <= r.viewFrom ? (r.view = Wi(e, t, i), r.viewFrom = t) : (r.viewFrom > t ? r.view = Wi(e, t, r.viewFrom).concat(r.view) : r.viewFrom < t && (r.view = r.view.slice(Dr(e, t))), r.viewFrom = t, r.viewTo < i ? r.view = r.view.concat(Wi(e, r.viewTo, i)) : r.viewTo > i && (r.view = r.view.slice(0, Dr(e, i)))), r.viewTo = i;
    }
    function Bl(e) {
      for (var t = e.display.view, i = 0, r = 0; r < t.length; r++) {
        var n = t[r];
        !n.hidden && (!n.node || n.changes) && ++i;
      }
      return i;
    }
    function ui(e) {
      e.display.input.showSelection(e.display.input.prepareSelection());
    }
    function Ml(e, t) {
      t === void 0 && (t = !0);
      var i = e.doc, r = {}, n = r.cursors = document.createDocumentFragment(), a = r.selection = document.createDocumentFragment(), l = e.options.$customCursor;
      l && (t = !0);
      for (var o = 0; o < i.sel.ranges.length; o++)
        if (!(!t && o == i.sel.primIndex)) {
          var u = i.sel.ranges[o];
          if (!(u.from().line >= e.display.viewTo || u.to().line < e.display.viewFrom)) {
            var f = u.empty();
            if (l) {
              var D = l(e, u);
              D && oa(e, D, n);
            } else
              (f || e.options.showCursorWhenSelecting) && oa(e, u.head, n);
            f || rs(e, u, a);
          }
        }
      return r;
    }
    function oa(e, t, i) {
      var r = Ht(e, t, "div", null, null, !e.options.singleCursorHeightPerLine), n = i.appendChild(T("div", " ", "CodeMirror-cursor"));
      if (n.style.left = r.left + "px", n.style.top = r.top + "px", n.style.height = Math.max(0, r.bottom - r.top) * e.options.cursorHeight + "px", /\bcm-fat-cursor\b/.test(e.getWrapperElement().className)) {
        var a = qi(e, t, "div", null, null), l = a.right - a.left;
        n.style.width = (l > 0 ? l : e.defaultCharWidth()) + "px";
      }
      if (r.other) {
        var o = i.appendChild(T("div", " ", "CodeMirror-cursor CodeMirror-secondarycursor"));
        o.style.display = "", o.style.left = r.other.left + "px", o.style.top = r.other.top + "px", o.style.height = (r.other.bottom - r.other.top) * 0.85 + "px";
      }
    }
    function ji(e, t) {
      return e.top - t.top || e.left - t.left;
    }
    function rs(e, t, i) {
      var r = e.display, n = e.doc, a = document.createDocumentFragment(), l = ml(e.display), o = l.left, u = Math.max(r.sizerWidth, mr(e) - r.sizer.offsetLeft) - l.right, f = n.direction == "ltr";
      function D(ne, he, be, xe) {
        he < 0 && (he = 0), he = Math.round(he), xe = Math.round(xe), a.appendChild(T("div", null, "CodeMirror-selected", "position: absolute; left: " + ne + `px;
                             top: ` + he + "px; width: " + (be ?? u - ne) + `px;
                             height: ` + (xe - he) + "px"));
      }
      function w(ne, he, be) {
        var xe = me(n, ne), Te = xe.text.length, Ue, ft;
        function Ze(rt, wt) {
          return qi(e, $(ne, rt), "div", xe, wt);
        }
        function Ft(rt, wt, gt) {
          var lt = Ll(e, xe, null, rt), it = wt == "ltr" == (gt == "after") ? "left" : "right", Qe = gt == "after" ? lt.begin : lt.end - (/\s/.test(xe.text.charAt(lt.end - 1)) ? 2 : 1);
          return Ze(Qe, it)[it];
        }
        var Ct = ue(xe, n.direction);
        return de(Ct, he || 0, be ?? Te, function(rt, wt, gt, lt) {
          var it = gt == "ltr", Qe = Ze(rt, it ? "left" : "right"), kt = Ze(wt - 1, it ? "right" : "left"), Qr = he == null && rt == 0, cr = be == null && wt == Te, mt = lt == 0, Kt = !Ct || lt == Ct.length - 1;
          if (kt.top - Qe.top <= 3) {
            var ct = (f ? Qr : cr) && mt, Ia = (f ? cr : Qr) && Kt, er = ct ? o : (it ? Qe : kt).left, Sr = Ia ? u : (it ? kt : Qe).right;
            D(er, Qe.top, Sr - er, Qe.bottom);
          } else {
            var Fr, yt, $r, Oa;
            it ? (Fr = f && Qr && mt ? o : Qe.left, yt = f ? u : Ft(rt, gt, "before"), $r = f ? o : Ft(wt, gt, "after"), Oa = f && cr && Kt ? u : kt.right) : (Fr = f ? Ft(rt, gt, "before") : o, yt = !f && Qr && mt ? u : Qe.right, $r = !f && cr && Kt ? o : kt.left, Oa = f ? Ft(wt, gt, "after") : u), D(Fr, Qe.top, yt - Fr, Qe.bottom), Qe.bottom < kt.top && D(o, Qe.bottom, null, kt.top), D($r, kt.top, Oa - $r, kt.bottom);
          }
          (!Ue || ji(Qe, Ue) < 0) && (Ue = Qe), ji(kt, Ue) < 0 && (Ue = kt), (!ft || ji(Qe, ft) < 0) && (ft = Qe), ji(kt, ft) < 0 && (ft = kt);
        }), { start: Ue, end: ft };
      }
      var M = t.from(), L = t.to();
      if (M.line == L.line)
        w(M.line, M.ch, L.ch);
      else {
        var W = me(n, M.line), K = me(n, L.line), ee = Ot(W) == Ot(K), ie = w(M.line, M.ch, ee ? W.text.length + 1 : null).end, se = w(L.line, ee ? 0 : null, L.ch).start;
        ee && (ie.top < se.top - 2 ? (D(ie.right, ie.top, null, ie.bottom), D(o, se.top, se.left, se.bottom)) : D(ie.right, ie.top, se.left - ie.right, ie.bottom)), ie.bottom < se.top && D(o, ie.bottom, null, se.top);
      }
      i.appendChild(a);
    }
    function ua(e) {
      if (e.state.focused) {
        var t = e.display;
        clearInterval(t.blinker);
        var i = !0;
        t.cursorDiv.style.visibility = "", e.options.cursorBlinkRate > 0 ? t.blinker = setInterval(function() {
          e.hasFocus() || zr(e), t.cursorDiv.style.visibility = (i = !i) ? "" : "hidden";
        }, e.options.cursorBlinkRate) : e.options.cursorBlinkRate < 0 && (t.cursorDiv.style.visibility = "hidden");
      }
    }
    function Nl(e) {
      e.hasFocus() || (e.display.input.focus(), e.state.focused || fa(e));
    }
    function sa(e) {
      e.state.delayingBlurEvent = !0, setTimeout(function() {
        e.state.delayingBlurEvent && (e.state.delayingBlurEvent = !1, e.state.focused && zr(e));
      }, 100);
    }
    function fa(e, t) {
      e.state.delayingBlurEvent && !e.state.draggingText && (e.state.delayingBlurEvent = !1), e.options.readOnly != "nocursor" && (e.state.focused || (He(e, "focus", e, t), e.state.focused = !0, et(e.display.wrapper, "CodeMirror-focused"), !e.curOp && e.display.selForContextMenu != e.doc.sel && (e.display.input.reset(), z && setTimeout(function() {
        return e.display.input.reset(!0);
      }, 20)), e.display.input.receivedFocus()), ua(e));
    }
    function zr(e, t) {
      e.state.delayingBlurEvent || (e.state.focused && (He(e, "blur", e, t), e.state.focused = !1, Se(e.display.wrapper, "CodeMirror-focused")), clearInterval(e.display.blinker), setTimeout(function() {
        e.state.focused || (e.display.shift = !1);
      }, 150));
    }
    function Ki(e) {
      for (var t = e.display, i = t.lineDiv.offsetTop, r = Math.max(0, t.scroller.getBoundingClientRect().top), n = t.lineDiv.getBoundingClientRect().top, a = 0, l = 0; l < t.view.length; l++) {
        var o = t.view[l], u = e.options.lineWrapping, f = void 0, D = 0;
        if (!o.hidden) {
          if (n += o.line.height, x && A < 8) {
            var w = o.node.offsetTop + o.node.offsetHeight;
            f = w - i, i = w;
          } else {
            var M = o.node.getBoundingClientRect();
            f = M.bottom - M.top, !u && o.text.firstChild && (D = o.text.firstChild.getBoundingClientRect().right - M.left - 1);
          }
          var L = o.line.height - f;
          if ((L > 5e-3 || L < -5e-3) && (n < r && (a -= L), Ut(o.line, f), Il(o.line), o.rest))
            for (var W = 0; W < o.rest.length; W++)
              Il(o.rest[W]);
          if (D > e.display.sizerWidth) {
            var K = Math.ceil(D / Rr(e.display));
            K > e.display.maxLineLength && (e.display.maxLineLength = K, e.display.maxLine = o.line, e.display.maxLineChanged = !0);
          }
        }
      }
      Math.abs(a) > 2 && (t.scroller.scrollTop += a);
    }
    function Il(e) {
      if (e.widgets)
        for (var t = 0; t < e.widgets.length; ++t) {
          var i = e.widgets[t], r = i.node.parentNode;
          r && (i.height = r.offsetHeight);
        }
    }
    function Xi(e, t, i) {
      var r = i && i.top != null ? Math.max(0, i.top) : e.scroller.scrollTop;
      r = Math.floor(r - _i(e));
      var n = i && i.bottom != null ? i.bottom : r + e.wrapper.clientHeight, a = vr(t, r), l = vr(t, n);
      if (i && i.ensure) {
        var o = i.ensure.from.line, u = i.ensure.to.line;
        o < a ? (a = o, l = vr(t, Qt(me(t, o)) + e.wrapper.clientHeight)) : Math.min(u, t.lastLine()) >= l && (a = vr(t, Qt(me(t, u)) - e.wrapper.clientHeight), l = u);
      }
      return { from: a, to: Math.max(l, a + 1) };
    }
    function is(e, t) {
      if (!Le(e, "scrollCursorIntoView")) {
        var i = e.display, r = i.sizer.getBoundingClientRect(), n = null, a = i.wrapper.ownerDocument;
        if (t.top + r.top < 0 ? n = !0 : t.bottom + r.top > (a.defaultView.innerHeight || a.documentElement.clientHeight) && (n = !1), n != null && !Q) {
          var l = T("div", "​", null, `position: absolute;
                         top: ` + (t.top - i.viewOffset - _i(e.display)) + `px;
                         height: ` + (t.bottom - t.top + Gt(e) + i.barHeight) + `px;
                         left: ` + t.left + "px; width: " + Math.max(2, t.right - t.left) + "px;");
          e.display.lineSpace.appendChild(l), l.scrollIntoView(n), e.display.lineSpace.removeChild(l);
        }
      }
    }
    function ns(e, t, i, r) {
      r == null && (r = 0);
      var n;
      !e.options.lineWrapping && t == i && (i = t.sticky == "before" ? $(t.line, t.ch + 1, "before") : t, t = t.ch ? $(t.line, t.sticky == "before" ? t.ch - 1 : t.ch, "after") : t);
      for (var a = 0; a < 5; a++) {
        var l = !1, o = Ht(e, t), u = !i || i == t ? o : Ht(e, i);
        n = {
          left: Math.min(o.left, u.left),
          top: Math.min(o.top, u.top) - r,
          right: Math.max(o.left, u.left),
          bottom: Math.max(o.bottom, u.bottom) + r
        };
        var f = ca(e, n), D = e.doc.scrollTop, w = e.doc.scrollLeft;
        if (f.scrollTop != null && (fi(e, f.scrollTop), Math.abs(e.doc.scrollTop - D) > 1 && (l = !0)), f.scrollLeft != null && (br(e, f.scrollLeft), Math.abs(e.doc.scrollLeft - w) > 1 && (l = !0)), !l)
          break;
      }
      return n;
    }
    function as(e, t) {
      var i = ca(e, t);
      i.scrollTop != null && fi(e, i.scrollTop), i.scrollLeft != null && br(e, i.scrollLeft);
    }
    function ca(e, t) {
      var i = e.display, r = Hr(e.display);
      t.top < 0 && (t.top = 0);
      var n = e.curOp && e.curOp.scrollTop != null ? e.curOp.scrollTop : i.scroller.scrollTop, a = Jn(e), l = {};
      t.bottom - t.top > a && (t.bottom = t.top + a);
      var o = e.doc.height + $n(i), u = t.top < r, f = t.bottom > o - r;
      if (t.top < n)
        l.scrollTop = u ? 0 : t.top;
      else if (t.bottom > n + a) {
        var D = Math.min(t.top, (f ? o : t.bottom) - a);
        D != n && (l.scrollTop = D);
      }
      var w = e.options.fixedGutter ? 0 : i.gutters.offsetWidth, M = e.curOp && e.curOp.scrollLeft != null ? e.curOp.scrollLeft : i.scroller.scrollLeft - w, L = mr(e) - i.gutters.offsetWidth, W = t.right - t.left > L;
      return W && (t.right = t.left + L), t.left < 10 ? l.scrollLeft = 0 : t.left < M ? l.scrollLeft = Math.max(0, t.left + w - (W ? 0 : 10)) : t.right > L + M - 3 && (l.scrollLeft = t.right + (W ? 0 : 10) - L), l;
    }
    function ha(e, t) {
      t != null && (Yi(e), e.curOp.scrollTop = (e.curOp.scrollTop == null ? e.doc.scrollTop : e.curOp.scrollTop) + t);
    }
    function Pr(e) {
      Yi(e);
      var t = e.getCursor();
      e.curOp.scrollToPos = { from: t, to: t, margin: e.options.cursorScrollMargin };
    }
    function si(e, t, i) {
      (t != null || i != null) && Yi(e), t != null && (e.curOp.scrollLeft = t), i != null && (e.curOp.scrollTop = i);
    }
    function ls(e, t) {
      Yi(e), e.curOp.scrollToPos = t;
    }
    function Yi(e) {
      var t = e.curOp.scrollToPos;
      if (t) {
        e.curOp.scrollToPos = null;
        var i = Al(e, t.from), r = Al(e, t.to);
        Ol(e, i, r, t.margin);
      }
    }
    function Ol(e, t, i, r) {
      var n = ca(e, {
        left: Math.min(t.left, i.left),
        top: Math.min(t.top, i.top) - r,
        right: Math.max(t.right, i.right),
        bottom: Math.max(t.bottom, i.bottom) + r
      });
      si(e, n.scrollLeft, n.scrollTop);
    }
    function fi(e, t) {
      Math.abs(e.doc.scrollTop - t) < 2 || (m || pa(e, { top: t }), Hl(e, t, !0), m && pa(e), di(e, 100));
    }
    function Hl(e, t, i) {
      t = Math.max(0, Math.min(e.display.scroller.scrollHeight - e.display.scroller.clientHeight, t)), !(e.display.scroller.scrollTop == t && !i) && (e.doc.scrollTop = t, e.display.scrollbars.setScrollTop(t), e.display.scroller.scrollTop != t && (e.display.scroller.scrollTop = t));
    }
    function br(e, t, i, r) {
      t = Math.max(0, Math.min(t, e.display.scroller.scrollWidth - e.display.scroller.clientWidth)), !((i ? t == e.doc.scrollLeft : Math.abs(e.doc.scrollLeft - t) < 2) && !r) && (e.doc.scrollLeft = t, _l(e), e.display.scroller.scrollLeft != t && (e.display.scroller.scrollLeft = t), e.display.scrollbars.setScrollLeft(t));
    }
    function ci(e) {
      var t = e.display, i = t.gutters.offsetWidth, r = Math.round(e.doc.height + $n(e.display));
      return {
        clientHeight: t.scroller.clientHeight,
        viewHeight: t.wrapper.clientHeight,
        scrollWidth: t.scroller.scrollWidth,
        clientWidth: t.scroller.clientWidth,
        viewWidth: t.wrapper.clientWidth,
        barLeft: e.options.fixedGutter ? i : 0,
        docHeight: r,
        scrollHeight: r + Gt(e) + t.barHeight,
        nativeBarWidth: t.nativeBarWidth,
        gutterWidth: i
      };
    }
    var Cr = function(e, t, i) {
      this.cm = i;
      var r = this.vert = T("div", [T("div", null, null, "min-width: 1px")], "CodeMirror-vscrollbar"), n = this.horiz = T("div", [T("div", null, null, "height: 100%; min-height: 1px")], "CodeMirror-hscrollbar");
      r.tabIndex = n.tabIndex = -1, e(r), e(n), U(r, "scroll", function() {
        r.clientHeight && t(r.scrollTop, "vertical");
      }), U(n, "scroll", function() {
        n.clientWidth && t(n.scrollLeft, "horizontal");
      }), this.checkedZeroWidth = !1, x && A < 8 && (this.horiz.style.minHeight = this.vert.style.minWidth = "18px");
    };
    Cr.prototype.update = function(e) {
      var t = e.scrollWidth > e.clientWidth + 1, i = e.scrollHeight > e.clientHeight + 1, r = e.nativeBarWidth;
      if (i) {
        this.vert.style.display = "block", this.vert.style.bottom = t ? r + "px" : "0";
        var n = e.viewHeight - (t ? r : 0);
        this.vert.firstChild.style.height = Math.max(0, e.scrollHeight - e.clientHeight + n) + "px";
      } else
        this.vert.scrollTop = 0, this.vert.style.display = "", this.vert.firstChild.style.height = "0";
      if (t) {
        this.horiz.style.display = "block", this.horiz.style.right = i ? r + "px" : "0", this.horiz.style.left = e.barLeft + "px";
        var a = e.viewWidth - e.barLeft - (i ? r : 0);
        this.horiz.firstChild.style.width = Math.max(0, e.scrollWidth - e.clientWidth + a) + "px";
      } else
        this.horiz.style.display = "", this.horiz.firstChild.style.width = "0";
      return !this.checkedZeroWidth && e.clientHeight > 0 && (r == 0 && this.zeroWidthHack(), this.checkedZeroWidth = !0), { right: i ? r : 0, bottom: t ? r : 0 };
    }, Cr.prototype.setScrollLeft = function(e) {
      this.horiz.scrollLeft != e && (this.horiz.scrollLeft = e), this.disableHoriz && this.enableZeroWidthBar(this.horiz, this.disableHoriz, "horiz");
    }, Cr.prototype.setScrollTop = function(e) {
      this.vert.scrollTop != e && (this.vert.scrollTop = e), this.disableVert && this.enableZeroWidthBar(this.vert, this.disableVert, "vert");
    }, Cr.prototype.zeroWidthHack = function() {
      var e = _ && !J ? "12px" : "18px";
      this.horiz.style.height = this.vert.style.width = e, this.horiz.style.visibility = this.vert.style.visibility = "hidden", this.disableHoriz = new nt(), this.disableVert = new nt();
    }, Cr.prototype.enableZeroWidthBar = function(e, t, i) {
      e.style.visibility = "";
      function r() {
        var n = e.getBoundingClientRect(), a = i == "vert" ? document.elementFromPoint(n.right - 1, (n.top + n.bottom) / 2) : document.elementFromPoint((n.right + n.left) / 2, n.bottom - 1);
        a != e ? e.style.visibility = "hidden" : t.set(1e3, r);
      }
      t.set(1e3, r);
    }, Cr.prototype.clear = function() {
      var e = this.horiz.parentNode;
      e.removeChild(this.horiz), e.removeChild(this.vert);
    };
    var hi = function() {
    };
    hi.prototype.update = function() {
      return { bottom: 0, right: 0 };
    }, hi.prototype.setScrollLeft = function() {
    }, hi.prototype.setScrollTop = function() {
    }, hi.prototype.clear = function() {
    };
    function Wr(e, t) {
      t || (t = ci(e));
      var i = e.display.barWidth, r = e.display.barHeight;
      Rl(e, t);
      for (var n = 0; n < 4 && i != e.display.barWidth || r != e.display.barHeight; n++)
        i != e.display.barWidth && e.options.lineWrapping && Ki(e), Rl(e, ci(e)), i = e.display.barWidth, r = e.display.barHeight;
    }
    function Rl(e, t) {
      var i = e.display, r = i.scrollbars.update(t);
      i.sizer.style.paddingRight = (i.barWidth = r.right) + "px", i.sizer.style.paddingBottom = (i.barHeight = r.bottom) + "px", i.heightForcer.style.borderBottom = r.bottom + "px solid transparent", r.right && r.bottom ? (i.scrollbarFiller.style.display = "block", i.scrollbarFiller.style.height = r.bottom + "px", i.scrollbarFiller.style.width = r.right + "px") : i.scrollbarFiller.style.display = "", r.bottom && e.options.coverGutterNextToScrollbar && e.options.fixedGutter ? (i.gutterFiller.style.display = "block", i.gutterFiller.style.height = r.bottom + "px", i.gutterFiller.style.width = t.gutterWidth + "px") : i.gutterFiller.style.display = "";
    }
    var zl = { native: Cr, null: hi };
    function Pl(e) {
      e.display.scrollbars && (e.display.scrollbars.clear(), e.display.scrollbars.addClass && Se(e.display.wrapper, e.display.scrollbars.addClass)), e.display.scrollbars = new zl[e.options.scrollbarStyle](function(t) {
        e.display.wrapper.insertBefore(t, e.display.scrollbarFiller), U(t, "mousedown", function() {
          e.state.focused && setTimeout(function() {
            return e.display.input.focus();
          }, 0);
        }), t.setAttribute("cm-not-content", "true");
      }, function(t, i) {
        i == "horizontal" ? br(e, t) : fi(e, t);
      }, e), e.display.scrollbars.addClass && et(e.display.wrapper, e.display.scrollbars.addClass);
    }
    var os = 0;
    function wr(e) {
      e.curOp = {
        cm: e,
        viewChanged: !1,
        // Flag that indicates that lines might need to be redrawn
        startHeight: e.doc.height,
        // Used to detect need to update scrollbar
        forceUpdate: !1,
        // Used to force a redraw
        updateInput: 0,
        // Whether to reset the input textarea
        typing: !1,
        // Whether this reset should be careful to leave existing text (for compositing)
        changeObjs: null,
        // Accumulated changes, for firing change events
        cursorActivityHandlers: null,
        // Set of handlers to fire cursorActivity on
        cursorActivityCalled: 0,
        // Tracks which cursorActivity handlers have been called already
        selectionChanged: !1,
        // Whether the selection needs to be redrawn
        updateMaxLine: !1,
        // Set when the widest line needs to be determined anew
        scrollLeft: null,
        scrollTop: null,
        // Intermediate scroll position, not pushed to DOM yet
        scrollToPos: null,
        // Used to scroll to a specific position
        focus: !1,
        id: ++os,
        // Unique ID
        markArrays: null
        // Used by addMarkedSpan
      }, zu(e.curOp);
    }
    function kr(e) {
      var t = e.curOp;
      t && Wu(t, function(i) {
        for (var r = 0; r < i.ops.length; r++)
          i.ops[r].cm.curOp = null;
        us(i);
      });
    }
    function us(e) {
      for (var t = e.ops, i = 0; i < t.length; i++)
        ss(t[i]);
      for (var r = 0; r < t.length; r++)
        fs(t[r]);
      for (var n = 0; n < t.length; n++)
        cs(t[n]);
      for (var a = 0; a < t.length; a++)
        hs(t[a]);
      for (var l = 0; l < t.length; l++)
        ds(t[l]);
    }
    function ss(e) {
      var t = e.cm, i = t.display;
      gs(t), e.updateMaxLine && Zn(t), e.mustUpdate = e.viewChanged || e.forceUpdate || e.scrollTop != null || e.scrollToPos && (e.scrollToPos.from.line < i.viewFrom || e.scrollToPos.to.line >= i.viewTo) || i.maxLineChanged && t.options.lineWrapping, e.update = e.mustUpdate && new Zi(t, e.mustUpdate && { top: e.scrollTop, ensure: e.scrollToPos }, e.forceUpdate);
    }
    function fs(e) {
      e.updatedDisplay = e.mustUpdate && da(e.cm, e.update);
    }
    function cs(e) {
      var t = e.cm, i = t.display;
      e.updatedDisplay && Ki(t), e.barMeasure = ci(t), i.maxLineChanged && !t.options.lineWrapping && (e.adjustWidthTo = yl(t, i.maxLine, i.maxLine.text.length).left + 3, t.display.sizerWidth = e.adjustWidthTo, e.barMeasure.scrollWidth = Math.max(i.scroller.clientWidth, i.sizer.offsetLeft + e.adjustWidthTo + Gt(t) + t.display.barWidth), e.maxScrollLeft = Math.max(0, i.sizer.offsetLeft + e.adjustWidthTo - mr(t))), (e.updatedDisplay || e.selectionChanged) && (e.preparedSelection = i.input.prepareSelection());
    }
    function hs(e) {
      var t = e.cm;
      e.adjustWidthTo != null && (t.display.sizer.style.minWidth = e.adjustWidthTo + "px", e.maxScrollLeft < t.doc.scrollLeft && br(t, Math.min(t.display.scroller.scrollLeft, e.maxScrollLeft), !0), t.display.maxLineChanged = !1);
      var i = e.focus && e.focus == Me(j(t));
      e.preparedSelection && t.display.input.showSelection(e.preparedSelection, i), (e.updatedDisplay || e.startHeight != t.doc.height) && Wr(t, e.barMeasure), e.updatedDisplay && va(t, e.barMeasure), e.selectionChanged && ua(t), t.state.focused && e.updateInput && t.display.input.reset(e.typing), i && Nl(e.cm);
    }
    function ds(e) {
      var t = e.cm, i = t.display, r = t.doc;
      if (e.updatedDisplay && Wl(t, e.update), i.wheelStartX != null && (e.scrollTop != null || e.scrollLeft != null || e.scrollToPos) && (i.wheelStartX = i.wheelStartY = null), e.scrollTop != null && Hl(t, e.scrollTop, e.forceScroll), e.scrollLeft != null && br(t, e.scrollLeft, !0, !0), e.scrollToPos) {
        var n = ns(
          t,
          Ae(r, e.scrollToPos.from),
          Ae(r, e.scrollToPos.to),
          e.scrollToPos.margin
        );
        is(t, n);
      }
      var a = e.maybeHiddenMarkers, l = e.maybeUnhiddenMarkers;
      if (a)
        for (var o = 0; o < a.length; ++o)
          a[o].lines.length || He(a[o], "hide");
      if (l)
        for (var u = 0; u < l.length; ++u)
          l[u].lines.length && He(l[u], "unhide");
      i.wrapper.offsetHeight && (r.scrollTop = t.display.scroller.scrollTop), e.changeObjs && He(t, "changes", t, e.changeObjs), e.update && e.update.finish();
    }
    function St(e, t) {
      if (e.curOp)
        return t();
      wr(e);
      try {
        return t();
      } finally {
        kr(e);
      }
    }
    function ut(e, t) {
      return function() {
        if (e.curOp)
          return t.apply(e, arguments);
        wr(e);
        try {
          return t.apply(e, arguments);
        } finally {
          kr(e);
        }
      };
    }
    function xt(e) {
      return function() {
        if (this.curOp)
          return e.apply(this, arguments);
        wr(this);
        try {
          return e.apply(this, arguments);
        } finally {
          kr(this);
        }
      };
    }
    function st(e) {
      return function() {
        var t = this.cm;
        if (!t || t.curOp)
          return e.apply(this, arguments);
        wr(t);
        try {
          return e.apply(this, arguments);
        } finally {
          kr(t);
        }
      };
    }
    function di(e, t) {
      e.doc.highlightFrontier < e.display.viewTo && e.state.highlight.set(t, $e(ps, e));
    }
    function ps(e) {
      var t = e.doc;
      if (!(t.highlightFrontier >= e.display.viewTo)) {
        var i = +/* @__PURE__ */ new Date() + e.options.workTime, r = ri(e, t.highlightFrontier), n = [];
        t.iter(r.line, Math.min(t.first + t.size, e.display.viewTo + 500), function(a) {
          if (r.line >= e.display.viewFrom) {
            var l = a.styles, o = a.text.length > e.options.maxHighlightLength ? pr(t.mode, r.state) : null, u = Xa(e, a, r, !0);
            o && (r.state = o), a.styles = u.styles;
            var f = a.styleClasses, D = u.classes;
            D ? a.styleClasses = D : f && (a.styleClasses = null);
            for (var w = !l || l.length != a.styles.length || f != D && (!f || !D || f.bgClass != D.bgClass || f.textClass != D.textClass), M = 0; !w && M < l.length; ++M)
              w = l[M] != a.styles[M];
            w && n.push(r.line), a.stateAfter = r.save(), r.nextLine();
          } else
            a.text.length <= e.options.maxHighlightLength && qn(e, a.text, r), a.stateAfter = r.line % 5 == 0 ? r.save() : null, r.nextLine();
          if (+/* @__PURE__ */ new Date() > i)
            return di(e, e.options.workDelay), !0;
        }), t.highlightFrontier = r.line, t.modeFrontier = Math.max(t.modeFrontier, r.line), n.length && St(e, function() {
          for (var a = 0; a < n.length; a++)
            nr(e, n[a], "text");
        });
      }
    }
    var Zi = function(e, t, i) {
      var r = e.display;
      this.viewport = t, this.visible = Xi(r, e.doc, t), this.editorIsHidden = !r.wrapper.offsetWidth, this.wrapperHeight = r.wrapper.clientHeight, this.wrapperWidth = r.wrapper.clientWidth, this.oldDisplayWidth = mr(e), this.force = i, this.dims = na(e), this.events = [];
    };
    Zi.prototype.signal = function(e, t) {
      pt(e, t) && this.events.push(arguments);
    }, Zi.prototype.finish = function() {
      for (var e = 0; e < this.events.length; e++)
        He.apply(null, this.events[e]);
    };
    function gs(e) {
      var t = e.display;
      !t.scrollbarsClipped && t.scroller.offsetWidth && (t.nativeBarWidth = t.scroller.offsetWidth - t.scroller.clientWidth, t.heightForcer.style.height = Gt(e) + "px", t.sizer.style.marginBottom = -t.nativeBarWidth + "px", t.sizer.style.borderRightWidth = Gt(e) + "px", t.scrollbarsClipped = !0);
    }
    function vs(e) {
      if (e.hasFocus())
        return null;
      var t = Me(j(e));
      if (!t || !ge(e.display.lineDiv, t))
        return null;
      var i = { activeElt: t };
      if (window.getSelection) {
        var r = Ee(e).getSelection();
        r.anchorNode && r.extend && ge(e.display.lineDiv, r.anchorNode) && (i.anchorNode = r.anchorNode, i.anchorOffset = r.anchorOffset, i.focusNode = r.focusNode, i.focusOffset = r.focusOffset);
      }
      return i;
    }
    function ms(e) {
      if (!(!e || !e.activeElt || e.activeElt == Me(Ne(e.activeElt))) && (e.activeElt.focus(), !/^(INPUT|TEXTAREA)$/.test(e.activeElt.nodeName) && e.anchorNode && ge(document.body, e.anchorNode) && ge(document.body, e.focusNode))) {
        var t = e.activeElt.ownerDocument, i = t.defaultView.getSelection(), r = t.createRange();
        r.setEnd(e.anchorNode, e.anchorOffset), r.collapse(!1), i.removeAllRanges(), i.addRange(r), i.extend(e.focusNode, e.focusOffset);
      }
    }
    function da(e, t) {
      var i = e.display, r = e.doc;
      if (t.editorIsHidden)
        return ar(e), !1;
      if (!t.force && t.visible.from >= i.viewFrom && t.visible.to <= i.viewTo && (i.updateLineNumbers == null || i.updateLineNumbers >= i.viewTo) && i.renderedView == i.view && Bl(e) == 0)
        return !1;
      Ul(e) && (ar(e), t.dims = na(e));
      var n = r.first + r.size, a = Math.max(t.visible.from - e.options.viewportMargin, r.first), l = Math.min(n, t.visible.to + e.options.viewportMargin);
      i.viewFrom < a && a - i.viewFrom < 20 && (a = Math.max(r.first, i.viewFrom)), i.viewTo > l && i.viewTo - l < 20 && (l = Math.min(n, i.viewTo)), Zt && (a = Xn(e.doc, a), l = ol(e.doc, l));
      var o = a != i.viewFrom || l != i.viewTo || i.lastWrapHeight != t.wrapperHeight || i.lastWrapWidth != t.wrapperWidth;
      ts(e, a, l), i.viewOffset = Qt(me(e.doc, i.viewFrom)), e.display.mover.style.top = i.viewOffset + "px";
      var u = Bl(e);
      if (!o && u == 0 && !t.force && i.renderedView == i.view && (i.updateLineNumbers == null || i.updateLineNumbers >= i.viewTo))
        return !1;
      var f = vs(e);
      return u > 4 && (i.lineDiv.style.display = "none"), xs(e, i.updateLineNumbers, t.dims), u > 4 && (i.lineDiv.style.display = ""), i.renderedView = i.view, ms(f), ke(i.cursorDiv), ke(i.selectionDiv), i.gutters.style.height = i.sizer.style.minHeight = 0, o && (i.lastWrapHeight = t.wrapperHeight, i.lastWrapWidth = t.wrapperWidth, di(e, 400)), i.updateLineNumbers = null, !0;
    }
    function Wl(e, t) {
      for (var i = t.viewport, r = !0; ; r = !1) {
        if (!r || !e.options.lineWrapping || t.oldDisplayWidth == mr(e)) {
          if (i && i.top != null && (i = { top: Math.min(e.doc.height + $n(e.display) - Jn(e), i.top) }), t.visible = Xi(e.display, e.doc, i), t.visible.from >= e.display.viewFrom && t.visible.to <= e.display.viewTo)
            break;
        } else
          r && (t.visible = Xi(e.display, e.doc, i));
        if (!da(e, t))
          break;
        Ki(e);
        var n = ci(e);
        ui(e), Wr(e, n), va(e, n), t.force = !1;
      }
      t.signal(e, "update", e), (e.display.viewFrom != e.display.reportedViewFrom || e.display.viewTo != e.display.reportedViewTo) && (t.signal(e, "viewportChange", e, e.display.viewFrom, e.display.viewTo), e.display.reportedViewFrom = e.display.viewFrom, e.display.reportedViewTo = e.display.viewTo);
    }
    function pa(e, t) {
      var i = new Zi(e, t);
      if (da(e, i)) {
        Ki(e), Wl(e, i);
        var r = ci(e);
        ui(e), Wr(e, r), va(e, r), i.finish();
      }
    }
    function xs(e, t, i) {
      var r = e.display, n = e.options.lineNumbers, a = r.lineDiv, l = a.firstChild;
      function o(W) {
        var K = W.nextSibling;
        return z && _ && e.display.currentWheelTarget == W ? W.style.display = "none" : W.parentNode.removeChild(W), K;
      }
      for (var u = r.view, f = r.viewFrom, D = 0; D < u.length; D++) {
        var w = u[D];
        if (!w.hidden)
          if (!w.node || w.node.parentNode != a) {
            var M = ju(e, w, f, i);
            a.insertBefore(M, l);
          } else {
            for (; l != w.node; )
              l = o(l);
            var L = n && t != null && t <= f && w.lineNumber;
            w.changes && (Ie(w.changes, "gutter") > -1 && (L = !1), hl(e, w, f, i)), L && (ke(w.lineNumber), w.lineNumber.appendChild(document.createTextNode(Wn(e.options, f)))), l = w.node.nextSibling;
          }
        f += w.size;
      }
      for (; l; )
        l = o(l);
    }
    function ga(e) {
      var t = e.gutters.offsetWidth;
      e.sizer.style.marginLeft = t + "px", ot(e, "gutterChanged", e);
    }
    function va(e, t) {
      e.display.sizer.style.minHeight = t.docHeight + "px", e.display.heightForcer.style.top = t.docHeight + "px", e.display.gutters.style.height = t.docHeight + e.display.barHeight + Gt(e) + "px";
    }
    function _l(e) {
      var t = e.display, i = t.view;
      if (!(!t.alignWidgets && (!t.gutters.firstChild || !e.options.fixedGutter))) {
        for (var r = aa(t) - t.scroller.scrollLeft + e.doc.scrollLeft, n = t.gutters.offsetWidth, a = r + "px", l = 0; l < i.length; l++)
          if (!i[l].hidden) {
            e.options.fixedGutter && (i[l].gutter && (i[l].gutter.style.left = a), i[l].gutterBackground && (i[l].gutterBackground.style.left = a));
            var o = i[l].alignable;
            if (o)
              for (var u = 0; u < o.length; u++)
                o[u].style.left = a;
          }
        e.options.fixedGutter && (t.gutters.style.left = r + n + "px");
      }
    }
    function Ul(e) {
      if (!e.options.lineNumbers)
        return !1;
      var t = e.doc, i = Wn(e.options, t.first + t.size - 1), r = e.display;
      if (i.length != r.lineNumChars) {
        var n = r.measure.appendChild(T(
          "div",
          [T("div", i)],
          "CodeMirror-linenumber CodeMirror-gutter-elt"
        )), a = n.firstChild.offsetWidth, l = n.offsetWidth - a;
        return r.lineGutter.style.width = "", r.lineNumInnerWidth = Math.max(a, r.lineGutter.offsetWidth - l) + 1, r.lineNumWidth = r.lineNumInnerWidth + l, r.lineNumChars = r.lineNumInnerWidth ? i.length : -1, r.lineGutter.style.width = r.lineNumWidth + "px", ga(e.display), !0;
      }
      return !1;
    }
    function ma(e, t) {
      for (var i = [], r = !1, n = 0; n < e.length; n++) {
        var a = e[n], l = null;
        if (typeof a != "string" && (l = a.style, a = a.className), a == "CodeMirror-linenumbers")
          if (t)
            r = !0;
          else
            continue;
        i.push({ className: a, style: l });
      }
      return t && !r && i.push({ className: "CodeMirror-linenumbers", style: null }), i;
    }
    function ql(e) {
      var t = e.gutters, i = e.gutterSpecs;
      ke(t), e.lineGutter = null;
      for (var r = 0; r < i.length; ++r) {
        var n = i[r], a = n.className, l = n.style, o = t.appendChild(T("div", null, "CodeMirror-gutter " + a));
        l && (o.style.cssText = l), a == "CodeMirror-linenumbers" && (e.lineGutter = o, o.style.width = (e.lineNumWidth || 1) + "px");
      }
      t.style.display = i.length ? "" : "none", ga(e);
    }
    function pi(e) {
      ql(e.display), Dt(e), _l(e);
    }
    function ys(e, t, i, r) {
      var n = this;
      this.input = i, n.scrollbarFiller = T("div", null, "CodeMirror-scrollbar-filler"), n.scrollbarFiller.setAttribute("cm-not-content", "true"), n.gutterFiller = T("div", null, "CodeMirror-gutter-filler"), n.gutterFiller.setAttribute("cm-not-content", "true"), n.lineDiv = V("div", null, "CodeMirror-code"), n.selectionDiv = T("div", null, null, "position: relative; z-index: 1"), n.cursorDiv = T("div", null, "CodeMirror-cursors"), n.measure = T("div", null, "CodeMirror-measure"), n.lineMeasure = T("div", null, "CodeMirror-measure"), n.lineSpace = V(
        "div",
        [n.measure, n.lineMeasure, n.selectionDiv, n.cursorDiv, n.lineDiv],
        null,
        "position: relative; outline: none"
      );
      var a = V("div", [n.lineSpace], "CodeMirror-lines");
      n.mover = T("div", [a], null, "position: relative"), n.sizer = T("div", [n.mover], "CodeMirror-sizer"), n.sizerWidth = null, n.heightForcer = T("div", null, null, "position: absolute; height: " + _e + "px; width: 1px;"), n.gutters = T("div", null, "CodeMirror-gutters"), n.lineGutter = null, n.scroller = T("div", [n.sizer, n.heightForcer, n.gutters], "CodeMirror-scroll"), n.scroller.setAttribute("tabIndex", "-1"), n.wrapper = T("div", [n.scrollbarFiller, n.gutterFiller, n.scroller], "CodeMirror"), N && G === 105 && (n.wrapper.style.clipPath = "inset(0px)"), n.wrapper.setAttribute("translate", "no"), x && A < 8 && (n.gutters.style.zIndex = -1, n.scroller.style.paddingRight = 0), !z && !(m && R) && (n.scroller.draggable = !0), e && (e.appendChild ? e.appendChild(n.wrapper) : e(n.wrapper)), n.viewFrom = n.viewTo = t.first, n.reportedViewFrom = n.reportedViewTo = t.first, n.view = [], n.renderedView = null, n.externalMeasured = null, n.viewOffset = 0, n.lastWrapHeight = n.lastWrapWidth = 0, n.updateLineNumbers = null, n.nativeBarWidth = n.barHeight = n.barWidth = 0, n.scrollbarsClipped = !1, n.lineNumWidth = n.lineNumInnerWidth = n.lineNumChars = null, n.alignWidgets = !1, n.cachedCharWidth = n.cachedTextHeight = n.cachedPaddingH = null, n.maxLine = null, n.maxLineLength = 0, n.maxLineChanged = !1, n.wheelDX = n.wheelDY = n.wheelStartX = n.wheelStartY = null, n.shift = !1, n.selForContextMenu = null, n.activeTouch = null, n.gutterSpecs = ma(r.gutters, r.lineNumbers), ql(n), i.init(n);
    }
    var Qi = 0, Jt = null;
    x ? Jt = -0.53 : m ? Jt = 15 : N ? Jt = -0.7 : le && (Jt = -1 / 3);
    function Gl(e) {
      var t = e.wheelDeltaX, i = e.wheelDeltaY;
      return t == null && e.detail && e.axis == e.HORIZONTAL_AXIS && (t = e.detail), i == null && e.detail && e.axis == e.VERTICAL_AXIS ? i = e.detail : i == null && (i = e.wheelDelta), { x: t, y: i };
    }
    function Ds(e) {
      var t = Gl(e);
      return t.x *= Jt, t.y *= Jt, t;
    }
    function jl(e, t) {
      N && G == 102 && (e.display.chromeScrollHack == null ? e.display.sizer.style.pointerEvents = "none" : clearTimeout(e.display.chromeScrollHack), e.display.chromeScrollHack = setTimeout(function() {
        e.display.chromeScrollHack = null, e.display.sizer.style.pointerEvents = "";
      }, 100));
      var i = Gl(t), r = i.x, n = i.y, a = Jt;
      t.deltaMode === 0 && (r = t.deltaX, n = t.deltaY, a = 1);
      var l = e.display, o = l.scroller, u = o.scrollWidth > o.clientWidth, f = o.scrollHeight > o.clientHeight;
      if (r && u || n && f) {
        if (n && _ && z) {
          e:
            for (var D = t.target, w = l.view; D != o; D = D.parentNode)
              for (var M = 0; M < w.length; M++)
                if (w[M].node == D) {
                  e.display.currentWheelTarget = D;
                  break e;
                }
        }
        if (r && !m && !X && a != null) {
          n && f && fi(e, Math.max(0, o.scrollTop + n * a)), br(e, Math.max(0, o.scrollLeft + r * a)), (!n || n && f) && Ye(t), l.wheelStartX = null;
          return;
        }
        if (n && a != null) {
          var L = n * a, W = e.doc.scrollTop, K = W + l.wrapper.clientHeight;
          L < 0 ? W = Math.max(0, W + L - 50) : K = Math.min(e.doc.height, K + L + 50), pa(e, { top: W, bottom: K });
        }
        Qi < 20 && t.deltaMode !== 0 && (l.wheelStartX == null ? (l.wheelStartX = o.scrollLeft, l.wheelStartY = o.scrollTop, l.wheelDX = r, l.wheelDY = n, setTimeout(function() {
          if (l.wheelStartX != null) {
            var ee = o.scrollLeft - l.wheelStartX, ie = o.scrollTop - l.wheelStartY, se = ie && l.wheelDY && ie / l.wheelDY || ee && l.wheelDX && ee / l.wheelDX;
            l.wheelStartX = l.wheelStartY = null, se && (Jt = (Jt * Qi + se) / (Qi + 1), ++Qi);
          }
        }, 200)) : (l.wheelDX += r, l.wheelDY += n));
      }
    }
    var Lt = function(e, t) {
      this.ranges = e, this.primIndex = t;
    };
    Lt.prototype.primary = function() {
      return this.ranges[this.primIndex];
    }, Lt.prototype.equals = function(e) {
      if (e == this)
        return !0;
      if (e.primIndex != this.primIndex || e.ranges.length != this.ranges.length)
        return !1;
      for (var t = 0; t < this.ranges.length; t++) {
        var i = this.ranges[t], r = e.ranges[t];
        if (!_n(i.anchor, r.anchor) || !_n(i.head, r.head))
          return !1;
      }
      return !0;
    }, Lt.prototype.deepCopy = function() {
      for (var e = [], t = 0; t < this.ranges.length; t++)
        e[t] = new Re(Un(this.ranges[t].anchor), Un(this.ranges[t].head));
      return new Lt(e, this.primIndex);
    }, Lt.prototype.somethingSelected = function() {
      for (var e = 0; e < this.ranges.length; e++)
        if (!this.ranges[e].empty())
          return !0;
      return !1;
    }, Lt.prototype.contains = function(e, t) {
      t || (t = e);
      for (var i = 0; i < this.ranges.length; i++) {
        var r = this.ranges[i];
        if (Fe(t, r.from()) >= 0 && Fe(e, r.to()) <= 0)
          return i;
      }
      return -1;
    };
    var Re = function(e, t) {
      this.anchor = e, this.head = t;
    };
    Re.prototype.from = function() {
      return Ni(this.anchor, this.head);
    }, Re.prototype.to = function() {
      return Mi(this.anchor, this.head);
    }, Re.prototype.empty = function() {
      return this.head.line == this.anchor.line && this.head.ch == this.anchor.ch;
    };
    function Rt(e, t, i) {
      var r = e && e.options.selectionsMayTouch, n = t[i];
      t.sort(function(M, L) {
        return Fe(M.from(), L.from());
      }), i = Ie(t, n);
      for (var a = 1; a < t.length; a++) {
        var l = t[a], o = t[a - 1], u = Fe(o.to(), l.from());
        if (r && !l.empty() ? u > 0 : u >= 0) {
          var f = Ni(o.from(), l.from()), D = Mi(o.to(), l.to()), w = o.empty() ? l.from() == l.head : o.from() == o.head;
          a <= i && --i, t.splice(--a, 2, new Re(w ? D : f, w ? f : D));
        }
      }
      return new Lt(t, i);
    }
    function lr(e, t) {
      return new Lt([new Re(e, t || e)], 0);
    }
    function or(e) {
      return e.text ? $(
        e.from.line + e.text.length - 1,
        Be(e.text).length + (e.text.length == 1 ? e.from.ch : 0)
      ) : e.to;
    }
    function Kl(e, t) {
      if (Fe(e, t.from) < 0)
        return e;
      if (Fe(e, t.to) <= 0)
        return or(t);
      var i = e.line + t.text.length - (t.to.line - t.from.line) - 1, r = e.ch;
      return e.line == t.to.line && (r += or(t).ch - t.to.ch), $(i, r);
    }
    function xa(e, t) {
      for (var i = [], r = 0; r < e.sel.ranges.length; r++) {
        var n = e.sel.ranges[r];
        i.push(new Re(
          Kl(n.anchor, t),
          Kl(n.head, t)
        ));
      }
      return Rt(e.cm, i, e.sel.primIndex);
    }
    function Xl(e, t, i) {
      return e.line == t.line ? $(i.line, e.ch - t.ch + i.ch) : $(i.line + (e.line - t.line), e.ch);
    }
    function bs(e, t, i) {
      for (var r = [], n = $(e.first, 0), a = n, l = 0; l < t.length; l++) {
        var o = t[l], u = Xl(o.from, n, a), f = Xl(or(o), n, a);
        if (n = o.to, a = f, i == "around") {
          var D = e.sel.ranges[l], w = Fe(D.head, D.anchor) < 0;
          r[l] = new Re(w ? f : u, w ? u : f);
        } else
          r[l] = new Re(u, u);
      }
      return new Lt(r, e.sel.primIndex);
    }
    function ya(e) {
      e.doc.mode = Rn(e.options, e.doc.modeOption), gi(e);
    }
    function gi(e) {
      e.doc.iter(function(t) {
        t.stateAfter && (t.stateAfter = null), t.styles && (t.styles = null);
      }), e.doc.modeFrontier = e.doc.highlightFrontier = e.doc.first, di(e, 100), e.state.modeGen++, e.curOp && Dt(e);
    }
    function Yl(e, t) {
      return t.from.ch == 0 && t.to.ch == 0 && Be(t.text) == "" && (!e.cm || e.cm.options.wholeLineUpdateBefore);
    }
    function Da(e, t, i, r) {
      function n(se) {
        return i ? i[se] : null;
      }
      function a(se, ne, he) {
        Lu(se, ne, he, r), ot(se, "change", se, t);
      }
      function l(se, ne) {
        for (var he = [], be = se; be < ne; ++be)
          he.push(new Nr(f[be], n(be), r));
        return he;
      }
      var o = t.from, u = t.to, f = t.text, D = me(e, o.line), w = me(e, u.line), M = Be(f), L = n(f.length - 1), W = u.line - o.line;
      if (t.full)
        e.insert(0, l(0, f.length)), e.remove(f.length, e.size - f.length);
      else if (Yl(e, t)) {
        var K = l(0, f.length - 1);
        a(w, w.text, L), W && e.remove(o.line, W), K.length && e.insert(o.line, K);
      } else if (D == w)
        if (f.length == 1)
          a(D, D.text.slice(0, o.ch) + M + D.text.slice(u.ch), L);
        else {
          var ee = l(1, f.length - 1);
          ee.push(new Nr(M + D.text.slice(u.ch), L, r)), a(D, D.text.slice(0, o.ch) + f[0], n(0)), e.insert(o.line + 1, ee);
        }
      else if (f.length == 1)
        a(D, D.text.slice(0, o.ch) + f[0] + w.text.slice(u.ch), n(0)), e.remove(o.line + 1, W);
      else {
        a(D, D.text.slice(0, o.ch) + f[0], n(0)), a(w, M + w.text.slice(u.ch), L);
        var ie = l(1, f.length - 1);
        W > 1 && e.remove(o.line + 1, W - 1), e.insert(o.line + 1, ie);
      }
      ot(e, "change", e, t);
    }
    function ur(e, t, i) {
      function r(n, a, l) {
        if (n.linked)
          for (var o = 0; o < n.linked.length; ++o) {
            var u = n.linked[o];
            if (u.doc != a) {
              var f = l && u.sharedHist;
              i && !f || (t(u.doc, f), r(u.doc, n, f));
            }
          }
      }
      r(e, null, !0);
    }
    function Zl(e, t) {
      if (t.cm)
        throw new Error("This document is already in use.");
      e.doc = t, t.cm = e, la(e), ya(e), Ql(e), e.options.direction = t.direction, e.options.lineWrapping || Zn(e), e.options.mode = t.modeOption, Dt(e);
    }
    function Ql(e) {
      (e.doc.direction == "rtl" ? et : Se)(e.display.lineDiv, "CodeMirror-rtl");
    }
    function Cs(e) {
      St(e, function() {
        Ql(e), Dt(e);
      });
    }
    function $i(e) {
      this.done = [], this.undone = [], this.undoDepth = e ? e.undoDepth : 1 / 0, this.lastModTime = this.lastSelTime = 0, this.lastOp = this.lastSelOp = null, this.lastOrigin = this.lastSelOrigin = null, this.generation = this.maxGeneration = e ? e.maxGeneration : 1;
    }
    function ba(e, t) {
      var i = { from: Un(t.from), to: or(t), text: gr(e, t.from, t.to) };
      return Vl(e, i, t.from.line, t.to.line + 1), ur(e, function(r) {
        return Vl(r, i, t.from.line, t.to.line + 1);
      }, !0), i;
    }
    function $l(e) {
      for (; e.length; ) {
        var t = Be(e);
        if (t.ranges)
          e.pop();
        else
          break;
      }
    }
    function ws(e, t) {
      if (t)
        return $l(e.done), Be(e.done);
      if (e.done.length && !Be(e.done).ranges)
        return Be(e.done);
      if (e.done.length > 1 && !e.done[e.done.length - 2].ranges)
        return e.done.pop(), Be(e.done);
    }
    function Jl(e, t, i, r) {
      var n = e.history;
      n.undone.length = 0;
      var a = +/* @__PURE__ */ new Date(), l, o;
      if ((n.lastOp == r || n.lastOrigin == t.origin && t.origin && (t.origin.charAt(0) == "+" && n.lastModTime > a - (e.cm ? e.cm.options.historyEventDelay : 500) || t.origin.charAt(0) == "*")) && (l = ws(n, n.lastOp == r)))
        o = Be(l.changes), Fe(t.from, t.to) == 0 && Fe(t.from, o.to) == 0 ? o.to = or(t) : l.changes.push(ba(e, t));
      else {
        var u = Be(n.done);
        for ((!u || !u.ranges) && Ji(e.sel, n.done), l = {
          changes: [ba(e, t)],
          generation: n.generation
        }, n.done.push(l); n.done.length > n.undoDepth; )
          n.done.shift(), n.done[0].ranges || n.done.shift();
      }
      n.done.push(i), n.generation = ++n.maxGeneration, n.lastModTime = n.lastSelTime = a, n.lastOp = n.lastSelOp = r, n.lastOrigin = n.lastSelOrigin = t.origin, o || He(e, "historyAdded");
    }
    function ks(e, t, i, r) {
      var n = t.charAt(0);
      return n == "*" || n == "+" && i.ranges.length == r.ranges.length && i.somethingSelected() == r.somethingSelected() && /* @__PURE__ */ new Date() - e.history.lastSelTime <= (e.cm ? e.cm.options.historyEventDelay : 500);
    }
    function Ss(e, t, i, r) {
      var n = e.history, a = r && r.origin;
      i == n.lastSelOp || a && n.lastSelOrigin == a && (n.lastModTime == n.lastSelTime && n.lastOrigin == a || ks(e, a, Be(n.done), t)) ? n.done[n.done.length - 1] = t : Ji(t, n.done), n.lastSelTime = +/* @__PURE__ */ new Date(), n.lastSelOrigin = a, n.lastSelOp = i, r && r.clearRedo !== !1 && $l(n.undone);
    }
    function Ji(e, t) {
      var i = Be(t);
      i && i.ranges && i.equals(e) || t.push(e);
    }
    function Vl(e, t, i, r) {
      var n = t["spans_" + e.id], a = 0;
      e.iter(Math.max(e.first, i), Math.min(e.first + e.size, r), function(l) {
        l.markedSpans && ((n || (n = t["spans_" + e.id] = {}))[a] = l.markedSpans), ++a;
      });
    }
    function Fs(e) {
      if (!e)
        return null;
      for (var t, i = 0; i < e.length; ++i)
        e[i].marker.explicitlyCleared ? t || (t = e.slice(0, i)) : t && t.push(e[i]);
      return t ? t.length ? t : null : e;
    }
    function As(e, t) {
      var i = t["spans_" + e.id];
      if (!i)
        return null;
      for (var r = [], n = 0; n < t.text.length; ++n)
        r.push(Fs(i[n]));
      return r;
    }
    function eo(e, t) {
      var i = As(e, t), r = jn(e, t);
      if (!i)
        return r;
      if (!r)
        return i;
      for (var n = 0; n < i.length; ++n) {
        var a = i[n], l = r[n];
        if (a && l)
          e:
            for (var o = 0; o < l.length; ++o) {
              for (var u = l[o], f = 0; f < a.length; ++f)
                if (a[f].marker == u.marker)
                  continue e;
              a.push(u);
            }
        else
          l && (i[n] = l);
      }
      return i;
    }
    function _r(e, t, i) {
      for (var r = [], n = 0; n < e.length; ++n) {
        var a = e[n];
        if (a.ranges) {
          r.push(i ? Lt.prototype.deepCopy.call(a) : a);
          continue;
        }
        var l = a.changes, o = [];
        r.push({ changes: o });
        for (var u = 0; u < l.length; ++u) {
          var f = l[u], D = void 0;
          if (o.push({ from: f.from, to: f.to, text: f.text }), t)
            for (var w in f)
              (D = w.match(/^spans_(\d+)$/)) && Ie(t, Number(D[1])) > -1 && (Be(o)[w] = f[w], delete f[w]);
        }
      }
      return r;
    }
    function Ca(e, t, i, r) {
      if (r) {
        var n = e.anchor;
        if (i) {
          var a = Fe(t, n) < 0;
          a != Fe(i, n) < 0 ? (n = t, t = i) : a != Fe(t, i) < 0 && (t = i);
        }
        return new Re(n, t);
      } else
        return new Re(i || t, t);
    }
    function Vi(e, t, i, r, n) {
      n == null && (n = e.cm && (e.cm.display.shift || e.extend)), vt(e, new Lt([Ca(e.sel.primary(), t, i, n)], 0), r);
    }
    function to(e, t, i) {
      for (var r = [], n = e.cm && (e.cm.display.shift || e.extend), a = 0; a < e.sel.ranges.length; a++)
        r[a] = Ca(e.sel.ranges[a], t[a], null, n);
      var l = Rt(e.cm, r, e.sel.primIndex);
      vt(e, l, i);
    }
    function wa(e, t, i, r) {
      var n = e.sel.ranges.slice(0);
      n[t] = i, vt(e, Rt(e.cm, n, e.sel.primIndex), r);
    }
    function ro(e, t, i, r) {
      vt(e, lr(t, i), r);
    }
    function Es(e, t, i) {
      var r = {
        ranges: t.ranges,
        update: function(n) {
          this.ranges = [];
          for (var a = 0; a < n.length; a++)
            this.ranges[a] = new Re(
              Ae(e, n[a].anchor),
              Ae(e, n[a].head)
            );
        },
        origin: i && i.origin
      };
      return He(e, "beforeSelectionChange", e, r), e.cm && He(e.cm, "beforeSelectionChange", e.cm, r), r.ranges != t.ranges ? Rt(e.cm, r.ranges, r.ranges.length - 1) : t;
    }
    function io(e, t, i) {
      var r = e.history.done, n = Be(r);
      n && n.ranges ? (r[r.length - 1] = t, en(e, t, i)) : vt(e, t, i);
    }
    function vt(e, t, i) {
      en(e, t, i), Ss(e, e.sel, e.cm ? e.cm.curOp.id : NaN, i);
    }
    function en(e, t, i) {
      (pt(e, "beforeSelectionChange") || e.cm && pt(e.cm, "beforeSelectionChange")) && (t = Es(e, t, i));
      var r = i && i.bias || (Fe(t.primary().head, e.sel.primary().head) < 0 ? -1 : 1);
      no(e, lo(e, t, r, !0)), !(i && i.scroll === !1) && e.cm && e.cm.getOption("readOnly") != "nocursor" && Pr(e.cm);
    }
    function no(e, t) {
      t.equals(e.sel) || (e.sel = t, e.cm && (e.cm.curOp.updateInput = 1, e.cm.curOp.selectionChanged = !0, at(e.cm)), ot(e, "cursorActivity", e));
    }
    function ao(e) {
      no(e, lo(e, e.sel, null, !1));
    }
    function lo(e, t, i, r) {
      for (var n, a = 0; a < t.ranges.length; a++) {
        var l = t.ranges[a], o = t.ranges.length == e.sel.ranges.length && e.sel.ranges[a], u = tn(e, l.anchor, o && o.anchor, i, r), f = l.head == l.anchor ? u : tn(e, l.head, o && o.head, i, r);
        (n || u != l.anchor || f != l.head) && (n || (n = t.ranges.slice(0, a)), n[a] = new Re(u, f));
      }
      return n ? Rt(e.cm, n, t.primIndex) : t;
    }
    function Ur(e, t, i, r, n) {
      var a = me(e, t.line);
      if (a.markedSpans)
        for (var l = 0; l < a.markedSpans.length; ++l) {
          var o = a.markedSpans[l], u = o.marker, f = "selectLeft" in u ? !u.selectLeft : u.inclusiveLeft, D = "selectRight" in u ? !u.selectRight : u.inclusiveRight;
          if ((o.from == null || (f ? o.from <= t.ch : o.from < t.ch)) && (o.to == null || (D ? o.to >= t.ch : o.to > t.ch))) {
            if (n && (He(u, "beforeCursorEnter"), u.explicitlyCleared))
              if (a.markedSpans) {
                --l;
                continue;
              } else
                break;
            if (!u.atomic)
              continue;
            if (i) {
              var w = u.find(r < 0 ? 1 : -1), M = void 0;
              if ((r < 0 ? D : f) && (w = oo(e, w, -r, w && w.line == t.line ? a : null)), w && w.line == t.line && (M = Fe(w, i)) && (r < 0 ? M < 0 : M > 0))
                return Ur(e, w, t, r, n);
            }
            var L = u.find(r < 0 ? -1 : 1);
            return (r < 0 ? f : D) && (L = oo(e, L, r, L.line == t.line ? a : null)), L ? Ur(e, L, t, r, n) : null;
          }
        }
      return t;
    }
    function tn(e, t, i, r, n) {
      var a = r || 1, l = Ur(e, t, i, a, n) || !n && Ur(e, t, i, a, !0) || Ur(e, t, i, -a, n) || !n && Ur(e, t, i, -a, !0);
      return l || (e.cantEdit = !0, $(e.first, 0));
    }
    function oo(e, t, i, r) {
      return i < 0 && t.ch == 0 ? t.line > e.first ? Ae(e, $(t.line - 1)) : null : i > 0 && t.ch == (r || me(e, t.line)).text.length ? t.line < e.first + e.size - 1 ? $(t.line + 1, 0) : null : new $(t.line, t.ch + i);
    }
    function uo(e) {
      e.setSelection($(e.firstLine(), 0), $(e.lastLine()), dt);
    }
    function so(e, t, i) {
      var r = {
        canceled: !1,
        from: t.from,
        to: t.to,
        text: t.text,
        origin: t.origin,
        cancel: function() {
          return r.canceled = !0;
        }
      };
      return i && (r.update = function(n, a, l, o) {
        n && (r.from = Ae(e, n)), a && (r.to = Ae(e, a)), l && (r.text = l), o !== void 0 && (r.origin = o);
      }), He(e, "beforeChange", e, r), e.cm && He(e.cm, "beforeChange", e.cm, r), r.canceled ? (e.cm && (e.cm.curOp.updateInput = 2), null) : { from: r.from, to: r.to, text: r.text, origin: r.origin };
    }
    function qr(e, t, i) {
      if (e.cm) {
        if (!e.cm.curOp)
          return ut(e.cm, qr)(e, t, i);
        if (e.cm.state.suppressEdits)
          return;
      }
      if (!((pt(e, "beforeChange") || e.cm && pt(e.cm, "beforeChange")) && (t = so(e, t, !0), !t))) {
        var r = el && !i && Su(e, t.from, t.to);
        if (r)
          for (var n = r.length - 1; n >= 0; --n)
            fo(e, { from: r[n].from, to: r[n].to, text: n ? [""] : t.text, origin: t.origin });
        else
          fo(e, t);
      }
    }
    function fo(e, t) {
      if (!(t.text.length == 1 && t.text[0] == "" && Fe(t.from, t.to) == 0)) {
        var i = xa(e, t);
        Jl(e, t, i, e.cm ? e.cm.curOp.id : NaN), vi(e, t, i, jn(e, t));
        var r = [];
        ur(e, function(n, a) {
          !a && Ie(r, n.history) == -1 && (go(n.history, t), r.push(n.history)), vi(n, t, null, jn(n, t));
        });
      }
    }
    function rn(e, t, i) {
      var r = e.cm && e.cm.state.suppressEdits;
      if (!(r && !i)) {
        for (var n = e.history, a, l = e.sel, o = t == "undo" ? n.done : n.undone, u = t == "undo" ? n.undone : n.done, f = 0; f < o.length && (a = o[f], !(i ? a.ranges && !a.equals(e.sel) : !a.ranges)); f++)
          ;
        if (f != o.length) {
          for (n.lastOrigin = n.lastSelOrigin = null; ; )
            if (a = o.pop(), a.ranges) {
              if (Ji(a, u), i && !a.equals(e.sel)) {
                vt(e, a, { clearRedo: !1 });
                return;
              }
              l = a;
            } else if (r) {
              o.push(a);
              return;
            } else
              break;
          var D = [];
          Ji(l, u), u.push({ changes: D, generation: n.generation }), n.generation = a.generation || ++n.maxGeneration;
          for (var w = pt(e, "beforeChange") || e.cm && pt(e.cm, "beforeChange"), M = function(K) {
            var ee = a.changes[K];
            if (ee.origin = t, w && !so(e, ee, !1))
              return o.length = 0, {};
            D.push(ba(e, ee));
            var ie = K ? xa(e, ee) : Be(o);
            vi(e, ee, ie, eo(e, ee)), !K && e.cm && e.cm.scrollIntoView({ from: ee.from, to: or(ee) });
            var se = [];
            ur(e, function(ne, he) {
              !he && Ie(se, ne.history) == -1 && (go(ne.history, ee), se.push(ne.history)), vi(ne, ee, null, eo(ne, ee));
            });
          }, L = a.changes.length - 1; L >= 0; --L) {
            var W = M(L);
            if (W)
              return W.v;
          }
        }
      }
    }
    function co(e, t) {
      if (t != 0 && (e.first += t, e.sel = new Lt(Et(e.sel.ranges, function(n) {
        return new Re(
          $(n.anchor.line + t, n.anchor.ch),
          $(n.head.line + t, n.head.ch)
        );
      }), e.sel.primIndex), e.cm)) {
        Dt(e.cm, e.first, e.first - t, t);
        for (var i = e.cm.display, r = i.viewFrom; r < i.viewTo; r++)
          nr(e.cm, r, "gutter");
      }
    }
    function vi(e, t, i, r) {
      if (e.cm && !e.cm.curOp)
        return ut(e.cm, vi)(e, t, i, r);
      if (t.to.line < e.first) {
        co(e, t.text.length - 1 - (t.to.line - t.from.line));
        return;
      }
      if (!(t.from.line > e.lastLine())) {
        if (t.from.line < e.first) {
          var n = t.text.length - 1 - (e.first - t.from.line);
          co(e, n), t = {
            from: $(e.first, 0),
            to: $(t.to.line + n, t.to.ch),
            text: [Be(t.text)],
            origin: t.origin
          };
        }
        var a = e.lastLine();
        t.to.line > a && (t = {
          from: t.from,
          to: $(a, me(e, a).text.length),
          text: [t.text[0]],
          origin: t.origin
        }), t.removed = gr(e, t.from, t.to), i || (i = xa(e, t)), e.cm ? Ls(e.cm, t, r) : Da(e, t, r), en(e, i, dt), e.cantEdit && tn(e, $(e.firstLine(), 0)) && (e.cantEdit = !1);
      }
    }
    function Ls(e, t, i) {
      var r = e.doc, n = e.display, a = t.from, l = t.to, o = !1, u = a.line;
      e.options.lineWrapping || (u = Pe(Ot(me(r, a.line))), r.iter(u, l.line + 1, function(L) {
        if (L == n.maxLine)
          return o = !0, !0;
      })), r.sel.contains(t.from, t.to) > -1 && at(e), Da(r, t, i, Tl(e)), e.options.lineWrapping || (r.iter(u, a.line + t.text.length, function(L) {
        var W = Pi(L);
        W > n.maxLineLength && (n.maxLine = L, n.maxLineLength = W, n.maxLineChanged = !0, o = !1);
      }), o && (e.curOp.updateMaxLine = !0)), xu(r, a.line), di(e, 400);
      var f = t.text.length - (l.line - a.line) - 1;
      t.full ? Dt(e) : a.line == l.line && t.text.length == 1 && !Yl(e.doc, t) ? nr(e, a.line, "text") : Dt(e, a.line, l.line + 1, f);
      var D = pt(e, "changes"), w = pt(e, "change");
      if (w || D) {
        var M = {
          from: a,
          to: l,
          text: t.text,
          removed: t.removed,
          origin: t.origin
        };
        w && ot(e, "change", e, M), D && (e.curOp.changeObjs || (e.curOp.changeObjs = [])).push(M);
      }
      e.display.selForContextMenu = null;
    }
    function Gr(e, t, i, r, n) {
      var a;
      r || (r = i), Fe(r, i) < 0 && (a = [r, i], i = a[0], r = a[1]), typeof t == "string" && (t = e.splitLines(t)), qr(e, { from: i, to: r, text: t, origin: n });
    }
    function ho(e, t, i, r) {
      i < e.line ? e.line += r : t < e.line && (e.line = t, e.ch = 0);
    }
    function po(e, t, i, r) {
      for (var n = 0; n < e.length; ++n) {
        var a = e[n], l = !0;
        if (a.ranges) {
          a.copied || (a = e[n] = a.deepCopy(), a.copied = !0);
          for (var o = 0; o < a.ranges.length; o++)
            ho(a.ranges[o].anchor, t, i, r), ho(a.ranges[o].head, t, i, r);
          continue;
        }
        for (var u = 0; u < a.changes.length; ++u) {
          var f = a.changes[u];
          if (i < f.from.line)
            f.from = $(f.from.line + r, f.from.ch), f.to = $(f.to.line + r, f.to.ch);
          else if (t <= f.to.line) {
            l = !1;
            break;
          }
        }
        l || (e.splice(0, n + 1), n = 0);
      }
    }
    function go(e, t) {
      var i = t.from.line, r = t.to.line, n = t.text.length - (r - i) - 1;
      po(e.done, i, r, n), po(e.undone, i, r, n);
    }
    function mi(e, t, i, r) {
      var n = t, a = t;
      return typeof t == "number" ? a = me(e, ja(e, t)) : n = Pe(t), n == null ? null : (r(a, n) && e.cm && nr(e.cm, n, i), a);
    }
    function xi(e) {
      this.lines = e, this.parent = null;
      for (var t = 0, i = 0; i < e.length; ++i)
        e[i].parent = this, t += e[i].height;
      this.height = t;
    }
    xi.prototype = {
      chunkSize: function() {
        return this.lines.length;
      },
      // Remove the n lines at offset 'at'.
      removeInner: function(e, t) {
        for (var i = e, r = e + t; i < r; ++i) {
          var n = this.lines[i];
          this.height -= n.height, Tu(n), ot(n, "delete");
        }
        this.lines.splice(e, t);
      },
      // Helper used to collapse a small branch into a single leaf.
      collapse: function(e) {
        e.push.apply(e, this.lines);
      },
      // Insert the given array of lines at offset 'at', count them as
      // having the given height.
      insertInner: function(e, t, i) {
        this.height += i, this.lines = this.lines.slice(0, e).concat(t).concat(this.lines.slice(e));
        for (var r = 0; r < t.length; ++r)
          t[r].parent = this;
      },
      // Used to iterate over a part of the tree.
      iterN: function(e, t, i) {
        for (var r = e + t; e < r; ++e)
          if (i(this.lines[e]))
            return !0;
      }
    };
    function yi(e) {
      this.children = e;
      for (var t = 0, i = 0, r = 0; r < e.length; ++r) {
        var n = e[r];
        t += n.chunkSize(), i += n.height, n.parent = this;
      }
      this.size = t, this.height = i, this.parent = null;
    }
    yi.prototype = {
      chunkSize: function() {
        return this.size;
      },
      removeInner: function(e, t) {
        this.size -= t;
        for (var i = 0; i < this.children.length; ++i) {
          var r = this.children[i], n = r.chunkSize();
          if (e < n) {
            var a = Math.min(t, n - e), l = r.height;
            if (r.removeInner(e, a), this.height -= l - r.height, n == a && (this.children.splice(i--, 1), r.parent = null), (t -= a) == 0)
              break;
            e = 0;
          } else
            e -= n;
        }
        if (this.size - t < 25 && (this.children.length > 1 || !(this.children[0] instanceof xi))) {
          var o = [];
          this.collapse(o), this.children = [new xi(o)], this.children[0].parent = this;
        }
      },
      collapse: function(e) {
        for (var t = 0; t < this.children.length; ++t)
          this.children[t].collapse(e);
      },
      insertInner: function(e, t, i) {
        this.size += t.length, this.height += i;
        for (var r = 0; r < this.children.length; ++r) {
          var n = this.children[r], a = n.chunkSize();
          if (e <= a) {
            if (n.insertInner(e, t, i), n.lines && n.lines.length > 50) {
              for (var l = n.lines.length % 25 + 25, o = l; o < n.lines.length; ) {
                var u = new xi(n.lines.slice(o, o += 25));
                n.height -= u.height, this.children.splice(++r, 0, u), u.parent = this;
              }
              n.lines = n.lines.slice(0, l), this.maybeSpill();
            }
            break;
          }
          e -= a;
        }
      },
      // When a node has grown, check whether it should be split.
      maybeSpill: function() {
        if (!(this.children.length <= 10)) {
          var e = this;
          do {
            var t = e.children.splice(e.children.length - 5, 5), i = new yi(t);
            if (e.parent) {
              e.size -= i.size, e.height -= i.height;
              var n = Ie(e.parent.children, e);
              e.parent.children.splice(n + 1, 0, i);
            } else {
              var r = new yi(e.children);
              r.parent = e, e.children = [r, i], e = r;
            }
            i.parent = e.parent;
          } while (e.children.length > 10);
          e.parent.maybeSpill();
        }
      },
      iterN: function(e, t, i) {
        for (var r = 0; r < this.children.length; ++r) {
          var n = this.children[r], a = n.chunkSize();
          if (e < a) {
            var l = Math.min(t, a - e);
            if (n.iterN(e, l, i))
              return !0;
            if ((t -= l) == 0)
              break;
            e = 0;
          } else
            e -= a;
        }
      }
    };
    var Di = function(e, t, i) {
      if (i)
        for (var r in i)
          i.hasOwnProperty(r) && (this[r] = i[r]);
      this.doc = e, this.node = t;
    };
    Di.prototype.clear = function() {
      var e = this.doc.cm, t = this.line.widgets, i = this.line, r = Pe(i);
      if (!(r == null || !t)) {
        for (var n = 0; n < t.length; ++n)
          t[n] == this && t.splice(n--, 1);
        t.length || (i.widgets = null);
        var a = li(this);
        Ut(i, Math.max(0, i.height - a)), e && (St(e, function() {
          vo(e, i, -a), nr(e, r, "widget");
        }), ot(e, "lineWidgetCleared", e, this, r));
      }
    }, Di.prototype.changed = function() {
      var e = this, t = this.height, i = this.doc.cm, r = this.line;
      this.height = null;
      var n = li(this) - t;
      n && (ir(this.doc, r) || Ut(r, r.height + n), i && St(i, function() {
        i.curOp.forceUpdate = !0, vo(i, r, n), ot(i, "lineWidgetChanged", i, e, Pe(r));
      }));
    }, Nt(Di);
    function vo(e, t, i) {
      Qt(t) < (e.curOp && e.curOp.scrollTop || e.doc.scrollTop) && ha(e, i);
    }
    function Ts(e, t, i, r) {
      var n = new Di(e, i, r), a = e.cm;
      return a && n.noHScroll && (a.display.alignWidgets = !0), mi(e, t, "widget", function(l) {
        var o = l.widgets || (l.widgets = []);
        if (n.insertAt == null ? o.push(n) : o.splice(Math.min(o.length, Math.max(0, n.insertAt)), 0, n), n.line = l, a && !ir(e, l)) {
          var u = Qt(l) < e.scrollTop;
          Ut(l, l.height + li(n)), u && ha(a, n.height), a.curOp.forceUpdate = !0;
        }
        return !0;
      }), a && ot(a, "lineWidgetAdded", a, n, typeof t == "number" ? t : Pe(t)), n;
    }
    var mo = 0, sr = function(e, t) {
      this.lines = [], this.type = t, this.doc = e, this.id = ++mo;
    };
    sr.prototype.clear = function() {
      if (!this.explicitlyCleared) {
        var e = this.doc.cm, t = e && !e.curOp;
        if (t && wr(e), pt(this, "clear")) {
          var i = this.find();
          i && ot(this, "clear", i.from, i.to);
        }
        for (var r = null, n = null, a = 0; a < this.lines.length; ++a) {
          var l = this.lines[a], o = ii(l.markedSpans, this);
          e && !this.collapsed ? nr(e, Pe(l), "text") : e && (o.to != null && (n = Pe(l)), o.from != null && (r = Pe(l))), l.markedSpans = bu(l.markedSpans, o), o.from == null && this.collapsed && !ir(this.doc, l) && e && Ut(l, Hr(e.display));
        }
        if (e && this.collapsed && !e.options.lineWrapping)
          for (var u = 0; u < this.lines.length; ++u) {
            var f = Ot(this.lines[u]), D = Pi(f);
            D > e.display.maxLineLength && (e.display.maxLine = f, e.display.maxLineLength = D, e.display.maxLineChanged = !0);
          }
        r != null && e && this.collapsed && Dt(e, r, n + 1), this.lines.length = 0, this.explicitlyCleared = !0, this.atomic && this.doc.cantEdit && (this.doc.cantEdit = !1, e && ao(e.doc)), e && ot(e, "markerCleared", e, this, r, n), t && kr(e), this.parent && this.parent.clear();
      }
    }, sr.prototype.find = function(e, t) {
      e == null && this.type == "bookmark" && (e = 1);
      for (var i, r, n = 0; n < this.lines.length; ++n) {
        var a = this.lines[n], l = ii(a.markedSpans, this);
        if (l.from != null && (i = $(t ? a : Pe(a), l.from), e == -1))
          return i;
        if (l.to != null && (r = $(t ? a : Pe(a), l.to), e == 1))
          return r;
      }
      return i && { from: i, to: r };
    }, sr.prototype.changed = function() {
      var e = this, t = this.find(-1, !0), i = this, r = this.doc.cm;
      !t || !r || St(r, function() {
        var n = t.line, a = Pe(t.line), l = Vn(r, a);
        if (l && (Cl(l), r.curOp.selectionChanged = r.curOp.forceUpdate = !0), r.curOp.updateMaxLine = !0, !ir(i.doc, n) && i.height != null) {
          var o = i.height;
          i.height = null;
          var u = li(i) - o;
          u && Ut(n, n.height + u);
        }
        ot(r, "markerChanged", r, e);
      });
    }, sr.prototype.attachLine = function(e) {
      if (!this.lines.length && this.doc.cm) {
        var t = this.doc.cm.curOp;
        (!t.maybeHiddenMarkers || Ie(t.maybeHiddenMarkers, this) == -1) && (t.maybeUnhiddenMarkers || (t.maybeUnhiddenMarkers = [])).push(this);
      }
      this.lines.push(e);
    }, sr.prototype.detachLine = function(e) {
      if (this.lines.splice(Ie(this.lines, e), 1), !this.lines.length && this.doc.cm) {
        var t = this.doc.cm.curOp;
        (t.maybeHiddenMarkers || (t.maybeHiddenMarkers = [])).push(this);
      }
    }, Nt(sr);
    function jr(e, t, i, r, n) {
      if (r && r.shared)
        return Bs(e, t, i, r, n);
      if (e.cm && !e.cm.curOp)
        return ut(e.cm, jr)(e, t, i, r, n);
      var a = new sr(e, n), l = Fe(t, i);
      if (r && ht(r, a, !1), l > 0 || l == 0 && a.clearWhenEmpty !== !1)
        return a;
      if (a.replacedWith && (a.collapsed = !0, a.widgetNode = V("span", [a.replacedWith], "CodeMirror-widget"), r.handleMouseEvents || a.widgetNode.setAttribute("cm-ignore-events", "true"), r.insertLeft && (a.widgetNode.insertLeft = !0)), a.collapsed) {
        if (ll(e, t.line, t, i, a) || t.line != i.line && ll(e, i.line, t, i, a))
          throw new Error("Inserting collapsed marker partially overlapping an existing one");
        Du();
      }
      a.addToHistory && Jl(e, { from: t, to: i, origin: "markText" }, e.sel, NaN);
      var o = t.line, u = e.cm, f;
      if (e.iter(o, i.line + 1, function(w) {
        u && a.collapsed && !u.options.lineWrapping && Ot(w) == u.display.maxLine && (f = !0), a.collapsed && o != t.line && Ut(w, 0), Cu(w, new Oi(
          a,
          o == t.line ? t.ch : null,
          o == i.line ? i.ch : null
        ), e.cm && e.cm.curOp), ++o;
      }), a.collapsed && e.iter(t.line, i.line + 1, function(w) {
        ir(e, w) && Ut(w, 0);
      }), a.clearOnEnter && U(a, "beforeCursorEnter", function() {
        return a.clear();
      }), a.readOnly && (yu(), (e.history.done.length || e.history.undone.length) && e.clearHistory()), a.collapsed && (a.id = ++mo, a.atomic = !0), u) {
        if (f && (u.curOp.updateMaxLine = !0), a.collapsed)
          Dt(u, t.line, i.line + 1);
        else if (a.className || a.startStyle || a.endStyle || a.css || a.attributes || a.title)
          for (var D = t.line; D <= i.line; D++)
            nr(u, D, "text");
        a.atomic && ao(u.doc), ot(u, "markerAdded", u, a);
      }
      return a;
    }
    var bi = function(e, t) {
      this.markers = e, this.primary = t;
      for (var i = 0; i < e.length; ++i)
        e[i].parent = this;
    };
    bi.prototype.clear = function() {
      if (!this.explicitlyCleared) {
        this.explicitlyCleared = !0;
        for (var e = 0; e < this.markers.length; ++e)
          this.markers[e].clear();
        ot(this, "clear");
      }
    }, bi.prototype.find = function(e, t) {
      return this.primary.find(e, t);
    }, Nt(bi);
    function Bs(e, t, i, r, n) {
      r = ht(r), r.shared = !1;
      var a = [jr(e, t, i, r, n)], l = a[0], o = r.widgetNode;
      return ur(e, function(u) {
        o && (r.widgetNode = o.cloneNode(!0)), a.push(jr(u, Ae(u, t), Ae(u, i), r, n));
        for (var f = 0; f < u.linked.length; ++f)
          if (u.linked[f].isParent)
            return;
        l = Be(a);
      }), new bi(a, l);
    }
    function xo(e) {
      return e.findMarks($(e.first, 0), e.clipPos($(e.lastLine())), function(t) {
        return t.parent;
      });
    }
    function Ms(e, t) {
      for (var i = 0; i < t.length; i++) {
        var r = t[i], n = r.find(), a = e.clipPos(n.from), l = e.clipPos(n.to);
        if (Fe(a, l)) {
          var o = jr(e, a, l, r.primary, r.primary.type);
          r.markers.push(o), o.parent = r;
        }
      }
    }
    function Ns(e) {
      for (var t = function(r) {
        var n = e[r], a = [n.primary.doc];
        ur(n.primary.doc, function(u) {
          return a.push(u);
        });
        for (var l = 0; l < n.markers.length; l++) {
          var o = n.markers[l];
          Ie(a, o.doc) == -1 && (o.parent = null, n.markers.splice(l--, 1));
        }
      }, i = 0; i < e.length; i++)
        t(i);
    }
    var Is = 0, bt = function(e, t, i, r, n) {
      if (!(this instanceof bt))
        return new bt(e, t, i, r, n);
      i == null && (i = 0), yi.call(this, [new xi([new Nr("", null)])]), this.first = i, this.scrollTop = this.scrollLeft = 0, this.cantEdit = !1, this.cleanGeneration = 1, this.modeFrontier = this.highlightFrontier = i;
      var a = $(i, 0);
      this.sel = lr(a), this.history = new $i(null), this.id = ++Is, this.modeOption = t, this.lineSep = r, this.direction = n == "rtl" ? "rtl" : "ltr", this.extend = !1, typeof e == "string" && (e = this.splitLines(e)), Da(this, { from: a, to: a, text: e }), vt(this, lr(a), dt);
    };
    bt.prototype = I(yi.prototype, {
      constructor: bt,
      // Iterate over the document. Supports two forms -- with only one
      // argument, it calls that for each line in the document. With
      // three, it iterates over the range given by the first two (with
      // the second being non-inclusive).
      iter: function(e, t, i) {
        i ? this.iterN(e - this.first, t - e, i) : this.iterN(this.first, this.first + this.size, e);
      },
      // Non-public interface for adding and removing lines.
      insert: function(e, t) {
        for (var i = 0, r = 0; r < t.length; ++r)
          i += t[r].height;
        this.insertInner(e - this.first, t, i);
      },
      remove: function(e, t) {
        this.removeInner(e - this.first, t);
      },
      // From here, the methods are part of the public interface. Most
      // are also available from CodeMirror (editor) instances.
      getValue: function(e) {
        var t = Pn(this, this.first, this.first + this.size);
        return e === !1 ? t : t.join(e || this.lineSeparator());
      },
      setValue: st(function(e) {
        var t = $(this.first, 0), i = this.first + this.size - 1;
        qr(this, {
          from: t,
          to: $(i, me(this, i).text.length),
          text: this.splitLines(e),
          origin: "setValue",
          full: !0
        }, !0), this.cm && si(this.cm, 0, 0), vt(this, lr(t), dt);
      }),
      replaceRange: function(e, t, i, r) {
        t = Ae(this, t), i = i ? Ae(this, i) : t, Gr(this, e, t, i, r);
      },
      getRange: function(e, t, i) {
        var r = gr(this, Ae(this, e), Ae(this, t));
        return i === !1 ? r : i === "" ? r.join("") : r.join(i || this.lineSeparator());
      },
      getLine: function(e) {
        var t = this.getLineHandle(e);
        return t && t.text;
      },
      getLineHandle: function(e) {
        if (ti(this, e))
          return me(this, e);
      },
      getLineNumber: function(e) {
        return Pe(e);
      },
      getLineHandleVisualStart: function(e) {
        return typeof e == "number" && (e = me(this, e)), Ot(e);
      },
      lineCount: function() {
        return this.size;
      },
      firstLine: function() {
        return this.first;
      },
      lastLine: function() {
        return this.first + this.size - 1;
      },
      clipPos: function(e) {
        return Ae(this, e);
      },
      getCursor: function(e) {
        var t = this.sel.primary(), i;
        return e == null || e == "head" ? i = t.head : e == "anchor" ? i = t.anchor : e == "end" || e == "to" || e === !1 ? i = t.to() : i = t.from(), i;
      },
      listSelections: function() {
        return this.sel.ranges;
      },
      somethingSelected: function() {
        return this.sel.somethingSelected();
      },
      setCursor: st(function(e, t, i) {
        ro(this, Ae(this, typeof e == "number" ? $(e, t || 0) : e), null, i);
      }),
      setSelection: st(function(e, t, i) {
        ro(this, Ae(this, e), Ae(this, t || e), i);
      }),
      extendSelection: st(function(e, t, i) {
        Vi(this, Ae(this, e), t && Ae(this, t), i);
      }),
      extendSelections: st(function(e, t) {
        to(this, Ka(this, e), t);
      }),
      extendSelectionsBy: st(function(e, t) {
        var i = Et(this.sel.ranges, e);
        to(this, Ka(this, i), t);
      }),
      setSelections: st(function(e, t, i) {
        if (e.length) {
          for (var r = [], n = 0; n < e.length; n++)
            r[n] = new Re(
              Ae(this, e[n].anchor),
              Ae(this, e[n].head || e[n].anchor)
            );
          t == null && (t = Math.min(e.length - 1, this.sel.primIndex)), vt(this, Rt(this.cm, r, t), i);
        }
      }),
      addSelection: st(function(e, t, i) {
        var r = this.sel.ranges.slice(0);
        r.push(new Re(Ae(this, e), Ae(this, t || e))), vt(this, Rt(this.cm, r, r.length - 1), i);
      }),
      getSelection: function(e) {
        for (var t = this.sel.ranges, i, r = 0; r < t.length; r++) {
          var n = gr(this, t[r].from(), t[r].to());
          i = i ? i.concat(n) : n;
        }
        return e === !1 ? i : i.join(e || this.lineSeparator());
      },
      getSelections: function(e) {
        for (var t = [], i = this.sel.ranges, r = 0; r < i.length; r++) {
          var n = gr(this, i[r].from(), i[r].to());
          e !== !1 && (n = n.join(e || this.lineSeparator())), t[r] = n;
        }
        return t;
      },
      replaceSelection: function(e, t, i) {
        for (var r = [], n = 0; n < this.sel.ranges.length; n++)
          r[n] = e;
        this.replaceSelections(r, t, i || "+input");
      },
      replaceSelections: st(function(e, t, i) {
        for (var r = [], n = this.sel, a = 0; a < n.ranges.length; a++) {
          var l = n.ranges[a];
          r[a] = { from: l.from(), to: l.to(), text: this.splitLines(e[a]), origin: i };
        }
        for (var o = t && t != "end" && bs(this, r, t), u = r.length - 1; u >= 0; u--)
          qr(this, r[u]);
        o ? io(this, o) : this.cm && Pr(this.cm);
      }),
      undo: st(function() {
        rn(this, "undo");
      }),
      redo: st(function() {
        rn(this, "redo");
      }),
      undoSelection: st(function() {
        rn(this, "undo", !0);
      }),
      redoSelection: st(function() {
        rn(this, "redo", !0);
      }),
      setExtending: function(e) {
        this.extend = e;
      },
      getExtending: function() {
        return this.extend;
      },
      historySize: function() {
        for (var e = this.history, t = 0, i = 0, r = 0; r < e.done.length; r++)
          e.done[r].ranges || ++t;
        for (var n = 0; n < e.undone.length; n++)
          e.undone[n].ranges || ++i;
        return { undo: t, redo: i };
      },
      clearHistory: function() {
        var e = this;
        this.history = new $i(this.history), ur(this, function(t) {
          return t.history = e.history;
        }, !0);
      },
      markClean: function() {
        this.cleanGeneration = this.changeGeneration(!0);
      },
      changeGeneration: function(e) {
        return e && (this.history.lastOp = this.history.lastSelOp = this.history.lastOrigin = null), this.history.generation;
      },
      isClean: function(e) {
        return this.history.generation == (e || this.cleanGeneration);
      },
      getHistory: function() {
        return {
          done: _r(this.history.done),
          undone: _r(this.history.undone)
        };
      },
      setHistory: function(e) {
        var t = this.history = new $i(this.history);
        t.done = _r(e.done.slice(0), null, !0), t.undone = _r(e.undone.slice(0), null, !0);
      },
      setGutterMarker: st(function(e, t, i) {
        return mi(this, e, "gutter", function(r) {
          var n = r.gutterMarkers || (r.gutterMarkers = {});
          return n[t] = i, !i && p(n) && (r.gutterMarkers = null), !0;
        });
      }),
      clearGutter: st(function(e) {
        var t = this;
        this.iter(function(i) {
          i.gutterMarkers && i.gutterMarkers[e] && mi(t, i, "gutter", function() {
            return i.gutterMarkers[e] = null, p(i.gutterMarkers) && (i.gutterMarkers = null), !0;
          });
        });
      }),
      lineInfo: function(e) {
        var t;
        if (typeof e == "number") {
          if (!ti(this, e) || (t = e, e = me(this, e), !e))
            return null;
        } else if (t = Pe(e), t == null)
          return null;
        return {
          line: t,
          handle: e,
          text: e.text,
          gutterMarkers: e.gutterMarkers,
          textClass: e.textClass,
          bgClass: e.bgClass,
          wrapClass: e.wrapClass,
          widgets: e.widgets
        };
      },
      addLineClass: st(function(e, t, i) {
        return mi(this, e, t == "gutter" ? "gutter" : "class", function(r) {
          var n = t == "text" ? "textClass" : t == "background" ? "bgClass" : t == "gutter" ? "gutterClass" : "wrapClass";
          if (!r[n])
            r[n] = i;
          else {
            if (ae(i).test(r[n]))
              return !1;
            r[n] += " " + i;
          }
          return !0;
        });
      }),
      removeLineClass: st(function(e, t, i) {
        return mi(this, e, t == "gutter" ? "gutter" : "class", function(r) {
          var n = t == "text" ? "textClass" : t == "background" ? "bgClass" : t == "gutter" ? "gutterClass" : "wrapClass", a = r[n];
          if (a)
            if (i == null)
              r[n] = null;
            else {
              var l = a.match(ae(i));
              if (!l)
                return !1;
              var o = l.index + l[0].length;
              r[n] = a.slice(0, l.index) + (!l.index || o == a.length ? "" : " ") + a.slice(o) || null;
            }
          else
            return !1;
          return !0;
        });
      }),
      addLineWidget: st(function(e, t, i) {
        return Ts(this, e, t, i);
      }),
      removeLineWidget: function(e) {
        e.clear();
      },
      markText: function(e, t, i) {
        return jr(this, Ae(this, e), Ae(this, t), i, i && i.type || "range");
      },
      setBookmark: function(e, t) {
        var i = {
          replacedWith: t && (t.nodeType == null ? t.widget : t),
          insertLeft: t && t.insertLeft,
          clearWhenEmpty: !1,
          shared: t && t.shared,
          handleMouseEvents: t && t.handleMouseEvents
        };
        return e = Ae(this, e), jr(this, e, e, i, "bookmark");
      },
      findMarksAt: function(e) {
        e = Ae(this, e);
        var t = [], i = me(this, e.line).markedSpans;
        if (i)
          for (var r = 0; r < i.length; ++r) {
            var n = i[r];
            (n.from == null || n.from <= e.ch) && (n.to == null || n.to >= e.ch) && t.push(n.marker.parent || n.marker);
          }
        return t;
      },
      findMarks: function(e, t, i) {
        e = Ae(this, e), t = Ae(this, t);
        var r = [], n = e.line;
        return this.iter(e.line, t.line + 1, function(a) {
          var l = a.markedSpans;
          if (l)
            for (var o = 0; o < l.length; o++) {
              var u = l[o];
              !(u.to != null && n == e.line && e.ch >= u.to || u.from == null && n != e.line || u.from != null && n == t.line && u.from >= t.ch) && (!i || i(u.marker)) && r.push(u.marker.parent || u.marker);
            }
          ++n;
        }), r;
      },
      getAllMarks: function() {
        var e = [];
        return this.iter(function(t) {
          var i = t.markedSpans;
          if (i)
            for (var r = 0; r < i.length; ++r)
              i[r].from != null && e.push(i[r].marker);
        }), e;
      },
      posFromIndex: function(e) {
        var t, i = this.first, r = this.lineSeparator().length;
        return this.iter(function(n) {
          var a = n.text.length + r;
          if (a > e)
            return t = e, !0;
          e -= a, ++i;
        }), Ae(this, $(i, t));
      },
      indexFromPos: function(e) {
        e = Ae(this, e);
        var t = e.ch;
        if (e.line < this.first || e.ch < 0)
          return 0;
        var i = this.lineSeparator().length;
        return this.iter(this.first, e.line, function(r) {
          t += r.text.length + i;
        }), t;
      },
      copy: function(e) {
        var t = new bt(
          Pn(this, this.first, this.first + this.size),
          this.modeOption,
          this.first,
          this.lineSep,
          this.direction
        );
        return t.scrollTop = this.scrollTop, t.scrollLeft = this.scrollLeft, t.sel = this.sel, t.extend = !1, e && (t.history.undoDepth = this.history.undoDepth, t.setHistory(this.getHistory())), t;
      },
      linkedDoc: function(e) {
        e || (e = {});
        var t = this.first, i = this.first + this.size;
        e.from != null && e.from > t && (t = e.from), e.to != null && e.to < i && (i = e.to);
        var r = new bt(Pn(this, t, i), e.mode || this.modeOption, t, this.lineSep, this.direction);
        return e.sharedHist && (r.history = this.history), (this.linked || (this.linked = [])).push({ doc: r, sharedHist: e.sharedHist }), r.linked = [{ doc: this, isParent: !0, sharedHist: e.sharedHist }], Ms(r, xo(this)), r;
      },
      unlinkDoc: function(e) {
        if (e instanceof je && (e = e.doc), this.linked)
          for (var t = 0; t < this.linked.length; ++t) {
            var i = this.linked[t];
            if (i.doc == e) {
              this.linked.splice(t, 1), e.unlinkDoc(this), Ns(xo(this));
              break;
            }
          }
        if (e.history == this.history) {
          var r = [e.id];
          ur(e, function(n) {
            return r.push(n.id);
          }, !0), e.history = new $i(null), e.history.done = _r(this.history.done, r), e.history.undone = _r(this.history.undone, r);
        }
      },
      iterLinkedDocs: function(e) {
        ur(this, e);
      },
      getMode: function() {
        return this.mode;
      },
      getEditor: function() {
        return this.cm;
      },
      splitLines: function(e) {
        return this.lineSep ? e.split(this.lineSep) : In(e);
      },
      lineSeparator: function() {
        return this.lineSep || `
`;
      },
      setDirection: st(function(e) {
        e != "rtl" && (e = "ltr"), e != this.direction && (this.direction = e, this.iter(function(t) {
          return t.order = null;
        }), this.cm && Cs(this.cm));
      })
    }), bt.prototype.eachLine = bt.prototype.iter;
    var yo = 0;
    function Os(e) {
      var t = this;
      if (Do(t), !(Le(t, e) || $t(t.display, e))) {
        Ye(e), x && (yo = +/* @__PURE__ */ new Date());
        var i = yr(t, e, !0), r = e.dataTransfer.files;
        if (!(!i || t.isReadOnly()))
          if (r && r.length && window.FileReader && window.File)
            for (var n = r.length, a = Array(n), l = 0, o = function() {
              ++l == n && ut(t, function() {
                i = Ae(t.doc, i);
                var L = {
                  from: i,
                  to: i,
                  text: t.doc.splitLines(
                    a.filter(function(W) {
                      return W != null;
                    }).join(t.doc.lineSeparator())
                  ),
                  origin: "paste"
                };
                qr(t.doc, L), io(t.doc, lr(Ae(t.doc, i), Ae(t.doc, or(L))));
              })();
            }, u = function(L, W) {
              if (t.options.allowDropFileTypes && Ie(t.options.allowDropFileTypes, L.type) == -1) {
                o();
                return;
              }
              var K = new FileReader();
              K.onerror = function() {
                return o();
              }, K.onload = function() {
                var ee = K.result;
                if (/[\x00-\x08\x0e-\x1f]{2}/.test(ee)) {
                  o();
                  return;
                }
                a[W] = ee, o();
              }, K.readAsText(L);
            }, f = 0; f < r.length; f++)
              u(r[f], f);
          else {
            if (t.state.draggingText && t.doc.sel.contains(i) > -1) {
              t.state.draggingText(e), setTimeout(function() {
                return t.display.input.focus();
              }, 20);
              return;
            }
            try {
              var D = e.dataTransfer.getData("Text");
              if (D) {
                var w;
                if (t.state.draggingText && !t.state.draggingText.copy && (w = t.listSelections()), en(t.doc, lr(i, i)), w)
                  for (var M = 0; M < w.length; ++M)
                    Gr(t.doc, "", w[M].anchor, w[M].head, "drag");
                t.replaceSelection(D, "around", "paste"), t.display.input.focus();
              }
            } catch {
            }
          }
      }
    }
    function Hs(e, t) {
      if (x && (!e.state.draggingText || +/* @__PURE__ */ new Date() - yo < 100)) {
        It(t);
        return;
      }
      if (!(Le(e, t) || $t(e.display, t)) && (t.dataTransfer.setData("Text", e.getSelection()), t.dataTransfer.effectAllowed = "copyMove", t.dataTransfer.setDragImage && !le)) {
        var i = T("img", null, null, "position: fixed; left: 0; top: 0;");
        i.src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==", X && (i.width = i.height = 1, e.display.wrapper.appendChild(i), i._top = i.offsetTop), t.dataTransfer.setDragImage(i, 0, 0), X && i.parentNode.removeChild(i);
      }
    }
    function Rs(e, t) {
      var i = yr(e, t);
      if (i) {
        var r = document.createDocumentFragment();
        oa(e, i, r), e.display.dragCursor || (e.display.dragCursor = T("div", null, "CodeMirror-cursors CodeMirror-dragcursors"), e.display.lineSpace.insertBefore(e.display.dragCursor, e.display.cursorDiv)), De(e.display.dragCursor, r);
      }
    }
    function Do(e) {
      e.display.dragCursor && (e.display.lineSpace.removeChild(e.display.dragCursor), e.display.dragCursor = null);
    }
    function bo(e) {
      if (document.getElementsByClassName) {
        for (var t = document.getElementsByClassName("CodeMirror"), i = [], r = 0; r < t.length; r++) {
          var n = t[r].CodeMirror;
          n && i.push(n);
        }
        i.length && i[0].operation(function() {
          for (var a = 0; a < i.length; a++)
            e(i[a]);
        });
      }
    }
    var Co = !1;
    function zs() {
      Co || (Ps(), Co = !0);
    }
    function Ps() {
      var e;
      U(window, "resize", function() {
        e == null && (e = setTimeout(function() {
          e = null, bo(Ws);
        }, 100));
      }), U(window, "blur", function() {
        return bo(zr);
      });
    }
    function Ws(e) {
      var t = e.display;
      t.cachedCharWidth = t.cachedTextHeight = t.cachedPaddingH = null, t.scrollbarsClipped = !1, e.setSize();
    }
    for (var fr = {
      3: "Pause",
      8: "Backspace",
      9: "Tab",
      13: "Enter",
      16: "Shift",
      17: "Ctrl",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Esc",
      32: "Space",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "Left",
      38: "Up",
      39: "Right",
      40: "Down",
      44: "PrintScrn",
      45: "Insert",
      46: "Delete",
      59: ";",
      61: "=",
      91: "Mod",
      92: "Mod",
      93: "Mod",
      106: "*",
      107: "=",
      109: "-",
      110: ".",
      111: "/",
      145: "ScrollLock",
      173: "-",
      186: ";",
      187: "=",
      188: ",",
      189: "-",
      190: ".",
      191: "/",
      192: "`",
      219: "[",
      220: "\\",
      221: "]",
      222: "'",
      224: "Mod",
      63232: "Up",
      63233: "Down",
      63234: "Left",
      63235: "Right",
      63272: "Delete",
      63273: "Home",
      63275: "End",
      63276: "PageUp",
      63277: "PageDown",
      63302: "Insert"
    }, Ci = 0; Ci < 10; Ci++)
      fr[Ci + 48] = fr[Ci + 96] = String(Ci);
    for (var nn = 65; nn <= 90; nn++)
      fr[nn] = String.fromCharCode(nn);
    for (var wi = 1; wi <= 12; wi++)
      fr[wi + 111] = fr[wi + 63235] = "F" + wi;
    var Vt = {};
    Vt.basic = {
      Left: "goCharLeft",
      Right: "goCharRight",
      Up: "goLineUp",
      Down: "goLineDown",
      End: "goLineEnd",
      Home: "goLineStartSmart",
      PageUp: "goPageUp",
      PageDown: "goPageDown",
      Delete: "delCharAfter",
      Backspace: "delCharBefore",
      "Shift-Backspace": "delCharBefore",
      Tab: "defaultTab",
      "Shift-Tab": "indentAuto",
      Enter: "newlineAndIndent",
      Insert: "toggleOverwrite",
      Esc: "singleSelection"
    }, Vt.pcDefault = {
      "Ctrl-A": "selectAll",
      "Ctrl-D": "deleteLine",
      "Ctrl-Z": "undo",
      "Shift-Ctrl-Z": "redo",
      "Ctrl-Y": "redo",
      "Ctrl-Home": "goDocStart",
      "Ctrl-End": "goDocEnd",
      "Ctrl-Up": "goLineUp",
      "Ctrl-Down": "goLineDown",
      "Ctrl-Left": "goGroupLeft",
      "Ctrl-Right": "goGroupRight",
      "Alt-Left": "goLineStart",
      "Alt-Right": "goLineEnd",
      "Ctrl-Backspace": "delGroupBefore",
      "Ctrl-Delete": "delGroupAfter",
      "Ctrl-S": "save",
      "Ctrl-F": "find",
      "Ctrl-G": "findNext",
      "Shift-Ctrl-G": "findPrev",
      "Shift-Ctrl-F": "replace",
      "Shift-Ctrl-R": "replaceAll",
      "Ctrl-[": "indentLess",
      "Ctrl-]": "indentMore",
      "Ctrl-U": "undoSelection",
      "Shift-Ctrl-U": "redoSelection",
      "Alt-U": "redoSelection",
      fallthrough: "basic"
    }, Vt.emacsy = {
      "Ctrl-F": "goCharRight",
      "Ctrl-B": "goCharLeft",
      "Ctrl-P": "goLineUp",
      "Ctrl-N": "goLineDown",
      "Ctrl-A": "goLineStart",
      "Ctrl-E": "goLineEnd",
      "Ctrl-V": "goPageDown",
      "Shift-Ctrl-V": "goPageUp",
      "Ctrl-D": "delCharAfter",
      "Ctrl-H": "delCharBefore",
      "Alt-Backspace": "delWordBefore",
      "Ctrl-K": "killLine",
      "Ctrl-T": "transposeChars",
      "Ctrl-O": "openLine"
    }, Vt.macDefault = {
      "Cmd-A": "selectAll",
      "Cmd-D": "deleteLine",
      "Cmd-Z": "undo",
      "Shift-Cmd-Z": "redo",
      "Cmd-Y": "redo",
      "Cmd-Home": "goDocStart",
      "Cmd-Up": "goDocStart",
      "Cmd-End": "goDocEnd",
      "Cmd-Down": "goDocEnd",
      "Alt-Left": "goGroupLeft",
      "Alt-Right": "goGroupRight",
      "Cmd-Left": "goLineLeft",
      "Cmd-Right": "goLineRight",
      "Alt-Backspace": "delGroupBefore",
      "Ctrl-Alt-Backspace": "delGroupAfter",
      "Alt-Delete": "delGroupAfter",
      "Cmd-S": "save",
      "Cmd-F": "find",
      "Cmd-G": "findNext",
      "Shift-Cmd-G": "findPrev",
      "Cmd-Alt-F": "replace",
      "Shift-Cmd-Alt-F": "replaceAll",
      "Cmd-[": "indentLess",
      "Cmd-]": "indentMore",
      "Cmd-Backspace": "delWrappedLineLeft",
      "Cmd-Delete": "delWrappedLineRight",
      "Cmd-U": "undoSelection",
      "Shift-Cmd-U": "redoSelection",
      "Ctrl-Up": "goDocStart",
      "Ctrl-Down": "goDocEnd",
      fallthrough: ["basic", "emacsy"]
    }, Vt.default = _ ? Vt.macDefault : Vt.pcDefault;
    function _s(e) {
      var t = e.split(/-(?!$)/);
      e = t[t.length - 1];
      for (var i, r, n, a, l = 0; l < t.length - 1; l++) {
        var o = t[l];
        if (/^(cmd|meta|m)$/i.test(o))
          a = !0;
        else if (/^a(lt)?$/i.test(o))
          i = !0;
        else if (/^(c|ctrl|control)$/i.test(o))
          r = !0;
        else if (/^s(hift)?$/i.test(o))
          n = !0;
        else
          throw new Error("Unrecognized modifier name: " + o);
      }
      return i && (e = "Alt-" + e), r && (e = "Ctrl-" + e), a && (e = "Cmd-" + e), n && (e = "Shift-" + e), e;
    }
    function Us(e) {
      var t = {};
      for (var i in e)
        if (e.hasOwnProperty(i)) {
          var r = e[i];
          if (/^(name|fallthrough|(de|at)tach)$/.test(i))
            continue;
          if (r == "...") {
            delete e[i];
            continue;
          }
          for (var n = Et(i.split(" "), _s), a = 0; a < n.length; a++) {
            var l = void 0, o = void 0;
            a == n.length - 1 ? (o = n.join(" "), l = r) : (o = n.slice(0, a + 1).join(" "), l = "...");
            var u = t[o];
            if (!u)
              t[o] = l;
            else if (u != l)
              throw new Error("Inconsistent bindings for " + o);
          }
          delete e[i];
        }
      for (var f in t)
        e[f] = t[f];
      return e;
    }
    function Kr(e, t, i, r) {
      t = an(t);
      var n = t.call ? t.call(e, r) : t[e];
      if (n === !1)
        return "nothing";
      if (n === "...")
        return "multi";
      if (n != null && i(n))
        return "handled";
      if (t.fallthrough) {
        if (Object.prototype.toString.call(t.fallthrough) != "[object Array]")
          return Kr(e, t.fallthrough, i, r);
        for (var a = 0; a < t.fallthrough.length; a++) {
          var l = Kr(e, t.fallthrough[a], i, r);
          if (l)
            return l;
        }
      }
    }
    function wo(e) {
      var t = typeof e == "string" ? e : fr[e.keyCode];
      return t == "Ctrl" || t == "Alt" || t == "Shift" || t == "Mod";
    }
    function ko(e, t, i) {
      var r = e;
      return t.altKey && r != "Alt" && (e = "Alt-" + e), (pe ? t.metaKey : t.ctrlKey) && r != "Ctrl" && (e = "Ctrl-" + e), (pe ? t.ctrlKey : t.metaKey) && r != "Mod" && (e = "Cmd-" + e), !i && t.shiftKey && r != "Shift" && (e = "Shift-" + e), e;
    }
    function So(e, t) {
      if (X && e.keyCode == 34 && e.char)
        return !1;
      var i = fr[e.keyCode];
      return i == null || e.altGraphKey ? !1 : (e.keyCode == 3 && e.code && (i = e.code), ko(i, e, t));
    }
    function an(e) {
      return typeof e == "string" ? Vt[e] : e;
    }
    function Xr(e, t) {
      for (var i = e.doc.sel.ranges, r = [], n = 0; n < i.length; n++) {
        for (var a = t(i[n]); r.length && Fe(a.from, Be(r).to) <= 0; ) {
          var l = r.pop();
          if (Fe(l.from, a.from) < 0) {
            a.from = l.from;
            break;
          }
        }
        r.push(a);
      }
      St(e, function() {
        for (var o = r.length - 1; o >= 0; o--)
          Gr(e.doc, "", r[o].from, r[o].to, "+delete");
        Pr(e);
      });
    }
    function ka(e, t, i) {
      var r = E(e.text, t + i, i);
      return r < 0 || r > e.text.length ? null : r;
    }
    function Sa(e, t, i) {
      var r = ka(e, t.ch, i);
      return r == null ? null : new $(t.line, r, i < 0 ? "after" : "before");
    }
    function Fa(e, t, i, r, n) {
      if (e) {
        t.doc.direction == "rtl" && (n = -n);
        var a = ue(i, t.doc.direction);
        if (a) {
          var l = n < 0 ? Be(a) : a[0], o = n < 0 == (l.level == 1), u = o ? "after" : "before", f;
          if (l.level > 0 || t.doc.direction == "rtl") {
            var D = Or(t, i);
            f = n < 0 ? i.text.length - 1 : 0;
            var w = jt(t, D, f).top;
            f = re(function(M) {
              return jt(t, D, M).top == w;
            }, n < 0 == (l.level == 1) ? l.from : l.to - 1, f), u == "before" && (f = ka(i, f, 1));
          } else
            f = n < 0 ? l.to : l.from;
          return new $(r, f, u);
        }
      }
      return new $(r, n < 0 ? i.text.length : 0, n < 0 ? "before" : "after");
    }
    function qs(e, t, i, r) {
      var n = ue(t, e.doc.direction);
      if (!n)
        return Sa(t, i, r);
      i.ch >= t.text.length ? (i.ch = t.text.length, i.sticky = "before") : i.ch <= 0 && (i.ch = 0, i.sticky = "after");
      var a = ve(n, i.ch, i.sticky), l = n[a];
      if (e.doc.direction == "ltr" && l.level % 2 == 0 && (r > 0 ? l.to > i.ch : l.from < i.ch))
        return Sa(t, i, r);
      var o = function(ie, se) {
        return ka(t, ie instanceof $ ? ie.ch : ie, se);
      }, u, f = function(ie) {
        return e.options.lineWrapping ? (u = u || Or(e, t), Ll(e, t, u, ie)) : { begin: 0, end: t.text.length };
      }, D = f(i.sticky == "before" ? o(i, -1) : i.ch);
      if (e.doc.direction == "rtl" || l.level == 1) {
        var w = l.level == 1 == r < 0, M = o(i, w ? 1 : -1);
        if (M != null && (w ? M <= l.to && M <= D.end : M >= l.from && M >= D.begin)) {
          var L = w ? "before" : "after";
          return new $(i.line, M, L);
        }
      }
      var W = function(ie, se, ne) {
        for (var he = function(Ue, ft) {
          return ft ? new $(i.line, o(Ue, 1), "before") : new $(i.line, Ue, "after");
        }; ie >= 0 && ie < n.length; ie += se) {
          var be = n[ie], xe = se > 0 == (be.level != 1), Te = xe ? ne.begin : o(ne.end, -1);
          if (be.from <= Te && Te < be.to || (Te = xe ? be.from : o(be.to, -1), ne.begin <= Te && Te < ne.end))
            return he(Te, xe);
        }
      }, K = W(a + r, r, D);
      if (K)
        return K;
      var ee = r > 0 ? D.end : o(D.begin, -1);
      return ee != null && !(r > 0 && ee == t.text.length) && (K = W(r > 0 ? 0 : n.length - 1, r, f(ee)), K) ? K : null;
    }
    var ki = {
      selectAll: uo,
      singleSelection: function(e) {
        return e.setSelection(e.getCursor("anchor"), e.getCursor("head"), dt);
      },
      killLine: function(e) {
        return Xr(e, function(t) {
          if (t.empty()) {
            var i = me(e.doc, t.head.line).text.length;
            return t.head.ch == i && t.head.line < e.lastLine() ? { from: t.head, to: $(t.head.line + 1, 0) } : { from: t.head, to: $(t.head.line, i) };
          } else
            return { from: t.from(), to: t.to() };
        });
      },
      deleteLine: function(e) {
        return Xr(e, function(t) {
          return {
            from: $(t.from().line, 0),
            to: Ae(e.doc, $(t.to().line + 1, 0))
          };
        });
      },
      delLineLeft: function(e) {
        return Xr(e, function(t) {
          return {
            from: $(t.from().line, 0),
            to: t.from()
          };
        });
      },
      delWrappedLineLeft: function(e) {
        return Xr(e, function(t) {
          var i = e.charCoords(t.head, "div").top + 5, r = e.coordsChar({ left: 0, top: i }, "div");
          return { from: r, to: t.from() };
        });
      },
      delWrappedLineRight: function(e) {
        return Xr(e, function(t) {
          var i = e.charCoords(t.head, "div").top + 5, r = e.coordsChar({ left: e.display.lineDiv.offsetWidth + 100, top: i }, "div");
          return { from: t.from(), to: r };
        });
      },
      undo: function(e) {
        return e.undo();
      },
      redo: function(e) {
        return e.redo();
      },
      undoSelection: function(e) {
        return e.undoSelection();
      },
      redoSelection: function(e) {
        return e.redoSelection();
      },
      goDocStart: function(e) {
        return e.extendSelection($(e.firstLine(), 0));
      },
      goDocEnd: function(e) {
        return e.extendSelection($(e.lastLine()));
      },
      goLineStart: function(e) {
        return e.extendSelectionsBy(
          function(t) {
            return Fo(e, t.head.line);
          },
          { origin: "+move", bias: 1 }
        );
      },
      goLineStartSmart: function(e) {
        return e.extendSelectionsBy(
          function(t) {
            return Ao(e, t.head);
          },
          { origin: "+move", bias: 1 }
        );
      },
      goLineEnd: function(e) {
        return e.extendSelectionsBy(
          function(t) {
            return Gs(e, t.head.line);
          },
          { origin: "+move", bias: -1 }
        );
      },
      goLineRight: function(e) {
        return e.extendSelectionsBy(function(t) {
          var i = e.cursorCoords(t.head, "div").top + 5;
          return e.coordsChar({ left: e.display.lineDiv.offsetWidth + 100, top: i }, "div");
        }, Bt);
      },
      goLineLeft: function(e) {
        return e.extendSelectionsBy(function(t) {
          var i = e.cursorCoords(t.head, "div").top + 5;
          return e.coordsChar({ left: 0, top: i }, "div");
        }, Bt);
      },
      goLineLeftSmart: function(e) {
        return e.extendSelectionsBy(function(t) {
          var i = e.cursorCoords(t.head, "div").top + 5, r = e.coordsChar({ left: 0, top: i }, "div");
          return r.ch < e.getLine(r.line).search(/\S/) ? Ao(e, t.head) : r;
        }, Bt);
      },
      goLineUp: function(e) {
        return e.moveV(-1, "line");
      },
      goLineDown: function(e) {
        return e.moveV(1, "line");
      },
      goPageUp: function(e) {
        return e.moveV(-1, "page");
      },
      goPageDown: function(e) {
        return e.moveV(1, "page");
      },
      goCharLeft: function(e) {
        return e.moveH(-1, "char");
      },
      goCharRight: function(e) {
        return e.moveH(1, "char");
      },
      goColumnLeft: function(e) {
        return e.moveH(-1, "column");
      },
      goColumnRight: function(e) {
        return e.moveH(1, "column");
      },
      goWordLeft: function(e) {
        return e.moveH(-1, "word");
      },
      goGroupRight: function(e) {
        return e.moveH(1, "group");
      },
      goGroupLeft: function(e) {
        return e.moveH(-1, "group");
      },
      goWordRight: function(e) {
        return e.moveH(1, "word");
      },
      delCharBefore: function(e) {
        return e.deleteH(-1, "codepoint");
      },
      delCharAfter: function(e) {
        return e.deleteH(1, "char");
      },
      delWordBefore: function(e) {
        return e.deleteH(-1, "word");
      },
      delWordAfter: function(e) {
        return e.deleteH(1, "word");
      },
      delGroupBefore: function(e) {
        return e.deleteH(-1, "group");
      },
      delGroupAfter: function(e) {
        return e.deleteH(1, "group");
      },
      indentAuto: function(e) {
        return e.indentSelection("smart");
      },
      indentMore: function(e) {
        return e.indentSelection("add");
      },
      indentLess: function(e) {
        return e.indentSelection("subtract");
      },
      insertTab: function(e) {
        return e.replaceSelection("	");
      },
      insertSoftTab: function(e) {
        for (var t = [], i = e.listSelections(), r = e.options.tabSize, n = 0; n < i.length; n++) {
          var a = i[n].from(), l = Xe(e.getLine(a.line), a.ch, r);
          t.push(Wt(r - l % r));
        }
        e.replaceSelections(t);
      },
      defaultTab: function(e) {
        e.somethingSelected() ? e.indentSelection("add") : e.execCommand("insertTab");
      },
      // Swap the two chars left and right of each selection's head.
      // Move cursor behind the two swapped characters afterwards.
      //
      // Doesn't consider line feeds a character.
      // Doesn't scan more than one line above to find a character.
      // Doesn't do anything on an empty line.
      // Doesn't do anything with non-empty selections.
      transposeChars: function(e) {
        return St(e, function() {
          for (var t = e.listSelections(), i = [], r = 0; r < t.length; r++)
            if (t[r].empty()) {
              var n = t[r].head, a = me(e.doc, n.line).text;
              if (a) {
                if (n.ch == a.length && (n = new $(n.line, n.ch - 1)), n.ch > 0)
                  n = new $(n.line, n.ch + 1), e.replaceRange(
                    a.charAt(n.ch - 1) + a.charAt(n.ch - 2),
                    $(n.line, n.ch - 2),
                    n,
                    "+transpose"
                  );
                else if (n.line > e.doc.first) {
                  var l = me(e.doc, n.line - 1).text;
                  l && (n = new $(n.line, 1), e.replaceRange(
                    a.charAt(0) + e.doc.lineSeparator() + l.charAt(l.length - 1),
                    $(n.line - 1, l.length - 1),
                    n,
                    "+transpose"
                  ));
                }
              }
              i.push(new Re(n, n));
            }
          e.setSelections(i);
        });
      },
      newlineAndIndent: function(e) {
        return St(e, function() {
          for (var t = e.listSelections(), i = t.length - 1; i >= 0; i--)
            e.replaceRange(e.doc.lineSeparator(), t[i].anchor, t[i].head, "+input");
          t = e.listSelections();
          for (var r = 0; r < t.length; r++)
            e.indentLine(t[r].from().line, null, !0);
          Pr(e);
        });
      },
      openLine: function(e) {
        return e.replaceSelection(`
`, "start");
      },
      toggleOverwrite: function(e) {
        return e.toggleOverwrite();
      }
    };
    function Fo(e, t) {
      var i = me(e.doc, t), r = Ot(i);
      return r != i && (t = Pe(r)), Fa(!0, e, r, t, 1);
    }
    function Gs(e, t) {
      var i = me(e.doc, t), r = Au(i);
      return r != i && (t = Pe(r)), Fa(!0, e, i, t, -1);
    }
    function Ao(e, t) {
      var i = Fo(e, t.line), r = me(e.doc, i.line), n = ue(r, e.doc.direction);
      if (!n || n[0].level == 0) {
        var a = Math.max(i.ch, r.text.search(/\S/)), l = t.line == i.line && t.ch <= a && t.ch;
        return $(i.line, l ? 0 : a, i.sticky);
      }
      return i;
    }
    function ln(e, t, i) {
      if (typeof t == "string" && (t = ki[t], !t))
        return !1;
      e.display.input.ensurePolled();
      var r = e.display.shift, n = !1;
      try {
        e.isReadOnly() && (e.state.suppressEdits = !0), i && (e.display.shift = !1), n = t(e) != Je;
      } finally {
        e.display.shift = r, e.state.suppressEdits = !1;
      }
      return n;
    }
    function js(e, t, i) {
      for (var r = 0; r < e.state.keyMaps.length; r++) {
        var n = Kr(t, e.state.keyMaps[r], i, e);
        if (n)
          return n;
      }
      return e.options.extraKeys && Kr(t, e.options.extraKeys, i, e) || Kr(t, e.options.keyMap, i, e);
    }
    var Ks = new nt();
    function Si(e, t, i, r) {
      var n = e.state.keySeq;
      if (n) {
        if (wo(t))
          return "handled";
        if (/\'$/.test(t) ? e.state.keySeq = null : Ks.set(50, function() {
          e.state.keySeq == n && (e.state.keySeq = null, e.display.input.reset());
        }), Eo(e, n + " " + t, i, r))
          return !0;
      }
      return Eo(e, t, i, r);
    }
    function Eo(e, t, i, r) {
      var n = js(e, t, r);
      return n == "multi" && (e.state.keySeq = t), n == "handled" && ot(e, "keyHandled", e, t, i), (n == "handled" || n == "multi") && (Ye(i), ua(e)), !!n;
    }
    function Lo(e, t) {
      var i = So(t, !0);
      return i ? t.shiftKey && !e.state.keySeq ? Si(e, "Shift-" + i, t, function(r) {
        return ln(e, r, !0);
      }) || Si(e, i, t, function(r) {
        if (typeof r == "string" ? /^go[A-Z]/.test(r) : r.motion)
          return ln(e, r);
      }) : Si(e, i, t, function(r) {
        return ln(e, r);
      }) : !1;
    }
    function Xs(e, t, i) {
      return Si(e, "'" + i + "'", t, function(r) {
        return ln(e, r, !0);
      });
    }
    var Aa = null;
    function To(e) {
      var t = this;
      if (!(e.target && e.target != t.display.input.getField()) && (t.curOp.focus = Me(j(t)), !Le(t, e))) {
        x && A < 11 && e.keyCode == 27 && (e.returnValue = !1);
        var i = e.keyCode;
        t.display.shift = i == 16 || e.shiftKey;
        var r = Lo(t, e);
        X && (Aa = r ? i : null, !r && i == 88 && !cu && (_ ? e.metaKey : e.ctrlKey) && t.replaceSelection("", null, "cut")), m && !_ && !r && i == 46 && e.shiftKey && !e.ctrlKey && document.execCommand && document.execCommand("cut"), i == 18 && !/\bCodeMirror-crosshair\b/.test(t.display.lineDiv.className) && Ys(t);
      }
    }
    function Ys(e) {
      var t = e.display.lineDiv;
      et(t, "CodeMirror-crosshair");
      function i(r) {
        (r.keyCode == 18 || !r.altKey) && (Se(t, "CodeMirror-crosshair"), Oe(document, "keyup", i), Oe(document, "mouseover", i));
      }
      U(document, "keyup", i), U(document, "mouseover", i);
    }
    function Bo(e) {
      e.keyCode == 16 && (this.doc.sel.shift = !1), Le(this, e);
    }
    function Mo(e) {
      var t = this;
      if (!(e.target && e.target != t.display.input.getField()) && !($t(t.display, e) || Le(t, e) || e.ctrlKey && !e.altKey || _ && e.metaKey)) {
        var i = e.keyCode, r = e.charCode;
        if (X && i == Aa) {
          Aa = null, Ye(e);
          return;
        }
        if (!(X && (!e.which || e.which < 10) && Lo(t, e))) {
          var n = String.fromCharCode(r ?? i);
          n != "\b" && (Xs(t, e, n) || t.display.input.onKeyPress(e));
        }
      }
    }
    var Zs = 400, Ea = function(e, t, i) {
      this.time = e, this.pos = t, this.button = i;
    };
    Ea.prototype.compare = function(e, t, i) {
      return this.time + Zs > e && Fe(t, this.pos) == 0 && i == this.button;
    };
    var Fi, Ai;
    function Qs(e, t) {
      var i = +/* @__PURE__ */ new Date();
      return Ai && Ai.compare(i, e, t) ? (Fi = Ai = null, "triple") : Fi && Fi.compare(i, e, t) ? (Ai = new Ea(i, e, t), Fi = null, "double") : (Fi = new Ea(i, e, t), Ai = null, "single");
    }
    function No(e) {
      var t = this, i = t.display;
      if (!(Le(t, e) || i.activeTouch && i.input.supportsTouch())) {
        if (i.input.ensurePolled(), i.shift = e.shiftKey, $t(i, e)) {
          z || (i.scroller.draggable = !1, setTimeout(function() {
            return i.scroller.draggable = !0;
          }, 100));
          return;
        }
        if (!La(t, e)) {
          var r = yr(t, e), n = rr(e), a = r ? Qs(r, n) : "single";
          Ee(t).focus(), n == 1 && t.state.selectingText && t.state.selectingText(e), !(r && $s(t, n, r, a, e)) && (n == 1 ? r ? Vs(t, r, a, e) : ei(e) == i.scroller && Ye(e) : n == 2 ? (r && Vi(t.doc, r), setTimeout(function() {
            return i.input.focus();
          }, 20)) : n == 3 && (qe ? t.display.input.onContextMenu(e) : sa(t)));
        }
      }
    }
    function $s(e, t, i, r, n) {
      var a = "Click";
      return r == "double" ? a = "Double" + a : r == "triple" && (a = "Triple" + a), a = (t == 1 ? "Left" : t == 2 ? "Middle" : "Right") + a, Si(e, ko(a, n), n, function(l) {
        if (typeof l == "string" && (l = ki[l]), !l)
          return !1;
        var o = !1;
        try {
          e.isReadOnly() && (e.state.suppressEdits = !0), o = l(e, i) != Je;
        } finally {
          e.state.suppressEdits = !1;
        }
        return o;
      });
    }
    function Js(e, t, i) {
      var r = e.getOption("configureMouse"), n = r ? r(e, t, i) : {};
      if (n.unit == null) {
        var a = te ? i.shiftKey && i.metaKey : i.altKey;
        n.unit = a ? "rectangle" : t == "single" ? "char" : t == "double" ? "word" : "line";
      }
      return (n.extend == null || e.doc.extend) && (n.extend = e.doc.extend || i.shiftKey), n.addNew == null && (n.addNew = _ ? i.metaKey : i.ctrlKey), n.moveOnDrag == null && (n.moveOnDrag = !(_ ? i.altKey : i.ctrlKey)), n;
    }
    function Vs(e, t, i, r) {
      x ? setTimeout($e(Nl, e), 0) : e.curOp.focus = Me(j(e));
      var n = Js(e, i, r), a = e.doc.sel, l;
      e.options.dragDrop && ou && !e.isReadOnly() && i == "single" && (l = a.contains(t)) > -1 && (Fe((l = a.ranges[l]).from(), t) < 0 || t.xRel > 0) && (Fe(l.to(), t) > 0 || t.xRel < 0) ? ef(e, r, t, n) : tf(e, r, t, n);
    }
    function ef(e, t, i, r) {
      var n = e.display, a = !1, l = ut(e, function(f) {
        z && (n.scroller.draggable = !1), e.state.draggingText = !1, e.state.delayingBlurEvent && (e.hasFocus() ? e.state.delayingBlurEvent = !1 : sa(e)), Oe(n.wrapper.ownerDocument, "mouseup", l), Oe(n.wrapper.ownerDocument, "mousemove", o), Oe(n.scroller, "dragstart", u), Oe(n.scroller, "drop", l), a || (Ye(f), r.addNew || Vi(e.doc, i, null, null, r.extend), z && !le || x && A == 9 ? setTimeout(function() {
          n.wrapper.ownerDocument.body.focus({ preventScroll: !0 }), n.input.focus();
        }, 20) : n.input.focus());
      }), o = function(f) {
        a = a || Math.abs(t.clientX - f.clientX) + Math.abs(t.clientY - f.clientY) >= 10;
      }, u = function() {
        return a = !0;
      };
      z && (n.scroller.draggable = !0), e.state.draggingText = l, l.copy = !r.moveOnDrag, U(n.wrapper.ownerDocument, "mouseup", l), U(n.wrapper.ownerDocument, "mousemove", o), U(n.scroller, "dragstart", u), U(n.scroller, "drop", l), e.state.delayingBlurEvent = !0, setTimeout(function() {
        return n.input.focus();
      }, 20), n.scroller.dragDrop && n.scroller.dragDrop();
    }
    function Io(e, t, i) {
      if (i == "char")
        return new Re(t, t);
      if (i == "word")
        return e.findWordAt(t);
      if (i == "line")
        return new Re($(t.line, 0), Ae(e.doc, $(t.line + 1, 0)));
      var r = i(e, t);
      return new Re(r.from, r.to);
    }
    function tf(e, t, i, r) {
      x && sa(e);
      var n = e.display, a = e.doc;
      Ye(t);
      var l, o, u = a.sel, f = u.ranges;
      if (r.addNew && !r.extend ? (o = a.sel.contains(i), o > -1 ? l = f[o] : l = new Re(i, i)) : (l = a.sel.primary(), o = a.sel.primIndex), r.unit == "rectangle")
        r.addNew || (l = new Re(i, i)), i = yr(e, t, !0, !0), o = -1;
      else {
        var D = Io(e, i, r.unit);
        r.extend ? l = Ca(l, D.anchor, D.head, r.extend) : l = D;
      }
      r.addNew ? o == -1 ? (o = f.length, vt(
        a,
        Rt(e, f.concat([l]), o),
        { scroll: !1, origin: "*mouse" }
      )) : f.length > 1 && f[o].empty() && r.unit == "char" && !r.extend ? (vt(
        a,
        Rt(e, f.slice(0, o).concat(f.slice(o + 1)), 0),
        { scroll: !1, origin: "*mouse" }
      ), u = a.sel) : wa(a, o, l, ye) : (o = 0, vt(a, new Lt([l], 0), ye), u = a.sel);
      var w = i;
      function M(ne) {
        if (Fe(w, ne) != 0)
          if (w = ne, r.unit == "rectangle") {
            for (var he = [], be = e.options.tabSize, xe = Xe(me(a, i.line).text, i.ch, be), Te = Xe(me(a, ne.line).text, ne.ch, be), Ue = Math.min(xe, Te), ft = Math.max(xe, Te), Ze = Math.min(i.line, ne.line), Ft = Math.min(e.lastLine(), Math.max(i.line, ne.line)); Ze <= Ft; Ze++) {
              var Ct = me(a, Ze).text, rt = Mt(Ct, Ue, be);
              Ue == ft ? he.push(new Re($(Ze, rt), $(Ze, rt))) : Ct.length > rt && he.push(new Re($(Ze, rt), $(Ze, Mt(Ct, ft, be))));
            }
            he.length || he.push(new Re(i, i)), vt(
              a,
              Rt(e, u.ranges.slice(0, o).concat(he), o),
              { origin: "*mouse", scroll: !1 }
            ), e.scrollIntoView(ne);
          } else {
            var wt = l, gt = Io(e, ne, r.unit), lt = wt.anchor, it;
            Fe(gt.anchor, lt) > 0 ? (it = gt.head, lt = Ni(wt.from(), gt.anchor)) : (it = gt.anchor, lt = Mi(wt.to(), gt.head));
            var Qe = u.ranges.slice(0);
            Qe[o] = rf(e, new Re(Ae(a, lt), it)), vt(a, Rt(e, Qe, o), ye);
          }
      }
      var L = n.wrapper.getBoundingClientRect(), W = 0;
      function K(ne) {
        var he = ++W, be = yr(e, ne, !0, r.unit == "rectangle");
        if (be)
          if (Fe(be, w) != 0) {
            e.curOp.focus = Me(j(e)), M(be);
            var xe = Xi(n, a);
            (be.line >= xe.to || be.line < xe.from) && setTimeout(ut(e, function() {
              W == he && K(ne);
            }), 150);
          } else {
            var Te = ne.clientY < L.top ? -20 : ne.clientY > L.bottom ? 20 : 0;
            Te && setTimeout(ut(e, function() {
              W == he && (n.scroller.scrollTop += Te, K(ne));
            }), 50);
          }
      }
      function ee(ne) {
        e.state.selectingText = !1, W = 1 / 0, ne && (Ye(ne), n.input.focus()), Oe(n.wrapper.ownerDocument, "mousemove", ie), Oe(n.wrapper.ownerDocument, "mouseup", se), a.history.lastSelOrigin = null;
      }
      var ie = ut(e, function(ne) {
        ne.buttons === 0 || !rr(ne) ? ee(ne) : K(ne);
      }), se = ut(e, ee);
      e.state.selectingText = se, U(n.wrapper.ownerDocument, "mousemove", ie), U(n.wrapper.ownerDocument, "mouseup", se);
    }
    function rf(e, t) {
      var i = t.anchor, r = t.head, n = me(e.doc, i.line);
      if (Fe(i, r) == 0 && i.sticky == r.sticky)
        return t;
      var a = ue(n);
      if (!a)
        return t;
      var l = ve(a, i.ch, i.sticky), o = a[l];
      if (o.from != i.ch && o.to != i.ch)
        return t;
      var u = l + (o.from == i.ch == (o.level != 1) ? 0 : 1);
      if (u == 0 || u == a.length)
        return t;
      var f;
      if (r.line != i.line)
        f = (r.line - i.line) * (e.doc.direction == "ltr" ? 1 : -1) > 0;
      else {
        var D = ve(a, r.ch, r.sticky), w = D - l || (r.ch - i.ch) * (o.level == 1 ? -1 : 1);
        D == u - 1 || D == u ? f = w < 0 : f = w > 0;
      }
      var M = a[u + (f ? -1 : 0)], L = f == (M.level == 1), W = L ? M.from : M.to, K = L ? "after" : "before";
      return i.ch == W && i.sticky == K ? t : new Re(new $(i.line, W, K), r);
    }
    function Oo(e, t, i, r) {
      var n, a;
      if (t.touches)
        n = t.touches[0].clientX, a = t.touches[0].clientY;
      else
        try {
          n = t.clientX, a = t.clientY;
        } catch {
          return !1;
        }
      if (n >= Math.floor(e.display.gutters.getBoundingClientRect().right))
        return !1;
      r && Ye(t);
      var l = e.display, o = l.lineDiv.getBoundingClientRect();
      if (a > o.bottom || !pt(e, i))
        return Yt(t);
      a -= o.top - l.viewOffset;
      for (var u = 0; u < e.display.gutterSpecs.length; ++u) {
        var f = l.gutters.childNodes[u];
        if (f && f.getBoundingClientRect().right >= n) {
          var D = vr(e.doc, a), w = e.display.gutterSpecs[u];
          return He(e, i, e, D, w.className, t), Yt(t);
        }
      }
    }
    function La(e, t) {
      return Oo(e, t, "gutterClick", !0);
    }
    function Ho(e, t) {
      $t(e.display, t) || nf(e, t) || Le(e, t, "contextmenu") || qe || e.display.input.onContextMenu(t);
    }
    function nf(e, t) {
      return pt(e, "gutterContextMenu") ? Oo(e, t, "gutterContextMenu", !1) : !1;
    }
    function Ro(e) {
      e.display.wrapper.className = e.display.wrapper.className.replace(/\s*cm-s-\S+/g, "") + e.options.theme.replace(/(^|\s)\s*/g, " cm-s-"), oi(e);
    }
    var Yr = { toString: function() {
      return "CodeMirror.Init";
    } }, zo = {}, on = {};
    function af(e) {
      var t = e.optionHandlers;
      function i(r, n, a, l) {
        e.defaults[r] = n, a && (t[r] = l ? function(o, u, f) {
          f != Yr && a(o, u, f);
        } : a);
      }
      e.defineOption = i, e.Init = Yr, i("value", "", function(r, n) {
        return r.setValue(n);
      }, !0), i("mode", null, function(r, n) {
        r.doc.modeOption = n, ya(r);
      }, !0), i("indentUnit", 2, ya, !0), i("indentWithTabs", !1), i("smartIndent", !0), i("tabSize", 4, function(r) {
        gi(r), oi(r), Dt(r);
      }, !0), i("lineSeparator", null, function(r, n) {
        if (r.doc.lineSep = n, !!n) {
          var a = [], l = r.doc.first;
          r.doc.iter(function(u) {
            for (var f = 0; ; ) {
              var D = u.text.indexOf(n, f);
              if (D == -1)
                break;
              f = D + n.length, a.push($(l, D));
            }
            l++;
          });
          for (var o = a.length - 1; o >= 0; o--)
            Gr(r.doc, n, a[o], $(a[o].line, a[o].ch + n.length));
        }
      }), i("specialChars", /[\u0000-\u001f\u007f-\u009f\u00ad\u061c\u200b\u200e\u200f\u2028\u2029\u202d\u202e\u2066\u2067\u2069\ufeff\ufff9-\ufffc]/g, function(r, n, a) {
        r.state.specialChars = new RegExp(n.source + (n.test("	") ? "" : "|	"), "g"), a != Yr && r.refresh();
      }), i("specialCharPlaceholder", Nu, function(r) {
        return r.refresh();
      }, !0), i("electricChars", !0), i("inputStyle", R ? "contenteditable" : "textarea", function() {
        throw new Error("inputStyle can not (yet) be changed in a running editor");
      }, !0), i("spellcheck", !1, function(r, n) {
        return r.getInputField().spellcheck = n;
      }, !0), i("autocorrect", !1, function(r, n) {
        return r.getInputField().autocorrect = n;
      }, !0), i("autocapitalize", !1, function(r, n) {
        return r.getInputField().autocapitalize = n;
      }, !0), i("rtlMoveVisually", !Y), i("wholeLineUpdateBefore", !0), i("theme", "default", function(r) {
        Ro(r), pi(r);
      }, !0), i("keyMap", "default", function(r, n, a) {
        var l = an(n), o = a != Yr && an(a);
        o && o.detach && o.detach(r, l), l.attach && l.attach(r, o || null);
      }), i("extraKeys", null), i("configureMouse", null), i("lineWrapping", !1, of, !0), i("gutters", [], function(r, n) {
        r.display.gutterSpecs = ma(n, r.options.lineNumbers), pi(r);
      }, !0), i("fixedGutter", !0, function(r, n) {
        r.display.gutters.style.left = n ? aa(r.display) + "px" : "0", r.refresh();
      }, !0), i("coverGutterNextToScrollbar", !1, function(r) {
        return Wr(r);
      }, !0), i("scrollbarStyle", "native", function(r) {
        Pl(r), Wr(r), r.display.scrollbars.setScrollTop(r.doc.scrollTop), r.display.scrollbars.setScrollLeft(r.doc.scrollLeft);
      }, !0), i("lineNumbers", !1, function(r, n) {
        r.display.gutterSpecs = ma(r.options.gutters, n), pi(r);
      }, !0), i("firstLineNumber", 1, pi, !0), i("lineNumberFormatter", function(r) {
        return r;
      }, pi, !0), i("showCursorWhenSelecting", !1, ui, !0), i("resetSelectionOnContextMenu", !0), i("lineWiseCopyCut", !0), i("pasteLinesPerSelection", !0), i("selectionsMayTouch", !1), i("readOnly", !1, function(r, n) {
        n == "nocursor" && (zr(r), r.display.input.blur()), r.display.input.readOnlyChanged(n);
      }), i("screenReaderLabel", null, function(r, n) {
        n = n === "" ? null : n, r.display.input.screenReaderLabelChanged(n);
      }), i("disableInput", !1, function(r, n) {
        n || r.display.input.reset();
      }, !0), i("dragDrop", !0, lf), i("allowDropFileTypes", null), i("cursorBlinkRate", 530), i("cursorScrollMargin", 0), i("cursorHeight", 1, ui, !0), i("singleCursorHeightPerLine", !0, ui, !0), i("workTime", 100), i("workDelay", 100), i("flattenSpans", !0, gi, !0), i("addModeClass", !1, gi, !0), i("pollInterval", 100), i("undoDepth", 200, function(r, n) {
        return r.doc.history.undoDepth = n;
      }), i("historyEventDelay", 1250), i("viewportMargin", 10, function(r) {
        return r.refresh();
      }, !0), i("maxHighlightLength", 1e4, gi, !0), i("moveInputWithCursor", !0, function(r, n) {
        n || r.display.input.resetPosition();
      }), i("tabindex", null, function(r, n) {
        return r.display.input.getField().tabIndex = n || "";
      }), i("autofocus", null), i("direction", "ltr", function(r, n) {
        return r.doc.setDirection(n);
      }, !0), i("phrases", null);
    }
    function lf(e, t, i) {
      var r = i && i != Yr;
      if (!t != !r) {
        var n = e.display.dragFunctions, a = t ? U : Oe;
        a(e.display.scroller, "dragstart", n.start), a(e.display.scroller, "dragenter", n.enter), a(e.display.scroller, "dragover", n.over), a(e.display.scroller, "dragleave", n.leave), a(e.display.scroller, "drop", n.drop);
      }
    }
    function of(e) {
      e.options.lineWrapping ? (et(e.display.wrapper, "CodeMirror-wrap"), e.display.sizer.style.minWidth = "", e.display.sizerWidth = null) : (Se(e.display.wrapper, "CodeMirror-wrap"), Zn(e)), la(e), Dt(e), oi(e), setTimeout(function() {
        return Wr(e);
      }, 100);
    }
    function je(e, t) {
      var i = this;
      if (!(this instanceof je))
        return new je(e, t);
      this.options = t = t ? ht(t) : {}, ht(zo, t, !1);
      var r = t.value;
      typeof r == "string" ? r = new bt(r, t.mode, null, t.lineSeparator, t.direction) : t.mode && (r.modeOption = t.mode), this.doc = r;
      var n = new je.inputStyles[t.inputStyle](this), a = this.display = new ys(e, r, n, t);
      a.wrapper.CodeMirror = this, Ro(this), t.lineWrapping && (this.display.wrapper.className += " CodeMirror-wrap"), Pl(this), this.state = {
        keyMaps: [],
        // stores maps added by addKeyMap
        overlays: [],
        // highlighting overlays, as added by addOverlay
        modeGen: 0,
        // bumped when mode/overlay changes, used to invalidate highlighting info
        overwrite: !1,
        delayingBlurEvent: !1,
        focused: !1,
        suppressEdits: !1,
        // used to disable editing during key handlers when in readOnly mode
        pasteIncoming: -1,
        cutIncoming: -1,
        // help recognize paste/cut edits in input.poll
        selectingText: !1,
        draggingText: !1,
        highlight: new nt(),
        // stores highlight worker timeout
        keySeq: null,
        // Unfinished key sequence
        specialChars: null
      }, t.autofocus && !R && a.input.focus(), x && A < 11 && setTimeout(function() {
        return i.display.input.reset(!0);
      }, 20), uf(this), zs(), wr(this), this.curOp.forceUpdate = !0, Zl(this, r), t.autofocus && !R || this.hasFocus() ? setTimeout(function() {
        i.hasFocus() && !i.state.focused && fa(i);
      }, 20) : zr(this);
      for (var l in on)
        on.hasOwnProperty(l) && on[l](this, t[l], Yr);
      Ul(this), t.finishInit && t.finishInit(this);
      for (var o = 0; o < Ta.length; ++o)
        Ta[o](this);
      kr(this), z && t.lineWrapping && getComputedStyle(a.lineDiv).textRendering == "optimizelegibility" && (a.lineDiv.style.textRendering = "auto");
    }
    je.defaults = zo, je.optionHandlers = on;
    function uf(e) {
      var t = e.display;
      U(t.scroller, "mousedown", ut(e, No)), x && A < 11 ? U(t.scroller, "dblclick", ut(e, function(u) {
        if (!Le(e, u)) {
          var f = yr(e, u);
          if (!(!f || La(e, u) || $t(e.display, u))) {
            Ye(u);
            var D = e.findWordAt(f);
            Vi(e.doc, D.anchor, D.head);
          }
        }
      })) : U(t.scroller, "dblclick", function(u) {
        return Le(e, u) || Ye(u);
      }), U(t.scroller, "contextmenu", function(u) {
        return Ho(e, u);
      }), U(t.input.getField(), "contextmenu", function(u) {
        t.scroller.contains(u.target) || Ho(e, u);
      });
      var i, r = { end: 0 };
      function n() {
        t.activeTouch && (i = setTimeout(function() {
          return t.activeTouch = null;
        }, 1e3), r = t.activeTouch, r.end = +/* @__PURE__ */ new Date());
      }
      function a(u) {
        if (u.touches.length != 1)
          return !1;
        var f = u.touches[0];
        return f.radiusX <= 1 && f.radiusY <= 1;
      }
      function l(u, f) {
        if (f.left == null)
          return !0;
        var D = f.left - u.left, w = f.top - u.top;
        return D * D + w * w > 20 * 20;
      }
      U(t.scroller, "touchstart", function(u) {
        if (!Le(e, u) && !a(u) && !La(e, u)) {
          t.input.ensurePolled(), clearTimeout(i);
          var f = +/* @__PURE__ */ new Date();
          t.activeTouch = {
            start: f,
            moved: !1,
            prev: f - r.end <= 300 ? r : null
          }, u.touches.length == 1 && (t.activeTouch.left = u.touches[0].pageX, t.activeTouch.top = u.touches[0].pageY);
        }
      }), U(t.scroller, "touchmove", function() {
        t.activeTouch && (t.activeTouch.moved = !0);
      }), U(t.scroller, "touchend", function(u) {
        var f = t.activeTouch;
        if (f && !$t(t, u) && f.left != null && !f.moved && /* @__PURE__ */ new Date() - f.start < 300) {
          var D = e.coordsChar(t.activeTouch, "page"), w;
          !f.prev || l(f, f.prev) ? w = new Re(D, D) : !f.prev.prev || l(f, f.prev.prev) ? w = e.findWordAt(D) : w = new Re($(D.line, 0), Ae(e.doc, $(D.line + 1, 0))), e.setSelection(w.anchor, w.head), e.focus(), Ye(u);
        }
        n();
      }), U(t.scroller, "touchcancel", n), U(t.scroller, "scroll", function() {
        t.scroller.clientHeight && (fi(e, t.scroller.scrollTop), br(e, t.scroller.scrollLeft, !0), He(e, "scroll", e));
      }), U(t.scroller, "mousewheel", function(u) {
        return jl(e, u);
      }), U(t.scroller, "DOMMouseScroll", function(u) {
        return jl(e, u);
      }), U(t.wrapper, "scroll", function() {
        return t.wrapper.scrollTop = t.wrapper.scrollLeft = 0;
      }), t.dragFunctions = {
        enter: function(u) {
          Le(e, u) || It(u);
        },
        over: function(u) {
          Le(e, u) || (Rs(e, u), It(u));
        },
        start: function(u) {
          return Hs(e, u);
        },
        drop: ut(e, Os),
        leave: function(u) {
          Le(e, u) || Do(e);
        }
      };
      var o = t.input.getField();
      U(o, "keyup", function(u) {
        return Bo.call(e, u);
      }), U(o, "keydown", ut(e, To)), U(o, "keypress", ut(e, Mo)), U(o, "focus", function(u) {
        return fa(e, u);
      }), U(o, "blur", function(u) {
        return zr(e, u);
      });
    }
    var Ta = [];
    je.defineInitHook = function(e) {
      return Ta.push(e);
    };
    function Ei(e, t, i, r) {
      var n = e.doc, a;
      i == null && (i = "add"), i == "smart" && (n.mode.indent ? a = ri(e, t).state : i = "prev");
      var l = e.options.tabSize, o = me(n, t), u = Xe(o.text, null, l);
      o.stateAfter && (o.stateAfter = null);
      var f = o.text.match(/^\s*/)[0], D;
      if (!r && !/\S/.test(o.text))
        D = 0, i = "not";
      else if (i == "smart" && (D = n.mode.indent(a, o.text.slice(f.length), o.text), D == Je || D > 150)) {
        if (!r)
          return;
        i = "prev";
      }
      i == "prev" ? t > n.first ? D = Xe(me(n, t - 1).text, null, l) : D = 0 : i == "add" ? D = u + e.options.indentUnit : i == "subtract" ? D = u - e.options.indentUnit : typeof i == "number" && (D = u + i), D = Math.max(0, D);
      var w = "", M = 0;
      if (e.options.indentWithTabs)
        for (var L = Math.floor(D / l); L; --L)
          M += l, w += "	";
      if (M < D && (w += Wt(D - M)), w != f)
        return Gr(n, w, $(t, 0), $(t, f.length), "+input"), o.stateAfter = null, !0;
      for (var W = 0; W < n.sel.ranges.length; W++) {
        var K = n.sel.ranges[W];
        if (K.head.line == t && K.head.ch < f.length) {
          var ee = $(t, f.length);
          wa(n, W, new Re(ee, ee));
          break;
        }
      }
    }
    var zt = null;
    function un(e) {
      zt = e;
    }
    function Ba(e, t, i, r, n) {
      var a = e.doc;
      e.display.shift = !1, r || (r = a.sel);
      var l = +/* @__PURE__ */ new Date() - 200, o = n == "paste" || e.state.pasteIncoming > l, u = In(t), f = null;
      if (o && r.ranges.length > 1)
        if (zt && zt.text.join(`
`) == t) {
          if (r.ranges.length % zt.text.length == 0) {
            f = [];
            for (var D = 0; D < zt.text.length; D++)
              f.push(a.splitLines(zt.text[D]));
          }
        } else
          u.length == r.ranges.length && e.options.pasteLinesPerSelection && (f = Et(u, function(ie) {
            return [ie];
          }));
      for (var w = e.curOp.updateInput, M = r.ranges.length - 1; M >= 0; M--) {
        var L = r.ranges[M], W = L.from(), K = L.to();
        L.empty() && (i && i > 0 ? W = $(W.line, W.ch - i) : e.state.overwrite && !o ? K = $(K.line, Math.min(me(a, K.line).text.length, K.ch + Be(u).length)) : o && zt && zt.lineWise && zt.text.join(`
`) == u.join(`
`) && (W = K = $(W.line, 0)));
        var ee = {
          from: W,
          to: K,
          text: f ? f[M % f.length] : u,
          origin: n || (o ? "paste" : e.state.cutIncoming > l ? "cut" : "+input")
        };
        qr(e.doc, ee), ot(e, "inputRead", e, ee);
      }
      t && !o && Wo(e, t), Pr(e), e.curOp.updateInput < 2 && (e.curOp.updateInput = w), e.curOp.typing = !0, e.state.pasteIncoming = e.state.cutIncoming = -1;
    }
    function Po(e, t) {
      var i = e.clipboardData && e.clipboardData.getData("Text");
      if (i)
        return e.preventDefault(), !t.isReadOnly() && !t.options.disableInput && t.hasFocus() && St(t, function() {
          return Ba(t, i, 0, null, "paste");
        }), !0;
    }
    function Wo(e, t) {
      if (!(!e.options.electricChars || !e.options.smartIndent))
        for (var i = e.doc.sel, r = i.ranges.length - 1; r >= 0; r--) {
          var n = i.ranges[r];
          if (!(n.head.ch > 100 || r && i.ranges[r - 1].head.line == n.head.line)) {
            var a = e.getModeAt(n.head), l = !1;
            if (a.electricChars) {
              for (var o = 0; o < a.electricChars.length; o++)
                if (t.indexOf(a.electricChars.charAt(o)) > -1) {
                  l = Ei(e, n.head.line, "smart");
                  break;
                }
            } else
              a.electricInput && a.electricInput.test(me(e.doc, n.head.line).text.slice(0, n.head.ch)) && (l = Ei(e, n.head.line, "smart"));
            l && ot(e, "electricInput", e, n.head.line);
          }
        }
    }
    function _o(e) {
      for (var t = [], i = [], r = 0; r < e.doc.sel.ranges.length; r++) {
        var n = e.doc.sel.ranges[r].head.line, a = { anchor: $(n, 0), head: $(n + 1, 0) };
        i.push(a), t.push(e.getRange(a.anchor, a.head));
      }
      return { text: t, ranges: i };
    }
    function Ma(e, t, i, r) {
      e.setAttribute("autocorrect", i ? "on" : "off"), e.setAttribute("autocapitalize", r ? "on" : "off"), e.setAttribute("spellcheck", !!t);
    }
    function Uo() {
      var e = T("textarea", null, null, "position: absolute; bottom: -1em; padding: 0; width: 1px; height: 1em; min-height: 1em; outline: none"), t = T("div", [e], null, "overflow: hidden; position: relative; width: 3px; height: 0px;");
      return z ? e.style.width = "1000px" : e.setAttribute("wrap", "off"), H && (e.style.border = "1px solid black"), t;
    }
    function sf(e) {
      var t = e.optionHandlers, i = e.helpers = {};
      e.prototype = {
        constructor: e,
        focus: function() {
          Ee(this).focus(), this.display.input.focus();
        },
        setOption: function(r, n) {
          var a = this.options, l = a[r];
          a[r] == n && r != "mode" || (a[r] = n, t.hasOwnProperty(r) && ut(this, t[r])(this, n, l), He(this, "optionChange", this, r));
        },
        getOption: function(r) {
          return this.options[r];
        },
        getDoc: function() {
          return this.doc;
        },
        addKeyMap: function(r, n) {
          this.state.keyMaps[n ? "push" : "unshift"](an(r));
        },
        removeKeyMap: function(r) {
          for (var n = this.state.keyMaps, a = 0; a < n.length; ++a)
            if (n[a] == r || n[a].name == r)
              return n.splice(a, 1), !0;
        },
        addOverlay: xt(function(r, n) {
          var a = r.token ? r : e.getMode(this.options, r);
          if (a.startState)
            throw new Error("Overlays may not be stateful.");
          _t(
            this.state.overlays,
            {
              mode: a,
              modeSpec: r,
              opaque: n && n.opaque,
              priority: n && n.priority || 0
            },
            function(l) {
              return l.priority;
            }
          ), this.state.modeGen++, Dt(this);
        }),
        removeOverlay: xt(function(r) {
          for (var n = this.state.overlays, a = 0; a < n.length; ++a) {
            var l = n[a].modeSpec;
            if (l == r || typeof r == "string" && l.name == r) {
              n.splice(a, 1), this.state.modeGen++, Dt(this);
              return;
            }
          }
        }),
        indentLine: xt(function(r, n, a) {
          typeof n != "string" && typeof n != "number" && (n == null ? n = this.options.smartIndent ? "smart" : "prev" : n = n ? "add" : "subtract"), ti(this.doc, r) && Ei(this, r, n, a);
        }),
        indentSelection: xt(function(r) {
          for (var n = this.doc.sel.ranges, a = -1, l = 0; l < n.length; l++) {
            var o = n[l];
            if (o.empty())
              o.head.line > a && (Ei(this, o.head.line, r, !0), a = o.head.line, l == this.doc.sel.primIndex && Pr(this));
            else {
              var u = o.from(), f = o.to(), D = Math.max(a, u.line);
              a = Math.min(this.lastLine(), f.line - (f.ch ? 0 : 1)) + 1;
              for (var w = D; w < a; ++w)
                Ei(this, w, r);
              var M = this.doc.sel.ranges;
              u.ch == 0 && n.length == M.length && M[l].from().ch > 0 && wa(this.doc, l, new Re(u, M[l].to()), dt);
            }
          }
        }),
        // Fetch the parser token for a given character. Useful for hacks
        // that want to inspect the mode state (say, for completion).
        getTokenAt: function(r, n) {
          return $a(this, r, n);
        },
        getLineTokens: function(r, n) {
          return $a(this, $(r), n, !0);
        },
        getTokenTypeAt: function(r) {
          r = Ae(this.doc, r);
          var n = Ya(this, me(this.doc, r.line)), a = 0, l = (n.length - 1) / 2, o = r.ch, u;
          if (o == 0)
            u = n[2];
          else
            for (; ; ) {
              var f = a + l >> 1;
              if ((f ? n[f * 2 - 1] : 0) >= o)
                l = f;
              else if (n[f * 2 + 1] < o)
                a = f + 1;
              else {
                u = n[f * 2 + 2];
                break;
              }
            }
          var D = u ? u.indexOf("overlay ") : -1;
          return D < 0 ? u : D == 0 ? null : u.slice(0, D - 1);
        },
        getModeAt: function(r) {
          var n = this.doc.mode;
          return n.innerMode ? e.innerMode(n, this.getTokenAt(r).state).mode : n;
        },
        getHelper: function(r, n) {
          return this.getHelpers(r, n)[0];
        },
        getHelpers: function(r, n) {
          var a = [];
          if (!i.hasOwnProperty(n))
            return a;
          var l = i[n], o = this.getModeAt(r);
          if (typeof o[n] == "string")
            l[o[n]] && a.push(l[o[n]]);
          else if (o[n])
            for (var u = 0; u < o[n].length; u++) {
              var f = l[o[n][u]];
              f && a.push(f);
            }
          else
            o.helperType && l[o.helperType] ? a.push(l[o.helperType]) : l[o.name] && a.push(l[o.name]);
          for (var D = 0; D < l._global.length; D++) {
            var w = l._global[D];
            w.pred(o, this) && Ie(a, w.val) == -1 && a.push(w.val);
          }
          return a;
        },
        getStateAfter: function(r, n) {
          var a = this.doc;
          return r = ja(a, r ?? a.first + a.size - 1), ri(this, r + 1, n).state;
        },
        cursorCoords: function(r, n) {
          var a, l = this.doc.sel.primary();
          return r == null ? a = l.head : typeof r == "object" ? a = Ae(this.doc, r) : a = r ? l.from() : l.to(), Ht(this, a, n || "page");
        },
        charCoords: function(r, n) {
          return qi(this, Ae(this.doc, r), n || "page");
        },
        coordsChar: function(r, n) {
          return r = Fl(this, r, n || "page"), ra(this, r.left, r.top);
        },
        lineAtHeight: function(r, n) {
          return r = Fl(this, { top: r, left: 0 }, n || "page").top, vr(this.doc, r + this.display.viewOffset);
        },
        heightAtLine: function(r, n, a) {
          var l = !1, o;
          if (typeof r == "number") {
            var u = this.doc.first + this.doc.size - 1;
            r < this.doc.first ? r = this.doc.first : r > u && (r = u, l = !0), o = me(this.doc, r);
          } else
            o = r;
          return Ui(this, o, { top: 0, left: 0 }, n || "page", a || l).top + (l ? this.doc.height - Qt(o) : 0);
        },
        defaultTextHeight: function() {
          return Hr(this.display);
        },
        defaultCharWidth: function() {
          return Rr(this.display);
        },
        getViewport: function() {
          return { from: this.display.viewFrom, to: this.display.viewTo };
        },
        addWidget: function(r, n, a, l, o) {
          var u = this.display;
          r = Ht(this, Ae(this.doc, r));
          var f = r.bottom, D = r.left;
          if (n.style.position = "absolute", n.setAttribute("cm-ignore-events", "true"), this.display.input.setUneditable(n), u.sizer.appendChild(n), l == "over")
            f = r.top;
          else if (l == "above" || l == "near") {
            var w = Math.max(u.wrapper.clientHeight, this.doc.height), M = Math.max(u.sizer.clientWidth, u.lineSpace.clientWidth);
            (l == "above" || r.bottom + n.offsetHeight > w) && r.top > n.offsetHeight ? f = r.top - n.offsetHeight : r.bottom + n.offsetHeight <= w && (f = r.bottom), D + n.offsetWidth > M && (D = M - n.offsetWidth);
          }
          n.style.top = f + "px", n.style.left = n.style.right = "", o == "right" ? (D = u.sizer.clientWidth - n.offsetWidth, n.style.right = "0px") : (o == "left" ? D = 0 : o == "middle" && (D = (u.sizer.clientWidth - n.offsetWidth) / 2), n.style.left = D + "px"), a && as(this, { left: D, top: f, right: D + n.offsetWidth, bottom: f + n.offsetHeight });
        },
        triggerOnKeyDown: xt(To),
        triggerOnKeyPress: xt(Mo),
        triggerOnKeyUp: Bo,
        triggerOnMouseDown: xt(No),
        execCommand: function(r) {
          if (ki.hasOwnProperty(r))
            return ki[r].call(null, this);
        },
        triggerElectric: xt(function(r) {
          Wo(this, r);
        }),
        findPosH: function(r, n, a, l) {
          var o = 1;
          n < 0 && (o = -1, n = -n);
          for (var u = Ae(this.doc, r), f = 0; f < n && (u = Na(this.doc, u, o, a, l), !u.hitSide); ++f)
            ;
          return u;
        },
        moveH: xt(function(r, n) {
          var a = this;
          this.extendSelectionsBy(function(l) {
            return a.display.shift || a.doc.extend || l.empty() ? Na(a.doc, l.head, r, n, a.options.rtlMoveVisually) : r < 0 ? l.from() : l.to();
          }, Bt);
        }),
        deleteH: xt(function(r, n) {
          var a = this.doc.sel, l = this.doc;
          a.somethingSelected() ? l.replaceSelection("", null, "+delete") : Xr(this, function(o) {
            var u = Na(l, o.head, r, n, !1);
            return r < 0 ? { from: u, to: o.head } : { from: o.head, to: u };
          });
        }),
        findPosV: function(r, n, a, l) {
          var o = 1, u = l;
          n < 0 && (o = -1, n = -n);
          for (var f = Ae(this.doc, r), D = 0; D < n; ++D) {
            var w = Ht(this, f, "div");
            if (u == null ? u = w.left : w.left = u, f = qo(this, w, o, a), f.hitSide)
              break;
          }
          return f;
        },
        moveV: xt(function(r, n) {
          var a = this, l = this.doc, o = [], u = !this.display.shift && !l.extend && l.sel.somethingSelected();
          if (l.extendSelectionsBy(function(D) {
            if (u)
              return r < 0 ? D.from() : D.to();
            var w = Ht(a, D.head, "div");
            D.goalColumn != null && (w.left = D.goalColumn), o.push(w.left);
            var M = qo(a, w, r, n);
            return n == "page" && D == l.sel.primary() && ha(a, qi(a, M, "div").top - w.top), M;
          }, Bt), o.length)
            for (var f = 0; f < l.sel.ranges.length; f++)
              l.sel.ranges[f].goalColumn = o[f];
        }),
        // Find the word at the given position (as returned by coordsChar).
        findWordAt: function(r) {
          var n = this.doc, a = me(n, r.line).text, l = r.ch, o = r.ch;
          if (a) {
            var u = this.getHelper(r, "wordChars");
            (r.sticky == "before" || o == a.length) && l ? --l : ++o;
            for (var f = a.charAt(l), D = h(f, u) ? function(w) {
              return h(w, u);
            } : /\s/.test(f) ? function(w) {
              return /\s/.test(w);
            } : function(w) {
              return !/\s/.test(w) && !h(w);
            }; l > 0 && D(a.charAt(l - 1)); )
              --l;
            for (; o < a.length && D(a.charAt(o)); )
              ++o;
          }
          return new Re($(r.line, l), $(r.line, o));
        },
        toggleOverwrite: function(r) {
          r != null && r == this.state.overwrite || ((this.state.overwrite = !this.state.overwrite) ? et(this.display.cursorDiv, "CodeMirror-overwrite") : Se(this.display.cursorDiv, "CodeMirror-overwrite"), He(this, "overwriteToggle", this, this.state.overwrite));
        },
        hasFocus: function() {
          return this.display.input.getField() == Me(j(this));
        },
        isReadOnly: function() {
          return !!(this.options.readOnly || this.doc.cantEdit);
        },
        scrollTo: xt(function(r, n) {
          si(this, r, n);
        }),
        getScrollInfo: function() {
          var r = this.display.scroller;
          return {
            left: r.scrollLeft,
            top: r.scrollTop,
            height: r.scrollHeight - Gt(this) - this.display.barHeight,
            width: r.scrollWidth - Gt(this) - this.display.barWidth,
            clientHeight: Jn(this),
            clientWidth: mr(this)
          };
        },
        scrollIntoView: xt(function(r, n) {
          r == null ? (r = { from: this.doc.sel.primary().head, to: null }, n == null && (n = this.options.cursorScrollMargin)) : typeof r == "number" ? r = { from: $(r, 0), to: null } : r.from == null && (r = { from: r, to: null }), r.to || (r.to = r.from), r.margin = n || 0, r.from.line != null ? ls(this, r) : Ol(this, r.from, r.to, r.margin);
        }),
        setSize: xt(function(r, n) {
          var a = this, l = function(u) {
            return typeof u == "number" || /^\d+$/.test(String(u)) ? u + "px" : u;
          };
          r != null && (this.display.wrapper.style.width = l(r)), n != null && (this.display.wrapper.style.height = l(n)), this.options.lineWrapping && wl(this);
          var o = this.display.viewFrom;
          this.doc.iter(o, this.display.viewTo, function(u) {
            if (u.widgets) {
              for (var f = 0; f < u.widgets.length; f++)
                if (u.widgets[f].noHScroll) {
                  nr(a, o, "widget");
                  break;
                }
            }
            ++o;
          }), this.curOp.forceUpdate = !0, He(this, "refresh", this);
        }),
        operation: function(r) {
          return St(this, r);
        },
        startOperation: function() {
          return wr(this);
        },
        endOperation: function() {
          return kr(this);
        },
        refresh: xt(function() {
          var r = this.display.cachedTextHeight;
          Dt(this), this.curOp.forceUpdate = !0, oi(this), si(this, this.doc.scrollLeft, this.doc.scrollTop), ga(this.display), (r == null || Math.abs(r - Hr(this.display)) > 0.5 || this.options.lineWrapping) && la(this), He(this, "refresh", this);
        }),
        swapDoc: xt(function(r) {
          var n = this.doc;
          return n.cm = null, this.state.selectingText && this.state.selectingText(), Zl(this, r), oi(this), this.display.input.reset(), si(this, r.scrollLeft, r.scrollTop), this.curOp.forceScroll = !0, ot(this, "swapDoc", this, n), n;
        }),
        phrase: function(r) {
          var n = this.options.phrases;
          return n && Object.prototype.hasOwnProperty.call(n, r) ? n[r] : r;
        },
        getInputField: function() {
          return this.display.input.getField();
        },
        getWrapperElement: function() {
          return this.display.wrapper;
        },
        getScrollerElement: function() {
          return this.display.scroller;
        },
        getGutterElement: function() {
          return this.display.gutters;
        }
      }, Nt(e), e.registerHelper = function(r, n, a) {
        i.hasOwnProperty(r) || (i[r] = e[r] = { _global: [] }), i[r][n] = a;
      }, e.registerGlobalHelper = function(r, n, a, l) {
        e.registerHelper(r, n, l), i[r]._global.push({ pred: a, val: l });
      };
    }
    function Na(e, t, i, r, n) {
      var a = t, l = i, o = me(e, t.line), u = n && e.direction == "rtl" ? -i : i;
      function f() {
        var se = t.line + u;
        return se < e.first || se >= e.first + e.size ? !1 : (t = new $(se, t.ch, t.sticky), o = me(e, se));
      }
      function D(se) {
        var ne;
        if (r == "codepoint") {
          var he = o.text.charCodeAt(t.ch + (i > 0 ? 0 : -1));
          if (isNaN(he))
            ne = null;
          else {
            var be = i > 0 ? he >= 55296 && he < 56320 : he >= 56320 && he < 57343;
            ne = new $(t.line, Math.max(0, Math.min(o.text.length, t.ch + i * (be ? 2 : 1))), -i);
          }
        } else
          n ? ne = qs(e.cm, o, t, i) : ne = Sa(o, t, i);
        if (ne == null)
          if (!se && f())
            t = Fa(n, e.cm, o, t.line, u);
          else
            return !1;
        else
          t = ne;
        return !0;
      }
      if (r == "char" || r == "codepoint")
        D();
      else if (r == "column")
        D(!0);
      else if (r == "word" || r == "group")
        for (var w = null, M = r == "group", L = e.cm && e.cm.getHelper(t, "wordChars"), W = !0; !(i < 0 && !D(!W)); W = !1) {
          var K = o.text.charAt(t.ch) || `
`, ee = h(K, L) ? "w" : M && K == `
` ? "n" : !M || /\s/.test(K) ? null : "p";
          if (M && !W && !ee && (ee = "s"), w && w != ee) {
            i < 0 && (i = 1, D(), t.sticky = "after");
            break;
          }
          if (ee && (w = ee), i > 0 && !D(!W))
            break;
        }
      var ie = tn(e, t, a, l, !0);
      return _n(a, ie) && (ie.hitSide = !0), ie;
    }
    function qo(e, t, i, r) {
      var n = e.doc, a = t.left, l;
      if (r == "page") {
        var o = Math.min(e.display.wrapper.clientHeight, Ee(e).innerHeight || n(e).documentElement.clientHeight), u = Math.max(o - 0.5 * Hr(e.display), 3);
        l = (i > 0 ? t.bottom : t.top) + i * u;
      } else
        r == "line" && (l = i > 0 ? t.bottom + 3 : t.top - 3);
      for (var f; f = ra(e, a, l), !!f.outside; ) {
        if (i < 0 ? l <= 0 : l >= n.height) {
          f.hitSide = !0;
          break;
        }
        l += i * 5;
      }
      return f;
    }
    var We = function(e) {
      this.cm = e, this.lastAnchorNode = this.lastAnchorOffset = this.lastFocusNode = this.lastFocusOffset = null, this.polling = new nt(), this.composing = null, this.gracePeriod = !1, this.readDOMTimeout = null;
    };
    We.prototype.init = function(e) {
      var t = this, i = this, r = i.cm, n = i.div = e.lineDiv;
      n.contentEditable = !0, Ma(n, r.options.spellcheck, r.options.autocorrect, r.options.autocapitalize);
      function a(o) {
        for (var u = o.target; u; u = u.parentNode) {
          if (u == n)
            return !0;
          if (/\bCodeMirror-(?:line)?widget\b/.test(u.className))
            break;
        }
        return !1;
      }
      U(n, "paste", function(o) {
        !a(o) || Le(r, o) || Po(o, r) || A <= 11 && setTimeout(ut(r, function() {
          return t.updateFromDOM();
        }), 20);
      }), U(n, "compositionstart", function(o) {
        t.composing = { data: o.data, done: !1 };
      }), U(n, "compositionupdate", function(o) {
        t.composing || (t.composing = { data: o.data, done: !1 });
      }), U(n, "compositionend", function(o) {
        t.composing && (o.data != t.composing.data && t.readFromDOMSoon(), t.composing.done = !0);
      }), U(n, "touchstart", function() {
        return i.forceCompositionEnd();
      }), U(n, "input", function() {
        t.composing || t.readFromDOMSoon();
      });
      function l(o) {
        if (!(!a(o) || Le(r, o))) {
          if (r.somethingSelected())
            un({ lineWise: !1, text: r.getSelections() }), o.type == "cut" && r.replaceSelection("", null, "cut");
          else if (r.options.lineWiseCopyCut) {
            var u = _o(r);
            un({ lineWise: !0, text: u.text }), o.type == "cut" && r.operation(function() {
              r.setSelections(u.ranges, 0, dt), r.replaceSelection("", null, "cut");
            });
          } else
            return;
          if (o.clipboardData) {
            o.clipboardData.clearData();
            var f = zt.text.join(`
`);
            if (o.clipboardData.setData("Text", f), o.clipboardData.getData("Text") == f) {
              o.preventDefault();
              return;
            }
          }
          var D = Uo(), w = D.firstChild;
          Ma(w), r.display.lineSpace.insertBefore(D, r.display.lineSpace.firstChild), w.value = zt.text.join(`
`);
          var M = Me(Ne(n));
          S(w), setTimeout(function() {
            r.display.lineSpace.removeChild(D), M.focus(), M == n && i.showPrimarySelection();
          }, 50);
        }
      }
      U(n, "copy", l), U(n, "cut", l);
    }, We.prototype.screenReaderLabelChanged = function(e) {
      e ? this.div.setAttribute("aria-label", e) : this.div.removeAttribute("aria-label");
    }, We.prototype.prepareSelection = function() {
      var e = Ml(this.cm, !1);
      return e.focus = Me(Ne(this.div)) == this.div, e;
    }, We.prototype.showSelection = function(e, t) {
      !e || !this.cm.display.view.length || ((e.focus || t) && this.showPrimarySelection(), this.showMultipleSelections(e));
    }, We.prototype.getSelection = function() {
      return this.cm.display.wrapper.ownerDocument.getSelection();
    }, We.prototype.showPrimarySelection = function() {
      var e = this.getSelection(), t = this.cm, i = t.doc.sel.primary(), r = i.from(), n = i.to();
      if (t.display.viewTo == t.display.viewFrom || r.line >= t.display.viewTo || n.line < t.display.viewFrom) {
        e.removeAllRanges();
        return;
      }
      var a = sn(t, e.anchorNode, e.anchorOffset), l = sn(t, e.focusNode, e.focusOffset);
      if (!(a && !a.bad && l && !l.bad && Fe(Ni(a, l), r) == 0 && Fe(Mi(a, l), n) == 0)) {
        var o = t.display.view, u = r.line >= t.display.viewFrom && Go(t, r) || { node: o[0].measure.map[2], offset: 0 }, f = n.line < t.display.viewTo && Go(t, n);
        if (!f) {
          var D = o[o.length - 1].measure, w = D.maps ? D.maps[D.maps.length - 1] : D.map;
          f = { node: w[w.length - 1], offset: w[w.length - 2] - w[w.length - 3] };
        }
        if (!u || !f) {
          e.removeAllRanges();
          return;
        }
        var M = e.rangeCount && e.getRangeAt(0), L;
        try {
          L = Z(u.node, u.offset, f.offset, f.node);
        } catch {
        }
        L && (!m && t.state.focused ? (e.collapse(u.node, u.offset), L.collapsed || (e.removeAllRanges(), e.addRange(L))) : (e.removeAllRanges(), e.addRange(L)), M && e.anchorNode == null ? e.addRange(M) : m && this.startGracePeriod()), this.rememberSelection();
      }
    }, We.prototype.startGracePeriod = function() {
      var e = this;
      clearTimeout(this.gracePeriod), this.gracePeriod = setTimeout(function() {
        e.gracePeriod = !1, e.selectionChanged() && e.cm.operation(function() {
          return e.cm.curOp.selectionChanged = !0;
        });
      }, 20);
    }, We.prototype.showMultipleSelections = function(e) {
      De(this.cm.display.cursorDiv, e.cursors), De(this.cm.display.selectionDiv, e.selection);
    }, We.prototype.rememberSelection = function() {
      var e = this.getSelection();
      this.lastAnchorNode = e.anchorNode, this.lastAnchorOffset = e.anchorOffset, this.lastFocusNode = e.focusNode, this.lastFocusOffset = e.focusOffset;
    }, We.prototype.selectionInEditor = function() {
      var e = this.getSelection();
      if (!e.rangeCount)
        return !1;
      var t = e.getRangeAt(0).commonAncestorContainer;
      return ge(this.div, t);
    }, We.prototype.focus = function() {
      this.cm.options.readOnly != "nocursor" && ((!this.selectionInEditor() || Me(Ne(this.div)) != this.div) && this.showSelection(this.prepareSelection(), !0), this.div.focus());
    }, We.prototype.blur = function() {
      this.div.blur();
    }, We.prototype.getField = function() {
      return this.div;
    }, We.prototype.supportsTouch = function() {
      return !0;
    }, We.prototype.receivedFocus = function() {
      var e = this, t = this;
      this.selectionInEditor() ? setTimeout(function() {
        return e.pollSelection();
      }, 20) : St(this.cm, function() {
        return t.cm.curOp.selectionChanged = !0;
      });
      function i() {
        t.cm.state.focused && (t.pollSelection(), t.polling.set(t.cm.options.pollInterval, i));
      }
      this.polling.set(this.cm.options.pollInterval, i);
    }, We.prototype.selectionChanged = function() {
      var e = this.getSelection();
      return e.anchorNode != this.lastAnchorNode || e.anchorOffset != this.lastAnchorOffset || e.focusNode != this.lastFocusNode || e.focusOffset != this.lastFocusOffset;
    }, We.prototype.pollSelection = function() {
      if (!(this.readDOMTimeout != null || this.gracePeriod || !this.selectionChanged())) {
        var e = this.getSelection(), t = this.cm;
        if (q && N && this.cm.display.gutterSpecs.length && ff(e.anchorNode)) {
          this.cm.triggerOnKeyDown({ type: "keydown", keyCode: 8, preventDefault: Math.abs }), this.blur(), this.focus();
          return;
        }
        if (!this.composing) {
          this.rememberSelection();
          var i = sn(t, e.anchorNode, e.anchorOffset), r = sn(t, e.focusNode, e.focusOffset);
          i && r && St(t, function() {
            vt(t.doc, lr(i, r), dt), (i.bad || r.bad) && (t.curOp.selectionChanged = !0);
          });
        }
      }
    }, We.prototype.pollContent = function() {
      this.readDOMTimeout != null && (clearTimeout(this.readDOMTimeout), this.readDOMTimeout = null);
      var e = this.cm, t = e.display, i = e.doc.sel.primary(), r = i.from(), n = i.to();
      if (r.ch == 0 && r.line > e.firstLine() && (r = $(r.line - 1, me(e.doc, r.line - 1).length)), n.ch == me(e.doc, n.line).text.length && n.line < e.lastLine() && (n = $(n.line + 1, 0)), r.line < t.viewFrom || n.line > t.viewTo - 1)
        return !1;
      var a, l, o;
      r.line == t.viewFrom || (a = Dr(e, r.line)) == 0 ? (l = Pe(t.view[0].line), o = t.view[0].node) : (l = Pe(t.view[a].line), o = t.view[a - 1].node.nextSibling);
      var u = Dr(e, n.line), f, D;
      if (u == t.view.length - 1 ? (f = t.viewTo - 1, D = t.lineDiv.lastChild) : (f = Pe(t.view[u + 1].line) - 1, D = t.view[u + 1].node.previousSibling), !o)
        return !1;
      for (var w = e.doc.splitLines(cf(e, o, D, l, f)), M = gr(e.doc, $(l, 0), $(f, me(e.doc, f).text.length)); w.length > 1 && M.length > 1; )
        if (Be(w) == Be(M))
          w.pop(), M.pop(), f--;
        else if (w[0] == M[0])
          w.shift(), M.shift(), l++;
        else
          break;
      for (var L = 0, W = 0, K = w[0], ee = M[0], ie = Math.min(K.length, ee.length); L < ie && K.charCodeAt(L) == ee.charCodeAt(L); )
        ++L;
      for (var se = Be(w), ne = Be(M), he = Math.min(
        se.length - (w.length == 1 ? L : 0),
        ne.length - (M.length == 1 ? L : 0)
      ); W < he && se.charCodeAt(se.length - W - 1) == ne.charCodeAt(ne.length - W - 1); )
        ++W;
      if (w.length == 1 && M.length == 1 && l == r.line)
        for (; L && L > r.ch && se.charCodeAt(se.length - W - 1) == ne.charCodeAt(ne.length - W - 1); )
          L--, W++;
      w[w.length - 1] = se.slice(0, se.length - W).replace(/^\u200b+/, ""), w[0] = w[0].slice(L).replace(/\u200b+$/, "");
      var be = $(l, L), xe = $(f, M.length ? Be(M).length - W : 0);
      if (w.length > 1 || w[0] || Fe(be, xe))
        return Gr(e.doc, w, be, xe, "+input"), !0;
    }, We.prototype.ensurePolled = function() {
      this.forceCompositionEnd();
    }, We.prototype.reset = function() {
      this.forceCompositionEnd();
    }, We.prototype.forceCompositionEnd = function() {
      this.composing && (clearTimeout(this.readDOMTimeout), this.composing = null, this.updateFromDOM(), this.div.blur(), this.div.focus());
    }, We.prototype.readFromDOMSoon = function() {
      var e = this;
      this.readDOMTimeout == null && (this.readDOMTimeout = setTimeout(function() {
        if (e.readDOMTimeout = null, e.composing)
          if (e.composing.done)
            e.composing = null;
          else
            return;
        e.updateFromDOM();
      }, 80));
    }, We.prototype.updateFromDOM = function() {
      var e = this;
      (this.cm.isReadOnly() || !this.pollContent()) && St(this.cm, function() {
        return Dt(e.cm);
      });
    }, We.prototype.setUneditable = function(e) {
      e.contentEditable = "false";
    }, We.prototype.onKeyPress = function(e) {
      e.charCode == 0 || this.composing || (e.preventDefault(), this.cm.isReadOnly() || ut(this.cm, Ba)(this.cm, String.fromCharCode(e.charCode == null ? e.keyCode : e.charCode), 0));
    }, We.prototype.readOnlyChanged = function(e) {
      this.div.contentEditable = String(e != "nocursor");
    }, We.prototype.onContextMenu = function() {
    }, We.prototype.resetPosition = function() {
    }, We.prototype.needsContentAttribute = !0;
    function Go(e, t) {
      var i = Vn(e, t.line);
      if (!i || i.hidden)
        return null;
      var r = me(e.doc, t.line), n = xl(i, r, t.line), a = ue(r, e.doc.direction), l = "left";
      if (a) {
        var o = ve(a, t.ch);
        l = o % 2 ? "right" : "left";
      }
      var u = bl(n.map, t.ch, l);
      return u.offset = u.collapse == "right" ? u.end : u.start, u;
    }
    function ff(e) {
      for (var t = e; t; t = t.parentNode)
        if (/CodeMirror-gutter-wrapper/.test(t.className))
          return !0;
      return !1;
    }
    function Zr(e, t) {
      return t && (e.bad = !0), e;
    }
    function cf(e, t, i, r, n) {
      var a = "", l = !1, o = e.doc.lineSeparator(), u = !1;
      function f(L) {
        return function(W) {
          return W.id == L;
        };
      }
      function D() {
        l && (a += o, u && (a += o), l = u = !1);
      }
      function w(L) {
        L && (D(), a += L);
      }
      function M(L) {
        if (L.nodeType == 1) {
          var W = L.getAttribute("cm-text");
          if (W) {
            w(W);
            return;
          }
          var K = L.getAttribute("cm-marker"), ee;
          if (K) {
            var ie = e.findMarks($(r, 0), $(n + 1, 0), f(+K));
            ie.length && (ee = ie[0].find(0)) && w(gr(e.doc, ee.from, ee.to).join(o));
            return;
          }
          if (L.getAttribute("contenteditable") == "false")
            return;
          var se = /^(pre|div|p|li|table|br)$/i.test(L.nodeName);
          if (!/^br$/i.test(L.nodeName) && L.textContent.length == 0)
            return;
          se && D();
          for (var ne = 0; ne < L.childNodes.length; ne++)
            M(L.childNodes[ne]);
          /^(pre|p)$/i.test(L.nodeName) && (u = !0), se && (l = !0);
        } else
          L.nodeType == 3 && w(L.nodeValue.replace(/\u200b/g, "").replace(/\u00a0/g, " "));
      }
      for (; M(t), t != i; )
        t = t.nextSibling, u = !1;
      return a;
    }
    function sn(e, t, i) {
      var r;
      if (t == e.display.lineDiv) {
        if (r = e.display.lineDiv.childNodes[i], !r)
          return Zr(e.clipPos($(e.display.viewTo - 1)), !0);
        t = null, i = 0;
      } else
        for (r = t; ; r = r.parentNode) {
          if (!r || r == e.display.lineDiv)
            return null;
          if (r.parentNode && r.parentNode == e.display.lineDiv)
            break;
        }
      for (var n = 0; n < e.display.view.length; n++) {
        var a = e.display.view[n];
        if (a.node == r)
          return hf(a, t, i);
      }
    }
    function hf(e, t, i) {
      var r = e.text.firstChild, n = !1;
      if (!t || !ge(r, t))
        return Zr($(Pe(e.line), 0), !0);
      if (t == r && (n = !0, t = r.childNodes[i], i = 0, !t)) {
        var a = e.rest ? Be(e.rest) : e.line;
        return Zr($(Pe(a), a.text.length), n);
      }
      var l = t.nodeType == 3 ? t : null, o = t;
      for (!l && t.childNodes.length == 1 && t.firstChild.nodeType == 3 && (l = t.firstChild, i && (i = l.nodeValue.length)); o.parentNode != r; )
        o = o.parentNode;
      var u = e.measure, f = u.maps;
      function D(ee, ie, se) {
        for (var ne = -1; ne < (f ? f.length : 0); ne++)
          for (var he = ne < 0 ? u.map : f[ne], be = 0; be < he.length; be += 3) {
            var xe = he[be + 2];
            if (xe == ee || xe == ie) {
              var Te = Pe(ne < 0 ? e.line : e.rest[ne]), Ue = he[be] + se;
              return (se < 0 || xe != ee) && (Ue = he[be + (se ? 1 : 0)]), $(Te, Ue);
            }
          }
      }
      var w = D(l, o, i);
      if (w)
        return Zr(w, n);
      for (var M = o.nextSibling, L = l ? l.nodeValue.length - i : 0; M; M = M.nextSibling) {
        if (w = D(M, M.firstChild, 0), w)
          return Zr($(w.line, w.ch - L), n);
        L += M.textContent.length;
      }
      for (var W = o.previousSibling, K = i; W; W = W.previousSibling) {
        if (w = D(W, W.firstChild, -1), w)
          return Zr($(w.line, w.ch + K), n);
        K += W.textContent.length;
      }
    }
    var Ve = function(e) {
      this.cm = e, this.prevInput = "", this.pollingFast = !1, this.polling = new nt(), this.hasSelection = !1, this.composing = null, this.resetting = !1;
    };
    Ve.prototype.init = function(e) {
      var t = this, i = this, r = this.cm;
      this.createField(e);
      var n = this.textarea;
      e.wrapper.insertBefore(this.wrapper, e.wrapper.firstChild), H && (n.style.width = "0px"), U(n, "input", function() {
        x && A >= 9 && t.hasSelection && (t.hasSelection = null), i.poll();
      }), U(n, "paste", function(l) {
        Le(r, l) || Po(l, r) || (r.state.pasteIncoming = +/* @__PURE__ */ new Date(), i.fastPoll());
      });
      function a(l) {
        if (!Le(r, l)) {
          if (r.somethingSelected())
            un({ lineWise: !1, text: r.getSelections() });
          else if (r.options.lineWiseCopyCut) {
            var o = _o(r);
            un({ lineWise: !0, text: o.text }), l.type == "cut" ? r.setSelections(o.ranges, null, dt) : (i.prevInput = "", n.value = o.text.join(`
`), S(n));
          } else
            return;
          l.type == "cut" && (r.state.cutIncoming = +/* @__PURE__ */ new Date());
        }
      }
      U(n, "cut", a), U(n, "copy", a), U(e.scroller, "paste", function(l) {
        if (!($t(e, l) || Le(r, l))) {
          if (!n.dispatchEvent) {
            r.state.pasteIncoming = +/* @__PURE__ */ new Date(), i.focus();
            return;
          }
          var o = new Event("paste");
          o.clipboardData = l.clipboardData, n.dispatchEvent(o);
        }
      }), U(e.lineSpace, "selectstart", function(l) {
        $t(e, l) || Ye(l);
      }), U(n, "compositionstart", function() {
        var l = r.getCursor("from");
        i.composing && i.composing.range.clear(), i.composing = {
          start: l,
          range: r.markText(l, r.getCursor("to"), { className: "CodeMirror-composing" })
        };
      }), U(n, "compositionend", function() {
        i.composing && (i.poll(), i.composing.range.clear(), i.composing = null);
      });
    }, Ve.prototype.createField = function(e) {
      this.wrapper = Uo(), this.textarea = this.wrapper.firstChild;
      var t = this.cm.options;
      Ma(this.textarea, t.spellcheck, t.autocorrect, t.autocapitalize);
    }, Ve.prototype.screenReaderLabelChanged = function(e) {
      e ? this.textarea.setAttribute("aria-label", e) : this.textarea.removeAttribute("aria-label");
    }, Ve.prototype.prepareSelection = function() {
      var e = this.cm, t = e.display, i = e.doc, r = Ml(e);
      if (e.options.moveInputWithCursor) {
        var n = Ht(e, i.sel.primary().head, "div"), a = t.wrapper.getBoundingClientRect(), l = t.lineDiv.getBoundingClientRect();
        r.teTop = Math.max(0, Math.min(
          t.wrapper.clientHeight - 10,
          n.top + l.top - a.top
        )), r.teLeft = Math.max(0, Math.min(
          t.wrapper.clientWidth - 10,
          n.left + l.left - a.left
        ));
      }
      return r;
    }, Ve.prototype.showSelection = function(e) {
      var t = this.cm, i = t.display;
      De(i.cursorDiv, e.cursors), De(i.selectionDiv, e.selection), e.teTop != null && (this.wrapper.style.top = e.teTop + "px", this.wrapper.style.left = e.teLeft + "px");
    }, Ve.prototype.reset = function(e) {
      if (!(this.contextMenuPending || this.composing && e)) {
        var t = this.cm;
        if (this.resetting = !0, t.somethingSelected()) {
          this.prevInput = "";
          var i = t.getSelection();
          this.textarea.value = i, t.state.focused && S(this.textarea), x && A >= 9 && (this.hasSelection = i);
        } else
          e || (this.prevInput = this.textarea.value = "", x && A >= 9 && (this.hasSelection = null));
        this.resetting = !1;
      }
    }, Ve.prototype.getField = function() {
      return this.textarea;
    }, Ve.prototype.supportsTouch = function() {
      return !1;
    }, Ve.prototype.focus = function() {
      if (this.cm.options.readOnly != "nocursor" && (!R || Me(Ne(this.textarea)) != this.textarea))
        try {
          this.textarea.focus();
        } catch {
        }
    }, Ve.prototype.blur = function() {
      this.textarea.blur();
    }, Ve.prototype.resetPosition = function() {
      this.wrapper.style.top = this.wrapper.style.left = 0;
    }, Ve.prototype.receivedFocus = function() {
      this.slowPoll();
    }, Ve.prototype.slowPoll = function() {
      var e = this;
      this.pollingFast || this.polling.set(this.cm.options.pollInterval, function() {
        e.poll(), e.cm.state.focused && e.slowPoll();
      });
    }, Ve.prototype.fastPoll = function() {
      var e = !1, t = this;
      t.pollingFast = !0;
      function i() {
        var r = t.poll();
        !r && !e ? (e = !0, t.polling.set(60, i)) : (t.pollingFast = !1, t.slowPoll());
      }
      t.polling.set(20, i);
    }, Ve.prototype.poll = function() {
      var e = this, t = this.cm, i = this.textarea, r = this.prevInput;
      if (this.contextMenuPending || this.resetting || !t.state.focused || fu(i) && !r && !this.composing || t.isReadOnly() || t.options.disableInput || t.state.keySeq)
        return !1;
      var n = i.value;
      if (n == r && !t.somethingSelected())
        return !1;
      if (x && A >= 9 && this.hasSelection === n || _ && /[\uf700-\uf7ff]/.test(n))
        return t.display.input.reset(), !1;
      if (t.doc.sel == t.display.selForContextMenu) {
        var a = n.charCodeAt(0);
        if (a == 8203 && !r && (r = "​"), a == 8666)
          return this.reset(), this.cm.execCommand("undo");
      }
      for (var l = 0, o = Math.min(r.length, n.length); l < o && r.charCodeAt(l) == n.charCodeAt(l); )
        ++l;
      return St(t, function() {
        Ba(
          t,
          n.slice(l),
          r.length - l,
          null,
          e.composing ? "*compose" : null
        ), n.length > 1e3 || n.indexOf(`
`) > -1 ? i.value = e.prevInput = "" : e.prevInput = n, e.composing && (e.composing.range.clear(), e.composing.range = t.markText(
          e.composing.start,
          t.getCursor("to"),
          { className: "CodeMirror-composing" }
        ));
      }), !0;
    }, Ve.prototype.ensurePolled = function() {
      this.pollingFast && this.poll() && (this.pollingFast = !1);
    }, Ve.prototype.onKeyPress = function() {
      x && A >= 9 && (this.hasSelection = null), this.fastPoll();
    }, Ve.prototype.onContextMenu = function(e) {
      var t = this, i = t.cm, r = i.display, n = t.textarea;
      t.contextMenuPending && t.contextMenuPending();
      var a = yr(i, e), l = r.scroller.scrollTop;
      if (!a || X)
        return;
      var o = i.options.resetSelectionOnContextMenu;
      o && i.doc.sel.contains(a) == -1 && ut(i, vt)(i.doc, lr(a), dt);
      var u = n.style.cssText, f = t.wrapper.style.cssText, D = t.wrapper.offsetParent.getBoundingClientRect();
      t.wrapper.style.cssText = "position: static", n.style.cssText = `position: absolute; width: 30px; height: 30px;
      top: ` + (e.clientY - D.top - 5) + "px; left: " + (e.clientX - D.left - 5) + `px;
      z-index: 1000; background: ` + (x ? "rgba(255, 255, 255, .05)" : "transparent") + `;
      outline: none; border-width: 0; outline: none; overflow: hidden; opacity: .05; filter: alpha(opacity=5);`;
      var w;
      z && (w = n.ownerDocument.defaultView.scrollY), r.input.focus(), z && n.ownerDocument.defaultView.scrollTo(null, w), r.input.reset(), i.somethingSelected() || (n.value = t.prevInput = " "), t.contextMenuPending = L, r.selForContextMenu = i.doc.sel, clearTimeout(r.detectingSelectAll);
      function M() {
        if (n.selectionStart != null) {
          var K = i.somethingSelected(), ee = "​" + (K ? n.value : "");
          n.value = "⇚", n.value = ee, t.prevInput = K ? "" : "​", n.selectionStart = 1, n.selectionEnd = ee.length, r.selForContextMenu = i.doc.sel;
        }
      }
      function L() {
        if (t.contextMenuPending == L && (t.contextMenuPending = !1, t.wrapper.style.cssText = f, n.style.cssText = u, x && A < 9 && r.scrollbars.setScrollTop(r.scroller.scrollTop = l), n.selectionStart != null)) {
          (!x || x && A < 9) && M();
          var K = 0, ee = function() {
            r.selForContextMenu == i.doc.sel && n.selectionStart == 0 && n.selectionEnd > 0 && t.prevInput == "​" ? ut(i, uo)(i) : K++ < 10 ? r.detectingSelectAll = setTimeout(ee, 500) : (r.selForContextMenu = null, r.input.reset());
          };
          r.detectingSelectAll = setTimeout(ee, 200);
        }
      }
      if (x && A >= 9 && M(), qe) {
        It(e);
        var W = function() {
          Oe(window, "mouseup", W), setTimeout(L, 20);
        };
        U(window, "mouseup", W);
      } else
        setTimeout(L, 50);
    }, Ve.prototype.readOnlyChanged = function(e) {
      e || this.reset(), this.textarea.disabled = e == "nocursor", this.textarea.readOnly = !!e;
    }, Ve.prototype.setUneditable = function() {
    }, Ve.prototype.needsContentAttribute = !1;
    function df(e, t) {
      if (t = t ? ht(t) : {}, t.value = e.value, !t.tabindex && e.tabIndex && (t.tabindex = e.tabIndex), !t.placeholder && e.placeholder && (t.placeholder = e.placeholder), t.autofocus == null) {
        var i = Me(Ne(e));
        t.autofocus = i == e || e.getAttribute("autofocus") != null && i == document.body;
      }
      function r() {
        e.value = o.getValue();
      }
      var n;
      if (e.form && (U(e.form, "submit", r), !t.leaveSubmitMethodAlone)) {
        var a = e.form;
        n = a.submit;
        try {
          var l = a.submit = function() {
            r(), a.submit = n, a.submit(), a.submit = l;
          };
        } catch {
        }
      }
      t.finishInit = function(u) {
        u.save = r, u.getTextArea = function() {
          return e;
        }, u.toTextArea = function() {
          u.toTextArea = isNaN, r(), e.parentNode.removeChild(u.getWrapperElement()), e.style.display = "", e.form && (Oe(e.form, "submit", r), !t.leaveSubmitMethodAlone && typeof e.form.submit == "function" && (e.form.submit = n));
        };
      }, e.style.display = "none";
      var o = je(
        function(u) {
          return e.parentNode.insertBefore(u, e.nextSibling);
        },
        t
      );
      return o;
    }
    function pf(e) {
      e.off = Oe, e.on = U, e.wheelEventPixels = Ds, e.Doc = bt, e.splitLines = In, e.countColumn = Xe, e.findColumn = Mt, e.isWordChar = B, e.Pass = Je, e.signal = He, e.Line = Nr, e.changeEnd = or, e.scrollbarModel = zl, e.Pos = $, e.cmpPos = Fe, e.modes = Hn, e.mimeModes = Br, e.resolveMode = Bi, e.getMode = Rn, e.modeExtensions = Mr, e.extendMode = gu, e.copyState = pr, e.startState = Ga, e.innerMode = zn, e.commands = ki, e.keyMap = Vt, e.keyName = So, e.isModifierKey = wo, e.lookupKey = Kr, e.normalizeKeyMap = Us, e.StringStream = tt, e.SharedTextMarker = bi, e.TextMarker = sr, e.LineWidget = Di, e.e_preventDefault = Ye, e.e_stopPropagation = Xt, e.e_stop = It, e.addClass = et, e.contains = ge, e.rmClass = Se, e.keyNames = fr;
    }
    af(je), sf(je);
    var gf = "iter insert remove copy getEditor constructor".split(" ");
    for (var fn in bt.prototype)
      bt.prototype.hasOwnProperty(fn) && Ie(gf, fn) < 0 && (je.prototype[fn] = function(e) {
        return function() {
          return e.apply(this.doc, arguments);
        };
      }(bt.prototype[fn]));
    return Nt(bt), je.inputStyles = { textarea: Ve, contenteditable: We }, je.defineMode = function(e) {
      !je.defaults.mode && e != "null" && (je.defaults.mode = e), du.apply(this, arguments);
    }, je.defineMIME = pu, je.defineMode("null", function() {
      return { token: function(e) {
        return e.skipToEnd();
      } };
    }), je.defineMIME("text/plain", "null"), je.defineExtension = function(e, t) {
      je.prototype[e] = t;
    }, je.defineDocExtension = function(e, t) {
      bt.prototype[e] = t;
    }, je.fromTextArea = df, pf(je), je.version = "5.65.20", je;
  });
})(Qo);
var Tt = Qo.exports;
(function(s, b) {
  (function(c) {
    c(Tt);
  })(function(c) {
    var v = /^(\s*)(>[> ]*|[*+-] \[[x ]\]\s|[*+-]\s|(\d+)([.)]))(\s*)/, m = /^(\s*)(>[> ]*|[*+-] \[[x ]\]|[*+-]|(\d+)[.)])(\s*)$/, C = /[*+-]\s/;
    c.commands.newlineAndIndentContinueMarkdownList = function(y) {
      if (y.getOption("disableInput"))
        return c.Pass;
      for (var x = y.listSelections(), A = [], z = 0; z < x.length; z++) {
        var P = x[z].head, N = y.getStateAfter(P.line), G = c.innerMode(y.getMode(), N);
        if (G.mode.name !== "markdown" && G.mode.helperType !== "markdown") {
          y.execCommand("newlineAndIndent");
          return;
        } else
          N = G.state;
        var X = N.list !== !1, le = N.quote !== 0, J = y.getLine(P.line), Q = v.exec(J), H = /^\s*$/.test(J.slice(0, P.ch));
        if (!x[z].empty() || !X && !le || !Q || H) {
          y.execCommand("newlineAndIndent");
          return;
        }
        if (m.test(J)) {
          var q = le && />\s*$/.test(J), R = !/>\s*$/.test(J);
          (q || R) && y.replaceRange("", {
            line: P.line,
            ch: 0
          }, {
            line: P.line,
            ch: P.ch + 1
          }), A[z] = `
`;
        } else {
          var _ = Q[1], te = Q[5], Y = !(C.test(Q[2]) || Q[2].indexOf(">") >= 0), oe = Y ? parseInt(Q[3], 10) + 1 + Q[4] : Q[2].replace("x", " ");
          A[z] = `
` + _ + oe + te, Y && g(y, P);
        }
      }
      y.replaceSelections(A);
    };
    function g(y, x) {
      var A = x.line, z = 0, P = 0, N = v.exec(y.getLine(A)), G = N[1];
      do {
        z += 1;
        var X = A + z, le = y.getLine(X), J = v.exec(le);
        if (J) {
          var Q = J[1], H = parseInt(N[3], 10) + z - P, q = parseInt(J[3], 10), R = q;
          if (G === Q && !isNaN(q))
            H === q && (R = q + 1), H > q && (R = H + 1), y.replaceRange(
              le.replace(v, Q + R + J[4] + J[5]),
              {
                line: X,
                ch: 0
              },
              {
                line: X,
                ch: le.length
              }
            );
          else {
            if (G.length > Q.length || G.length < Q.length && z === 1)
              return;
            P += 1;
          }
        }
      } while (J);
    }
  });
})();
var $o = Tt;
$o.commands.tabAndIndentMarkdownList = function(s) {
  var b = s.listSelections(), c = b[0].head, v = s.getStateAfter(c.line), m = v.list !== !1;
  if (m) {
    s.execCommand("indentMore");
    return;
  }
  if (s.options.indentWithTabs)
    s.execCommand("insertTab");
  else {
    var C = Array(s.options.tabSize + 1).join(" ");
    s.replaceSelection(C);
  }
};
$o.commands.shiftTabAndUnindentMarkdownList = function(s) {
  var b = s.listSelections(), c = b[0].head, v = s.getStateAfter(c.line), m = v.list !== !1;
  if (m) {
    s.execCommand("indentLess");
    return;
  }
  if (s.options.indentWithTabs)
    s.execCommand("insertTab");
  else {
    var C = Array(s.options.tabSize + 1).join(" ");
    s.replaceSelection(C);
  }
};
(function(s, b) {
  (function(c) {
    c(Tt);
  })(function(c) {
    c.defineOption("fullScreen", !1, function(C, g, y) {
      y == c.Init && (y = !1), !y != !g && (g ? v(C) : m(C));
    });
    function v(C) {
      var g = C.getWrapperElement();
      C.state.fullScreenRestore = {
        scrollTop: window.pageYOffset,
        scrollLeft: window.pageXOffset,
        width: g.style.width,
        height: g.style.height
      }, g.style.width = "", g.style.height = "auto", g.className += " CodeMirror-fullscreen", document.documentElement.style.overflow = "hidden", C.refresh();
    }
    function m(C) {
      var g = C.getWrapperElement();
      g.className = g.className.replace(/\s*CodeMirror-fullscreen\b/, ""), document.documentElement.style.overflow = "";
      var y = C.state.fullScreenRestore;
      g.style.width = y.width, g.style.height = y.height, window.scrollTo(y.scrollLeft, y.scrollTop), C.refresh();
    }
  });
})();
var Df = { exports: {} }, bf = { exports: {} };
(function(s, b) {
  (function(c) {
    c(Tt);
  })(function(c) {
    var v = {
      autoSelfClosers: {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        frame: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0,
        menuitem: !0
      },
      implicitlyClosed: {
        dd: !0,
        li: !0,
        optgroup: !0,
        option: !0,
        p: !0,
        rp: !0,
        rt: !0,
        tbody: !0,
        td: !0,
        tfoot: !0,
        th: !0,
        tr: !0
      },
      contextGrabbers: {
        dd: { dd: !0, dt: !0 },
        dt: { dd: !0, dt: !0 },
        li: { li: !0 },
        option: { option: !0, optgroup: !0 },
        optgroup: { optgroup: !0 },
        p: {
          address: !0,
          article: !0,
          aside: !0,
          blockquote: !0,
          dir: !0,
          div: !0,
          dl: !0,
          fieldset: !0,
          footer: !0,
          form: !0,
          h1: !0,
          h2: !0,
          h3: !0,
          h4: !0,
          h5: !0,
          h6: !0,
          header: !0,
          hgroup: !0,
          hr: !0,
          menu: !0,
          nav: !0,
          ol: !0,
          p: !0,
          pre: !0,
          section: !0,
          table: !0,
          ul: !0
        },
        rp: { rp: !0, rt: !0 },
        rt: { rp: !0, rt: !0 },
        tbody: { tbody: !0, tfoot: !0 },
        td: { td: !0, th: !0 },
        tfoot: { tbody: !0 },
        th: { td: !0, th: !0 },
        thead: { tbody: !0, tfoot: !0 },
        tr: { tr: !0 }
      },
      doNotIndent: { pre: !0 },
      allowUnquoted: !0,
      allowMissing: !0,
      caseFold: !0
    }, m = {
      autoSelfClosers: {},
      implicitlyClosed: {},
      contextGrabbers: {},
      doNotIndent: {},
      allowUnquoted: !1,
      allowMissing: !1,
      allowMissingTagName: !1,
      caseFold: !1
    };
    c.defineMode("xml", function(C, g) {
      var y = C.indentUnit, x = {}, A = g.htmlMode ? v : m;
      for (var z in A)
        x[z] = A[z];
      for (var z in g)
        x[z] = g[z];
      var P, N;
      function G(T, V) {
        function Z(et) {
          return V.tokenize = et, et(T, V);
        }
        var ge = T.next();
        if (ge == "<")
          return T.eat("!") ? T.eat("[") ? T.match("CDATA[") ? Z(J("atom", "]]>")) : null : T.match("--") ? Z(J("comment", "-->")) : T.match("DOCTYPE", !0, !0) ? (T.eatWhile(/[\w\._\-]/), Z(Q(1))) : null : T.eat("?") ? (T.eatWhile(/[\w\._\-]/), V.tokenize = J("meta", "?>"), "meta") : (P = T.eat("/") ? "closeTag" : "openTag", V.tokenize = X, "tag bracket");
        if (ge == "&") {
          var Me;
          return T.eat("#") ? T.eat("x") ? Me = T.eatWhile(/[a-fA-F\d]/) && T.eat(";") : Me = T.eatWhile(/[\d]/) && T.eat(";") : Me = T.eatWhile(/[\w\.\-:]/) && T.eat(";"), Me ? "atom" : "error";
        } else
          return T.eatWhile(/[^&<]/), null;
      }
      G.isInText = !0;
      function X(T, V) {
        var Z = T.next();
        if (Z == ">" || Z == "/" && T.eat(">"))
          return V.tokenize = G, P = Z == ">" ? "endTag" : "selfcloseTag", "tag bracket";
        if (Z == "=")
          return P = "equals", null;
        if (Z == "<") {
          V.tokenize = G, V.state = te, V.tagName = V.tagStart = null;
          var ge = V.tokenize(T, V);
          return ge ? ge + " tag error" : "tag error";
        } else
          return /[\'\"]/.test(Z) ? (V.tokenize = le(Z), V.stringStartCol = T.column(), V.tokenize(T, V)) : (T.match(/^[^\s\u00a0=<>\"\']*[^\s\u00a0=<>\"\'\/]/), "word");
      }
      function le(T) {
        var V = function(Z, ge) {
          for (; !Z.eol(); )
            if (Z.next() == T) {
              ge.tokenize = X;
              break;
            }
          return "string";
        };
        return V.isInAttribute = !0, V;
      }
      function J(T, V) {
        return function(Z, ge) {
          for (; !Z.eol(); ) {
            if (Z.match(V)) {
              ge.tokenize = G;
              break;
            }
            Z.next();
          }
          return T;
        };
      }
      function Q(T) {
        return function(V, Z) {
          for (var ge; (ge = V.next()) != null; ) {
            if (ge == "<")
              return Z.tokenize = Q(T + 1), Z.tokenize(V, Z);
            if (ge == ">")
              if (T == 1) {
                Z.tokenize = G;
                break;
              } else
                return Z.tokenize = Q(T - 1), Z.tokenize(V, Z);
          }
          return "meta";
        };
      }
      function H(T) {
        return T && T.toLowerCase();
      }
      function q(T, V, Z) {
        this.prev = T.context, this.tagName = V || "", this.indent = T.indented, this.startOfLine = Z, (x.doNotIndent.hasOwnProperty(V) || T.context && T.context.noIndent) && (this.noIndent = !0);
      }
      function R(T) {
        T.context && (T.context = T.context.prev);
      }
      function _(T, V) {
        for (var Z; ; ) {
          if (!T.context || (Z = T.context.tagName, !x.contextGrabbers.hasOwnProperty(H(Z)) || !x.contextGrabbers[H(Z)].hasOwnProperty(H(V))))
            return;
          R(T);
        }
      }
      function te(T, V, Z) {
        return T == "openTag" ? (Z.tagStart = V.column(), Y) : T == "closeTag" ? oe : te;
      }
      function Y(T, V, Z) {
        return T == "word" ? (Z.tagName = V.current(), N = "tag", ae) : x.allowMissingTagName && T == "endTag" ? (N = "tag bracket", ae(T, V, Z)) : (N = "error", Y);
      }
      function oe(T, V, Z) {
        if (T == "word") {
          var ge = V.current();
          return Z.context && Z.context.tagName != ge && x.implicitlyClosed.hasOwnProperty(H(Z.context.tagName)) && R(Z), Z.context && Z.context.tagName == ge || x.matchClosing === !1 ? (N = "tag", pe) : (N = "tag error", qe);
        } else
          return x.allowMissingTagName && T == "endTag" ? (N = "tag bracket", pe(T, V, Z)) : (N = "error", qe);
      }
      function pe(T, V, Z) {
        return T != "endTag" ? (N = "error", pe) : (R(Z), te);
      }
      function qe(T, V, Z) {
        return N = "error", pe(T, V, Z);
      }
      function ae(T, V, Z) {
        if (T == "word")
          return N = "attribute", Se;
        if (T == "endTag" || T == "selfcloseTag") {
          var ge = Z.tagName, Me = Z.tagStart;
          return Z.tagName = Z.tagStart = null, T == "selfcloseTag" || x.autoSelfClosers.hasOwnProperty(H(ge)) ? _(Z, ge) : (_(Z, ge), Z.context = new q(Z, ge, Me == Z.indented)), te;
        }
        return N = "error", ae;
      }
      function Se(T, V, Z) {
        return T == "equals" ? ke : (x.allowMissing || (N = "error"), ae(T, V, Z));
      }
      function ke(T, V, Z) {
        return T == "string" ? De : T == "word" && x.allowUnquoted ? (N = "string", ae) : (N = "error", ae(T, V, Z));
      }
      function De(T, V, Z) {
        return T == "string" ? De : ae(T, V, Z);
      }
      return {
        startState: function(T) {
          var V = {
            tokenize: G,
            state: te,
            indented: T || 0,
            tagName: null,
            tagStart: null,
            context: null
          };
          return T != null && (V.baseIndent = T), V;
        },
        token: function(T, V) {
          if (!V.tagName && T.sol() && (V.indented = T.indentation()), T.eatSpace())
            return null;
          P = null;
          var Z = V.tokenize(T, V);
          return (Z || P) && Z != "comment" && (N = null, V.state = V.state(P || Z, T, V), N && (Z = N == "error" ? Z + " error" : N)), Z;
        },
        indent: function(T, V, Z) {
          var ge = T.context;
          if (T.tokenize.isInAttribute)
            return T.tagStart == T.indented ? T.stringStartCol + 1 : T.indented + y;
          if (ge && ge.noIndent)
            return c.Pass;
          if (T.tokenize != X && T.tokenize != G)
            return Z ? Z.match(/^(\s*)/)[0].length : 0;
          if (T.tagName)
            return x.multilineTagIndentPastTag !== !1 ? T.tagStart + T.tagName.length + 2 : T.tagStart + y * (x.multilineTagIndentFactor || 1);
          if (x.alignCDATA && /<!\[CDATA\[/.test(V))
            return 0;
          var Me = V && /^<(\/)?([\w_:\.-]*)/.exec(V);
          if (Me && Me[1])
            for (; ge; )
              if (ge.tagName == Me[2]) {
                ge = ge.prev;
                break;
              } else if (x.implicitlyClosed.hasOwnProperty(H(ge.tagName)))
                ge = ge.prev;
              else
                break;
          else if (Me)
            for (; ge; ) {
              var et = x.contextGrabbers[H(ge.tagName)];
              if (et && et.hasOwnProperty(H(Me[2])))
                ge = ge.prev;
              else
                break;
            }
          for (; ge && ge.prev && !ge.startOfLine; )
            ge = ge.prev;
          return ge ? ge.indent + y : T.baseIndent || 0;
        },
        electricInput: /<\/[\s\w:]+>$/,
        blockCommentStart: "<!--",
        blockCommentEnd: "-->",
        configuration: x.htmlMode ? "html" : "xml",
        helperType: x.htmlMode ? "html" : "xml",
        skipAttribute: function(T) {
          T.state == ke && (T.state = ae);
        },
        xmlCurrentTag: function(T) {
          return T.tagName ? { name: T.tagName, close: T.type == "closeTag" } : null;
        },
        xmlCurrentContext: function(T) {
          for (var V = [], Z = T.context; Z; Z = Z.prev)
            V.push(Z.tagName);
          return V.reverse();
        }
      };
    }), c.defineMIME("text/xml", "xml"), c.defineMIME("application/xml", "xml"), c.mimeModes.hasOwnProperty("text/html") || c.defineMIME("text/html", { name: "xml", htmlMode: !0 });
  });
})();
var Cf = bf.exports, jo = { exports: {} }, Ko;
function wf() {
  return Ko || (Ko = 1, function(s, b) {
    (function(c) {
      c(Tt);
    })(function(c) {
      c.modeInfo = [
        { name: "APL", mime: "text/apl", mode: "apl", ext: ["dyalog", "apl"] },
        { name: "PGP", mimes: ["application/pgp", "application/pgp-encrypted", "application/pgp-keys", "application/pgp-signature"], mode: "asciiarmor", ext: ["asc", "pgp", "sig"] },
        { name: "ASN.1", mime: "text/x-ttcn-asn", mode: "asn.1", ext: ["asn", "asn1"] },
        { name: "Asterisk", mime: "text/x-asterisk", mode: "asterisk", file: /^extensions\.conf$/i },
        { name: "Brainfuck", mime: "text/x-brainfuck", mode: "brainfuck", ext: ["b", "bf"] },
        { name: "C", mime: "text/x-csrc", mode: "clike", ext: ["c", "h", "ino"] },
        { name: "C++", mime: "text/x-c++src", mode: "clike", ext: ["cpp", "c++", "cc", "cxx", "hpp", "h++", "hh", "hxx"], alias: ["cpp"] },
        { name: "Cobol", mime: "text/x-cobol", mode: "cobol", ext: ["cob", "cpy", "cbl"] },
        { name: "C#", mime: "text/x-csharp", mode: "clike", ext: ["cs"], alias: ["csharp", "cs"] },
        { name: "Clojure", mime: "text/x-clojure", mode: "clojure", ext: ["clj", "cljc", "cljx"] },
        { name: "ClojureScript", mime: "text/x-clojurescript", mode: "clojure", ext: ["cljs"] },
        { name: "Closure Stylesheets (GSS)", mime: "text/x-gss", mode: "css", ext: ["gss"] },
        { name: "CMake", mime: "text/x-cmake", mode: "cmake", ext: ["cmake", "cmake.in"], file: /^CMakeLists\.txt$/ },
        { name: "CoffeeScript", mimes: ["application/vnd.coffeescript", "text/coffeescript", "text/x-coffeescript"], mode: "coffeescript", ext: ["coffee"], alias: ["coffee", "coffee-script"] },
        { name: "Common Lisp", mime: "text/x-common-lisp", mode: "commonlisp", ext: ["cl", "lisp", "el"], alias: ["lisp"] },
        { name: "Cypher", mime: "application/x-cypher-query", mode: "cypher", ext: ["cyp", "cypher"] },
        { name: "Cython", mime: "text/x-cython", mode: "python", ext: ["pyx", "pxd", "pxi"] },
        { name: "Crystal", mime: "text/x-crystal", mode: "crystal", ext: ["cr"] },
        { name: "CSS", mime: "text/css", mode: "css", ext: ["css"] },
        { name: "CQL", mime: "text/x-cassandra", mode: "sql", ext: ["cql"] },
        { name: "D", mime: "text/x-d", mode: "d", ext: ["d"] },
        { name: "Dart", mimes: ["application/dart", "text/x-dart"], mode: "dart", ext: ["dart"] },
        { name: "diff", mime: "text/x-diff", mode: "diff", ext: ["diff", "patch"] },
        { name: "Django", mime: "text/x-django", mode: "django" },
        { name: "Dockerfile", mime: "text/x-dockerfile", mode: "dockerfile", file: /^Dockerfile$/ },
        { name: "DTD", mime: "application/xml-dtd", mode: "dtd", ext: ["dtd"] },
        { name: "Dylan", mime: "text/x-dylan", mode: "dylan", ext: ["dylan", "dyl", "intr"] },
        { name: "EBNF", mime: "text/x-ebnf", mode: "ebnf" },
        { name: "ECL", mime: "text/x-ecl", mode: "ecl", ext: ["ecl"] },
        { name: "edn", mime: "application/edn", mode: "clojure", ext: ["edn"] },
        { name: "Eiffel", mime: "text/x-eiffel", mode: "eiffel", ext: ["e"] },
        { name: "Elm", mime: "text/x-elm", mode: "elm", ext: ["elm"] },
        { name: "Embedded JavaScript", mime: "application/x-ejs", mode: "htmlembedded", ext: ["ejs"] },
        { name: "Embedded Ruby", mime: "application/x-erb", mode: "htmlembedded", ext: ["erb"] },
        { name: "Erlang", mime: "text/x-erlang", mode: "erlang", ext: ["erl"] },
        { name: "Esper", mime: "text/x-esper", mode: "sql" },
        { name: "Factor", mime: "text/x-factor", mode: "factor", ext: ["factor"] },
        { name: "FCL", mime: "text/x-fcl", mode: "fcl" },
        { name: "Forth", mime: "text/x-forth", mode: "forth", ext: ["forth", "fth", "4th"] },
        { name: "Fortran", mime: "text/x-fortran", mode: "fortran", ext: ["f", "for", "f77", "f90", "f95"] },
        { name: "F#", mime: "text/x-fsharp", mode: "mllike", ext: ["fs"], alias: ["fsharp"] },
        { name: "Gas", mime: "text/x-gas", mode: "gas", ext: ["s"] },
        { name: "Gherkin", mime: "text/x-feature", mode: "gherkin", ext: ["feature"] },
        { name: "GitHub Flavored Markdown", mime: "text/x-gfm", mode: "gfm", file: /^(readme|contributing|history)\.md$/i },
        { name: "Go", mime: "text/x-go", mode: "go", ext: ["go"] },
        { name: "Groovy", mime: "text/x-groovy", mode: "groovy", ext: ["groovy", "gradle"], file: /^Jenkinsfile$/ },
        { name: "HAML", mime: "text/x-haml", mode: "haml", ext: ["haml"] },
        { name: "Haskell", mime: "text/x-haskell", mode: "haskell", ext: ["hs"] },
        { name: "Haskell (Literate)", mime: "text/x-literate-haskell", mode: "haskell-literate", ext: ["lhs"] },
        { name: "Haxe", mime: "text/x-haxe", mode: "haxe", ext: ["hx"] },
        { name: "HXML", mime: "text/x-hxml", mode: "haxe", ext: ["hxml"] },
        { name: "ASP.NET", mime: "application/x-aspx", mode: "htmlembedded", ext: ["aspx"], alias: ["asp", "aspx"] },
        { name: "HTML", mime: "text/html", mode: "htmlmixed", ext: ["html", "htm", "handlebars", "hbs"], alias: ["xhtml"] },
        { name: "HTTP", mime: "message/http", mode: "http" },
        { name: "IDL", mime: "text/x-idl", mode: "idl", ext: ["pro"] },
        { name: "Pug", mime: "text/x-pug", mode: "pug", ext: ["jade", "pug"], alias: ["jade"] },
        { name: "Java", mime: "text/x-java", mode: "clike", ext: ["java"] },
        { name: "Java Server Pages", mime: "application/x-jsp", mode: "htmlembedded", ext: ["jsp"], alias: ["jsp"] },
        {
          name: "JavaScript",
          mimes: ["text/javascript", "text/ecmascript", "application/javascript", "application/x-javascript", "application/ecmascript"],
          mode: "javascript",
          ext: ["js"],
          alias: ["ecmascript", "js", "node"]
        },
        { name: "JSON", mimes: ["application/json", "application/x-json"], mode: "javascript", ext: ["json", "map"], alias: ["json5"] },
        { name: "JSON-LD", mime: "application/ld+json", mode: "javascript", ext: ["jsonld"], alias: ["jsonld"] },
        { name: "JSX", mime: "text/jsx", mode: "jsx", ext: ["jsx"] },
        { name: "Jinja2", mime: "text/jinja2", mode: "jinja2", ext: ["j2", "jinja", "jinja2"] },
        { name: "Julia", mime: "text/x-julia", mode: "julia", ext: ["jl"], alias: ["jl"] },
        { name: "Kotlin", mime: "text/x-kotlin", mode: "clike", ext: ["kt"] },
        { name: "LESS", mime: "text/x-less", mode: "css", ext: ["less"] },
        { name: "LiveScript", mime: "text/x-livescript", mode: "livescript", ext: ["ls"], alias: ["ls"] },
        { name: "Lua", mime: "text/x-lua", mode: "lua", ext: ["lua"] },
        { name: "Markdown", mime: "text/x-markdown", mode: "markdown", ext: ["markdown", "md", "mkd"] },
        { name: "mIRC", mime: "text/mirc", mode: "mirc" },
        { name: "MariaDB SQL", mime: "text/x-mariadb", mode: "sql" },
        { name: "Mathematica", mime: "text/x-mathematica", mode: "mathematica", ext: ["m", "nb", "wl", "wls"] },
        { name: "Modelica", mime: "text/x-modelica", mode: "modelica", ext: ["mo"] },
        { name: "MUMPS", mime: "text/x-mumps", mode: "mumps", ext: ["mps"] },
        { name: "MS SQL", mime: "text/x-mssql", mode: "sql" },
        { name: "mbox", mime: "application/mbox", mode: "mbox", ext: ["mbox"] },
        { name: "MySQL", mime: "text/x-mysql", mode: "sql" },
        { name: "Nginx", mime: "text/x-nginx-conf", mode: "nginx", file: /nginx.*\.conf$/i },
        { name: "NSIS", mime: "text/x-nsis", mode: "nsis", ext: ["nsh", "nsi"] },
        {
          name: "NTriples",
          mimes: ["application/n-triples", "application/n-quads", "text/n-triples"],
          mode: "ntriples",
          ext: ["nt", "nq"]
        },
        { name: "Objective-C", mime: "text/x-objectivec", mode: "clike", ext: ["m"], alias: ["objective-c", "objc"] },
        { name: "Objective-C++", mime: "text/x-objectivec++", mode: "clike", ext: ["mm"], alias: ["objective-c++", "objc++"] },
        { name: "OCaml", mime: "text/x-ocaml", mode: "mllike", ext: ["ml", "mli", "mll", "mly"] },
        { name: "Octave", mime: "text/x-octave", mode: "octave", ext: ["m"] },
        { name: "Oz", mime: "text/x-oz", mode: "oz", ext: ["oz"] },
        { name: "Pascal", mime: "text/x-pascal", mode: "pascal", ext: ["p", "pas"] },
        { name: "PEG.js", mime: "null", mode: "pegjs", ext: ["jsonld"] },
        { name: "Perl", mime: "text/x-perl", mode: "perl", ext: ["pl", "pm"] },
        { name: "PHP", mimes: ["text/x-php", "application/x-httpd-php", "application/x-httpd-php-open"], mode: "php", ext: ["php", "php3", "php4", "php5", "php7", "phtml"] },
        { name: "Pig", mime: "text/x-pig", mode: "pig", ext: ["pig"] },
        { name: "Plain Text", mime: "text/plain", mode: "null", ext: ["txt", "text", "conf", "def", "list", "log"] },
        { name: "PLSQL", mime: "text/x-plsql", mode: "sql", ext: ["pls"] },
        { name: "PostgreSQL", mime: "text/x-pgsql", mode: "sql" },
        { name: "PowerShell", mime: "application/x-powershell", mode: "powershell", ext: ["ps1", "psd1", "psm1"] },
        { name: "Properties files", mime: "text/x-properties", mode: "properties", ext: ["properties", "ini", "in"], alias: ["ini", "properties"] },
        { name: "ProtoBuf", mime: "text/x-protobuf", mode: "protobuf", ext: ["proto"] },
        { name: "Python", mime: "text/x-python", mode: "python", ext: ["BUILD", "bzl", "py", "pyw"], file: /^(BUCK|BUILD)$/ },
        { name: "Puppet", mime: "text/x-puppet", mode: "puppet", ext: ["pp"] },
        { name: "Q", mime: "text/x-q", mode: "q", ext: ["q"] },
        { name: "R", mime: "text/x-rsrc", mode: "r", ext: ["r", "R"], alias: ["rscript"] },
        { name: "reStructuredText", mime: "text/x-rst", mode: "rst", ext: ["rst"], alias: ["rst"] },
        { name: "RPM Changes", mime: "text/x-rpm-changes", mode: "rpm" },
        { name: "RPM Spec", mime: "text/x-rpm-spec", mode: "rpm", ext: ["spec"] },
        { name: "Ruby", mime: "text/x-ruby", mode: "ruby", ext: ["rb"], alias: ["jruby", "macruby", "rake", "rb", "rbx"] },
        { name: "Rust", mime: "text/x-rustsrc", mode: "rust", ext: ["rs"] },
        { name: "SAS", mime: "text/x-sas", mode: "sas", ext: ["sas"] },
        { name: "Sass", mime: "text/x-sass", mode: "sass", ext: ["sass"] },
        { name: "Scala", mime: "text/x-scala", mode: "clike", ext: ["scala"] },
        { name: "Scheme", mime: "text/x-scheme", mode: "scheme", ext: ["scm", "ss"] },
        { name: "SCSS", mime: "text/x-scss", mode: "css", ext: ["scss"] },
        { name: "Shell", mimes: ["text/x-sh", "application/x-sh"], mode: "shell", ext: ["sh", "ksh", "bash"], alias: ["bash", "sh", "zsh"], file: /^PKGBUILD$/ },
        { name: "Sieve", mime: "application/sieve", mode: "sieve", ext: ["siv", "sieve"] },
        { name: "Slim", mimes: ["text/x-slim", "application/x-slim"], mode: "slim", ext: ["slim"] },
        { name: "Smalltalk", mime: "text/x-stsrc", mode: "smalltalk", ext: ["st"] },
        { name: "Smarty", mime: "text/x-smarty", mode: "smarty", ext: ["tpl"] },
        { name: "Solr", mime: "text/x-solr", mode: "solr" },
        { name: "SML", mime: "text/x-sml", mode: "mllike", ext: ["sml", "sig", "fun", "smackspec"] },
        { name: "Soy", mime: "text/x-soy", mode: "soy", ext: ["soy"], alias: ["closure template"] },
        { name: "SPARQL", mime: "application/sparql-query", mode: "sparql", ext: ["rq", "sparql"], alias: ["sparul"] },
        { name: "Spreadsheet", mime: "text/x-spreadsheet", mode: "spreadsheet", alias: ["excel", "formula"] },
        { name: "SQL", mime: "text/x-sql", mode: "sql", ext: ["sql"] },
        { name: "SQLite", mime: "text/x-sqlite", mode: "sql" },
        { name: "Squirrel", mime: "text/x-squirrel", mode: "clike", ext: ["nut"] },
        { name: "Stylus", mime: "text/x-styl", mode: "stylus", ext: ["styl"] },
        { name: "Swift", mime: "text/x-swift", mode: "swift", ext: ["swift"] },
        { name: "sTeX", mime: "text/x-stex", mode: "stex" },
        { name: "LaTeX", mime: "text/x-latex", mode: "stex", ext: ["text", "ltx", "tex"], alias: ["tex"] },
        { name: "SystemVerilog", mime: "text/x-systemverilog", mode: "verilog", ext: ["v", "sv", "svh"] },
        { name: "Tcl", mime: "text/x-tcl", mode: "tcl", ext: ["tcl"] },
        { name: "Textile", mime: "text/x-textile", mode: "textile", ext: ["textile"] },
        { name: "TiddlyWiki", mime: "text/x-tiddlywiki", mode: "tiddlywiki" },
        { name: "Tiki wiki", mime: "text/tiki", mode: "tiki" },
        { name: "TOML", mime: "text/x-toml", mode: "toml", ext: ["toml"] },
        { name: "Tornado", mime: "text/x-tornado", mode: "tornado" },
        { name: "troff", mime: "text/troff", mode: "troff", ext: ["1", "2", "3", "4", "5", "6", "7", "8", "9"] },
        { name: "TTCN", mime: "text/x-ttcn", mode: "ttcn", ext: ["ttcn", "ttcn3", "ttcnpp"] },
        { name: "TTCN_CFG", mime: "text/x-ttcn-cfg", mode: "ttcn-cfg", ext: ["cfg"] },
        { name: "Turtle", mime: "text/turtle", mode: "turtle", ext: ["ttl"] },
        { name: "TypeScript", mime: "application/typescript", mode: "javascript", ext: ["ts"], alias: ["ts"] },
        { name: "TypeScript-JSX", mime: "text/typescript-jsx", mode: "jsx", ext: ["tsx"], alias: ["tsx"] },
        { name: "Twig", mime: "text/x-twig", mode: "twig" },
        { name: "Web IDL", mime: "text/x-webidl", mode: "webidl", ext: ["webidl"] },
        { name: "VB.NET", mime: "text/x-vb", mode: "vb", ext: ["vb"] },
        { name: "VBScript", mime: "text/vbscript", mode: "vbscript", ext: ["vbs"] },
        { name: "Velocity", mime: "text/velocity", mode: "velocity", ext: ["vtl"] },
        { name: "Verilog", mime: "text/x-verilog", mode: "verilog", ext: ["v"] },
        { name: "VHDL", mime: "text/x-vhdl", mode: "vhdl", ext: ["vhd", "vhdl"] },
        { name: "Vue.js Component", mimes: ["script/x-vue", "text/x-vue"], mode: "vue", ext: ["vue"] },
        { name: "XML", mimes: ["application/xml", "text/xml"], mode: "xml", ext: ["xml", "xsl", "xsd", "svg"], alias: ["rss", "wsdl", "xsd"] },
        { name: "XQuery", mime: "application/xquery", mode: "xquery", ext: ["xy", "xquery"] },
        { name: "Yacas", mime: "text/x-yacas", mode: "yacas", ext: ["ys"] },
        { name: "YAML", mimes: ["text/x-yaml", "text/yaml"], mode: "yaml", ext: ["yaml", "yml"], alias: ["yml"] },
        { name: "Z80", mime: "text/x-z80", mode: "z80", ext: ["z80"] },
        { name: "mscgen", mime: "text/x-mscgen", mode: "mscgen", ext: ["mscgen", "mscin", "msc"] },
        { name: "xu", mime: "text/x-xu", mode: "mscgen", ext: ["xu"] },
        { name: "msgenny", mime: "text/x-msgenny", mode: "mscgen", ext: ["msgenny"] },
        { name: "WebAssembly", mime: "text/webassembly", mode: "wast", ext: ["wat", "wast"] }
      ];
      for (var v = 0; v < c.modeInfo.length; v++) {
        var m = c.modeInfo[v];
        m.mimes && (m.mime = m.mimes[0]);
      }
      c.findModeByMIME = function(C) {
        C = C.toLowerCase();
        for (var g = 0; g < c.modeInfo.length; g++) {
          var y = c.modeInfo[g];
          if (y.mime == C)
            return y;
          if (y.mimes) {
            for (var x = 0; x < y.mimes.length; x++)
              if (y.mimes[x] == C)
                return y;
          }
        }
        if (/\+xml$/.test(C))
          return c.findModeByMIME("application/xml");
        if (/\+json$/.test(C))
          return c.findModeByMIME("application/json");
      }, c.findModeByExtension = function(C) {
        C = C.toLowerCase();
        for (var g = 0; g < c.modeInfo.length; g++) {
          var y = c.modeInfo[g];
          if (y.ext) {
            for (var x = 0; x < y.ext.length; x++)
              if (y.ext[x] == C)
                return y;
          }
        }
      }, c.findModeByFileName = function(C) {
        for (var g = 0; g < c.modeInfo.length; g++) {
          var y = c.modeInfo[g];
          if (y.file && y.file.test(C))
            return y;
        }
        var x = C.lastIndexOf("."), A = x > -1 && C.substring(x + 1, C.length);
        if (A)
          return c.findModeByExtension(A);
      }, c.findModeByName = function(C) {
        C = C.toLowerCase();
        for (var g = 0; g < c.modeInfo.length; g++) {
          var y = c.modeInfo[g];
          if (y.name.toLowerCase() == C)
            return y;
          if (y.alias) {
            for (var x = 0; x < y.alias.length; x++)
              if (y.alias[x].toLowerCase() == C)
                return y;
          }
        }
      };
    });
  }()), jo.exports;
}
(function(s, b) {
  (function(c) {
    c(Tt, Cf, wf());
  })(function(c) {
    c.defineMode("markdown", function(v, m) {
      var C = c.getMode(v, "text/html"), g = C.name == "null";
      function y(S) {
        if (c.findModeByName) {
          var d = c.findModeByName(S);
          d && (S = d.mime || d.mimes[0]);
        }
        var j = c.getMode(v, S);
        return j.name == "null" ? null : j;
      }
      m.highlightFormatting === void 0 && (m.highlightFormatting = !1), m.maxBlockquoteDepth === void 0 && (m.maxBlockquoteDepth = 0), m.taskLists === void 0 && (m.taskLists = !1), m.strikethrough === void 0 && (m.strikethrough = !1), m.emoji === void 0 && (m.emoji = !1), m.fencedCodeBlockHighlighting === void 0 && (m.fencedCodeBlockHighlighting = !0), m.fencedCodeBlockDefaultMode === void 0 && (m.fencedCodeBlockDefaultMode = "text/plain"), m.xml === void 0 && (m.xml = !0), m.tokenTypeOverrides === void 0 && (m.tokenTypeOverrides = {});
      var x = {
        header: "header",
        code: "comment",
        quote: "quote",
        list1: "variable-2",
        list2: "variable-3",
        list3: "keyword",
        hr: "hr",
        image: "image",
        imageAltText: "image-alt-text",
        imageMarker: "image-marker",
        formatting: "formatting",
        linkInline: "link",
        linkEmail: "link",
        linkText: "link",
        linkHref: "string",
        em: "em",
        strong: "strong",
        strikethrough: "strikethrough",
        emoji: "builtin"
      };
      for (var A in x)
        x.hasOwnProperty(A) && m.tokenTypeOverrides[A] && (x[A] = m.tokenTypeOverrides[A]);
      var z = /^([*\-_])(?:\s*\1){2,}\s*$/, P = /^(?:[*\-+]|^[0-9]+([.)]))\s+/, N = /^\[(x| )\](?=\s)/i, G = m.allowAtxHeaderWithoutSpace ? /^(#+)/ : /^(#+)(?: |$)/, X = /^ {0,3}(?:\={1,}|-{2,})\s*$/, le = /^[^#!\[\]*_\\<>` "'(~:]+/, J = /^(~~~+|```+)[ \t]*([\w\/+#-]*)[^\n`]*$/, Q = /^\s*\[[^\]]+?\]:.*$/, H = /[!"#$%&'()*+,\-.\/:;<=>?@\[\\\]^_`{|}~\xA1\xA7\xAB\xB6\xB7\xBB\xBF\u037E\u0387\u055A-\u055F\u0589\u058A\u05BE\u05C0\u05C3\u05C6\u05F3\u05F4\u0609\u060A\u060C\u060D\u061B\u061E\u061F\u066A-\u066D\u06D4\u0700-\u070D\u07F7-\u07F9\u0830-\u083E\u085E\u0964\u0965\u0970\u0AF0\u0DF4\u0E4F\u0E5A\u0E5B\u0F04-\u0F12\u0F14\u0F3A-\u0F3D\u0F85\u0FD0-\u0FD4\u0FD9\u0FDA\u104A-\u104F\u10FB\u1360-\u1368\u1400\u166D\u166E\u169B\u169C\u16EB-\u16ED\u1735\u1736\u17D4-\u17D6\u17D8-\u17DA\u1800-\u180A\u1944\u1945\u1A1E\u1A1F\u1AA0-\u1AA6\u1AA8-\u1AAD\u1B5A-\u1B60\u1BFC-\u1BFF\u1C3B-\u1C3F\u1C7E\u1C7F\u1CC0-\u1CC7\u1CD3\u2010-\u2027\u2030-\u2043\u2045-\u2051\u2053-\u205E\u207D\u207E\u208D\u208E\u2308-\u230B\u2329\u232A\u2768-\u2775\u27C5\u27C6\u27E6-\u27EF\u2983-\u2998\u29D8-\u29DB\u29FC\u29FD\u2CF9-\u2CFC\u2CFE\u2CFF\u2D70\u2E00-\u2E2E\u2E30-\u2E42\u3001-\u3003\u3008-\u3011\u3014-\u301F\u3030\u303D\u30A0\u30FB\uA4FE\uA4FF\uA60D-\uA60F\uA673\uA67E\uA6F2-\uA6F7\uA874-\uA877\uA8CE\uA8CF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA95F\uA9C1-\uA9CD\uA9DE\uA9DF\uAA5C-\uAA5F\uAADE\uAADF\uAAF0\uAAF1\uABEB\uFD3E\uFD3F\uFE10-\uFE19\uFE30-\uFE52\uFE54-\uFE61\uFE63\uFE68\uFE6A\uFE6B\uFF01-\uFF03\uFF05-\uFF0A\uFF0C-\uFF0F\uFF1A\uFF1B\uFF1F\uFF20\uFF3B-\uFF3D\uFF3F\uFF5B\uFF5D\uFF5F-\uFF65]|\uD800[\uDD00-\uDD02\uDF9F\uDFD0]|\uD801\uDD6F|\uD802[\uDC57\uDD1F\uDD3F\uDE50-\uDE58\uDE7F\uDEF0-\uDEF6\uDF39-\uDF3F\uDF99-\uDF9C]|\uD804[\uDC47-\uDC4D\uDCBB\uDCBC\uDCBE-\uDCC1\uDD40-\uDD43\uDD74\uDD75\uDDC5-\uDDC9\uDDCD\uDDDB\uDDDD-\uDDDF\uDE38-\uDE3D\uDEA9]|\uD805[\uDCC6\uDDC1-\uDDD7\uDE41-\uDE43\uDF3C-\uDF3E]|\uD809[\uDC70-\uDC74]|\uD81A[\uDE6E\uDE6F\uDEF5\uDF37-\uDF3B\uDF44]|\uD82F\uDC9F|\uD836[\uDE87-\uDE8B]/, q = "    ";
      function R(S, d, j) {
        return d.f = d.inline = j, j(S, d);
      }
      function _(S, d, j) {
        return d.f = d.block = j, j(S, d);
      }
      function te(S) {
        return !S || !/\S/.test(S.string);
      }
      function Y(S) {
        if (S.linkTitle = !1, S.linkHref = !1, S.linkText = !1, S.em = !1, S.strong = !1, S.strikethrough = !1, S.quote = 0, S.indentedCode = !1, S.f == pe) {
          var d = g;
          if (!d) {
            var j = c.innerMode(C, S.htmlState);
            d = j.mode.name == "xml" && j.state.tagStart === null && !j.state.context && j.state.tokenize.isInText;
          }
          d && (S.f = ke, S.block = oe, S.htmlState = null);
        }
        return S.trailingSpace = 0, S.trailingSpaceNewLine = !1, S.prevLine = S.thisLine, S.thisLine = { stream: null }, null;
      }
      function oe(S, d) {
        var j = S.column() === d.indentation, Ne = te(d.prevLine.stream), Ee = d.indentedCode, $e = d.prevLine.hr, ht = d.list !== !1, Xe = (d.listStack[d.listStack.length - 1] || 0) + 3;
        d.indentedCode = !1;
        var nt = d.indentation;
        if (d.indentationDiff === null && (d.indentationDiff = d.indentation, ht)) {
          for (d.list = null; nt < d.listStack[d.listStack.length - 1]; )
            d.listStack.pop(), d.listStack.length ? d.indentation = d.listStack[d.listStack.length - 1] : d.list = !1;
          d.list !== !1 && (d.indentationDiff = nt - d.listStack[d.listStack.length - 1]);
        }
        var Ie = !Ne && !$e && !d.prevLine.header && (!ht || !Ee) && !d.prevLine.fencedCodeEnd, _e = (d.list === !1 || $e || Ne) && d.indentation <= Xe && S.match(z), Je = null;
        if (d.indentationDiff >= 4 && (Ee || d.prevLine.fencedCodeEnd || d.prevLine.header || Ne))
          return S.skipToEnd(), d.indentedCode = !0, x.code;
        if (S.eatSpace())
          return null;
        if (j && d.indentation <= Xe && (Je = S.match(G)) && Je[1].length <= 6)
          return d.quote = 0, d.header = Je[1].length, d.thisLine.header = !0, m.highlightFormatting && (d.formatting = "header"), d.f = d.inline, ae(d);
        if (d.indentation <= Xe && S.eat(">"))
          return d.quote = j ? 1 : d.quote + 1, m.highlightFormatting && (d.formatting = "quote"), S.eatSpace(), ae(d);
        if (!_e && !d.setext && j && d.indentation <= Xe && (Je = S.match(P))) {
          var dt = Je[1] ? "ol" : "ul";
          return d.indentation = nt + S.current().length, d.list = !0, d.quote = 0, d.listStack.push(d.indentation), d.em = !1, d.strong = !1, d.code = !1, d.strikethrough = !1, m.taskLists && S.match(N, !1) && (d.taskList = !0), d.f = d.inline, m.highlightFormatting && (d.formatting = ["list", "list-" + dt]), ae(d);
        } else {
          if (j && d.indentation <= Xe && (Je = S.match(J, !0)))
            return d.quote = 0, d.fencedEndRE = new RegExp(Je[1] + "+ *$"), d.localMode = m.fencedCodeBlockHighlighting && y(Je[2] || m.fencedCodeBlockDefaultMode), d.localMode && (d.localState = c.startState(d.localMode)), d.f = d.block = qe, m.highlightFormatting && (d.formatting = "code-block"), d.code = -1, ae(d);
          if (
            // if setext set, indicates line after ---/===
            d.setext || // line before ---/===
            (!Ie || !ht) && !d.quote && d.list === !1 && !d.code && !_e && !Q.test(S.string) && (Je = S.lookAhead(1)) && (Je = Je.match(X))
          )
            return d.setext ? (d.header = d.setext, d.setext = 0, S.skipToEnd(), m.highlightFormatting && (d.formatting = "header")) : (d.header = Je[0].charAt(0) == "=" ? 1 : 2, d.setext = d.header), d.thisLine.header = !0, d.f = d.inline, ae(d);
          if (_e)
            return S.skipToEnd(), d.hr = !0, d.thisLine.hr = !0, x.hr;
          if (S.peek() === "[")
            return R(S, d, ge);
        }
        return R(S, d, d.inline);
      }
      function pe(S, d) {
        var j = C.token(S, d.htmlState);
        if (!g) {
          var Ne = c.innerMode(C, d.htmlState);
          (Ne.mode.name == "xml" && Ne.state.tagStart === null && !Ne.state.context && Ne.state.tokenize.isInText || d.md_inside && S.current().indexOf(">") > -1) && (d.f = ke, d.block = oe, d.htmlState = null);
        }
        return j;
      }
      function qe(S, d) {
        var j = d.listStack[d.listStack.length - 1] || 0, Ne = d.indentation < j, Ee = j + 3;
        if (d.fencedEndRE && d.indentation <= Ee && (Ne || S.match(d.fencedEndRE))) {
          m.highlightFormatting && (d.formatting = "code-block");
          var $e;
          return Ne || ($e = ae(d)), d.localMode = d.localState = null, d.block = oe, d.f = ke, d.fencedEndRE = null, d.code = 0, d.thisLine.fencedCodeEnd = !0, Ne ? _(S, d, d.block) : $e;
        } else
          return d.localMode ? d.localMode.token(S, d.localState) : (S.skipToEnd(), x.code);
      }
      function ae(S) {
        var d = [];
        if (S.formatting) {
          d.push(x.formatting), typeof S.formatting == "string" && (S.formatting = [S.formatting]);
          for (var j = 0; j < S.formatting.length; j++)
            d.push(x.formatting + "-" + S.formatting[j]), S.formatting[j] === "header" && d.push(x.formatting + "-" + S.formatting[j] + "-" + S.header), S.formatting[j] === "quote" && (!m.maxBlockquoteDepth || m.maxBlockquoteDepth >= S.quote ? d.push(x.formatting + "-" + S.formatting[j] + "-" + S.quote) : d.push("error"));
        }
        if (S.taskOpen)
          return d.push("meta"), d.length ? d.join(" ") : null;
        if (S.taskClosed)
          return d.push("property"), d.length ? d.join(" ") : null;
        if (S.linkHref ? d.push(x.linkHref, "url") : (S.strong && d.push(x.strong), S.em && d.push(x.em), S.strikethrough && d.push(x.strikethrough), S.emoji && d.push(x.emoji), S.linkText && d.push(x.linkText), S.code && d.push(x.code), S.image && d.push(x.image), S.imageAltText && d.push(x.imageAltText, "link"), S.imageMarker && d.push(x.imageMarker)), S.header && d.push(x.header, x.header + "-" + S.header), S.quote && (d.push(x.quote), !m.maxBlockquoteDepth || m.maxBlockquoteDepth >= S.quote ? d.push(x.quote + "-" + S.quote) : d.push(x.quote + "-" + m.maxBlockquoteDepth)), S.list !== !1) {
          var Ne = (S.listStack.length - 1) % 3;
          Ne ? Ne === 1 ? d.push(x.list2) : d.push(x.list3) : d.push(x.list1);
        }
        return S.trailingSpaceNewLine ? d.push("trailing-space-new-line") : S.trailingSpace && d.push("trailing-space-" + (S.trailingSpace % 2 ? "a" : "b")), d.length ? d.join(" ") : null;
      }
      function Se(S, d) {
        if (S.match(le, !0))
          return ae(d);
      }
      function ke(S, d) {
        var j = d.text(S, d);
        if (typeof j < "u")
          return j;
        if (d.list)
          return d.list = null, ae(d);
        if (d.taskList) {
          var Ne = S.match(N, !0)[1] === " ";
          return Ne ? d.taskOpen = !0 : d.taskClosed = !0, m.highlightFormatting && (d.formatting = "task"), d.taskList = !1, ae(d);
        }
        if (d.taskOpen = !1, d.taskClosed = !1, d.header && S.match(/^#+$/, !0))
          return m.highlightFormatting && (d.formatting = "header"), ae(d);
        var Ee = S.next();
        if (d.linkTitle) {
          d.linkTitle = !1;
          var $e = Ee;
          Ee === "(" && ($e = ")"), $e = ($e + "").replace(/([.?*+^\[\]\\(){}|-])/g, "\\$1");
          var ht = "^\\s*(?:[^" + $e + "\\\\]+|\\\\\\\\|\\\\.)" + $e;
          if (S.match(new RegExp(ht), !0))
            return x.linkHref;
        }
        if (Ee === "`") {
          var Xe = d.formatting;
          m.highlightFormatting && (d.formatting = "code"), S.eatWhile("`");
          var nt = S.current().length;
          if (d.code == 0 && (!d.quote || nt == 1))
            return d.code = nt, ae(d);
          if (nt == d.code) {
            var Ie = ae(d);
            return d.code = 0, Ie;
          } else
            return d.formatting = Xe, ae(d);
        } else if (d.code)
          return ae(d);
        if (Ee === "\\" && (S.next(), m.highlightFormatting)) {
          var _e = ae(d), Je = x.formatting + "-escape";
          return _e ? _e + " " + Je : Je;
        }
        if (Ee === "!" && S.match(/\[[^\]]*\] ?(?:\(|\[)/, !1))
          return d.imageMarker = !0, d.image = !0, m.highlightFormatting && (d.formatting = "image"), ae(d);
        if (Ee === "[" && d.imageMarker && S.match(/[^\]]*\](\(.*?\)| ?\[.*?\])/, !1))
          return d.imageMarker = !1, d.imageAltText = !0, m.highlightFormatting && (d.formatting = "image"), ae(d);
        if (Ee === "]" && d.imageAltText) {
          m.highlightFormatting && (d.formatting = "image");
          var _e = ae(d);
          return d.imageAltText = !1, d.image = !1, d.inline = d.f = T, _e;
        }
        if (Ee === "[" && !d.image)
          return d.linkText && S.match(/^.*?\]/) || (d.linkText = !0, m.highlightFormatting && (d.formatting = "link")), ae(d);
        if (Ee === "]" && d.linkText) {
          m.highlightFormatting && (d.formatting = "link");
          var _e = ae(d);
          return d.linkText = !1, d.inline = d.f = S.match(/\(.*?\)| ?\[.*?\]/, !1) ? T : ke, _e;
        }
        if (Ee === "<" && S.match(/^(https?|ftps?):\/\/(?:[^\\>]|\\.)+>/, !1)) {
          d.f = d.inline = De, m.highlightFormatting && (d.formatting = "link");
          var _e = ae(d);
          return _e ? _e += " " : _e = "", _e + x.linkInline;
        }
        if (Ee === "<" && S.match(/^[^> \\]+@(?:[^\\>]|\\.)+>/, !1)) {
          d.f = d.inline = De, m.highlightFormatting && (d.formatting = "link");
          var _e = ae(d);
          return _e ? _e += " " : _e = "", _e + x.linkEmail;
        }
        if (m.xml && Ee === "<" && S.match(/^(!--|\?|!\[CDATA\[|[a-z][a-z0-9-]*(?:\s+[a-z_:.\-]+(?:\s*=\s*[^>]+)?)*\s*(?:>|$))/i, !1)) {
          var dt = S.string.indexOf(">", S.pos);
          if (dt != -1) {
            var ye = S.string.substring(S.start, dt);
            /markdown\s*=\s*('|"){0,1}1('|"){0,1}/.test(ye) && (d.md_inside = !0);
          }
          return S.backUp(1), d.htmlState = c.startState(C), _(S, d, pe);
        }
        if (m.xml && Ee === "<" && S.match(/^\/\w*?>/))
          return d.md_inside = !1, "tag";
        if (Ee === "*" || Ee === "_") {
          for (var Bt = 1, Mt = S.pos == 1 ? " " : S.string.charAt(S.pos - 2); Bt < 3 && S.eat(Ee); )
            Bt++;
          var At = S.peek() || " ", Wt = !/\s/.test(At) && (!H.test(At) || /\s/.test(Mt) || H.test(Mt)), Be = !/\s/.test(Mt) && (!H.test(Mt) || /\s/.test(At) || H.test(At)), Et = null, _t = null;
          if (Bt % 2 && (!d.em && Wt && (Ee === "*" || !Be || H.test(Mt)) ? Et = !0 : d.em == Ee && Be && (Ee === "*" || !Wt || H.test(At)) && (Et = !1)), Bt > 1 && (!d.strong && Wt && (Ee === "*" || !Be || H.test(Mt)) ? _t = !0 : d.strong == Ee && Be && (Ee === "*" || !Wt || H.test(At)) && (_t = !1)), _t != null || Et != null) {
            m.highlightFormatting && (d.formatting = Et == null ? "strong" : _t == null ? "em" : "strong em"), Et === !0 && (d.em = Ee), _t === !0 && (d.strong = Ee);
            var Ie = ae(d);
            return Et === !1 && (d.em = !1), _t === !1 && (d.strong = !1), Ie;
          }
        } else if (Ee === " " && (S.eat("*") || S.eat("_"))) {
          if (S.peek() === " ")
            return ae(d);
          S.backUp(1);
        }
        if (m.strikethrough) {
          if (Ee === "~" && S.eatWhile(Ee)) {
            if (d.strikethrough) {
              m.highlightFormatting && (d.formatting = "strikethrough");
              var Ie = ae(d);
              return d.strikethrough = !1, Ie;
            } else if (S.match(/^[^\s]/, !1))
              return d.strikethrough = !0, m.highlightFormatting && (d.formatting = "strikethrough"), ae(d);
          } else if (Ee === " " && S.match("~~", !0)) {
            if (S.peek() === " ")
              return ae(d);
            S.backUp(2);
          }
        }
        if (m.emoji && Ee === ":" && S.match(/^(?:[a-z_\d+][a-z_\d+-]*|\-[a-z_\d+][a-z_\d+-]*):/)) {
          d.emoji = !0, m.highlightFormatting && (d.formatting = "emoji");
          var Tr = ae(d);
          return d.emoji = !1, Tr;
        }
        return Ee === " " && (S.match(/^ +$/, !1) ? d.trailingSpace++ : d.trailingSpace && (d.trailingSpaceNewLine = !0)), ae(d);
      }
      function De(S, d) {
        var j = S.next();
        if (j === ">") {
          d.f = d.inline = ke, m.highlightFormatting && (d.formatting = "link");
          var Ne = ae(d);
          return Ne ? Ne += " " : Ne = "", Ne + x.linkInline;
        }
        return S.match(/^[^>]+/, !0), x.linkInline;
      }
      function T(S, d) {
        if (S.eatSpace())
          return null;
        var j = S.next();
        return j === "(" || j === "[" ? (d.f = d.inline = Z(j === "(" ? ")" : "]"), m.highlightFormatting && (d.formatting = "link-string"), d.linkHref = !0, ae(d)) : "error";
      }
      var V = {
        ")": /^(?:[^\\\(\)]|\\.|\((?:[^\\\(\)]|\\.)*\))*?(?=\))/,
        "]": /^(?:[^\\\[\]]|\\.|\[(?:[^\\\[\]]|\\.)*\])*?(?=\])/
      };
      function Z(S) {
        return function(d, j) {
          var Ne = d.next();
          if (Ne === S) {
            j.f = j.inline = ke, m.highlightFormatting && (j.formatting = "link-string");
            var Ee = ae(j);
            return j.linkHref = !1, Ee;
          }
          return d.match(V[S]), j.linkHref = !0, ae(j);
        };
      }
      function ge(S, d) {
        return S.match(/^([^\]\\]|\\.)*\]:/, !1) ? (d.f = Me, S.next(), m.highlightFormatting && (d.formatting = "link"), d.linkText = !0, ae(d)) : R(S, d, ke);
      }
      function Me(S, d) {
        if (S.match("]:", !0)) {
          d.f = d.inline = et, m.highlightFormatting && (d.formatting = "link");
          var j = ae(d);
          return d.linkText = !1, j;
        }
        return S.match(/^([^\]\\]|\\.)+/, !0), x.linkText;
      }
      function et(S, d) {
        return S.eatSpace() ? null : (S.match(/^[^\s]+/, !0), S.peek() === void 0 ? d.linkTitle = !0 : S.match(/^(?:\s+(?:"(?:[^"\\]|\\.)+"|'(?:[^'\\]|\\.)+'|\((?:[^)\\]|\\.)+\)))?/, !0), d.f = d.inline = ke, x.linkHref + " url");
      }
      var Pt = {
        startState: function() {
          return {
            f: oe,
            prevLine: { stream: null },
            thisLine: { stream: null },
            block: oe,
            htmlState: null,
            indentation: 0,
            inline: ke,
            text: Se,
            formatting: !1,
            linkText: !1,
            linkHref: !1,
            linkTitle: !1,
            code: 0,
            em: !1,
            strong: !1,
            header: 0,
            setext: 0,
            hr: !1,
            taskList: !1,
            list: !1,
            listStack: [],
            quote: 0,
            trailingSpace: 0,
            trailingSpaceNewLine: !1,
            strikethrough: !1,
            emoji: !1,
            fencedEndRE: null
          };
        },
        copyState: function(S) {
          return {
            f: S.f,
            prevLine: S.prevLine,
            thisLine: S.thisLine,
            block: S.block,
            htmlState: S.htmlState && c.copyState(C, S.htmlState),
            indentation: S.indentation,
            localMode: S.localMode,
            localState: S.localMode ? c.copyState(S.localMode, S.localState) : null,
            inline: S.inline,
            text: S.text,
            formatting: !1,
            linkText: S.linkText,
            linkTitle: S.linkTitle,
            linkHref: S.linkHref,
            code: S.code,
            em: S.em,
            strong: S.strong,
            strikethrough: S.strikethrough,
            emoji: S.emoji,
            header: S.header,
            setext: S.setext,
            hr: S.hr,
            taskList: S.taskList,
            list: S.list,
            listStack: S.listStack.slice(0),
            quote: S.quote,
            indentedCode: S.indentedCode,
            trailingSpace: S.trailingSpace,
            trailingSpaceNewLine: S.trailingSpaceNewLine,
            md_inside: S.md_inside,
            fencedEndRE: S.fencedEndRE
          };
        },
        token: function(S, d) {
          if (d.formatting = !1, S != d.thisLine.stream) {
            if (d.header = 0, d.hr = !1, S.match(/^\s*$/, !0))
              return Y(d), null;
            if (d.prevLine = d.thisLine, d.thisLine = { stream: S }, d.taskList = !1, d.trailingSpace = 0, d.trailingSpaceNewLine = !1, !d.localState && (d.f = d.block, d.f != pe)) {
              var j = S.match(/^\s*/, !0)[0].replace(/\t/g, q).length;
              if (d.indentation = j, d.indentationDiff = null, j > 0)
                return null;
            }
          }
          return d.f(S, d);
        },
        innerMode: function(S) {
          return S.block == pe ? { state: S.htmlState, mode: C } : S.localState ? { state: S.localState, mode: S.localMode } : { state: S, mode: Pt };
        },
        indent: function(S, d, j) {
          return S.block == pe && C.indent ? C.indent(S.htmlState, d, j) : S.localState && S.localMode.indent ? S.localMode.indent(S.localState, d, j) : c.Pass;
        },
        blankLine: Y,
        getType: ae,
        blockCommentStart: "<!--",
        blockCommentEnd: "-->",
        closeBrackets: "()[]{}''\"\"``",
        fold: "markdown"
      };
      return Pt;
    }, "xml"), c.defineMIME("text/markdown", "markdown"), c.defineMIME("text/x-markdown", "markdown");
  });
})();
var kf = Df.exports, Sf = { exports: {} };
(function(s, b) {
  (function(c) {
    c(Tt);
  })(function(c) {
    c.overlayMode = function(v, m, C) {
      return {
        startState: function() {
          return {
            base: c.startState(v),
            overlay: c.startState(m),
            basePos: 0,
            baseCur: null,
            overlayPos: 0,
            overlayCur: null,
            streamSeen: null
          };
        },
        copyState: function(g) {
          return {
            base: c.copyState(v, g.base),
            overlay: c.copyState(m, g.overlay),
            basePos: g.basePos,
            baseCur: null,
            overlayPos: g.overlayPos,
            overlayCur: null
          };
        },
        token: function(g, y) {
          return (g != y.streamSeen || Math.min(y.basePos, y.overlayPos) < g.start) && (y.streamSeen = g, y.basePos = y.overlayPos = g.start), g.start == y.basePos && (y.baseCur = v.token(g, y.base), y.basePos = g.pos), g.start == y.overlayPos && (g.pos = g.start, y.overlayCur = m.token(g, y.overlay), y.overlayPos = g.pos), g.pos = Math.min(y.basePos, y.overlayPos), y.overlayCur == null ? y.baseCur : y.baseCur != null && y.overlay.combineTokens || C && y.overlay.combineTokens == null ? y.baseCur + " " + y.overlayCur : y.overlayCur;
        },
        indent: v.indent && function(g, y, x) {
          return v.indent(g.base, y, x);
        },
        electricChars: v.electricChars,
        innerMode: function(g) {
          return { state: g.base, mode: v };
        },
        blankLine: function(g) {
          var y, x;
          return v.blankLine && (y = v.blankLine(g.base)), m.blankLine && (x = m.blankLine(g.overlay)), x == null ? y : C && y != null ? y + " " + x : x;
        }
      };
    };
  });
})();
var Ff = Sf.exports;
(function(s, b) {
  (function(c) {
    c(Tt);
  })(function(c) {
    c.defineOption("placeholder", "", function(A, z, P) {
      var N = P && P != c.Init;
      if (z && !N)
        A.on("blur", g), A.on("change", y), A.on("swapDoc", y), c.on(A.getInputField(), "compositionupdate", A.state.placeholderCompose = function() {
          C(A);
        }), y(A);
      else if (!z && N) {
        A.off("blur", g), A.off("change", y), A.off("swapDoc", y), c.off(A.getInputField(), "compositionupdate", A.state.placeholderCompose), v(A);
        var G = A.getWrapperElement();
        G.className = G.className.replace(" CodeMirror-empty", "");
      }
      z && !A.hasFocus() && g(A);
    });
    function v(A) {
      A.state.placeholder && (A.state.placeholder.parentNode.removeChild(A.state.placeholder), A.state.placeholder = null);
    }
    function m(A) {
      v(A);
      var z = A.state.placeholder = document.createElement("pre");
      z.style.cssText = "height: 0; overflow: visible", z.style.direction = A.getOption("direction"), z.className = "CodeMirror-placeholder CodeMirror-line-like";
      var P = A.getOption("placeholder");
      typeof P == "string" && (P = document.createTextNode(P)), z.appendChild(P), A.display.lineSpace.insertBefore(z, A.display.lineSpace.firstChild);
    }
    function C(A) {
      setTimeout(function() {
        var z = !1;
        if (A.lineCount() == 1) {
          var P = A.getInputField();
          z = P.nodeName == "TEXTAREA" ? !A.getLine(0).length : !/[^\u200b]/.test(P.querySelector(".CodeMirror-line").textContent);
        }
        z ? m(A) : v(A);
      }, 20);
    }
    function g(A) {
      x(A) && m(A);
    }
    function y(A) {
      var z = A.getWrapperElement(), P = x(A);
      z.className = z.className.replace(" CodeMirror-empty", "") + (P ? " CodeMirror-empty" : ""), P ? m(A) : v(A);
    }
    function x(A) {
      return A.lineCount() === 1 && A.getLine(0) === "";
    }
  });
})();
(function(s, b) {
  (function(c) {
    c(Tt);
  })(function(c) {
    c.defineOption("autoRefresh", !1, function(C, g) {
      C.state.autoRefresh && (m(C, C.state.autoRefresh), C.state.autoRefresh = null), g && C.display.wrapper.offsetHeight == 0 && v(C, C.state.autoRefresh = { delay: g.delay || 250 });
    });
    function v(C, g) {
      function y() {
        C.display.wrapper.offsetHeight ? (m(C, g), C.display.lastWrapHeight != C.display.wrapper.clientHeight && C.refresh()) : g.timeout = setTimeout(y, g.delay);
      }
      g.timeout = setTimeout(y, g.delay), g.hurry = function() {
        clearTimeout(g.timeout), g.timeout = setTimeout(y, 50);
      }, c.on(window, "mouseup", g.hurry), c.on(window, "keyup", g.hurry);
    }
    function m(C, g) {
      clearTimeout(g.timeout), c.off(window, "mouseup", g.hurry), c.off(window, "keyup", g.hurry);
    }
  });
})();
(function(s, b) {
  (function(c) {
    c(Tt);
  })(function(c) {
    c.defineOption("styleSelectedText", !1, function(N, G, X) {
      var le = X && X != c.Init;
      G && !le ? (N.state.markedSelection = [], N.state.markedSelectionStyle = typeof G == "string" ? G : "CodeMirror-selectedtext", z(N), N.on("cursorActivity", v), N.on("change", m)) : !G && le && (N.off("cursorActivity", v), N.off("change", m), A(N), N.state.markedSelection = N.state.markedSelectionStyle = null);
    });
    function v(N) {
      N.state.markedSelection && N.operation(function() {
        P(N);
      });
    }
    function m(N) {
      N.state.markedSelection && N.state.markedSelection.length && N.operation(function() {
        A(N);
      });
    }
    var C = 8, g = c.Pos, y = c.cmpPos;
    function x(N, G, X, le) {
      if (y(G, X) != 0)
        for (var J = N.state.markedSelection, Q = N.state.markedSelectionStyle, H = G.line; ; ) {
          var q = H == G.line ? G : g(H, 0), R = H + C, _ = R >= X.line, te = _ ? X : g(R, 0), Y = N.markText(q, te, { className: Q });
          if (le == null ? J.push(Y) : J.splice(le++, 0, Y), _)
            break;
          H = R;
        }
    }
    function A(N) {
      for (var G = N.state.markedSelection, X = 0; X < G.length; ++X)
        G[X].clear();
      G.length = 0;
    }
    function z(N) {
      A(N);
      for (var G = N.listSelections(), X = 0; X < G.length; X++)
        x(N, G[X].from(), G[X].to());
    }
    function P(N) {
      if (!N.somethingSelected())
        return A(N);
      if (N.listSelections().length > 1)
        return z(N);
      var G = N.getCursor("start"), X = N.getCursor("end"), le = N.state.markedSelection;
      if (!le.length)
        return x(N, G, X);
      var J = le[0].find(), Q = le[le.length - 1].find();
      if (!J || !Q || X.line - G.line <= C || y(G, Q.to) >= 0 || y(X, J.from) <= 0)
        return z(N);
      for (; y(G, J.from) > 0; )
        le.shift().clear(), J = le[0].find();
      for (y(G, J.from) < 0 && (J.to.line - G.line < C ? (le.shift().clear(), x(N, G, J.to, 0)) : x(N, G, J.from, 0)); y(X, Q.to) < 0; )
        le.pop().clear(), Q = le[le.length - 1].find();
      y(X, Q.to) > 0 && (X.line - Q.from.line < C ? (le.pop().clear(), x(N, Q.from, X)) : x(N, Q.to, X));
    }
  });
})();
(function(s, b) {
  (function(c) {
    c(Tt);
  })(function(c) {
    var v = c.Pos;
    function m(H) {
      var q = H.flags;
      return q ?? (H.ignoreCase ? "i" : "") + (H.global ? "g" : "") + (H.multiline ? "m" : "");
    }
    function C(H, q) {
      for (var R = m(H), _ = R, te = 0; te < q.length; te++)
        _.indexOf(q.charAt(te)) == -1 && (_ += q.charAt(te));
      return R == _ ? H : new RegExp(H.source, _);
    }
    function g(H) {
      return /\\s|\\n|\n|\\W|\\D|\[\^/.test(H.source);
    }
    function y(H, q, R) {
      q = C(q, "g");
      for (var _ = R.line, te = R.ch, Y = H.lastLine(); _ <= Y; _++, te = 0) {
        q.lastIndex = te;
        var oe = H.getLine(_), pe = q.exec(oe);
        if (pe)
          return {
            from: v(_, pe.index),
            to: v(_, pe.index + pe[0].length),
            match: pe
          };
      }
    }
    function x(H, q, R) {
      if (!g(q))
        return y(H, q, R);
      q = C(q, "gm");
      for (var _, te = 1, Y = R.line, oe = H.lastLine(); Y <= oe; ) {
        for (var pe = 0; pe < te && !(Y > oe); pe++) {
          var qe = H.getLine(Y++);
          _ = _ == null ? qe : _ + `
` + qe;
        }
        te = te * 2, q.lastIndex = R.ch;
        var ae = q.exec(_);
        if (ae) {
          var Se = _.slice(0, ae.index).split(`
`), ke = ae[0].split(`
`), De = R.line + Se.length - 1, T = Se[Se.length - 1].length;
          return {
            from: v(De, T),
            to: v(
              De + ke.length - 1,
              ke.length == 1 ? T + ke[0].length : ke[ke.length - 1].length
            ),
            match: ae
          };
        }
      }
    }
    function A(H, q, R) {
      for (var _, te = 0; te <= H.length; ) {
        q.lastIndex = te;
        var Y = q.exec(H);
        if (!Y)
          break;
        var oe = Y.index + Y[0].length;
        if (oe > H.length - R)
          break;
        (!_ || oe > _.index + _[0].length) && (_ = Y), te = Y.index + 1;
      }
      return _;
    }
    function z(H, q, R) {
      q = C(q, "g");
      for (var _ = R.line, te = R.ch, Y = H.firstLine(); _ >= Y; _--, te = -1) {
        var oe = H.getLine(_), pe = A(oe, q, te < 0 ? 0 : oe.length - te);
        if (pe)
          return {
            from: v(_, pe.index),
            to: v(_, pe.index + pe[0].length),
            match: pe
          };
      }
    }
    function P(H, q, R) {
      if (!g(q))
        return z(H, q, R);
      q = C(q, "gm");
      for (var _, te = 1, Y = H.getLine(R.line).length - R.ch, oe = R.line, pe = H.firstLine(); oe >= pe; ) {
        for (var qe = 0; qe < te && oe >= pe; qe++) {
          var ae = H.getLine(oe--);
          _ = _ == null ? ae : ae + `
` + _;
        }
        te *= 2;
        var Se = A(_, q, Y);
        if (Se) {
          var ke = _.slice(0, Se.index).split(`
`), De = Se[0].split(`
`), T = oe + ke.length, V = ke[ke.length - 1].length;
          return {
            from: v(T, V),
            to: v(
              T + De.length - 1,
              De.length == 1 ? V + De[0].length : De[De.length - 1].length
            ),
            match: Se
          };
        }
      }
    }
    var N, G;
    String.prototype.normalize ? (N = function(H) {
      return H.normalize("NFD").toLowerCase();
    }, G = function(H) {
      return H.normalize("NFD");
    }) : (N = function(H) {
      return H.toLowerCase();
    }, G = function(H) {
      return H;
    });
    function X(H, q, R, _) {
      if (H.length == q.length)
        return R;
      for (var te = 0, Y = R + Math.max(0, H.length - q.length); ; ) {
        if (te == Y)
          return te;
        var oe = te + Y >> 1, pe = _(H.slice(0, oe)).length;
        if (pe == R)
          return oe;
        pe > R ? Y = oe : te = oe + 1;
      }
    }
    function le(H, q, R, _) {
      if (!q.length)
        return null;
      var te = _ ? N : G, Y = te(q).split(/\r|\n\r?/);
      e:
        for (var oe = R.line, pe = R.ch, qe = H.lastLine() + 1 - Y.length; oe <= qe; oe++, pe = 0) {
          var ae = H.getLine(oe).slice(pe), Se = te(ae);
          if (Y.length == 1) {
            var ke = Se.indexOf(Y[0]);
            if (ke == -1)
              continue e;
            var R = X(ae, Se, ke, te) + pe;
            return {
              from: v(oe, X(ae, Se, ke, te) + pe),
              to: v(oe, X(ae, Se, ke + Y[0].length, te) + pe)
            };
          } else {
            var De = Se.length - Y[0].length;
            if (Se.slice(De) != Y[0])
              continue e;
            for (var T = 1; T < Y.length - 1; T++)
              if (te(H.getLine(oe + T)) != Y[T])
                continue e;
            var V = H.getLine(oe + Y.length - 1), Z = te(V), ge = Y[Y.length - 1];
            if (Z.slice(0, ge.length) != ge)
              continue e;
            return {
              from: v(oe, X(ae, Se, De, te) + pe),
              to: v(oe + Y.length - 1, X(V, Z, ge.length, te))
            };
          }
        }
    }
    function J(H, q, R, _) {
      if (!q.length)
        return null;
      var te = _ ? N : G, Y = te(q).split(/\r|\n\r?/);
      e:
        for (var oe = R.line, pe = R.ch, qe = H.firstLine() - 1 + Y.length; oe >= qe; oe--, pe = -1) {
          var ae = H.getLine(oe);
          pe > -1 && (ae = ae.slice(0, pe));
          var Se = te(ae);
          if (Y.length == 1) {
            var ke = Se.lastIndexOf(Y[0]);
            if (ke == -1)
              continue e;
            return {
              from: v(oe, X(ae, Se, ke, te)),
              to: v(oe, X(ae, Se, ke + Y[0].length, te))
            };
          } else {
            var De = Y[Y.length - 1];
            if (Se.slice(0, De.length) != De)
              continue e;
            for (var T = 1, R = oe - Y.length + 1; T < Y.length - 1; T++)
              if (te(H.getLine(R + T)) != Y[T])
                continue e;
            var V = H.getLine(oe + 1 - Y.length), Z = te(V);
            if (Z.slice(Z.length - Y[0].length) != Y[0])
              continue e;
            return {
              from: v(oe + 1 - Y.length, X(V, Z, V.length - Y[0].length, te)),
              to: v(oe, X(ae, Se, De.length, te))
            };
          }
        }
    }
    function Q(H, q, R, _) {
      this.atOccurrence = !1, this.afterEmptyMatch = !1, this.doc = H, R = R ? H.clipPos(R) : v(0, 0), this.pos = { from: R, to: R };
      var te;
      typeof _ == "object" ? te = _.caseFold : (te = _, _ = null), typeof q == "string" ? (te == null && (te = !1), this.matches = function(Y, oe) {
        return (Y ? J : le)(H, q, oe, te);
      }) : (q = C(q, "gm"), !_ || _.multiline !== !1 ? this.matches = function(Y, oe) {
        return (Y ? P : x)(H, q, oe);
      } : this.matches = function(Y, oe) {
        return (Y ? z : y)(H, q, oe);
      });
    }
    Q.prototype = {
      findNext: function() {
        return this.find(!1);
      },
      findPrevious: function() {
        return this.find(!0);
      },
      find: function(H) {
        var q = this.doc.clipPos(H ? this.pos.from : this.pos.to);
        if (this.afterEmptyMatch && this.atOccurrence && (q = v(q.line, q.ch), H ? (q.ch--, q.ch < 0 && (q.line--, q.ch = (this.doc.getLine(q.line) || "").length)) : (q.ch++, q.ch > (this.doc.getLine(q.line) || "").length && (q.ch = 0, q.line++)), c.cmpPos(q, this.doc.clipPos(q)) != 0))
          return this.atOccurrence = !1;
        var R = this.matches(H, q);
        if (this.afterEmptyMatch = R && c.cmpPos(R.from, R.to) == 0, R)
          return this.pos = R, this.atOccurrence = !0, this.pos.match || !0;
        var _ = v(H ? this.doc.firstLine() : this.doc.lastLine() + 1, 0);
        return this.pos = { from: _, to: _ }, this.atOccurrence = !1;
      },
      from: function() {
        if (this.atOccurrence)
          return this.pos.from;
      },
      to: function() {
        if (this.atOccurrence)
          return this.pos.to;
      },
      replace: function(H, q) {
        if (this.atOccurrence) {
          var R = c.splitLines(H);
          this.doc.replaceRange(R, this.pos.from, this.pos.to, q), this.pos.to = v(
            this.pos.from.line + R.length - 1,
            R[R.length - 1].length + (R.length == 1 ? this.pos.from.ch : 0)
          );
        }
      }
    }, c.defineExtension("getSearchCursor", function(H, q, R) {
      return new Q(this.doc, H, q, R);
    }), c.defineDocExtension("getSearchCursor", function(H, q, R) {
      return new Q(this, H, q, R);
    }), c.defineExtension("selectMatches", function(H, q) {
      for (var R = [], _ = this.getSearchCursor(H, this.getCursor("from"), q); _.findNext() && !(c.cmpPos(_.to(), this.getCursor("to")) > 0); )
        R.push({ anchor: _.from(), head: _.to() });
      R.length && this.setSelections(R, 0);
    });
  });
})();
(function(s, b) {
  (function(c) {
    c(Tt, kf, Ff);
  })(function(c) {
    var v = /^((?:(?:aaas?|about|acap|adiumxtra|af[ps]|aim|apt|attachment|aw|beshare|bitcoin|bolo|callto|cap|chrome(?:-extension)?|cid|coap|com-eventbrite-attendee|content|crid|cvs|data|dav|dict|dlna-(?:playcontainer|playsingle)|dns|doi|dtn|dvb|ed2k|facetime|feed|file|finger|fish|ftp|geo|gg|git|gizmoproject|go|gopher|gtalk|h323|hcp|https?|iax|icap|icon|im|imap|info|ipn|ipp|irc[6s]?|iris(?:\.beep|\.lwz|\.xpc|\.xpcs)?|itms|jar|javascript|jms|keyparc|lastfm|ldaps?|magnet|mailto|maps|market|message|mid|mms|ms-help|msnim|msrps?|mtqp|mumble|mupdate|mvn|news|nfs|nih?|nntp|notes|oid|opaquelocktoken|palm|paparazzi|platform|pop|pres|proxy|psyc|query|res(?:ource)?|rmi|rsync|rtmp|rtsp|secondlife|service|session|sftp|sgn|shttp|sieve|sips?|skype|sm[bs]|snmp|soap\.beeps?|soldat|spotify|ssh|steam|svn|tag|teamspeak|tel(?:net)?|tftp|things|thismessage|tip|tn3270|tv|udp|unreal|urn|ut2004|vemmi|ventrilo|view-source|webcal|wss?|wtai|wyciwyg|xcon(?:-userid)?|xfire|xmlrpc\.beeps?|xmpp|xri|ymsgr|z39\.50[rs]?):(?:\/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]|\([^\s()<>]*\))+(?:\([^\s()<>]*\)|[^\s`*!()\[\]{};:'".,<>?«»“”‘’]))/i;
    c.defineMode("gfm", function(m, C) {
      var g = 0;
      function y(P) {
        return P.code = !1, null;
      }
      var x = {
        startState: function() {
          return {
            code: !1,
            codeBlock: !1,
            ateSpace: !1
          };
        },
        copyState: function(P) {
          return {
            code: P.code,
            codeBlock: P.codeBlock,
            ateSpace: P.ateSpace
          };
        },
        token: function(P, N) {
          if (N.combineTokens = null, N.codeBlock)
            return P.match(/^```+/) ? (N.codeBlock = !1, null) : (P.skipToEnd(), null);
          if (P.sol() && (N.code = !1), P.sol() && P.match(/^```+/))
            return P.skipToEnd(), N.codeBlock = !0, null;
          if (P.peek() === "`") {
            P.next();
            var G = P.pos;
            P.eatWhile("`");
            var X = 1 + P.pos - G;
            return N.code ? X === g && (N.code = !1) : (g = X, N.code = !0), null;
          } else if (N.code)
            return P.next(), null;
          if (P.eatSpace())
            return N.ateSpace = !0, null;
          if ((P.sol() || N.ateSpace) && (N.ateSpace = !1, C.gitHubSpice !== !1)) {
            if (P.match(/^(?:[a-zA-Z0-9\-_]+\/)?(?:[a-zA-Z0-9\-_]+@)?(?=.{0,6}\d)(?:[a-f0-9]{7,40}\b)/))
              return N.combineTokens = !0, "link";
            if (P.match(/^(?:[a-zA-Z0-9\-_]+\/)?(?:[a-zA-Z0-9\-_]+)?#[0-9]+\b/))
              return N.combineTokens = !0, "link";
          }
          return P.match(v) && P.string.slice(P.start - 2, P.start) != "](" && (P.start == 0 || /\W/.test(P.string.charAt(P.start - 1))) ? (N.combineTokens = !0, "link") : (P.next(), null);
        },
        blankLine: y
      }, A = {
        taskLists: !0,
        strikethrough: !0,
        emoji: !0
      };
      for (var z in C)
        A[z] = C[z];
      return A.name = "markdown", c.overlayMode(c.getMode(m, A), x);
    }, "markdown"), c.defineMIME("text/x-gfm", "gfm");
  });
})();
var Jo = { exports: {} };
(function(s) {
  var b;
  (function() {
    b = function(c, v, m, C) {
      C = C || {}, this.dictionary = null, this.rules = {}, this.dictionaryTable = {}, this.compoundRules = [], this.compoundRuleCodes = {}, this.replacementTable = [], this.flags = C.flags || {}, this.memoized = {}, this.loaded = !1;
      var g = this, y, x, A, z, P;
      if (c)
        if (g.dictionary = c, v && m)
          J();
        else if (typeof window < "u" && (window.chrome && window.chrome.runtime || window.browser && window.browser.runtime)) {
          var N = window.chrome && window.chrome.runtime ? window.chrome.runtime : window.browser.runtime;
          C.dictionaryPath ? y = C.dictionaryPath : y = "typo/dictionaries", v || G(N.getURL(y + "/" + c + "/" + c + ".aff"), X), m || G(N.getURL(y + "/" + c + "/" + c + ".dic"), le);
        } else
          C.dictionaryPath ? y = C.dictionaryPath : typeof __dirname < "u" ? y = __dirname + "/dictionaries" : y = "./dictionaries", v || G(y + "/" + c + "/" + c + ".aff", X), m || G(y + "/" + c + "/" + c + ".dic", le);
      function G(Q, H) {
        var q = g._readFile(Q, null, C == null ? void 0 : C.asyncLoad);
        C != null && C.asyncLoad ? q.then(function(R) {
          H(R);
        }) : H(q);
      }
      function X(Q) {
        v = Q, m && J();
      }
      function le(Q) {
        m = Q, v && J();
      }
      function J() {
        for (g.rules = g._parseAFF(v), g.compoundRuleCodes = {}, x = 0, z = g.compoundRules.length; x < z; x++) {
          var Q = g.compoundRules[x];
          for (A = 0, P = Q.length; A < P; A++)
            g.compoundRuleCodes[Q[A]] = [];
        }
        "ONLYINCOMPOUND" in g.flags && (g.compoundRuleCodes[g.flags.ONLYINCOMPOUND] = []), g.dictionaryTable = g._parseDIC(m);
        for (x in g.compoundRuleCodes)
          g.compoundRuleCodes[x].length === 0 && delete g.compoundRuleCodes[x];
        for (x = 0, z = g.compoundRules.length; x < z; x++) {
          var H = g.compoundRules[x], q = "";
          for (A = 0, P = H.length; A < P; A++) {
            var R = H[A];
            R in g.compoundRuleCodes ? q += "(" + g.compoundRuleCodes[R].join("|") + ")" : q += R;
          }
          g.compoundRules[x] = new RegExp("^" + q + "$", "i");
        }
        g.loaded = !0, C != null && C.asyncLoad && (C != null && C.loadedCallback) && C.loadedCallback(g);
      }
      return this;
    }, b.prototype = {
      /**
       * Loads a Typo instance from a hash of all of the Typo properties.
       *
       * @param {object} obj A hash of Typo properties, probably gotten from a JSON.parse(JSON.stringify(typo_instance)).
       */
      load: function(c) {
        for (var v in c)
          c.hasOwnProperty(v) && (this[v] = c[v]);
        return this;
      },
      /**
       * Read the contents of a file.
       *
       * @param {string} path The path (relative) to the file.
       * @param {string} [charset="ISO8859-1"] The expected charset of the file
       * @param {boolean} async If true, the file will be read asynchronously. For node.js this does nothing, all
       *        files are read synchronously.
       * @returns {string} The file data if async is false, otherwise a promise object. If running node.js, the data is
       *          always returned.
       */
      _readFile: function(c, v, m) {
        var C;
        if (v = v || "utf8", typeof XMLHttpRequest < "u") {
          var g = new XMLHttpRequest();
          if (g.open("GET", c, !!m), (C = g.overrideMimeType) === null || C === void 0 || C.call(g, "text/plain; charset=" + v), m) {
            var y = new Promise(function(A, z) {
              g.onload = function() {
                g.status === 200 ? A(g.responseText) : z(g.statusText);
              }, g.onerror = function() {
                z(g.statusText);
              };
            });
            return g.send(null), y;
          } else
            return g.send(null), g.responseText;
        } else if (typeof xf < "u") {
          var x = yf;
          try {
            if (x.existsSync(c))
              return x.readFileSync(c, v);
            console.log("Path " + c + " does not exist.");
          } catch (A) {
            console.log(A);
          }
          return "";
        }
        return "";
      },
      /**
       * Parse the rules out from a .aff file.
       *
       * @param {string} data The contents of the affix file.
       * @returns object The rules from the file.
       */
      _parseAFF: function(c) {
        var v = {}, m, C, g, y, x, A, z, P, N = c.split(/\r?\n/);
        for (x = 0, z = N.length; x < z; x++)
          if (m = this._removeAffixComments(N[x]), m = m.trim(), !!m) {
            var G = m.split(/\s+/), X = G[0];
            if (X === "PFX" || X === "SFX") {
              var le = G[1], J = G[2];
              g = parseInt(G[3], 10);
              var Q = [];
              for (A = x + 1, P = x + 1 + g; A < P; A++) {
                C = N[A], y = C.split(/\s+/);
                var H = y[2], q = y[3].split("/"), R = q[0];
                R === "0" && (R = "");
                var _ = this.parseRuleCodes(q[1]), te = y[4], Y = {
                  add: R
                };
                _.length > 0 && (Y.continuationClasses = _), te !== "." && (X === "SFX" ? Y.match = new RegExp(te + "$") : Y.match = new RegExp("^" + te)), H != "0" && (X === "SFX" ? Y.remove = new RegExp(H + "$") : Y.remove = H), Q.push(Y);
              }
              v[le] = { type: X, combineable: J === "Y", entries: Q }, x += g;
            } else if (X === "COMPOUNDRULE") {
              for (g = parseInt(G[1], 10), A = x + 1, P = x + 1 + g; A < P; A++)
                m = N[A], y = m.split(/\s+/), this.compoundRules.push(y[1]);
              x += g;
            } else
              X === "REP" ? (y = m.split(/\s+/), y.length === 3 && this.replacementTable.push([y[1], y[2]])) : this.flags[X] = G[1];
          }
        return v;
      },
      /**
       * Removes comments.
       *
       * @param {string} data A line from an affix file.
       * @return {string} The cleaned-up line.
       */
      _removeAffixComments: function(c) {
        return c.match(/^\s*#/) ? "" : c;
      },
      /**
       * Parses the words out from the .dic file.
       *
       * @param {string} data The data from the dictionary file.
       * @returns HashMap The lookup table containing all of the words and
       *                 word forms from the dictionary.
       */
      _parseDIC: function(c) {
        c = this._removeDicComments(c);
        var v = c.split(/\r?\n/), m = {};
        function C(Se, ke) {
          m.hasOwnProperty(Se) || (m[Se] = null), ke.length > 0 && (m[Se] === null && (m[Se] = []), m[Se].push(ke));
        }
        for (var g = 1, y = v.length; g < y; g++) {
          var x = v[g];
          if (x) {
            var A = x.replace(/\s.*$/, ""), z = A.split("/", 2), P = z[0];
            if (z.length > 1) {
              var N = this.parseRuleCodes(z[1]);
              (!("NEEDAFFIX" in this.flags) || N.indexOf(this.flags.NEEDAFFIX) === -1) && C(P, N);
              for (var G = 0, X = N.length; G < X; G++) {
                var le = N[G], J = this.rules[le];
                if (J)
                  for (var Q = this._applyRule(P, J), H = 0, q = Q.length; H < q; H++) {
                    var R = Q[H];
                    if (C(R, []), J.combineable)
                      for (var _ = G + 1; _ < X; _++) {
                        var te = N[_], Y = this.rules[te];
                        if (Y && Y.combineable && J.type != Y.type)
                          for (var oe = this._applyRule(R, Y), pe = 0, qe = oe.length; pe < qe; pe++) {
                            var ae = oe[pe];
                            C(ae, []);
                          }
                      }
                  }
                le in this.compoundRuleCodes && this.compoundRuleCodes[le].push(P);
              }
            } else
              C(P.trim(), []);
          }
        }
        return m;
      },
      /**
       * Removes comment lines and then cleans up blank lines and trailing whitespace.
       *
       * @param {string} data The data from a .dic file.
       * @return {string} The cleaned-up data.
       */
      _removeDicComments: function(c) {
        return c = c.replace(/^\t.*$/mg, ""), c;
      },
      parseRuleCodes: function(c) {
        if (c)
          if ("FLAG" in this.flags)
            if (this.flags.FLAG === "long") {
              for (var v = [], m = 0, C = c.length; m < C; m += 2)
                v.push(c.substr(m, 2));
              return v;
            } else
              return this.flags.FLAG === "num" ? c.split(",") : this.flags.FLAG === "UTF-8" ? Array.from(c) : c.split("");
          else
            return c.split("");
        else
          return [];
      },
      /**
       * Applies an affix rule to a word.
       *
       * @param {string} word The base word.
       * @param {Object} rule The affix rule.
       * @returns {string[]} The new words generated by the rule.
       */
      _applyRule: function(c, v) {
        for (var m = v.entries, C = [], g = 0, y = m.length; g < y; g++) {
          var x = m[g];
          if (!x.match || c.match(x.match)) {
            var A = c;
            if (x.remove && (A = A.replace(x.remove, "")), v.type === "SFX" ? A = A + x.add : A = x.add + A, C.push(A), "continuationClasses" in x)
              for (var z = 0, P = x.continuationClasses.length; z < P; z++) {
                var N = this.rules[x.continuationClasses[z]];
                N && (C = C.concat(this._applyRule(A, N)));
              }
          }
        }
        return C;
      },
      /**
       * Checks whether a word or a capitalization variant exists in the current dictionary.
       * The word is trimmed and several variations of capitalizations are checked.
       * If you want to check a word without any changes made to it, call checkExact()
       *
       * @see http://blog.stevenlevithan.com/archives/faster-trim-javascript re:trimming function
       *
       * @param {string} aWord The word to check.
       * @returns {boolean}
       */
      check: function(c) {
        if (!this.loaded)
          throw "Dictionary not loaded.";
        if (!c)
          return !1;
        var v = c.replace(/^\s\s*/, "").replace(/\s\s*$/, "");
        if (this.checkExact(v))
          return !0;
        if (v.toUpperCase() === v) {
          var m = v[0] + v.substring(1).toLowerCase();
          if (this.hasFlag(m, "KEEPCASE"))
            return !1;
          if (this.checkExact(m) || this.checkExact(v.toLowerCase()))
            return !0;
        }
        var C = v[0].toLowerCase() + v.substring(1);
        if (C !== v) {
          if (this.hasFlag(C, "KEEPCASE"))
            return !1;
          if (this.checkExact(C))
            return !0;
        }
        return !1;
      },
      /**
       * Checks whether a word exists in the current dictionary.
       *
       * @param {string} word The word to check.
       * @returns {boolean}
       */
      checkExact: function(c) {
        if (!this.loaded)
          throw "Dictionary not loaded.";
        var v = this.dictionaryTable[c], m, C;
        if (typeof v > "u") {
          if ("COMPOUNDMIN" in this.flags && c.length >= this.flags.COMPOUNDMIN) {
            for (m = 0, C = this.compoundRules.length; m < C; m++)
              if (c.match(this.compoundRules[m]))
                return !0;
          }
        } else {
          if (v === null)
            return !0;
          if (typeof v == "object") {
            for (m = 0, C = v.length; m < C; m++)
              if (!this.hasFlag(c, "ONLYINCOMPOUND", v[m]))
                return !0;
          }
        }
        return !1;
      },
      /**
       * Looks up whether a given word is flagged with a given flag.
       *
       * @param {string} word The word in question.
       * @param {string} flag The flag in question.
       * @return {boolean}
       */
      hasFlag: function(c, v, m) {
        if (!this.loaded)
          throw "Dictionary not loaded.";
        return !!(v in this.flags && (typeof m > "u" && (m = Array.prototype.concat.apply([], this.dictionaryTable[c])), m && m.indexOf(this.flags[v]) !== -1));
      },
      /**
       * Returns a list of suggestions for a misspelled word.
       *
       * @see http://www.norvig.com/spell-correct.html for the basis of this suggestor.
       * This suggestor is primitive, but it works.
       *
       * @param {string} word The misspelling.
       * @param {number} [limit=5] The maximum number of suggestions to return.
       * @returns {string[]} The array of suggestions.
       */
      alphabet: "",
      suggest: function(c, v) {
        if (!this.loaded)
          throw "Dictionary not loaded.";
        if (v = v || 5, this.memoized.hasOwnProperty(c)) {
          var m = this.memoized[c].limit;
          if (v <= m || this.memoized[c].suggestions.length < m)
            return this.memoized[c].suggestions.slice(0, v);
        }
        if (this.check(c))
          return [];
        for (var C = 0, g = this.replacementTable.length; C < g; C++) {
          var y = this.replacementTable[C];
          if (c.indexOf(y[0]) !== -1) {
            var x = c.replace(y[0], y[1]);
            if (this.check(x))
              return [x];
          }
        }
        if (!this.alphabet) {
          this.alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", "TRY" in this.flags && (this.alphabet += this.flags.TRY), "WORDCHARS" in this.flags && (this.alphabet += this.flags.WORDCHARS);
          var A = this.alphabet.split("");
          A.sort();
          for (var z = {}, C = 0; C < A.length; C++)
            z[A[C]] = !0;
          this.alphabet = "";
          for (var C in z)
            this.alphabet += C;
        }
        var P = this;
        function N(X, le) {
          var J = {}, Q, H, q, R, _ = P.alphabet.length;
          for (var te in X)
            for (Q = 0, q = te.length + 1; Q < q; Q++) {
              var Y = [te.substring(0, Q), te.substring(Q)];
              if (Y[1] && (R = Y[0] + Y[1].substring(1), (!le || P.check(R)) && (R in J ? J[R] += 1 : J[R] = 1)), Y[1].length > 1 && Y[1][1] !== Y[1][0] && (R = Y[0] + Y[1][1] + Y[1][0] + Y[1].substring(2), (!le || P.check(R)) && (R in J ? J[R] += 1 : J[R] = 1)), Y[1]) {
                var oe = Y[1].substring(0, 1).toUpperCase() === Y[1].substring(0, 1) ? "uppercase" : "lowercase";
                for (H = 0; H < _; H++) {
                  var pe = P.alphabet[H];
                  oe === "uppercase" && (pe = pe.toUpperCase()), pe != Y[1].substring(0, 1) && (R = Y[0] + pe + Y[1].substring(1), (!le || P.check(R)) && (R in J ? J[R] += 1 : J[R] = 1));
                }
              }
              if (Y[1])
                for (H = 0; H < _; H++) {
                  var oe = Y[0].substring(-1).toUpperCase() === Y[0].substring(-1) && Y[1].substring(0, 1).toUpperCase() === Y[1].substring(0, 1) ? "uppercase" : "lowercase", pe = P.alphabet[H];
                  oe === "uppercase" && (pe = pe.toUpperCase()), R = Y[0] + pe + Y[1], (!le || P.check(R)) && (R in J ? J[R] += 1 : J[R] = 1);
                }
            }
          return J;
        }
        function G(X) {
          var le, J = N((le = {}, le[X] = !0, le)), Q = N(J, !0), H = Q;
          for (var q in J)
            P.check(q) && (q in H ? H[q] += J[q] : H[q] = J[q]);
          var R, _ = [];
          for (R in H)
            H.hasOwnProperty(R) && (P.hasFlag(R, "PRIORITYSUGGEST") && (H[R] += 1e3), _.push([R, H[R]]));
          function te(qe, ae) {
            var Se = qe[1], ke = ae[1];
            return Se < ke ? -1 : Se > ke ? 1 : ae[0].localeCompare(qe[0]);
          }
          _.sort(te).reverse();
          var Y = [], oe = "lowercase";
          X.toUpperCase() === X ? oe = "uppercase" : X.substr(0, 1).toUpperCase() + X.substr(1).toLowerCase() === X && (oe = "capitalized");
          var pe = v;
          for (R = 0; R < Math.min(pe, _.length); R++)
            oe === "uppercase" ? _[R][0] = _[R][0].toUpperCase() : oe === "capitalized" && (_[R][0] = _[R][0].substr(0, 1).toUpperCase() + _[R][0].substr(1)), !P.hasFlag(_[R][0], "NOSUGGEST") && Y.indexOf(_[R][0]) === -1 ? Y.push(_[R][0]) : pe++;
          return Y;
        }
        return this.memoized[c] = {
          suggestions: G(c),
          limit: v
        }, this.memoized[c].suggestions;
      }
    };
  })(), s.exports = b;
})(Jo);
var Af = Jo.exports, Xo = Af;
function Ke(s) {
  if (s = s || {}, typeof s.codeMirrorInstance != "function" || typeof s.codeMirrorInstance.defineMode != "function") {
    console.log("CodeMirror Spell Checker: You must provide an instance of CodeMirror via the option `codeMirrorInstance`");
    return;
  }
  String.prototype.includes || (String.prototype.includes = function() {
    return String.prototype.indexOf.apply(this, arguments) !== -1;
  }), s.codeMirrorInstance.defineMode("spell-checker", function(b) {
    if (!Ke.aff_loading) {
      Ke.aff_loading = !0;
      var c = new XMLHttpRequest();
      c.open("GET", "https://cdn.jsdelivr.net/codemirror.spell-checker/latest/en_US.aff", !0), c.onload = function() {
        c.readyState === 4 && c.status === 200 && (Ke.aff_data = c.responseText, Ke.num_loaded++, Ke.num_loaded == 2 && (Ke.typo = new Xo("en_US", Ke.aff_data, Ke.dic_data, {
          platform: "any"
        })));
      }, c.send(null);
    }
    if (!Ke.dic_loading) {
      Ke.dic_loading = !0;
      var v = new XMLHttpRequest();
      v.open("GET", "https://cdn.jsdelivr.net/codemirror.spell-checker/latest/en_US.dic", !0), v.onload = function() {
        v.readyState === 4 && v.status === 200 && (Ke.dic_data = v.responseText, Ke.num_loaded++, Ke.num_loaded == 2 && (Ke.typo = new Xo("en_US", Ke.aff_data, Ke.dic_data, {
          platform: "any"
        })));
      }, v.send(null);
    }
    var m = '!"#$%&()*+,-./:;<=>?@[\\]^_`{|}~ ', C = {
      token: function(y) {
        var x = y.peek(), A = "";
        if (m.includes(x))
          return y.next(), null;
        for (; (x = y.peek()) != null && !m.includes(x); )
          A += x, y.next();
        return Ke.typo && !Ke.typo.check(A) ? "spell-error" : null;
      }
    }, g = s.codeMirrorInstance.getMode(
      b,
      b.backdrop || "text/plain"
    );
    return s.codeMirrorInstance.overlayMode(g, C, !0);
  });
}
Ke.num_loaded = 0;
Ke.aff_loading = !1;
Ke.dic_loading = !1;
Ke.aff_data = "";
Ke.dic_data = "";
Ke.typo;
var Ef = Ke, Vo = {};
(function(s) {
  function b(I, O) {
    for (var B = 0; B < O.length; B++) {
      var h = O[B];
      h.enumerable = h.enumerable || !1, h.configurable = !0, "value" in h && (h.writable = !0), Object.defineProperty(I, x(h.key), h);
    }
  }
  function c(I, O, B) {
    return O && b(I.prototype, O), B && b(I, B), Object.defineProperty(I, "prototype", {
      writable: !1
    }), I;
  }
  function v() {
    return v = Object.assign ? Object.assign.bind() : function(I) {
      for (var O = 1; O < arguments.length; O++) {
        var B = arguments[O];
        for (var h in B)
          Object.prototype.hasOwnProperty.call(B, h) && (I[h] = B[h]);
      }
      return I;
    }, v.apply(this, arguments);
  }
  function m(I, O) {
    if (I) {
      if (typeof I == "string")
        return C(I, O);
      var B = Object.prototype.toString.call(I).slice(8, -1);
      if (B === "Object" && I.constructor && (B = I.constructor.name), B === "Map" || B === "Set")
        return Array.from(I);
      if (B === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(B))
        return C(I, O);
    }
  }
  function C(I, O) {
    (O == null || O > I.length) && (O = I.length);
    for (var B = 0, h = new Array(O); B < O; B++)
      h[B] = I[B];
    return h;
  }
  function g(I, O) {
    var B = typeof Symbol < "u" && I[Symbol.iterator] || I["@@iterator"];
    if (B)
      return (B = B.call(I)).next.bind(B);
    if (Array.isArray(I) || (B = m(I)) || O && I && typeof I.length == "number") {
      B && (I = B);
      var h = 0;
      return function() {
        return h >= I.length ? {
          done: !0
        } : {
          done: !1,
          value: I[h++]
        };
      };
    }
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  function y(I, O) {
    if (typeof I != "object" || I === null)
      return I;
    var B = I[Symbol.toPrimitive];
    if (B !== void 0) {
      var h = B.call(I, O || "default");
      if (typeof h != "object")
        return h;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (O === "string" ? String : Number)(I);
  }
  function x(I) {
    var O = y(I, "string");
    return typeof O == "symbol" ? O : String(O);
  }
  function A() {
    return {
      async: !1,
      baseUrl: null,
      breaks: !1,
      extensions: null,
      gfm: !0,
      headerIds: !0,
      headerPrefix: "",
      highlight: null,
      hooks: null,
      langPrefix: "language-",
      mangle: !0,
      pedantic: !1,
      renderer: null,
      sanitize: !1,
      sanitizer: null,
      silent: !1,
      smartypants: !1,
      tokenizer: null,
      walkTokens: null,
      xhtml: !1
    };
  }
  s.defaults = A();
  function z(I) {
    s.defaults = I;
  }
  var P = /[&<>"']/, N = new RegExp(P.source, "g"), G = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, X = new RegExp(G.source, "g"), le = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }, J = function(O) {
    return le[O];
  };
  function Q(I, O) {
    if (O) {
      if (P.test(I))
        return I.replace(N, J);
    } else if (G.test(I))
      return I.replace(X, J);
    return I;
  }
  var H = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
  function q(I) {
    return I.replace(H, function(O, B) {
      return B = B.toLowerCase(), B === "colon" ? ":" : B.charAt(0) === "#" ? B.charAt(1) === "x" ? String.fromCharCode(parseInt(B.substring(2), 16)) : String.fromCharCode(+B.substring(1)) : "";
    });
  }
  var R = /(^|[^\[])\^/g;
  function _(I, O) {
    I = typeof I == "string" ? I : I.source, O = O || "";
    var B = {
      replace: function(p, F) {
        return F = F.source || F, F = F.replace(R, "$1"), I = I.replace(p, F), B;
      },
      getRegex: function() {
        return new RegExp(I, O);
      }
    };
    return B;
  }
  var te = /[^\w:]/g, Y = /^$|^[a-z][a-z0-9+.-]*:|^[?#]/i;
  function oe(I, O, B) {
    if (I) {
      var h;
      try {
        h = decodeURIComponent(q(B)).replace(te, "").toLowerCase();
      } catch {
        return null;
      }
      if (h.indexOf("javascript:") === 0 || h.indexOf("vbscript:") === 0 || h.indexOf("data:") === 0)
        return null;
    }
    O && !Y.test(B) && (B = ke(O, B));
    try {
      B = encodeURI(B).replace(/%25/g, "%");
    } catch {
      return null;
    }
    return B;
  }
  var pe = {}, qe = /^[^:]+:\/*[^/]*$/, ae = /^([^:]+:)[\s\S]*$/, Se = /^([^:]+:\/*[^/]*)[\s\S]*$/;
  function ke(I, O) {
    pe[" " + I] || (qe.test(I) ? pe[" " + I] = I + "/" : pe[" " + I] = V(I, "/", !0)), I = pe[" " + I];
    var B = I.indexOf(":") === -1;
    return O.substring(0, 2) === "//" ? B ? O : I.replace(ae, "$1") + O : O.charAt(0) === "/" ? B ? O : I.replace(Se, "$1") + O : I + O;
  }
  var De = {
    exec: function() {
    }
  };
  function T(I, O) {
    var B = I.replace(/\|/g, function(F, k, E) {
      for (var re = !1, de = k; --de >= 0 && E[de] === "\\"; )
        re = !re;
      return re ? "|" : " |";
    }), h = B.split(/ \|/), p = 0;
    if (h[0].trim() || h.shift(), h.length > 0 && !h[h.length - 1].trim() && h.pop(), h.length > O)
      h.splice(O);
    else
      for (; h.length < O; )
        h.push("");
    for (; p < h.length; p++)
      h[p] = h[p].trim().replace(/\\\|/g, "|");
    return h;
  }
  function V(I, O, B) {
    var h = I.length;
    if (h === 0)
      return "";
    for (var p = 0; p < h; ) {
      var F = I.charAt(h - p - 1);
      if (F === O && !B)
        p++;
      else if (F !== O && B)
        p++;
      else
        break;
    }
    return I.slice(0, h - p);
  }
  function Z(I, O) {
    if (I.indexOf(O[1]) === -1)
      return -1;
    for (var B = I.length, h = 0, p = 0; p < B; p++)
      if (I[p] === "\\")
        p++;
      else if (I[p] === O[0])
        h++;
      else if (I[p] === O[1] && (h--, h < 0))
        return p;
    return -1;
  }
  function ge(I) {
    I && I.sanitize && !I.silent && console.warn("marked(): sanitize and sanitizer parameters are deprecated since version 0.7.0, should not be used and will be removed in the future. Read more here: https://marked.js.org/#/USING_ADVANCED.md#options");
  }
  function Me(I, O) {
    if (O < 1)
      return "";
    for (var B = ""; O > 1; )
      O & 1 && (B += I), O >>= 1, I += I;
    return B + I;
  }
  function et(I, O, B, h) {
    var p = O.href, F = O.title ? Q(O.title) : null, k = I[1].replace(/\\([\[\]])/g, "$1");
    if (I[0].charAt(0) !== "!") {
      h.state.inLink = !0;
      var E = {
        type: "link",
        raw: B,
        href: p,
        title: F,
        text: k,
        tokens: h.inlineTokens(k)
      };
      return h.state.inLink = !1, E;
    }
    return {
      type: "image",
      raw: B,
      href: p,
      title: F,
      text: Q(k)
    };
  }
  function Pt(I, O) {
    var B = I.match(/^(\s+)(?:```)/);
    if (B === null)
      return O;
    var h = B[1];
    return O.split(`
`).map(function(p) {
      var F = p.match(/^\s+/);
      if (F === null)
        return p;
      var k = F[0];
      return k.length >= h.length ? p.slice(h.length) : p;
    }).join(`
`);
  }
  var S = /* @__PURE__ */ function() {
    function I(B) {
      this.options = B || s.defaults;
    }
    var O = I.prototype;
    return O.space = function(h) {
      var p = this.rules.block.newline.exec(h);
      if (p && p[0].length > 0)
        return {
          type: "space",
          raw: p[0]
        };
    }, O.code = function(h) {
      var p = this.rules.block.code.exec(h);
      if (p) {
        var F = p[0].replace(/^ {1,4}/gm, "");
        return {
          type: "code",
          raw: p[0],
          codeBlockStyle: "indented",
          text: this.options.pedantic ? F : V(F, `
`)
        };
      }
    }, O.fences = function(h) {
      var p = this.rules.block.fences.exec(h);
      if (p) {
        var F = p[0], k = Pt(F, p[3] || "");
        return {
          type: "code",
          raw: F,
          lang: p[2] ? p[2].trim().replace(this.rules.inline._escapes, "$1") : p[2],
          text: k
        };
      }
    }, O.heading = function(h) {
      var p = this.rules.block.heading.exec(h);
      if (p) {
        var F = p[2].trim();
        if (/#$/.test(F)) {
          var k = V(F, "#");
          (this.options.pedantic || !k || / $/.test(k)) && (F = k.trim());
        }
        return {
          type: "heading",
          raw: p[0],
          depth: p[1].length,
          text: F,
          tokens: this.lexer.inline(F)
        };
      }
    }, O.hr = function(h) {
      var p = this.rules.block.hr.exec(h);
      if (p)
        return {
          type: "hr",
          raw: p[0]
        };
    }, O.blockquote = function(h) {
      var p = this.rules.block.blockquote.exec(h);
      if (p) {
        var F = p[0].replace(/^ *>[ \t]?/gm, ""), k = this.lexer.state.top;
        this.lexer.state.top = !0;
        var E = this.lexer.blockTokens(F);
        return this.lexer.state.top = k, {
          type: "blockquote",
          raw: p[0],
          tokens: E,
          text: F
        };
      }
    }, O.list = function(h) {
      var p = this.rules.block.list.exec(h);
      if (p) {
        var F, k, E, re, de, fe, ve, we, ue, Ce, U, ze, Oe = p[1].trim(), He = Oe.length > 1, Le = {
          type: "list",
          raw: "",
          ordered: He,
          start: He ? +Oe.slice(0, -1) : "",
          loose: !1,
          items: []
        };
        Oe = He ? "\\d{1,9}\\" + Oe.slice(-1) : "\\" + Oe, this.options.pedantic && (Oe = He ? Oe : "[*+-]");
        for (var at = new RegExp("^( {0,3}" + Oe + ")((?:[	 ][^\\n]*)?(?:\\n|$))"); h && (ze = !1, !(!(p = at.exec(h)) || this.rules.block.hr.test(h))); ) {
          if (F = p[0], h = h.substring(F.length), we = p[2].split(`
`, 1)[0].replace(/^\t+/, function(rr) {
            return " ".repeat(3 * rr.length);
          }), ue = h.split(`
`, 1)[0], this.options.pedantic ? (re = 2, U = we.trimLeft()) : (re = p[2].search(/[^ ]/), re = re > 4 ? 1 : re, U = we.slice(re), re += p[1].length), fe = !1, !we && /^ *$/.test(ue) && (F += ue + `
`, h = h.substring(ue.length + 1), ze = !0), !ze)
            for (var pt = new RegExp("^ {0," + Math.min(3, re - 1) + "}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))"), Nt = new RegExp("^ {0," + Math.min(3, re - 1) + "}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)"), Ye = new RegExp("^ {0," + Math.min(3, re - 1) + "}(?:```|~~~)"), Xt = new RegExp("^ {0," + Math.min(3, re - 1) + "}#"); h && (Ce = h.split(`
`, 1)[0], ue = Ce, this.options.pedantic && (ue = ue.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), !(Ye.test(ue) || Xt.test(ue) || pt.test(ue) || Nt.test(h))); ) {
              if (ue.search(/[^ ]/) >= re || !ue.trim())
                U += `
` + ue.slice(re);
              else {
                if (fe || we.search(/[^ ]/) >= 4 || Ye.test(we) || Xt.test(we) || Nt.test(we))
                  break;
                U += `
` + ue;
              }
              !fe && !ue.trim() && (fe = !0), F += Ce + `
`, h = h.substring(Ce.length + 1), we = ue.slice(re);
            }
          Le.loose || (ve ? Le.loose = !0 : /\n *\n *$/.test(F) && (ve = !0)), this.options.gfm && (k = /^\[[ xX]\] /.exec(U), k && (E = k[0] !== "[ ] ", U = U.replace(/^\[[ xX]\] +/, ""))), Le.items.push({
            type: "list_item",
            raw: F,
            task: !!k,
            checked: E,
            loose: !1,
            text: U
          }), Le.raw += F;
        }
        Le.items[Le.items.length - 1].raw = F.trimRight(), Le.items[Le.items.length - 1].text = U.trimRight(), Le.raw = Le.raw.trimRight();
        var Yt = Le.items.length;
        for (de = 0; de < Yt; de++)
          if (this.lexer.state.top = !1, Le.items[de].tokens = this.lexer.blockTokens(Le.items[de].text, []), !Le.loose) {
            var It = Le.items[de].tokens.filter(function(rr) {
              return rr.type === "space";
            }), ei = It.length > 0 && It.some(function(rr) {
              return /\n.*\n/.test(rr.raw);
            });
            Le.loose = ei;
          }
        if (Le.loose)
          for (de = 0; de < Yt; de++)
            Le.items[de].loose = !0;
        return Le;
      }
    }, O.html = function(h) {
      var p = this.rules.block.html.exec(h);
      if (p) {
        var F = {
          type: "html",
          raw: p[0],
          pre: !this.options.sanitizer && (p[1] === "pre" || p[1] === "script" || p[1] === "style"),
          text: p[0]
        };
        if (this.options.sanitize) {
          var k = this.options.sanitizer ? this.options.sanitizer(p[0]) : Q(p[0]);
          F.type = "paragraph", F.text = k, F.tokens = this.lexer.inline(k);
        }
        return F;
      }
    }, O.def = function(h) {
      var p = this.rules.block.def.exec(h);
      if (p) {
        var F = p[1].toLowerCase().replace(/\s+/g, " "), k = p[2] ? p[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline._escapes, "$1") : "", E = p[3] ? p[3].substring(1, p[3].length - 1).replace(this.rules.inline._escapes, "$1") : p[3];
        return {
          type: "def",
          tag: F,
          raw: p[0],
          href: k,
          title: E
        };
      }
    }, O.table = function(h) {
      var p = this.rules.block.table.exec(h);
      if (p) {
        var F = {
          type: "table",
          header: T(p[1]).map(function(ve) {
            return {
              text: ve
            };
          }),
          align: p[2].replace(/^ *|\| *$/g, "").split(/ *\| */),
          rows: p[3] && p[3].trim() ? p[3].replace(/\n[ \t]*$/, "").split(`
`) : []
        };
        if (F.header.length === F.align.length) {
          F.raw = p[0];
          var k = F.align.length, E, re, de, fe;
          for (E = 0; E < k; E++)
            /^ *-+: *$/.test(F.align[E]) ? F.align[E] = "right" : /^ *:-+: *$/.test(F.align[E]) ? F.align[E] = "center" : /^ *:-+ *$/.test(F.align[E]) ? F.align[E] = "left" : F.align[E] = null;
          for (k = F.rows.length, E = 0; E < k; E++)
            F.rows[E] = T(F.rows[E], F.header.length).map(function(ve) {
              return {
                text: ve
              };
            });
          for (k = F.header.length, re = 0; re < k; re++)
            F.header[re].tokens = this.lexer.inline(F.header[re].text);
          for (k = F.rows.length, re = 0; re < k; re++)
            for (fe = F.rows[re], de = 0; de < fe.length; de++)
              fe[de].tokens = this.lexer.inline(fe[de].text);
          return F;
        }
      }
    }, O.lheading = function(h) {
      var p = this.rules.block.lheading.exec(h);
      if (p)
        return {
          type: "heading",
          raw: p[0],
          depth: p[2].charAt(0) === "=" ? 1 : 2,
          text: p[1],
          tokens: this.lexer.inline(p[1])
        };
    }, O.paragraph = function(h) {
      var p = this.rules.block.paragraph.exec(h);
      if (p) {
        var F = p[1].charAt(p[1].length - 1) === `
` ? p[1].slice(0, -1) : p[1];
        return {
          type: "paragraph",
          raw: p[0],
          text: F,
          tokens: this.lexer.inline(F)
        };
      }
    }, O.text = function(h) {
      var p = this.rules.block.text.exec(h);
      if (p)
        return {
          type: "text",
          raw: p[0],
          text: p[0],
          tokens: this.lexer.inline(p[0])
        };
    }, O.escape = function(h) {
      var p = this.rules.inline.escape.exec(h);
      if (p)
        return {
          type: "escape",
          raw: p[0],
          text: Q(p[1])
        };
    }, O.tag = function(h) {
      var p = this.rules.inline.tag.exec(h);
      if (p)
        return !this.lexer.state.inLink && /^<a /i.test(p[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(p[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(p[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(p[0]) && (this.lexer.state.inRawBlock = !1), {
          type: this.options.sanitize ? "text" : "html",
          raw: p[0],
          inLink: this.lexer.state.inLink,
          inRawBlock: this.lexer.state.inRawBlock,
          text: this.options.sanitize ? this.options.sanitizer ? this.options.sanitizer(p[0]) : Q(p[0]) : p[0]
        };
    }, O.link = function(h) {
      var p = this.rules.inline.link.exec(h);
      if (p) {
        var F = p[2].trim();
        if (!this.options.pedantic && /^</.test(F)) {
          if (!/>$/.test(F))
            return;
          var k = V(F.slice(0, -1), "\\");
          if ((F.length - k.length) % 2 === 0)
            return;
        } else {
          var E = Z(p[2], "()");
          if (E > -1) {
            var re = p[0].indexOf("!") === 0 ? 5 : 4, de = re + p[1].length + E;
            p[2] = p[2].substring(0, E), p[0] = p[0].substring(0, de).trim(), p[3] = "";
          }
        }
        var fe = p[2], ve = "";
        if (this.options.pedantic) {
          var we = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(fe);
          we && (fe = we[1], ve = we[3]);
        } else
          ve = p[3] ? p[3].slice(1, -1) : "";
        return fe = fe.trim(), /^</.test(fe) && (this.options.pedantic && !/>$/.test(F) ? fe = fe.slice(1) : fe = fe.slice(1, -1)), et(p, {
          href: fe && fe.replace(this.rules.inline._escapes, "$1"),
          title: ve && ve.replace(this.rules.inline._escapes, "$1")
        }, p[0], this.lexer);
      }
    }, O.reflink = function(h, p) {
      var F;
      if ((F = this.rules.inline.reflink.exec(h)) || (F = this.rules.inline.nolink.exec(h))) {
        var k = (F[2] || F[1]).replace(/\s+/g, " ");
        if (k = p[k.toLowerCase()], !k) {
          var E = F[0].charAt(0);
          return {
            type: "text",
            raw: E,
            text: E
          };
        }
        return et(F, k, F[0], this.lexer);
      }
    }, O.emStrong = function(h, p, F) {
      F === void 0 && (F = "");
      var k = this.rules.inline.emStrong.lDelim.exec(h);
      if (k && !(k[3] && F.match(/(?:[0-9A-Za-z\xAA\xB2\xB3\xB5\xB9\xBA\xBC-\xBE\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u0660-\u0669\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07C0-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088E\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0966-\u096F\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09E6-\u09F1\u09F4-\u09F9\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A66-\u0A6F\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AE6-\u0AEF\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B66-\u0B6F\u0B71-\u0B77\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0BE6-\u0BF2\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5D\u0C60\u0C61\u0C66-\u0C6F\u0C78-\u0C7E\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDD\u0CDE\u0CE0\u0CE1\u0CE6-\u0CEF\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D58-\u0D61\u0D66-\u0D78\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DE6-\u0DEF\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F20-\u0F33\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F-\u1049\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u1090-\u1099\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1369-\u137C\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u17E0-\u17E9\u17F0-\u17F9\u1810-\u1819\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19DA\u1A00-\u1A16\u1A20-\u1A54\u1A80-\u1A89\u1A90-\u1A99\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B50-\u1B59\u1B83-\u1BA0\u1BAE-\u1BE5\u1C00-\u1C23\u1C40-\u1C49\u1C4D-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2070\u2071\u2074-\u2079\u207F-\u2089\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2150-\u2189\u2460-\u249B\u24EA-\u24FF\u2776-\u2793\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2CFD\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u3192-\u3195\u31A0-\u31BF\u31F0-\u31FF\u3220-\u3229\u3248-\u324F\u3251-\u325F\u3280-\u3289\u32B1-\u32BF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7CA\uA7D0\uA7D1\uA7D3\uA7D5-\uA7D9\uA7F2-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA830-\uA835\uA840-\uA873\uA882-\uA8B3\uA8D0-\uA8D9\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA900-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF-\uA9D9\uA9E0-\uA9E4\uA9E6-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA50-\uAA59\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD07-\uDD33\uDD40-\uDD78\uDD8A\uDD8B\uDE80-\uDE9C\uDEA0-\uDED0\uDEE1-\uDEFB\uDF00-\uDF23\uDF2D-\uDF4A\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCA0-\uDCA9\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD70-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC58-\uDC76\uDC79-\uDC9E\uDCA7-\uDCAF\uDCE0-\uDCF2\uDCF4\uDCF5\uDCFB-\uDD1B\uDD20-\uDD39\uDD80-\uDDB7\uDDBC-\uDDCF\uDDD2-\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE40-\uDE48\uDE60-\uDE7E\uDE80-\uDE9F\uDEC0-\uDEC7\uDEC9-\uDEE4\uDEEB-\uDEEF\uDF00-\uDF35\uDF40-\uDF55\uDF58-\uDF72\uDF78-\uDF91\uDFA9-\uDFAF]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDCFA-\uDD23\uDD30-\uDD39\uDE60-\uDE7E\uDE80-\uDEA9\uDEB0\uDEB1\uDF00-\uDF27\uDF30-\uDF45\uDF51-\uDF54\uDF70-\uDF81\uDFB0-\uDFCB\uDFE0-\uDFF6]|\uD804[\uDC03-\uDC37\uDC52-\uDC6F\uDC71\uDC72\uDC75\uDC83-\uDCAF\uDCD0-\uDCE8\uDCF0-\uDCF9\uDD03-\uDD26\uDD36-\uDD3F\uDD44\uDD47\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDD0-\uDDDA\uDDDC\uDDE1-\uDDF4\uDE00-\uDE11\uDE13-\uDE2B\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDEF0-\uDEF9\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC50-\uDC59\uDC5F-\uDC61\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDCD0-\uDCD9\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE50-\uDE59\uDE80-\uDEAA\uDEB8\uDEC0-\uDEC9\uDF00-\uDF1A\uDF30-\uDF3B\uDF40-\uDF46]|\uD806[\uDC00-\uDC2B\uDCA0-\uDCF2\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD2F\uDD3F\uDD41\uDD50-\uDD59\uDDA0-\uDDA7\uDDAA-\uDDD0\uDDE1\uDDE3\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE89\uDE9D\uDEB0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC50-\uDC6C\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46\uDD50-\uDD59\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD89\uDD98\uDDA0-\uDDA9\uDEE0-\uDEF2\uDFB0\uDFC0-\uDFD4]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF0]|[\uD80C\uD81C-\uD820\uD822\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879\uD880-\uD883][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE60-\uDE69\uDE70-\uDEBE\uDEC0-\uDEC9\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF50-\uDF59\uDF5B-\uDF61\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDE40-\uDE96\uDF00-\uDF4A\uDF50\uDF93-\uDF9F\uDFE0\uDFE1\uDFE3]|\uD821[\uDC00-\uDFF7]|\uD823[\uDC00-\uDCD5\uDD00-\uDD08]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD50-\uDD52\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD834[\uDEE0-\uDEF3\uDF60-\uDF78]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB\uDFCE-\uDFFF]|\uD837[\uDF00-\uDF1E]|\uD838[\uDD00-\uDD2C\uDD37-\uDD3D\uDD40-\uDD49\uDD4E\uDE90-\uDEAD\uDEC0-\uDEEB\uDEF0-\uDEF9]|\uD839[\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83A[\uDC00-\uDCC4\uDCC7-\uDCCF\uDD00-\uDD43\uDD4B\uDD50-\uDD59]|\uD83B[\uDC71-\uDCAB\uDCAD-\uDCAF\uDCB1-\uDCB4\uDD01-\uDD2D\uDD2F-\uDD3D\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD83C[\uDD00-\uDD0C]|\uD83E[\uDFF0-\uDFF9]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF38\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A])/))) {
        var E = k[1] || k[2] || "";
        if (!E || E && (F === "" || this.rules.inline.punctuation.exec(F))) {
          var re = k[0].length - 1, de, fe, ve = re, we = 0, ue = k[0][0] === "*" ? this.rules.inline.emStrong.rDelimAst : this.rules.inline.emStrong.rDelimUnd;
          for (ue.lastIndex = 0, p = p.slice(-1 * h.length + re); (k = ue.exec(p)) != null; )
            if (de = k[1] || k[2] || k[3] || k[4] || k[5] || k[6], !!de) {
              if (fe = de.length, k[3] || k[4]) {
                ve += fe;
                continue;
              } else if ((k[5] || k[6]) && re % 3 && !((re + fe) % 3)) {
                we += fe;
                continue;
              }
              if (ve -= fe, !(ve > 0)) {
                fe = Math.min(fe, fe + ve + we);
                var Ce = h.slice(0, re + k.index + (k[0].length - de.length) + fe);
                if (Math.min(re, fe) % 2) {
                  var U = Ce.slice(1, -1);
                  return {
                    type: "em",
                    raw: Ce,
                    text: U,
                    tokens: this.lexer.inlineTokens(U)
                  };
                }
                var ze = Ce.slice(2, -2);
                return {
                  type: "strong",
                  raw: Ce,
                  text: ze,
                  tokens: this.lexer.inlineTokens(ze)
                };
              }
            }
        }
      }
    }, O.codespan = function(h) {
      var p = this.rules.inline.code.exec(h);
      if (p) {
        var F = p[2].replace(/\n/g, " "), k = /[^ ]/.test(F), E = /^ /.test(F) && / $/.test(F);
        return k && E && (F = F.substring(1, F.length - 1)), F = Q(F, !0), {
          type: "codespan",
          raw: p[0],
          text: F
        };
      }
    }, O.br = function(h) {
      var p = this.rules.inline.br.exec(h);
      if (p)
        return {
          type: "br",
          raw: p[0]
        };
    }, O.del = function(h) {
      var p = this.rules.inline.del.exec(h);
      if (p)
        return {
          type: "del",
          raw: p[0],
          text: p[2],
          tokens: this.lexer.inlineTokens(p[2])
        };
    }, O.autolink = function(h, p) {
      var F = this.rules.inline.autolink.exec(h);
      if (F) {
        var k, E;
        return F[2] === "@" ? (k = Q(this.options.mangle ? p(F[1]) : F[1]), E = "mailto:" + k) : (k = Q(F[1]), E = k), {
          type: "link",
          raw: F[0],
          text: k,
          href: E,
          tokens: [{
            type: "text",
            raw: k,
            text: k
          }]
        };
      }
    }, O.url = function(h, p) {
      var F;
      if (F = this.rules.inline.url.exec(h)) {
        var k, E;
        if (F[2] === "@")
          k = Q(this.options.mangle ? p(F[0]) : F[0]), E = "mailto:" + k;
        else {
          var re;
          do
            re = F[0], F[0] = this.rules.inline._backpedal.exec(F[0])[0];
          while (re !== F[0]);
          k = Q(F[0]), F[1] === "www." ? E = "http://" + F[0] : E = F[0];
        }
        return {
          type: "link",
          raw: F[0],
          text: k,
          href: E,
          tokens: [{
            type: "text",
            raw: k,
            text: k
          }]
        };
      }
    }, O.inlineText = function(h, p) {
      var F = this.rules.inline.text.exec(h);
      if (F) {
        var k;
        return this.lexer.state.inRawBlock ? k = this.options.sanitize ? this.options.sanitizer ? this.options.sanitizer(F[0]) : Q(F[0]) : F[0] : k = Q(this.options.smartypants ? p(F[0]) : F[0]), {
          type: "text",
          raw: F[0],
          text: k
        };
      }
    }, I;
  }(), d = {
    newline: /^(?: *(?:\n|$))+/,
    code: /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/,
    fences: /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/,
    hr: /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,
    heading: /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/,
    blockquote: /^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/,
    list: /^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/,
    html: "^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))",
    def: /^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/,
    table: De,
    lheading: /^((?:.|\n(?!\n))+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
    // regex template, placeholders will be replaced according to different paragraph
    // interruption rules of commonmark and the original markdown spec:
    _paragraph: /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/,
    text: /^[^\n]+/
  };
  d._label = /(?!\s*\])(?:\\.|[^\[\]\\])+/, d._title = /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/, d.def = _(d.def).replace("label", d._label).replace("title", d._title).getRegex(), d.bullet = /(?:[*+-]|\d{1,9}[.)])/, d.listItemStart = _(/^( *)(bull) */).replace("bull", d.bullet).getRegex(), d.list = _(d.list).replace(/bull/g, d.bullet).replace("hr", "\\n+(?=\\1?(?:(?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$))").replace("def", "\\n+(?=" + d.def.source + ")").getRegex(), d._tag = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", d._comment = /<!--(?!-?>)[\s\S]*?(?:-->|$)/, d.html = _(d.html, "i").replace("comment", d._comment).replace("tag", d._tag).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), d.paragraph = _(d._paragraph).replace("hr", d.hr).replace("heading", " {0,3}#{1,6} ").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", d._tag).getRegex(), d.blockquote = _(d.blockquote).replace("paragraph", d.paragraph).getRegex(), d.normal = v({}, d), d.gfm = v({}, d.normal, {
    table: "^ *([^\\n ].*\\|.*)\\n {0,3}(?:\\| *)?(:?-+:? *(?:\\| *:?-+:? *)*)(?:\\| *)?(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"
    // Cells
  }), d.gfm.table = _(d.gfm.table).replace("hr", d.hr).replace("heading", " {0,3}#{1,6} ").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", d._tag).getRegex(), d.gfm.paragraph = _(d._paragraph).replace("hr", d.hr).replace("heading", " {0,3}#{1,6} ").replace("|lheading", "").replace("table", d.gfm.table).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", d._tag).getRegex(), d.pedantic = v({}, d.normal, {
    html: _(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", d._comment).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
    def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
    heading: /^(#{1,6})(.*)(?:\n+|$)/,
    fences: De,
    // fences not supported
    lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
    paragraph: _(d.normal._paragraph).replace("hr", d.hr).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", d.lheading).replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").getRegex()
  });
  var j = {
    escape: /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,
    autolink: /^<(scheme:[^\s\x00-\x1f<>]*|email)>/,
    url: De,
    tag: "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>",
    // CDATA section
    link: /^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/,
    reflink: /^!?\[(label)\]\[(ref)\]/,
    nolink: /^!?\[(ref)\](?:\[\])?/,
    reflinkSearch: "reflink|nolink(?!\\()",
    emStrong: {
      lDelim: /^(?:\*+(?:([punct_])|[^\s*]))|^_+(?:([punct*])|([^\s_]))/,
      //        (1) and (2) can only be a Right Delimiter. (3) and (4) can only be Left.  (5) and (6) can be either Left or Right.
      //          () Skip orphan inside strong                                      () Consume to delim     (1) #***                (2) a***#, a***                             (3) #***a, ***a                 (4) ***#              (5) #***#                 (6) a***a
      rDelimAst: /^(?:[^_*\\]|\\.)*?\_\_(?:[^_*\\]|\\.)*?\*(?:[^_*\\]|\\.)*?(?=\_\_)|(?:[^*\\]|\\.)+(?=[^*])|[punct_](\*+)(?=[\s]|$)|(?:[^punct*_\s\\]|\\.)(\*+)(?=[punct_\s]|$)|[punct_\s](\*+)(?=[^punct*_\s])|[\s](\*+)(?=[punct_])|[punct_](\*+)(?=[punct_])|(?:[^punct*_\s\\]|\\.)(\*+)(?=[^punct*_\s])/,
      rDelimUnd: /^(?:[^_*\\]|\\.)*?\*\*(?:[^_*\\]|\\.)*?\_(?:[^_*\\]|\\.)*?(?=\*\*)|(?:[^_\\]|\\.)+(?=[^_])|[punct*](\_+)(?=[\s]|$)|(?:[^punct*_\s\\]|\\.)(\_+)(?=[punct*\s]|$)|[punct*\s](\_+)(?=[^punct*_\s])|[\s](\_+)(?=[punct*])|[punct*](\_+)(?=[punct*])/
      // ^- Not allowed for _
    },
    code: /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,
    br: /^( {2,}|\\)\n(?!\s*$)/,
    del: De,
    text: /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/,
    punctuation: /^([\spunctuation])/
  };
  j._punctuation = "!\"#$%&'()+\\-.,/:;<=>?@\\[\\]`^{|}~", j.punctuation = _(j.punctuation).replace(/punctuation/g, j._punctuation).getRegex(), j.blockSkip = /\[[^\]]*?\]\([^\)]*?\)|`[^`]*?`|<[^>]*?>/g, j.escapedEmSt = /(?:^|[^\\])(?:\\\\)*\\[*_]/g, j._comment = _(d._comment).replace("(?:-->|$)", "-->").getRegex(), j.emStrong.lDelim = _(j.emStrong.lDelim).replace(/punct/g, j._punctuation).getRegex(), j.emStrong.rDelimAst = _(j.emStrong.rDelimAst, "g").replace(/punct/g, j._punctuation).getRegex(), j.emStrong.rDelimUnd = _(j.emStrong.rDelimUnd, "g").replace(/punct/g, j._punctuation).getRegex(), j._escapes = /\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/g, j._scheme = /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/, j._email = /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/, j.autolink = _(j.autolink).replace("scheme", j._scheme).replace("email", j._email).getRegex(), j._attribute = /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/, j.tag = _(j.tag).replace("comment", j._comment).replace("attribute", j._attribute).getRegex(), j._label = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, j._href = /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/, j._title = /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/, j.link = _(j.link).replace("label", j._label).replace("href", j._href).replace("title", j._title).getRegex(), j.reflink = _(j.reflink).replace("label", j._label).replace("ref", d._label).getRegex(), j.nolink = _(j.nolink).replace("ref", d._label).getRegex(), j.reflinkSearch = _(j.reflinkSearch, "g").replace("reflink", j.reflink).replace("nolink", j.nolink).getRegex(), j.normal = v({}, j), j.pedantic = v({}, j.normal, {
    strong: {
      start: /^__|\*\*/,
      middle: /^__(?=\S)([\s\S]*?\S)__(?!_)|^\*\*(?=\S)([\s\S]*?\S)\*\*(?!\*)/,
      endAst: /\*\*(?!\*)/g,
      endUnd: /__(?!_)/g
    },
    em: {
      start: /^_|\*/,
      middle: /^()\*(?=\S)([\s\S]*?\S)\*(?!\*)|^_(?=\S)([\s\S]*?\S)_(?!_)/,
      endAst: /\*(?!\*)/g,
      endUnd: /_(?!_)/g
    },
    link: _(/^!?\[(label)\]\((.*?)\)/).replace("label", j._label).getRegex(),
    reflink: _(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", j._label).getRegex()
  }), j.gfm = v({}, j.normal, {
    escape: _(j.escape).replace("])", "~|])").getRegex(),
    _extended_email: /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/,
    url: /^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/,
    _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
    del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
    text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
  }), j.gfm.url = _(j.gfm.url, "i").replace("email", j.gfm._extended_email).getRegex(), j.breaks = v({}, j.gfm, {
    br: _(j.br).replace("{2,}", "*").getRegex(),
    text: _(j.gfm.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
  });
  function Ne(I) {
    return I.replace(/---/g, "—").replace(/--/g, "–").replace(/(^|[-\u2014/(\[{"\s])'/g, "$1‘").replace(/'/g, "’").replace(/(^|[-\u2014/(\[{\u2018\s])"/g, "$1“").replace(/"/g, "”").replace(/\.{3}/g, "…");
  }
  function Ee(I) {
    var O = "", B, h, p = I.length;
    for (B = 0; B < p; B++)
      h = I.charCodeAt(B), Math.random() > 0.5 && (h = "x" + h.toString(16)), O += "&#" + h + ";";
    return O;
  }
  var $e = /* @__PURE__ */ function() {
    function I(B) {
      this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = B || s.defaults, this.options.tokenizer = this.options.tokenizer || new S(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
        inLink: !1,
        inRawBlock: !1,
        top: !0
      };
      var h = {
        block: d.normal,
        inline: j.normal
      };
      this.options.pedantic ? (h.block = d.pedantic, h.inline = j.pedantic) : this.options.gfm && (h.block = d.gfm, this.options.breaks ? h.inline = j.breaks : h.inline = j.gfm), this.tokenizer.rules = h;
    }
    I.lex = function(h, p) {
      var F = new I(p);
      return F.lex(h);
    }, I.lexInline = function(h, p) {
      var F = new I(p);
      return F.inlineTokens(h);
    };
    var O = I.prototype;
    return O.lex = function(h) {
      h = h.replace(/\r\n|\r/g, `
`), this.blockTokens(h, this.tokens);
      for (var p; p = this.inlineQueue.shift(); )
        this.inlineTokens(p.src, p.tokens);
      return this.tokens;
    }, O.blockTokens = function(h, p) {
      var F = this;
      p === void 0 && (p = []), this.options.pedantic ? h = h.replace(/\t/g, "    ").replace(/^ +$/gm, "") : h = h.replace(/^( *)(\t+)/gm, function(ve, we, ue) {
        return we + "    ".repeat(ue.length);
      });
      for (var k, E, re, de; h; )
        if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some(function(ve) {
          return (k = ve.call({
            lexer: F
          }, h, p)) ? (h = h.substring(k.raw.length), p.push(k), !0) : !1;
        }))) {
          if (k = this.tokenizer.space(h)) {
            h = h.substring(k.raw.length), k.raw.length === 1 && p.length > 0 ? p[p.length - 1].raw += `
` : p.push(k);
            continue;
          }
          if (k = this.tokenizer.code(h)) {
            h = h.substring(k.raw.length), E = p[p.length - 1], E && (E.type === "paragraph" || E.type === "text") ? (E.raw += `
` + k.raw, E.text += `
` + k.text, this.inlineQueue[this.inlineQueue.length - 1].src = E.text) : p.push(k);
            continue;
          }
          if (k = this.tokenizer.fences(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.heading(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.hr(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.blockquote(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.list(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.html(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.def(h)) {
            h = h.substring(k.raw.length), E = p[p.length - 1], E && (E.type === "paragraph" || E.type === "text") ? (E.raw += `
` + k.raw, E.text += `
` + k.raw, this.inlineQueue[this.inlineQueue.length - 1].src = E.text) : this.tokens.links[k.tag] || (this.tokens.links[k.tag] = {
              href: k.href,
              title: k.title
            });
            continue;
          }
          if (k = this.tokenizer.table(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.lheading(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (re = h, this.options.extensions && this.options.extensions.startBlock && function() {
            var ve = 1 / 0, we = h.slice(1), ue = void 0;
            F.options.extensions.startBlock.forEach(function(Ce) {
              ue = Ce.call({
                lexer: this
              }, we), typeof ue == "number" && ue >= 0 && (ve = Math.min(ve, ue));
            }), ve < 1 / 0 && ve >= 0 && (re = h.substring(0, ve + 1));
          }(), this.state.top && (k = this.tokenizer.paragraph(re))) {
            E = p[p.length - 1], de && E.type === "paragraph" ? (E.raw += `
` + k.raw, E.text += `
` + k.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = E.text) : p.push(k), de = re.length !== h.length, h = h.substring(k.raw.length);
            continue;
          }
          if (k = this.tokenizer.text(h)) {
            h = h.substring(k.raw.length), E = p[p.length - 1], E && E.type === "text" ? (E.raw += `
` + k.raw, E.text += `
` + k.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = E.text) : p.push(k);
            continue;
          }
          if (h) {
            var fe = "Infinite loop on byte: " + h.charCodeAt(0);
            if (this.options.silent) {
              console.error(fe);
              break;
            } else
              throw new Error(fe);
          }
        }
      return this.state.top = !0, p;
    }, O.inline = function(h, p) {
      return p === void 0 && (p = []), this.inlineQueue.push({
        src: h,
        tokens: p
      }), p;
    }, O.inlineTokens = function(h, p) {
      var F = this;
      p === void 0 && (p = []);
      var k, E, re, de = h, fe, ve, we;
      if (this.tokens.links) {
        var ue = Object.keys(this.tokens.links);
        if (ue.length > 0)
          for (; (fe = this.tokenizer.rules.inline.reflinkSearch.exec(de)) != null; )
            ue.includes(fe[0].slice(fe[0].lastIndexOf("[") + 1, -1)) && (de = de.slice(0, fe.index) + "[" + Me("a", fe[0].length - 2) + "]" + de.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
      }
      for (; (fe = this.tokenizer.rules.inline.blockSkip.exec(de)) != null; )
        de = de.slice(0, fe.index) + "[" + Me("a", fe[0].length - 2) + "]" + de.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
      for (; (fe = this.tokenizer.rules.inline.escapedEmSt.exec(de)) != null; )
        de = de.slice(0, fe.index + fe[0].length - 2) + "++" + de.slice(this.tokenizer.rules.inline.escapedEmSt.lastIndex), this.tokenizer.rules.inline.escapedEmSt.lastIndex--;
      for (; h; )
        if (ve || (we = ""), ve = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some(function(U) {
          return (k = U.call({
            lexer: F
          }, h, p)) ? (h = h.substring(k.raw.length), p.push(k), !0) : !1;
        }))) {
          if (k = this.tokenizer.escape(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.tag(h)) {
            h = h.substring(k.raw.length), E = p[p.length - 1], E && k.type === "text" && E.type === "text" ? (E.raw += k.raw, E.text += k.text) : p.push(k);
            continue;
          }
          if (k = this.tokenizer.link(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.reflink(h, this.tokens.links)) {
            h = h.substring(k.raw.length), E = p[p.length - 1], E && k.type === "text" && E.type === "text" ? (E.raw += k.raw, E.text += k.text) : p.push(k);
            continue;
          }
          if (k = this.tokenizer.emStrong(h, de, we)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.codespan(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.br(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.del(h)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (k = this.tokenizer.autolink(h, Ee)) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (!this.state.inLink && (k = this.tokenizer.url(h, Ee))) {
            h = h.substring(k.raw.length), p.push(k);
            continue;
          }
          if (re = h, this.options.extensions && this.options.extensions.startInline && function() {
            var U = 1 / 0, ze = h.slice(1), Oe = void 0;
            F.options.extensions.startInline.forEach(function(He) {
              Oe = He.call({
                lexer: this
              }, ze), typeof Oe == "number" && Oe >= 0 && (U = Math.min(U, Oe));
            }), U < 1 / 0 && U >= 0 && (re = h.substring(0, U + 1));
          }(), k = this.tokenizer.inlineText(re, Ne)) {
            h = h.substring(k.raw.length), k.raw.slice(-1) !== "_" && (we = k.raw.slice(-1)), ve = !0, E = p[p.length - 1], E && E.type === "text" ? (E.raw += k.raw, E.text += k.text) : p.push(k);
            continue;
          }
          if (h) {
            var Ce = "Infinite loop on byte: " + h.charCodeAt(0);
            if (this.options.silent) {
              console.error(Ce);
              break;
            } else
              throw new Error(Ce);
          }
        }
      return p;
    }, c(I, null, [{
      key: "rules",
      get: function() {
        return {
          block: d,
          inline: j
        };
      }
    }]), I;
  }(), ht = /* @__PURE__ */ function() {
    function I(B) {
      this.options = B || s.defaults;
    }
    var O = I.prototype;
    return O.code = function(h, p, F) {
      var k = (p || "").match(/\S*/)[0];
      if (this.options.highlight) {
        var E = this.options.highlight(h, k);
        E != null && E !== h && (F = !0, h = E);
      }
      return h = h.replace(/\n$/, "") + `
`, k ? '<pre><code class="' + this.options.langPrefix + Q(k) + '">' + (F ? h : Q(h, !0)) + `</code></pre>
` : "<pre><code>" + (F ? h : Q(h, !0)) + `</code></pre>
`;
    }, O.blockquote = function(h) {
      return `<blockquote>
` + h + `</blockquote>
`;
    }, O.html = function(h) {
      return h;
    }, O.heading = function(h, p, F, k) {
      if (this.options.headerIds) {
        var E = this.options.headerPrefix + k.slug(F);
        return "<h" + p + ' id="' + E + '">' + h + "</h" + p + `>
`;
      }
      return "<h" + p + ">" + h + "</h" + p + `>
`;
    }, O.hr = function() {
      return this.options.xhtml ? `<hr/>
` : `<hr>
`;
    }, O.list = function(h, p, F) {
      var k = p ? "ol" : "ul", E = p && F !== 1 ? ' start="' + F + '"' : "";
      return "<" + k + E + `>
` + h + "</" + k + `>
`;
    }, O.listitem = function(h) {
      return "<li>" + h + `</li>
`;
    }, O.checkbox = function(h) {
      return "<input " + (h ? 'checked="" ' : "") + 'disabled="" type="checkbox"' + (this.options.xhtml ? " /" : "") + "> ";
    }, O.paragraph = function(h) {
      return "<p>" + h + `</p>
`;
    }, O.table = function(h, p) {
      return p && (p = "<tbody>" + p + "</tbody>"), `<table>
<thead>
` + h + `</thead>
` + p + `</table>
`;
    }, O.tablerow = function(h) {
      return `<tr>
` + h + `</tr>
`;
    }, O.tablecell = function(h, p) {
      var F = p.header ? "th" : "td", k = p.align ? "<" + F + ' align="' + p.align + '">' : "<" + F + ">";
      return k + h + ("</" + F + `>
`);
    }, O.strong = function(h) {
      return "<strong>" + h + "</strong>";
    }, O.em = function(h) {
      return "<em>" + h + "</em>";
    }, O.codespan = function(h) {
      return "<code>" + h + "</code>";
    }, O.br = function() {
      return this.options.xhtml ? "<br/>" : "<br>";
    }, O.del = function(h) {
      return "<del>" + h + "</del>";
    }, O.link = function(h, p, F) {
      if (h = oe(this.options.sanitize, this.options.baseUrl, h), h === null)
        return F;
      var k = '<a href="' + h + '"';
      return p && (k += ' title="' + p + '"'), k += ">" + F + "</a>", k;
    }, O.image = function(h, p, F) {
      if (h = oe(this.options.sanitize, this.options.baseUrl, h), h === null)
        return F;
      var k = '<img src="' + h + '" alt="' + F + '"';
      return p && (k += ' title="' + p + '"'), k += this.options.xhtml ? "/>" : ">", k;
    }, O.text = function(h) {
      return h;
    }, I;
  }(), Xe = /* @__PURE__ */ function() {
    function I() {
    }
    var O = I.prototype;
    return O.strong = function(h) {
      return h;
    }, O.em = function(h) {
      return h;
    }, O.codespan = function(h) {
      return h;
    }, O.del = function(h) {
      return h;
    }, O.html = function(h) {
      return h;
    }, O.text = function(h) {
      return h;
    }, O.link = function(h, p, F) {
      return "" + F;
    }, O.image = function(h, p, F) {
      return "" + F;
    }, O.br = function() {
      return "";
    }, I;
  }(), nt = /* @__PURE__ */ function() {
    function I() {
      this.seen = {};
    }
    var O = I.prototype;
    return O.serialize = function(h) {
      return h.toLowerCase().trim().replace(/<[!\/a-z].*?>/ig, "").replace(/[\u2000-\u206F\u2E00-\u2E7F\\'!"#$%&()*+,./:;<=>?@[\]^`{|}~]/g, "").replace(/\s/g, "-");
    }, O.getNextSafeSlug = function(h, p) {
      var F = h, k = 0;
      if (this.seen.hasOwnProperty(F)) {
        k = this.seen[h];
        do
          k++, F = h + "-" + k;
        while (this.seen.hasOwnProperty(F));
      }
      return p || (this.seen[h] = k, this.seen[F] = 0), F;
    }, O.slug = function(h, p) {
      p === void 0 && (p = {});
      var F = this.serialize(h);
      return this.getNextSafeSlug(F, p.dryrun);
    }, I;
  }(), Ie = /* @__PURE__ */ function() {
    function I(B) {
      this.options = B || s.defaults, this.options.renderer = this.options.renderer || new ht(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Xe(), this.slugger = new nt();
    }
    I.parse = function(h, p) {
      var F = new I(p);
      return F.parse(h);
    }, I.parseInline = function(h, p) {
      var F = new I(p);
      return F.parseInline(h);
    };
    var O = I.prototype;
    return O.parse = function(h, p) {
      p === void 0 && (p = !0);
      var F = "", k, E, re, de, fe, ve, we, ue, Ce, U, ze, Oe, He, Le, at, pt, Nt, Ye, Xt, Yt = h.length;
      for (k = 0; k < Yt; k++) {
        if (U = h[k], this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[U.type] && (Xt = this.options.extensions.renderers[U.type].call({
          parser: this
        }, U), Xt !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(U.type))) {
          F += Xt || "";
          continue;
        }
        switch (U.type) {
          case "space":
            continue;
          case "hr": {
            F += this.renderer.hr();
            continue;
          }
          case "heading": {
            F += this.renderer.heading(this.parseInline(U.tokens), U.depth, q(this.parseInline(U.tokens, this.textRenderer)), this.slugger);
            continue;
          }
          case "code": {
            F += this.renderer.code(U.text, U.lang, U.escaped);
            continue;
          }
          case "table": {
            for (ue = "", we = "", de = U.header.length, E = 0; E < de; E++)
              we += this.renderer.tablecell(this.parseInline(U.header[E].tokens), {
                header: !0,
                align: U.align[E]
              });
            for (ue += this.renderer.tablerow(we), Ce = "", de = U.rows.length, E = 0; E < de; E++) {
              for (ve = U.rows[E], we = "", fe = ve.length, re = 0; re < fe; re++)
                we += this.renderer.tablecell(this.parseInline(ve[re].tokens), {
                  header: !1,
                  align: U.align[re]
                });
              Ce += this.renderer.tablerow(we);
            }
            F += this.renderer.table(ue, Ce);
            continue;
          }
          case "blockquote": {
            Ce = this.parse(U.tokens), F += this.renderer.blockquote(Ce);
            continue;
          }
          case "list": {
            for (ze = U.ordered, Oe = U.start, He = U.loose, de = U.items.length, Ce = "", E = 0; E < de; E++)
              at = U.items[E], pt = at.checked, Nt = at.task, Le = "", at.task && (Ye = this.renderer.checkbox(pt), He ? at.tokens.length > 0 && at.tokens[0].type === "paragraph" ? (at.tokens[0].text = Ye + " " + at.tokens[0].text, at.tokens[0].tokens && at.tokens[0].tokens.length > 0 && at.tokens[0].tokens[0].type === "text" && (at.tokens[0].tokens[0].text = Ye + " " + at.tokens[0].tokens[0].text)) : at.tokens.unshift({
                type: "text",
                text: Ye
              }) : Le += Ye), Le += this.parse(at.tokens, He), Ce += this.renderer.listitem(Le, Nt, pt);
            F += this.renderer.list(Ce, ze, Oe);
            continue;
          }
          case "html": {
            F += this.renderer.html(U.text);
            continue;
          }
          case "paragraph": {
            F += this.renderer.paragraph(this.parseInline(U.tokens));
            continue;
          }
          case "text": {
            for (Ce = U.tokens ? this.parseInline(U.tokens) : U.text; k + 1 < Yt && h[k + 1].type === "text"; )
              U = h[++k], Ce += `
` + (U.tokens ? this.parseInline(U.tokens) : U.text);
            F += p ? this.renderer.paragraph(Ce) : Ce;
            continue;
          }
          default: {
            var It = 'Token with "' + U.type + '" type was not found.';
            if (this.options.silent) {
              console.error(It);
              return;
            } else
              throw new Error(It);
          }
        }
      }
      return F;
    }, O.parseInline = function(h, p) {
      p = p || this.renderer;
      var F = "", k, E, re, de = h.length;
      for (k = 0; k < de; k++) {
        if (E = h[k], this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[E.type] && (re = this.options.extensions.renderers[E.type].call({
          parser: this
        }, E), re !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(E.type))) {
          F += re || "";
          continue;
        }
        switch (E.type) {
          case "escape": {
            F += p.text(E.text);
            break;
          }
          case "html": {
            F += p.html(E.text);
            break;
          }
          case "link": {
            F += p.link(E.href, E.title, this.parseInline(E.tokens, p));
            break;
          }
          case "image": {
            F += p.image(E.href, E.title, E.text);
            break;
          }
          case "strong": {
            F += p.strong(this.parseInline(E.tokens, p));
            break;
          }
          case "em": {
            F += p.em(this.parseInline(E.tokens, p));
            break;
          }
          case "codespan": {
            F += p.codespan(E.text);
            break;
          }
          case "br": {
            F += p.br();
            break;
          }
          case "del": {
            F += p.del(this.parseInline(E.tokens, p));
            break;
          }
          case "text": {
            F += p.text(E.text);
            break;
          }
          default: {
            var fe = 'Token with "' + E.type + '" type was not found.';
            if (this.options.silent) {
              console.error(fe);
              return;
            } else
              throw new Error(fe);
          }
        }
      }
      return F;
    }, I;
  }(), _e = /* @__PURE__ */ function() {
    function I(B) {
      this.options = B || s.defaults;
    }
    var O = I.prototype;
    return O.preprocess = function(h) {
      return h;
    }, O.postprocess = function(h) {
      return h;
    }, I;
  }();
  _e.passThroughHooks = /* @__PURE__ */ new Set(["preprocess", "postprocess"]);
  function Je(I, O, B) {
    return function(h) {
      if (h.message += `
Please report this to https://github.com/markedjs/marked.`, I) {
        var p = "<p>An error occurred:</p><pre>" + Q(h.message + "", !0) + "</pre>";
        if (O)
          return Promise.resolve(p);
        if (B) {
          B(null, p);
          return;
        }
        return p;
      }
      if (O)
        return Promise.reject(h);
      if (B) {
        B(h);
        return;
      }
      throw h;
    };
  }
  function dt(I, O) {
    return function(B, h, p) {
      typeof h == "function" && (p = h, h = null);
      var F = v({}, h);
      h = v({}, ye.defaults, F);
      var k = Je(h.silent, h.async, p);
      if (typeof B > "u" || B === null)
        return k(new Error("marked(): input parameter is undefined or null"));
      if (typeof B != "string")
        return k(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(B) + ", string expected"));
      if (ge(h), h.hooks && (h.hooks.options = h), p) {
        var E = h.highlight, re;
        try {
          h.hooks && (B = h.hooks.preprocess(B)), re = I(B, h);
        } catch (ue) {
          return k(ue);
        }
        var de = function(Ce) {
          var U;
          if (!Ce)
            try {
              h.walkTokens && ye.walkTokens(re, h.walkTokens), U = O(re, h), h.hooks && (U = h.hooks.postprocess(U));
            } catch (ze) {
              Ce = ze;
            }
          return h.highlight = E, Ce ? k(Ce) : p(null, U);
        };
        if (!E || E.length < 3 || (delete h.highlight, !re.length))
          return de();
        var fe = 0;
        ye.walkTokens(re, function(ue) {
          ue.type === "code" && (fe++, setTimeout(function() {
            E(ue.text, ue.lang, function(Ce, U) {
              if (Ce)
                return de(Ce);
              U != null && U !== ue.text && (ue.text = U, ue.escaped = !0), fe--, fe === 0 && de();
            });
          }, 0));
        }), fe === 0 && de();
        return;
      }
      if (h.async)
        return Promise.resolve(h.hooks ? h.hooks.preprocess(B) : B).then(function(ue) {
          return I(ue, h);
        }).then(function(ue) {
          return h.walkTokens ? Promise.all(ye.walkTokens(ue, h.walkTokens)).then(function() {
            return ue;
          }) : ue;
        }).then(function(ue) {
          return O(ue, h);
        }).then(function(ue) {
          return h.hooks ? h.hooks.postprocess(ue) : ue;
        }).catch(k);
      try {
        h.hooks && (B = h.hooks.preprocess(B));
        var ve = I(B, h);
        h.walkTokens && ye.walkTokens(ve, h.walkTokens);
        var we = O(ve, h);
        return h.hooks && (we = h.hooks.postprocess(we)), we;
      } catch (ue) {
        return k(ue);
      }
    };
  }
  function ye(I, O, B) {
    return dt($e.lex, Ie.parse)(I, O, B);
  }
  ye.options = ye.setOptions = function(I) {
    return ye.defaults = v({}, ye.defaults, I), z(ye.defaults), ye;
  }, ye.getDefaults = A, ye.defaults = s.defaults, ye.use = function() {
    for (var I = ye.defaults.extensions || {
      renderers: {},
      childTokens: {}
    }, O = arguments.length, B = new Array(O), h = 0; h < O; h++)
      B[h] = arguments[h];
    B.forEach(function(p) {
      var F = v({}, p);
      if (F.async = ye.defaults.async || F.async || !1, p.extensions && (p.extensions.forEach(function(E) {
        if (!E.name)
          throw new Error("extension name required");
        if (E.renderer) {
          var re = I.renderers[E.name];
          re ? I.renderers[E.name] = function() {
            for (var de = arguments.length, fe = new Array(de), ve = 0; ve < de; ve++)
              fe[ve] = arguments[ve];
            var we = E.renderer.apply(this, fe);
            return we === !1 && (we = re.apply(this, fe)), we;
          } : I.renderers[E.name] = E.renderer;
        }
        if (E.tokenizer) {
          if (!E.level || E.level !== "block" && E.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          I[E.level] ? I[E.level].unshift(E.tokenizer) : I[E.level] = [E.tokenizer], E.start && (E.level === "block" ? I.startBlock ? I.startBlock.push(E.start) : I.startBlock = [E.start] : E.level === "inline" && (I.startInline ? I.startInline.push(E.start) : I.startInline = [E.start]));
        }
        E.childTokens && (I.childTokens[E.name] = E.childTokens);
      }), F.extensions = I), p.renderer && function() {
        var E = ye.defaults.renderer || new ht(), re = function(ve) {
          var we = E[ve];
          E[ve] = function() {
            for (var ue = arguments.length, Ce = new Array(ue), U = 0; U < ue; U++)
              Ce[U] = arguments[U];
            var ze = p.renderer[ve].apply(E, Ce);
            return ze === !1 && (ze = we.apply(E, Ce)), ze;
          };
        };
        for (var de in p.renderer)
          re(de);
        F.renderer = E;
      }(), p.tokenizer && function() {
        var E = ye.defaults.tokenizer || new S(), re = function(ve) {
          var we = E[ve];
          E[ve] = function() {
            for (var ue = arguments.length, Ce = new Array(ue), U = 0; U < ue; U++)
              Ce[U] = arguments[U];
            var ze = p.tokenizer[ve].apply(E, Ce);
            return ze === !1 && (ze = we.apply(E, Ce)), ze;
          };
        };
        for (var de in p.tokenizer)
          re(de);
        F.tokenizer = E;
      }(), p.hooks && function() {
        var E = ye.defaults.hooks || new _e(), re = function(ve) {
          var we = E[ve];
          _e.passThroughHooks.has(ve) ? E[ve] = function(ue) {
            if (ye.defaults.async)
              return Promise.resolve(p.hooks[ve].call(E, ue)).then(function(U) {
                return we.call(E, U);
              });
            var Ce = p.hooks[ve].call(E, ue);
            return we.call(E, Ce);
          } : E[ve] = function() {
            for (var ue = arguments.length, Ce = new Array(ue), U = 0; U < ue; U++)
              Ce[U] = arguments[U];
            var ze = p.hooks[ve].apply(E, Ce);
            return ze === !1 && (ze = we.apply(E, Ce)), ze;
          };
        };
        for (var de in p.hooks)
          re(de);
        F.hooks = E;
      }(), p.walkTokens) {
        var k = ye.defaults.walkTokens;
        F.walkTokens = function(E) {
          var re = [];
          return re.push(p.walkTokens.call(this, E)), k && (re = re.concat(k.call(this, E))), re;
        };
      }
      ye.setOptions(F);
    });
  }, ye.walkTokens = function(I, O) {
    for (var B = [], h = function() {
      var E = F.value;
      switch (B = B.concat(O.call(ye, E)), E.type) {
        case "table": {
          for (var re = g(E.header), de; !(de = re()).done; ) {
            var fe = de.value;
            B = B.concat(ye.walkTokens(fe.tokens, O));
          }
          for (var ve = g(E.rows), we; !(we = ve()).done; )
            for (var ue = we.value, Ce = g(ue), U; !(U = Ce()).done; ) {
              var ze = U.value;
              B = B.concat(ye.walkTokens(ze.tokens, O));
            }
          break;
        }
        case "list": {
          B = B.concat(ye.walkTokens(E.items, O));
          break;
        }
        default:
          ye.defaults.extensions && ye.defaults.extensions.childTokens && ye.defaults.extensions.childTokens[E.type] ? ye.defaults.extensions.childTokens[E.type].forEach(function(Oe) {
            B = B.concat(ye.walkTokens(E[Oe], O));
          }) : E.tokens && (B = B.concat(ye.walkTokens(E.tokens, O)));
      }
    }, p = g(I), F; !(F = p()).done; )
      h();
    return B;
  }, ye.parseInline = dt($e.lexInline, Ie.parseInline), ye.Parser = Ie, ye.parser = Ie.parse, ye.Renderer = ht, ye.TextRenderer = Xe, ye.Lexer = $e, ye.lexer = $e.lex, ye.Tokenizer = S, ye.Slugger = nt, ye.Hooks = _e, ye.parse = ye;
  var Bt = ye.options, Mt = ye.setOptions, At = ye.use, Wt = ye.walkTokens, Be = ye.parseInline, Et = ye, _t = Ie.parse, Tr = $e.lex;
  s.Hooks = _e, s.Lexer = $e, s.Parser = Ie, s.Renderer = ht, s.Slugger = nt, s.TextRenderer = Xe, s.Tokenizer = S, s.getDefaults = A, s.lexer = Tr, s.marked = ye, s.options = Bt, s.parse = Et, s.parseInline = Be, s.parser = _t, s.setOptions = Mt, s.use = At, s.walkTokens = Wt;
})(Vo);
var Jr = Tt, Lf = Ef, Ha = Vo.marked, eu = /Mac/.test(navigator.platform), Tf = new RegExp(/(<a.*?https?:\/\/.*?[^a]>)+?/g), Li = {
  toggleBold: dn,
  toggleItalic: pn,
  drawLink: Sn,
  toggleHeadingSmaller: Ti,
  toggleHeadingBigger: xn,
  drawImage: Fn,
  toggleBlockquote: mn,
  toggleOrderedList: wn,
  toggleUnorderedList: Cn,
  toggleCodeBlock: vn,
  togglePreview: Bn,
  toggleStrikethrough: gn,
  toggleHeading1: yn,
  toggleHeading2: Dn,
  toggleHeading3: bn,
  toggleHeading4: za,
  toggleHeading5: Pa,
  toggleHeading6: Wa,
  cleanBlock: kn,
  drawTable: An,
  drawHorizontalRule: En,
  undo: Ln,
  redo: Tn,
  toggleSideBySide: Vr,
  toggleFullScreen: Er
}, Bf = {
  toggleBold: "Cmd-B",
  toggleItalic: "Cmd-I",
  drawLink: "Cmd-K",
  toggleHeadingSmaller: "Cmd-H",
  toggleHeadingBigger: "Shift-Cmd-H",
  toggleHeading1: "Ctrl+Alt+1",
  toggleHeading2: "Ctrl+Alt+2",
  toggleHeading3: "Ctrl+Alt+3",
  toggleHeading4: "Ctrl+Alt+4",
  toggleHeading5: "Ctrl+Alt+5",
  toggleHeading6: "Ctrl+Alt+6",
  cleanBlock: "Cmd-E",
  drawImage: "Cmd-Alt-I",
  toggleBlockquote: "Cmd-'",
  toggleOrderedList: "Cmd-Alt-L",
  toggleUnorderedList: "Cmd-L",
  toggleCodeBlock: "Cmd-Alt-C",
  togglePreview: "Cmd-P",
  toggleSideBySide: "F9",
  toggleFullScreen: "F11"
}, Mf = function(s) {
  for (var b in Li)
    if (Li[b] === s)
      return b;
  return null;
}, Ra = function() {
  var s = !1;
  return function(b) {
    (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(b) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw-(n|u)|c55\/|capi|ccwa|cdm-|cell|chtm|cldc|cmd-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc-s|devi|dica|dmob|do(c|p)o|ds(12|-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(-|_)|g1 u|g560|gene|gf-5|g-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd-(m|p|t)|hei-|hi(pt|ta)|hp( i|ip)|hs-c|ht(c(-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i-(20|go|ma)|i230|iac( |-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|-[a-w])|libw|lynx|m1-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|-([1-8]|c))|phil|pire|pl(ay|uc)|pn-2|po(ck|rt|se)|prox|psio|pt-g|qa-a|qc(07|12|21|32|60|-[2-7]|i-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h-|oo|p-)|sdk\/|se(c(-|0|1)|47|mc|nd|ri)|sgh-|shar|sie(-|m)|sk-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h-|v-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl-|tdg-|tel(i|m)|tim-|t-mo|to(pl|sh)|ts(70|m-|m3|m5)|tx-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas-|your|zeto|zte-/i.test(b.substr(0, 4))) && (s = !0);
  }(navigator.userAgent || navigator.vendor || window.opera), s;
};
function Nf(s) {
  for (var b; (b = Tf.exec(s)) !== null; ) {
    var c = b[0];
    if (c.indexOf("target=") === -1) {
      var v = c.replace(/>$/, ' target="_blank">');
      s = s.replace(c, v);
    }
  }
  return s;
}
function If(s) {
  for (var b = new DOMParser(), c = b.parseFromString(s, "text/html"), v = c.getElementsByTagName("li"), m = 0; m < v.length; m++)
    for (var C = v[m], g = 0; g < C.children.length; g++) {
      var y = C.children[g];
      y instanceof HTMLInputElement && y.type === "checkbox" && (C.style.marginLeft = "-1.5em", C.style.listStyleType = "none");
    }
  return c.documentElement.innerHTML;
}
function tu(s) {
  return eu ? s = s.replace("Ctrl", "Cmd") : s = s.replace("Cmd", "Ctrl"), s;
}
function Of(s, b, c, v) {
  var m = cn(s, !1, b, c, "button", v);
  m.classList.add("easymde-dropdown"), m.onclick = function() {
    m.focus();
  };
  var C = document.createElement("div");
  C.className = "easymde-dropdown-content";
  for (var g = 0; g < s.children.length; g++) {
    var y = s.children[g], x;
    typeof y == "string" && y in Ar ? x = cn(Ar[y], !0, b, c, "button", v) : x = cn(y, !0, b, c, "button", v), x.addEventListener("click", function(A) {
      A.stopPropagation();
    }, !1), C.appendChild(x);
  }
  return m.appendChild(C), m;
}
function cn(s, b, c, v, m, C) {
  s = s || {};
  var g = document.createElement(m);
  if (s.attributes)
    for (var y in s.attributes)
      Object.prototype.hasOwnProperty.call(s.attributes, y) && g.setAttribute(y, s.attributes[y]);
  var x = C.options.toolbarButtonClassPrefix ? C.options.toolbarButtonClassPrefix + "-" : "";
  g.className = x + s.name, g.setAttribute("type", m), c = c ?? !0, s.text && (g.innerText = s.text), s.name && s.name in v && (Li[s.name] = s.action), s.title && c && (g.title = Rf(s.title, s.action, v), eu && (g.title = g.title.replace("Ctrl", "⌘"), g.title = g.title.replace("Alt", "⌥"))), s.title && g.setAttribute("aria-label", s.title), s.noDisable && g.classList.add("no-disable"), s.noMobile && g.classList.add("no-mobile");
  var A = [];
  typeof s.className < "u" && (A = s.className.split(" "));
  for (var z = [], P = 0; P < A.length; P++) {
    var N = A[P];
    N.match(/^fa([srlb]|(-[\w-]*)|$)/) ? z.push(N) : g.classList.add(N);
  }
  if (g.tabIndex = -1, z.length > 0) {
    for (var G = document.createElement("i"), X = 0; X < z.length; X++) {
      var le = z[X];
      G.classList.add(le);
    }
    g.appendChild(G);
  }
  return typeof s.icon < "u" && (g.innerHTML = s.icon), s.action && b && (typeof s.action == "function" ? g.onclick = function(J) {
    J.preventDefault(), s.action(C);
  } : typeof s.action == "string" && (g.onclick = function(J) {
    J.preventDefault(), window.open(s.action, "_blank");
  })), g;
}
function Hf() {
  var s = document.createElement("i");
  return s.className = "separator", s.innerHTML = "|", s;
}
function Rf(s, b, c) {
  var v, m = s;
  return b && (v = Mf(b), c[v] && (m += " (" + tu(c[v]) + ")")), m;
}
function hr(s, b) {
  b = b || s.getCursor("start");
  var c = s.getTokenAt(b);
  if (!c.type)
    return {};
  for (var v = c.type.split(" "), m = {}, C, g, y = 0; y < v.length; y++)
    C = v[y], C === "strong" ? m.bold = !0 : C === "variable-2" ? (g = s.getLine(b.line), /^\s*\d+\.\s/.test(g) ? m["ordered-list"] = !0 : m["unordered-list"] = !0) : C === "atom" ? m.quote = !0 : C === "em" ? m.italic = !0 : C === "quote" ? m.quote = !0 : C === "strikethrough" ? m.strikethrough = !0 : C === "comment" ? m.code = !0 : C === "link" && !m.image ? m.link = !0 : C === "image" ? m.image = !0 : C.match(/^header(-[1-6])?$/) && (m[C.replace("header", "heading")] = !0);
  return m;
}
var Yo = "";
function Er(s) {
  var b = s.codemirror;
  b.setOption("fullScreen", !b.getOption("fullScreen")), b.getOption("fullScreen") ? (Yo = document.body.style.overflow, document.body.style.overflow = "hidden") : document.body.style.overflow = Yo;
  var c = b.getWrapperElement(), v = c.nextSibling;
  if (v.classList.contains("editor-preview-active-side"))
    if (s.options.sideBySideFullscreen === !1) {
      var m = c.parentNode;
      b.getOption("fullScreen") ? m.classList.remove("sided--no-fullscreen") : m.classList.add("sided--no-fullscreen");
    } else
      Vr(s);
  if (s.options.onToggleFullScreen && s.options.onToggleFullScreen(b.getOption("fullScreen") || !1), typeof s.options.maxHeight < "u" && (b.getOption("fullScreen") ? (b.getScrollerElement().style.removeProperty("height"), v.style.removeProperty("height")) : (b.getScrollerElement().style.height = s.options.maxHeight, s.setPreviewMaxHeight())), s.toolbar_div.classList.toggle("fullscreen"), s.toolbarElements && s.toolbarElements.fullscreen) {
    var C = s.toolbarElements.fullscreen;
    C.classList.toggle("active");
  }
}
function dn(s) {
  qa(s, "bold", s.options.blockStyles.bold);
}
function pn(s) {
  qa(s, "italic", s.options.blockStyles.italic);
}
function gn(s) {
  qa(s, "strikethrough", "~~");
}
function vn(s) {
  var b = s.options.blockStyles.code;
  function c(De) {
    if (typeof De != "object")
      throw "fencing_line() takes a 'line' object (not a line number, or line text).  Got: " + typeof De + ": " + De;
    return De.styles && De.styles[2] && De.styles[2].indexOf("formatting-code-block") !== -1;
  }
  function v(De) {
    return De.state.base.base || De.state.base;
  }
  function m(De, T, V, Z, ge) {
    V = V || De.getLineHandle(T), Z = Z || De.getTokenAt({
      line: T,
      ch: 1
    }), ge = ge || !!V.text && De.getTokenAt({
      line: T,
      ch: V.text.length - 1
    });
    var Me = Z.type ? Z.type.split(" ") : [];
    return ge && v(ge).indentedCode ? "indented" : Me.indexOf("comment") === -1 ? !1 : v(Z).fencedChars || v(ge).fencedChars || c(V) ? "fenced" : "single";
  }
  function C(De, T, V, Z) {
    var ge = T.line + 1, Me = V.line + 1, et = T.line !== V.line, Pt = Z + `
`, S = `
` + Z;
    et && Me++, et && V.ch === 0 && (S = Z + `
`, Me--), Lr(De, !1, [Pt, S]), De.setSelection({
      line: ge,
      ch: 0
    }, {
      line: Me,
      ch: 0
    });
  }
  var g = s.codemirror, y = g.getCursor("start"), x = g.getCursor("end"), A = g.getTokenAt({
    line: y.line,
    ch: y.ch || 1
  }), z = g.getLineHandle(y.line), P = m(g, y.line, z, A), N, G, X;
  if (P === "single") {
    var le = z.text.slice(0, y.ch).replace("`", ""), J = z.text.slice(y.ch).replace("`", "");
    g.replaceRange(le + J, {
      line: y.line,
      ch: 0
    }, {
      line: y.line,
      ch: 99999999999999
    }), y.ch--, y !== x && x.ch--, g.setSelection(y, x), g.focus();
  } else if (P === "fenced")
    if (y.line !== x.line || y.ch !== x.ch) {
      for (N = y.line; N >= 0 && (z = g.getLineHandle(N), !c(z)); N--)
        ;
      var Q = g.getTokenAt({
        line: N,
        ch: 1
      }), H = v(Q).fencedChars, q, R, _, te;
      c(g.getLineHandle(y.line)) ? (q = "", R = y.line) : c(g.getLineHandle(y.line - 1)) ? (q = "", R = y.line - 1) : (q = H + `
`, R = y.line), c(g.getLineHandle(x.line)) ? (_ = "", te = x.line, x.ch === 0 && (te += 1)) : x.ch !== 0 && c(g.getLineHandle(x.line + 1)) ? (_ = "", te = x.line + 1) : (_ = H + `
`, te = x.line + 1), x.ch === 0 && (te -= 1), g.operation(function() {
        g.replaceRange(_, {
          line: te,
          ch: 0
        }, {
          line: te + (_ ? 0 : 1),
          ch: 0
        }), g.replaceRange(q, {
          line: R,
          ch: 0
        }, {
          line: R + (q ? 0 : 1),
          ch: 0
        });
      }), g.setSelection({
        line: R + (q ? 1 : 0),
        ch: 0
      }, {
        line: te + (q ? 1 : -1),
        ch: 0
      }), g.focus();
    } else {
      var Y = y.line;
      if (c(g.getLineHandle(y.line)) && (m(g, y.line + 1) === "fenced" ? (N = y.line, Y = y.line + 1) : (G = y.line, Y = y.line - 1)), N === void 0)
        for (N = Y; N >= 0 && (z = g.getLineHandle(N), !c(z)); N--)
          ;
      if (G === void 0)
        for (X = g.lineCount(), G = Y; G < X && (z = g.getLineHandle(G), !c(z)); G++)
          ;
      g.operation(function() {
        g.replaceRange("", {
          line: N,
          ch: 0
        }, {
          line: N + 1,
          ch: 0
        }), g.replaceRange("", {
          line: G - 1,
          ch: 0
        }, {
          line: G,
          ch: 0
        });
      }), g.focus();
    }
  else if (P === "indented") {
    if (y.line !== x.line || y.ch !== x.ch)
      N = y.line, G = x.line, x.ch === 0 && G--;
    else {
      for (N = y.line; N >= 0; N--)
        if (z = g.getLineHandle(N), !z.text.match(/^\s*$/) && m(g, N, z) !== "indented") {
          N += 1;
          break;
        }
      for (X = g.lineCount(), G = y.line; G < X; G++)
        if (z = g.getLineHandle(G), !z.text.match(/^\s*$/) && m(g, G, z) !== "indented") {
          G -= 1;
          break;
        }
    }
    var oe = g.getLineHandle(G + 1), pe = oe && g.getTokenAt({
      line: G + 1,
      ch: oe.text.length - 1
    }), qe = pe && v(pe).indentedCode;
    qe && g.replaceRange(`
`, {
      line: G + 1,
      ch: 0
    });
    for (var ae = N; ae <= G; ae++)
      g.indentLine(ae, "subtract");
    g.focus();
  } else {
    var Se = y.line === x.line && y.ch === x.ch && y.ch === 0, ke = y.line !== x.line;
    Se || ke ? C(g, y, x, b) : Lr(g, !1, ["`", "`"]);
  }
}
function mn(s) {
  Ua(s.codemirror, "quote");
}
function Ti(s) {
  dr(s.codemirror, "smaller");
}
function xn(s) {
  dr(s.codemirror, "bigger");
}
function yn(s) {
  dr(s.codemirror, void 0, 1);
}
function Dn(s) {
  dr(s.codemirror, void 0, 2);
}
function bn(s) {
  dr(s.codemirror, void 0, 3);
}
function za(s) {
  dr(s.codemirror, void 0, 4);
}
function Pa(s) {
  dr(s.codemirror, void 0, 5);
}
function Wa(s) {
  dr(s.codemirror, void 0, 6);
}
function Cn(s) {
  var b = s.codemirror, c = "*";
  ["-", "+", "*"].includes(s.options.unorderedListStyle) && (c = s.options.unorderedListStyle), Ua(b, "unordered-list", c);
}
function wn(s) {
  Ua(s.codemirror, "ordered-list");
}
function kn(s) {
  zf(s.codemirror);
}
function Sn(s) {
  var b = s.options, c = "https://";
  if (b.promptURLs) {
    var v = prompt(b.promptTexts.link, c);
    if (!v)
      return !1;
    c = ru(v);
  }
  nu(s, "link", b.insertTexts.link, c);
}
function Fn(s) {
  var b = s.options, c = "https://";
  if (b.promptURLs) {
    var v = prompt(b.promptTexts.image, c);
    if (!v)
      return !1;
    c = ru(v);
  }
  nu(s, "image", b.insertTexts.image, c);
}
function ru(s) {
  return encodeURI(s).replace(/([\\()])/g, "\\$1");
}
function _a(s) {
  s.openBrowseFileWindow();
}
function iu(s, b) {
  var c = s.codemirror, v = hr(c), m = s.options, C = b.substr(b.lastIndexOf("/") + 1), g = C.substring(C.lastIndexOf(".") + 1).replace(/\?.*$/, "").toLowerCase();
  if (["png", "jpg", "jpeg", "gif", "svg", "apng", "avif", "webp"].includes(g))
    Lr(c, v.image, m.insertTexts.uploadedImage, b);
  else {
    var y = m.insertTexts.link;
    y[0] = "[" + C, Lr(c, v.link, y, b);
  }
  s.updateStatusBar("upload-image", s.options.imageTexts.sbOnUploaded.replace("#image_name#", C)), setTimeout(function() {
    s.updateStatusBar("upload-image", s.options.imageTexts.sbInit);
  }, 1e3);
}
function An(s) {
  var b = s.codemirror, c = hr(b), v = s.options;
  Lr(b, c.table, v.insertTexts.table);
}
function En(s) {
  var b = s.codemirror, c = hr(b), v = s.options;
  Lr(b, c.image, v.insertTexts.horizontalRule);
}
function Ln(s) {
  var b = s.codemirror;
  b.undo(), b.focus();
}
function Tn(s) {
  var b = s.codemirror;
  b.redo(), b.focus();
}
function Vr(s) {
  var b = s.codemirror, c = b.getWrapperElement(), v = c.nextSibling, m = s.toolbarElements && s.toolbarElements["side-by-side"], C = !1, g = c.parentNode;
  v.classList.contains("editor-preview-active-side") ? (s.options.sideBySideFullscreen === !1 && g.classList.remove("sided--no-fullscreen"), v.classList.remove("editor-preview-active-side"), m && m.classList.remove("active"), c.classList.remove("CodeMirror-sided")) : (setTimeout(function() {
    b.getOption("fullScreen") || (s.options.sideBySideFullscreen === !1 ? g.classList.add("sided--no-fullscreen") : Er(s)), v.classList.add("editor-preview-active-side");
  }, 1), m && m.classList.add("active"), c.classList.add("CodeMirror-sided"), C = !0);
  var y = c.lastChild;
  if (y.classList.contains("editor-preview-active")) {
    y.classList.remove("editor-preview-active");
    var x = s.toolbarElements.preview, A = s.toolbar_div;
    x.classList.remove("active"), A.classList.remove("disabled-for-preview");
  }
  var z = function() {
    var N = s.options.previewRender(s.value(), v);
    N != null && (v.innerHTML = N);
  };
  if (b.sideBySideRenderingFunction || (b.sideBySideRenderingFunction = z), C) {
    var P = s.options.previewRender(s.value(), v);
    P != null && (v.innerHTML = P), b.on("update", b.sideBySideRenderingFunction);
  } else
    b.off("update", b.sideBySideRenderingFunction);
  b.refresh();
}
function Bn(s) {
  var b = s.codemirror, c = b.getWrapperElement(), v = s.toolbar_div, m = s.options.toolbar ? s.toolbarElements.preview : !1, C = c.lastChild, g = b.getWrapperElement().nextSibling;
  if (g.classList.contains("editor-preview-active-side") && Vr(s), !C || !C.classList.contains("editor-preview-full")) {
    if (C = document.createElement("div"), C.className = "editor-preview-full", s.options.previewClass)
      if (Array.isArray(s.options.previewClass))
        for (var y = 0; y < s.options.previewClass.length; y++)
          C.classList.add(s.options.previewClass[y]);
      else
        typeof s.options.previewClass == "string" && C.classList.add(s.options.previewClass);
    c.appendChild(C);
  }
  C.classList.contains("editor-preview-active") ? (C.classList.remove("editor-preview-active"), m && (m.classList.remove("active"), v.classList.remove("disabled-for-preview"))) : (setTimeout(function() {
    C.classList.add("editor-preview-active");
  }, 1), m && (m.classList.add("active"), v.classList.add("disabled-for-preview")));
  var x = s.options.previewRender(s.value(), C);
  x !== null && (C.innerHTML = x);
}
function Lr(s, b, c, v) {
  if (!s.getWrapperElement().lastChild.classList.contains("editor-preview-active")) {
    var m, C = c[0], g = c[1], y = {}, x = {};
    Object.assign(y, s.getCursor("start")), Object.assign(x, s.getCursor("end")), v && (C = C.replace("#url#", v), g = g.replace("#url#", v)), b ? (m = s.getLine(y.line), C = m.slice(0, y.ch), g = m.slice(y.ch), s.replaceRange(C + g, {
      line: y.line,
      ch: 0
    })) : (m = s.getSelection(), s.replaceSelection(C + m + g), y.ch += C.length, y !== x && (x.ch += C.length)), s.setSelection(y, x), s.focus();
  }
}
function dr(s, b, c) {
  if (!s.getWrapperElement().lastChild.classList.contains("editor-preview-active")) {
    for (var v = s.getCursor("start"), m = s.getCursor("end"), C = v.line; C <= m.line; C++)
      (function(g) {
        var y = s.getLine(g), x = y.search(/[^#]/);
        b !== void 0 ? x <= 0 ? b == "bigger" ? y = "###### " + y : y = "# " + y : x == 6 && b == "smaller" ? y = y.substr(7) : x == 1 && b == "bigger" ? y = y.substr(2) : b == "bigger" ? y = y.substr(1) : y = "#" + y : x <= 0 ? y = "#".repeat(c) + " " + y : x == c ? y = y.substr(x + 1) : y = "#".repeat(c) + " " + y.substr(x + 1), s.replaceRange(y, {
          line: g,
          ch: 0
        }, {
          line: g,
          ch: 99999999999999
        });
      })(C);
    s.focus();
  }
}
function Ua(s, b, c) {
  if (!s.getWrapperElement().lastChild.classList.contains("editor-preview-active")) {
    for (var v = /^(\s*)(\*|-|\+|\d*\.)(\s+)/, m = /^\s*/, C = hr(s), g = s.getCursor("start"), y = s.getCursor("end"), x = {
      quote: /^(\s*)>\s+/,
      "unordered-list": v,
      "ordered-list": v
    }, A = function(X, le) {
      var J = {
        quote: ">",
        "unordered-list": c,
        "ordered-list": "%%i."
      };
      return J[X].replace("%%i", le);
    }, z = function(X, le) {
      var J = {
        quote: ">",
        "unordered-list": "\\" + c,
        "ordered-list": "\\d+."
      }, Q = new RegExp(J[X]);
      return le && Q.test(le);
    }, P = function(X, le, J) {
      var Q = v.exec(le), H = A(X, N);
      return Q !== null ? (z(X, Q[2]) && (H = ""), le = Q[1] + H + Q[3] + le.replace(m, "").replace(x[X], "$1")) : J == !1 && (le = H + " " + le), le;
    }, N = 1, G = g.line; G <= y.line; G++)
      (function(X) {
        var le = s.getLine(X);
        C[b] ? le = le.replace(x[b], "$1") : (b == "unordered-list" && (le = P("ordered-list", le, !0)), le = P(b, le, !1), N += 1), s.replaceRange(le, {
          line: X,
          ch: 0
        }, {
          line: X,
          ch: 99999999999999
        });
      })(G);
    s.focus();
  }
}
function nu(s, b, c, v) {
  if (!(!s.codemirror || s.isPreviewActive())) {
    var m = s.codemirror, C = hr(m), g = C[b];
    if (!g) {
      Lr(m, g, c, v);
      return;
    }
    var y = m.getCursor("start"), x = m.getCursor("end"), A = m.getLine(y.line), z = A.slice(0, y.ch), P = A.slice(y.ch);
    b == "link" ? z = z.replace(/(.*)[^!]\[/, "$1") : b == "image" && (z = z.replace(/(.*)!\[$/, "$1")), P = P.replace(/]\(.*?\)/, ""), m.replaceRange(z + P, {
      line: y.line,
      ch: 0
    }, {
      line: y.line,
      ch: 99999999999999
    }), y.ch -= c[0].length, y !== x && (x.ch -= c[0].length), m.setSelection(y, x), m.focus();
  }
}
function qa(s, b, c, v) {
  if (!(!s.codemirror || s.isPreviewActive())) {
    v = typeof v > "u" ? c : v;
    var m = s.codemirror, C = hr(m), g, y = c, x = v, A = m.getCursor("start"), z = m.getCursor("end");
    C[b] ? (g = m.getLine(A.line), y = g.slice(0, A.ch), x = g.slice(A.ch), b == "bold" ? (y = y.replace(/(\*\*|__)(?![\s\S]*(\*\*|__))/, ""), x = x.replace(/(\*\*|__)/, "")) : b == "italic" ? (y = y.replace(/(\*|_)(?![\s\S]*(\*|_))/, ""), x = x.replace(/(\*|_)/, "")) : b == "strikethrough" && (y = y.replace(/(\*\*|~~)(?![\s\S]*(\*\*|~~))/, ""), x = x.replace(/(\*\*|~~)/, "")), m.replaceRange(y + x, {
      line: A.line,
      ch: 0
    }, {
      line: A.line,
      ch: 99999999999999
    }), b == "bold" || b == "strikethrough" ? (A.ch -= 2, A !== z && (z.ch -= 2)) : b == "italic" && (A.ch -= 1, A !== z && (z.ch -= 1))) : (g = m.getSelection(), b == "bold" ? (g = g.split("**").join(""), g = g.split("__").join("")) : b == "italic" ? (g = g.split("*").join(""), g = g.split("_").join("")) : b == "strikethrough" && (g = g.split("~~").join("")), m.replaceSelection(y + g + x), A.ch += c.length, z.ch = A.ch + g.length), m.setSelection(A, z), m.focus();
  }
}
function zf(s) {
  if (!s.getWrapperElement().lastChild.classList.contains("editor-preview-active"))
    for (var b = s.getCursor("start"), c = s.getCursor("end"), v, m = b.line; m <= c.line; m++)
      v = s.getLine(m), v = v.replace(/^[ ]*([# ]+|\*|-|[> ]+|[0-9]+(.|\)))[ ]*/, ""), s.replaceRange(v, {
        line: m,
        ch: 0
      }, {
        line: m,
        ch: 99999999999999
      });
}
function hn(s, b) {
  if (Math.abs(s) < 1024)
    return "" + s + b[0];
  var c = 0;
  do
    s /= 1024, ++c;
  while (Math.abs(s) >= 1024 && c < b.length);
  return "" + s.toFixed(1) + b[c];
}
function au(s, b) {
  for (var c in b)
    Object.prototype.hasOwnProperty.call(b, c) && (b[c] instanceof Array ? s[c] = b[c].concat(s[c] instanceof Array ? s[c] : []) : b[c] !== null && typeof b[c] == "object" && b[c].constructor === Object ? s[c] = au(s[c] || {}, b[c]) : s[c] = b[c]);
  return s;
}
function tr(s) {
  for (var b = 1; b < arguments.length; b++)
    s = au(s, arguments[b]);
  return s;
}
function Zo(s) {
  var b = /[a-zA-Z0-9_\u00A0-\u02AF\u0392-\u03c9\u0410-\u04F9]+|[\u4E00-\u9FFF\u3400-\u4dbf\uf900-\ufaff\u3040-\u309f\uac00-\ud7af]+/g, c = s.match(b), v = 0;
  if (c === null)
    return v;
  for (var m = 0; m < c.length; m++)
    c[m].charCodeAt(0) >= 19968 ? v += c[m].length : v += 1;
  return v;
}
var Ge = {
  bold: "fa fa-bold",
  italic: "fa fa-italic",
  strikethrough: "fa fa-strikethrough",
  heading: "fa fa-header fa-heading",
  "heading-smaller": "fa fa-header fa-heading header-smaller",
  "heading-bigger": "fa fa-header fa-heading header-bigger",
  "heading-1": "fa fa-header fa-heading header-1",
  "heading-2": "fa fa-header fa-heading header-2",
  "heading-3": "fa fa-header fa-heading header-3",
  code: "fa fa-code",
  quote: "fa fa-quote-left",
  "ordered-list": "fa fa-list-ol",
  "unordered-list": "fa fa-list-ul",
  "clean-block": "fa fa-eraser",
  link: "fa fa-link",
  image: "fa fa-image",
  "upload-image": "fa fa-image",
  table: "fa fa-table",
  "horizontal-rule": "fa fa-minus",
  preview: "fa fa-eye",
  "side-by-side": "fa fa-columns",
  fullscreen: "fa fa-arrows-alt",
  guide: "fa fa-question-circle",
  undo: "fa fa-undo",
  redo: "fa fa-repeat fa-redo"
}, Ar = {
  bold: {
    name: "bold",
    action: dn,
    className: Ge.bold,
    title: "Bold",
    default: !0
  },
  italic: {
    name: "italic",
    action: pn,
    className: Ge.italic,
    title: "Italic",
    default: !0
  },
  strikethrough: {
    name: "strikethrough",
    action: gn,
    className: Ge.strikethrough,
    title: "Strikethrough"
  },
  heading: {
    name: "heading",
    action: Ti,
    className: Ge.heading,
    title: "Heading",
    default: !0
  },
  "heading-smaller": {
    name: "heading-smaller",
    action: Ti,
    className: Ge["heading-smaller"],
    title: "Smaller Heading"
  },
  "heading-bigger": {
    name: "heading-bigger",
    action: xn,
    className: Ge["heading-bigger"],
    title: "Bigger Heading"
  },
  "heading-1": {
    name: "heading-1",
    action: yn,
    className: Ge["heading-1"],
    title: "Big Heading"
  },
  "heading-2": {
    name: "heading-2",
    action: Dn,
    className: Ge["heading-2"],
    title: "Medium Heading"
  },
  "heading-3": {
    name: "heading-3",
    action: bn,
    className: Ge["heading-3"],
    title: "Small Heading"
  },
  "separator-1": {
    name: "separator-1"
  },
  code: {
    name: "code",
    action: vn,
    className: Ge.code,
    title: "Code"
  },
  quote: {
    name: "quote",
    action: mn,
    className: Ge.quote,
    title: "Quote",
    default: !0
  },
  "unordered-list": {
    name: "unordered-list",
    action: Cn,
    className: Ge["unordered-list"],
    title: "Generic List",
    default: !0
  },
  "ordered-list": {
    name: "ordered-list",
    action: wn,
    className: Ge["ordered-list"],
    title: "Numbered List",
    default: !0
  },
  "clean-block": {
    name: "clean-block",
    action: kn,
    className: Ge["clean-block"],
    title: "Clean block"
  },
  "separator-2": {
    name: "separator-2"
  },
  link: {
    name: "link",
    action: Sn,
    className: Ge.link,
    title: "Create Link",
    default: !0
  },
  image: {
    name: "image",
    action: Fn,
    className: Ge.image,
    title: "Insert Image",
    default: !0
  },
  "upload-image": {
    name: "upload-image",
    action: _a,
    className: Ge["upload-image"],
    title: "Import an image"
  },
  table: {
    name: "table",
    action: An,
    className: Ge.table,
    title: "Insert Table"
  },
  "horizontal-rule": {
    name: "horizontal-rule",
    action: En,
    className: Ge["horizontal-rule"],
    title: "Insert Horizontal Line"
  },
  "separator-3": {
    name: "separator-3"
  },
  preview: {
    name: "preview",
    action: Bn,
    className: Ge.preview,
    noDisable: !0,
    title: "Toggle Preview",
    default: !0
  },
  "side-by-side": {
    name: "side-by-side",
    action: Vr,
    className: Ge["side-by-side"],
    noDisable: !0,
    noMobile: !0,
    title: "Toggle Side by Side",
    default: !0
  },
  fullscreen: {
    name: "fullscreen",
    action: Er,
    className: Ge.fullscreen,
    noDisable: !0,
    noMobile: !0,
    title: "Toggle Fullscreen",
    default: !0
  },
  "separator-4": {
    name: "separator-4"
  },
  guide: {
    name: "guide",
    action: "https://www.markdownguide.org/basic-syntax/",
    className: Ge.guide,
    noDisable: !0,
    title: "Markdown Guide",
    default: !0
  },
  "separator-5": {
    name: "separator-5"
  },
  undo: {
    name: "undo",
    action: Ln,
    className: Ge.undo,
    noDisable: !0,
    title: "Undo"
  },
  redo: {
    name: "redo",
    action: Tn,
    className: Ge.redo,
    noDisable: !0,
    title: "Redo"
  }
}, Pf = {
  link: ["[", "](#url#)"],
  image: ["![", "](#url#)"],
  uploadedImage: ["![](#url#)", ""],
  // uploadedImage: ['![](#url#)\n', ''], // TODO: New line insertion doesn't work here.
  table: ["", `

| Column 1 | Column 2 | Column 3 |
| -------- | -------- | -------- |
| Text     | Text     | Text     |

`],
  horizontalRule: ["", `

-----

`]
}, Wf = {
  link: "URL for the link:",
  image: "URL of the image:"
}, _f = {
  locale: "en-US",
  format: {
    hour: "2-digit",
    minute: "2-digit"
  }
}, Uf = {
  bold: "**",
  code: "```",
  italic: "*"
}, qf = {
  sbInit: "Attach files by drag and dropping or pasting from clipboard.",
  sbOnDragEnter: "Drop image to upload it.",
  sbOnDrop: "Uploading image #images_names#...",
  sbProgress: "Uploading #file_name#: #progress#%",
  sbOnUploaded: "Uploaded #image_name#",
  sizeUnits: " B, KB, MB"
}, Gf = {
  noFileGiven: "You must select a file.",
  typeNotAllowed: "This image type is not allowed.",
  fileTooLarge: `Image #image_name# is too big (#image_size#).
Maximum file size is #image_max_size#.`,
  importError: "Something went wrong when uploading the image #image_name#."
};
function ce(s) {
  s = s || {}, s.parent = this;
  var b = !0;
  if (s.autoDownloadFontAwesome === !1 && (b = !1), s.autoDownloadFontAwesome !== !0)
    for (var c = document.styleSheets, v = 0; v < c.length; v++)
      c[v].href && c[v].href.indexOf("//maxcdn.bootstrapcdn.com/font-awesome/") > -1 && (b = !1);
  if (b) {
    var m = document.createElement("link");
    m.rel = "stylesheet", m.href = "https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css", document.getElementsByTagName("head")[0].appendChild(m);
  }
  if (s.element)
    this.element = s.element;
  else if (s.element === null) {
    console.log("EasyMDE: Error. No element was found.");
    return;
  }
  if (s.toolbar === void 0) {
    s.toolbar = [];
    for (var C in Ar)
      Object.prototype.hasOwnProperty.call(Ar, C) && (C.indexOf("separator-") != -1 && s.toolbar.push("|"), (Ar[C].default === !0 || s.showIcons && s.showIcons.constructor === Array && s.showIcons.indexOf(C) != -1) && s.toolbar.push(C));
  }
  if (Object.prototype.hasOwnProperty.call(s, "previewClass") || (s.previewClass = "editor-preview"), Object.prototype.hasOwnProperty.call(s, "status") || (s.status = ["autosave", "lines", "words", "cursor"], s.uploadImage && s.status.unshift("upload-image")), s.previewRender || (s.previewRender = function(y) {
    return this.parent.markdown(y);
  }), s.parsingConfig = tr({
    highlightFormatting: !0
    // needed for toggleCodeBlock to detect types of code
  }, s.parsingConfig || {}), s.insertTexts = tr({}, Pf, s.insertTexts || {}), s.promptTexts = tr({}, Wf, s.promptTexts || {}), s.blockStyles = tr({}, Uf, s.blockStyles || {}), s.autosave != null && (s.autosave.timeFormat = tr({}, _f, s.autosave.timeFormat || {})), s.iconClassMap = tr({}, Ge, s.iconClassMap || {}), s.shortcuts = tr({}, Bf, s.shortcuts || {}), s.maxHeight = s.maxHeight || void 0, s.direction = s.direction || "ltr", typeof s.maxHeight < "u" ? s.minHeight = s.maxHeight : s.minHeight = s.minHeight || "300px", s.errorCallback = s.errorCallback || function(y) {
    alert(y);
  }, s.uploadImage = s.uploadImage || !1, s.imageMaxSize = s.imageMaxSize || 2097152, s.imageAccept = s.imageAccept || "image/png, image/jpeg, image/gif, image/avif", s.imageTexts = tr({}, qf, s.imageTexts || {}), s.errorMessages = tr({}, Gf, s.errorMessages || {}), s.imagePathAbsolute = s.imagePathAbsolute || !1, s.imageCSRFName = s.imageCSRFName || "csrfmiddlewaretoken", s.imageCSRFHeader = s.imageCSRFHeader || !1, s.imageInputName = s.imageInputName || "image", s.autosave != null && s.autosave.unique_id != null && s.autosave.unique_id != "" && (s.autosave.uniqueId = s.autosave.unique_id), s.overlayMode && s.overlayMode.combine === void 0 && (s.overlayMode.combine = !0), this.options = s, this.render(), s.initialValue && (!this.options.autosave || this.options.autosave.foundSavedValue !== !0) && this.value(s.initialValue), s.uploadImage) {
    var g = this;
    this.codemirror.on("dragenter", function(y, x) {
      g.updateStatusBar("upload-image", g.options.imageTexts.sbOnDragEnter), x.stopPropagation(), x.preventDefault();
    }), this.codemirror.on("dragend", function(y, x) {
      g.updateStatusBar("upload-image", g.options.imageTexts.sbInit), x.stopPropagation(), x.preventDefault();
    }), this.codemirror.on("dragleave", function(y, x) {
      g.updateStatusBar("upload-image", g.options.imageTexts.sbInit), x.stopPropagation(), x.preventDefault();
    }), this.codemirror.on("dragover", function(y, x) {
      g.updateStatusBar("upload-image", g.options.imageTexts.sbOnDragEnter), x.stopPropagation(), x.preventDefault();
    }), this.codemirror.on("drop", function(y, x) {
      x.stopPropagation(), x.preventDefault(), s.imageUploadFunction ? g.uploadImagesUsingCustomFunction(s.imageUploadFunction, x.dataTransfer.files) : g.uploadImages(x.dataTransfer.files);
    }), this.codemirror.on("paste", function(y, x) {
      s.imageUploadFunction ? g.uploadImagesUsingCustomFunction(s.imageUploadFunction, x.clipboardData.files) : g.uploadImages(x.clipboardData.files);
    });
  }
}
ce.prototype.uploadImages = function(s, b, c) {
  if (s.length !== 0) {
    for (var v = [], m = 0; m < s.length; m++)
      v.push(s[m].name), this.uploadImage(s[m], b, c);
    this.updateStatusBar("upload-image", this.options.imageTexts.sbOnDrop.replace("#images_names#", v.join(", ")));
  }
};
ce.prototype.uploadImagesUsingCustomFunction = function(s, b) {
  if (b.length !== 0) {
    for (var c = [], v = 0; v < b.length; v++)
      c.push(b[v].name), this.uploadImageUsingCustomFunction(s, b[v]);
    this.updateStatusBar("upload-image", this.options.imageTexts.sbOnDrop.replace("#images_names#", c.join(", ")));
  }
};
ce.prototype.updateStatusBar = function(s, b) {
  if (this.gui.statusbar) {
    var c = this.gui.statusbar.getElementsByClassName(s);
    c.length === 1 ? this.gui.statusbar.getElementsByClassName(s)[0].textContent = b : c.length === 0 ? console.log("EasyMDE: status bar item " + s + " was not found.") : console.log("EasyMDE: Several status bar items named " + s + " was found.");
  }
};
ce.prototype.markdown = function(s) {
  if (Ha) {
    var b;
    if (this.options && this.options.renderingConfig && this.options.renderingConfig.markedOptions ? b = this.options.renderingConfig.markedOptions : b = {}, this.options && this.options.renderingConfig && this.options.renderingConfig.singleLineBreaks === !1 ? b.breaks = !1 : b.breaks = !0, this.options && this.options.renderingConfig && this.options.renderingConfig.codeSyntaxHighlighting === !0) {
      var c = this.options.renderingConfig.hljs || window.hljs;
      c && (b.highlight = function(m, C) {
        return C && c.getLanguage(C) ? c.highlight(C, m).value : c.highlightAuto(m).value;
      });
    }
    Ha.use(b);
    var v = Ha.parse(s);
    return this.options.renderingConfig && typeof this.options.renderingConfig.sanitizerFunction == "function" && (v = this.options.renderingConfig.sanitizerFunction.call(this, v)), v = Nf(v), v = If(v), v;
  }
};
ce.prototype.render = function(s) {
  if (s || (s = this.element || document.getElementsByTagName("textarea")[0]), this._rendered && this._rendered === s)
    return;
  this.element = s;
  var b = this.options, c = this, v = {};
  for (var m in b.shortcuts)
    b.shortcuts[m] !== null && Li[m] !== null && function(J) {
      v[tu(b.shortcuts[J])] = function() {
        var Q = Li[J];
        typeof Q == "function" ? Q(c) : typeof Q == "string" && window.open(Q, "_blank");
      };
    }(m);
  v.Enter = "newlineAndIndentContinueMarkdownList", v.Tab = "tabAndIndentMarkdownList", v["Shift-Tab"] = "shiftTabAndUnindentMarkdownList", v.Esc = function(J) {
    J.getOption("fullScreen") && Er(c);
  }, this.documentOnKeyDown = function(J) {
    J = J || window.event, J.keyCode == 27 && c.codemirror.getOption("fullScreen") && Er(c);
  }, document.addEventListener("keydown", this.documentOnKeyDown, !1);
  var C, g;
  b.overlayMode ? (Jr.defineMode("overlay-mode", function(J) {
    return Jr.overlayMode(Jr.getMode(J, b.spellChecker !== !1 ? "spell-checker" : "gfm"), b.overlayMode.mode, b.overlayMode.combine);
  }), C = "overlay-mode", g = b.parsingConfig, g.gitHubSpice = !1) : (C = b.parsingConfig, C.name = "gfm", C.gitHubSpice = !1), b.spellChecker !== !1 && (C = "spell-checker", g = b.parsingConfig, g.name = "gfm", g.gitHubSpice = !1, typeof b.spellChecker == "function" ? b.spellChecker({
    codeMirrorInstance: Jr
  }) : Lf({
    codeMirrorInstance: Jr
  }));
  function y(J, Q, H) {
    return {
      addNew: !1
    };
  }
  if (this.codemirror = Jr.fromTextArea(s, {
    mode: C,
    backdrop: g,
    theme: b.theme != null ? b.theme : "easymde",
    tabSize: b.tabSize != null ? b.tabSize : 2,
    indentUnit: b.tabSize != null ? b.tabSize : 2,
    indentWithTabs: b.indentWithTabs !== !1,
    lineNumbers: b.lineNumbers === !0,
    autofocus: b.autofocus === !0,
    extraKeys: v,
    direction: b.direction,
    lineWrapping: b.lineWrapping !== !1,
    allowDropFileTypes: ["text/plain"],
    placeholder: b.placeholder || s.getAttribute("placeholder") || "",
    styleSelectedText: b.styleSelectedText != null ? b.styleSelectedText : !Ra(),
    scrollbarStyle: b.scrollbarStyle != null ? b.scrollbarStyle : "native",
    configureMouse: y,
    inputStyle: b.inputStyle != null ? b.inputStyle : Ra() ? "contenteditable" : "textarea",
    spellcheck: b.nativeSpellcheck != null ? b.nativeSpellcheck : !0,
    autoRefresh: b.autoRefresh != null ? b.autoRefresh : !1
  }), this.codemirror.getScrollerElement().style.minHeight = b.minHeight, typeof b.maxHeight < "u" && (this.codemirror.getScrollerElement().style.height = b.maxHeight), b.forceSync === !0) {
    var x = this.codemirror;
    x.on("change", function() {
      x.save();
    });
  }
  this.gui = {};
  var A = document.createElement("div");
  A.classList.add("EasyMDEContainer"), A.setAttribute("role", "application");
  var z = this.codemirror.getWrapperElement();
  z.parentNode.insertBefore(A, z), A.appendChild(z), b.toolbar !== !1 && (this.gui.toolbar = this.createToolbar()), b.status !== !1 && (this.gui.statusbar = this.createStatusbar()), b.autosave != null && b.autosave.enabled === !0 && (this.autosave(), this.codemirror.on("change", function() {
    clearTimeout(c._autosave_timeout), c._autosave_timeout = setTimeout(function() {
      c.autosave();
    }, c.options.autosave.submit_delay || c.options.autosave.delay || 1e3);
  }));
  function P(J, Q) {
    var H, q = window.getComputedStyle(document.querySelector(".CodeMirror-sizer")).width.replace("px", "");
    return J < q ? H = Q + "px" : H = Q / J * 100 + "%", H;
  }
  var N = this;
  function G(J, Q) {
    var H = new URL(Q.url, document.baseURI).href;
    J.setAttribute("data-img-src", H), J.setAttribute("style", "--bg-image:url(" + H + ");--width:" + Q.naturalWidth + "px;--height:" + P(Q.naturalWidth, Q.naturalHeight)), N.codemirror.setSize();
  }
  function X() {
    b.previewImagesInEditor && A.querySelectorAll(".cm-image-marker").forEach(function(J) {
      var Q = J.parentElement;
      if (Q.innerText.match(/^!\[.*?\]\(.*\)/g) && !Q.hasAttribute("data-img-src")) {
        var H = Q.innerText.match(/!\[.*?\]\((.*?)\)/);
        if (window.EMDEimagesCache || (window.EMDEimagesCache = {}), H && H.length >= 2) {
          var q = H[1];
          if (b.imagesPreviewHandler) {
            var R = b.imagesPreviewHandler(H[1]);
            typeof R == "string" && (q = R);
          }
          if (window.EMDEimagesCache[q])
            G(Q, window.EMDEimagesCache[q]);
          else {
            window.EMDEimagesCache[q] = {};
            var _ = document.createElement("img");
            _.onload = function() {
              window.EMDEimagesCache[q] = {
                naturalWidth: _.naturalWidth,
                naturalHeight: _.naturalHeight,
                url: q
              }, G(Q, window.EMDEimagesCache[q]);
            }, _.src = q;
          }
        }
      }
    });
  }
  this.codemirror.on("update", function() {
    X();
  }), this.gui.sideBySide = this.createSideBySide(), this._rendered = this.element, (b.autofocus === !0 || s.autofocus) && this.codemirror.focus();
  var le = this.codemirror;
  setTimeout((function() {
    le.refresh();
  }).bind(le), 0);
};
ce.prototype.cleanup = function() {
  document.removeEventListener("keydown", this.documentOnKeyDown);
};
function lu() {
  if (typeof localStorage == "object")
    try {
      localStorage.setItem("smde_localStorage", 1), localStorage.removeItem("smde_localStorage");
    } catch {
      return !1;
    }
  else
    return !1;
  return !0;
}
ce.prototype.autosave = function() {
  if (lu()) {
    var s = this;
    if (this.options.autosave.uniqueId == null || this.options.autosave.uniqueId == "") {
      console.log("EasyMDE: You must set a uniqueId to use the autosave feature");
      return;
    }
    this.options.autosave.binded !== !0 && (s.element.form != null && s.element.form != null && s.element.form.addEventListener("submit", function() {
      clearTimeout(s.autosaveTimeoutId), s.autosaveTimeoutId = void 0, localStorage.removeItem("smde_" + s.options.autosave.uniqueId);
    }), this.options.autosave.binded = !0), this.options.autosave.loaded !== !0 && (typeof localStorage.getItem("smde_" + this.options.autosave.uniqueId) == "string" && localStorage.getItem("smde_" + this.options.autosave.uniqueId) != "" && (this.codemirror.setValue(localStorage.getItem("smde_" + this.options.autosave.uniqueId)), this.options.autosave.foundSavedValue = !0), this.options.autosave.loaded = !0);
    var b = s.value();
    b !== "" ? localStorage.setItem("smde_" + this.options.autosave.uniqueId, b) : localStorage.removeItem("smde_" + this.options.autosave.uniqueId);
    var c = document.getElementById("autosaved");
    if (c != null && c != null && c != "") {
      var v = /* @__PURE__ */ new Date(), m = new Intl.DateTimeFormat([this.options.autosave.timeFormat.locale, "en-US"], this.options.autosave.timeFormat.format).format(v), C = this.options.autosave.text == null ? "Autosaved: " : this.options.autosave.text;
      c.innerHTML = C + m;
    }
  } else
    console.log("EasyMDE: localStorage not available, cannot autosave");
};
ce.prototype.clearAutosavedValue = function() {
  if (lu()) {
    if (this.options.autosave == null || this.options.autosave.uniqueId == null || this.options.autosave.uniqueId == "") {
      console.log("EasyMDE: You must set a uniqueId to clear the autosave value");
      return;
    }
    localStorage.removeItem("smde_" + this.options.autosave.uniqueId);
  } else
    console.log("EasyMDE: localStorage not available, cannot autosave");
};
ce.prototype.openBrowseFileWindow = function(s, b) {
  var c = this, v = this.gui.toolbar.getElementsByClassName("imageInput")[0];
  v.click();
  function m(C) {
    c.options.imageUploadFunction ? c.uploadImagesUsingCustomFunction(c.options.imageUploadFunction, C.target.files) : c.uploadImages(C.target.files, s, b), v.removeEventListener("change", m);
  }
  v.addEventListener("change", m);
};
ce.prototype.uploadImage = function(s, b, c) {
  var v = this;
  b = b || function(A) {
    iu(v, A);
  };
  function m(x) {
    v.updateStatusBar("upload-image", x), setTimeout(function() {
      v.updateStatusBar("upload-image", v.options.imageTexts.sbInit);
    }, 1e4), c && typeof c == "function" && c(x), v.options.errorCallback(x);
  }
  function C(x) {
    var A = v.options.imageTexts.sizeUnits.split(",");
    return x.replace("#image_name#", s.name).replace("#image_size#", hn(s.size, A)).replace("#image_max_size#", hn(v.options.imageMaxSize, A));
  }
  if (s.size > this.options.imageMaxSize) {
    m(C(this.options.errorMessages.fileTooLarge));
    return;
  }
  var g = new FormData();
  g.append("image", s), v.options.imageCSRFToken && !v.options.imageCSRFHeader && g.append(v.options.imageCSRFName, v.options.imageCSRFToken);
  var y = new XMLHttpRequest();
  y.upload.onprogress = function(x) {
    if (x.lengthComputable) {
      var A = "" + Math.round(x.loaded * 100 / x.total);
      v.updateStatusBar("upload-image", v.options.imageTexts.sbProgress.replace("#file_name#", s.name).replace("#progress#", A));
    }
  }, y.open("POST", this.options.imageUploadEndpoint), v.options.imageCSRFToken && v.options.imageCSRFHeader && y.setRequestHeader(v.options.imageCSRFName, v.options.imageCSRFToken), y.onload = function() {
    try {
      var x = JSON.parse(this.responseText);
    } catch {
      console.error("EasyMDE: The server did not return a valid json."), m(C(v.options.errorMessages.importError));
      return;
    }
    this.status === 200 && x && !x.error && x.data && x.data.filePath ? b((v.options.imagePathAbsolute ? "" : window.location.origin + "/") + x.data.filePath) : x.error && x.error in v.options.errorMessages ? m(C(v.options.errorMessages[x.error])) : x.error ? m(C(x.error)) : (console.error("EasyMDE: Received an unexpected response after uploading the image." + this.status + " (" + this.statusText + ")"), m(C(v.options.errorMessages.importError)));
  }, y.onerror = function(x) {
    console.error("EasyMDE: An unexpected error occurred when trying to upload the image." + x.target.status + " (" + x.target.statusText + ")"), m(v.options.errorMessages.importError);
  }, y.send(g);
};
ce.prototype.uploadImageUsingCustomFunction = function(s, b) {
  var c = this;
  function v(g) {
    iu(c, g);
  }
  function m(g) {
    var y = C(g);
    c.updateStatusBar("upload-image", y), setTimeout(function() {
      c.updateStatusBar("upload-image", c.options.imageTexts.sbInit);
    }, 1e4), c.options.errorCallback(y);
  }
  function C(g) {
    var y = c.options.imageTexts.sizeUnits.split(",");
    return g.replace("#image_name#", b.name).replace("#image_size#", hn(b.size, y)).replace("#image_max_size#", hn(c.options.imageMaxSize, y));
  }
  s.apply(this, [b, v, m]);
};
ce.prototype.setPreviewMaxHeight = function() {
  var s = this.codemirror, b = s.getWrapperElement(), c = b.nextSibling, v = parseInt(window.getComputedStyle(b).paddingTop), m = parseInt(window.getComputedStyle(b).borderTopWidth), C = parseInt(this.options.maxHeight), g = C + v * 2 + m * 2, y = g.toString() + "px";
  c.style.height = y;
};
ce.prototype.createSideBySide = function() {
  var s = this.codemirror, b = s.getWrapperElement(), c = b.nextSibling;
  if (!c || !c.classList.contains("editor-preview-side")) {
    if (c = document.createElement("div"), c.className = "editor-preview-side", this.options.previewClass)
      if (Array.isArray(this.options.previewClass))
        for (var v = 0; v < this.options.previewClass.length; v++)
          c.classList.add(this.options.previewClass[v]);
      else
        typeof this.options.previewClass == "string" && c.classList.add(this.options.previewClass);
    b.parentNode.insertBefore(c, b.nextSibling);
  }
  if (typeof this.options.maxHeight < "u" && this.setPreviewMaxHeight(), this.options.syncSideBySidePreviewScroll === !1)
    return c;
  var m = !1, C = !1;
  return s.on("scroll", function(g) {
    if (m) {
      m = !1;
      return;
    }
    C = !0;
    var y = g.getScrollInfo().height - g.getScrollInfo().clientHeight, x = parseFloat(g.getScrollInfo().top) / y, A = (c.scrollHeight - c.clientHeight) * x;
    c.scrollTop = A;
  }), c.onscroll = function() {
    if (C) {
      C = !1;
      return;
    }
    m = !0;
    var g = c.scrollHeight - c.clientHeight, y = parseFloat(c.scrollTop) / g, x = (s.getScrollInfo().height - s.getScrollInfo().clientHeight) * y;
    s.scrollTo(0, x);
  }, c;
};
ce.prototype.createToolbar = function(s) {
  if (s = s || this.options.toolbar, !(!s || s.length === 0)) {
    var b;
    for (b = 0; b < s.length; b++)
      Ar[s[b]] != null && (s[b] = Ar[s[b]]);
    var c = document.createElement("div");
    c.className = "editor-toolbar", c.setAttribute("role", "toolbar");
    var v = this, m = {};
    for (v.toolbar = s, b = 0; b < s.length; b++)
      if (!(s[b].name == "guide" && v.options.toolbarGuideIcon === !1) && !(v.options.hideIcons && v.options.hideIcons.indexOf(s[b].name) != -1) && !((s[b].name == "fullscreen" || s[b].name == "side-by-side") && Ra())) {
        if (s[b] === "|") {
          for (var C = !1, g = b + 1; g < s.length; g++)
            s[g] !== "|" && (!v.options.hideIcons || v.options.hideIcons.indexOf(s[g].name) == -1) && (C = !0);
          if (!C)
            continue;
        }
        (function(A) {
          var z;
          if (A === "|" ? z = Hf() : A.children ? z = Of(A, v.options.toolbarTips, v.options.shortcuts, v) : z = cn(A, !0, v.options.toolbarTips, v.options.shortcuts, "button", v), m[A.name || A] = z, c.appendChild(z), A.name === "upload-image") {
            var P = document.createElement("input");
            P.className = "imageInput", P.type = "file", P.multiple = !0, P.name = v.options.imageInputName, P.accept = v.options.imageAccept, P.style.display = "none", P.style.opacity = 0, c.appendChild(P);
          }
        })(s[b]);
      }
    v.toolbar_div = c, v.toolbarElements = m;
    var y = this.codemirror;
    y.on("cursorActivity", function() {
      var A = hr(y);
      for (var z in m)
        (function(P) {
          var N = m[P];
          A[P] ? N.classList.add("active") : P != "fullscreen" && P != "side-by-side" && N.classList.remove("active");
        })(z);
    });
    var x = y.getWrapperElement();
    return x.parentNode.insertBefore(c, x), c;
  }
};
ce.prototype.createStatusbar = function(s) {
  s = s || this.options.status;
  var b = this.options, c = this.codemirror;
  if (!(!s || s.length === 0)) {
    var v = [], m, C, g, y;
    for (m = 0; m < s.length; m++)
      if (C = void 0, g = void 0, y = void 0, typeof s[m] == "object")
        v.push({
          className: s[m].className,
          defaultValue: s[m].defaultValue,
          onUpdate: s[m].onUpdate,
          onActivity: s[m].onActivity
        });
      else {
        var x = s[m];
        x === "words" ? (y = function(G) {
          G.innerHTML = Zo(c.getValue());
        }, C = function(G) {
          G.innerHTML = Zo(c.getValue());
        }) : x === "lines" ? (y = function(G) {
          G.innerHTML = c.lineCount();
        }, C = function(G) {
          G.innerHTML = c.lineCount();
        }) : x === "cursor" ? (y = function(G) {
          G.innerHTML = "1:1";
        }, g = function(G) {
          var X = c.getCursor(), le = X.line + 1, J = X.ch + 1;
          G.innerHTML = le + ":" + J;
        }) : x === "autosave" ? y = function(G) {
          b.autosave != null && b.autosave.enabled === !0 && G.setAttribute("id", "autosaved");
        } : x === "upload-image" && (y = function(G) {
          G.innerHTML = b.imageTexts.sbInit;
        }), v.push({
          className: x,
          defaultValue: y,
          onUpdate: C,
          onActivity: g
        });
      }
    var A = document.createElement("div");
    for (A.className = "editor-statusbar", m = 0; m < v.length; m++) {
      var z = v[m], P = document.createElement("span");
      P.className = z.className, typeof z.defaultValue == "function" && z.defaultValue(P), typeof z.onUpdate == "function" && this.codemirror.on("update", function(G, X) {
        return function() {
          X.onUpdate(G);
        };
      }(P, z)), typeof z.onActivity == "function" && this.codemirror.on("cursorActivity", function(G, X) {
        return function() {
          X.onActivity(G);
        };
      }(P, z)), A.appendChild(P);
    }
    var N = this.codemirror.getWrapperElement();
    return N.parentNode.insertBefore(A, N.nextSibling), A;
  }
};
ce.prototype.value = function(s) {
  var b = this.codemirror;
  if (s === void 0)
    return b.getValue();
  if (b.getDoc().setValue(s), this.isPreviewActive()) {
    var c = b.getWrapperElement(), v = c.lastChild, m = this.options.previewRender(s, v);
    m !== null && (v.innerHTML = m);
  }
  return this;
};
ce.toggleBold = dn;
ce.toggleItalic = pn;
ce.toggleStrikethrough = gn;
ce.toggleBlockquote = mn;
ce.toggleHeadingSmaller = Ti;
ce.toggleHeadingBigger = xn;
ce.toggleHeading1 = yn;
ce.toggleHeading2 = Dn;
ce.toggleHeading3 = bn;
ce.toggleHeading4 = za;
ce.toggleHeading5 = Pa;
ce.toggleHeading6 = Wa;
ce.toggleCodeBlock = vn;
ce.toggleUnorderedList = Cn;
ce.toggleOrderedList = wn;
ce.cleanBlock = kn;
ce.drawLink = Sn;
ce.drawImage = Fn;
ce.drawUploadedImage = _a;
ce.drawTable = An;
ce.drawHorizontalRule = En;
ce.undo = Ln;
ce.redo = Tn;
ce.togglePreview = Bn;
ce.toggleSideBySide = Vr;
ce.toggleFullScreen = Er;
ce.prototype.toggleBold = function() {
  dn(this);
};
ce.prototype.toggleItalic = function() {
  pn(this);
};
ce.prototype.toggleStrikethrough = function() {
  gn(this);
};
ce.prototype.toggleBlockquote = function() {
  mn(this);
};
ce.prototype.toggleHeadingSmaller = function() {
  Ti(this);
};
ce.prototype.toggleHeadingBigger = function() {
  xn(this);
};
ce.prototype.toggleHeading1 = function() {
  yn(this);
};
ce.prototype.toggleHeading2 = function() {
  Dn(this);
};
ce.prototype.toggleHeading3 = function() {
  bn(this);
};
ce.prototype.toggleHeading4 = function() {
  za(this);
};
ce.prototype.toggleHeading5 = function() {
  Pa(this);
};
ce.prototype.toggleHeading6 = function() {
  Wa(this);
};
ce.prototype.toggleCodeBlock = function() {
  vn(this);
};
ce.prototype.toggleUnorderedList = function() {
  Cn(this);
};
ce.prototype.toggleOrderedList = function() {
  wn(this);
};
ce.prototype.cleanBlock = function() {
  kn(this);
};
ce.prototype.drawLink = function() {
  Sn(this);
};
ce.prototype.drawImage = function() {
  Fn(this);
};
ce.prototype.drawUploadedImage = function() {
  _a(this);
};
ce.prototype.drawTable = function() {
  An(this);
};
ce.prototype.drawHorizontalRule = function() {
  En(this);
};
ce.prototype.undo = function() {
  Ln(this);
};
ce.prototype.redo = function() {
  Tn(this);
};
ce.prototype.togglePreview = function() {
  Bn(this);
};
ce.prototype.toggleSideBySide = function() {
  Vr(this);
};
ce.prototype.toggleFullScreen = function() {
  Er(this);
};
ce.prototype.isPreviewActive = function() {
  var s = this.codemirror, b = s.getWrapperElement(), c = b.lastChild;
  return c.classList.contains("editor-preview-active");
};
ce.prototype.isSideBySideActive = function() {
  var s = this.codemirror, b = s.getWrapperElement(), c = b.nextSibling;
  return c.classList.contains("editor-preview-active-side");
};
ce.prototype.isFullscreenActive = function() {
  var s = this.codemirror;
  return s.getOption("fullScreen");
};
ce.prototype.getState = function() {
  var s = this.codemirror;
  return hr(s);
};
ce.prototype.toTextArea = function() {
  var s = this.codemirror, b = s.getWrapperElement(), c = b.parentNode;
  c && (this.gui.toolbar && c.removeChild(this.gui.toolbar), this.gui.statusbar && c.removeChild(this.gui.statusbar), this.gui.sideBySide && c.removeChild(this.gui.sideBySide)), c.parentNode.insertBefore(b, c), c.remove(), s.toTextArea(), this.autosaveTimeoutId && (clearTimeout(this.autosaveTimeoutId), this.autosaveTimeoutId = void 0, this.clearAutosavedValue());
};
var jf = ce;
const Kf = /* @__PURE__ */ mf(jf), Qf = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Kf
}, Symbol.toStringTag, { value: "Module" }));
export {
  Qf as e
};
