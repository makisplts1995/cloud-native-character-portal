import { S as T, i as U, s as W, c as X, m as Y, k as Z, n as j, p as v } from "./index-e79f0bb2.js";
import { A as p, p as $ } from "./ApexChart-fb0e9d4c.js";
function tt(m) {
  let a, e;
  return a = new p({ props: { options: (
    /*options*/
    m[0]
  ) } }), {
    c() {
      X(a.$$.fragment);
    },
    m(c, f) {
      Y(a, c, f), e = !0;
    },
    p(c, [f]) {
      const h = {};
      f & /*options*/
      1 && (h.options = /*options*/
      c[0]), a.$set(h);
    },
    i(c) {
      e || (Z(a.$$.fragment, c), e = !0);
    },
    o(c) {
      j(a.$$.fragment, c), e = !1;
    },
    d(c) {
      v(a, c);
    }
  };
}
function et(m, a, e) {
  let c, f, h, V, { dataProvider: L } = a, { valueColumn: C } = a, { title: F } = a, { xAxisLabel: I } = a, { yAxisLabel: S } = a, { height: g } = a, { width: y } = a, { dataLabels: z } = a, { animate: B } = a, { stacked: N } = a, { palette: _ } = a, { c1: R, c2: q, c3: E, c4: H, c5: O } = a, { horizontal: k } = a, { bucketCount: M = 10 } = a, { onClick: w } = a;
  function K(t, o, n) {
    w == null || w({ rowsInBucket: t, lowerLimit: o, upperLimit: n });
  }
  const Q = (t, o, n) => {
    const d = (t.rows ?? []).map((l) => parseFloat(l[o])).filter((l) => !isNaN(l)), [b, s] = D(d), u = G(b, s, n), x = Array(n).fill(0);
    return d.forEach((l) => {
      const i = u.findIndex((P) => P.min <= l && l <= P.max);
      x[i]++;
    }), [{ data: u.map((l, i) => ({
      x: `${l.min} – ${l.max}`,
      y: x[i]
    })) }];
  }, D = (t) => {
    const o = Math.floor(Math.min(...t)), n = Math.ceil(Math.max(...t));
    return [o, n];
  }, G = (t, o, n) => {
    var u;
    n = n < 2 ? 2 : Math.floor(n);
    const A = o - t, d = Math.floor(A / n), b = A - d * n, s = [];
    for (let x = 0; x < n; x++) {
      const r = ((u = s == null ? void 0 : s[s.length - 1]) == null ? void 0 : u.max) ?? t, l = x < b ? 1 : 0;
      s.push({
        min: r,
        max: r + d + l
      });
    }
    return s;
  }, J = (t, o) => t && o === "x" || !t && o === "y" ? (n) => Math.floor(n) === n ? n : " " : (n) => n;
  return m.$$set = (t) => {
    "dataProvider" in t && e(1, L = t.dataProvider), "valueColumn" in t && e(2, C = t.valueColumn), "title" in t && e(3, F = t.title), "xAxisLabel" in t && e(4, I = t.xAxisLabel), "yAxisLabel" in t && e(5, S = t.yAxisLabel), "height" in t && e(6, g = t.height), "width" in t && e(7, y = t.width), "dataLabels" in t && e(8, z = t.dataLabels), "animate" in t && e(9, B = t.animate), "stacked" in t && e(10, N = t.stacked), "palette" in t && e(11, _ = t.palette), "c1" in t && e(12, R = t.c1), "c2" in t && e(13, q = t.c2), "c3" in t && e(14, E = t.c3), "c4" in t && e(15, H = t.c4), "c5" in t && e(16, O = t.c5), "horizontal" in t && e(17, k = t.horizontal), "bucketCount" in t && e(18, M = t.bucketCount), "onClick" in t && e(19, w = t.onClick);
  }, m.$$.update = () => {
    m.$$.dirty & /*dataProvider, valueColumn, bucketCount*/
    262150 && e(22, c = Q(L, C, M)), m.$$.dirty & /*horizontal*/
    131072 && e(21, f = J(k, "x")), m.$$.dirty & /*horizontal*/
    131072 && e(20, h = J(k, "y")), m.$$.dirty & /*series, palette, c1, c2, c3, c4, c5, title, dataLabels, height, width, stacked, animate, dataProvider, valueColumn, bucketCount, horizontal, xAxisLabel, xAxisFormatter, yAxisLabel, yAxisFormatter*/
    7864318 && e(0, V = {
      series: c,
      colors: _ === "Custom" ? [R, q, E, H, O] : [],
      theme: { palette: $(_) },
      title: { text: F },
      dataLabels: {
        enabled: z,
        dropShadow: { enabled: !0 }
      },
      chart: {
        height: g == null || g === "" ? "auto" : g,
        width: y == null || y === "" ? "100%" : y,
        type: "bar",
        stacked: N,
        animations: { enabled: B },
        toolbar: { show: !1 },
        zoom: { enabled: !1 },
        events: {
          // Clicking on a bucket
          dataPointSelection(t, o, n) {
            const A = n.dataPointIndex, b = (L.rows || []).map((i, P) => ({
              row: i,
              value: parseFloat(i[C]),
              i: P
            })).filter((i) => !isNaN(i.value)), [s, u] = D(b.map((i) => i.value)), r = G(s, u, M)[A], l = b.filter((i) => i.value >= r.min && i.value <= r.max).map((i) => i.row);
            K(l, r.min, r.max);
          }
        }
      },
      plotOptions: { bar: { horizontal: k } },
      xaxis: {
        type: "category",
        title: { text: I },
        labels: { formatter: f }
      },
      yaxis: {
        decimalsInFloat: 0,
        title: { text: S },
        labels: { formatter: h }
      }
    });
  }, [
    V,
    L,
    C,
    F,
    I,
    S,
    g,
    y,
    z,
    B,
    N,
    _,
    R,
    q,
    E,
    H,
    O,
    k,
    M,
    w,
    h,
    f,
    c
  ];
}
class it extends T {
  constructor(a) {
    super(), U(this, a, et, tt, W, {
      dataProvider: 1,
      valueColumn: 2,
      title: 3,
      xAxisLabel: 4,
      yAxisLabel: 5,
      height: 6,
      width: 7,
      dataLabels: 8,
      animate: 9,
      stacked: 10,
      palette: 11,
      c1: 12,
      c2: 13,
      c3: 14,
      c4: 15,
      c5: 16,
      horizontal: 17,
      bucketCount: 18,
      onClick: 19
    });
  }
}
export {
  it as default
};
