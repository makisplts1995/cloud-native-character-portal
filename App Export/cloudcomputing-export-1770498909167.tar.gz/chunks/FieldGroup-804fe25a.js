import { S as A, i as G, s as S, e as g, b as v, d as y, f as j, g as q, q as w, z as $, n as _, A as z, k as p, h as H, o as J, u as k, v as B, ad as D, F as h, G as F, H as C, J as P, c as E, m as I, p as K } from "./index-e79f0bb2.js";
import L from "./Section-387eaaf2.js";
import "./Placeholder-527c0fd1.js";
function M(n) {
  let l;
  const s = (
    /*#slots*/
    n[5].default
  ), e = h(
    s,
    n,
    /*$$scope*/
    n[6],
    null
  );
  return {
    c() {
      e && e.c();
    },
    m(t, o) {
      e && e.m(t, o), l = !0;
    },
    p(t, o) {
      e && e.p && (!l || o & /*$$scope*/
      64) && F(
        e,
        s,
        t,
        /*$$scope*/
        t[6],
        l ? P(
          s,
          /*$$scope*/
          t[6],
          o,
          null
        ) : C(
          /*$$scope*/
          t[6]
        ),
        null
      );
    },
    i(t) {
      l || (p(e, t), l = !0);
    },
    o(t) {
      _(e, t), l = !1;
    },
    d(t) {
      e && e.d(t);
    }
  };
}
function N(n) {
  let l, s;
  return l = new L({
    props: {
      type: (
        /*type*/
        n[1]
      ),
      $$slots: { default: [O] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      E(l.$$.fragment);
    },
    m(e, t) {
      I(l, e, t), s = !0;
    },
    p(e, t) {
      const o = {};
      t & /*type*/
      2 && (o.type = /*type*/
      e[1]), t & /*$$scope*/
      64 && (o.$$scope = { dirty: t, ctx: e }), l.$set(o);
    },
    i(e) {
      s || (p(l.$$.fragment, e), s = !0);
    },
    o(e) {
      _(l.$$.fragment, e), s = !1;
    },
    d(e) {
      K(l, e);
    }
  };
}
function O(n) {
  let l;
  const s = (
    /*#slots*/
    n[5].default
  ), e = h(
    s,
    n,
    /*$$scope*/
    n[6],
    null
  );
  return {
    c() {
      e && e.c();
    },
    m(t, o) {
      e && e.m(t, o), l = !0;
    },
    p(t, o) {
      e && e.p && (!l || o & /*$$scope*/
      64) && F(
        e,
        s,
        t,
        /*$$scope*/
        t[6],
        l ? P(
          s,
          /*$$scope*/
          t[6],
          o,
          null
        ) : C(
          /*$$scope*/
          t[6]
        ),
        null
      );
    },
    i(t) {
      l || (p(e, t), l = !0);
    },
    o(t) {
      _(e, t), l = !1;
    },
    d(t) {
      e && e.d(t);
    }
  };
}
function Q(n) {
  let l, s, e, t, o, u, c, m;
  const f = [N, M], a = [];
  function b(r, i) {
    return (
      /*labelPosition*/
      r[0] === "above" && /*type*/
      r[1] !== "oneColumn" ? 0 : 1
    );
  }
  return e = b(n), t = a[e] = f[e](n), {
    c() {
      l = g("div"), s = g("div"), t.c(), v(s, "class", "spectrum-Form svelte-ct1cyj"), y(
        s,
        "spectrum-Form--labelsAbove",
        /*labelPosition*/
        n[0] === "above"
      ), v(l, "class", "wrapper svelte-ct1cyj");
    },
    m(r, i) {
      j(r, l, i), q(l, s), a[e].m(s, null), u = !0, c || (m = w(o = /*styleable*/
      n[3].call(
        null,
        l,
        /*$component*/
        n[2].styles
      )), c = !0);
    },
    p(r, [i]) {
      let d = e;
      e = b(r), e === d ? a[e].p(r, i) : ($(), _(a[d], 1, 1, () => {
        a[d] = null;
      }), z(), t = a[e], t ? t.p(r, i) : (t = a[e] = f[e](r), t.c()), p(t, 1), t.m(s, null)), (!u || i & /*labelPosition*/
      1) && y(
        s,
        "spectrum-Form--labelsAbove",
        /*labelPosition*/
        r[0] === "above"
      ), o && H(o.update) && i & /*$component*/
      4 && o.update.call(
        null,
        /*$component*/
        r[2].styles
      );
    },
    i(r) {
      u || (p(t), u = !0);
    },
    o(r) {
      _(t), u = !1;
    },
    d(r) {
      r && J(l), a[e].d(), c = !1, m();
    }
  };
}
function R(n, l, s) {
  let e, { $$slots: t = {}, $$scope: o } = l, { labelPosition: u = "above" } = l, { type: c = "oneColumn" } = l;
  const { styleable: m } = k("sdk"), f = k("component");
  return B(n, f, (a) => s(2, e = a)), D("field-group", { labelPosition: u }), n.$$set = (a) => {
    "labelPosition" in a && s(0, u = a.labelPosition), "type" in a && s(1, c = a.type), "$$scope" in a && s(6, o = a.$$scope);
  }, [u, c, e, m, f, t, o];
}
class W extends A {
  constructor(l) {
    super(), G(this, l, R, Q, S, { labelPosition: 0, type: 1 });
  }
}
export {
  W as default
};
