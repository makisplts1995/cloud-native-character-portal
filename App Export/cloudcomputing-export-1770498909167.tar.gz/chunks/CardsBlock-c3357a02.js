import { S as Le, i as Ue, s as Pe, y as M, f as p, k as s, z as R, n as m, A as T, o as w, u as V, K as Ae, c as _, m as g, p as k, M as h, ac as j, ai as q, aj as G, aT as ae, cc as A, a as K, N as fe, ce as Me, cf as Oe } from "./index-e79f0bb2.js";
import { e as ye, a as Ne } from "./blocks-74fe5821.js";
function ue(i, e, o) {
  const t = i.slice();
  return t[46] = e[o], t[48] = o, t;
}
function ce(i) {
  let e, o;
  return e = new Ae({
    props: {
      $$slots: { default: [We] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      _(e.$$.fragment);
    },
    m(t, l) {
      g(e, t, l), o = !0;
    },
    p(t, l) {
      const n = {};
      l[0] & /*dataSource, formId, enrichedFilter, sortColumn, sortOrder, paginate, limit, autoRefresh, dataProviderId, noRowsMessage, cardWidth, repeaterId, cardTitle, cardSubtitle, cardDescription, cardImageURL, cardHorizontal, showCardButton, cardButtonText, cardButtonOnClick, fullCardURL, cardPeek, titleButtonAction, titleButtonText, enrichedSearchColumns, showTitleButton, title*/
      260046847 | l[1] & /*$$scope*/
      262144 && (n.$$scope = { dirty: l, ctx: t }), e.$set(n);
    },
    i(t) {
      o || (s(e.$$.fragment, t), o = !0);
    },
    o(t) {
      m(e.$$.fragment, t), o = !1;
    },
    d(t) {
      k(e, t);
    }
  };
}
function se(i) {
  let e, o;
  return e = new h({
    props: {
      type: "container",
      props: {
        direction: "row",
        hAlign: "stretch",
        vAlign: "middle",
        gap: "M",
        wrap: !0
      },
      styles: { normal: { "margin-bottom": "20px" } },
      order: 0,
      $$slots: { default: [ze] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      _(e.$$.fragment);
    },
    m(t, l) {
      g(e, t, l), o = !0;
    },
    p(t, l) {
      const n = {};
      l[0] & /*titleButtonAction, titleButtonText, enrichedSearchColumns, showTitleButton, title*/
      18874561 | l[1] & /*$$scope*/
      262144 && (n.$$scope = { dirty: l, ctx: t }), e.$set(n);
    },
    i(t) {
      o || (s(e.$$.fragment, t), o = !0);
    },
    o(t) {
      m(e.$$.fragment, t), o = !1;
    },
    d(t) {
      k(e, t);
    }
  };
}
function me(i) {
  let e = [], o = /* @__PURE__ */ new Map(), t, l, n = fe(
    /*enrichedSearchColumns*/
    i[21]
  );
  const f = (r) => (
    /*column*/
    r[46].name
  );
  for (let r = 0; r < n.length; r += 1) {
    let u = ue(i, n, r), c = f(u);
    o.set(c, e[r] = de(c, u));
  }
  return {
    c() {
      for (let r = 0; r < e.length; r += 1)
        e[r].c();
      t = M();
    },
    m(r, u) {
      for (let c = 0; c < e.length; c += 1)
        e[c] && e[c].m(r, u);
      p(r, t, u), l = !0;
    },
    p(r, u) {
      u[0] & /*enrichedSearchColumns*/
      2097152 && (n = fe(
        /*enrichedSearchColumns*/
        r[21]
      ), R(), e = Me(e, u, f, 1, r, n, o, t.parentNode, Oe, de, t, ue), T());
    },
    i(r) {
      if (!l) {
        for (let u = 0; u < n.length; u += 1)
          s(e[u]);
        l = !0;
      }
    },
    o(r) {
      for (let u = 0; u < e.length; u += 1)
        m(e[u]);
      l = !1;
    },
    d(r) {
      r && w(t);
      for (let u = 0; u < e.length; u += 1)
        e[u].d(r);
    }
  };
}
function de(i, e) {
  let o, t, l;
  return t = new h({
    props: {
      type: (
        /*column*/
        e[46].componentType
      ),
      props: {
        field: (
          /*column*/
          e[46].name
        ),
        placeholder: (
          /*column*/
          e[46].name
        ),
        text: (
          /*column*/
          e[46].name
        ),
        autoWidth: !0
      },
      order: (
        /*idx*/
        e[48]
      ),
      styles: { normal: { width: "192px" } }
    }
  }), {
    key: i,
    first: null,
    c() {
      o = M(), _(t.$$.fragment), this.first = o;
    },
    m(n, f) {
      p(n, o, f), g(t, n, f), l = !0;
    },
    p(n, f) {
      e = n;
      const r = {};
      f[0] & /*enrichedSearchColumns*/
      2097152 && (r.type = /*column*/
      e[46].componentType), f[0] & /*enrichedSearchColumns*/
      2097152 && (r.props = {
        field: (
          /*column*/
          e[46].name
        ),
        placeholder: (
          /*column*/
          e[46].name
        ),
        text: (
          /*column*/
          e[46].name
        ),
        autoWidth: !0
      }), f[0] & /*enrichedSearchColumns*/
      2097152 && (r.order = /*idx*/
      e[48]), t.$set(r);
    },
    i(n) {
      l || (s(t.$$.fragment, n), l = !0);
    },
    o(n) {
      m(t.$$.fragment, n), l = !1;
    },
    d(n) {
      n && w(o), k(t, n);
    }
  };
}
function _e(i) {
  var t;
  let e, o;
  return e = new h({
    props: {
      type: "button",
      props: {
        onClick: (
          /*titleButtonAction*/
          i[24]
        ),
        text: (
          /*titleButtonText*/
          i[7]
        ),
        type: "cta"
      },
      order: (
        /*enrichedSearchColumns*/
        ((t = i[21]) == null ? void 0 : t.length) ?? 0
      )
    }
  }), {
    c() {
      _(e.$$.fragment);
    },
    m(l, n) {
      g(e, l, n), o = !0;
    },
    p(l, n) {
      var r;
      const f = {};
      n[0] & /*titleButtonAction, titleButtonText*/
      16777344 && (f.props = {
        onClick: (
          /*titleButtonAction*/
          l[24]
        ),
        text: (
          /*titleButtonText*/
          l[7]
        ),
        type: "cta"
      }), n[0] & /*enrichedSearchColumns*/
      2097152 && (f.order = /*enrichedSearchColumns*/
      ((r = l[21]) == null ? void 0 : r.length) ?? 0), e.$set(f);
    },
    i(l) {
      o || (s(e.$$.fragment, l), o = !0);
    },
    o(l) {
      m(e.$$.fragment, l), o = !1;
    },
    d(l) {
      k(e, l);
    }
  };
}
function De(i) {
  var f;
  let e, o, t, l = (
    /*enrichedSearchColumns*/
    ((f = i[21]) == null ? void 0 : f.length) && me(i)
  ), n = (
    /*showTitleButton*/
    i[6] && _e(i)
  );
  return {
    c() {
      l && l.c(), e = K(), n && n.c(), o = M();
    },
    m(r, u) {
      l && l.m(r, u), p(r, e, u), n && n.m(r, u), p(r, o, u), t = !0;
    },
    p(r, u) {
      var c;
      /*enrichedSearchColumns*/
      (c = r[21]) != null && c.length ? l ? (l.p(r, u), u[0] & /*enrichedSearchColumns*/
      2097152 && s(l, 1)) : (l = me(r), l.c(), s(l, 1), l.m(e.parentNode, e)) : l && (R(), m(l, 1, 1, () => {
        l = null;
      }), T()), /*showTitleButton*/
      r[6] ? n ? (n.p(r, u), u[0] & /*showTitleButton*/
      64 && s(n, 1)) : (n = _e(r), n.c(), s(n, 1), n.m(o.parentNode, o)) : n && (R(), m(n, 1, 1, () => {
        n = null;
      }), T());
    },
    i(r) {
      t || (s(l), s(n), t = !0);
    },
    o(r) {
      m(l), m(n), t = !1;
    },
    d(r) {
      r && (w(e), w(o)), l && l.d(r), n && n.d(r);
    }
  };
}
function ze(i) {
  let e, o, t, l;
  return e = new h({
    props: {
      type: "textv2",
      props: {
        text: (
          /*title*/
          i[0] ? `## ${/*title*/
          i[0]}` : ""
        )
      },
      order: 0
    }
  }), t = new h({
    props: {
      type: "container",
      props: {
        direction: "row",
        hAlign: "left",
        vAlign: "middle",
        gap: "M",
        wrap: !0
      },
      order: 1,
      $$slots: { default: [De] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      _(e.$$.fragment), o = K(), _(t.$$.fragment);
    },
    m(n, f) {
      g(e, n, f), p(n, o, f), g(t, n, f), l = !0;
    },
    p(n, f) {
      const r = {};
      f[0] & /*title*/
      1 && (r.props = {
        text: (
          /*title*/
          n[0] ? `## ${/*title*/
          n[0]}` : ""
        )
      }), e.$set(r);
      const u = {};
      f[0] & /*titleButtonAction, titleButtonText, enrichedSearchColumns, showTitleButton*/
      18874560 | f[1] & /*$$scope*/
      262144 && (u.$$scope = { dirty: f, ctx: n }), t.$set(u);
    },
    i(n) {
      l || (s(e.$$.fragment, n), s(t.$$.fragment, n), l = !0);
    },
    o(n) {
      m(e.$$.fragment, n), m(t.$$.fragment, n), l = !1;
    },
    d(n) {
      n && w(o), k(e, n), k(t, n);
    }
  };
}
function Ie(i) {
  let e, o;
  return e = new h({
    props: {
      type: "spectrumcard",
      props: {
        title: (
          /*cardTitle*/
          i[8]
        ),
        subtitle: (
          /*cardSubtitle*/
          i[9]
        ),
        description: (
          /*cardDescription*/
          i[10]
        ),
        imageURL: (
          /*cardImageURL*/
          i[11]
        ),
        horizontal: (
          /*cardHorizontal*/
          i[13]
        ),
        showButton: (
          /*showCardButton*/
          i[14]
        ),
        buttonText: (
          /*cardButtonText*/
          i[15]
        ),
        buttonOnClick: (
          /*cardButtonOnClick*/
          i[16]
        ),
        linkURL: (
          /*fullCardURL*/
          i[25]
        ),
        linkPeek: (
          /*cardPeek*/
          i[12]
        )
      },
      styles: { normal: { width: "auto" } },
      order: 0
    }
  }), {
    c() {
      _(e.$$.fragment);
    },
    m(t, l) {
      g(e, t, l), o = !0;
    },
    p(t, l) {
      const n = {};
      l[0] & /*cardTitle, cardSubtitle, cardDescription, cardImageURL, cardHorizontal, showCardButton, cardButtonText, cardButtonOnClick, fullCardURL, cardPeek*/
      33685248 && (n.props = {
        title: (
          /*cardTitle*/
          t[8]
        ),
        subtitle: (
          /*cardSubtitle*/
          t[9]
        ),
        description: (
          /*cardDescription*/
          t[10]
        ),
        imageURL: (
          /*cardImageURL*/
          t[11]
        ),
        horizontal: (
          /*cardHorizontal*/
          t[13]
        ),
        showButton: (
          /*showCardButton*/
          t[14]
        ),
        buttonText: (
          /*cardButtonText*/
          t[15]
        ),
        buttonOnClick: (
          /*cardButtonOnClick*/
          t[16]
        ),
        linkURL: (
          /*fullCardURL*/
          t[25]
        ),
        linkPeek: (
          /*cardPeek*/
          t[12]
        )
      }), e.$set(n);
    },
    i(t) {
      o || (s(e.$$.fragment, t), o = !0);
    },
    o(t) {
      m(e.$$.fragment, t), o = !1;
    },
    d(t) {
      k(e, t);
    }
  };
}
function He(i) {
  let e, o, t;
  function l(f) {
    i[37](f);
  }
  let n = {
    type: "repeater",
    context: "repeater",
    props: {
      dataProvider: `{{ literal ${A(
        /*dataProviderId*/
        i[22]
      )} }}`,
      direction: "row",
      hAlign: "stretch",
      vAlign: "top",
      gap: "M",
      noRowsMessage: (
        /*noRowsMessage*/
        i[17] || "No rows found"
      )
    },
    styles: {
      custom: `display: grid;
grid-template-columns: repeat(auto-fill, minmax(min(${/*cardWidth*/
      i[26]}px, 100%), 1fr));`
    },
    order: 0,
    $$slots: { default: [Ie] },
    $$scope: { ctx: i }
  };
  return (
    /*repeaterId*/
    i[20] !== void 0 && (n.id = /*repeaterId*/
    i[20]), e = new h({ props: n }), j.push(() => q(e, "id", l)), {
      c() {
        _(e.$$.fragment);
      },
      m(f, r) {
        g(e, f, r), t = !0;
      },
      p(f, r) {
        const u = {};
        r[0] & /*dataProviderId, noRowsMessage*/
        4325376 && (u.props = {
          dataProvider: `{{ literal ${A(
            /*dataProviderId*/
            f[22]
          )} }}`,
          direction: "row",
          hAlign: "stretch",
          vAlign: "top",
          gap: "M",
          noRowsMessage: (
            /*noRowsMessage*/
            f[17] || "No rows found"
          )
        }), r[0] & /*cardWidth*/
        67108864 && (u.styles = {
          custom: `display: grid;
grid-template-columns: repeat(auto-fill, minmax(min(${/*cardWidth*/
          f[26]}px, 100%), 1fr));`
        }), r[0] & /*cardTitle, cardSubtitle, cardDescription, cardImageURL, cardHorizontal, showCardButton, cardButtonText, cardButtonOnClick, fullCardURL, cardPeek*/
        33685248 | r[1] & /*$$scope*/
        262144 && (u.$$scope = { dirty: r, ctx: f }), !o && r[0] & /*repeaterId*/
        1048576 && (o = !0, u.id = /*repeaterId*/
        f[20], G(() => o = !1)), e.$set(u);
      },
      i(f) {
        t || (s(e.$$.fragment, f), t = !0);
      },
      o(f) {
        m(e.$$.fragment, f), t = !1;
      },
      d(f) {
        k(e, f);
      }
    }
  );
}
function Fe(i) {
  var u;
  let e, o, t, l, n = (
    /*title*/
    (i[0] || /*enrichedSearchColumns*/
    ((u = i[21]) == null ? void 0 : u.length) || /*showTitleButton*/
    i[6]) && se(i)
  );
  function f(c) {
    i[38](c);
  }
  let r = {
    type: "dataprovider",
    props: {
      dataSource: (
        /*dataSource*/
        i[1]
      ),
      filter: (
        /*enrichedFilter*/
        i[27]
      ),
      sortColumn: (
        /*sortColumn*/
        i[2]
      ),
      sortOrder: (
        /*sortOrder*/
        i[3]
      ),
      paginate: (
        /*paginate*/
        i[4]
      ),
      limit: (
        /*limit*/
        i[5]
      ),
      autoRefresh: (
        /*autoRefresh*/
        i[18]
      )
    },
    order: 1,
    $$slots: { default: [He] },
    $$scope: { ctx: i }
  };
  return (
    /*dataProviderId*/
    i[22] !== void 0 && (r.id = /*dataProviderId*/
    i[22]), o = new h({ props: r }), j.push(() => q(o, "id", f)), {
      c() {
        n && n.c(), e = K(), _(o.$$.fragment);
      },
      m(c, d) {
        n && n.m(c, d), p(c, e, d), g(o, c, d), l = !0;
      },
      p(c, d) {
        var C;
        /*title*/
        c[0] || /*enrichedSearchColumns*/
        (C = c[21]) != null && C.length || /*showTitleButton*/
        c[6] ? n ? (n.p(c, d), d[0] & /*title, enrichedSearchColumns, showTitleButton*/
        2097217 && s(n, 1)) : (n = se(c), n.c(), s(n, 1), n.m(e.parentNode, e)) : n && (R(), m(n, 1, 1, () => {
          n = null;
        }), T());
        const b = {};
        d[0] & /*dataSource, enrichedFilter, sortColumn, sortOrder, paginate, limit, autoRefresh*/
        134479934 && (b.props = {
          dataSource: (
            /*dataSource*/
            c[1]
          ),
          filter: (
            /*enrichedFilter*/
            c[27]
          ),
          sortColumn: (
            /*sortColumn*/
            c[2]
          ),
          sortOrder: (
            /*sortOrder*/
            c[3]
          ),
          paginate: (
            /*paginate*/
            c[4]
          ),
          limit: (
            /*limit*/
            c[5]
          ),
          autoRefresh: (
            /*autoRefresh*/
            c[18]
          )
        }), d[0] & /*dataProviderId, noRowsMessage, cardWidth, repeaterId, cardTitle, cardSubtitle, cardDescription, cardImageURL, cardHorizontal, showCardButton, cardButtonText, cardButtonOnClick, fullCardURL, cardPeek*/
        106168064 | d[1] & /*$$scope*/
        262144 && (b.$$scope = { dirty: d, ctx: c }), !t && d[0] & /*dataProviderId*/
        4194304 && (t = !0, b.id = /*dataProviderId*/
        c[22], G(() => t = !1)), o.$set(b);
      },
      i(c) {
        l || (s(n), s(o.$$.fragment, c), l = !0);
      },
      o(c) {
        m(n), m(o.$$.fragment, c), l = !1;
      },
      d(c) {
        c && w(e), n && n.d(c), k(o, c);
      }
    }
  );
}
function We(i) {
  let e, o, t;
  function l(f) {
    i[39](f);
  }
  let n = {
    type: "form",
    props: {
      dataSource: (
        /*dataSource*/
        i[1]
      ),
      disableSchemaValidation: !0
    },
    $$slots: { default: [Fe] },
    $$scope: { ctx: i }
  };
  return (
    /*formId*/
    i[19] !== void 0 && (n.id = /*formId*/
    i[19]), e = new h({ props: n }), j.push(() => q(e, "id", l)), {
      c() {
        _(e.$$.fragment);
      },
      m(f, r) {
        g(e, f, r), t = !0;
      },
      p(f, r) {
        const u = {};
        r[0] & /*dataSource*/
        2 && (u.props = {
          dataSource: (
            /*dataSource*/
            f[1]
          ),
          disableSchemaValidation: !0
        }), r[0] & /*dataSource, enrichedFilter, sortColumn, sortOrder, paginate, limit, autoRefresh, dataProviderId, noRowsMessage, cardWidth, repeaterId, cardTitle, cardSubtitle, cardDescription, cardImageURL, cardHorizontal, showCardButton, cardButtonText, cardButtonOnClick, fullCardURL, cardPeek, titleButtonAction, titleButtonText, enrichedSearchColumns, showTitleButton, title*/
        259522559 | r[1] & /*$$scope*/
        262144 && (u.$$scope = { dirty: r, ctx: f }), !o && r[0] & /*formId*/
        524288 && (o = !0, u.id = /*formId*/
        f[19], G(() => o = !1)), e.$set(u);
      },
      i(f) {
        t || (s(e.$$.fragment, f), t = !0);
      },
      o(f) {
        m(e.$$.fragment, f), t = !1;
      },
      d(f) {
        k(e, f);
      }
    }
  );
}
function Ve(i) {
  let e, o, t = (
    /*schemaLoaded*/
    i[23] && ce(i)
  );
  return {
    c() {
      t && t.c(), e = M();
    },
    m(l, n) {
      t && t.m(l, n), p(l, e, n), o = !0;
    },
    p(l, n) {
      /*schemaLoaded*/
      l[23] ? t ? (t.p(l, n), n[0] & /*schemaLoaded*/
      8388608 && s(t, 1)) : (t = ce(l), t.c(), s(t, 1), t.m(e.parentNode, e)) : t && (R(), m(t, 1, 1, () => {
        t = null;
      }), T());
    },
    i(l) {
      o || (s(t), o = !0);
    },
    o(l) {
      m(t), o = !1;
    },
    d(l) {
      l && w(e), t && t.d(l);
    }
  };
}
function je(i, e, o) {
  let t, l, n, f, { title: r } = e, { dataSource: u } = e, { searchColumns: c } = e, { filter: d } = e, { sortColumn: b } = e, { sortOrder: C } = e, { paginate: E } = e, { limit: J } = e, { showTitleButton: Q } = e, { titleButtonText: X } = e, { titleButtonURL: O } = e, { titleButtonPeek: y } = e, { cardTitle: Y } = e, { cardSubtitle: Z } = e, { cardDescription: v } = e, { cardImageURL: x } = e, { linkCardTitle: N } = e, { cardURL: D } = e, { cardPeek: $ } = e, { cardHorizontal: z } = e, { showCardButton: ee } = e, { cardButtonText: te } = e, { cardButtonOnClick: ne } = e, { linkColumn: I } = e, { noRowsMessage: oe } = e, { autoRefresh: le } = e;
  const ge = V("context"), { fetchDatasourceSchema: ke, generateGoldenSample: he } = V("sdk"), be = V("component");
  let S, L, U, H, F, ie = !1;
  const pe = () => {
    var P;
    const a = ((P = ae(ge)[L]) == null ? void 0 : P.rows) || [], B = he(a);
    return { [`${ae(be).id}-repeater`]: B };
  }, we = (a, B, W, P) => {
    if (!a || !B || !W)
      return null;
    const Se = P || "_id", re = B.split("/:");
    return re.length > 1 ? `${re[0]}/{{ ${A(W)}.${A(Se)} }}` : B;
  }, Ce = async (a) => {
    a && o(36, H = await ke(a, { enrichRelationships: !0 })), o(23, ie = !0);
  };
  function Be(a) {
    U = a, o(20, U);
  }
  function Re(a) {
    L = a, o(22, L);
  }
  function Te(a) {
    S = a, o(19, S);
  }
  return i.$$set = (a) => {
    "title" in a && o(0, r = a.title), "dataSource" in a && o(1, u = a.dataSource), "searchColumns" in a && o(28, c = a.searchColumns), "filter" in a && o(29, d = a.filter), "sortColumn" in a && o(2, b = a.sortColumn), "sortOrder" in a && o(3, C = a.sortOrder), "paginate" in a && o(4, E = a.paginate), "limit" in a && o(5, J = a.limit), "showTitleButton" in a && o(6, Q = a.showTitleButton), "titleButtonText" in a && o(7, X = a.titleButtonText), "titleButtonURL" in a && o(30, O = a.titleButtonURL), "titleButtonPeek" in a && o(31, y = a.titleButtonPeek), "cardTitle" in a && o(8, Y = a.cardTitle), "cardSubtitle" in a && o(9, Z = a.cardSubtitle), "cardDescription" in a && o(10, v = a.cardDescription), "cardImageURL" in a && o(11, x = a.cardImageURL), "linkCardTitle" in a && o(32, N = a.linkCardTitle), "cardURL" in a && o(33, D = a.cardURL), "cardPeek" in a && o(12, $ = a.cardPeek), "cardHorizontal" in a && o(13, z = a.cardHorizontal), "showCardButton" in a && o(14, ee = a.showCardButton), "cardButtonText" in a && o(15, te = a.cardButtonText), "cardButtonOnClick" in a && o(16, ne = a.cardButtonOnClick), "linkColumn" in a && o(34, I = a.linkColumn), "noRowsMessage" in a && o(17, oe = a.noRowsMessage), "autoRefresh" in a && o(18, le = a.autoRefresh);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*dataSource*/
    2 && Ce(u), i.$$.dirty[0] & /*searchColumns*/
    268435456 | i.$$.dirty[1] & /*schema*/
    32 && ye(c, H).then((a) => o(21, F = a)), i.$$.dirty[0] & /*filter, enrichedSearchColumns, formId*/
    539492352 && o(27, t = Ne(d, F, S)), i.$$.dirty[0] & /*cardHorizontal*/
    8192 && o(26, l = z ? 420 : 300), i.$$.dirty[0] & /*repeaterId*/
    1048576 | i.$$.dirty[1] & /*linkCardTitle, cardURL, linkColumn*/
    14 && o(25, n = we(N, D, U, I)), i.$$.dirty[0] & /*titleButtonURL*/
    1073741824 | i.$$.dirty[1] & /*titleButtonPeek*/
    1 && o(24, f = [
      {
        "##eventHandlerType": "Navigate To",
        parameters: {
          peek: y,
          url: O
        }
      }
    ]);
  }, [
    r,
    u,
    b,
    C,
    E,
    J,
    Q,
    X,
    Y,
    Z,
    v,
    x,
    $,
    z,
    ee,
    te,
    ne,
    oe,
    le,
    S,
    U,
    F,
    L,
    ie,
    f,
    n,
    l,
    t,
    c,
    d,
    O,
    y,
    N,
    D,
    I,
    pe,
    H,
    Be,
    Re,
    Te
  ];
}
class Ke extends Le {
  constructor(e) {
    super(), Ue(
      this,
      e,
      je,
      Ve,
      Pe,
      {
        title: 0,
        dataSource: 1,
        searchColumns: 28,
        filter: 29,
        sortColumn: 2,
        sortOrder: 3,
        paginate: 4,
        limit: 5,
        showTitleButton: 6,
        titleButtonText: 7,
        titleButtonURL: 30,
        titleButtonPeek: 31,
        cardTitle: 8,
        cardSubtitle: 9,
        cardDescription: 10,
        cardImageURL: 11,
        linkCardTitle: 32,
        cardURL: 33,
        cardPeek: 12,
        cardHorizontal: 13,
        showCardButton: 14,
        cardButtonText: 15,
        cardButtonOnClick: 16,
        linkColumn: 34,
        noRowsMessage: 17,
        autoRefresh: 18,
        getAdditionalDataContext: 35
      },
      null,
      [-1, -1]
    );
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[35];
  }
}
export {
  Ke as default
};
