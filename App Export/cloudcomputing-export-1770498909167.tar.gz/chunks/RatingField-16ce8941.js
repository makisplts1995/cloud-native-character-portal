import { S as ne, i as ie, s as ae, b2 as oe, ac as M, ai as L, c as q, m as D, aj as V, k as p, n as R, p as G, N as I, e as B, b as A, f as H, z as re, A as te, o as T, O as fe, I as se, a as ue, d as w, aD as N, g as P, l as k, h as z, r as de } from "./index-e79f0bb2.js";
import { F as _e } from "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function X(e, l, i) {
  const f = e.slice();
  return f[31] = l[i], f[33] = i, f;
}
function j(e) {
  var _;
  let l, i, f, a, u, o, s;
  f = new se({
    props: {
      name: (
        /*type*/
        e[6]
      ),
      size: (
        /*size*/
        e[5]
      ),
      color: (
        /*ratingColour*/
        e[14]
      ),
      weight: (
        /*isRated*/
        e[16](
          /*hoverRating*/
          e[9],
          /*i*/
          e[33]
        ) || /*isRated*/
        e[16](
          /*fieldState*/
          (_ = e[8]) == null ? void 0 : _.value,
          /*i*/
          e[33]
        ) ? "fill" : "regular"
      )
    }
  });
  function r() {
    return (
      /*mouseover_handler*/
      e[20](
        /*i*/
        e[33]
      )
    );
  }
  function h() {
    return (
      /*focus_handler*/
      e[22](
        /*i*/
        e[33]
      )
    );
  }
  function t(...g) {
    return (
      /*keydown_handler*/
      e[24](
        /*i*/
        e[33],
        ...g
      )
    );
  }
  function d() {
    return (
      /*click_handler*/
      e[25](
        /*i*/
        e[33]
      )
    );
  }
  return {
    c() {
      var g, m;
      l = B("button"), i = B("div"), q(f.$$.fragment), a = ue(), A(i, "class", "icon-container svelte-1sxxz0v"), w(
        i,
        "hover-preview",
        /*isRated*/
        e[16](
          /*hoverRating*/
          e[9],
          /*i*/
          e[33]
        ) && !/*isRated*/
        e[16](
          /*fieldState*/
          (g = e[8]) == null ? void 0 : g.value,
          /*i*/
          e[33]
        )
      ), A(l, "type", "button"), A(l, "class", "rating-icon-wrapper svelte-1sxxz0v"), N(l, "padding", "0 " + /*spacing*/
      e[13] + "px"), w(
        l,
        "disabled",
        /*fieldState*/
        (m = e[8]) == null ? void 0 : m.disabled
      );
    },
    m(g, m) {
      H(g, l, m), P(l, i), D(f, i, null), P(l, a), u = !0, o || (s = [
        k(l, "mouseover", function() {
          z(
            /*enabled*/
            e[12] ? r : null
          ) && /*enabled*/
          (e[12] ? r : null).apply(this, arguments);
        }),
        k(l, "mouseleave", function() {
          z(
            /*enabled*/
            e[12] ? (
              /*mouseleave_handler*/
              e[21]
            ) : null
          ) && /*enabled*/
          (e[12] ? (
            /*mouseleave_handler*/
            e[21]
          ) : null).apply(this, arguments);
        }),
        k(l, "focus", function() {
          z(
            /*enabled*/
            e[12] ? h : null
          ) && /*enabled*/
          (e[12] ? h : null).apply(this, arguments);
        }),
        k(l, "blur", function() {
          z(
            /*enabled*/
            e[12] ? (
              /*blur_handler*/
              e[23]
            ) : null
          ) && /*enabled*/
          (e[12] ? (
            /*blur_handler*/
            e[23]
          ) : null).apply(this, arguments);
        }),
        k(l, "keydown", t),
        k(l, "click", d)
      ], o = !0);
    },
    p(g, m) {
      var y, v, c;
      e = g;
      const b = {};
      m[0] & /*type*/
      64 && (b.name = /*type*/
      e[6]), m[0] & /*size*/
      32 && (b.size = /*size*/
      e[5]), m[0] & /*ratingColour*/
      16384 && (b.color = /*ratingColour*/
      e[14]), m[0] & /*hoverRating, fieldState*/
      768 && (b.weight = /*isRated*/
      e[16](
        /*hoverRating*/
        e[9],
        /*i*/
        e[33]
      ) || /*isRated*/
      e[16](
        /*fieldState*/
        (y = e[8]) == null ? void 0 : y.value,
        /*i*/
        e[33]
      ) ? "fill" : "regular"), f.$set(b), (!u || m[0] & /*isRated, hoverRating, fieldState*/
      66304) && w(
        i,
        "hover-preview",
        /*isRated*/
        e[16](
          /*hoverRating*/
          e[9],
          /*i*/
          e[33]
        ) && !/*isRated*/
        e[16](
          /*fieldState*/
          (v = e[8]) == null ? void 0 : v.value,
          /*i*/
          e[33]
        )
      ), (!u || m[0] & /*spacing*/
      8192) && N(l, "padding", "0 " + /*spacing*/
      e[13] + "px"), (!u || m[0] & /*fieldState*/
      256) && w(
        l,
        "disabled",
        /*fieldState*/
        (c = e[8]) == null ? void 0 : c.disabled
      );
    },
    i(g) {
      u || (p(f.$$.fragment, g), u = !0);
    },
    o(g) {
      R(f.$$.fragment, g), u = !1;
    },
    d(g) {
      g && T(l), G(f), o = !1, de(s);
    }
  };
}
function ge(e) {
  let l, i, f = I({ length: (
    /*numberOfStars*/
    e[4]
  ) }), a = [];
  for (let o = 0; o < f.length; o += 1)
    a[o] = j(X(e, f, o));
  const u = (o) => R(a[o], 1, 1, () => {
    a[o] = null;
  });
  return {
    c() {
      l = B("div");
      for (let o = 0; o < a.length; o += 1)
        a[o].c();
      A(l, "class", "rating-container svelte-1sxxz0v");
    },
    m(o, s) {
      H(o, l, s);
      for (let r = 0; r < a.length; r += 1)
        a[r] && a[r].m(l, null);
      i = !0;
    },
    p(o, s) {
      if (s[0] & /*spacing, fieldState, enabled, hoverRating, handleClick, isRated, type, size, ratingColour, numberOfStars*/
      127856) {
        f = I({ length: (
          /*numberOfStars*/
          o[4]
        ) });
        let r;
        for (r = 0; r < f.length; r += 1) {
          const h = X(o, f, r);
          a[r] ? (a[r].p(h, s), p(a[r], 1)) : (a[r] = j(h), a[r].c(), p(a[r], 1), a[r].m(l, null));
        }
        for (re(), r = f.length; r < a.length; r += 1)
          u(r);
        te();
      }
    },
    i(o) {
      if (!i) {
        for (let s = 0; s < f.length; s += 1)
          p(a[s]);
        i = !0;
      }
    },
    o(o) {
      a = a.filter(Boolean);
      for (let s = 0; s < a.length; s += 1)
        R(a[s]);
      i = !1;
    },
    d(o) {
      o && T(l), fe(a, o);
    }
  };
}
function me(e) {
  let l, i, f, a, u;
  function o(t) {
    e[26](t);
  }
  function s(t) {
    e[27](t);
  }
  function r(t) {
    e[28](t);
  }
  let h = {
    label: (
      /*label*/
      e[3]
    ),
    field: (
      /*field*/
      e[2]
    ),
    disabled: (
      /*disabled*/
      e[0]
    ),
    readonly: (
      /*readonly*/
      e[1]
    ),
    validation: (
      /*validation*/
      e[7]
    ),
    type: oe.NUMBER,
    defaultValue: "0",
    $$slots: { default: [ge] },
    $$scope: { ctx: e }
  };
  return (
    /*fieldState*/
    e[8] !== void 0 && (h.fieldState = /*fieldState*/
    e[8]), /*fieldApi*/
    e[10] !== void 0 && (h.fieldApi = /*fieldApi*/
    e[10]), /*fieldSchema*/
    e[11] !== void 0 && (h.fieldSchema = /*fieldSchema*/
    e[11]), l = new _e({ props: h }), M.push(() => L(l, "fieldState", o)), M.push(() => L(l, "fieldApi", s)), M.push(() => L(l, "fieldSchema", r)), {
      c() {
        q(l.$$.fragment);
      },
      m(t, d) {
        D(l, t, d), u = !0;
      },
      p(t, d) {
        const _ = {};
        d[0] & /*label*/
        8 && (_.label = /*label*/
        t[3]), d[0] & /*field*/
        4 && (_.field = /*field*/
        t[2]), d[0] & /*disabled*/
        1 && (_.disabled = /*disabled*/
        t[0]), d[0] & /*readonly*/
        2 && (_.readonly = /*readonly*/
        t[1]), d[0] & /*validation*/
        128 && (_.validation = /*validation*/
        t[7]), d[0] & /*numberOfStars, spacing, fieldState, enabled, hoverRating, type, size, ratingColour*/
        29552 | d[1] & /*$$scope*/
        8 && (_.$$scope = { dirty: d, ctx: t }), !i && d[0] & /*fieldState*/
        256 && (i = !0, _.fieldState = /*fieldState*/
        t[8], V(() => i = !1)), !f && d[0] & /*fieldApi*/
        1024 && (f = !0, _.fieldApi = /*fieldApi*/
        t[10], V(() => f = !1)), !a && d[0] & /*fieldSchema*/
        2048 && (a = !0, _.fieldSchema = /*fieldSchema*/
        t[11], V(() => a = !1)), l.$set(_);
      },
      i(t) {
        u || (p(l.$$.fragment, t), u = !0);
      },
      o(t) {
        R(l.$$.fragment, t), u = !1;
      },
      d(t) {
        G(l, t);
      }
    }
  );
}
function he(e, l, i) {
  let f, a, u, { colour: o = "" } = l, { disabled: s = !1 } = l, { readonly: r = !1 } = l, { field: h } = l, { label: t } = l, { numberOfStars: d = 5 } = l, { size: _ = "L" } = l, { type: g = "star" } = l, { variant: m = "Primary" } = l, { validation: b } = l, { onChange: y } = l, v = null, c, S, F;
  const U = {
    Primary: "var(--primaryColor)",
    Secondary: "var(--primaryColorHover)",
    Mono: "var(--spectrum-global-color-gray-900)",
    Gold: "var(--spectrum-global-color-yellow-500)",
    Red: "var(--spectrum-global-color-red-500)",
    Custom: "var(--primaryColor)"
  }, E = { XS: 0.25, S: 0.5, M: 1, L: 1.5, XL: 2 }, O = (n) => {
    if (u) {
      const C = S == null ? void 0 : S.setValue(n);
      y && C && y({ value: n });
    }
  }, J = (n, C) => typeof n == "number" && n >= C + 1, K = (n) => i(9, v = n + 1), Q = () => i(9, v = null), W = (n) => i(9, v = n + 1), Y = () => i(9, v = null), Z = (n, C) => u && C.key === "Enter" && O(n + 1), x = (n) => O(n + 1);
  function $(n) {
    c = n, i(8, c);
  }
  function ee(n) {
    S = n, i(10, S);
  }
  function le(n) {
    F = n, i(11, F);
  }
  return e.$$set = (n) => {
    "colour" in n && i(17, o = n.colour), "disabled" in n && i(0, s = n.disabled), "readonly" in n && i(1, r = n.readonly), "field" in n && i(2, h = n.field), "label" in n && i(3, t = n.label), "numberOfStars" in n && i(4, d = n.numberOfStars), "size" in n && i(5, _ = n.size), "type" in n && i(6, g = n.type), "variant" in n && i(18, m = n.variant), "validation" in n && i(7, b = n.validation), "onChange" in n && i(19, y = n.onChange);
  }, e.$$.update = () => {
    e.$$.dirty[0] & /*variant, colour*/
    393216 && i(14, f = m === "Custom" && o ? o : U[m] || "var(--primaryColor)"), e.$$.dirty[0] & /*size*/
    32 && i(13, a = E[_] || E.M), e.$$.dirty[0] & /*fieldState*/
    256 && i(12, u = !(c != null && c.disabled) && !(c != null && c.readonly));
  }, [
    s,
    r,
    h,
    t,
    d,
    _,
    g,
    b,
    c,
    v,
    S,
    F,
    u,
    a,
    f,
    O,
    J,
    o,
    m,
    y,
    K,
    Q,
    W,
    Y,
    Z,
    x,
    $,
    ee,
    le
  ];
}
class Se extends ne {
  constructor(l) {
    super(), ie(
      this,
      l,
      he,
      me,
      ae,
      {
        colour: 17,
        disabled: 0,
        readonly: 1,
        field: 2,
        label: 3,
        numberOfStars: 4,
        size: 5,
        type: 6,
        variant: 18,
        validation: 7,
        onChange: 19
      },
      null,
      [-1, -1]
    );
  }
}
export {
  Se as default
};
