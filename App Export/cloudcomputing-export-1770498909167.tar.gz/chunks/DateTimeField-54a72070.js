import { S as B, i as E, s as G, ac as W, ai as y, c as N, m as F, aj as w, k as _, n as T, p as M, y as J, f as K, z as L, A as Q, o as R } from "./index-e79f0bb2.js";
import { D as U } from "./DatePicker-c2e8a5bb.js";
import { F as X } from "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function I(a) {
  let l, f;
  return l = new U({
    props: {
      value: (
        /*fieldState*/
        a[14].value
      ),
      disabled: (
        /*fieldState*/
        a[14].disabled
      ),
      readonly: (
        /*fieldState*/
        a[14].readonly
      ),
      error: (
        /*fieldState*/
        a[14].error
      ),
      id: (
        /*fieldState*/
        a[14].fieldId
      ),
      enableTime: (
        /*enableTime*/
        a[5]
      ),
      timeOnly: (
        /*timeOnly*/
        a[6]
      ),
      time24hr: (
        /*time24hr*/
        a[7]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        a[8]
      ),
      startDayOfWeek: (
        /*startDayOfWeek*/
        a[9]
      ),
      placeholder: (
        /*placeholder*/
        a[2]
      )
    }
  }), l.$on(
    "change",
    /*handleChange*/
    a[16]
  ), {
    c() {
      N(l.$$.fragment);
    },
    m(e, n) {
      F(l, e, n), f = !0;
    },
    p(e, n) {
      const d = {};
      n & /*fieldState*/
      16384 && (d.value = /*fieldState*/
      e[14].value), n & /*fieldState*/
      16384 && (d.disabled = /*fieldState*/
      e[14].disabled), n & /*fieldState*/
      16384 && (d.readonly = /*fieldState*/
      e[14].readonly), n & /*fieldState*/
      16384 && (d.error = /*fieldState*/
      e[14].error), n & /*fieldState*/
      16384 && (d.id = /*fieldState*/
      e[14].fieldId), n & /*enableTime*/
      32 && (d.enableTime = /*enableTime*/
      e[5]), n & /*timeOnly*/
      64 && (d.timeOnly = /*timeOnly*/
      e[6]), n & /*time24hr*/
      128 && (d.time24hr = /*time24hr*/
      e[7]), n & /*ignoreTimezones*/
      256 && (d.ignoreTimezones = /*ignoreTimezones*/
      e[8]), n & /*startDayOfWeek*/
      512 && (d.startDayOfWeek = /*startDayOfWeek*/
      e[9]), n & /*placeholder*/
      4 && (d.placeholder = /*placeholder*/
      e[2]), l.$set(d);
    },
    i(e) {
      f || (_(l.$$.fragment, e), f = !0);
    },
    o(e) {
      T(l.$$.fragment, e), f = !1;
    },
    d(e) {
      M(l, e);
    }
  };
}
function Y(a) {
  let l, f, e = (
    /*fieldState*/
    a[14] && I(a)
  );
  return {
    c() {
      e && e.c(), l = J();
    },
    m(n, d) {
      e && e.m(n, d), K(n, l, d), f = !0;
    },
    p(n, d) {
      /*fieldState*/
      n[14] ? e ? (e.p(n, d), d & /*fieldState*/
      16384 && _(e, 1)) : (e = I(n), e.c(), _(e, 1), e.m(l.parentNode, l)) : e && (L(), T(e, 1, 1, () => {
        e = null;
      }), Q());
    },
    i(n) {
      f || (_(e), f = !0);
    },
    o(n) {
      T(e), f = !1;
    },
    d(n) {
      n && R(l), e && e.d(n);
    }
  };
}
function Z(a) {
  let l, f, e, n;
  function d(t) {
    a[19](t);
  }
  function b(t) {
    a[20](t);
  }
  let m = {
    label: (
      /*label*/
      a[1]
    ),
    field: (
      /*field*/
      a[0]
    ),
    disabled: (
      /*disabled*/
      a[3]
    ),
    readonly: (
      /*readonly*/
      a[4]
    ),
    validation: (
      /*validation*/
      a[10]
    ),
    defaultValue: (
      /*defaultValue*/
      a[11]
    ),
    span: (
      /*span*/
      a[12]
    ),
    helpText: (
      /*helpText*/
      a[13]
    ),
    type: "datetime",
    $$slots: { default: [Y] },
    $$scope: { ctx: a }
  };
  return (
    /*fieldState*/
    a[14] !== void 0 && (m.fieldState = /*fieldState*/
    a[14]), /*fieldApi*/
    a[15] !== void 0 && (m.fieldApi = /*fieldApi*/
    a[15]), l = new X({ props: m }), W.push(() => y(l, "fieldState", d)), W.push(() => y(l, "fieldApi", b)), {
      c() {
        N(l.$$.fragment);
      },
      m(t, s) {
        F(l, t, s), n = !0;
      },
      p(t, [s]) {
        const u = {};
        s & /*label*/
        2 && (u.label = /*label*/
        t[1]), s & /*field*/
        1 && (u.field = /*field*/
        t[0]), s & /*disabled*/
        8 && (u.disabled = /*disabled*/
        t[3]), s & /*readonly*/
        16 && (u.readonly = /*readonly*/
        t[4]), s & /*validation*/
        1024 && (u.validation = /*validation*/
        t[10]), s & /*defaultValue*/
        2048 && (u.defaultValue = /*defaultValue*/
        t[11]), s & /*span*/
        4096 && (u.span = /*span*/
        t[12]), s & /*helpText*/
        8192 && (u.helpText = /*helpText*/
        t[13]), s & /*$$scope, fieldState, enableTime, timeOnly, time24hr, ignoreTimezones, startDayOfWeek, placeholder*/
        8405988 && (u.$$scope = { dirty: s, ctx: t }), !f && s & /*fieldState*/
        16384 && (f = !0, u.fieldState = /*fieldState*/
        t[14], w(() => f = !1)), !e && s & /*fieldApi*/
        32768 && (e = !0, u.fieldApi = /*fieldApi*/
        t[15], w(() => e = !1)), l.$set(u);
      },
      i(t) {
        n || (_(l.$$.fragment, t), n = !0);
      },
      o(t) {
        T(l.$$.fragment, t), n = !1;
      },
      d(t) {
        M(l, t);
      }
    }
  );
}
function p(a, l, f) {
  let { field: e } = l, { label: n } = l, { placeholder: d } = l, { disabled: b = !1 } = l, { readonly: m = !1 } = l, { enableTime: t = !0 } = l, { timeOnly: s = !1 } = l, { time24hr: u = !1 } = l, { ignoreTimezones: S = !1 } = l, { startDayOfWeek: D = "Monday" } = l, { validation: A } = l, { defaultValue: V } = l, { onChange: h } = l, { span: z } = l, { helpText: C = null } = l, { valueAsTimestamp: c = !1 } = l, k, g;
  const j = (i) => {
    let o = i.detail;
    s && c && (q(o) || (o = v(o)));
    const O = g.setValue(o);
    h && O && h({ value: o });
  }, q = (i) => !isNaN(new Date(i)), v = (i) => {
    let [o, O] = i.split(":").map(Number);
    const r = /* @__PURE__ */ new Date();
    return r.setHours(o), r.setMinutes(O), r.setSeconds(0), r.setMilliseconds(0), r.toISOString();
  };
  function H(i) {
    k = i, f(14, k);
  }
  function P(i) {
    g = i, f(15, g);
  }
  return a.$$set = (i) => {
    "field" in i && f(0, e = i.field), "label" in i && f(1, n = i.label), "placeholder" in i && f(2, d = i.placeholder), "disabled" in i && f(3, b = i.disabled), "readonly" in i && f(4, m = i.readonly), "enableTime" in i && f(5, t = i.enableTime), "timeOnly" in i && f(6, s = i.timeOnly), "time24hr" in i && f(7, u = i.time24hr), "ignoreTimezones" in i && f(8, S = i.ignoreTimezones), "startDayOfWeek" in i && f(9, D = i.startDayOfWeek), "validation" in i && f(10, A = i.validation), "defaultValue" in i && f(11, V = i.defaultValue), "onChange" in i && f(17, h = i.onChange), "span" in i && f(12, z = i.span), "helpText" in i && f(13, C = i.helpText), "valueAsTimestamp" in i && f(18, c = i.valueAsTimestamp);
  }, [
    e,
    n,
    d,
    b,
    m,
    t,
    s,
    u,
    S,
    D,
    A,
    V,
    z,
    C,
    k,
    g,
    j,
    h,
    c,
    H,
    P
  ];
}
class ae extends B {
  constructor(l) {
    super(), E(this, l, p, Z, G, {
      field: 0,
      label: 1,
      placeholder: 2,
      disabled: 3,
      readonly: 4,
      enableTime: 5,
      timeOnly: 6,
      time24hr: 7,
      ignoreTimezones: 8,
      startDayOfWeek: 9,
      validation: 10,
      defaultValue: 11,
      onChange: 17,
      span: 12,
      helpText: 13,
      valueAsTimestamp: 18
    });
  }
}
export {
  ae as default
};
