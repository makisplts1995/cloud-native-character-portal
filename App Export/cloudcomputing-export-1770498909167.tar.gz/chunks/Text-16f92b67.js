import { S as v, i as z, s as b, e as k, c as p, b as q, f as S, m as T, q as C, h as M, k as J, n as N, o as O, p as V, u as d, v as j } from "./index-e79f0bb2.js";
import { M as A } from "./MarkdownViewer-8bfac1b0.js";
function B(o) {
  let s, t, r, a, l, c;
  return t = new A({ props: { value: (
    /*safeText*/
    o[0]
  ) } }), {
    c() {
      s = k("div"), p(t.$$.fragment), q(s, "class", "svelte-rl4qpz");
    },
    m(n, i) {
      S(n, s, i), T(t, s, null), a = !0, l || (c = C(r = /*styleable*/
      o[3].call(
        null,
        s,
        /*styles*/
        o[1]
      )), l = !0);
    },
    p(n, [i]) {
      const u = {};
      i & /*safeText*/
      1 && (u.value = /*safeText*/
      n[0]), t.$set(u), r && M(r.update) && i & /*styles*/
      2 && r.update.call(
        null,
        /*styles*/
        n[1]
      );
    },
    i(n) {
      a || (J(t.$$.fragment, n), a = !0);
    },
    o(n) {
      N(t.$$.fragment, n), a = !1;
    },
    d(n) {
      n && O(s), V(t), l = !1, c();
    }
  };
}
function D(o, s, t) {
  let r, a, l, { text: c = "" } = s, { color: n = void 0 } = s, { align: i = "left" } = s, { size: u = "14px" } = s;
  const m = d("component");
  j(o, m, (e) => t(8, l = e));
  const { styleable: g } = d("sdk"), y = (e, f, x, h) => {
    let _ = {
      "text-align": x,
      "font-size": h || "14px"
    };
    return f && (_.color = f), {
      ...e,
      normal: { ...e.normal, ..._ }
    };
  }, w = (e) => {
    if (e == null)
      return "";
    if (typeof e != "string")
      try {
        return JSON.stringify(e);
      } catch {
        return "";
      }
    return e;
  };
  return o.$$set = (e) => {
    "text" in e && t(4, c = e.text), "color" in e && t(5, n = e.color), "align" in e && t(6, i = e.align), "size" in e && t(7, u = e.size);
  }, o.$$.update = () => {
    o.$$.dirty & /*$component, color, align, size*/
    480 && t(1, r = y(l.styles, n, i, u)), o.$$.dirty & /*text*/
    16 && t(0, a = w(c));
  }, [a, r, m, g, c, n, i, u, l];
}
class G extends v {
  constructor(s) {
    super(), z(this, s, D, B, b, { text: 4, color: 5, align: 6, size: 7 });
  }
}
export {
  G as default
};
