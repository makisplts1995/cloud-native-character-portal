import { S as M, i as P, s as Q, c as R, m as V, k as W, n as X, p as Y } from "./index-e79f0bb2.js";
import { A as v, p, f as Z } from "./ApexChart-fb0e9d4c.js";
function $(a) {
  let n, e;
  return n = new v({ props: { options: (
    /*options*/
    a[0]
  ) } }), {
    c() {
      R(n.$$.fragment);
    },
    m(i, m) {
      V(n, i, m), e = !0;
    },
    p(i, [m]) {
      const f = {};
      m & /*options*/
      1 && (f.options = /*options*/
      i[0]), n.$set(f);
    },
    i(i) {
      e || (W(n.$$.fragment, i), e = !0);
    },
    o(i) {
      X(n.$$.fragment, i), e = !1;
    },
    d(i) {
      Y(n, i);
    }
  };
}
function tt(a, n, e) {
  let i, m, f, L, w, j, { dataProvider: s } = n, { labelColumn: y } = n, { valueColumns: S } = n, { title: _ } = n, { xAxisLabel: k } = n, { yAxisLabel: F } = n, { height: r } = n, { width: h } = n, { dataLabels: z } = n, { animate: U } = n, { legend: D } = n, { stacked: B } = n, { yAxisUnits: A } = n, { palette: C } = n, { c1: I, c2: q, c3: N, c4: O, c5: T } = n, { horizontal: x } = n, { onClick: b } = n;
  function H(t) {
    b == null || b({ bar: t });
  }
  const J = (t, u = []) => {
    const o = t.rows ?? [];
    return u.map((l) => ({
      name: l,
      data: o.map((c) => {
        var d, G;
        const g = c == null ? void 0 : c[l];
        return ((G = (d = t == null ? void 0 : t.schema) == null ? void 0 : d[l]) == null ? void 0 : G.type) === "datetime" && g ? Date.parse(g) : g;
      })
    }));
  }, K = (t, u) => (t.rows ?? []).map((l) => {
    const c = l == null ? void 0 : l[u];
    return ["string", "number", "boolean"].includes(typeof c) ? c : "";
  }), E = (t, u, o, l) => {
    const c = l === "y" && o || l === "x" && !o;
    return t === "datetime" && c ? Z.Datetime : c ? Z.Default : Z[u];
  };
  return a.$$set = (t) => {
    "dataProvider" in t && e(1, s = t.dataProvider), "labelColumn" in t && e(2, y = t.labelColumn), "valueColumns" in t && e(3, S = t.valueColumns), "title" in t && e(4, _ = t.title), "xAxisLabel" in t && e(5, k = t.xAxisLabel), "yAxisLabel" in t && e(6, F = t.yAxisLabel), "height" in t && e(7, r = t.height), "width" in t && e(8, h = t.width), "dataLabels" in t && e(9, z = t.dataLabels), "animate" in t && e(10, U = t.animate), "legend" in t && e(11, D = t.legend), "stacked" in t && e(12, B = t.stacked), "yAxisUnits" in t && e(13, A = t.yAxisUnits), "palette" in t && e(14, C = t.palette), "c1" in t && e(15, I = t.c1), "c2" in t && e(16, q = t.c2), "c3" in t && e(17, N = t.c3), "c4" in t && e(18, O = t.c4), "c5" in t && e(19, T = t.c5), "horizontal" in t && e(20, x = t.horizontal), "onClick" in t && e(21, b = t.onClick);
  }, a.$$.update = () => {
    var t, u;
    a.$$.dirty & /*dataProvider, valueColumns*/
    10 && e(25, i = J(s, S)), a.$$.dirty & /*dataProvider, labelColumn*/
    6 && e(24, m = K(s, y)), a.$$.dirty & /*dataProvider, labelColumn*/
    6 && e(26, f = ((u = (t = s == null ? void 0 : s.schema) == null ? void 0 : t[y]) == null ? void 0 : u.type) === "datetime" ? "datetime" : "category"), a.$$.dirty & /*labelType, yAxisUnits, horizontal*/
    68165632 && e(23, L = E(f, A, x, "x")), a.$$.dirty & /*labelType, yAxisUnits, horizontal*/
    68165632 && e(22, w = E(f, A, x, "y")), a.$$.dirty & /*series, palette, c1, c2, c3, c4, c5, legend, title, dataLabels, height, width, stacked, animate, dataProvider, horizontal, categories, xAxisFormatter, xAxisLabel, yAxisFormatter, yAxisLabel*/
    65003506 && e(0, j = {
      series: i,
      colors: C === "Custom" ? [I, q, N, O, T] : [],
      theme: { palette: p(C) },
      legend: {
        show: D,
        position: "top",
        horizontalAlign: "right",
        showForSingleSeries: !0,
        showForNullSeries: !0,
        showForZeroSeries: !0
      },
      title: { text: _ },
      dataLabels: {
        enabled: z,
        dropShadow: { enabled: !0 }
      },
      chart: {
        height: r == null || r === "" ? "auto" : r,
        width: h == null || h === "" ? "100%" : h,
        type: "bar",
        stacked: B,
        animations: { enabled: U },
        toolbar: { show: !1 },
        zoom: { enabled: !1 },
        events: {
          // Clicking on a bar or group of bars
          dataPointSelection(o, l, c) {
            const g = c.dataPointIndex, d = s.rows[g];
            H(d);
          }
        }
      },
      plotOptions: { bar: { horizontal: x } },
      // We can just always provide the categories to the xaxis and horizontal mode automatically handles "tranposing" the categories to the yaxis, but certain things like labels need to be manually put on a certain axis based on the selected mode. Titles do not need to be handled this way, they are exposed to the user as "X axis" and Y Axis" so flipping them would be confusing.
      xaxis: {
        categories: m,
        labels: { formatter: L },
        title: { text: k }
      },
      // Providing `type: "datetime"` normally makes Apex Charts parse unix time nicely with no additonal config, but bar charts in horizontal mode don't have a default setting for parsing the labels of dates, and will just spit out the unix time value. It also doesn't seem to respect any date based formatting properties passed in. So we'll just manually format the labels, the chart still sorts the dates correctly in any case
      yaxis: {
        labels: { formatter: w },
        title: { text: F }
      }
    });
  }, [
    j,
    s,
    y,
    S,
    _,
    k,
    F,
    r,
    h,
    z,
    U,
    D,
    B,
    A,
    C,
    I,
    q,
    N,
    O,
    T,
    x,
    b,
    w,
    L,
    m,
    i,
    f
  ];
}
class it extends M {
  constructor(n) {
    super(), P(this, n, tt, $, Q, {
      dataProvider: 1,
      labelColumn: 2,
      valueColumns: 3,
      title: 4,
      xAxisLabel: 5,
      yAxisLabel: 6,
      height: 7,
      width: 8,
      dataLabels: 9,
      animate: 10,
      legend: 11,
      stacked: 12,
      yAxisUnits: 13,
      palette: 14,
      c1: 15,
      c2: 16,
      c3: 17,
      c4: 18,
      c5: 19,
      horizontal: 20,
      onClick: 21
    });
  }
}
export {
  it as default
};
