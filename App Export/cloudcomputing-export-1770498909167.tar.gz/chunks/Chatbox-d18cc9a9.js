import { S as K, i as X, s as q, c9 as w, b as a, f as F, g as _, B as M, o as L, N as B, e as k, a as V, bz as Q, l as Y, k as C, z as U, A as z, n as S, O as ce, r as _e, bI as de, ae as me, aa as ge, aZ as O, w as he, y as W, c as D, m as P, p as Z, ap as be, ac as x, t as j, j as H, v as ve, ca as ke } from "./index-e79f0bb2.js";
import { M as pe } from "./MarkdownViewer-8bfac1b0.js";
function $(s) {
  let e;
  return {
    c() {
      e = w("animateTransform"), a(e, "attributeName", "transform"), a(e, "attributeType", "XML"), a(e, "type", "rotate"), a(e, "from", "0 75 75"), a(e, "to", "360 75 75"), a(e, "dur", "2.5s"), a(e, "repeatCount", "indefinite"), a(e, "calcMode", "spline"), a(e, "keyTimes", "0;1"), a(e, "keySplines", "0.3 0 0.5 1");
    },
    m(t, n) {
      F(t, e, n);
    },
    d(t) {
      t && L(e);
    }
  };
}
function ye(s) {
  let e, t, n, l, i, o, r, f, p, c, u, d, g, m, h, v, T, E, G, b, y = (
    /*animate*/
    s[1] && $()
  );
  return {
    c() {
      e = w("svg"), t = w("g"), n = w("g"), y && y.c(), l = w("path"), i = w("path"), o = w("path"), r = w("path"), f = w("defs"), p = w("linearGradient"), c = w("stop"), u = w("stop"), d = w("linearGradient"), g = w("stop"), m = w("stop"), h = w("linearGradient"), v = w("stop"), T = w("stop"), E = w("linearGradient"), G = w("stop"), b = w("stop"), a(l, "id", "Vector"), a(l, "d", "M22.3457 95.0839L51.9032 124.642C53.199 125.937 55.2988 125.937 56.5946 124.642L69.4653 111.771C70.6236 110.612 71.171 108.976 70.9436 107.352L67.4872 82.9246C67.2334 81.1475 65.8371 79.7512 64.0626 79.4999L39.6354 76.0436C38.0143 75.8135 36.3774 76.3609 35.2164 77.5218L22.3457 90.3926C21.0499 91.6884 21.0499 93.7881 22.3457 95.0839Z"), a(l, "fill", "url(#paint0_linear_605_124)"), a(i, "id", "Vector_2"), a(i, "d", "M92.0381 124.643L121.596 95.0851C122.891 93.7893 122.891 91.6895 121.596 90.3937L108.725 77.5229C107.567 76.3647 105.93 75.8172 104.306 76.0447L79.8787 79.501C78.1016 79.7549 76.7053 81.1512 76.454 82.9257L72.9977 107.353C72.7676 108.974 73.315 110.611 74.4759 111.772L87.3467 124.643C88.6425 125.938 90.7422 125.938 92.0381 124.643Z"), a(i, "fill", "url(#paint1_linear_605_124)"), a(o, "id", "Vector_3"), a(o, "d", "M121.654 54.92L92.0968 25.3624C90.801 24.0666 88.7012 24.0666 87.4054 25.3624L74.5347 38.2332C73.3764 39.3915 72.829 41.0284 73.0564 42.6521L76.5128 67.0793C76.7666 68.8565 78.1629 70.2527 79.9374 70.504L104.365 73.9603C105.986 74.1904 107.623 73.643 108.784 72.4821L121.654 59.6113C122.95 58.3155 122.95 56.2158 121.654 54.92Z"), a(o, "fill", "url(#paint2_linear_605_124)"), a(r, "id", "Vector_4"), a(r, "d", "M51.9619 25.3613L22.4044 54.9188C21.1086 56.2146 21.1086 58.3144 22.4044 59.6102L35.2752 72.481C36.4334 73.6393 38.0704 74.1867 39.6941 73.9592L64.1213 70.5029C65.8984 70.249 67.2947 68.8527 67.546 67.0782L71.0023 42.651C71.2324 41.0299 70.685 39.393 69.5241 38.2321L56.6533 25.3613C55.3575 24.0655 53.2578 24.0655 51.9619 25.3613Z"), a(r, "fill", "url(#paint3_linear_605_124)"), a(n, "id", "Group 48096461"), a(t, "id", "bbai"), a(c, "stop-color", "#6E56FF"), a(u, "offset", "1"), a(u, "stop-color", "#9F8FFF"), a(p, "id", "paint0_linear_605_124"), a(p, "x1", "52.1505"), a(p, "y1", "121.517"), a(p, "x2", "68.292"), a(p, "y2", "84.222"), a(p, "gradientUnits", "userSpaceOnUse"), a(g, "stop-color", "#6E56FF"), a(m, "offset", "1"), a(m, "stop-color", "#9F8FFF"), a(d, "id", "paint1_linear_605_124"), a(d, "x1", "118.471"), a(d, "y1", "94.8378"), a(d, "x2", "81.1761"), a(d, "y2", "78.6963"), a(d, "gradientUnits", "userSpaceOnUse"), a(v, "stop-color", "#6E56FF"), a(T, "offset", "1"), a(T, "stop-color", "#9F8FFF"), a(h, "id", "paint2_linear_605_124"), a(h, "x1", "91.8495"), a(h, "y1", "28.4869"), a(h, "x2", "75.708"), a(h, "y2", "65.7819"), a(h, "gradientUnits", "userSpaceOnUse"), a(G, "stop-color", "#6E56FF"), a(b, "offset", "1"), a(b, "stop-color", "#9F8FFF"), a(E, "id", "paint3_linear_605_124"), a(E, "x1", "25.5289"), a(E, "y1", "55.1661"), a(E, "x2", "62.8239"), a(E, "y2", "71.3076"), a(E, "gradientUnits", "userSpaceOnUse"), a(e, "viewBox", "0 0 150 150"), a(
        e,
        "width",
        /*size*/
        s[0]
      ), a(e, "fill", "none"), a(e, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(N, A) {
      F(N, e, A), _(e, t), _(t, n), y && y.m(n, null), _(n, l), _(n, i), _(n, o), _(n, r), _(e, f), _(f, p), _(p, c), _(p, u), _(f, d), _(d, g), _(d, m), _(f, h), _(h, v), _(h, T), _(f, E), _(E, G), _(E, b);
    },
    p(N, [A]) {
      /*animate*/
      N[1] ? y || (y = $(), y.c(), y.m(n, l)) : y && (y.d(1), y = null), A & /*size*/
      1 && a(
        e,
        "width",
        /*size*/
        N[0]
      );
    },
    i: M,
    o: M,
    d(N) {
      N && L(e), y && y.d();
    }
  };
}
function we(s, e, t) {
  let { size: n = "64px" } = e, { animate: l = !1 } = e;
  return s.$$set = (i) => {
    "size" in i && t(0, n = i.size), "animate" in i && t(1, l = i.animate);
  }, [n, l];
}
class Ce extends K {
  constructor(e) {
    super(), X(this, e, we, ye, q, { size: 0, animate: 1 });
  }
}
var R, Fe = new Uint8Array(16);
function Le() {
  if (!R && (R = typeof crypto < "u" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto < "u" && typeof msCrypto.getRandomValues == "function" && msCrypto.getRandomValues.bind(msCrypto), !R))
    throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
  return R(Fe);
}
const Ie = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
function Se(s) {
  return typeof s == "string" && Ie.test(s);
}
var I = [];
for (var J = 0; J < 256; ++J)
  I.push((J + 256).toString(16).substr(1));
function Ne(s) {
  var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, t = (I[s[e + 0]] + I[s[e + 1]] + I[s[e + 2]] + I[s[e + 3]] + "-" + I[s[e + 4]] + I[s[e + 5]] + "-" + I[s[e + 6]] + I[s[e + 7]] + "-" + I[s[e + 8]] + I[s[e + 9]] + "-" + I[s[e + 10]] + I[s[e + 11]] + I[s[e + 12]] + I[s[e + 13]] + I[s[e + 14]] + I[s[e + 15]]).toLowerCase();
  if (!Se(t))
    throw TypeError("Stringified UUID is invalid");
  return t;
}
function Ee(s, e, t) {
  s = s || {};
  var n = s.random || (s.rng || Le)();
  if (n[6] = n[6] & 15 | 64, n[8] = n[8] & 63 | 128, e) {
    t = t || 0;
    for (var l = 0; l < 16; ++l)
      e[t + l] = n[l];
    return e;
  }
  return Ne(n);
}
function ee(s, e, t) {
  const n = s.slice();
  return n[17] = e[t], n;
}
function te(s, e, t) {
  const n = s.slice();
  return n[20] = e[t], n;
}
function Te(s) {
  const e = s.slice(), t = (
    /*part*/
    e[20]
  );
  return e[23] = t, e;
}
function Ve(s) {
  let e, t, n = B(
    /*message*/
    s[17].parts || []
  ), l = [];
  for (let o = 0; o < n.length; o += 1)
    l[o] = se(te(s, n, o));
  const i = (o) => S(l[o], 1, 1, () => {
    l[o] = null;
  });
  return {
    c() {
      e = k("div");
      for (let o = 0; o < l.length; o += 1)
        l[o].c();
      a(e, "class", "message assistant svelte-128f9i3");
    },
    m(o, r) {
      F(o, e, r);
      for (let f = 0; f < l.length; f += 1)
        l[f] && l[f].m(e, null);
      t = !0;
    },
    p(o, r) {
      if (r & /*chat, JSON*/
      1) {
        n = B(
          /*message*/
          o[17].parts || []
        );
        let f;
        for (f = 0; f < n.length; f += 1) {
          const p = te(o, n, f);
          l[f] ? (l[f].p(p, r), C(l[f], 1)) : (l[f] = se(p), l[f].c(), C(l[f], 1), l[f].m(e, null));
        }
        for (U(), f = n.length; f < l.length; f += 1)
          i(f);
        z();
      }
    },
    i(o) {
      if (!t) {
        for (let r = 0; r < n.length; r += 1)
          C(l[r]);
        t = !0;
      }
    },
    o(o) {
      l = l.filter(Boolean);
      for (let r = 0; r < l.length; r += 1)
        S(l[r]);
      t = !1;
    },
    d(o) {
      o && L(e), ce(l, o);
    }
  };
}
function Ae(s) {
  let e, t, n;
  return t = new pe({
    props: {
      value: (
        /*message*/
        s[17].parts && /*message*/
        s[17].parts.length > 0 ? (
          /*message*/
          s[17].parts.filter(ae).map(re).join("")
        ) : "[Empty message]"
      )
    }
  }), {
    c() {
      e = k("div"), D(t.$$.fragment), a(e, "class", "message user svelte-128f9i3");
    },
    m(l, i) {
      F(l, e, i), P(t, e, null), n = !0;
    },
    p(l, i) {
      const o = {};
      i & /*chat*/
      1 && (o.value = /*message*/
      l[17].parts && /*message*/
      l[17].parts.length > 0 ? (
        /*message*/
        l[17].parts.filter(ae).map(re).join("")
      ) : "[Empty message]"), t.$set(o);
    },
    i(l) {
      n || (C(t.$$.fragment, l), n = !0);
    },
    o(l) {
      S(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && L(e), Z(t);
    }
  };
}
function Me(s) {
  let e, t, n, l, i, o = ("toolName" in /*toolPart*/
  s[23] && /*toolPart*/
  s[23].toolName || "Tool") + "", r, f, p, c = "state" in /*toolPart*/
  s[23] && ne(s), u = "state" in /*toolPart*/
  s[23] && /*toolPart*/
  s[23].state === "output-available" && "output" in /*toolPart*/
  s[23] && /*toolPart*/
  s[23].output && le(s);
  return {
    c() {
      e = k("div"), t = k("div"), n = k("span"), n.textContent = "🔧", l = V(), i = k("span"), r = j(o), f = V(), c && c.c(), p = V(), u && u.c(), a(n, "class", "tool-icon svelte-128f9i3"), a(i, "class", "tool-name svelte-128f9i3"), a(t, "class", "tool-header svelte-128f9i3"), a(e, "class", "tool-part svelte-128f9i3");
    },
    m(d, g) {
      F(d, e, g), _(e, t), _(t, n), _(t, l), _(t, i), _(i, r), _(t, f), c && c.m(t, null), _(e, p), u && u.m(e, null);
    },
    p(d, g) {
      g & /*chat*/
      1 && o !== (o = ("toolName" in /*toolPart*/
      d[23] && /*toolPart*/
      d[23].toolName || "Tool") + "") && H(r, o), "state" in /*toolPart*/
      d[23] ? c ? c.p(d, g) : (c = ne(d), c.c(), c.m(t, null)) : c && (c.d(1), c = null), "state" in /*toolPart*/
      d[23] && /*toolPart*/
      d[23].state === "output-available" && "output" in /*toolPart*/
      d[23] && /*toolPart*/
      d[23].output ? u ? u.p(d, g) : (u = le(d), u.c(), u.m(e, null)) : u && (u.d(1), u = null);
    },
    i: M,
    o: M,
    d(d) {
      d && L(e), c && c.d(), u && u.d();
    }
  };
}
function Ue(s) {
  let e, t, n, l, i = (
    /*part*/
    (s[20].text || "") + ""
  ), o;
  return {
    c() {
      e = k("div"), t = k("div"), t.textContent = "Reasoning", n = V(), l = k("div"), o = j(i), a(t, "class", "reasoning-label svelte-128f9i3"), a(l, "class", "reasoning-content svelte-128f9i3"), a(e, "class", "reasoning-part svelte-128f9i3");
    },
    m(r, f) {
      F(r, e, f), _(e, t), _(e, n), _(e, l), _(l, o);
    },
    p(r, f) {
      f & /*chat*/
      1 && i !== (i = /*part*/
      (r[20].text || "") + "") && H(o, i);
    },
    i: M,
    o: M,
    d(r) {
      r && L(e);
    }
  };
}
function ze(s) {
  let e, t;
  return e = new pe({
    props: { value: (
      /*part*/
      s[20].text || ""
    ) }
  }), {
    c() {
      D(e.$$.fragment);
    },
    m(n, l) {
      P(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l & /*chat*/
      1 && (i.value = /*part*/
      n[20].text || ""), e.$set(i);
    },
    i(n) {
      t || (C(e.$$.fragment, n), t = !0);
    },
    o(n) {
      S(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Z(e, n);
    }
  };
}
function ne(s) {
  let e;
  function t(i, o) {
    if (
      /*toolPart*/
      i[23].state === "output-available"
    )
      return Be;
    if (
      /*toolPart*/
      i[23].state === "output-error"
    )
      return Re;
    if (
      /*toolPart*/
      i[23].state === "input-streaming"
    )
      return Oe;
    if (
      /*toolPart*/
      i[23].state === "input-available"
    )
      return Ge;
  }
  let n = t(s), l = n && n(s);
  return {
    c() {
      l && l.c(), e = W();
    },
    m(i, o) {
      l && l.m(i, o), F(i, e, o);
    },
    p(i, o) {
      n !== (n = t(i)) && (l && l.d(1), l = n && n(i), l && (l.c(), l.m(e.parentNode, e)));
    },
    d(i) {
      i && L(e), l && l.d(i);
    }
  };
}
function Ge(s) {
  let e;
  return {
    c() {
      e = k("span"), e.textContent = "...", a(e, "class", "tool-status pending svelte-128f9i3");
    },
    m(t, n) {
      F(t, e, n);
    },
    d(t) {
      t && L(e);
    }
  };
}
function Oe(s) {
  let e;
  return {
    c() {
      e = k("span"), e.textContent = "...", a(e, "class", "tool-status pending svelte-128f9i3");
    },
    m(t, n) {
      F(t, e, n);
    },
    d(t) {
      t && L(e);
    }
  };
}
function Re(s) {
  let e;
  return {
    c() {
      e = k("span"), e.textContent = "✗", a(e, "class", "tool-status error svelte-128f9i3");
    },
    m(t, n) {
      F(t, e, n);
    },
    d(t) {
      t && L(e);
    }
  };
}
function Be(s) {
  let e;
  return {
    c() {
      e = k("span"), e.textContent = "✓", a(e, "class", "tool-status success svelte-128f9i3");
    },
    m(t, n) {
      F(t, e, n);
    },
    d(t) {
      t && L(e);
    }
  };
}
function le(s) {
  let e, t, n, l, i = (typeof /*toolPart*/
  s[23].output == "string" ? (
    /*toolPart*/
    s[23].output
  ) : JSON.stringify(
    /*toolPart*/
    s[23].output,
    null,
    2
  )) + "", o;
  return {
    c() {
      e = k("div"), t = k("div"), t.textContent = "Output:", n = V(), l = k("pre"), o = j(i), a(t, "class", "tool-output-label svelte-128f9i3"), a(l, "class", "tool-output-content svelte-128f9i3"), a(e, "class", "tool-output svelte-128f9i3");
    },
    m(r, f) {
      F(r, e, f), _(e, t), _(e, n), _(e, l), _(l, o);
    },
    p(r, f) {
      f & /*chat*/
      1 && i !== (i = (typeof /*toolPart*/
      r[23].output == "string" ? (
        /*toolPart*/
        r[23].output
      ) : JSON.stringify(
        /*toolPart*/
        r[23].output,
        null,
        2
      )) + "") && H(o, i);
    },
    d(r) {
      r && L(e);
    }
  };
}
function se(s) {
  let e, t, n, l, i;
  const o = [ze, Ue, Me], r = [];
  function f(c, u) {
    var d;
    return u & /*chat*/
    1 && (e = null), /*part*/
    c[20].type === "text" ? 0 : (
      /*part*/
      c[20].type === "reasoning" ? 1 : (e == null && (e = !!/*part*/
      ((d = c[20].type) != null && d.startsWith("tool-") || /*part*/
      c[20].type === "dynamic-tool")), e ? 2 : -1)
    );
  }
  function p(c, u) {
    return u === 2 ? Te(c) : c;
  }
  return ~(t = f(s, -1)) && (n = r[t] = o[t](p(s, t))), {
    c() {
      n && n.c(), l = W();
    },
    m(c, u) {
      ~t && r[t].m(c, u), F(c, l, u), i = !0;
    },
    p(c, u) {
      let d = t;
      t = f(c, u), t === d ? ~t && r[t].p(p(c, t), u) : (n && (U(), S(r[d], 1, 1, () => {
        r[d] = null;
      }), z()), ~t ? (n = r[t], n ? n.p(p(c, t), u) : (n = r[t] = o[t](p(c, t)), n.c()), C(n, 1), n.m(l.parentNode, l)) : n = null);
    },
    i(c) {
      i || (C(n), i = !0);
    },
    o(c) {
      S(n), i = !1;
    },
    d(c) {
      c && L(l), ~t && r[t].d(c);
    }
  };
}
function ie(s) {
  let e, t, n, l;
  const i = [Ae, Ve], o = [];
  function r(f, p) {
    return (
      /*message*/
      f[17].role === "user" ? 0 : (
        /*message*/
        f[17].role === "assistant" ? 1 : -1
      )
    );
  }
  return ~(e = r(s)) && (t = o[e] = i[e](s)), {
    c() {
      t && t.c(), n = W();
    },
    m(f, p) {
      ~e && o[e].m(f, p), F(f, n, p), l = !0;
    },
    p(f, p) {
      let c = e;
      e = r(f), e === c ? ~e && o[e].p(f, p) : (t && (U(), S(o[c], 1, 1, () => {
        o[c] = null;
      }), z()), ~e ? (t = o[e], t ? t.p(f, p) : (t = o[e] = i[e](f), t.c()), C(t, 1), t.m(n.parentNode, n)) : t = null);
    },
    i(f) {
      l || (C(t), l = !0);
    },
    o(f) {
      S(t), l = !1;
    },
    d(f) {
      f && L(n), ~e && o[e].d(f);
    }
  };
}
function oe(s) {
  let e, t, n;
  return t = new Ce({ props: { size: "48px", animate: !0 } }), {
    c() {
      e = k("div"), D(t.$$.fragment), a(e, "class", "message system svelte-128f9i3");
    },
    m(l, i) {
      F(l, e, i), P(t, e, null), n = !0;
    },
    i(l) {
      n || (C(t.$$.fragment, l), n = !0);
    },
    o(l) {
      S(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && L(e), Z(t);
    }
  };
}
function De(s) {
  let e, t, n, l, i, o, r, f, p, c = B(
    /*chat*/
    s[0].messages
  ), u = [];
  for (let m = 0; m < c.length; m += 1)
    u[m] = ie(ee(s, c, m));
  const d = (m) => S(u[m], 1, 1, () => {
    u[m] = null;
  });
  let g = (
    /*loading*/
    s[1] && oe()
  );
  return {
    c() {
      e = k("div"), t = k("div");
      for (let m = 0; m < u.length; m += 1)
        u[m].c();
      n = V(), g && g.c(), l = V(), i = k("div"), o = k("textarea"), a(t, "class", "chatbox svelte-128f9i3"), a(o, "class", "input spectrum-Textfield-input svelte-128f9i3"), a(o, "placeholder", "Ask anything"), o.disabled = /*loading*/
      s[1], a(i, "class", "input-wrapper svelte-128f9i3"), a(e, "class", "chat-area svelte-128f9i3");
    },
    m(m, h) {
      F(m, e, h), _(e, t);
      for (let v = 0; v < u.length; v += 1)
        u[v] && u[v].m(t, null);
      _(t, n), g && g.m(t, null), _(e, l), _(e, i), _(i, o), Q(
        o,
        /*inputValue*/
        s[3]
      ), s[11](o), s[12](e), r = !0, f || (p = [
        Y(
          o,
          "input",
          /*textarea_input_handler*/
          s[10]
        ),
        Y(
          o,
          "keydown",
          /*handleKeyDown*/
          s[5]
        )
      ], f = !0);
    },
    p(m, [h]) {
      if (h & /*chat, JSON*/
      1) {
        c = B(
          /*chat*/
          m[0].messages
        );
        let v;
        for (v = 0; v < c.length; v += 1) {
          const T = ee(m, c, v);
          u[v] ? (u[v].p(T, h), C(u[v], 1)) : (u[v] = ie(T), u[v].c(), C(u[v], 1), u[v].m(t, n));
        }
        for (U(), v = c.length; v < u.length; v += 1)
          d(v);
        z();
      }
      /*loading*/
      m[1] ? g ? h & /*loading*/
      2 && C(g, 1) : (g = oe(), g.c(), C(g, 1), g.m(t, null)) : g && (U(), S(g, 1, 1, () => {
        g = null;
      }), z()), (!r || h & /*loading*/
      2) && (o.disabled = /*loading*/
      m[1]), h & /*inputValue*/
      8 && Q(
        o,
        /*inputValue*/
        m[3]
      );
    },
    i(m) {
      if (!r) {
        for (let h = 0; h < c.length; h += 1)
          C(u[h]);
        C(g), r = !0;
      }
    },
    o(m) {
      u = u.filter(Boolean);
      for (let h = 0; h < u.length; h += 1)
        S(u[h]);
      S(g), r = !1;
    },
    d(m) {
      m && L(e), ce(u, m), g && g.d(), s[11](null), s[12](null), f = !1, _e(p);
    }
  };
}
const ae = (s) => s.type === "text", re = (s) => s.type === "text" ? s.text : "";
function Pe(s, e, t) {
  let { API: n = de() } = e, { workspaceId: l } = e, { chat: i } = e, { loading: o = !1 } = e;
  const r = me();
  let f = "", p, c, u, d, g;
  async function m() {
    await O(), p && t(4, p.scrollTop = p.scrollHeight, p);
  }
  async function h(b) {
    b.key === "Enter" && !b.shiftKey && (b.preventDefault(), await v());
  }
  async function v() {
    i || t(0, i = { title: "", messages: [] });
    const b = {
      id: Ee(),
      role: "user",
      parts: [{ type: "text", text: f }]
    }, y = {
      ...i,
      messages: [...i.messages, b]
    };
    t(0, i = y), await m(), t(3, f = ""), t(1, o = !0);
    try {
      const N = await n.agentChatStream(y, l);
      for await (const A of N)
        t(0, i = {
          ...y,
          messages: [...y.messages, A]
        }), m();
      t(1, o = !1), r("chatSaved", { chatId: i._id, chat: i });
    } catch (N) {
      console.error(N), be.error(N.message), t(1, o = !1);
    }
    await O(), u && u.focus();
  }
  ge(async () => {
    c = new MutationObserver(async () => {
      await O(), p && t(4, p.scrollTop = p.scrollHeight, p);
    }), p && c.observe(p, {
      childList: !0,
      subtree: !0,
      attributes: !0
    }), await O(), u && u.focus();
  }), he(() => {
    c.disconnect();
  });
  function T() {
    f = this.value, t(3, f);
  }
  function E(b) {
    x[b ? "unshift" : "push"](() => {
      u = b, t(2, u);
    });
  }
  function G(b) {
    x[b ? "unshift" : "push"](() => {
      p = b, t(4, p);
    });
  }
  return s.$$set = (b) => {
    "API" in b && t(6, n = b.API), "workspaceId" in b && t(7, l = b.workspaceId), "chat" in b && t(0, i = b.chat), "loading" in b && t(1, o = b.loading);
  }, s.$$.update = () => {
    var b;
    if (s.$$.dirty & /*chat*/
    1 && (b = i == null ? void 0 : i.messages) != null && b.length && m(), s.$$.dirty & /*chat, textareaElement, lastFocusedChatId, lastFocusedNewChat*/
    773) {
      const y = i == null ? void 0 : i._id, N = !y && (!(i != null && i.messages) || i.messages.length === 0);
      u && (y && y !== d || N && i && i !== g) && (O().then(() => u == null ? void 0 : u.focus()), t(8, d = y), t(9, g = N ? i : void 0));
    }
  }, [
    i,
    o,
    u,
    f,
    p,
    h,
    n,
    l,
    d,
    g,
    T,
    E,
    G
  ];
}
class Ze extends K {
  constructor(e) {
    super(), X(this, e, Pe, De, q, {
      API: 6,
      workspaceId: 7,
      chat: 0,
      loading: 1
    });
  }
}
function fe(s) {
  let e, t;
  return {
    c() {
      e = k("p"), t = j(
        /*intro*/
        s[0]
      ), a(e, "class", "agent-chat__intro svelte-1eyzmhn");
    },
    m(n, l) {
      F(n, e, l), _(e, t);
    },
    p(n, l) {
      l & /*intro*/
      1 && H(
        t,
        /*intro*/
        n[0]
      );
    },
    d(n) {
      n && L(e);
    }
  };
}
function ue(s) {
  let e, t;
  return e = new Ze({
    props: {
      chat: (
        /*chat*/
        s[2]
      ),
      workspaceId: (
        /*workspaceId*/
        s[1]
      )
    }
  }), {
    c() {
      D(e.$$.fragment);
    },
    m(n, l) {
      P(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l & /*workspaceId*/
      2 && (i.workspaceId = /*workspaceId*/
      n[1]), e.$set(i);
    },
    i(n) {
      t || (C(e.$$.fragment, n), t = !0);
    },
    o(n) {
      S(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Z(e, n);
    }
  };
}
function je(s) {
  let e, t, n, l, i = (
    /*intro*/
    s[0] && fe(s)
  ), o = (
    /*workspaceId*/
    s[1] && ue(s)
  );
  return {
    c() {
      e = k("section"), i && i.c(), t = V(), n = k("div"), o && o.c(), a(n, "class", "chat-wrapper svelte-1eyzmhn"), a(e, "class", "agent-chat svelte-1eyzmhn");
    },
    m(r, f) {
      F(r, e, f), i && i.m(e, null), _(e, t), _(e, n), o && o.m(n, null), l = !0;
    },
    p(r, [f]) {
      /*intro*/
      r[0] ? i ? i.p(r, f) : (i = fe(r), i.c(), i.m(e, t)) : i && (i.d(1), i = null), /*workspaceId*/
      r[1] ? o ? (o.p(r, f), f & /*workspaceId*/
      2 && C(o, 1)) : (o = ue(r), o.c(), C(o, 1), o.m(n, null)) : o && (U(), S(o, 1, 1, () => {
        o = null;
      }), z());
    },
    i(r) {
      l || (C(o), l = !0);
    },
    o(r) {
      S(o), l = !1;
    },
    d(r) {
      r && L(e), i && i.d(), o && o.d();
    }
  };
}
function He(s, e, t) {
  let n, l;
  ve(s, ke, (r) => t(3, l = r));
  let { intro: i = "Ask our assistant anything about this app." } = e, o = { title: "", messages: [] };
  return s.$$set = (r) => {
    "intro" in r && t(0, i = r.intro);
  }, s.$$.update = () => {
    s.$$.dirty & /*$appStore*/
    8 && t(1, n = (l == null ? void 0 : l.appId) ?? null);
  }, [i, n, o, l];
}
class Xe extends K {
  constructor(e) {
    super(), X(this, e, He, je, q, { intro: 0 });
  }
}
export {
  Xe as default
};
