import { S as Y, i as Z, s as x, I as H, e as N, c as E, a as L, t as J, b as k, d as Q, f as w, g as y, m as B, l as K, h as U, j as ge, k as _, n as P, o as T, p as C, r as me, q as de, u as V, v as _e, w as Pe, x as pe, y as $, z as ee, A as te, B as ae, C as he, D as be, L as W, E as ve, F as ye, G as Ne, H as ke, J as we, P as Te } from "./index-e79f0bb2.js";
function Ae(a) {
  let t, e, u, i, o, s, r, n, f, g, p, h, S;
  return u = new H({ props: { name: "caret-left", size: "M" } }), g = new H({
    props: { name: "caret-right", size: "M" }
  }), {
    c() {
      t = N("nav"), e = N("div"), E(u.$$.fragment), i = L(), o = N("span"), s = J("Page "), r = J(
        /*page*/
        a[0]
      ), n = L(), f = N("div"), E(g.$$.fragment), k(e, "class", "spectrum-ActionButton spectrum-ActionButton--sizeM spectrum-ActionButton--quiet spectrum-Pagination-prevButton svelte-1w0vi9g"), Q(e, "is-disabled", !/*hasPrevPage*/
      a[3]), k(o, "class", "spectrum-Body--secondary spectrum-Pagination-counter svelte-1w0vi9g"), k(f, "class", "spectrum-ActionButton spectrum-ActionButton--sizeM spectrum-ActionButton--quiet spectrum-Pagination-nextButton svelte-1w0vi9g"), Q(f, "is-disabled", !/*hasNextPage*/
      a[4]), k(t, "class", "spectrum-Pagination spectrum-Pagination--explicit");
    },
    m(m, d) {
      w(m, t, d), y(t, e), B(u, e, null), y(t, i), y(t, o), y(o, s), y(o, r), y(t, n), y(t, f), B(g, f, null), p = !0, h || (S = [
        K(e, "click", function() {
          U(
            /*hasPrevPage*/
            a[3] ? (
              /*goToPrevPage*/
              a[1]
            ) : null
          ) && /*hasPrevPage*/
          (a[3] ? (
            /*goToPrevPage*/
            a[1]
          ) : null).apply(this, arguments);
        }),
        K(f, "click", function() {
          U(
            /*hasNextPage*/
            a[4] ? (
              /*goToNextPage*/
              a[2]
            ) : null
          ) && /*hasNextPage*/
          (a[4] ? (
            /*goToNextPage*/
            a[2]
          ) : null).apply(this, arguments);
        })
      ], h = !0);
    },
    p(m, [d]) {
      a = m, (!p || d & /*hasPrevPage*/
      8) && Q(e, "is-disabled", !/*hasPrevPage*/
      a[3]), (!p || d & /*page*/
      1) && ge(
        r,
        /*page*/
        a[0]
      ), (!p || d & /*hasNextPage*/
      16) && Q(f, "is-disabled", !/*hasNextPage*/
      a[4]);
    },
    i(m) {
      p || (_(u.$$.fragment, m), _(g.$$.fragment, m), p = !0);
    },
    o(m) {
      P(u.$$.fragment, m), P(g.$$.fragment, m), p = !1;
    },
    d(m) {
      m && T(t), C(u), C(g), h = !1, me(S);
    }
  };
}
function De(a, t, e) {
  let { page: u } = t, { goToPrevPage: i } = t, { goToNextPage: o } = t, { hasPrevPage: s = !0 } = t, { hasNextPage: r = !0 } = t;
  return a.$$set = (n) => {
    "page" in n && e(0, u = n.page), "goToPrevPage" in n && e(1, i = n.goToPrevPage), "goToNextPage" in n && e(2, o = n.goToNextPage), "hasPrevPage" in n && e(3, s = n.hasPrevPage), "hasNextPage" in n && e(4, r = n.hasNextPage);
  }, [u, i, o, s, r];
}
class Oe extends Y {
  constructor(t) {
    super(), Z(this, t, De, Ae, x, {
      page: 0,
      goToPrevPage: 1,
      goToNextPage: 2,
      hasPrevPage: 3,
      hasNextPage: 4
    });
  }
}
function Ee(a) {
  let t, e, u;
  const i = (
    /*#slots*/
    a[19].default
  ), o = ye(
    i,
    a,
    /*$$scope*/
    a[20],
    null
  );
  let s = (
    /*paginate*/
    a[0] && /*$fetch*/
    a[2].supportsPagination && X(a)
  );
  return {
    c() {
      o && o.c(), t = L(), s && s.c(), e = $();
    },
    m(r, n) {
      o && o.m(r, n), w(r, t, n), s && s.m(r, n), w(r, e, n), u = !0;
    },
    p(r, n) {
      o && o.p && (!u || n & /*$$scope*/
      1048576) && Ne(
        o,
        i,
        r,
        /*$$scope*/
        r[20],
        u ? we(
          i,
          /*$$scope*/
          r[20],
          n,
          null
        ) : ke(
          /*$$scope*/
          r[20]
        ),
        null
      ), /*paginate*/
      r[0] && /*$fetch*/
      r[2].supportsPagination ? s ? (s.p(r, n), n & /*paginate, $fetch*/
      5 && _(s, 1)) : (s = X(r), s.c(), _(s, 1), s.m(e.parentNode, e)) : s && (ee(), P(s, 1, 1, () => {
        s = null;
      }), te());
    },
    i(r) {
      u || (_(o, r), _(s), u = !0);
    },
    o(r) {
      P(o, r), P(s), u = !1;
    },
    d(r) {
      r && (T(t), T(e)), o && o.d(r), s && s.d(r);
    }
  };
}
function Be(a) {
  let t, e, u;
  return e = new Te({}), {
    c() {
      t = N("div"), E(e.$$.fragment), k(t, "class", "loading svelte-1w67a05");
    },
    m(i, o) {
      w(i, t, o), B(e, t, null), u = !0;
    },
    p: ae,
    i(i) {
      u || (_(e.$$.fragment, i), u = !0);
    },
    o(i) {
      P(e.$$.fragment, i), u = !1;
    },
    d(i) {
      i && T(t), C(e);
    }
  };
}
function X(a) {
  let t, e, u;
  return e = new Oe({
    props: {
      page: (
        /*$fetch*/
        a[2].pageNumber + 1
      ),
      hasPrevPage: (
        /*$fetch*/
        a[2].hasPrevPage
      ),
      hasNextPage: (
        /*$fetch*/
        a[2].hasNextPage
      ),
      goToPrevPage: (
        /*fetch*/
        a[1].prevPage
      ),
      goToNextPage: (
        /*fetch*/
        a[1].nextPage
      )
    }
  }), {
    c() {
      t = N("div"), E(e.$$.fragment), k(t, "class", "pagination svelte-1w67a05");
    },
    m(i, o) {
      w(i, t, o), B(e, t, null), u = !0;
    },
    p(i, o) {
      const s = {};
      o & /*$fetch*/
      4 && (s.page = /*$fetch*/
      i[2].pageNumber + 1), o & /*$fetch*/
      4 && (s.hasPrevPage = /*$fetch*/
      i[2].hasPrevPage), o & /*$fetch*/
      4 && (s.hasNextPage = /*$fetch*/
      i[2].hasNextPage), o & /*fetch*/
      2 && (s.goToPrevPage = /*fetch*/
      i[1].prevPage), o & /*fetch*/
      2 && (s.goToNextPage = /*fetch*/
      i[1].nextPage), e.$set(s);
    },
    i(i) {
      u || (_(e.$$.fragment, i), u = !0);
    },
    o(i) {
      P(e.$$.fragment, i), u = !1;
    },
    d(i) {
      i && T(t), C(e);
    }
  };
}
function Ce(a) {
  let t, e, u, i;
  const o = [Be, Ee], s = [];
  function r(n, f) {
    return (
      /*$fetch*/
      n[2].loaded ? 1 : 0
    );
  }
  return t = r(a), e = s[t] = o[t](a), {
    c() {
      e.c(), u = $();
    },
    m(n, f) {
      s[t].m(n, f), w(n, u, f), i = !0;
    },
    p(n, f) {
      let g = t;
      t = r(n), t === g ? s[t].p(n, f) : (ee(), P(s[g], 1, 1, () => {
        s[g] = null;
      }), te(), e = s[t], e ? e.p(n, f) : (e = s[t] = o[t](n), e.c()), _(e, 1), e.m(u.parentNode, u));
    },
    i(n) {
      i || (_(e), i = !0);
    },
    o(n) {
      P(e), i = !1;
    },
    d(n) {
      n && T(u), s[t].d(n);
    }
  };
}
function Se(a) {
  let t, e, u, i, o, s;
  return e = new /*Provider*/
  a[7]({
    props: {
      actions: (
        /*actions*/
        a[5]
      ),
      data: (
        /*dataContext*/
        a[4]
      ),
      $$slots: { default: [Ce] },
      $$scope: { ctx: a }
    }
  }), {
    c() {
      t = N("div"), E(e.$$.fragment), k(t, "class", "container svelte-1w67a05");
    },
    m(r, n) {
      w(r, t, n), B(e, t, null), i = !0, o || (s = de(u = /*styleable*/
      a[6].call(
        null,
        t,
        /*$component*/
        a[3].styles
      )), o = !0);
    },
    p(r, [n]) {
      const f = {};
      n & /*actions*/
      32 && (f.actions = /*actions*/
      r[5]), n & /*dataContext*/
      16 && (f.data = /*dataContext*/
      r[4]), n & /*$$scope, $fetch, fetch, paginate*/
      1048583 && (f.$$scope = { dirty: n, ctx: r }), e.$set(f), u && U(u.update) && n & /*$component*/
      8 && u.update.call(
        null,
        /*$component*/
        r[3].styles
      );
    },
    i(r) {
      i || (_(e.$$.fragment, r), i = !0);
    },
    o(r) {
      P(e.$$.fragment, r), i = !1;
    },
    d(r) {
      r && T(t), C(e), o = !1, s();
    }
  };
}
function qe(a, t, e) {
  let u, i, o, s, r, n, f, g = ae, p = () => (g(), g = he(o, (l) => e(2, f = l)), o), h;
  a.$$.on_destroy.push(() => g());
  let { $$slots: S = {}, $$scope: m } = t, { dataSource: d } = t, { filter: j } = t, { sortColumn: q } = t, { sortOrder: R } = t, { limit: D } = t, { paginate: z } = t, { autoRefresh: M } = t;
  const { styleable: ne, Provider: se, ActionTypes: I, API: re } = V("sdk"), G = V("component");
  _e(a, G, (l) => e(3, h = l));
  let F, A = {};
  const ie = (l) => be({
    API: re,
    datasource: l,
    options: {
      query: i,
      sortColumn: q,
      sortOrder: R,
      limit: D,
      paginate: z
    }
  }), oe = (l) => {
    if (!l)
      return l;
    let c = { ...l };
    return Object.entries(c).forEach(([v, b]) => {
      b.visible === !1 && delete c[v];
    }), c;
  }, le = (l, c) => {
    !l || !c || e(15, A = { ...A, [l]: c });
  }, ue = (l) => {
    if (!l)
      return;
    const c = { ...A };
    delete c[l], e(15, A = c);
  }, fe = (l, c) => {
    var b, O;
    if (!Object.keys(c).length)
      return l;
    const v = {
      [W.AND]: {
        conditions: [
          ...l ? [l] : [],
          ...Object.values(c || {})
        ]
      },
      onEmptyFilter: ve.RETURN_NONE
    };
    return (((O = (b = v[W.AND]) == null ? void 0 : b.conditions) == null ? void 0 : O.length) ?? 0) > 0 ? v : {};
  }, ce = (l) => {
    clearInterval(F), l && (F = setInterval(o.refresh, Math.max(1e4, l * 1e3)));
  };
  return Pe(() => {
    clearInterval(F);
  }), a.$$set = (l) => {
    "dataSource" in l && e(9, d = l.dataSource), "filter" in l && e(10, j = l.filter), "sortColumn" in l && e(11, q = l.sortColumn), "sortOrder" in l && e(12, R = l.sortOrder), "limit" in l && e(13, D = l.limit), "paginate" in l && e(0, z = l.paginate), "autoRefresh" in l && e(14, M = l.autoRefresh), "$$scope" in l && e(20, m = l.$$scope);
  }, a.$$.update = () => {
    var l;
    a.$$.dirty & /*filter*/
    1024 && e(18, u = pe(j)), a.$$.dirty & /*defaultQuery, queryExtensions*/
    294912 && e(16, i = fe(u, A)), a.$$.dirty & /*dataSource*/
    512 && p(e(1, o = ie(d))), a.$$.dirty & /*fetch, query, sortColumn, sortOrder, limit, paginate*/
    79875 && o.update({
      query: i,
      sortColumn: q,
      sortOrder: R,
      limit: D,
      paginate: z
    }), a.$$.dirty & /*$fetch*/
    4 && e(17, s = oe(f.schema)), a.$$.dirty & /*autoRefresh*/
    16384 && ce(M), a.$$.dirty & /*fetch, dataSource*/
    514 && e(5, r = [
      {
        type: I.RefreshDatasource,
        callback: () => o.refresh(),
        metadata: { dataSource: d }
      },
      {
        type: I.AddDataProviderQueryExtension,
        callback: le
      },
      {
        type: I.RemoveDataProviderQueryExtension,
        callback: ue
      },
      {
        type: I.SetDataProviderSorting,
        callback: ({ column: c, order: v }) => {
          var O;
          let b = {};
          c && (b.sortColumn = c), v && (b.sortOrder = v), (O = Object.keys(b)) != null && O.length && o.update(b);
        }
      }
    ]), a.$$.dirty & /*$fetch, dataSource, schema, $component, limit*/
    139788 && e(4, n = {
      rows: f.rows,
      info: f.info,
      datasource: d || {},
      schema: s,
      rowsLength: f.rows.length,
      pageNumber: f.pageNumber + 1,
      // Undocumented properties. These aren't supposed to be used in builder
      // bindings, but are used internally by other components
      id: h == null ? void 0 : h.id,
      state: { query: f.query },
      limit: D,
      primaryDisplay: (l = f.definition) == null ? void 0 : l.primaryDisplay,
      loaded: f.loaded
    });
  }, [
    z,
    o,
    f,
    h,
    n,
    r,
    ne,
    se,
    G,
    d,
    j,
    q,
    R,
    D,
    M,
    A,
    i,
    s,
    u,
    S,
    m
  ];
}
class ze extends Y {
  constructor(t) {
    super(), Z(this, t, qe, Se, x, {
      dataSource: 9,
      filter: 10,
      sortColumn: 11,
      sortOrder: 12,
      limit: 13,
      paginate: 0,
      autoRefresh: 14
    });
  }
}
export {
  ze as default
};
