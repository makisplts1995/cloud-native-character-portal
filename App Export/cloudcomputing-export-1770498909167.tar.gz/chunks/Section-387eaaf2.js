import { S as j, i as E, s as I, F as K, e as N, a as R, b as S, f as z, g as W, q as L, G as Q, H as T, J as U, k as d, z as D, n as p, A as F, h as V, o as k, u as C, v as O, aa as X, N as w, y as Y, O as Z, c as $, d as A, m as x, p as ee, ac as le } from "./index-e79f0bb2.js";
import te from "./Placeholder-527c0fd1.js";
function M(n, l, i) {
  const a = n.slice();
  return a[16] = l[i], a;
}
function B(n) {
  let l, i, a = w(new Array(
    /*layoutMap*/
    n[8][
      /*type*/
      n[0]
    ] - /*$component*/
    n[3].children
  )), e = [];
  for (let t = 0; t < a.length; t += 1)
    e[t] = q(M(n, a, t));
  const r = (t) => p(e[t], 1, 1, () => {
    e[t] = null;
  });
  return {
    c() {
      for (let t = 0; t < e.length; t += 1)
        e[t].c();
      l = Y();
    },
    m(t, c) {
      for (let s = 0; s < e.length; s += 1)
        e[s] && e[s].m(t, c);
      z(t, l, c), i = !0;
    },
    p(t, c) {
      if (c & /*$builderStore, type, $component*/
      25) {
        a = w(new Array(
          /*layoutMap*/
          t[8][
            /*type*/
            t[0]
          ] - /*$component*/
          t[3].children
        ));
        let s;
        for (s = 0; s < a.length; s += 1) {
          const _ = M(t, a, s);
          e[s] ? (e[s].p(_, c), d(e[s], 1)) : (e[s] = q(_), e[s].c(), d(e[s], 1), e[s].m(l.parentNode, l));
        }
        for (D(), s = a.length; s < e.length; s += 1)
          r(s);
        F();
      }
    },
    i(t) {
      if (!i) {
        for (let c = 0; c < a.length; c += 1)
          d(e[c]);
        i = !0;
      }
    },
    o(t) {
      e = e.filter(Boolean);
      for (let c = 0; c < e.length; c += 1)
        p(e[c]);
      i = !1;
    },
    d(t) {
      t && k(l), Z(e, t);
    }
  };
}
function q(n) {
  let l, i, a, e;
  return i = new te({}), {
    c() {
      l = N("div"), $(i.$$.fragment), a = R(), S(l, "class", "svelte-1ybyfvi"), A(
        l,
        "placeholder",
        /*$builderStore*/
        n[4].inBuilder
      );
    },
    m(r, t) {
      z(r, l, t), x(i, l, null), W(l, a), e = !0;
    },
    p(r, t) {
      (!e || t & /*$builderStore*/
      16) && A(
        l,
        "placeholder",
        /*$builderStore*/
        r[4].inBuilder
      );
    },
    i(r) {
      e || (d(i.$$.fragment, r), e = !0);
    },
    o(r) {
      p(i.$$.fragment, r), e = !1;
    },
    d(r) {
      r && k(l), ee(i);
    }
  };
}
function ne(n) {
  let l, i, a, e, r, t, c;
  const s = (
    /*#slots*/
    n[12].default
  ), _ = K(
    s,
    n,
    /*$$scope*/
    n[11],
    null
  );
  let u = (
    /*layoutMap*/
    n[8][
      /*type*/
      n[0]
    ] - /*$component*/
    n[3].children > 0 && B(n)
  );
  return {
    c() {
      l = N("div"), _ && _.c(), i = R(), u && u.c(), S(l, "class", a = /*type*/
      n[0] + " columns-" + /*columnsDependingOnSize*/
      n[2] + " svelte-1ybyfvi");
    },
    m(o, m) {
      z(o, l, m), _ && _.m(l, null), W(l, i), u && u.m(l, null), n[13](l), r = !0, t || (c = L(e = /*styleable*/
      n[5].call(
        null,
        l,
        /*$component*/
        n[3].styles
      )), t = !0);
    },
    p(o, [m]) {
      _ && _.p && (!r || m & /*$$scope*/
      2048) && Q(
        _,
        s,
        o,
        /*$$scope*/
        o[11],
        r ? U(
          s,
          /*$$scope*/
          o[11],
          m,
          null
        ) : T(
          /*$$scope*/
          o[11]
        ),
        null
      ), /*layoutMap*/
      o[8][
        /*type*/
        o[0]
      ] - /*$component*/
      o[3].children > 0 ? u ? (u.p(o, m), m & /*type, $component*/
      9 && d(u, 1)) : (u = B(o), u.c(), d(u, 1), u.m(l, null)) : u && (D(), p(u, 1, 1, () => {
        u = null;
      }), F()), (!r || m & /*type, columnsDependingOnSize*/
      5 && a !== (a = /*type*/
      o[0] + " columns-" + /*columnsDependingOnSize*/
      o[2] + " svelte-1ybyfvi")) && S(l, "class", a), e && V(e.update) && m & /*$component*/
      8 && e.update.call(
        null,
        /*$component*/
        o[3].styles
      );
    },
    i(o) {
      r || (d(_, o), d(u), r = !0);
    },
    o(o) {
      p(_, o), p(u), r = !1;
    },
    d(o) {
      o && k(l), _ && _.d(o), u && u.d(), n[13](null), t = !1, c();
    }
  };
}
function se(n, l, i) {
  let a, e, r, { $$slots: t = {}, $$scope: c } = l;
  const { styleable: s, builderStore: _ } = C("sdk");
  O(n, _, (f) => i(4, r = f));
  const u = C("component");
  O(n, u, (f) => i(3, e = f));
  let { type: o = "mainSidebar" } = l, { minSize: m = 250 } = l, y = {
    mainSidebar: 2,
    sidebarMain: 2,
    oneColumn: 1,
    twoColumns: 2,
    threeColumns: 3
  }, b, v;
  const G = (f) => {
    const h = new ResizeObserver((g) => {
      if (!(g != null && g[0]))
        return;
      const P = g[0].target;
      i(10, v = P.clientWidth);
    });
    return h.observe(f), h;
  };
  function H(f) {
    const h = Math.floor(f / m) || 100;
    if (y[o] <= h)
      return !1;
    if (y[o] > h)
      return h;
  }
  X(() => {
    let f = G(b);
    return () => {
      f.disconnect();
    };
  });
  function J(f) {
    le[f ? "unshift" : "push"](() => {
      b = f, i(1, b);
    });
  }
  return n.$$set = (f) => {
    "type" in f && i(0, o = f.type), "minSize" in f && i(9, m = f.minSize), "$$scope" in f && i(11, c = f.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*containerWidth*/
    1024 && i(2, a = H(v));
  }, [
    o,
    b,
    a,
    e,
    r,
    s,
    _,
    u,
    y,
    m,
    v,
    c,
    t,
    J
  ];
}
class re extends j {
  constructor(l) {
    super(), E(this, l, se, ne, I, { type: 0, minSize: 9 });
  }
}
export {
  re as default
};
