import { S as ae, i as ne, s as te, ac as T, ai as W, c as P, m as j, aj as q, k as _, n as g, p as B, v as C, au as ie, u as z, aa as se, w as oe, e as U, a as Q, b as I, d as K, f as y, g as re, z as O, A as H, o as w, bO as fe, bV as de, cG as ue, P as ce } from "./index-e79f0bb2.js";
import { F as _e } from "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function J(t) {
  let e, n;
  return e = new ue({
    props: {
      value: (
        /*localFiles*/
        t[6]
      ),
      disabled: (
        /*loading*/
        t[7] || /*fieldState*/
        t[4].disabled
      ),
      error: (
        /*fieldState*/
        t[4].error
      ),
      processFiles: (
        /*processFiles*/
        t[13]
      ),
      handleFileTooLarge: (
        /*handleFileTooLarge*/
        t[12]
      ),
      maximum: 1,
      fileSizeLimit: (
        /*MaxFileSize*/
        t[11]
      )
    }
  }), e.$on(
    "change",
    /*handleChange*/
    t[14]
  ), {
    c() {
      P(e.$$.fragment);
    },
    m(s, a) {
      j(e, s, a), n = !0;
    },
    p(s, a) {
      const i = {};
      a & /*localFiles*/
      64 && (i.value = /*localFiles*/
      s[6]), a & /*loading, fieldState*/
      144 && (i.disabled = /*loading*/
      s[7] || /*fieldState*/
      s[4].disabled), a & /*fieldState*/
      16 && (i.error = /*fieldState*/
      s[4].error), e.$set(i);
    },
    i(s) {
      n || (_(e.$$.fragment, s), n = !0);
    },
    o(s) {
      g(e.$$.fragment, s), n = !1;
    },
    d(s) {
      B(e, s);
    }
  };
}
function N(t) {
  let e, n, s, a, i;
  return a = new ce({}), {
    c() {
      e = U("div"), n = Q(), s = U("div"), P(a.$$.fragment), I(e, "class", "overlay svelte-1f67xpj"), I(s, "class", "loading svelte-1f67xpj");
    },
    m(o, f) {
      y(o, e, f), y(o, n, f), y(o, s, f), j(a, s, null), i = !0;
    },
    i(o) {
      i || (_(a.$$.fragment, o), i = !0);
    },
    o(o) {
      g(a.$$.fragment, o), i = !1;
    },
    d(o) {
      o && (w(e), w(n), w(s)), B(a);
    }
  };
}
function me(t) {
  let e, n, s, a = (
    /*fieldState*/
    t[4] && J(t)
  ), i = (
    /*loading*/
    t[7] && N()
  );
  return {
    c() {
      e = U("div"), a && a.c(), n = Q(), i && i.c(), I(e, "class", "content svelte-1f67xpj"), K(
        e,
        "builder",
        /*$builderStore*/
        t[8].inBuilder
      );
    },
    m(o, f) {
      y(o, e, f), a && a.m(e, null), re(e, n), i && i.m(e, null), s = !0;
    },
    p(o, f) {
      /*fieldState*/
      o[4] ? a ? (a.p(o, f), f & /*fieldState*/
      16 && _(a, 1)) : (a = J(o), a.c(), _(a, 1), a.m(e, n)) : a && (O(), g(a, 1, 1, () => {
        a = null;
      }), H()), /*loading*/
      o[7] ? i ? f & /*loading*/
      128 && _(i, 1) : (i = N(), i.c(), _(i, 1), i.m(e, null)) : i && (O(), g(i, 1, 1, () => {
        i = null;
      }), H()), (!s || f & /*$builderStore*/
      256) && K(
        e,
        "builder",
        /*$builderStore*/
        o[8].inBuilder
      );
    },
    i(o) {
      s || (_(a), _(i), s = !0);
    },
    o(o) {
      g(a), g(i), s = !1;
    },
    d(o) {
      o && w(e), a && a.d(), i && i.d();
    }
  };
}
function ge(t) {
  let e, n, s, a;
  function i(r) {
    t[19](r);
  }
  function o(r) {
    t[20](r);
  }
  let f = {
    label: (
      /*label*/
      t[1]
    ),
    field: (
      /*field*/
      t[0]
    ),
    disabled: (
      /*disabled*/
      t[2]
    ),
    validation: (
      /*validation*/
      t[3]
    ),
    type: "s3upload",
    defaultValue: [],
    $$slots: { default: [me] },
    $$scope: { ctx: t }
  };
  return (
    /*fieldState*/
    t[4] !== void 0 && (f.fieldState = /*fieldState*/
    t[4]), /*fieldApi*/
    t[5] !== void 0 && (f.fieldApi = /*fieldApi*/
    t[5]), e = new _e({ props: f }), T.push(() => W(e, "fieldState", i)), T.push(() => W(e, "fieldApi", o)), {
      c() {
        P(e.$$.fragment);
      },
      m(r, d) {
        j(e, r, d), a = !0;
      },
      p(r, [d]) {
        const c = {};
        d & /*label*/
        2 && (c.label = /*label*/
        r[1]), d & /*field*/
        1 && (c.field = /*field*/
        r[0]), d & /*disabled*/
        4 && (c.disabled = /*disabled*/
        r[2]), d & /*validation*/
        8 && (c.validation = /*validation*/
        r[3]), d & /*$$scope, $builderStore, loading, localFiles, fieldState*/
        268435920 && (c.$$scope = { dirty: d, ctx: r }), !n && d & /*fieldState*/
        16 && (n = !0, c.fieldState = /*fieldState*/
        r[4], q(() => n = !1)), !s && d & /*fieldApi*/
        32 && (s = !0, c.fieldApi = /*fieldApi*/
        r[5], q(() => s = !1)), e.$set(c);
      },
      i(r) {
        a || (_(e.$$.fragment, r), a = !0);
      },
      o(r) {
        g(e.$$.fragment, r), a = !1;
      },
      d(r) {
        B(e, r);
      }
    }
  );
}
function be(t, e, n) {
  let s, a, i;
  C(t, ie, (l) => n(8, i = l));
  let { datasourceId: o } = e, { bucket: f } = e, { key: r } = e, { field: d } = e, { label: c } = e, { disabled: D = !1 } = e, { validation: E } = e, { onChange: k } = e;
  const V = z("context");
  C(t, V, (l) => n(23, a = l));
  let b, S, A = [];
  const { API: X, notificationStore: v, uploadStore: G } = z("sdk"), M = z("component");
  C(t, M, (l) => n(22, s = l));
  const Y = 1e9 * 5;
  let m, F = !1;
  const Z = () => {
    v.actions.warning("Files cannot exceed 5GB. Please try again with a smaller file.");
  }, L = async (l) => i.inBuilder ? [] : await new Promise((u) => {
    var h;
    if (!(l != null && l.length))
      return [];
    m = l[0], (h = m.type) != null && h.startsWith("image") || u([{ name: m.name, type: m.type }]);
    const p = new FileReader();
    p.addEventListener(
      "load",
      () => {
        u([
          {
            url: p.result,
            name: m.name,
            type: m.type
          }
        ]);
      },
      !1
    ), p.readAsDataURL(l[0]);
  }), x = async () => {
    const l = fe(r, a);
    n(7, F = !0);
    try {
      const u = await X.externalUpload(o, f, l, m);
      return v.actions.success("File uploaded successfully"), n(7, F = !1), u;
    } catch (u) {
      v.actions.error(`Error uploading file: ${(u == null ? void 0 : u.message) || u}`), n(7, F = !1);
    }
  }, $ = (l) => {
    n(6, A = l.detail);
    let u = de(l.detail) || [];
    u.forEach((h) => {
      var R;
      (R = h.type) != null && R.startsWith("image") && delete h.url;
    });
    const p = S.setValue(u);
    k && p && k({ value: u });
  };
  se(() => {
    G.actions.registerFileUpload(s.id, x);
  }), oe(() => {
    G.actions.unregisterFileUpload(s.id);
  });
  function ee(l) {
    b = l, n(4, b);
  }
  function le(l) {
    S = l, n(5, S);
  }
  return t.$$set = (l) => {
    "datasourceId" in l && n(15, o = l.datasourceId), "bucket" in l && n(16, f = l.bucket), "key" in l && n(17, r = l.key), "field" in l && n(0, d = l.field), "label" in l && n(1, c = l.label), "disabled" in l && n(2, D = l.disabled), "validation" in l && n(3, E = l.validation), "onChange" in l && n(18, k = l.onChange);
  }, t.$$.update = () => {
    var l;
    t.$$.dirty & /*fieldState*/
    16 && ((l = b == null ? void 0 : b.value) != null && l.length || n(6, A = []));
  }, [
    d,
    c,
    D,
    E,
    b,
    S,
    A,
    F,
    i,
    V,
    M,
    Y,
    Z,
    L,
    $,
    o,
    f,
    r,
    k,
    ee,
    le
  ];
}
class Fe extends ae {
  constructor(e) {
    super(), ne(this, e, be, ge, te, {
      datasourceId: 15,
      bucket: 16,
      key: 17,
      field: 0,
      label: 1,
      disabled: 2,
      validation: 3,
      onChange: 18
    });
  }
}
export {
  Fe as default
};
