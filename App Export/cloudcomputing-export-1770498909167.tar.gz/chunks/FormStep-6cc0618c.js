import { S as P, i as z, s as G, y as H, f as w, z as J, n as m, A as N, k as d, o as F, u as b, v as S, ad as j, B as q, C as D, al as E, F as I, e as K, q as L, G as M, H as O, J as Q, h as R, c as T, m as U, p as V } from "./index-e79f0bb2.js";
import W from "./Placeholder-527c0fd1.js";
function X(n) {
  let t, o, s, a, c;
  const l = (
    /*#slots*/
    n[13].default
  ), r = I(
    l,
    n,
    /*$$scope*/
    n[12],
    null
  );
  return {
    c() {
      t = K("div"), r && r.c();
    },
    m(e, i) {
      w(e, t, i), r && r.m(t, null), s = !0, a || (c = L(o = /*styleable*/
      n[4].call(
        null,
        t,
        /*$component*/
        n[1].styles
      )), a = !0);
    },
    p(e, i) {
      r && r.p && (!s || i & /*$$scope*/
      4096) && M(
        r,
        l,
        e,
        /*$$scope*/
        e[12],
        s ? Q(
          l,
          /*$$scope*/
          e[12],
          i,
          null
        ) : O(
          /*$$scope*/
          e[12]
        ),
        null
      ), o && R(o.update) && i & /*$component*/
      2 && o.update.call(
        null,
        /*$component*/
        e[1].styles
      );
    },
    i(e) {
      s || (d(r, e), s = !0);
    },
    o(e) {
      m(r, e), s = !1;
    },
    d(e) {
      e && F(t), r && r.d(e), a = !1, c();
    }
  };
}
function Y(n) {
  let t, o;
  return t = new W({
    props: {
      text: "Form steps need to be wrapped in a form"
    }
  }), {
    c() {
      T(t.$$.fragment);
    },
    m(s, a) {
      U(t, s, a), o = !0;
    },
    p: q,
    i(s) {
      o || (d(t.$$.fragment, s), o = !0);
    },
    o(s) {
      m(t.$$.fragment, s), o = !1;
    },
    d(s) {
      V(t, s);
    }
  };
}
function Z(n) {
  let t, o, s, a;
  const c = [Y, X], l = [];
  function r(e, i) {
    return (
      /*formContext*/
      e[8] ? (
        /*step*/
        e[0] === /*currentStep*/
        e[2] ? 1 : -1
      ) : 0
    );
  }
  return ~(t = r(n)) && (o = l[t] = c[t](n)), {
    c() {
      o && o.c(), s = H();
    },
    m(e, i) {
      ~t && l[t].m(e, i), w(e, s, i), a = !0;
    },
    p(e, [i]) {
      let p = t;
      t = r(e), t === p ? ~t && l[t].p(e, i) : (o && (J(), m(l[p], 1, 1, () => {
        l[p] = null;
      }), N()), ~t ? (o = l[t], o ? o.p(e, i) : (o = l[t] = c[t](e), o.c()), d(o, 1), o.m(s.parentNode, s)) : o = null);
    },
    i(e) {
      a || (d(o), a = !0);
    },
    o(e) {
      m(o), a = !1;
    },
    d(e) {
      e && F(s), ~t && l[t].d(e);
    }
  };
}
function v(n, t, o) {
  let s, a, c, l, r, e, i = q, p = () => (i(), i = D(s, (u) => o(11, e = u)), s);
  n.$$.on_destroy.push(() => i());
  let { $$slots: A = {}, $$scope: y } = t, { step: _ = 1 } = t;
  const { styleable: B, builderStore: k, componentStore: h } = b("sdk");
  S(n, k, (u) => o(10, r = u)), S(n, h, (u) => o(9, l = u));
  const g = b("component");
  S(n, g, (u) => o(1, c = u));
  const f = b("form"), C = E(_ || 1);
  return j("form-step", C), n.$$set = (u) => {
    "step" in u && o(0, _ = u.step), "$$scope" in u && o(12, y = u.$$scope);
  }, n.$$.update = () => {
    var u;
    n.$$.dirty & /*step*/
    1 && C.set(_ || 1), n.$$.dirty & /*$formState*/
    2048 && o(2, a = e == null ? void 0 : e.currentStep), n.$$.dirty & /*$builderStore, $componentStore, $component, step*/
    1539 && f && r.inBuilder && (u = l.selectedComponentPath) != null && u.includes(c.id) && f.formApi.setStep(_);
  }, p(o(3, s = f == null ? void 0 : f.formState)), [
    _,
    c,
    a,
    s,
    B,
    k,
    h,
    g,
    f,
    l,
    r,
    e,
    y,
    A
  ];
}
class ee extends P {
  constructor(t) {
    super(), z(this, t, v, Z, G, { step: 0 });
  }
}
export {
  ee as default
};
