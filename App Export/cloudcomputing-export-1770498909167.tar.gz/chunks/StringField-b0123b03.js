import { S as z, i as E, s as N, ac as I, ai as T, c as F, m as y, aj as V, k as r, n as m, p as C, y as B, f as D, z as G, A as H, o as J, cE as K, h as L } from "./index-e79f0bb2.js";
import { F as M } from "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function O(e) {
  let l, a;
  return l = new K({
    props: {
      updateOnChange: !1,
      value: (
        /*fieldState*/
        e[12].value
      ),
      disabled: (
        /*fieldState*/
        e[12].disabled
      ),
      readonly: (
        /*fieldState*/
        e[12].readonly
      ),
      id: (
        /*fieldState*/
        e[12].fieldId
      ),
      placeholder: (
        /*placeholder*/
        e[2]
      ),
      type: (
        /*type*/
        e[3]
      ),
      align: (
        /*align*/
        e[8]
      )
    }
  }), l.$on(
    "change",
    /*handleChange*/
    e[14]
  ), l.$on("input", function() {
    L(
      /*runOnInput*/
      e[9] ? (
        /*handleInput*/
        e[15]
      ) : void 0
    ) && /*runOnInput*/
    (e[9] ? (
      /*handleInput*/
      e[15]
    ) : void 0).apply(this, arguments);
  }), {
    c() {
      F(l.$$.fragment);
    },
    m(n, f) {
      y(l, n, f), a = !0;
    },
    p(n, f) {
      e = n;
      const d = {};
      f & /*fieldState*/
      4096 && (d.value = /*fieldState*/
      e[12].value), f & /*fieldState*/
      4096 && (d.disabled = /*fieldState*/
      e[12].disabled), f & /*fieldState*/
      4096 && (d.readonly = /*fieldState*/
      e[12].readonly), f & /*fieldState*/
      4096 && (d.id = /*fieldState*/
      e[12].fieldId), f & /*placeholder*/
      4 && (d.placeholder = /*placeholder*/
      e[2]), f & /*type*/
      8 && (d.type = /*type*/
      e[3]), f & /*align*/
      256 && (d.align = /*align*/
      e[8]), l.$set(d);
    },
    i(n) {
      a || (r(l.$$.fragment, n), a = !0);
    },
    o(n) {
      m(l.$$.fragment, n), a = !1;
    },
    d(n) {
      C(l, n);
    }
  };
}
function P(e) {
  let l, a, n = (
    /*fieldState*/
    e[12] && O(e)
  );
  return {
    c() {
      n && n.c(), l = B();
    },
    m(f, d) {
      n && n.m(f, d), D(f, l, d), a = !0;
    },
    p(f, d) {
      /*fieldState*/
      f[12] ? n ? (n.p(f, d), d & /*fieldState*/
      4096 && r(n, 1)) : (n = O(f), n.c(), r(n, 1), n.m(l.parentNode, l)) : n && (G(), m(n, 1, 1, () => {
        n = null;
      }), H());
    },
    i(f) {
      a || (r(n), a = !0);
    },
    o(f) {
      m(n), a = !1;
    },
    d(f) {
      f && J(l), n && n.d(f);
    }
  };
}
function Q(e) {
  let l, a, n, f;
  function d(t) {
    e[17](t);
  }
  function b(t) {
    e[18](t);
  }
  let _ = {
    label: (
      /*label*/
      e[1]
    ),
    field: (
      /*field*/
      e[0]
    ),
    disabled: (
      /*disabled*/
      e[4]
    ),
    readonly: (
      /*readonly*/
      e[5]
    ),
    validation: (
      /*validation*/
      e[6]
    ),
    defaultValue: (
      /*defaultValue*/
      e[7]
    ),
    span: (
      /*span*/
      e[10]
    ),
    helpText: (
      /*helpText*/
      e[11]
    ),
    type: (
      /*type*/
      e[3] === "number" ? "number" : "string"
    ),
    $$slots: { default: [P] },
    $$scope: { ctx: e }
  };
  return (
    /*fieldState*/
    e[12] !== void 0 && (_.fieldState = /*fieldState*/
    e[12]), /*fieldApi*/
    e[13] !== void 0 && (_.fieldApi = /*fieldApi*/
    e[13]), l = new M({ props: _ }), I.push(() => T(l, "fieldState", d)), I.push(() => T(l, "fieldApi", b)), {
      c() {
        F(l.$$.fragment);
      },
      m(t, u) {
        y(l, t, u), f = !0;
      },
      p(t, [u]) {
        const s = {};
        u & /*label*/
        2 && (s.label = /*label*/
        t[1]), u & /*field*/
        1 && (s.field = /*field*/
        t[0]), u & /*disabled*/
        16 && (s.disabled = /*disabled*/
        t[4]), u & /*readonly*/
        32 && (s.readonly = /*readonly*/
        t[5]), u & /*validation*/
        64 && (s.validation = /*validation*/
        t[6]), u & /*defaultValue*/
        128 && (s.defaultValue = /*defaultValue*/
        t[7]), u & /*span*/
        1024 && (s.span = /*span*/
        t[10]), u & /*helpText*/
        2048 && (s.helpText = /*helpText*/
        t[11]), u & /*type*/
        8 && (s.type = /*type*/
        t[3] === "number" ? "number" : "string"), u & /*$$scope, fieldState, placeholder, type, align, runOnInput*/
        529164 && (s.$$scope = { dirty: u, ctx: t }), !a && u & /*fieldState*/
        4096 && (a = !0, s.fieldState = /*fieldState*/
        t[12], V(() => a = !1)), !n && u & /*fieldApi*/
        8192 && (n = !0, s.fieldApi = /*fieldApi*/
        t[13], V(() => n = !1)), l.$set(s);
      },
      i(t) {
        f || (r(l.$$.fragment, t), f = !0);
      },
      o(t) {
        m(l.$$.fragment, t), f = !1;
      },
      d(t) {
        C(l, t);
      }
    }
  );
}
function R(e, l, a) {
  let { field: n } = l, { label: f } = l, { placeholder: d } = l, { type: b = "text" } = l, { disabled: _ = !1 } = l, { readonly: t = !1 } = l, { validation: u } = l, { defaultValue: s = "" } = l, { align: c } = l, { onChange: o } = l, { runOnInput: S = !1 } = l, { span: A } = l, { helpText: k = null } = l, h, g;
  const v = (i) => {
    g.setValue(i.detail) && (o == null || o({ value: i.detail }));
  }, w = (i) => {
    o == null || o({ value: i.target.value });
  };
  function j(i) {
    h = i, a(12, h);
  }
  function q(i) {
    g = i, a(13, g);
  }
  return e.$$set = (i) => {
    "field" in i && a(0, n = i.field), "label" in i && a(1, f = i.label), "placeholder" in i && a(2, d = i.placeholder), "type" in i && a(3, b = i.type), "disabled" in i && a(4, _ = i.disabled), "readonly" in i && a(5, t = i.readonly), "validation" in i && a(6, u = i.validation), "defaultValue" in i && a(7, s = i.defaultValue), "align" in i && a(8, c = i.align), "onChange" in i && a(16, o = i.onChange), "runOnInput" in i && a(9, S = i.runOnInput), "span" in i && a(10, A = i.span), "helpText" in i && a(11, k = i.helpText);
  }, [
    n,
    f,
    d,
    b,
    _,
    t,
    u,
    s,
    c,
    S,
    A,
    k,
    h,
    g,
    v,
    w,
    o,
    j,
    q
  ];
}
class p extends z {
  constructor(l) {
    super(), E(this, l, R, Q, N, {
      field: 0,
      label: 1,
      placeholder: 2,
      type: 3,
      disabled: 4,
      readonly: 5,
      validation: 6,
      defaultValue: 7,
      align: 8,
      onChange: 16,
      runOnInput: 9,
      span: 10,
      helpText: 11
    });
  }
}
export {
  p as default
};
