import { S as w, i as y, s as $, e as S, f as M, q, z as B, n as _, A as C, k as p, h as V, o as z, u as k, v as b, c as g, m as h, B as A, p as v } from "./index-e79f0bb2.js";
import { M as P } from "./MarkdownViewer-8bfac1b0.js";
import j from "./Placeholder-527c0fd1.js";
function D(o) {
  let n, t;
  return n = new j({}), {
    c() {
      g(n.$$.fragment);
    },
    m(e, l) {
      h(n, e, l), t = !0;
    },
    p: A,
    i(e) {
      t || (p(n.$$.fragment, e), t = !0);
    },
    o(e) {
      _(n.$$.fragment, e), t = !1;
    },
    d(e) {
      v(n, e);
    }
  };
}
function E(o) {
  let n, t;
  return n = new P({
    props: {
      value: (
        /*value*/
        o[0]
      ),
      height: (
        /*height*/
        o[6]
      )
    }
  }), {
    c() {
      g(n.$$.fragment);
    },
    m(e, l) {
      h(n, e, l), t = !0;
    },
    p(e, l) {
      const a = {};
      l & /*value*/
      1 && (a.value = /*value*/
      e[0]), n.$set(a);
    },
    i(e) {
      t || (p(n.$$.fragment, e), t = !0);
    },
    o(e) {
      _(n.$$.fragment, e), t = !1;
    },
    d(e) {
      v(n, e);
    }
  };
}
function F(o) {
  let n, t, e, l, a, u, c;
  const m = [E, D], i = [];
  function f(r, s) {
    return (
      /*value*/
      r[0] ? 0 : (
        /*$builderStore*/
        r[2].inBuilder ? 1 : -1
      )
    );
  }
  return ~(t = f(o)) && (e = i[t] = m[t](o)), {
    c() {
      n = S("div"), e && e.c();
    },
    m(r, s) {
      M(r, n, s), ~t && i[t].m(n, null), a = !0, u || (c = q(l = /*styleable*/
      o[5].call(
        null,
        n,
        /*$component*/
        o[1].styles
      )), u = !0);
    },
    p(r, [s]) {
      let d = t;
      t = f(r), t === d ? ~t && i[t].p(r, s) : (e && (B(), _(i[d], 1, 1, () => {
        i[d] = null;
      }), C()), ~t ? (e = i[t], e ? e.p(r, s) : (e = i[t] = m[t](r), e.c()), p(e, 1), e.m(n, null)) : e = null), l && V(l.update) && s & /*$component*/
      2 && l.update.call(
        null,
        /*$component*/
        r[1].styles
      );
    },
    i(r) {
      a || (p(e), a = !0);
    },
    o(r) {
      _(e), a = !1;
    },
    d(r) {
      r && z(n), ~t && i[t].d(), u = !1, c();
    }
  };
}
function G(o, n, t) {
  var f, r;
  let e, l, { value: a } = n;
  const u = k("component");
  b(o, u, (s) => t(1, e = s));
  const { builderStore: c, styleable: m } = k("sdk");
  b(o, c, (s) => t(2, l = s));
  const i = (r = (f = e.styles) == null ? void 0 : f.normal) == null ? void 0 : r.height;
  return o.$$set = (s) => {
    "value" in s && t(0, a = s.value);
  }, [a, e, l, u, c, m, i];
}
class K extends w {
  constructor(n) {
    super(), y(this, n, G, F, $, { value: 0 });
  }
}
export {
  K as default
};
