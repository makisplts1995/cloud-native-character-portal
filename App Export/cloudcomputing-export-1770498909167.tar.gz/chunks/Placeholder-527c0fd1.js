import { S as b, i as k, s as h, y as v, f as _, B as f, o as p, u as c, v as u, e as y, t as P, b as S, g as B, j as g } from "./index-e79f0bb2.js";
function m(s) {
  var o;
  let n, e = (
    /*text*/
    (s[0] || /*block*/
    ((o = s[5]) == null ? void 0 : o.name) || /*$component*/
    s[2].name || "Placeholder") + ""
  ), t;
  return {
    c() {
      n = y("div"), t = P(e), S(n, "class", "svelte-16hk7sb");
    },
    m(l, a) {
      _(l, n, a), B(n, t);
    },
    p(l, a) {
      var r;
      a & /*text, $component*/
      5 && e !== (e = /*text*/
      (l[0] || /*block*/
      ((r = l[5]) == null ? void 0 : r.name) || /*$component*/
      l[2].name || "Placeholder") + "") && g(t, e);
    },
    d(l) {
      l && p(n);
    }
  };
}
function C(s) {
  let n, e = (
    /*$builderStore*/
    s[1].inBuilder && m(s)
  );
  return {
    c() {
      e && e.c(), n = v();
    },
    m(t, o) {
      e && e.m(t, o), _(t, n, o);
    },
    p(t, [o]) {
      /*$builderStore*/
      t[1].inBuilder ? e ? e.p(t, o) : (e = m(t), e.c(), e.m(n.parentNode, n)) : e && (e.d(1), e = null);
    },
    i: f,
    o: f,
    d(t) {
      t && p(n), e && e.d(t);
    }
  };
}
function j(s, n, e) {
  let t, o;
  const { builderStore: l } = c("sdk");
  u(s, l, (i) => e(1, t = i));
  const a = c("component");
  u(s, a, (i) => e(2, o = i));
  const r = c("block");
  let { text: d = void 0 } = n;
  return s.$$set = (i) => {
    "text" in i && e(0, d = i.text);
  }, [d, t, o, l, a, r];
}
class x extends b {
  constructor(n) {
    super(), k(this, n, j, C, h, { text: 0 });
  }
}
export {
  x as default
};
