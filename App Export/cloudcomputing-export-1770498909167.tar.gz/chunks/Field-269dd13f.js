import { S as Ve, i as Ce, s as ie, c as V, m as C, k as h, n as S, p as j, u as z, v as Q, al as ne, bd as je, w as qe, bL as W, bM as $, y as fe, f as v, o as T, ac as H, e as P, a as E, b as y, d as F, g as A, q as ze, z as se, A as ae, h as oe, t as X, aJ as ee, l as le, cg as Me, r as Je, ai as R, c7 as Be, c8 as De, aj as U, F as re, G as ue, H as de, J as _e, B as ce, I as me, j as be } from "./index-e79f0bb2.js";
import pe from "./Placeholder-527c0fd1.js";
import { I as He } from "./InnerForm-04bc2863.js";
function Ee(t) {
  let e, l = (
    /*$component*/
    t[10].editing
  ), i, n, o, r, a, u, d, m, s, _ = te(t);
  const b = [Oe, Ne, Ke], g = [];
  function k(c, p) {
    return p[0] & /*schemaType, type*/
    8208 && (o = null), /*fieldState*/
    c[1] ? (o == null && (o = !!/*schemaType*/
    (c[13] && /*schemaType*/
    c[13] !== /*type*/
    c[4] && !["options", "longform"].includes(
      /*type*/
      c[4]
    ))), o ? 1 : 2) : 0;
  }
  return r = k(t, [-1, -1]), a = g[r] = b[r](t), {
    c() {
      e = P("div"), _.c(), i = E(), n = P("div"), a.c(), y(n, "class", "spectrum-Form-itemField svelte-87iude"), y(e, "class", "spectrum-Form-item svelte-87iude"), F(
        e,
        "span-2",
        /*span*/
        t[7] === 2
      ), F(
        e,
        "span-3",
        /*span*/
        t[7] === 3
      ), F(
        e,
        "span-6",
        /*span*/
        t[7] === 6 || !/*span*/
        t[7]
      ), F(
        e,
        "above",
        /*labelPos*/
        t[18] === "above"
      );
    },
    m(c, p) {
      v(c, e, p), _.m(e, null), A(e, i), A(e, n), g[r].m(n, null), d = !0, m || (s = ze(u = /*styleable*/
      t[15].call(
        null,
        e,
        /*$component*/
        t[10].styles
      )), m = !0);
    },
    p(c, p) {
      p[0] & /*$component*/
      1024 && ie(l, l = /*$component*/
      c[10].editing) ? (_.d(1), _ = te(c), _.c(), _.m(e, i)) : _.p(c, p);
      let L = r;
      r = k(c, p), r === L ? g[r].p(c, p) : (se(), S(g[L], 1, 1, () => {
        g[L] = null;
      }), ae(), a = g[r], a ? a.p(c, p) : (a = g[r] = b[r](c), a.c()), h(a, 1), a.m(n, null)), u && oe(u.update) && p[0] & /*$component*/
      1024 && u.update.call(
        null,
        /*$component*/
        c[10].styles
      ), (!d || p[0] & /*span*/
      128) && F(
        e,
        "span-2",
        /*span*/
        c[7] === 2
      ), (!d || p[0] & /*span*/
      128) && F(
        e,
        "span-3",
        /*span*/
        c[7] === 3
      ), (!d || p[0] & /*span*/
      128) && F(
        e,
        "span-6",
        /*span*/
        c[7] === 6 || !/*span*/
        c[7]
      );
    },
    i(c) {
      d || (h(a), d = !0);
    },
    o(c) {
      S(a), d = !1;
    },
    d(c) {
      c && T(e), _.d(c), g[r].d(), m = !1, s();
    }
  };
}
function Ge(t) {
  let e, l;
  return e = new He({
    props: {
      disabled: (
        /*disabled*/
        t[5]
      ),
      readonly: (
        /*readonly*/
        t[6]
      ),
      currentStep: ne(1),
      provideContext: !1,
      $$slots: { default: [We] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      V(e.$$.fragment);
    },
    m(i, n) {
      C(e, i, n), l = !0;
    },
    p(i, n) {
      const o = {};
      n[0] & /*disabled*/
      32 && (o.disabled = /*disabled*/
      i[5]), n[0] & /*readonly*/
      64 && (o.readonly = /*readonly*/
      i[6]), n[0] & /*$$props, fieldState, fieldApi, fieldSchema*/
      4194311 | n[1] & /*$$scope*/
      16 && (o.$$scope = { dirty: n, ctx: i }), e.$set(o);
    },
    i(i) {
      l || (h(e.$$.fragment, i), l = !0);
    },
    o(i) {
      S(e.$$.fragment, i), l = !1;
    },
    d(i) {
      j(e, i);
    }
  };
}
function te(t) {
  let e, l = (
    /*label*/
    (t[3] || " ") + ""
  ), i, n, o, r, a, u;
  return {
    c() {
      var d;
      e = P("label"), i = X(l), y(e, "contenteditable", n = /*$component*/
      t[10].editing), y(e, "for", o = /*fieldState*/
      (d = t[1]) == null ? void 0 : d.fieldId), y(e, "class", r = ee(`spectrum-FieldLabel spectrum-FieldLabel--sizeM spectrum-Form-itemLabel ${/*labelClass*/
      t[12]}`) + " svelte-87iude"), F(e, "hidden", !/*label*/
      t[3]), F(
        e,
        "readonly",
        /*readonly*/
        t[6]
      );
    },
    m(d, m) {
      v(d, e, m), A(e, i), t[33](e), a || (u = [
        le(e, "blur", function() {
          oe(
            /*$component*/
            t[10].editing ? (
              /*updateLabel*/
              t[21]
            ) : null
          ) && /*$component*/
          (t[10].editing ? (
            /*updateLabel*/
            t[21]
          ) : null).apply(this, arguments);
        }),
        le(
          e,
          "input",
          /*input_handler*/
          t[34]
        )
      ], a = !0);
    },
    p(d, m) {
      var s;
      t = d, m[0] & /*label*/
      8 && l !== (l = /*label*/
      (t[3] || " ") + "") && Me(
        i,
        l,
        /*$component*/
        t[10].editing
      ), m[0] & /*$component*/
      1024 && n !== (n = /*$component*/
      t[10].editing) && y(e, "contenteditable", n), m[0] & /*fieldState*/
      2 && o !== (o = /*fieldState*/
      (s = t[1]) == null ? void 0 : s.fieldId) && y(e, "for", o), m[0] & /*labelClass*/
      4096 && r !== (r = ee(`spectrum-FieldLabel spectrum-FieldLabel--sizeM spectrum-Form-itemLabel ${/*labelClass*/
      t[12]}`) + " svelte-87iude") && y(e, "class", r), m[0] & /*labelClass, label*/
      4104 && F(e, "hidden", !/*label*/
      t[3]), m[0] & /*labelClass, readonly*/
      4160 && F(
        e,
        "readonly",
        /*readonly*/
        t[6]
      );
    },
    d(d) {
      d && T(e), t[33](null), a = !1, Je(u);
    }
  };
}
function Ke(t) {
  let e, l, i, n, o;
  const r = (
    /*#slots*/
    t[29].default
  ), a = re(
    r,
    t,
    /*$$scope*/
    t[35],
    null
  ), u = [Re, Qe], d = [];
  function m(s, _) {
    return (
      /*fieldState*/
      s[1].error ? 0 : (
        /*helpText*/
        s[8] ? 1 : -1
      )
    );
  }
  return ~(l = m(t)) && (i = d[l] = u[l](t)), {
    c() {
      a && a.c(), e = E(), i && i.c(), n = fe();
    },
    m(s, _) {
      a && a.m(s, _), v(s, e, _), ~l && d[l].m(s, _), v(s, n, _), o = !0;
    },
    p(s, _) {
      a && a.p && (!o || _[1] & /*$$scope*/
      16) && ue(
        a,
        r,
        s,
        /*$$scope*/
        s[35],
        o ? _e(
          r,
          /*$$scope*/
          s[35],
          _,
          null
        ) : de(
          /*$$scope*/
          s[35]
        ),
        null
      );
      let b = l;
      l = m(s), l === b ? ~l && d[l].p(s, _) : (i && (se(), S(d[b], 1, 1, () => {
        d[b] = null;
      }), ae()), ~l ? (i = d[l], i ? i.p(s, _) : (i = d[l] = u[l](s), i.c()), h(i, 1), i.m(n.parentNode, n)) : i = null);
    },
    i(s) {
      o || (h(a, s), h(i), o = !0);
    },
    o(s) {
      S(a, s), S(i), o = !1;
    },
    d(s) {
      s && (T(e), T(n)), a && a.d(s), ~l && d[l].d(s);
    }
  };
}
function Ne(t) {
  let e, l;
  return e = new pe({
    props: {
      text: "This Field setting is the wrong data type for this component"
    }
  }), {
    c() {
      V(e.$$.fragment);
    },
    m(i, n) {
      C(e, i, n), l = !0;
    },
    p: ce,
    i(i) {
      l || (h(e.$$.fragment, i), l = !0);
    },
    o(i) {
      S(e.$$.fragment, i), l = !1;
    },
    d(i) {
      j(e, i);
    }
  };
}
function Oe(t) {
  let e, l;
  return e = new pe({}), {
    c() {
      V(e.$$.fragment);
    },
    m(i, n) {
      C(e, i, n), l = !0;
    },
    p: ce,
    i(i) {
      l || (h(e.$$.fragment, i), l = !0);
    },
    o(i) {
      S(e.$$.fragment, i), l = !1;
    },
    d(i) {
      j(e, i);
    }
  };
}
function Qe(t) {
  let e, l, i, n, o, r;
  return l = new me({ props: { name: "question" } }), {
    c() {
      e = P("div"), V(l.$$.fragment), i = E(), n = P("span"), o = X(
        /*helpText*/
        t[8]
      ), y(n, "class", "svelte-87iude"), y(e, "class", "helpText svelte-87iude");
    },
    m(a, u) {
      v(a, e, u), C(l, e, null), A(e, i), A(e, n), A(n, o), r = !0;
    },
    p(a, u) {
      (!r || u[0] & /*helpText*/
      256) && be(
        o,
        /*helpText*/
        a[8]
      );
    },
    i(a) {
      r || (h(l.$$.fragment, a), r = !0);
    },
    o(a) {
      S(l.$$.fragment, a), r = !1;
    },
    d(a) {
      a && T(e), j(l);
    }
  };
}
function Re(t) {
  let e, l, i, n, o = (
    /*fieldState*/
    t[1].error + ""
  ), r, a;
  return l = new me({ props: { name: "warning" } }), {
    c() {
      e = P("div"), V(l.$$.fragment), i = E(), n = P("span"), r = X(o), y(n, "class", "svelte-87iude"), y(e, "class", "error svelte-87iude");
    },
    m(u, d) {
      v(u, e, d), C(l, e, null), A(e, i), A(e, n), A(n, r), a = !0;
    },
    p(u, d) {
      (!a || d[0] & /*fieldState*/
      2) && o !== (o = /*fieldState*/
      u[1].error + "") && be(r, o);
    },
    i(u) {
      a || (h(l.$$.fragment, u), a = !0);
    },
    o(u) {
      S(l.$$.fragment, u), a = !1;
    },
    d(u) {
      u && T(e), j(l);
    }
  };
}
function Ue(t) {
  let e;
  const l = (
    /*#slots*/
    t[29].default
  ), i = re(
    l,
    t,
    /*$$scope*/
    t[35],
    null
  );
  return {
    c() {
      i && i.c();
    },
    m(n, o) {
      i && i.m(n, o), e = !0;
    },
    p(n, o) {
      i && i.p && (!e || o[1] & /*$$scope*/
      16) && ue(
        i,
        l,
        n,
        /*$$scope*/
        n[35],
        e ? _e(
          l,
          /*$$scope*/
          n[35],
          o,
          null
        ) : de(
          /*$$scope*/
          n[35]
        ),
        null
      );
    },
    i(n) {
      e || (h(i, n), e = !0);
    },
    o(n) {
      S(i, n), e = !1;
    },
    d(n) {
      i && i.d(n);
    }
  };
}
function We(t) {
  let e, l, i, n, o;
  const r = [
    /*$$props*/
    t[22]
  ];
  function a(s) {
    t[30](s);
  }
  function u(s) {
    t[31](s);
  }
  function d(s) {
    t[32](s);
  }
  let m = {
    $$slots: { default: [Ue] },
    $$scope: { ctx: t }
  };
  for (let s = 0; s < r.length; s += 1)
    m = W(m, r[s]);
  return (
    /*fieldState*/
    t[1] !== void 0 && (m.fieldState = /*fieldState*/
    t[1]), /*fieldApi*/
    t[2] !== void 0 && (m.fieldApi = /*fieldApi*/
    t[2]), /*fieldSchema*/
    t[0] !== void 0 && (m.fieldSchema = /*fieldSchema*/
    t[0]), e = new we({ props: m }), H.push(() => R(e, "fieldState", a)), H.push(() => R(e, "fieldApi", u)), H.push(() => R(e, "fieldSchema", d)), {
      c() {
        V(e.$$.fragment);
      },
      m(s, _) {
        C(e, s, _), o = !0;
      },
      p(s, _) {
        const b = _[0] & /*$$props*/
        4194304 ? Be(r, [De(
          /*$$props*/
          s[22]
        )]) : {};
        _[1] & /*$$scope*/
        16 && (b.$$scope = { dirty: _, ctx: s }), !l && _[0] & /*fieldState*/
        2 && (l = !0, b.fieldState = /*fieldState*/
        s[1], U(() => l = !1)), !i && _[0] & /*fieldApi*/
        4 && (i = !0, b.fieldApi = /*fieldApi*/
        s[2], U(() => i = !1)), !n && _[0] & /*fieldSchema*/
        1 && (n = !0, b.fieldSchema = /*fieldSchema*/
        s[0], U(() => n = !1)), e.$set(b);
      },
      i(s) {
        o || (h(e.$$.fragment, s), o = !0);
      },
      o(s) {
        S(e.$$.fragment, s), o = !1;
      },
      d(s) {
        j(e, s);
      }
    }
  );
}
function Xe(t) {
  let e, l, i, n;
  const o = [Ge, Ee], r = [];
  function a(u, d) {
    return (
      /*formContext*/
      u[14] ? 1 : 0
    );
  }
  return e = a(t), l = r[e] = o[e](t), {
    c() {
      l.c(), i = fe();
    },
    m(u, d) {
      r[e].m(u, d), v(u, i, d), n = !0;
    },
    p(u, d) {
      l.p(u, d);
    },
    i(u) {
      n || (h(l), n = !0);
    },
    o(u) {
      S(l), n = !1;
    },
    d(u) {
      u && T(i), r[e].d(u);
    }
  };
}
function Ye(t) {
  var i;
  let e, l;
  return e = new /*Provider*/
  t[16]({
    props: {
      data: { value: (
        /*fieldState*/
        (i = t[1]) == null ? void 0 : i.value
      ) },
      $$slots: { default: [Xe] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      V(e.$$.fragment);
    },
    m(n, o) {
      C(e, n, o), l = !0;
    },
    p(n, o) {
      var a;
      const r = {};
      o[0] & /*fieldState*/
      2 && (r.data = { value: (
        /*fieldState*/
        (a = n[1]) == null ? void 0 : a.value
      ) }), o[0] & /*disabled, readonly, $$props, fieldState, fieldApi, fieldSchema, $component, span, schemaType, type, helpText, labelClass, labelNode, label, touched*/
      4210687 | o[1] & /*$$scope*/
      16 && (r.$$scope = { dirty: o, ctx: n }), e.$set(r);
    },
    i(n) {
      l || (h(e.$$.fragment, n), l = !0);
    },
    o(n) {
      S(e.$$.fragment, n), l = !1;
    },
    d(n) {
      j(e, n);
    }
  };
}
function Ze(t, e, l) {
  let i, n, o, r, a, u, { $$slots: d = {}, $$scope: m } = e, { label: s = void 0 } = e, { field: _ = void 0 } = e, { fieldState: b } = e, { fieldApi: g } = e, { fieldSchema: k } = e, { defaultValue: c = void 0 } = e, { type: p } = e, { disabled: L = !1 } = e, { readonly: M = !1 } = e, { validation: J } = e, { span: Y = 6 } = e, { helpText: Z = void 0 } = e;
  const B = z("form"), ge = z("form-step"), G = z("field-group"), { styleable: ke, builderStore: he, Provider: Se } = z("sdk"), w = z("component");
  Q(t, w, (f) => l(10, r = f));
  const K = B == null ? void 0 : B.formApi, N = (G == null ? void 0 : G.labelPosition) || "above";
  let I, D = !1, q;
  const x = ge || ne(1);
  Q(t, x, (f) => l(28, u = f));
  const O = je({
    field: _ || r.name,
    type: p,
    defaultValue: c,
    disabled: L,
    readonly: M,
    validation: J,
    formStep: u || 1
  });
  Q(t, O, (f) => l(27, a = f));
  const ye = (f) => {
    l(26, I = K == null ? void 0 : K.registerField(f.field, f.type, f.defaultValue, f.disabled, f.readonly, f.validation, f.formStep));
  }, Fe = (f) => {
    if (D) {
      const Pe = f.target;
      he.actions.updateProp("label", Pe.textContent);
    }
    l(11, D = !1);
  };
  qe(() => {
    g == null || g.deregister(), n == null || n();
  });
  function Ae(f) {
    b = f, l(1, b), l(26, I);
  }
  function Le(f) {
    g = f, l(2, g), l(26, I);
  }
  function Ie(f) {
    k = f, l(0, k), l(26, I);
  }
  function ve(f) {
    H[f ? "unshift" : "push"](() => {
      q = f, l(9, q);
    });
  }
  const Te = () => l(11, D = !0);
  return t.$$set = (f) => {
    l(22, e = W(W({}, e), $(f))), "label" in f && l(3, s = f.label), "field" in f && l(23, _ = f.field), "fieldState" in f && l(1, b = f.fieldState), "fieldApi" in f && l(2, g = f.fieldApi), "fieldSchema" in f && l(0, k = f.fieldSchema), "defaultValue" in f && l(24, c = f.defaultValue), "type" in f && l(4, p = f.type), "disabled" in f && l(5, L = f.disabled), "readonly" in f && l(6, M = f.readonly), "validation" in f && l(25, J = f.validation), "span" in f && l(7, Y = f.span), "helpText" in f && l(8, Z = f.helpText), "$$scope" in f && l(35, m = f.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*field, $component, type, defaultValue, disabled, readonly, validation, $formStep*/
    327156848 && O.set({
      field: _ || r.name,
      type: p,
      defaultValue: c,
      disabled: L,
      readonly: M,
      validation: J,
      formStep: u || 1
    }), t.$$.dirty[0] & /*$fieldInfo*/
    134217728 && ye(a), t.$$.dirty[0] & /*formField*/
    67108864 && (n = I == null ? void 0 : I.subscribe((f) => {
      l(1, b = f == null ? void 0 : f.fieldState), l(2, g = f == null ? void 0 : f.fieldApi), l(0, k = f == null ? void 0 : f.fieldSchema);
    })), t.$$.dirty[0] & /*fieldSchema*/
    1 && l(13, i = (k == null ? void 0 : k.type) !== "formula" && (k == null ? void 0 : k.type) !== "bigint" ? k == null ? void 0 : k.type : "string"), t.$$.dirty[0] & /*$component, labelNode*/
    1536 && r.editing && (q == null || q.focus());
  }, l(12, o = N === "above" ? "" : `spectrum-FieldLabel--${N}`), e = $(e), [
    k,
    b,
    g,
    s,
    p,
    L,
    M,
    Y,
    Z,
    q,
    r,
    D,
    o,
    i,
    B,
    ke,
    Se,
    w,
    N,
    x,
    O,
    Fe,
    e,
    _,
    c,
    J,
    I,
    a,
    u,
    d,
    Ae,
    Le,
    Ie,
    ve,
    Te,
    m
  ];
}
class we extends Ve {
  constructor(e) {
    super(), Ce(
      this,
      e,
      Ze,
      Ye,
      ie,
      {
        label: 3,
        field: 23,
        fieldState: 1,
        fieldApi: 2,
        fieldSchema: 0,
        defaultValue: 24,
        type: 4,
        disabled: 5,
        readonly: 6,
        validation: 25,
        span: 7,
        helpText: 8
      },
      null,
      [-1, -1]
    );
  }
}
export {
  we as F
};
