import { S as m, i as _, s as f, bL as o, c as g, m as p, c7 as u, c8 as d, k as b, n as h, p as x, bM as c } from "./index-e79f0bb2.js";
import S from "./StringField-b0123b03.js";
import "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function v(r) {
  let t, n;
  const s = [
    /*$$props*/
    r[0],
    { type: "bigint" }
  ];
  let i = {};
  for (let e = 0; e < s.length; e += 1)
    i = o(i, s[e]);
  return t = new S({ props: i }), {
    c() {
      g(t.$$.fragment);
    },
    m(e, a) {
      p(t, e, a), n = !0;
    },
    p(e, [a]) {
      const l = a & /*$$props*/
      1 ? u(s, [d(
        /*$$props*/
        e[0]
      ), s[1]]) : {};
      t.$set(l);
    },
    i(e) {
      n || (b(t.$$.fragment, e), n = !0);
    },
    o(e) {
      h(t.$$.fragment, e), n = !1;
    },
    d(e) {
      x(t, e);
    }
  };
}
function y(r, t, n) {
  return r.$$set = (s) => {
    n(0, t = o(o({}, t), c(s)));
  }, t = c(t), [t];
}
class B extends m {
  constructor(t) {
    super(), _(this, t, y, v, f, {});
  }
}
export {
  B as default
};
