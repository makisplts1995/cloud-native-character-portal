import { S as Pe, i as Re, s as He, y as Je, f as le, z as Ye, n as z, A as Ke, k as T, o as re, u as Se, v as Le, al as ee, aT as V, ad as pe, ak as te, B as w, C as D, bV as Qe, co as ye, cp as We, cq as Xe, aO as Ze, F as Ve, e as Fe, b as M, q as he, G as ve, H as Ae, J as ge, h as ke, c as xe, m as $e, p as et, b2 as tt } from "./index-e79f0bb2.js";
function lt(s) {
  let l, t, i, d, y;
  const m = (
    /*#slots*/
    s[29].default
  ), a = Ve(
    m,
    s,
    /*$$scope*/
    s[30],
    null
  );
  return {
    c() {
      l = Fe("div"), a && a.c(), M(
        l,
        "class",
        /*size*/
        s[0]
      );
    },
    m(r, f) {
      le(r, l, f), a && a.m(l, null), i = !0, d || (y = he(t = /*styleable*/
      s[10].call(
        null,
        l,
        /*$component*/
        s[8].styles
      )), d = !0);
    },
    p(r, f) {
      a && a.p && (!i || f[0] & /*$$scope*/
      1073741824) && ve(
        a,
        m,
        r,
        /*$$scope*/
        r[30],
        i ? ge(
          m,
          /*$$scope*/
          r[30],
          f,
          null
        ) : Ae(
          /*$$scope*/
          r[30]
        ),
        null
      ), (!i || f[0] & /*size*/
      1) && M(
        l,
        "class",
        /*size*/
        r[0]
      ), t && ke(t.update) && f[0] & /*$component*/
      256 && t.update.call(
        null,
        /*$component*/
        r[8].styles
      );
    },
    i(r) {
      i || (T(a, r), i = !0);
    },
    o(r) {
      z(a, r), i = !1;
    },
    d(r) {
      r && re(l), a && a.d(r), d = !1, y();
    }
  };
}
function rt(s) {
  let l, t;
  return l = new /*Provider*/
  s[11]({
    props: {
      actions: (
        /*actions*/
        s[12]
      ),
      data: (
        /*dataContext*/
        s[3]
      ),
      $$slots: { default: [nt] },
      $$scope: { ctx: s }
    }
  }), {
    c() {
      xe(l.$$.fragment);
    },
    m(i, d) {
      $e(l, i, d), t = !0;
    },
    p(i, d) {
      const y = {};
      d[0] & /*dataContext*/
      8 && (y.data = /*dataContext*/
      i[3]), d[0] & /*$$scope, size, $component*/
      1073742081 && (y.$$scope = { dirty: d, ctx: i }), l.$set(y);
    },
    i(i) {
      t || (T(l.$$.fragment, i), t = !0);
    },
    o(i) {
      z(l.$$.fragment, i), t = !1;
    },
    d(i) {
      et(l, i);
    }
  };
}
function nt(s) {
  let l, t, i, d, y;
  const m = (
    /*#slots*/
    s[29].default
  ), a = Ve(
    m,
    s,
    /*$$scope*/
    s[30],
    null
  );
  return {
    c() {
      l = Fe("div"), a && a.c(), M(
        l,
        "class",
        /*size*/
        s[0]
      );
    },
    m(r, f) {
      le(r, l, f), a && a.m(l, null), i = !0, d || (y = he(t = /*styleable*/
      s[10].call(
        null,
        l,
        /*$component*/
        s[8].styles
      )), d = !0);
    },
    p(r, f) {
      a && a.p && (!i || f[0] & /*$$scope*/
      1073741824) && ve(
        a,
        m,
        r,
        /*$$scope*/
        r[30],
        i ? ge(
          m,
          /*$$scope*/
          r[30],
          f,
          null
        ) : Ae(
          /*$$scope*/
          r[30]
        ),
        null
      ), (!i || f[0] & /*size*/
      1) && M(
        l,
        "class",
        /*size*/
        r[0]
      ), t && ke(t.update) && f[0] & /*$component*/
      256 && t.update.call(
        null,
        /*$component*/
        r[8].styles
      );
    },
    i(r) {
      i || (T(a, r), i = !0);
    },
    o(r) {
      z(a, r), i = !1;
    },
    d(r) {
      r && re(l), a && a.d(r), d = !1, y();
    }
  };
}
function st(s) {
  let l, t, i, d;
  const y = [rt, lt], m = [];
  function a(r, f) {
    return (
      /*provideContext*/
      r[1] ? 0 : 1
    );
  }
  return l = a(s), t = m[l] = y[l](s), {
    c() {
      t.c(), i = Je();
    },
    m(r, f) {
      m[l].m(r, f), le(r, i, f), d = !0;
    },
    p(r, f) {
      let k = l;
      l = a(r), l === k ? m[l].p(r, f) : (Ye(), z(m[k], 1, 1, () => {
        m[k] = null;
      }), Ke(), t = m[l], t ? t.p(r, f) : (t = m[l] = y[l](r), t.c()), T(t, 1), t.m(i.parentNode, i));
    },
    i(r) {
      d || (T(t), d = !0);
    },
    o(r) {
      z(t), d = !1;
    },
    d(r) {
      r && re(i), m[l].d(r);
    }
  };
}
function it(s, l, t) {
  let i, d, y, m, a, r, f, k, P = w, Ce = () => (P(), P = D(a, (e) => t(24, k = e)), a), q, R = w, ne = () => (R(), R = D(F, (e) => t(25, q = e)), F), H, J = w, Ie = () => (J(), J = D(y, (e) => t(26, H = e)), y), O, Y = w, Ee = () => (Y(), Y = D(i, (e) => t(27, O = e)), i), j, K = w, Ue = () => (K(), K = D(d, (e) => t(28, j = e)), d), se;
  s.$$.on_destroy.push(() => P()), s.$$.on_destroy.push(() => R()), s.$$.on_destroy.push(() => J()), s.$$.on_destroy.push(() => Y()), s.$$.on_destroy.push(() => K());
  let { $$slots: we = {}, $$scope: ie } = l, { dataSource: L = void 0 } = l, { disabled: B = !1 } = l, { readonly: Q = !1 } = l, { initialValues: N = void 0 } = l, { size: oe = void 0 } = l, { schema: b = void 0 } = l, { definition: W = void 0 } = l, { disableSchemaValidation: X = !1 } = l, { editAutoColumns: Z = !1 } = l, { provideContext: ae = !0 } = l, { currentStep: F } = l;
  ne();
  const ue = Se("component");
  Le(s, ue, (e) => t(8, se = e));
  const { styleable: De, Provider: ze, ActionTypes: U } = Se("sdk");
  let h = [];
  const ce = ee({
    values: {},
    errors: {},
    valid: !0,
    currentStep: V(F)
  }), de = (e, n) => te(e, (o) => o.reduce((c, S) => ({ ...c, [S.name]: n(S) }), {})), Te = (e) => te(e, (n) => {
    const o = {};
    return n.forEach((c) => {
      if (c.type === "attachment") {
        const S = c.fieldState.value;
        let u = null;
        Array.isArray(S) && S[0] != null && (u = S[0].url), o[`${c.name}_first`] = u;
      }
    }), o;
  }), qe = (e, n, o) => {
    let c = Qe(e || {});
    return Object.entries(n || {}).map(([u, _]) => {
      var p;
      const A = v(u);
      return {
        key: u,
        value: _,
        lastUpdate: ((p = V(A).fieldState) == null ? void 0 : p.lastUpdate) || 0
      };
    }).sort((u, _) => u.lastUpdate - _.lastUpdate).forEach(({ key: u, value: _ }) => {
      ye(c, u, _);
    }), Object.entries(o || {}).forEach(([u, _]) => {
      ye(c, u, _);
    }), c;
  }, v = (e) => h.find((n) => V(n).name === e), Oe = (e, n, o) => {
    var c;
    if (Array.isArray(e) && o === tt.ARRAY && n) {
      const S = ((c = n == null ? void 0 : n.constraints) == null ? void 0 : c.inclusion) || [];
      return e.map((_) => String(_)).filter((_) => S.includes(_));
    }
    return e;
  }, E = {
    registerField: (e, n, o = null, c = !1, S = !1, u, _ = 1) => {
      var _e, me, be;
      if (!e)
        return;
      const A = X ? null : (_e = b == null ? void 0 : b[e]) == null ? void 0 : _e.constraints, p = We(A, u, e, W);
      o = Oe(o, b == null ? void 0 : b[e], n);
      let g = Xe(N, e) ?? o, G = null, C = `id-${Ze()}`;
      const x = v(e);
      if (x) {
        const { fieldState: I } = V(x);
        C = I.fieldId, I.value != null && I.value !== "" && (g = I.value), I.error && (G = p == null ? void 0 : p(g));
      }
      const Ge = !!((me = b == null ? void 0 : b[e]) != null && me.autocolumn), $ = ee({
        name: e,
        type: n,
        step: _ || 1,
        fieldState: {
          fieldId: C,
          value: g,
          error: G,
          disabled: B || c || Ge && !Z,
          readonly: Q || S || ((be = b == null ? void 0 : b[e]) == null ? void 0 : be.readonly),
          defaultValue: o,
          validator: p,
          lastUpdate: Date.now()
        },
        fieldApi: je(e),
        fieldSchema: (b == null ? void 0 : b[e]) ?? {}
      });
      if (x) {
        const I = h.filter((Me) => V(Me).name !== e);
        t(21, h = [...I, $]);
      } else
        t(21, h = [...h, $]);
      return $;
    },
    validate: () => {
      const e = h.filter((c) => V(c).step === V(F));
      let n = !0, o = !1;
      return e.forEach((c) => {
        const S = V(c).fieldApi.validate();
        n = n && S, !n && !o && (fe({ field: V(c) }), o = !0);
      }), n;
    },
    reset: () => {
      h.forEach((e) => {
        V(e).fieldApi.reset();
      });
    },
    changeStep: ({ type: e, number: n }) => {
      e === "next" ? F.update((o) => o + 1) : e === "prev" ? F.update((o) => Math.max(1, o - 1)) : e === "first" ? F.set(1) : e === "specific" && n && !isNaN(n) && F.set(parseInt(n));
    },
    setStep: (e) => {
      e && F.set(e);
    },
    setFieldValue: (e, n) => {
      const o = v(e);
      if (!o)
        return;
      const { fieldApi: c } = V(o);
      c.setValue(n);
    },
    resetField: (e) => {
      const n = v(e);
      if (!n)
        return;
      const { fieldApi: o } = V(n);
      o.reset();
    }
  }, je = (e) => {
    const n = (u, _ = !1) => {
      const A = v(e), { fieldState: p } = V(A), { validator: g } = p;
      if (!_ && p.value === u)
        return !1;
      const G = g == null ? void 0 : g(u);
      return A.update((C) => (C.fieldState.value = u, C.fieldState.error = G, C.fieldState.lastUpdate = Date.now(), C)), !0;
    };
    return {
      setValue: n,
      reset: () => {
        const u = v(e), { fieldState: _ } = V(u), A = _.defaultValue;
        u.update((p) => (p.fieldState.value = A, p.fieldState.error = null, p.fieldState.lastUpdate = Date.now(), p));
      },
      setDisabled: (u) => {
        var p;
        const _ = v(e), A = !!((p = b == null ? void 0 : b[e]) != null && p.autocolumn);
        _.update((g) => (g.fieldState.disabled = B || u || A, g));
      },
      deregister: () => {
        v(e).update((_) => (_.fieldState.validator = null, _.fieldState.error = null, _));
      },
      validate: () => {
        const u = v(e);
        return n(V(u).fieldState.value, !0), !V(u).fieldState.error;
      }
    };
  };
  pe("form", {
    formState: ce,
    formApi: E,
    // Datasource is needed by attachment fields to be able to upload files
    // to the correct table ID
    dataSource: L
  }), pe("form-step", ee(1));
  const Be = ({ type: e, field: n, value: o }) => {
    e === "set" ? E.setFieldValue(n, o) : E.resetField(n);
  }, fe = (e) => {
    let n;
    typeof e.field == "string" ? n = V(v(e.field)) : n = e.field;
    const o = n.fieldState.fieldId, c = document.getElementById(o);
    c && c.focus({ preventScroll: !0 });
    const S = document.querySelector(`label[for="${o}"]`);
    S && (S.style.scrollMargin = "100px", S.scrollIntoView({ behavior: "smooth", block: "nearest" }));
  }, Ne = [
    {
      type: U.ValidateForm,
      callback: E.validate
    },
    {
      type: U.ClearForm,
      callback: E.reset
    },
    {
      type: U.ChangeFormStep,
      callback: E.changeStep
    },
    {
      type: U.UpdateFieldValue,
      callback: Be
    },
    {
      type: U.ScrollTo,
      callback: fe
    }
  ];
  return s.$$set = (e) => {
    "dataSource" in e && t(13, L = e.dataSource), "disabled" in e && t(14, B = e.disabled), "readonly" in e && t(15, Q = e.readonly), "initialValues" in e && t(16, N = e.initialValues), "size" in e && t(0, oe = e.size), "schema" in e && t(17, b = e.schema), "definition" in e && t(18, W = e.definition), "disableSchemaValidation" in e && t(19, X = e.disableSchemaValidation), "editAutoColumns" in e && t(20, Z = e.editAutoColumns), "provideContext" in e && t(1, ae = e.provideContext), "currentStep" in e && ne(t(2, F = e.currentStep)), "$$scope" in e && t(30, ie = e.$$scope);
  }, s.$$.update = () => {
    s.$$.dirty[0] & /*fields*/
    2097152 && Ee(t(7, i = de(h, (e) => e.fieldState.value))), s.$$.dirty[0] & /*fields*/
    2097152 && Ue(t(6, d = de(h, (e) => e.fieldState.error))), s.$$.dirty[0] & /*fields*/
    2097152 && Ie(t(5, y = Te(h))), s.$$.dirty[0] & /*$errors*/
    268435456 && t(22, m = !Object.values(j).some((e) => e != null)), s.$$.dirty[0] & /*currentStep, fields*/
    2097156 && Ce(t(4, a = te([F, ...h], ([e, ...n]) => !n.filter((o) => o.step === e).some((o) => o.fieldState.error != null)))), s.$$.dirty[0] & /*$values, $errors, valid, $currentStep*/
    440401920 && ce.set({
      values: O,
      errors: j,
      valid: m,
      currentStep: q
    }), s.$$.dirty[0] & /*initialValues, $values, $enrichments*/
    201392128 && t(23, r = qe(N, O, H)), s.$$.dirty[0] & /*formValue, valid, $currentStep, $currentStepValid*/
    62914560 && t(3, f = {
      ...r,
      // These static values are prefixed to avoid clashes with actual columns
      __value: r,
      __valid: m,
      __currentStep: q,
      __currentStepValid: k
    });
  }, [
    oe,
    ae,
    F,
    f,
    a,
    y,
    d,
    i,
    se,
    ue,
    De,
    ze,
    Ne,
    L,
    B,
    Q,
    N,
    b,
    W,
    X,
    Z,
    h,
    m,
    r,
    k,
    q,
    H,
    O,
    j,
    we,
    ie
  ];
}
class at extends Pe {
  constructor(l) {
    super(), Re(
      this,
      l,
      it,
      st,
      He,
      {
        dataSource: 13,
        disabled: 14,
        readonly: 15,
        initialValues: 16,
        size: 0,
        schema: 17,
        definition: 18,
        disableSchemaValidation: 19,
        editAutoColumns: 20,
        provideContext: 1,
        currentStep: 2
      },
      null,
      [-1, -1]
    );
  }
}
export {
  at as I
};
