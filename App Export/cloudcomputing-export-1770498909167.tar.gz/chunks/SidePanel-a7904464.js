import { S as G, i as H, s as D, e as J, b as K, d as P, f as M, q as O, z as j, n as k, B as L, A as N, k as S, h as w, o as Q, r as R, u as B, v as m, F as T, G as U, H as V, J as W } from "./index-e79f0bb2.js";
function q(n) {
  let t;
  const l = (
    /*#slots*/
    n[15].default
  ), s = T(
    l,
    n,
    /*$$scope*/
    n[14],
    null
  );
  return {
    c() {
      s && s.c();
    },
    m(e, o) {
      s && s.m(e, o), t = !0;
    },
    p(e, o) {
      s && s.p && (!t || o & /*$$scope*/
      16384) && U(
        s,
        l,
        e,
        /*$$scope*/
        e[14],
        t ? W(
          l,
          /*$$scope*/
          e[14],
          o,
          null
        ) : V(
          /*$$scope*/
          e[14]
        ),
        null
      );
    },
    i(e) {
      t || (S(s, e), t = !0);
    },
    o(e) {
      k(s, e), t = !1;
    },
    d(e) {
      s && s.d(e);
    }
  };
}
function X(n) {
  let t, l = (
    /*renderKey*/
    n[2]
  ), s, e, o, c, d, u = q(n);
  return {
    c() {
      t = J("div"), u.c(), K(t, "class", "side-panel svelte-l1y86g"), P(
        t,
        "open",
        /*open*/
        n[0]
      );
    },
    m(i, r) {
      M(i, t, r), u.m(t, null), o = !0, c || (d = [
        O(s = /*styleable*/
        n[4].call(
          null,
          t,
          /*$component*/
          n[1].styles
        )),
        O(e = /*showInSidePanel*/
        n[8].call(
          null,
          t,
          /*open*/
          n[0]
        ))
      ], c = !0);
    },
    p(i, [r]) {
      r & /*renderKey*/
      4 && D(l, l = /*renderKey*/
      i[2]) ? (j(), k(u, 1, 1, L), N(), u = q(i), u.c(), S(u, 1), u.m(t, null)) : u.p(i, r), s && w(s.update) && r & /*$component*/
      2 && s.update.call(
        null,
        /*$component*/
        i[1].styles
      ), e && w(e.update) && r & /*open*/
      1 && e.update.call(
        null,
        /*open*/
        i[0]
      ), (!o || r & /*open*/
      1) && P(
        t,
        "open",
        /*open*/
        i[0]
      );
    },
    i(i) {
      o || (S(u), o = !0);
    },
    o(i) {
      k(u), o = !1;
    },
    d(i) {
      i && Q(t), u.d(i), c = !1, R(d);
    }
  };
}
function Y(n, t, l) {
  let s, e, o, c, d, { $$slots: u = {}, $$scope: i } = t;
  const r = B("component");
  m(n, r, (a) => l(1, e = a));
  const { styleable: v, sidePanelStore: f, builderStore: h, dndIsDragging: b } = B("sdk");
  m(n, f, (a) => l(11, o = a)), m(n, h, (a) => l(13, d = a)), m(n, b, (a) => l(12, c = a));
  let { onClose: _ } = t, { ignoreClicksOutside: y } = t, I = null;
  const z = async () => {
    _ && await _();
  }, A = (a, E) => {
    const C = (F) => {
      const p = document.getElementById("side-panel-container"), g = a;
      F ? p.contains(g) || p.appendChild(g) : p.contains(g) && (p.removeChild(g), z());
    };
    return C(E), { update: C, destroy: () => C(!1) };
  };
  return n.$$set = (a) => {
    "onClose" in a && l(9, _ = a.onClose), "ignoreClicksOutside" in a && l(10, y = a.ignoreClicksOutside), "$$scope" in a && l(14, i = a.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*$builderStore, $component, $sidePanelStore, $dndIsDragging*/
    14338 && d.inBuilder && (e.inSelectedPath && o.contentId !== e.id ? f.actions.open(e.id) : !e.inSelectedPath && o.contentId === e.id && !c && f.actions.close()), n.$$.dirty & /*$sidePanelStore, $component*/
    2050 && l(0, s = o.contentId === e.id), n.$$.dirty & /*open, ignoreClicksOutside*/
    1025 && s && (f.actions.setIgnoreClicksOutside(y), l(2, I = Math.random()));
  }, [
    s,
    e,
    I,
    r,
    v,
    f,
    h,
    b,
    A,
    _,
    y,
    o,
    c,
    d,
    i,
    u
  ];
}
class x extends G {
  constructor(t) {
    super(), H(this, t, Y, X, D, { onClose: 9, ignoreClicksOutside: 10 });
  }
}
export {
  x as default
};
