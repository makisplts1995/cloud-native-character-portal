import { az as h, cc as l, bg as b, bf as c, cr as L } from "./index-e79f0bb2.js";
const $ = {
  string: "stringfield",
  options: "optionsfield",
  number: "numberfield",
  bigint: "bigintfield",
  datetime: "datetimefield",
  boolean: "booleanfield",
  formula: "stringfield"
}, F = async (i, t) => {
  var a, e, d;
  if (!(i != null && i.length) || !t)
    return [];
  let s = [];
  for (let n of i) {
    let r = (a = t[n]) == null ? void 0 : a.type;
    if (n.includes(".")) {
      const y = n.split("."), o = y[0], T = y.slice(1).join("."), f = t[o];
      if ((f == null ? void 0 : f.type) === "link") {
        const g = await h.fetchTableDefinition(f.tableId);
        r = (d = (e = g == null ? void 0 : g.schema) == null ? void 0 : e[T]) == null ? void 0 : d.type;
      }
    }
    const p = $[r];
    p && s.push({
      name: n,
      componentType: p,
      type: r
    });
  }
  return s.slice(0, 5);
}, A = (i, t, s) => {
  if (!(t != null && t.length))
    return i;
  const a = [];
  return t == null || t.forEach((e) => {
    const d = e.name.split(".").map(l).join("."), n = e.type === "string" || e.type === "formula", r = e.type === "datetime", p = `${l(s)}.${d}`;
    if (r) {
      a.push({
        field: e.name,
        type: e.type,
        operator: "rangeLow",
        valueType: "Binding",
        value: `{{ ${p} }}`
      });
      let o = `{{ date (add (date ${p} "x") 86399999) "YYYY-MM-DDTHH:mm:ss.SSSZ" }}`;
      o = `{{#if ${p} }}${o}{{/if}}`, a.push({
        field: e.name,
        type: e.type,
        operator: "rangeHigh",
        valueType: "Binding",
        value: o
      });
    } else
      a.push({
        field: e.name,
        type: e.type,
        operator: n ? b.STRING : b.EQUAL,
        valueType: "Binding",
        value: `{{ ${p} }}`
      });
  }), {
    logicalOperator: c.ALL,
    onEmptyFilter: L.RETURN_ALL,
    groups: [
      ...(i == null ? void 0 : i.groups) || [],
      {
        logicalOperator: c.ALL,
        filters: a
      }
    ]
  };
};
export {
  A as a,
  F as e
};
