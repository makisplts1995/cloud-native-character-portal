const L = (s, f, t, C, a, n) => {
  var r, g;
  if (s == null || s === "schema")
    return ((r = f == null ? void 0 : f.constraints) == null ? void 0 : r.inclusion) ?? [];
  if (s === "provider" && a) {
    let e = {}, v = [];
    return (g = t == null ? void 0 : t.rows) == null || g.forEach((u) => {
      const l = u == null ? void 0 : u[a];
      if (l != null && !e[l]) {
        e[l] = !0;
        const E = u[C] || l;
        v.push({ value: l, label: E });
      }
    }), v;
  }
  return s === "custom" && n ? (n.forEach((e) => {
    typeof e.value == "string" && (e.value.toLowerCase() === "true" ? e.value = !0 : e.value.toLowerCase() === "false" && (e.value = !1));
  }), n) : [];
};
export {
  L as g
};
