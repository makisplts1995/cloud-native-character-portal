import { S as L, i as N, s as D, ac as S, ai as A, c as T, m as V, aj as C, k as r, n as m, p as F, y as E, f as G, z as H, A as J, o as K, cF as M } from "./index-e79f0bb2.js";
import { F as O } from "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function z(n) {
  let l, f;
  return l = new M({
    props: {
      value: (
        /*fieldState*/
        n[10].value
      ),
      disabled: (
        /*fieldState*/
        n[10].disabled
      ),
      readonly: (
        /*fieldState*/
        n[10].readonly
      ),
      error: (
        /*fieldState*/
        n[10].error
      ),
      id: (
        /*fieldState*/
        n[10].fieldId
      ),
      size: (
        /*size*/
        n[5]
      ),
      text: (
        /*text*/
        n[2]
      )
    }
  }), l.$on(
    "change",
    /*handleChange*/
    n[13]
  ), {
    c() {
      T(l.$$.fragment);
    },
    m(e, a) {
      V(l, e, a), f = !0;
    },
    p(e, a) {
      const d = {};
      a & /*fieldState*/
      1024 && (d.value = /*fieldState*/
      e[10].value), a & /*fieldState*/
      1024 && (d.disabled = /*fieldState*/
      e[10].disabled), a & /*fieldState*/
      1024 && (d.readonly = /*fieldState*/
      e[10].readonly), a & /*fieldState*/
      1024 && (d.error = /*fieldState*/
      e[10].error), a & /*fieldState*/
      1024 && (d.id = /*fieldState*/
      e[10].fieldId), a & /*size*/
      32 && (d.size = /*size*/
      e[5]), a & /*text*/
      4 && (d.text = /*text*/
      e[2]), l.$set(d);
    },
    i(e) {
      f || (r(l.$$.fragment, e), f = !0);
    },
    o(e) {
      m(l.$$.fragment, e), f = !1;
    },
    d(e) {
      F(l, e);
    }
  };
}
function P(n) {
  let l, f, e = (
    /*fieldState*/
    n[10] && z(n)
  );
  return {
    c() {
      e && e.c(), l = E();
    },
    m(a, d) {
      e && e.m(a, d), G(a, l, d), f = !0;
    },
    p(a, d) {
      /*fieldState*/
      a[10] ? e ? (e.p(a, d), d & /*fieldState*/
      1024 && r(e, 1)) : (e = z(a), e.c(), r(e, 1), e.m(l.parentNode, l)) : e && (H(), m(e, 1, 1, () => {
        e = null;
      }), J());
    },
    i(a) {
      f || (r(e), f = !0);
    },
    o(a) {
      m(e), f = !1;
    },
    d(a) {
      a && K(l), e && e.d(a);
    }
  };
}
function Q(n) {
  let l, f, e, a;
  function d(t) {
    n[15](t);
  }
  function _(t) {
    n[16](t);
  }
  let s = {
    label: (
      /*label*/
      n[1]
    ),
    field: (
      /*field*/
      n[0]
    ),
    disabled: (
      /*disabled*/
      n[3]
    ),
    readonly: (
      /*readonly*/
      n[4]
    ),
    validation: (
      /*validation*/
      n[6]
    ),
    span: (
      /*span*/
      n[8]
    ),
    helpText: (
      /*helpText*/
      n[9]
    ),
    defaultValue: (
      /*isTruthy*/
      n[12](
        /*defaultValue*/
        n[7]
      )
    ),
    type: "boolean",
    $$slots: { default: [P] },
    $$scope: { ctx: n }
  };
  return (
    /*fieldState*/
    n[10] !== void 0 && (s.fieldState = /*fieldState*/
    n[10]), /*fieldApi*/
    n[11] !== void 0 && (s.fieldApi = /*fieldApi*/
    n[11]), l = new O({ props: s }), S.push(() => A(l, "fieldState", d)), S.push(() => A(l, "fieldApi", _)), {
      c() {
        T(l.$$.fragment);
      },
      m(t, u) {
        V(l, t, u), a = !0;
      },
      p(t, [u]) {
        const o = {};
        u & /*label*/
        2 && (o.label = /*label*/
        t[1]), u & /*field*/
        1 && (o.field = /*field*/
        t[0]), u & /*disabled*/
        8 && (o.disabled = /*disabled*/
        t[3]), u & /*readonly*/
        16 && (o.readonly = /*readonly*/
        t[4]), u & /*validation*/
        64 && (o.validation = /*validation*/
        t[6]), u & /*span*/
        256 && (o.span = /*span*/
        t[8]), u & /*helpText*/
        512 && (o.helpText = /*helpText*/
        t[9]), u & /*defaultValue*/
        128 && (o.defaultValue = /*isTruthy*/
        t[12](
          /*defaultValue*/
          t[7]
        )), u & /*$$scope, fieldState, size, text*/
        132132 && (o.$$scope = { dirty: u, ctx: t }), !f && u & /*fieldState*/
        1024 && (f = !0, o.fieldState = /*fieldState*/
        t[10], C(() => f = !1)), !e && u & /*fieldApi*/
        2048 && (e = !0, o.fieldApi = /*fieldApi*/
        t[11], C(() => e = !1)), l.$set(o);
      },
      i(t) {
        a || (r(l.$$.fragment, t), a = !0);
      },
      o(t) {
        m(l.$$.fragment, t), a = !1;
      },
      d(t) {
        F(l, t);
      }
    }
  );
}
function R(n, l, f) {
  let { field: e } = l, { label: a } = l, { text: d } = l, { disabled: _ = !1 } = l, { readonly: s = !1 } = l, { size: t } = l, { validation: u } = l, { defaultValue: o } = l, { onChange: b } = l, { span: c } = l, { helpText: k = null } = l, g, h;
  const w = (i) => i ? i === !0 || typeof i == "string" && i.toLowerCase() === "true" : !1, I = (i) => {
    const B = h.setValue(i.detail);
    b && B && b({ value: i.detail });
  };
  function j(i) {
    g = i, f(10, g);
  }
  function q(i) {
    h = i, f(11, h);
  }
  return n.$$set = (i) => {
    "field" in i && f(0, e = i.field), "label" in i && f(1, a = i.label), "text" in i && f(2, d = i.text), "disabled" in i && f(3, _ = i.disabled), "readonly" in i && f(4, s = i.readonly), "size" in i && f(5, t = i.size), "validation" in i && f(6, u = i.validation), "defaultValue" in i && f(7, o = i.defaultValue), "onChange" in i && f(14, b = i.onChange), "span" in i && f(8, c = i.span), "helpText" in i && f(9, k = i.helpText);
  }, [
    e,
    a,
    d,
    _,
    s,
    t,
    u,
    o,
    c,
    k,
    g,
    h,
    w,
    I,
    b,
    j,
    q
  ];
}
class Z extends L {
  constructor(l) {
    super(), N(this, l, R, Q, D, {
      field: 0,
      label: 1,
      text: 2,
      disabled: 3,
      readonly: 4,
      size: 5,
      validation: 6,
      defaultValue: 7,
      onChange: 14,
      span: 8,
      helpText: 9
    });
  }
}
export {
  Z as default
};
