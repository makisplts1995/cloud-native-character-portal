import { S as r, i as u, s as p, e as d, b as m, f, q as h, h as y, B as c, o as _, u as i, v as b } from "./index-e79f0bb2.js";
function v(o) {
  let e, s, n, a;
  return {
    c() {
      e = d("div"), e.innerHTML = `<h1 class="svelte-ku38cm">Screen Slot</h1> <span class="svelte-ku38cm">The screens that you create will be displayed inside this box.
    <br/>
    This box is just a placeholder, to show you the position of screens.</span>`, m(e, "class", "svelte-ku38cm");
    },
    m(t, l) {
      f(t, e, l), n || (a = h(s = /*styleable*/
      o[1].call(null, e, {
        .../*$component*/
        o[0].styles,
        empty: !0
      })), n = !0);
    },
    p(t, [l]) {
      s && y(s.update) && l & /*$component*/
      1 && s.update.call(null, {
        .../*$component*/
        t[0].styles,
        empty: !0
      });
    },
    i: c,
    o: c,
    d(t) {
      t && _(e), n = !1, a();
    }
  };
}
function S(o, e, s) {
  let n;
  const { styleable: a } = i("sdk"), t = i("component");
  return b(o, t, (l) => s(0, n = l)), [n, a, t];
}
class x extends r {
  constructor(e) {
    super(), u(this, e, S, v, p, {});
  }
}
export {
  x as default
};
