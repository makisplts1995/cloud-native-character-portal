import { S as O, i as Q, s as A, y as R, f as D, B as q, o as E, u as P, v as M, e as U, t as V, b as m, d as r, g as W, q as X, l as N, h as j, cg as Y, r as Z, ac as p } from "./index-e79f0bb2.js";
function w(e) {
  let n, i, a, l, u, d, f;
  return {
    c() {
      n = U("h1"), i = V(
        /*componentText*/
        e[9]
      ), m(n, "contenteditable", a = /*$component*/
      e[4].editing), m(n, "class", l = "spectrum-Heading " + /*sizeClass*/
      e[8] + " " + /*alignClass*/
      e[7] + " svelte-7cr7ya"), r(
        n,
        "placeholder",
        /*placeholder*/
        e[10]
      ), r(
        n,
        "bold",
        /*bold*/
        e[0]
      ), r(
        n,
        "italic",
        /*italic*/
        e[1]
      ), r(
        n,
        "underline",
        /*underline*/
        e[2]
      );
    },
    m(s, o) {
      D(s, n, o), W(n, i), e[20](n), d || (f = [
        X(u = /*styleable*/
        e[11].call(
          null,
          n,
          /*styles*/
          e[6]
        )),
        N(n, "blur", function() {
          j(
            /*$component*/
            e[4].editing ? (
              /*updateText*/
              e[14]
            ) : null
          ) && /*$component*/
          (e[4].editing ? (
            /*updateText*/
            e[14]
          ) : null).apply(this, arguments);
        }),
        N(
          n,
          "input",
          /*input_handler*/
          e[21]
        )
      ], d = !0);
    },
    p(s, o) {
      e = s, o & /*componentText*/
      512 && Y(
        i,
        /*componentText*/
        e[9],
        /*$component*/
        e[4].editing
      ), o & /*$component*/
      16 && a !== (a = /*$component*/
      e[4].editing) && m(n, "contenteditable", a), o & /*sizeClass, alignClass*/
      384 && l !== (l = "spectrum-Heading " + /*sizeClass*/
      e[8] + " " + /*alignClass*/
      e[7] + " svelte-7cr7ya") && m(n, "class", l), u && j(u.update) && o & /*styles*/
      64 && u.update.call(
        null,
        /*styles*/
        e[6]
      ), o & /*sizeClass, alignClass, placeholder*/
      1408 && r(
        n,
        "placeholder",
        /*placeholder*/
        e[10]
      ), o & /*sizeClass, alignClass, bold*/
      385 && r(
        n,
        "bold",
        /*bold*/
        e[0]
      ), o & /*sizeClass, alignClass, italic*/
      386 && r(
        n,
        "italic",
        /*italic*/
        e[1]
      ), o & /*sizeClass, alignClass, underline*/
      388 && r(
        n,
        "underline",
        /*underline*/
        e[2]
      );
    },
    d(s) {
      s && E(n), e[20](null), d = !1, Z(f);
    }
  };
}
function v(e) {
  let n = (
    /*$component*/
    e[4].editing
  ), i, a = w(e);
  return {
    c() {
      a.c(), i = R();
    },
    m(l, u) {
      a.m(l, u), D(l, i, u);
    },
    p(l, [u]) {
      u & /*$component*/
      16 && A(n, n = /*$component*/
      l[4].editing) ? (a.d(1), a = w(l), a.c(), a.m(i.parentNode, i)) : a.p(l, u);
    },
    i: q,
    o: q,
    d(l) {
      l && E(i), a.d(l);
    }
  };
}
function x(e, n, i) {
  let a, l, u, d, f, s, o;
  const { styleable: F, builderStore: h } = P("sdk");
  M(e, h, (t) => i(19, o = t));
  const C = P("component");
  M(e, C, (t) => i(4, s = t));
  let { text: g } = n, { color: y } = n, { align: k } = n, { bold: H } = n, { italic: S } = n, { underline: B } = n, { size: z } = n, c, _ = !1;
  const G = (t, b, T) => !b.inBuilder || T.editing ? t || "" : t || T.name || "Placeholder text", I = (t, b) => b ? {
    ...t,
    normal: { ...t == null ? void 0 : t.normal, color: b }
  } : t, J = (t) => {
    _ && h.actions.updateProp("text", t.target.textContent), i(5, _ = !1);
  };
  function K(t) {
    p[t ? "unshift" : "push"](() => {
      c = t, i(3, c);
    });
  }
  const L = () => i(5, _ = !0);
  return e.$$set = (t) => {
    "text" in t && i(15, g = t.text), "color" in t && i(16, y = t.color), "align" in t && i(17, k = t.align), "bold" in t && i(0, H = t.bold), "italic" in t && i(1, S = t.italic), "underline" in t && i(2, B = t.underline), "size" in t && i(18, z = t.size);
  }, e.$$.update = () => {
    e.$$.dirty & /*$component, node*/
    24 && s.editing && (c == null || c.focus()), e.$$.dirty & /*$builderStore, text, $component*/
    557072 && i(10, a = o.inBuilder && !g && !s.editing), e.$$.dirty & /*text, $builderStore, $component*/
    557072 && i(9, l = G(g, o, s)), e.$$.dirty & /*size*/
    262144 && i(8, u = `spectrum-Heading--size${z || "M"}`), e.$$.dirty & /*align*/
    131072 && i(7, d = `align--${k || "left"}`), e.$$.dirty & /*$component, color*/
    65552 && i(6, f = I(s.styles, y));
  }, [
    H,
    S,
    B,
    c,
    s,
    _,
    f,
    d,
    u,
    l,
    a,
    F,
    h,
    C,
    J,
    g,
    y,
    k,
    z,
    o,
    K,
    L
  ];
}
class ee extends O {
  constructor(n) {
    super(), Q(this, n, x, v, A, {
      text: 15,
      color: 16,
      align: 17,
      bold: 0,
      italic: 1,
      underline: 2,
      size: 18
    });
  }
}
export {
  ee as default
};
