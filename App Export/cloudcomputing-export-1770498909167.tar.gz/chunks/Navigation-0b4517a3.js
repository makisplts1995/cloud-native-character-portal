import { S as L, i as U, s as q, F as C, e as d, a as N, b as r, f as h, g as m, q as k, G as S, H as A, J as F, h as G, k as H, n as J, o as y, u as v, v as j, aA as b } from "./index-e79f0bb2.js";
function p(o) {
  let l, a, s, u, i, _;
  return {
    c() {
      l = d("div"), a = d("a"), s = d("img"), r(s, "class", "logo svelte-1ggxdm7"), r(s, "alt", "logo"), b(s.src, u = /*logoUrl*/
      o[0] || "/builder/bblogo.png") || r(s, "src", u), r(s, "height", "48"), r(a, "href", "/"), r(l, "class", "nav__top svelte-1ggxdm7");
    },
    m(f, t) {
      h(f, l, t), m(l, a), m(a, s), i || (_ = k(
        /*linkable*/
        o[3].call(null, a)
      ), i = !0);
    },
    p(f, t) {
      t & /*logoUrl*/
      1 && !b(s.src, u = /*logoUrl*/
      f[0] || "/builder/bblogo.png") && r(s, "src", u);
    },
    d(f) {
      f && y(l), i = !1, _();
    }
  };
}
function w(o) {
  let l, a, s, u, i, _, f, t = !/*hideLogo*/
  o[1] && p(o);
  const c = (
    /*#slots*/
    o[7].default
  ), n = C(
    c,
    o,
    /*$$scope*/
    o[6],
    null
  );
  return {
    c() {
      l = d("div"), t && t.c(), a = N(), s = d("div"), n && n.c(), r(s, "class", "nav__menu svelte-1ggxdm7"), r(l, "class", "nav svelte-1ggxdm7");
    },
    m(e, g) {
      h(e, l, g), t && t.m(l, null), m(l, a), m(l, s), n && n.m(s, null), i = !0, _ || (f = k(u = /*styleable*/
      o[4].call(
        null,
        l,
        /*$component*/
        o[2].styles
      )), _ = !0);
    },
    p(e, [g]) {
      /*hideLogo*/
      e[1] ? t && (t.d(1), t = null) : t ? t.p(e, g) : (t = p(e), t.c(), t.m(l, a)), n && n.p && (!i || g & /*$$scope*/
      64) && S(
        n,
        c,
        e,
        /*$$scope*/
        e[6],
        i ? F(
          c,
          /*$$scope*/
          e[6],
          g,
          null
        ) : A(
          /*$$scope*/
          e[6]
        ),
        null
      ), u && G(u.update) && g & /*$component*/
      4 && u.update.call(
        null,
        /*$component*/
        e[2].styles
      );
    },
    i(e) {
      i || (H(n, e), i = !0);
    },
    o(e) {
      J(n, e), i = !1;
    },
    d(e) {
      e && y(l), t && t.d(), n && n.d(e), _ = !1, f();
    }
  };
}
function z(o, l, a) {
  let s, { $$slots: u = {}, $$scope: i } = l;
  const { linkable: _, styleable: f } = v("sdk"), t = v("component");
  j(o, t, (e) => a(2, s = e));
  let { logoUrl: c } = l, { hideLogo: n } = l;
  return o.$$set = (e) => {
    "logoUrl" in e && a(0, c = e.logoUrl), "hideLogo" in e && a(1, n = e.hideLogo), "$$scope" in e && a(6, i = e.$$scope);
  }, [c, n, s, _, f, t, i, u];
}
class D extends L {
  constructor(l) {
    super(), U(this, l, z, w, q, { logoUrl: 0, hideLogo: 1 });
  }
}
export {
  D as default
};
