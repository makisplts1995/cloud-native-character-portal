import { S as f, i as d, s as g, e as v, b as m, aD as h, f as _, B as c, o as b, ch as y, ac as M } from "./index-e79f0bb2.js";
function k(n) {
  let e;
  return {
    c() {
      e = v("div"), m(e, "class", "markdown-viewer svelte-12nifb7"), h(
        e,
        "height",
        /*height*/
        n[0]
      );
    },
    m(i, a) {
      _(i, e, a), n[3](e);
    },
    p(i, [a]) {
      a & /*height*/
      1 && h(
        e,
        "height",
        /*height*/
        i[0]
      );
    },
    i: c,
    o: c,
    d(i) {
      i && b(e), n[3](null);
    }
  };
}
function w(n, e, i) {
  let { value: a = void 0 } = e, { height: r = void 0 } = e, s;
  const l = async (t, u) => {
    if (t) {
      if (!u) {
        t.innerHTML = "";
        return;
      }
      t.innerHTML = y.parse(u, { async: !1 });
    }
  };
  function o(t) {
    M[t ? "unshift" : "push"](() => {
      s = t, i(1, s);
    });
  }
  return n.$$set = (t) => {
    "value" in t && i(2, a = t.value), "height" in t && i(0, r = t.height);
  }, n.$$.update = () => {
    n.$$.dirty & /*ref, value*/
    6 && l(s, a);
  }, [r, s, a, o];
}
class H extends f {
  constructor(e) {
    super(), d(this, e, w, k, g, { value: 2, height: 0 });
  }
}
export {
  H as M
};
