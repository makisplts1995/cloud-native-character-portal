import { S as M, i as B, s as C, K as W, c as E, m as S, k as p, n as _, p as y, u as $, v as q, cc as w, y as F, f as h, z as G, A as O, o as P, M as A, F as v, G as L, H, J as D, b2 as f } from "./index-e79f0bb2.js";
function J(l) {
  let n, o;
  return n = new A({
    props: {
      type: "dataprovider",
      context: "provider",
      props: {
        dataSource: (
          /*dataSource*/
          l[1]
        ),
        filter: (
          /*filter*/
          l[3]
        ),
        limit: 1,
        paginate: !1
      },
      $$slots: { default: [j] },
      $$scope: { ctx: l }
    }
  }), {
    c() {
      E(n.$$.fragment);
    },
    m(t, e) {
      S(n, t, e), o = !0;
    },
    p(t, e) {
      const r = {};
      e & /*dataSource, filter*/
      10 && (r.props = {
        dataSource: (
          /*dataSource*/
          t[1]
        ),
        filter: (
          /*filter*/
          t[3]
        ),
        limit: 1,
        paginate: !1
      }), e & /*$$scope, dataProvider, noRowsMessage*/
      2068 && (r.$$scope = { dirty: e, ctx: t }), n.$set(r);
    },
    i(t) {
      o || (p(n.$$.fragment, t), o = !0);
    },
    o(t) {
      _(n.$$.fragment, t), o = !1;
    },
    d(t) {
      y(n, t);
    }
  };
}
function K(l) {
  let n, o;
  return n = new A({
    props: {
      type: "container",
      props: {
        direction: "column",
        hAlign: "left",
        vAlign: "stretch"
      },
      $$slots: { default: [z] },
      $$scope: { ctx: l }
    }
  }), {
    c() {
      E(n.$$.fragment);
    },
    m(t, e) {
      S(n, t, e), o = !0;
    },
    p(t, e) {
      const r = {};
      e & /*$$scope*/
      2048 && (r.$$scope = { dirty: e, ctx: t }), n.$set(r);
    },
    i(t) {
      o || (p(n.$$.fragment, t), o = !0);
    },
    o(t) {
      _(n.$$.fragment, t), o = !1;
    },
    d(t) {
      y(n, t);
    }
  };
}
function U(l) {
  let n;
  const o = (
    /*#slots*/
    l[10].default
  ), t = v(
    o,
    l,
    /*$$scope*/
    l[11],
    null
  );
  return {
    c() {
      t && t.c();
    },
    m(e, r) {
      t && t.m(e, r), n = !0;
    },
    p(e, r) {
      t && t.p && (!n || r & /*$$scope*/
      2048) && L(
        t,
        o,
        e,
        /*$$scope*/
        e[11],
        n ? D(
          o,
          /*$$scope*/
          e[11],
          r,
          null
        ) : H(
          /*$$scope*/
          e[11]
        ),
        null
      );
    },
    i(e) {
      n || (p(t, e), n = !0);
    },
    o(e) {
      _(t, e), n = !1;
    },
    d(e) {
      t && t.d(e);
    }
  };
}
function j(l) {
  let n, o;
  return n = new A({
    props: {
      type: "repeater",
      context: "repeater",
      props: {
        dataProvider: (
          /*dataProvider*/
          l[4]
        ),
        noRowsMessage: (
          /*noRowsMessage*/
          l[2] || "We couldn't find a row to display"
        ),
        direction: "column",
        hAlign: "center",
        scope: (
          /*ContextScopes*/
          l[6].Global
        )
      },
      $$slots: { default: [U] },
      $$scope: { ctx: l }
    }
  }), {
    c() {
      E(n.$$.fragment);
    },
    m(t, e) {
      S(n, t, e), o = !0;
    },
    p(t, e) {
      const r = {};
      e & /*dataProvider, noRowsMessage*/
      20 && (r.props = {
        dataProvider: (
          /*dataProvider*/
          t[4]
        ),
        noRowsMessage: (
          /*noRowsMessage*/
          t[2] || "We couldn't find a row to display"
        ),
        direction: "column",
        hAlign: "center",
        scope: (
          /*ContextScopes*/
          t[6].Global
        )
      }), e & /*$$scope*/
      2048 && (r.$$scope = { dirty: e, ctx: t }), n.$set(r);
    },
    i(t) {
      o || (p(n.$$.fragment, t), o = !0);
    },
    o(t) {
      _(n.$$.fragment, t), o = !1;
    },
    d(t) {
      y(n, t);
    }
  };
}
function z(l) {
  let n;
  const o = (
    /*#slots*/
    l[10].default
  ), t = v(
    o,
    l,
    /*$$scope*/
    l[11],
    null
  );
  return {
    c() {
      t && t.c();
    },
    m(e, r) {
      t && t.m(e, r), n = !0;
    },
    p(e, r) {
      t && t.p && (!n || r & /*$$scope*/
      2048) && L(
        t,
        o,
        e,
        /*$$scope*/
        e[11],
        n ? D(
          o,
          /*$$scope*/
          e[11],
          r,
          null
        ) : H(
          /*$$scope*/
          e[11]
        ),
        null
      );
    },
    i(e) {
      n || (p(t, e), n = !0);
    },
    o(e) {
      _(t, e), n = !1;
    },
    d(e) {
      t && t.d(e);
    }
  };
}
function Q(l) {
  let n, o, t, e;
  const r = [K, J], i = [];
  function d(a, m) {
    return (
      /*actionType*/
      a[0] === "Create" ? 0 : 1
    );
  }
  return n = d(l), o = i[n] = r[n](l), {
    c() {
      o.c(), t = F();
    },
    m(a, m) {
      i[n].m(a, m), h(a, t, m), e = !0;
    },
    p(a, m) {
      let k = n;
      n = d(a), n === k ? i[n].p(a, m) : (G(), _(i[k], 1, 1, () => {
        i[k] = null;
      }), O(), o = i[n], o ? o.p(a, m) : (o = i[n] = r[n](a), o.c()), p(o, 1), o.m(t.parentNode, t));
    },
    i(a) {
      e || (p(o), e = !0);
    },
    o(a) {
      _(o), e = !1;
    },
    d(a) {
      a && P(t), i[n].d(a);
    }
  };
}
function Y(l) {
  let n, o;
  return n = new W({
    props: {
      $$slots: { default: [Q] },
      $$scope: { ctx: l }
    }
  }), {
    c() {
      E(n.$$.fragment);
    },
    m(t, e) {
      S(n, t, e), o = !0;
    },
    p(t, [e]) {
      const r = {};
      e & /*$$scope, actionType, dataSource, filter, dataProvider, noRowsMessage*/
      2079 && (r.$$scope = { dirty: e, ctx: t }), n.$set(r);
    },
    i(t) {
      o || (p(n.$$.fragment, t), o = !0);
    },
    o(t) {
      _(n.$$.fragment, t), o = !1;
    },
    d(t) {
      y(n, t);
    }
  };
}
function V(l, n, o) {
  let t, e, r, i, { $$slots: d = {}, $$scope: a } = n, { actionType: m } = n, { dataSource: k } = n, { rowId: s } = n, { noRowsMessage: c } = n;
  const g = $("component");
  q(l, g, (u) => o(9, i = u));
  const { ContextScopes: T } = $("sdk");
  return l.$$set = (u) => {
    "actionType" in u && o(0, m = u.actionType), "dataSource" in u && o(1, k = u.dataSource), "rowId" in u && o(7, s = u.rowId), "noRowsMessage" in u && o(2, c = u.noRowsMessage), "$$scope" in u && o(11, a = u.$$scope);
  }, l.$$.update = () => {
    l.$$.dirty & /*$component*/
    512 && o(8, t = `${i.id}-provider`), l.$$.dirty & /*providerId*/
    256 && o(4, e = `{{ literal ${w(t)} }}`), l.$$.dirty & /*rowId*/
    128 && o(3, r = [
      {
        field: "_id",
        operator: "equal",
        type: "string",
        value: s || `{{ ${w("url")}.${w("id")} }}`,
        valueType: "Binding"
      }
    ]);
  }, [
    m,
    k,
    c,
    r,
    e,
    g,
    T,
    s,
    t,
    i,
    d,
    a
  ];
}
class ee extends M {
  constructor(n) {
    super(), B(this, n, V, Y, C, {
      actionType: 0,
      dataSource: 1,
      rowId: 7,
      noRowsMessage: 2
    });
  }
}
function I(l) {
  var t;
  let n, o;
  return n = new A({
    props: {
      type: (
        /*getComponentForField*/
        l[2](
          /*field*/
          l[0]
        )
      ),
      props: (
        /*getPropsForField*/
        l[3](
          /*field*/
          l[0]
        )
      ),
      order: (
        /*order*/
        l[1]
      ),
      interactive: !0,
      name: (
        /*field*/
        (t = l[0]) == null ? void 0 : t.field
      )
    }
  }), {
    c() {
      E(n.$$.fragment);
    },
    m(e, r) {
      S(n, e, r), o = !0;
    },
    p(e, r) {
      var d;
      const i = {};
      r & /*field*/
      1 && (i.type = /*getComponentForField*/
      e[2](
        /*field*/
        e[0]
      )), r & /*field*/
      1 && (i.props = /*getPropsForField*/
      e[3](
        /*field*/
        e[0]
      )), r & /*order*/
      2 && (i.order = /*order*/
      e[1]), r & /*field*/
      1 && (i.name = /*field*/
      (d = e[0]) == null ? void 0 : d.field), n.$set(i);
    },
    i(e) {
      o || (p(n.$$.fragment, e), o = !0);
    },
    o(e) {
      _(n.$$.fragment, e), o = !1;
    },
    d(e) {
      y(n, e);
    }
  };
}
function X(l) {
  let n = (
    /*getComponentForField*/
    l[2](
      /*field*/
      l[0]
    ) && /*field*/
    l[0].active
  ), o, t, e = n && I(l);
  return {
    c() {
      e && e.c(), o = F();
    },
    m(r, i) {
      e && e.m(r, i), h(r, o, i), t = !0;
    },
    p(r, [i]) {
      i & /*field*/
      1 && (n = /*getComponentForField*/
      r[2](
        /*field*/
        r[0]
      ) && /*field*/
      r[0].active), n ? e ? (e.p(r, i), i & /*field*/
      1 && p(e, 1)) : (e = I(r), e.c(), p(e, 1), e.m(o.parentNode, o)) : e && (G(), _(e, 1, 1, () => {
        e = null;
      }), O());
    },
    i(r) {
      t || (p(e), t = !0);
    },
    o(r) {
      _(e), t = !1;
    },
    d(r) {
      r && P(o), e && e.d(r);
    }
  };
}
function Z(l, n, o) {
  let { field: t } = n, { schema: e } = n, { order: r } = n;
  const i = {
    [f.STRING]: "stringfield",
    [f.NUMBER]: "numberfield",
    [f.BIGINT]: "bigintfield",
    [f.OPTIONS]: "optionsfield",
    [f.ARRAY]: "multifieldselect",
    [f.BOOLEAN]: "booleanfield",
    [f.LONGFORM]: "longformfield",
    [f.DATETIME]: "datetimefield",
    [f.SIGNATURE_SINGLE]: "signaturesinglefield",
    [f.ATTACHMENTS]: "attachmentfield",
    [f.ATTACHMENT_SINGLE]: "attachmentsinglefield",
    [f.LINK]: "relationshipfield",
    [f.JSON]: "jsonfield",
    [f.BARCODEQR]: "codescanner",
    [f.BB_REFERENCE]: "bbreferencefield",
    [f.BB_REFERENCE_SINGLE]: "bbreferencesinglefield"
  }, d = (s) => {
    const c = s.field || s.name;
    return !c || !(e != null && e[c]) ? null : e[c];
  }, a = (s) => {
    const c = d(s);
    if (!c)
      return null;
    const { type: g } = c;
    return i[g];
  }, m = (s) => {
    const c = d(s), g = (c == null ? void 0 : c.displayName) || s.name;
    let T = s._component ? { ...s } : {
      field: s.name,
      label: g,
      placeholder: g,
      _instanceName: s.name
    };
    return T = { ...k(s), ...T }, T;
  };
  function k(s) {
    const c = {
      [f.ATTACHMENTS]: (u, b) => {
        var N, R;
        return {
          maximum: (R = (N = b == null ? void 0 : b.constraints) == null ? void 0 : N.length) == null ? void 0 : R.maximum
        };
      },
      [f.DATETIME]: (u, b) => {
        const N = { valueAsTimestamp: !(b != null && b.timeOnly) };
        return b != null && b.dateOnly && (N.enableTime = !1), N;
      }
    }, g = d(s), T = c[g.type];
    if (T)
      return T(s, g);
  }
  return l.$$set = (s) => {
    "field" in s && o(0, t = s.field), "schema" in s && o(4, e = s.schema), "order" in s && o(1, r = s.order);
  }, [t, r, a, m, e];
}
class te extends M {
  constructor(n) {
    super(), B(this, n, Z, X, C, { field: 0, schema: 4, order: 1 });
  }
}
export {
  te as F,
  ee as a
};
