import { R as Or, S as Jr, i as Kr, s as Zr, e as ae, b as F, f as he, q as Wr, h as en, B as Zt, o as ve, u as Wt, v as tn, aa as rn, ac as er, t as ze, g as ee, j as gt, y as nn, a as vt, aD as le, aA as tr, c9 as an } from "./index-e79f0bb2.js";
var yt = {}, Qe = {}, H = {};
Object.defineProperty(H, "__esModule", {
  value: !0
});
function on(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
var un = function t(e, n) {
  on(this, t), this.data = e, this.text = n.text || e, this.options = n;
};
H.default = un;
Object.defineProperty(Qe, "__esModule", {
  value: !0
});
Qe.CODE39 = void 0;
var fn = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), ln = H, cn = hn(ln);
function hn(t) {
  return t && t.__esModule ? t : { default: t };
}
function vn(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function dn(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function sn(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var _n = function(t) {
  sn(e, t);
  function e(n, r) {
    return vn(this, e), n = n.toUpperCase(), r.mod43 && (n += pn(En(n))), dn(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
  }
  return fn(e, [{
    key: "encode",
    value: function() {
      for (var r = ot("*"), a = 0; a < this.data.length; a++)
        r += ot(this.data[a]) + "0";
      return r += ot("*"), {
        data: r,
        text: this.text
      };
    }
  }, {
    key: "valid",
    value: function() {
      return this.data.search(/^[0-9A-Z\-\.\ \$\/\+\%]+$/) !== -1;
    }
  }]), e;
}(cn.default), br = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "-", ".", " ", "$", "/", "+", "%", "*"], gn = [20957, 29783, 23639, 30485, 20951, 29813, 23669, 20855, 29789, 23645, 29975, 23831, 30533, 22295, 30149, 24005, 21623, 29981, 23837, 22301, 30023, 23879, 30545, 22343, 30161, 24017, 21959, 30065, 23921, 22385, 29015, 18263, 29141, 17879, 29045, 18293, 17783, 29021, 18269, 17477, 17489, 17681, 20753, 35770];
function ot(t) {
  return yn(wr(t));
}
function yn(t) {
  return gn[t].toString(2);
}
function pn(t) {
  return br[t];
}
function wr(t) {
  return br.indexOf(t);
}
function En(t) {
  for (var e = 0, n = 0; n < t.length; n++)
    e += wr(t[n]);
  return e = e % 43, e;
}
Qe.CODE39 = _n;
var ne = {}, pt = {}, Re = {}, I = {};
Object.defineProperty(I, "__esModule", {
  value: !0
});
var ke;
function ut(t, e, n) {
  return e in t ? Object.defineProperty(t, e, { value: n, enumerable: !0, configurable: !0, writable: !0 }) : t[e] = n, t;
}
var mr = I.SET_A = 0, xr = I.SET_B = 1, Ar = I.SET_C = 2;
I.SHIFT = 98;
var On = I.START_A = 103, bn = I.START_B = 104, wn = I.START_C = 105;
I.MODULO = 103;
I.STOP = 106;
I.FNC1 = 207;
I.SET_BY_CODE = (ke = {}, ut(ke, On, mr), ut(ke, bn, xr), ut(ke, wn, Ar), ke);
I.SWAP = {
  101: mr,
  100: xr,
  99: Ar
};
I.A_START_CHAR = String.fromCharCode(208);
I.B_START_CHAR = String.fromCharCode(209);
I.C_START_CHAR = String.fromCharCode(210);
I.A_CHARS = "[\0-_È-Ï]";
I.B_CHARS = "[ -È-Ï]";
I.C_CHARS = "(Ï*[0-9]{2}Ï*)";
I.BARS = [11011001100, 11001101100, 11001100110, 10010011e3, 10010001100, 10001001100, 10011001e3, 10011000100, 10001100100, 11001001e3, 11001000100, 11000100100, 10110011100, 10011011100, 10011001110, 10111001100, 10011101100, 10011100110, 11001110010, 11001011100, 11001001110, 11011100100, 11001110100, 11101101110, 11101001100, 11100101100, 11100100110, 11101100100, 11100110100, 11100110010, 11011011e3, 11011000110, 11000110110, 10100011e3, 10001011e3, 10001000110, 10110001e3, 10001101e3, 10001100010, 11010001e3, 11000101e3, 11000100010, 10110111e3, 10110001110, 10001101110, 10111011e3, 10111000110, 10001110110, 11101110110, 11010001110, 11000101110, 11011101e3, 11011100010, 11011101110, 11101011e3, 11101000110, 11100010110, 11101101e3, 11101100010, 11100011010, 11101111010, 11001000010, 11110001010, 1010011e4, 10100001100, 1001011e4, 10010000110, 10000101100, 10000100110, 1011001e4, 10110000100, 1001101e4, 10011000010, 10000110100, 10000110010, 11000010010, 1100101e4, 11110111010, 11000010100, 10001111010, 10100111100, 10010111100, 10010011110, 10111100100, 10011110100, 10011110010, 11110100100, 11110010100, 11110010010, 11011011110, 11011110110, 11110110110, 10101111e3, 10100011110, 10001011110, 10111101e3, 10111100010, 11110101e3, 11110100010, 10111011110, 10111101110, 11101011110, 11110101110, 11010000100, 1101001e4, 11010011100, 1100011101011];
Object.defineProperty(Re, "__esModule", {
  value: !0
});
var mn = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), xn = H, An = $n(xn), z = I;
function $n(t) {
  return t && t.__esModule ? t : { default: t };
}
function Sn(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function Rn(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Mn(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Tn = function(t) {
  Mn(e, t);
  function e(n, r) {
    Sn(this, e);
    var a = Rn(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n.substring(1), r));
    return a.bytes = n.split("").map(function(i) {
      return i.charCodeAt(0);
    }), a;
  }
  return mn(e, [{
    key: "valid",
    value: function() {
      return /^[\x00-\x7F\xC8-\xD3]+$/.test(this.data);
    }
    // The public encoding function
  }, {
    key: "encode",
    value: function() {
      var r = this.bytes, a = r.shift() - 105, i = z.SET_BY_CODE[a];
      if (i === void 0)
        throw new RangeError("The encoding does not start with a start character.");
      this.shouldEncodeAsEan128() === !0 && r.unshift(z.FNC1);
      var f = e.next(r, 1, i);
      return {
        text: this.text === this.data ? this.text.replace(/[^\x20-\x7E]/g, "") : this.text,
        data: (
          // Add the start bits
          e.getBar(a) + // Add the encoded bits
          f.result + // Add the checksum
          e.getBar((f.checksum + a) % z.MODULO) + // Add the end bits
          e.getBar(z.STOP)
        )
      };
    }
    // GS1-128/EAN-128
  }, {
    key: "shouldEncodeAsEan128",
    value: function() {
      var r = this.options.ean128 || !1;
      return typeof r == "string" && (r = r.toLowerCase() === "true"), r;
    }
    // Get a bar symbol by index
  }], [{
    key: "getBar",
    value: function(r) {
      return z.BARS[r] ? z.BARS[r].toString() : "";
    }
    // Correct an index by a set and shift it from the bytes array
  }, {
    key: "correctIndex",
    value: function(r, a) {
      if (a === z.SET_A) {
        var i = r.shift();
        return i < 32 ? i + 64 : i - 32;
      } else
        return a === z.SET_B ? r.shift() - 32 : (r.shift() - 48) * 10 + r.shift() - 48;
    }
  }, {
    key: "next",
    value: function(r, a, i) {
      if (!r.length)
        return { result: "", checksum: 0 };
      var f = void 0, c = void 0;
      if (r[0] >= 200) {
        c = r.shift() - 105;
        var w = z.SWAP[c];
        w !== void 0 ? f = e.next(r, a + 1, w) : ((i === z.SET_A || i === z.SET_B) && c === z.SHIFT && (r[0] = i === z.SET_A ? r[0] > 95 ? r[0] - 96 : r[0] : r[0] < 32 ? r[0] + 96 : r[0]), f = e.next(r, a + 1, i));
      } else
        c = e.correctIndex(r, i), f = e.next(r, a + 1, i);
      var T = e.getBar(c), N = c * a;
      return {
        result: T + f.result,
        checksum: N + f.checksum
      };
    }
  }]), e;
}(An.default);
Re.default = Tn;
var Et = {};
Object.defineProperty(Et, "__esModule", {
  value: !0
});
var ce = I, $r = function(e) {
  return e.match(new RegExp("^" + ce.A_CHARS + "*"))[0].length;
}, Sr = function(e) {
  return e.match(new RegExp("^" + ce.B_CHARS + "*"))[0].length;
}, Rr = function(e) {
  return e.match(new RegExp("^" + ce.C_CHARS + "*"))[0];
};
function Ot(t, e) {
  var n = e ? ce.A_CHARS : ce.B_CHARS, r = t.match(new RegExp("^(" + n + "+?)(([0-9]{2}){2,})([^0-9]|$)"));
  if (r)
    return r[1] + String.fromCharCode(204) + Mr(t.substring(r[1].length));
  var a = t.match(new RegExp("^" + n + "+"))[0];
  return a.length === t.length ? t : a + String.fromCharCode(e ? 205 : 206) + Ot(t.substring(a.length), !e);
}
function Mr(t) {
  var e = Rr(t), n = e.length;
  if (n === t.length)
    return t;
  t = t.substring(n);
  var r = $r(t) >= Sr(t);
  return e + String.fromCharCode(r ? 206 : 205) + Ot(t, r);
}
Et.default = function(t) {
  var e = void 0, n = Rr(t).length;
  if (n >= 2)
    e = ce.C_START_CHAR + Mr(t);
  else {
    var r = $r(t) > Sr(t);
    e = (r ? ce.A_START_CHAR : ce.B_START_CHAR) + Ot(t, r);
  }
  return e.replace(
    /[\xCD\xCE]([^])[\xCD\xCE]/,
    // Any sequence between 205 and 206 characters
    function(a, i) {
      return String.fromCharCode(203) + i;
    }
  );
};
Object.defineProperty(pt, "__esModule", {
  value: !0
});
var Pn = Re, kn = Tr(Pn), Dn = Et, Bn = Tr(Dn);
function Tr(t) {
  return t && t.__esModule ? t : { default: t };
}
function In(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function ft(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Ln(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Cn = function(t) {
  Ln(e, t);
  function e(n, r) {
    if (In(this, e), /^[\x00-\x7F\xC8-\xD3]+$/.test(n))
      var a = ft(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, (0, Bn.default)(n), r));
    else
      var a = ft(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
    return ft(a);
  }
  return e;
}(kn.default);
pt.default = Cn;
var bt = {};
Object.defineProperty(bt, "__esModule", {
  value: !0
});
var jn = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), Nn = Re, Gn = Fn(Nn), rr = I;
function Fn(t) {
  return t && t.__esModule ? t : { default: t };
}
function Hn(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function Un(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Xn(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Vn = function(t) {
  Xn(e, t);
  function e(n, r) {
    return Hn(this, e), Un(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, rr.A_START_CHAR + n, r));
  }
  return jn(e, [{
    key: "valid",
    value: function() {
      return new RegExp("^" + rr.A_CHARS + "+$").test(this.data);
    }
  }]), e;
}(Gn.default);
bt.default = Vn;
var wt = {};
Object.defineProperty(wt, "__esModule", {
  value: !0
});
var qn = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), zn = Re, Qn = Yn(zn), nr = I;
function Yn(t) {
  return t && t.__esModule ? t : { default: t };
}
function Jn(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function Kn(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Zn(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Wn = function(t) {
  Zn(e, t);
  function e(n, r) {
    return Jn(this, e), Kn(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, nr.B_START_CHAR + n, r));
  }
  return qn(e, [{
    key: "valid",
    value: function() {
      return new RegExp("^" + nr.B_CHARS + "+$").test(this.data);
    }
  }]), e;
}(Qn.default);
wt.default = Wn;
var mt = {};
Object.defineProperty(mt, "__esModule", {
  value: !0
});
var ea = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), ta = Re, ra = na(ta), ar = I;
function na(t) {
  return t && t.__esModule ? t : { default: t };
}
function aa(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function ia(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function oa(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var ua = function(t) {
  oa(e, t);
  function e(n, r) {
    return aa(this, e), ia(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, ar.C_START_CHAR + n, r));
  }
  return ea(e, [{
    key: "valid",
    value: function() {
      return new RegExp("^" + ar.C_CHARS + "+$").test(this.data);
    }
  }]), e;
}(ra.default);
mt.default = ua;
Object.defineProperty(ne, "__esModule", {
  value: !0
});
ne.CODE128C = ne.CODE128B = ne.CODE128A = ne.CODE128 = void 0;
var fa = pt, la = Ye(fa), ca = bt, ha = Ye(ca), va = wt, da = Ye(va), sa = mt, _a = Ye(sa);
function Ye(t) {
  return t && t.__esModule ? t : { default: t };
}
ne.CODE128 = la.default;
ne.CODE128A = ha.default;
ne.CODE128B = da.default;
ne.CODE128C = _a.default;
var X = {}, xt = {}, Z = {};
Object.defineProperty(Z, "__esModule", {
  value: !0
});
Z.SIDE_BIN = "101";
Z.MIDDLE_BIN = "01010";
Z.BINARIES = {
  L: [
    // The L (left) type of encoding
    "0001101",
    "0011001",
    "0010011",
    "0111101",
    "0100011",
    "0110001",
    "0101111",
    "0111011",
    "0110111",
    "0001011"
  ],
  G: [
    // The G type of encoding
    "0100111",
    "0110011",
    "0011011",
    "0100001",
    "0011101",
    "0111001",
    "0000101",
    "0010001",
    "0001001",
    "0010111"
  ],
  R: [
    // The R (right) type of encoding
    "1110010",
    "1100110",
    "1101100",
    "1000010",
    "1011100",
    "1001110",
    "1010000",
    "1000100",
    "1001000",
    "1110100"
  ],
  O: [
    // The O (odd) encoding for UPC-E
    "0001101",
    "0011001",
    "0010011",
    "0111101",
    "0100011",
    "0110001",
    "0101111",
    "0111011",
    "0110111",
    "0001011"
  ],
  E: [
    // The E (even) encoding for UPC-E
    "0100111",
    "0110011",
    "0011011",
    "0100001",
    "0011101",
    "0111001",
    "0000101",
    "0010001",
    "0001001",
    "0010111"
  ]
};
Z.EAN2_STRUCTURE = ["LL", "LG", "GL", "GG"];
Z.EAN5_STRUCTURE = ["GGLLL", "GLGLL", "GLLGL", "GLLLG", "LGGLL", "LLGGL", "LLLGG", "LGLGL", "LGLLG", "LLGLG"];
Z.EAN13_STRUCTURE = ["LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG", "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL"];
var Je = {}, ge = {};
Object.defineProperty(ge, "__esModule", {
  value: !0
});
var ga = Z, ya = function(e, n, r) {
  var a = e.split("").map(function(f, c) {
    return ga.BINARIES[n[c]];
  }).map(function(f, c) {
    return f ? f[e[c]] : "";
  });
  if (r) {
    var i = e.length - 1;
    a = a.map(function(f, c) {
      return c < i ? f + r : f;
    });
  }
  return a.join("");
};
ge.default = ya;
Object.defineProperty(Je, "__esModule", {
  value: !0
});
var pa = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), me = Z, Ea = ge, ir = Pr(Ea), Oa = H, ba = Pr(Oa);
function Pr(t) {
  return t && t.__esModule ? t : { default: t };
}
function wa(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function ma(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function xa(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Aa = function(t) {
  xa(e, t);
  function e(n, r) {
    wa(this, e);
    var a = ma(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
    return a.fontSize = !r.flat && r.fontSize > r.width * 10 ? r.width * 10 : r.fontSize, a.guardHeight = r.height + a.fontSize / 2 + r.textMargin, a;
  }
  return pa(e, [{
    key: "encode",
    value: function() {
      return this.options.flat ? this.encodeFlat() : this.encodeGuarded();
    }
  }, {
    key: "leftText",
    value: function(r, a) {
      return this.text.substr(r, a);
    }
  }, {
    key: "leftEncode",
    value: function(r, a) {
      return (0, ir.default)(r, a);
    }
  }, {
    key: "rightText",
    value: function(r, a) {
      return this.text.substr(r, a);
    }
  }, {
    key: "rightEncode",
    value: function(r, a) {
      return (0, ir.default)(r, a);
    }
  }, {
    key: "encodeGuarded",
    value: function() {
      var r = { fontSize: this.fontSize }, a = { height: this.guardHeight };
      return [{ data: me.SIDE_BIN, options: a }, { data: this.leftEncode(), text: this.leftText(), options: r }, { data: me.MIDDLE_BIN, options: a }, { data: this.rightEncode(), text: this.rightText(), options: r }, { data: me.SIDE_BIN, options: a }];
    }
  }, {
    key: "encodeFlat",
    value: function() {
      var r = [me.SIDE_BIN, this.leftEncode(), me.MIDDLE_BIN, this.rightEncode(), me.SIDE_BIN];
      return {
        data: r.join(""),
        text: this.text
      };
    }
  }]), e;
}(ba.default);
Je.default = Aa;
Object.defineProperty(xt, "__esModule", {
  value: !0
});
var $a = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), De = function t(e, n, r) {
  e === null && (e = Function.prototype);
  var a = Object.getOwnPropertyDescriptor(e, n);
  if (a === void 0) {
    var i = Object.getPrototypeOf(e);
    return i === null ? void 0 : t(i, n, r);
  } else {
    if ("value" in a)
      return a.value;
    var f = a.get;
    return f === void 0 ? void 0 : f.call(r);
  }
}, Sa = Z, Ra = Je, Ma = Ta(Ra);
function Ta(t) {
  return t && t.__esModule ? t : { default: t };
}
function Pa(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function ka(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Da(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var or = function(e) {
  var n = e.substr(0, 12).split("").map(function(r) {
    return +r;
  }).reduce(function(r, a, i) {
    return i % 2 ? r + a * 3 : r + a;
  }, 0);
  return (10 - n % 10) % 10;
}, Ba = function(t) {
  Da(e, t);
  function e(n, r) {
    Pa(this, e), n.search(/^[0-9]{12}$/) !== -1 && (n += or(n));
    var a = ka(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
    return a.lastChar = r.lastChar, a;
  }
  return $a(e, [{
    key: "valid",
    value: function() {
      return this.data.search(/^[0-9]{13}$/) !== -1 && +this.data[12] === or(this.data);
    }
  }, {
    key: "leftText",
    value: function() {
      return De(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "leftText", this).call(this, 1, 6);
    }
  }, {
    key: "leftEncode",
    value: function() {
      var r = this.data.substr(1, 6), a = Sa.EAN13_STRUCTURE[this.data[0]];
      return De(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "leftEncode", this).call(this, r, a);
    }
  }, {
    key: "rightText",
    value: function() {
      return De(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "rightText", this).call(this, 7, 6);
    }
  }, {
    key: "rightEncode",
    value: function() {
      var r = this.data.substr(7, 6);
      return De(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "rightEncode", this).call(this, r, "RRRRRR");
    }
    // The "standard" way of printing EAN13 barcodes with guard bars
  }, {
    key: "encodeGuarded",
    value: function() {
      var r = De(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "encodeGuarded", this).call(this);
      return this.options.displayValue && (r.unshift({
        data: "000000000000",
        text: this.text.substr(0, 1),
        options: { textAlign: "left", fontSize: this.fontSize }
      }), this.options.lastChar && (r.push({
        data: "00"
      }), r.push({
        data: "00000",
        text: this.options.lastChar,
        options: { fontSize: this.fontSize }
      }))), r;
    }
  }]), e;
}(Ma.default);
xt.default = Ba;
var At = {};
Object.defineProperty(At, "__esModule", {
  value: !0
});
var Ia = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), He = function t(e, n, r) {
  e === null && (e = Function.prototype);
  var a = Object.getOwnPropertyDescriptor(e, n);
  if (a === void 0) {
    var i = Object.getPrototypeOf(e);
    return i === null ? void 0 : t(i, n, r);
  } else {
    if ("value" in a)
      return a.value;
    var f = a.get;
    return f === void 0 ? void 0 : f.call(r);
  }
}, La = Je, Ca = ja(La);
function ja(t) {
  return t && t.__esModule ? t : { default: t };
}
function Na(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function Ga(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Fa(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var ur = function(e) {
  var n = e.substr(0, 7).split("").map(function(r) {
    return +r;
  }).reduce(function(r, a, i) {
    return i % 2 ? r + a : r + a * 3;
  }, 0);
  return (10 - n % 10) % 10;
}, Ha = function(t) {
  Fa(e, t);
  function e(n, r) {
    return Na(this, e), n.search(/^[0-9]{7}$/) !== -1 && (n += ur(n)), Ga(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
  }
  return Ia(e, [{
    key: "valid",
    value: function() {
      return this.data.search(/^[0-9]{8}$/) !== -1 && +this.data[7] === ur(this.data);
    }
  }, {
    key: "leftText",
    value: function() {
      return He(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "leftText", this).call(this, 0, 4);
    }
  }, {
    key: "leftEncode",
    value: function() {
      var r = this.data.substr(0, 4);
      return He(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "leftEncode", this).call(this, r, "LLLL");
    }
  }, {
    key: "rightText",
    value: function() {
      return He(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "rightText", this).call(this, 4, 4);
    }
  }, {
    key: "rightEncode",
    value: function() {
      var r = this.data.substr(4, 4);
      return He(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "rightEncode", this).call(this, r, "RRRR");
    }
  }]), e;
}(Ca.default);
At.default = Ha;
var $t = {};
Object.defineProperty($t, "__esModule", {
  value: !0
});
var Ua = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), Xa = Z, Va = ge, qa = kr(Va), za = H, Qa = kr(za);
function kr(t) {
  return t && t.__esModule ? t : { default: t };
}
function Ya(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function Ja(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Ka(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Za = function(e) {
  var n = e.split("").map(function(r) {
    return +r;
  }).reduce(function(r, a, i) {
    return i % 2 ? r + a * 9 : r + a * 3;
  }, 0);
  return n % 10;
}, Wa = function(t) {
  Ka(e, t);
  function e(n, r) {
    return Ya(this, e), Ja(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
  }
  return Ua(e, [{
    key: "valid",
    value: function() {
      return this.data.search(/^[0-9]{5}$/) !== -1;
    }
  }, {
    key: "encode",
    value: function() {
      var r = Xa.EAN5_STRUCTURE[Za(this.data)];
      return {
        data: "1011" + (0, qa.default)(this.data, r, "01"),
        text: this.text
      };
    }
  }]), e;
}(Qa.default);
$t.default = Wa;
var St = {};
Object.defineProperty(St, "__esModule", {
  value: !0
});
var ei = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), ti = Z, ri = ge, ni = Dr(ri), ai = H, ii = Dr(ai);
function Dr(t) {
  return t && t.__esModule ? t : { default: t };
}
function oi(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function ui(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function fi(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var li = function(t) {
  fi(e, t);
  function e(n, r) {
    return oi(this, e), ui(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
  }
  return ei(e, [{
    key: "valid",
    value: function() {
      return this.data.search(/^[0-9]{2}$/) !== -1;
    }
  }, {
    key: "encode",
    value: function() {
      var r = ti.EAN2_STRUCTURE[parseInt(this.data) % 4];
      return {
        // Start bits + Encode the two digits with 01 in between
        data: "1011" + (0, ni.default)(this.data, r, "01"),
        text: this.text
      };
    }
  }]), e;
}(ii.default);
St.default = li;
var Le = {};
Object.defineProperty(Le, "__esModule", {
  value: !0
});
var ci = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}();
Le.checksum = dt;
var hi = ge, xe = Br(hi), vi = H, di = Br(vi);
function Br(t) {
  return t && t.__esModule ? t : { default: t };
}
function si(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function _i(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function gi(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var yi = function(t) {
  gi(e, t);
  function e(n, r) {
    si(this, e), n.search(/^[0-9]{11}$/) !== -1 && (n += dt(n));
    var a = _i(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
    return a.displayValue = r.displayValue, r.fontSize > r.width * 10 ? a.fontSize = r.width * 10 : a.fontSize = r.fontSize, a.guardHeight = r.height + a.fontSize / 2 + r.textMargin, a;
  }
  return ci(e, [{
    key: "valid",
    value: function() {
      return this.data.search(/^[0-9]{12}$/) !== -1 && this.data[11] == dt(this.data);
    }
  }, {
    key: "encode",
    value: function() {
      return this.options.flat ? this.flatEncoding() : this.guardedEncoding();
    }
  }, {
    key: "flatEncoding",
    value: function() {
      var r = "";
      return r += "101", r += (0, xe.default)(this.data.substr(0, 6), "LLLLLL"), r += "01010", r += (0, xe.default)(this.data.substr(6, 6), "RRRRRR"), r += "101", {
        data: r,
        text: this.text
      };
    }
  }, {
    key: "guardedEncoding",
    value: function() {
      var r = [];
      return this.displayValue && r.push({
        data: "00000000",
        text: this.text.substr(0, 1),
        options: { textAlign: "left", fontSize: this.fontSize }
      }), r.push({
        data: "101" + (0, xe.default)(this.data[0], "L"),
        options: { height: this.guardHeight }
      }), r.push({
        data: (0, xe.default)(this.data.substr(1, 5), "LLLLL"),
        text: this.text.substr(1, 5),
        options: { fontSize: this.fontSize }
      }), r.push({
        data: "01010",
        options: { height: this.guardHeight }
      }), r.push({
        data: (0, xe.default)(this.data.substr(6, 5), "RRRRR"),
        text: this.text.substr(6, 5),
        options: { fontSize: this.fontSize }
      }), r.push({
        data: (0, xe.default)(this.data[11], "R") + "101",
        options: { height: this.guardHeight }
      }), this.displayValue && r.push({
        data: "00000000",
        text: this.text.substr(11, 1),
        options: { textAlign: "right", fontSize: this.fontSize }
      }), r;
    }
  }]), e;
}(di.default);
function dt(t) {
  var e = 0, n;
  for (n = 1; n < 11; n += 2)
    e += parseInt(t[n]);
  for (n = 0; n < 11; n += 2)
    e += parseInt(t[n]) * 3;
  return (10 - e % 10) % 10;
}
Le.default = yi;
var Rt = {};
Object.defineProperty(Rt, "__esModule", {
  value: !0
});
var pi = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), Ei = ge, Oi = Ir(Ei), bi = H, wi = Ir(bi), mi = Le;
function Ir(t) {
  return t && t.__esModule ? t : { default: t };
}
function xi(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function lt(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Ai(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var $i = ["XX00000XXX", "XX10000XXX", "XX20000XXX", "XXX00000XX", "XXXX00000X", "XXXXX00005", "XXXXX00006", "XXXXX00007", "XXXXX00008", "XXXXX00009"], Si = [["EEEOOO", "OOOEEE"], ["EEOEOO", "OOEOEE"], ["EEOOEO", "OOEEOE"], ["EEOOOE", "OOEEEO"], ["EOEEOO", "OEOOEE"], ["EOOEEO", "OEEOOE"], ["EOOOEE", "OEEEOO"], ["EOEOEO", "OEOEOE"], ["EOEOOE", "OEOEEO"], ["EOOEOE", "OEEOEO"]], Ri = function(t) {
  Ai(e, t);
  function e(n, r) {
    xi(this, e);
    var a = lt(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
    if (a.isValid = !1, n.search(/^[0-9]{6}$/) !== -1)
      a.middleDigits = n, a.upcA = fr(n, "0"), a.text = r.text || "" + a.upcA[0] + n + a.upcA[a.upcA.length - 1], a.isValid = !0;
    else if (n.search(/^[01][0-9]{7}$/) !== -1)
      if (a.middleDigits = n.substring(1, n.length - 1), a.upcA = fr(a.middleDigits, n[0]), a.upcA[a.upcA.length - 1] === n[n.length - 1])
        a.isValid = !0;
      else
        return lt(a);
    else
      return lt(a);
    return a.displayValue = r.displayValue, r.fontSize > r.width * 10 ? a.fontSize = r.width * 10 : a.fontSize = r.fontSize, a.guardHeight = r.height + a.fontSize / 2 + r.textMargin, a;
  }
  return pi(e, [{
    key: "valid",
    value: function() {
      return this.isValid;
    }
  }, {
    key: "encode",
    value: function() {
      return this.options.flat ? this.flatEncoding() : this.guardedEncoding();
    }
  }, {
    key: "flatEncoding",
    value: function() {
      var r = "";
      return r += "101", r += this.encodeMiddleDigits(), r += "010101", {
        data: r,
        text: this.text
      };
    }
  }, {
    key: "guardedEncoding",
    value: function() {
      var r = [];
      return this.displayValue && r.push({
        data: "00000000",
        text: this.text[0],
        options: { textAlign: "left", fontSize: this.fontSize }
      }), r.push({
        data: "101",
        options: { height: this.guardHeight }
      }), r.push({
        data: this.encodeMiddleDigits(),
        text: this.text.substring(1, 7),
        options: { fontSize: this.fontSize }
      }), r.push({
        data: "010101",
        options: { height: this.guardHeight }
      }), this.displayValue && r.push({
        data: "00000000",
        text: this.text[7],
        options: { textAlign: "right", fontSize: this.fontSize }
      }), r;
    }
  }, {
    key: "encodeMiddleDigits",
    value: function() {
      var r = this.upcA[0], a = this.upcA[this.upcA.length - 1], i = Si[parseInt(a)][parseInt(r)];
      return (0, Oi.default)(this.middleDigits, i);
    }
  }]), e;
}(wi.default);
function fr(t, e) {
  for (var n = parseInt(t[t.length - 1]), r = $i[n], a = "", i = 0, f = 0; f < r.length; f++) {
    var c = r[f];
    c === "X" ? a += t[i++] : a += c;
  }
  return a = "" + e + a, "" + a + (0, mi.checksum)(a);
}
Rt.default = Ri;
Object.defineProperty(X, "__esModule", {
  value: !0
});
X.UPCE = X.UPC = X.EAN2 = X.EAN5 = X.EAN8 = X.EAN13 = void 0;
var Mi = xt, Ti = Me(Mi), Pi = At, ki = Me(Pi), Di = $t, Bi = Me(Di), Ii = St, Li = Me(Ii), Ci = Le, ji = Me(Ci), Ni = Rt, Gi = Me(Ni);
function Me(t) {
  return t && t.__esModule ? t : { default: t };
}
X.EAN13 = Ti.default;
X.EAN8 = ki.default;
X.EAN5 = Bi.default;
X.EAN2 = Li.default;
X.UPC = ji.default;
X.UPCE = Gi.default;
var $e = {}, Ke = {}, Ce = {};
Object.defineProperty(Ce, "__esModule", {
  value: !0
});
Ce.START_BIN = "1010";
Ce.END_BIN = "11101";
Ce.BINARIES = ["00110", "10001", "01001", "11000", "00101", "10100", "01100", "00011", "10010", "01010"];
Object.defineProperty(Ke, "__esModule", {
  value: !0
});
var Fi = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), Ue = Ce, Hi = H, Ui = Xi(Hi);
function Xi(t) {
  return t && t.__esModule ? t : { default: t };
}
function Vi(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function qi(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function zi(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Qi = function(t) {
  zi(e, t);
  function e() {
    return Vi(this, e), qi(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments));
  }
  return Fi(e, [{
    key: "valid",
    value: function() {
      return this.data.search(/^([0-9]{2})+$/) !== -1;
    }
  }, {
    key: "encode",
    value: function() {
      var r = this, a = this.data.match(/.{2}/g).map(function(i) {
        return r.encodePair(i);
      }).join("");
      return {
        data: Ue.START_BIN + a + Ue.END_BIN,
        text: this.text
      };
    }
    // Calculate the data of a number pair
  }, {
    key: "encodePair",
    value: function(r) {
      var a = Ue.BINARIES[r[1]];
      return Ue.BINARIES[r[0]].split("").map(function(i, f) {
        return (i === "1" ? "111" : "1") + (a[f] === "1" ? "000" : "0");
      }).join("");
    }
  }]), e;
}(Ui.default);
Ke.default = Qi;
var Mt = {};
Object.defineProperty(Mt, "__esModule", {
  value: !0
});
var Yi = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), Ji = Ke, Ki = Zi(Ji);
function Zi(t) {
  return t && t.__esModule ? t : { default: t };
}
function Wi(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function eo(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function to(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var lr = function(e) {
  var n = e.substr(0, 13).split("").map(function(r) {
    return parseInt(r, 10);
  }).reduce(function(r, a, i) {
    return r + a * (3 - i % 2 * 2);
  }, 0);
  return Math.ceil(n / 10) * 10 - n;
}, ro = function(t) {
  to(e, t);
  function e(n, r) {
    return Wi(this, e), n.search(/^[0-9]{13}$/) !== -1 && (n += lr(n)), eo(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
  }
  return Yi(e, [{
    key: "valid",
    value: function() {
      return this.data.search(/^[0-9]{14}$/) !== -1 && +this.data[13] === lr(this.data);
    }
  }]), e;
}(Ki.default);
Mt.default = ro;
Object.defineProperty($e, "__esModule", {
  value: !0
});
$e.ITF14 = $e.ITF = void 0;
var no = Ke, ao = Lr(no), io = Mt, oo = Lr(io);
function Lr(t) {
  return t && t.__esModule ? t : { default: t };
}
$e.ITF = ao.default;
$e.ITF14 = oo.default;
var K = {}, ye = {};
Object.defineProperty(ye, "__esModule", {
  value: !0
});
var uo = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), fo = H, lo = co(fo);
function co(t) {
  return t && t.__esModule ? t : { default: t };
}
function ho(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function vo(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function so(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var _o = function(t) {
  so(e, t);
  function e(n, r) {
    return ho(this, e), vo(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
  }
  return uo(e, [{
    key: "encode",
    value: function() {
      for (var r = "110", a = 0; a < this.data.length; a++) {
        var i = parseInt(this.data[a]), f = i.toString(2);
        f = go(f, 4 - f.length);
        for (var c = 0; c < f.length; c++)
          r += f[c] == "0" ? "100" : "110";
      }
      return r += "1001", {
        data: r,
        text: this.text
      };
    }
  }, {
    key: "valid",
    value: function() {
      return this.data.search(/^[0-9]+$/) !== -1;
    }
  }]), e;
}(lo.default);
function go(t, e) {
  for (var n = 0; n < e; n++)
    t = "0" + t;
  return t;
}
ye.default = _o;
var Tt = {}, pe = {};
Object.defineProperty(pe, "__esModule", {
  value: !0
});
pe.mod10 = yo;
pe.mod11 = po;
function yo(t) {
  for (var e = 0, n = 0; n < t.length; n++) {
    var r = parseInt(t[n]);
    (n + t.length) % 2 === 0 ? e += r : e += r * 2 % 10 + Math.floor(r * 2 / 10);
  }
  return (10 - e % 10) % 10;
}
function po(t) {
  for (var e = 0, n = [2, 3, 4, 5, 6, 7], r = 0; r < t.length; r++) {
    var a = parseInt(t[t.length - 1 - r]);
    e += n[r % n.length] * a;
  }
  return (11 - e % 11) % 11;
}
Object.defineProperty(Tt, "__esModule", {
  value: !0
});
var Eo = ye, Oo = wo(Eo), bo = pe;
function wo(t) {
  return t && t.__esModule ? t : { default: t };
}
function mo(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function xo(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Ao(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var $o = function(t) {
  Ao(e, t);
  function e(n, r) {
    return mo(this, e), xo(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n + (0, bo.mod10)(n), r));
  }
  return e;
}(Oo.default);
Tt.default = $o;
var Pt = {};
Object.defineProperty(Pt, "__esModule", {
  value: !0
});
var So = ye, Ro = To(So), Mo = pe;
function To(t) {
  return t && t.__esModule ? t : { default: t };
}
function Po(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function ko(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Do(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Bo = function(t) {
  Do(e, t);
  function e(n, r) {
    return Po(this, e), ko(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n + (0, Mo.mod11)(n), r));
  }
  return e;
}(Ro.default);
Pt.default = Bo;
var kt = {};
Object.defineProperty(kt, "__esModule", {
  value: !0
});
var Io = ye, Lo = Co(Io), cr = pe;
function Co(t) {
  return t && t.__esModule ? t : { default: t };
}
function jo(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function No(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Go(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Fo = function(t) {
  Go(e, t);
  function e(n, r) {
    return jo(this, e), n += (0, cr.mod10)(n), n += (0, cr.mod10)(n), No(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
  }
  return e;
}(Lo.default);
kt.default = Fo;
var Dt = {};
Object.defineProperty(Dt, "__esModule", {
  value: !0
});
var Ho = ye, Uo = Xo(Ho), hr = pe;
function Xo(t) {
  return t && t.__esModule ? t : { default: t };
}
function Vo(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function qo(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function zo(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Qo = function(t) {
  zo(e, t);
  function e(n, r) {
    return Vo(this, e), n += (0, hr.mod11)(n), n += (0, hr.mod10)(n), qo(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
  }
  return e;
}(Uo.default);
Dt.default = Qo;
Object.defineProperty(K, "__esModule", {
  value: !0
});
K.MSI1110 = K.MSI1010 = K.MSI11 = K.MSI10 = K.MSI = void 0;
var Yo = ye, Jo = je(Yo), Ko = Tt, Zo = je(Ko), Wo = Pt, eu = je(Wo), tu = kt, ru = je(tu), nu = Dt, au = je(nu);
function je(t) {
  return t && t.__esModule ? t : { default: t };
}
K.MSI = Jo.default;
K.MSI10 = Zo.default;
K.MSI11 = eu.default;
K.MSI1010 = ru.default;
K.MSI1110 = au.default;
var Ze = {};
Object.defineProperty(Ze, "__esModule", {
  value: !0
});
Ze.pharmacode = void 0;
var iu = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), ou = H, uu = fu(ou);
function fu(t) {
  return t && t.__esModule ? t : { default: t };
}
function lu(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function cu(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function hu(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var vu = function(t) {
  hu(e, t);
  function e(n, r) {
    lu(this, e);
    var a = cu(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
    return a.number = parseInt(n, 10), a;
  }
  return iu(e, [{
    key: "encode",
    value: function() {
      for (var r = this.number, a = ""; !isNaN(r) && r != 0; )
        r % 2 === 0 ? (a = "11100" + a, r = (r - 2) / 2) : (a = "100" + a, r = (r - 1) / 2);
      return a = a.slice(0, -2), {
        data: a,
        text: this.text
      };
    }
  }, {
    key: "valid",
    value: function() {
      return this.number >= 3 && this.number <= 131070;
    }
  }]), e;
}(uu.default);
Ze.pharmacode = vu;
var We = {};
Object.defineProperty(We, "__esModule", {
  value: !0
});
We.codabar = void 0;
var du = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), su = H, _u = gu(su);
function gu(t) {
  return t && t.__esModule ? t : { default: t };
}
function yu(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function pu(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Eu(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Ou = function(t) {
  Eu(e, t);
  function e(n, r) {
    yu(this, e), n.search(/^[0-9\-\$\:\.\+\/]+$/) === 0 && (n = "A" + n + "A");
    var a = pu(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n.toUpperCase(), r));
    return a.text = a.options.text || a.text.replace(/[A-D]/g, ""), a;
  }
  return du(e, [{
    key: "valid",
    value: function() {
      return this.data.search(/^[A-D][0-9\-\$\:\.\+\/]+[A-D]$/) !== -1;
    }
  }, {
    key: "encode",
    value: function() {
      for (var r = [], a = this.getEncodings(), i = 0; i < this.data.length; i++)
        r.push(a[this.data.charAt(i)]), i !== this.data.length - 1 && r.push("0");
      return {
        text: this.text,
        data: r.join("")
      };
    }
  }, {
    key: "getEncodings",
    value: function() {
      return {
        0: "101010011",
        1: "101011001",
        2: "101001011",
        3: "110010101",
        4: "101101001",
        5: "110101001",
        6: "100101011",
        7: "100101101",
        8: "100110101",
        9: "110100101",
        "-": "101001101",
        $: "101100101",
        ":": "1101011011",
        "/": "1101101011",
        ".": "1101101101",
        "+": "1011011011",
        A: "1011001001",
        B: "1001001011",
        C: "1010010011",
        D: "1010011001"
      };
    }
  }]), e;
}(_u.default);
We.codabar = Ou;
var Se = {}, et = {}, Ne = {};
Object.defineProperty(Ne, "__esModule", {
  value: !0
});
Ne.SYMBOLS = [
  "0",
  "1",
  "2",
  "3",
  "4",
  "5",
  "6",
  "7",
  "8",
  "9",
  "A",
  "B",
  "C",
  "D",
  "E",
  "F",
  "G",
  "H",
  "I",
  "J",
  "K",
  "L",
  "M",
  "N",
  "O",
  "P",
  "Q",
  "R",
  "S",
  "T",
  "U",
  "V",
  "W",
  "X",
  "Y",
  "Z",
  "-",
  ".",
  " ",
  "$",
  "/",
  "+",
  "%",
  // Only used for csum and multi-symbols character encodings
  "($)",
  "(%)",
  "(/)",
  "(+)",
  // Start/Stop
  "ÿ"
];
Ne.BINARIES = ["100010100", "101001000", "101000100", "101000010", "100101000", "100100100", "100100010", "101010000", "100010010", "100001010", "110101000", "110100100", "110100010", "110010100", "110010010", "110001010", "101101000", "101100100", "101100010", "100110100", "100011010", "101011000", "101001100", "101000110", "100101100", "100010110", "110110100", "110110010", "110101100", "110100110", "110010110", "110011010", "101101100", "101100110", "100110110", "100111010", "100101110", "111010100", "111010010", "111001010", "101101110", "101110110", "110101110", "100100110", "111011010", "111010110", "100110010", "101011110"];
Ne.MULTI_SYMBOLS = {
  "\0": ["(%)", "U"],
  "": ["($)", "A"],
  "": ["($)", "B"],
  "": ["($)", "C"],
  "": ["($)", "D"],
  "": ["($)", "E"],
  "": ["($)", "F"],
  "\x07": ["($)", "G"],
  "\b": ["($)", "H"],
  "	": ["($)", "I"],
  "\n": ["($)", "J"],
  "\v": ["($)", "K"],
  "\f": ["($)", "L"],
  "\r": ["($)", "M"],
  "": ["($)", "N"],
  "": ["($)", "O"],
  "": ["($)", "P"],
  "": ["($)", "Q"],
  "": ["($)", "R"],
  "": ["($)", "S"],
  "": ["($)", "T"],
  "": ["($)", "U"],
  "": ["($)", "V"],
  "": ["($)", "W"],
  "": ["($)", "X"],
  "": ["($)", "Y"],
  "": ["($)", "Z"],
  "\x1B": ["(%)", "A"],
  "": ["(%)", "B"],
  "": ["(%)", "C"],
  "": ["(%)", "D"],
  "": ["(%)", "E"],
  "!": ["(/)", "A"],
  '"': ["(/)", "B"],
  "#": ["(/)", "C"],
  "&": ["(/)", "F"],
  "'": ["(/)", "G"],
  "(": ["(/)", "H"],
  ")": ["(/)", "I"],
  "*": ["(/)", "J"],
  ",": ["(/)", "L"],
  ":": ["(/)", "Z"],
  ";": ["(%)", "F"],
  "<": ["(%)", "G"],
  "=": ["(%)", "H"],
  ">": ["(%)", "I"],
  "?": ["(%)", "J"],
  "@": ["(%)", "V"],
  "[": ["(%)", "K"],
  "\\": ["(%)", "L"],
  "]": ["(%)", "M"],
  "^": ["(%)", "N"],
  _: ["(%)", "O"],
  "`": ["(%)", "W"],
  a: ["(+)", "A"],
  b: ["(+)", "B"],
  c: ["(+)", "C"],
  d: ["(+)", "D"],
  e: ["(+)", "E"],
  f: ["(+)", "F"],
  g: ["(+)", "G"],
  h: ["(+)", "H"],
  i: ["(+)", "I"],
  j: ["(+)", "J"],
  k: ["(+)", "K"],
  l: ["(+)", "L"],
  m: ["(+)", "M"],
  n: ["(+)", "N"],
  o: ["(+)", "O"],
  p: ["(+)", "P"],
  q: ["(+)", "Q"],
  r: ["(+)", "R"],
  s: ["(+)", "S"],
  t: ["(+)", "T"],
  u: ["(+)", "U"],
  v: ["(+)", "V"],
  w: ["(+)", "W"],
  x: ["(+)", "X"],
  y: ["(+)", "Y"],
  z: ["(+)", "Z"],
  "{": ["(%)", "P"],
  "|": ["(%)", "Q"],
  "}": ["(%)", "R"],
  "~": ["(%)", "S"],
  "": ["(%)", "T"]
};
Object.defineProperty(et, "__esModule", {
  value: !0
});
var bu = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), Xe = Ne, wu = H, mu = xu(wu);
function xu(t) {
  return t && t.__esModule ? t : { default: t };
}
function Au(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function $u(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Su(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Ru = function(t) {
  Su(e, t);
  function e(n, r) {
    return Au(this, e), $u(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
  }
  return bu(e, [{
    key: "valid",
    value: function() {
      return /^[0-9A-Z\-. $/+%]+$/.test(this.data);
    }
  }, {
    key: "encode",
    value: function() {
      var r = this.data.split("").flatMap(function(c) {
        return Xe.MULTI_SYMBOLS[c] || c;
      }), a = r.map(function(c) {
        return e.getEncoding(c);
      }).join(""), i = e.checksum(r, 20), f = e.checksum(r.concat(i), 15);
      return {
        text: this.text,
        data: (
          // Add the start bits
          e.getEncoding("ÿ") + // Add the encoded bits
          a + // Add the checksum
          e.getEncoding(i) + e.getEncoding(f) + // Add the stop bits
          e.getEncoding("ÿ") + // Add the termination bit
          "1"
        )
      };
    }
    // Get the binary encoding of a symbol
  }], [{
    key: "getEncoding",
    value: function(r) {
      return Xe.BINARIES[e.symbolValue(r)];
    }
    // Get the symbol for a symbol value
  }, {
    key: "getSymbol",
    value: function(r) {
      return Xe.SYMBOLS[r];
    }
    // Get the symbol value of a symbol
  }, {
    key: "symbolValue",
    value: function(r) {
      return Xe.SYMBOLS.indexOf(r);
    }
    // Calculate a checksum symbol
  }, {
    key: "checksum",
    value: function(r, a) {
      var i = r.slice().reverse().reduce(function(f, c, w) {
        var T = w % a + 1;
        return f + e.symbolValue(c) * T;
      }, 0);
      return e.getSymbol(i % 47);
    }
  }]), e;
}(mu.default);
et.default = Ru;
var Bt = {};
Object.defineProperty(Bt, "__esModule", {
  value: !0
});
var Mu = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), Tu = et, Pu = ku(Tu);
function ku(t) {
  return t && t.__esModule ? t : { default: t };
}
function Du(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function Bu(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function Iu(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Lu = function(t) {
  Iu(e, t);
  function e(n, r) {
    return Du(this, e), Bu(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
  }
  return Mu(e, [{
    key: "valid",
    value: function() {
      return /^[\x00-\x7f]+$/.test(this.data);
    }
  }]), e;
}(Pu.default);
Bt.default = Lu;
Object.defineProperty(Se, "__esModule", {
  value: !0
});
Se.CODE93FullASCII = Se.CODE93 = void 0;
var Cu = et, ju = Cr(Cu), Nu = Bt, Gu = Cr(Nu);
function Cr(t) {
  return t && t.__esModule ? t : { default: t };
}
Se.CODE93 = ju.default;
Se.CODE93FullASCII = Gu.default;
var tt = {};
Object.defineProperty(tt, "__esModule", {
  value: !0
});
tt.GenericBarcode = void 0;
var Fu = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), Hu = H, Uu = Xu(Hu);
function Xu(t) {
  return t && t.__esModule ? t : { default: t };
}
function Vu(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function qu(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function zu(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var Qu = function(t) {
  zu(e, t);
  function e(n, r) {
    return Vu(this, e), qu(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, n, r));
  }
  return Fu(e, [{
    key: "encode",
    value: function() {
      return {
        data: "10101010101010101010101010101010101010101",
        text: this.text
      };
    }
    // Resturn true/false if the string provided is valid for this encoder
  }, {
    key: "valid",
    value: function() {
      return !0;
    }
  }]), e;
}(Uu.default);
tt.GenericBarcode = Qu;
Object.defineProperty(yt, "__esModule", {
  value: !0
});
var Yu = Qe, Ve = ne, Ae = X, vr = $e, Be = K, Ju = Ze, Ku = We, dr = Se, Zu = tt;
yt.default = {
  CODE39: Yu.CODE39,
  CODE128: Ve.CODE128,
  CODE128A: Ve.CODE128A,
  CODE128B: Ve.CODE128B,
  CODE128C: Ve.CODE128C,
  EAN13: Ae.EAN13,
  EAN8: Ae.EAN8,
  EAN5: Ae.EAN5,
  EAN2: Ae.EAN2,
  UPC: Ae.UPC,
  UPCE: Ae.UPCE,
  ITF14: vr.ITF14,
  ITF: vr.ITF,
  MSI: Be.MSI,
  MSI10: Be.MSI10,
  MSI11: Be.MSI11,
  MSI1010: Be.MSI1010,
  MSI1110: Be.MSI1110,
  pharmacode: Ju.pharmacode,
  codabar: Ku.codabar,
  CODE93: dr.CODE93,
  CODE93FullASCII: dr.CODE93FullASCII,
  GenericBarcode: Zu.GenericBarcode
};
var Te = {};
Object.defineProperty(Te, "__esModule", {
  value: !0
});
var Wu = Object.assign || function(t) {
  for (var e = 1; e < arguments.length; e++) {
    var n = arguments[e];
    for (var r in n)
      Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r]);
  }
  return t;
};
Te.default = function(t, e) {
  return Wu({}, t, e);
};
var It = {};
Object.defineProperty(It, "__esModule", {
  value: !0
});
It.default = e1;
function e1(t) {
  var e = [];
  function n(r) {
    if (Array.isArray(r))
      for (var a = 0; a < r.length; a++)
        n(r[a]);
    else
      r.text = r.text || "", r.data = r.data || "", e.push(r);
  }
  return n(t), e;
}
var Lt = {};
Object.defineProperty(Lt, "__esModule", {
  value: !0
});
Lt.default = t1;
function t1(t) {
  return t.marginTop = t.marginTop || t.margin, t.marginBottom = t.marginBottom || t.margin, t.marginRight = t.marginRight || t.margin, t.marginLeft = t.marginLeft || t.margin, t;
}
var Ct = {}, jt = {}, rt = {};
Object.defineProperty(rt, "__esModule", {
  value: !0
});
rt.default = r1;
function r1(t) {
  var e = ["width", "height", "textMargin", "fontSize", "margin", "marginTop", "marginBottom", "marginLeft", "marginRight"];
  for (var n in e)
    e.hasOwnProperty(n) && (n = e[n], typeof t[n] == "string" && (t[n] = parseInt(t[n], 10)));
  return typeof t.displayValue == "string" && (t.displayValue = t.displayValue != "false"), t;
}
var nt = {};
Object.defineProperty(nt, "__esModule", {
  value: !0
});
var n1 = {
  width: 2,
  height: 100,
  format: "auto",
  displayValue: !0,
  fontOptions: "",
  font: "monospace",
  text: void 0,
  textAlign: "center",
  textPosition: "bottom",
  textMargin: 2,
  fontSize: 20,
  background: "#ffffff",
  lineColor: "#000000",
  margin: 10,
  marginTop: void 0,
  marginBottom: void 0,
  marginLeft: void 0,
  marginRight: void 0,
  valid: function() {
  }
};
nt.default = n1;
Object.defineProperty(jt, "__esModule", {
  value: !0
});
var a1 = rt, i1 = jr(a1), o1 = nt, sr = jr(o1);
function jr(t) {
  return t && t.__esModule ? t : { default: t };
}
function u1(t) {
  var e = {};
  for (var n in sr.default)
    sr.default.hasOwnProperty(n) && (t.hasAttribute("jsbarcode-" + n.toLowerCase()) && (e[n] = t.getAttribute("jsbarcode-" + n.toLowerCase())), t.hasAttribute("data-" + n.toLowerCase()) && (e[n] = t.getAttribute("data-" + n.toLowerCase())));
  return e.value = t.getAttribute("jsbarcode-value") || t.getAttribute("data-value"), e = (0, i1.default)(e), e;
}
jt.default = u1;
var Nt = {}, Gt = {}, Q = {};
Object.defineProperty(Q, "__esModule", {
  value: !0
});
Q.getTotalWidthOfEncodings = Q.calculateEncodingAttributes = Q.getBarcodePadding = Q.getEncodingHeight = Q.getMaximumHeightOfEncodings = void 0;
var f1 = Te, l1 = c1(f1);
function c1(t) {
  return t && t.__esModule ? t : { default: t };
}
function Nr(t, e) {
  return e.height + (e.displayValue && t.text.length > 0 ? e.fontSize + e.textMargin : 0) + e.marginTop + e.marginBottom;
}
function Gr(t, e, n) {
  if (n.displayValue && e < t) {
    if (n.textAlign == "center")
      return Math.floor((t - e) / 2);
    if (n.textAlign == "left")
      return 0;
    if (n.textAlign == "right")
      return Math.floor(t - e);
  }
  return 0;
}
function h1(t, e, n) {
  for (var r = 0; r < t.length; r++) {
    var a = t[r], i = (0, l1.default)(e, a.options), f;
    i.displayValue ? f = s1(a.text, i, n) : f = 0;
    var c = a.data.length * i.width;
    a.width = Math.ceil(Math.max(f, c)), a.height = Nr(a, i), a.barcodePadding = Gr(f, c, i);
  }
}
function v1(t) {
  for (var e = 0, n = 0; n < t.length; n++)
    e += t[n].width;
  return e;
}
function d1(t) {
  for (var e = 0, n = 0; n < t.length; n++)
    t[n].height > e && (e = t[n].height);
  return e;
}
function s1(t, e, n) {
  var r;
  if (n)
    r = n;
  else if (typeof document < "u")
    r = document.createElement("canvas").getContext("2d");
  else
    return 0;
  r.font = e.fontOptions + " " + e.fontSize + "px " + e.font;
  var a = r.measureText(t);
  if (!a)
    return 0;
  var i = a.width;
  return i;
}
Q.getMaximumHeightOfEncodings = d1;
Q.getEncodingHeight = Nr;
Q.getBarcodePadding = Gr;
Q.calculateEncodingAttributes = h1;
Q.getTotalWidthOfEncodings = v1;
Object.defineProperty(Gt, "__esModule", {
  value: !0
});
var _1 = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), g1 = Te, y1 = p1(g1), ct = Q;
function p1(t) {
  return t && t.__esModule ? t : { default: t };
}
function E1(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
var O1 = function() {
  function t(e, n, r) {
    E1(this, t), this.canvas = e, this.encodings = n, this.options = r;
  }
  return _1(t, [{
    key: "render",
    value: function() {
      if (!this.canvas.getContext)
        throw new Error("The browser does not support canvas.");
      this.prepareCanvas();
      for (var n = 0; n < this.encodings.length; n++) {
        var r = (0, y1.default)(this.options, this.encodings[n].options);
        this.drawCanvasBarcode(r, this.encodings[n]), this.drawCanvasText(r, this.encodings[n]), this.moveCanvasDrawing(this.encodings[n]);
      }
      this.restoreCanvas();
    }
  }, {
    key: "prepareCanvas",
    value: function() {
      var n = this.canvas.getContext("2d");
      n.save(), (0, ct.calculateEncodingAttributes)(this.encodings, this.options, n);
      var r = (0, ct.getTotalWidthOfEncodings)(this.encodings), a = (0, ct.getMaximumHeightOfEncodings)(this.encodings);
      this.canvas.width = r + this.options.marginLeft + this.options.marginRight, this.canvas.height = a, n.clearRect(0, 0, this.canvas.width, this.canvas.height), this.options.background && (n.fillStyle = this.options.background, n.fillRect(0, 0, this.canvas.width, this.canvas.height)), n.translate(this.options.marginLeft, 0);
    }
  }, {
    key: "drawCanvasBarcode",
    value: function(n, r) {
      var a = this.canvas.getContext("2d"), i = r.data, f;
      n.textPosition == "top" ? f = n.marginTop + n.fontSize + n.textMargin : f = n.marginTop, a.fillStyle = n.lineColor;
      for (var c = 0; c < i.length; c++) {
        var w = c * n.width + r.barcodePadding;
        i[c] === "1" ? a.fillRect(w, f, n.width, n.height) : i[c] && a.fillRect(w, f, n.width, n.height * i[c]);
      }
    }
  }, {
    key: "drawCanvasText",
    value: function(n, r) {
      var a = this.canvas.getContext("2d"), i = n.fontOptions + " " + n.fontSize + "px " + n.font;
      if (n.displayValue) {
        var f, c;
        n.textPosition == "top" ? c = n.marginTop + n.fontSize - n.textMargin : c = n.height + n.textMargin + n.marginTop + n.fontSize, a.font = i, n.textAlign == "left" || r.barcodePadding > 0 ? (f = 0, a.textAlign = "left") : n.textAlign == "right" ? (f = r.width - 1, a.textAlign = "right") : (f = r.width / 2, a.textAlign = "center"), a.fillText(r.text, f, c);
      }
    }
  }, {
    key: "moveCanvasDrawing",
    value: function(n) {
      var r = this.canvas.getContext("2d");
      r.translate(n.width, 0);
    }
  }, {
    key: "restoreCanvas",
    value: function() {
      var n = this.canvas.getContext("2d");
      n.restore();
    }
  }]), t;
}();
Gt.default = O1;
var Ft = {};
Object.defineProperty(Ft, "__esModule", {
  value: !0
});
var b1 = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}(), w1 = Te, m1 = x1(w1), ht = Q;
function x1(t) {
  return t && t.__esModule ? t : { default: t };
}
function A1(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
var qe = "http://www.w3.org/2000/svg", $1 = function() {
  function t(e, n, r) {
    A1(this, t), this.svg = e, this.encodings = n, this.options = r, this.document = r.xmlDocument || document;
  }
  return b1(t, [{
    key: "render",
    value: function() {
      var n = this.options.marginLeft;
      this.prepareSVG();
      for (var r = 0; r < this.encodings.length; r++) {
        var a = this.encodings[r], i = (0, m1.default)(this.options, a.options), f = this.createGroup(n, i.marginTop, this.svg);
        this.setGroupOptions(f, i), this.drawSvgBarcode(f, i, a), this.drawSVGText(f, i, a), n += a.width;
      }
    }
  }, {
    key: "prepareSVG",
    value: function() {
      for (; this.svg.firstChild; )
        this.svg.removeChild(this.svg.firstChild);
      (0, ht.calculateEncodingAttributes)(this.encodings, this.options);
      var n = (0, ht.getTotalWidthOfEncodings)(this.encodings), r = (0, ht.getMaximumHeightOfEncodings)(this.encodings), a = n + this.options.marginLeft + this.options.marginRight;
      this.setSvgAttributes(a, r), this.options.background && this.drawRect(0, 0, a, r, this.svg).setAttribute("style", "fill:" + this.options.background + ";");
    }
  }, {
    key: "drawSvgBarcode",
    value: function(n, r, a) {
      var i = a.data, f;
      r.textPosition == "top" ? f = r.fontSize + r.textMargin : f = 0;
      for (var c = 0, w = 0, T = 0; T < i.length; T++)
        w = T * r.width + a.barcodePadding, i[T] === "1" ? c++ : c > 0 && (this.drawRect(w - r.width * c, f, r.width * c, r.height, n), c = 0);
      c > 0 && this.drawRect(w - r.width * (c - 1), f, r.width * c, r.height, n);
    }
  }, {
    key: "drawSVGText",
    value: function(n, r, a) {
      var i = this.document.createElementNS(qe, "text");
      if (r.displayValue) {
        var f, c;
        i.setAttribute("style", "font:" + r.fontOptions + " " + r.fontSize + "px " + r.font), r.textPosition == "top" ? c = r.fontSize - r.textMargin : c = r.height + r.textMargin + r.fontSize, r.textAlign == "left" || a.barcodePadding > 0 ? (f = 0, i.setAttribute("text-anchor", "start")) : r.textAlign == "right" ? (f = a.width - 1, i.setAttribute("text-anchor", "end")) : (f = a.width / 2, i.setAttribute("text-anchor", "middle")), i.setAttribute("x", f), i.setAttribute("y", c), i.appendChild(this.document.createTextNode(a.text)), n.appendChild(i);
      }
    }
  }, {
    key: "setSvgAttributes",
    value: function(n, r) {
      var a = this.svg;
      a.setAttribute("width", n + "px"), a.setAttribute("height", r + "px"), a.setAttribute("x", "0px"), a.setAttribute("y", "0px"), a.setAttribute("viewBox", "0 0 " + n + " " + r), a.setAttribute("xmlns", qe), a.setAttribute("version", "1.1"), a.setAttribute("style", "transform: translate(0,0)");
    }
  }, {
    key: "createGroup",
    value: function(n, r, a) {
      var i = this.document.createElementNS(qe, "g");
      return i.setAttribute("transform", "translate(" + n + ", " + r + ")"), a.appendChild(i), i;
    }
  }, {
    key: "setGroupOptions",
    value: function(n, r) {
      n.setAttribute("style", "fill:" + r.lineColor + ";");
    }
  }, {
    key: "drawRect",
    value: function(n, r, a, i, f) {
      var c = this.document.createElementNS(qe, "rect");
      return c.setAttribute("x", n), c.setAttribute("y", r), c.setAttribute("width", a), c.setAttribute("height", i), f.appendChild(c), c;
    }
  }]), t;
}();
Ft.default = $1;
var Ht = {};
Object.defineProperty(Ht, "__esModule", {
  value: !0
});
var S1 = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}();
function R1(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
var M1 = function() {
  function t(e, n, r) {
    R1(this, t), this.object = e, this.encodings = n, this.options = r;
  }
  return S1(t, [{
    key: "render",
    value: function() {
      this.object.encodings = this.encodings;
    }
  }]), t;
}();
Ht.default = M1;
Object.defineProperty(Nt, "__esModule", {
  value: !0
});
var T1 = Gt, P1 = Ut(T1), k1 = Ft, D1 = Ut(k1), B1 = Ht, I1 = Ut(B1);
function Ut(t) {
  return t && t.__esModule ? t : { default: t };
}
Nt.default = { CanvasRenderer: P1.default, SVGRenderer: D1.default, ObjectRenderer: I1.default };
var Pe = {};
Object.defineProperty(Pe, "__esModule", {
  value: !0
});
function Xt(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
function Vt(t, e) {
  if (!t)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e && (typeof e == "object" || typeof e == "function") ? e : t;
}
function qt(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function, not " + typeof e);
  t.prototype = Object.create(e && e.prototype, { constructor: { value: t, enumerable: !1, writable: !0, configurable: !0 } }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}
var L1 = function(t) {
  qt(e, t);
  function e(n, r) {
    Xt(this, e);
    var a = Vt(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this));
    return a.name = "InvalidInputException", a.symbology = n, a.input = r, a.message = '"' + a.input + '" is not a valid input for ' + a.symbology, a;
  }
  return e;
}(Error), C1 = function(t) {
  qt(e, t);
  function e() {
    Xt(this, e);
    var n = Vt(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this));
    return n.name = "InvalidElementException", n.message = "Not supported type to render on", n;
  }
  return e;
}(Error), j1 = function(t) {
  qt(e, t);
  function e() {
    Xt(this, e);
    var n = Vt(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this));
    return n.name = "NoElementException", n.message = "No element to render on.", n;
  }
  return e;
}(Error);
Pe.InvalidInputException = L1;
Pe.InvalidElementException = C1;
Pe.NoElementException = j1;
Object.defineProperty(Ct, "__esModule", {
  value: !0
});
var N1 = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
  return typeof t;
} : function(t) {
  return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
}, G1 = jt, st = Fr(G1), F1 = Nt, Ie = Fr(F1), H1 = Pe;
function Fr(t) {
  return t && t.__esModule ? t : { default: t };
}
function zt(t) {
  if (typeof t == "string")
    return U1(t);
  if (Array.isArray(t)) {
    for (var e = [], n = 0; n < t.length; n++)
      e.push(zt(t[n]));
    return e;
  } else {
    if (typeof HTMLCanvasElement < "u" && t instanceof HTMLImageElement)
      return X1(t);
    if (t && t.nodeName && t.nodeName.toLowerCase() === "svg" || typeof SVGElement < "u" && t instanceof SVGElement)
      return {
        element: t,
        options: (0, st.default)(t),
        renderer: Ie.default.SVGRenderer
      };
    if (typeof HTMLCanvasElement < "u" && t instanceof HTMLCanvasElement)
      return {
        element: t,
        options: (0, st.default)(t),
        renderer: Ie.default.CanvasRenderer
      };
    if (t && t.getContext)
      return {
        element: t,
        renderer: Ie.default.CanvasRenderer
      };
    if (t && (typeof t > "u" ? "undefined" : N1(t)) === "object" && !t.nodeName)
      return {
        element: t,
        renderer: Ie.default.ObjectRenderer
      };
    throw new H1.InvalidElementException();
  }
}
function U1(t) {
  var e = document.querySelectorAll(t);
  if (e.length !== 0) {
    for (var n = [], r = 0; r < e.length; r++)
      n.push(zt(e[r]));
    return n;
  }
}
function X1(t) {
  var e = document.createElement("canvas");
  return {
    element: e,
    options: (0, st.default)(t),
    renderer: Ie.default.CanvasRenderer,
    afterRender: function() {
      t.setAttribute("src", e.toDataURL());
    }
  };
}
Ct.default = zt;
var Qt = {};
Object.defineProperty(Qt, "__esModule", {
  value: !0
});
var V1 = function() {
  function t(e, n) {
    for (var r = 0; r < n.length; r++) {
      var a = n[r];
      a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
  }
  return function(e, n, r) {
    return n && t(e.prototype, n), r && t(e, r), e;
  };
}();
function q1(t, e) {
  if (!(t instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
var z1 = function() {
  function t(e) {
    q1(this, t), this.api = e;
  }
  return V1(t, [{
    key: "handleCatch",
    value: function(n) {
      if (n.name === "InvalidInputException")
        if (this.api._options.valid !== this.api._defaults.valid)
          this.api._options.valid(!1);
        else
          throw n.message;
      else
        throw n;
      this.api.render = function() {
      };
    }
  }, {
    key: "wrapBarcodeCall",
    value: function(n) {
      try {
        var r = n.apply(void 0, arguments);
        return this.api._options.valid(!0), r;
      } catch (a) {
        return this.handleCatch(a), this.api;
      }
    }
  }]), t;
}();
Qt.default = z1;
var Q1 = yt, _e = de(Q1), Y1 = Te, Ge = de(Y1), J1 = It, Hr = de(J1), K1 = Lt, _r = de(K1), Z1 = Ct, W1 = de(Z1), ef = rt, tf = de(ef), rf = Qt, nf = de(rf), Ur = Pe, af = nt, Xr = de(af);
function de(t) {
  return t && t.__esModule ? t : { default: t };
}
var ue = function() {
}, at = function(e, n, r) {
  var a = new ue();
  if (typeof e > "u")
    throw Error("No element to render on was provided.");
  return a._renderProperties = (0, W1.default)(e), a._encodings = [], a._options = Xr.default, a._errorHandler = new nf.default(a), typeof n < "u" && (r = r || {}, r.format || (r.format = qr()), a.options(r)[r.format](n, r).render()), a;
};
at.getModule = function(t) {
  return _e.default[t];
};
for (var gr in _e.default)
  _e.default.hasOwnProperty(gr) && of(_e.default, gr);
function of(t, e) {
  ue.prototype[e] = ue.prototype[e.toUpperCase()] = ue.prototype[e.toLowerCase()] = function(n, r) {
    var a = this;
    return a._errorHandler.wrapBarcodeCall(function() {
      r.text = typeof r.text > "u" ? void 0 : "" + r.text;
      var i = (0, Ge.default)(a._options, r);
      i = (0, tf.default)(i);
      var f = t[e], c = Vr(n, f, i);
      return a._encodings.push(c), a;
    });
  };
}
function Vr(t, e, n) {
  t = "" + t;
  var r = new e(t, n);
  if (!r.valid())
    throw new Ur.InvalidInputException(r.constructor.name, t);
  var a = r.encode();
  a = (0, Hr.default)(a);
  for (var i = 0; i < a.length; i++)
    a[i].options = (0, Ge.default)(n, a[i].options);
  return a;
}
function qr() {
  return _e.default.CODE128 ? "CODE128" : Object.keys(_e.default)[0];
}
ue.prototype.options = function(t) {
  return this._options = (0, Ge.default)(this._options, t), this;
};
ue.prototype.blank = function(t) {
  var e = new Array(t + 1).join("0");
  return this._encodings.push({ data: e }), this;
};
ue.prototype.init = function() {
  if (this._renderProperties) {
    Array.isArray(this._renderProperties) || (this._renderProperties = [this._renderProperties]);
    var t;
    for (var e in this._renderProperties) {
      t = this._renderProperties[e];
      var n = (0, Ge.default)(this._options, t.options);
      n.format == "auto" && (n.format = qr()), this._errorHandler.wrapBarcodeCall(function() {
        var r = n.value, a = _e.default[n.format.toUpperCase()], i = Vr(r, a, n);
        _t(t, i, n);
      });
    }
  }
};
ue.prototype.render = function() {
  if (!this._renderProperties)
    throw new Ur.NoElementException();
  if (Array.isArray(this._renderProperties))
    for (var t = 0; t < this._renderProperties.length; t++)
      _t(this._renderProperties[t], this._encodings, this._options);
  else
    _t(this._renderProperties, this._encodings, this._options);
  return this;
};
ue.prototype._defaults = Xr.default;
function _t(t, e, n) {
  e = (0, Hr.default)(e);
  for (var r = 0; r < e.length; r++)
    e[r].options = (0, Ge.default)(n, e[r].options), (0, _r.default)(e[r].options);
  (0, _r.default)(n);
  var a = t.renderer, i = new a(t.element, e, n);
  i.render(), t.afterRender && t.afterRender();
}
typeof window < "u" && (window.JsBarcode = at);
typeof jQuery < "u" && (jQuery.fn.JsBarcode = function(t, e) {
  var n = [];
  return jQuery(this).each(function() {
    n.push(this);
  }), at(n, t, e);
});
var uf = at;
const ff = /* @__PURE__ */ Or(uf);
var zr = { exports: {} };
(function(t, e) {
  var n = function() {
    var r = function(m, A) {
      var y = 236, b = 17, h = m, E = i[A], u = null, o = 0, O = null, g = [], p = {}, P = function(v, d) {
        o = h * 4 + 17, u = function(l) {
          for (var s = new Array(l), _ = 0; _ < l; _ += 1) {
            s[_] = new Array(l);
            for (var x = 0; x < l; x += 1)
              s[_][x] = null;
          }
          return s;
        }(o), k(0, 0), k(o - 7, 0), k(0, o - 7), j(), L(), ie(v, d), h >= 7 && re(v), O == null && (O = Qr(h, E, g)), oe(O, d);
      }, k = function(v, d) {
        for (var l = -1; l <= 7; l += 1)
          if (!(v + l <= -1 || o <= v + l))
            for (var s = -1; s <= 7; s += 1)
              d + s <= -1 || o <= d + s || (0 <= l && l <= 6 && (s == 0 || s == 6) || 0 <= s && s <= 6 && (l == 0 || l == 6) || 2 <= l && l <= 4 && 2 <= s && s <= 4 ? u[v + l][d + s] = !0 : u[v + l][d + s] = !1);
      }, D = function() {
        for (var v = 0, d = 0, l = 0; l < 8; l += 1) {
          P(!0, l);
          var s = c.getLostPoint(p);
          (l == 0 || v > s) && (v = s, d = l);
        }
        return d;
      }, L = function() {
        for (var v = 8; v < o - 8; v += 1)
          u[v][6] == null && (u[v][6] = v % 2 == 0);
        for (var d = 8; d < o - 8; d += 1)
          u[6][d] == null && (u[6][d] = d % 2 == 0);
      }, j = function() {
        for (var v = c.getPatternPosition(h), d = 0; d < v.length; d += 1)
          for (var l = 0; l < v.length; l += 1) {
            var s = v[d], _ = v[l];
            if (u[s][_] == null)
              for (var x = -2; x <= 2; x += 1)
                for (var S = -2; S <= 2; S += 1)
                  x == -2 || x == 2 || S == -2 || S == 2 || x == 0 && S == 0 ? u[s + x][_ + S] = !0 : u[s + x][_ + S] = !1;
          }
      }, re = function(v) {
        for (var d = c.getBCHTypeNumber(h), l = 0; l < 18; l += 1) {
          var s = !v && (d >> l & 1) == 1;
          u[Math.floor(l / 3)][l % 3 + o - 8 - 3] = s;
        }
        for (var l = 0; l < 18; l += 1) {
          var s = !v && (d >> l & 1) == 1;
          u[l % 3 + o - 8 - 3][Math.floor(l / 3)] = s;
        }
      }, ie = function(v, d) {
        for (var l = E << 3 | d, s = c.getBCHTypeInfo(l), _ = 0; _ < 15; _ += 1) {
          var x = !v && (s >> _ & 1) == 1;
          _ < 6 ? u[_][8] = x : _ < 8 ? u[_ + 1][8] = x : u[o - 15 + _][8] = x;
        }
        for (var _ = 0; _ < 15; _ += 1) {
          var x = !v && (s >> _ & 1) == 1;
          _ < 8 ? u[8][o - _ - 1] = x : _ < 9 ? u[8][15 - _ - 1 + 1] = x : u[8][15 - _ - 1] = x;
        }
        u[o - 8][8] = !v;
      }, oe = function(v, d) {
        for (var l = -1, s = o - 1, _ = 7, x = 0, S = c.getMaskFunction(d), $ = o - 1; $ > 0; $ -= 2)
          for ($ == 6 && ($ -= 1); ; ) {
            for (var B = 0; B < 2; B += 1)
              if (u[s][$ - B] == null) {
                var C = !1;
                x < v.length && (C = (v[x] >>> _ & 1) == 1);
                var R = S(s, $ - B);
                R && (C = !C), u[s][$ - B] = C, _ -= 1, _ == -1 && (x += 1, _ = 7);
              }
            if (s += l, s < 0 || o <= s) {
              s -= l, l = -l;
              break;
            }
          }
      }, be = function(v, d) {
        for (var l = 0, s = 0, _ = 0, x = new Array(d.length), S = new Array(d.length), $ = 0; $ < d.length; $ += 1) {
          var B = d[$].dataCount, C = d[$].totalCount - B;
          s = Math.max(s, B), _ = Math.max(_, C), x[$] = new Array(B);
          for (var R = 0; R < x[$].length; R += 1)
            x[$][R] = 255 & v.getBuffer()[R + l];
          l += B;
          var Y = c.getErrorCorrectPolynomial(C), J = T(x[$], Y.getLength() - 1), Yt = J.mod(Y);
          S[$] = new Array(Y.getLength() - 1);
          for (var R = 0; R < S[$].length; R += 1) {
            var Jt = R + Yt.getLength() - S[$].length;
            S[$][R] = Jt >= 0 ? Yt.getAt(Jt) : 0;
          }
        }
        for (var Kt = 0, R = 0; R < d.length; R += 1)
          Kt += d[R].totalCount;
        for (var it = new Array(Kt), Fe = 0, R = 0; R < s; R += 1)
          for (var $ = 0; $ < d.length; $ += 1)
            R < x[$].length && (it[Fe] = x[$][R], Fe += 1);
        for (var R = 0; R < _; R += 1)
          for (var $ = 0; $ < d.length; $ += 1)
            R < S[$].length && (it[Fe] = S[$][R], Fe += 1);
        return it;
      }, Qr = function(v, d, l) {
        for (var s = N.getRSBlocks(v, d), _ = fe(), x = 0; x < l.length; x += 1) {
          var S = l[x];
          _.put(S.getMode(), 4), _.put(S.getLength(), c.getLengthInBits(S.getMode(), v)), S.write(_);
        }
        for (var $ = 0, x = 0; x < s.length; x += 1)
          $ += s[x].dataCount;
        if (_.getLengthInBits() > $ * 8)
          throw "code length overflow. (" + _.getLengthInBits() + ">" + $ * 8 + ")";
        for (_.getLengthInBits() + 4 <= $ * 8 && _.put(0, 4); _.getLengthInBits() % 8 != 0; )
          _.putBit(!1);
        for (; !(_.getLengthInBits() >= $ * 8 || (_.put(y, 8), _.getLengthInBits() >= $ * 8)); )
          _.put(b, 8);
        return be(_, s);
      };
      p.addData = function(v, d) {
        d = d || "Byte";
        var l = null;
        switch (d) {
          case "Numeric":
            l = V(v);
            break;
          case "Alphanumeric":
            l = q(v);
            break;
          case "Byte":
            l = Ee(v);
            break;
          case "Kanji":
            l = U(v);
            break;
          default:
            throw "mode:" + d;
        }
        g.push(l), O = null;
      }, p.isDark = function(v, d) {
        if (v < 0 || o <= v || d < 0 || o <= d)
          throw v + "," + d;
        return u[v][d];
      }, p.getModuleCount = function() {
        return o;
      }, p.make = function() {
        if (h < 1) {
          for (var v = 1; v < 40; v++) {
            for (var d = N.getRSBlocks(v, E), l = fe(), s = 0; s < g.length; s++) {
              var _ = g[s];
              l.put(_.getMode(), 4), l.put(_.getLength(), c.getLengthInBits(_.getMode(), v)), _.write(l);
            }
            for (var x = 0, s = 0; s < d.length; s++)
              x += d[s].dataCount;
            if (l.getLengthInBits() <= x * 8)
              break;
          }
          h = v;
        }
        P(!1, D());
      }, p.createTableTag = function(v, d) {
        v = v || 2, d = typeof d > "u" ? v * 4 : d;
        var l = "";
        l += '<table style="', l += " border-width: 0px; border-style: none;", l += " border-collapse: collapse;", l += " padding: 0px; margin: " + d + "px;", l += '">', l += "<tbody>";
        for (var s = 0; s < p.getModuleCount(); s += 1) {
          l += "<tr>";
          for (var _ = 0; _ < p.getModuleCount(); _ += 1)
            l += '<td style="', l += " border-width: 0px; border-style: none;", l += " border-collapse: collapse;", l += " padding: 0px; margin: 0px;", l += " width: " + v + "px;", l += " height: " + v + "px;", l += " background-color: ", l += p.isDark(s, _) ? "#000000" : "#ffffff", l += ";", l += '"/>';
          l += "</tr>";
        }
        return l += "</tbody>", l += "</table>", l;
      }, p.createSvgTag = function(v, d, l, s) {
        var _ = {};
        typeof arguments[0] == "object" && (_ = arguments[0], v = _.cellSize, d = _.margin, l = _.alt, s = _.title), v = v || 2, d = typeof d > "u" ? v * 4 : d, l = typeof l == "string" ? { text: l } : l || {}, l.text = l.text || null, l.id = l.text ? l.id || "qrcode-description" : null, s = typeof s == "string" ? { text: s } : s || {}, s.text = s.text || null, s.id = s.text ? s.id || "qrcode-title" : null;
        var x = p.getModuleCount() * v + d * 2, S, $, B, C, R = "", Y;
        for (Y = "l" + v + ",0 0," + v + " -" + v + ",0 0,-" + v + "z ", R += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"', R += _.scalable ? "" : ' width="' + x + 'px" height="' + x + 'px"', R += ' viewBox="0 0 ' + x + " " + x + '" ', R += ' preserveAspectRatio="xMinYMin meet"', R += s.text || l.text ? ' role="img" aria-labelledby="' + we([s.id, l.id].join(" ").trim()) + '"' : "", R += ">", R += s.text ? '<title id="' + we(s.id) + '">' + we(s.text) + "</title>" : "", R += l.text ? '<description id="' + we(l.id) + '">' + we(l.text) + "</description>" : "", R += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>', R += '<path d="', B = 0; B < p.getModuleCount(); B += 1)
          for (C = B * v + d, S = 0; S < p.getModuleCount(); S += 1)
            p.isDark(B, S) && ($ = S * v + d, R += "M" + $ + "," + C + Y);
        return R += '" stroke="transparent" fill="black"/>', R += "</svg>", R;
      }, p.createDataURL = function(v, d) {
        v = v || 2, d = typeof d > "u" ? v * 4 : d;
        var l = p.getModuleCount() * v + d * 2, s = d, _ = l - d;
        return W(l, l, function(x, S) {
          if (s <= x && x < _ && s <= S && S < _) {
            var $ = Math.floor((x - s) / v), B = Math.floor((S - s) / v);
            return p.isDark(B, $) ? 0 : 1;
          } else
            return 1;
        });
      }, p.createImgTag = function(v, d, l) {
        v = v || 2, d = typeof d > "u" ? v * 4 : d;
        var s = p.getModuleCount() * v + d * 2, _ = "";
        return _ += "<img", _ += ' src="', _ += p.createDataURL(v, d), _ += '"', _ += ' width="', _ += s, _ += '"', _ += ' height="', _ += s, _ += '"', l && (_ += ' alt="', _ += we(l), _ += '"'), _ += "/>", _;
      };
      var we = function(v) {
        for (var d = "", l = 0; l < v.length; l += 1) {
          var s = v.charAt(l);
          switch (s) {
            case "<":
              d += "&lt;";
              break;
            case ">":
              d += "&gt;";
              break;
            case "&":
              d += "&amp;";
              break;
            case '"':
              d += "&quot;";
              break;
            default:
              d += s;
              break;
          }
        }
        return d;
      }, Yr = function(v) {
        var d = 1;
        v = typeof v > "u" ? d * 2 : v;
        var l = p.getModuleCount() * d + v * 2, s = v, _ = l - v, x, S, $, B, C, R = {
          "██": "█",
          "█ ": "▀",
          " █": "▄",
          "  ": " "
        }, Y = {
          "██": "▀",
          "█ ": "▀",
          " █": " ",
          "  ": " "
        }, J = "";
        for (x = 0; x < l; x += 2) {
          for ($ = Math.floor((x - s) / d), B = Math.floor((x + 1 - s) / d), S = 0; S < l; S += 1)
            C = "█", s <= S && S < _ && s <= x && x < _ && p.isDark($, Math.floor((S - s) / d)) && (C = " "), s <= S && S < _ && s <= x + 1 && x + 1 < _ && p.isDark(B, Math.floor((S - s) / d)) ? C += " " : C += "█", J += v < 1 && x + 1 >= _ ? Y[C] : R[C];
          J += `
`;
        }
        return l % 2 && v > 0 ? J.substring(0, J.length - l - 1) + Array(l + 1).join("▀") : J.substring(0, J.length - 1);
      };
      return p.createASCII = function(v, d) {
        if (v = v || 1, v < 2)
          return Yr(d);
        v -= 1, d = typeof d > "u" ? v * 2 : d;
        var l = p.getModuleCount() * v + d * 2, s = d, _ = l - d, x, S, $, B, C = Array(v + 1).join("██"), R = Array(v + 1).join("  "), Y = "", J = "";
        for (x = 0; x < l; x += 1) {
          for ($ = Math.floor((x - s) / v), J = "", S = 0; S < l; S += 1)
            B = 1, s <= S && S < _ && s <= x && x < _ && p.isDark($, Math.floor((S - s) / v)) && (B = 0), J += B ? C : R;
          for ($ = 0; $ < v; $ += 1)
            Y += J + `
`;
        }
        return Y.substring(0, Y.length - 1);
      }, p.renderTo2dContext = function(v, d) {
        d = d || 2;
        for (var l = p.getModuleCount(), s = 0; s < l; s++)
          for (var _ = 0; _ < l; _++)
            v.fillStyle = p.isDark(s, _) ? "black" : "white", v.fillRect(s * d, _ * d, d, d);
      }, p;
    };
    r.stringToBytesFuncs = {
      default: function(m) {
        for (var A = [], y = 0; y < m.length; y += 1) {
          var b = m.charCodeAt(y);
          A.push(b & 255);
        }
        return A;
      }
    }, r.stringToBytes = r.stringToBytesFuncs.default, r.createStringToBytes = function(m, A) {
      var y = function() {
        for (var h = G(m), E = function() {
          var L = h.read();
          if (L == -1)
            throw "eof";
          return L;
        }, u = 0, o = {}; ; ) {
          var O = h.read();
          if (O == -1)
            break;
          var g = E(), p = E(), P = E(), k = String.fromCharCode(O << 8 | g), D = p << 8 | P;
          o[k] = D, u += 1;
        }
        if (u != A)
          throw u + " != " + A;
        return o;
      }(), b = "?".charCodeAt(0);
      return function(h) {
        for (var E = [], u = 0; u < h.length; u += 1) {
          var o = h.charCodeAt(u);
          if (o < 128)
            E.push(o);
          else {
            var O = y[h.charAt(u)];
            typeof O == "number" ? (O & 255) == O ? E.push(O) : (E.push(O >>> 8), E.push(O & 255)) : E.push(b);
          }
        }
        return E;
      };
    };
    var a = {
      MODE_NUMBER: 1,
      MODE_ALPHA_NUM: 2,
      MODE_8BIT_BYTE: 4,
      MODE_KANJI: 8
    }, i = {
      L: 1,
      M: 0,
      Q: 3,
      H: 2
    }, f = {
      PATTERN000: 0,
      PATTERN001: 1,
      PATTERN010: 2,
      PATTERN011: 3,
      PATTERN100: 4,
      PATTERN101: 5,
      PATTERN110: 6,
      PATTERN111: 7
    }, c = function() {
      var m = [
        [],
        [6, 18],
        [6, 22],
        [6, 26],
        [6, 30],
        [6, 34],
        [6, 22, 38],
        [6, 24, 42],
        [6, 26, 46],
        [6, 28, 50],
        [6, 30, 54],
        [6, 32, 58],
        [6, 34, 62],
        [6, 26, 46, 66],
        [6, 26, 48, 70],
        [6, 26, 50, 74],
        [6, 30, 54, 78],
        [6, 30, 56, 82],
        [6, 30, 58, 86],
        [6, 34, 62, 90],
        [6, 28, 50, 72, 94],
        [6, 26, 50, 74, 98],
        [6, 30, 54, 78, 102],
        [6, 28, 54, 80, 106],
        [6, 32, 58, 84, 110],
        [6, 30, 58, 86, 114],
        [6, 34, 62, 90, 118],
        [6, 26, 50, 74, 98, 122],
        [6, 30, 54, 78, 102, 126],
        [6, 26, 52, 78, 104, 130],
        [6, 30, 56, 82, 108, 134],
        [6, 34, 60, 86, 112, 138],
        [6, 30, 58, 86, 114, 142],
        [6, 34, 62, 90, 118, 146],
        [6, 30, 54, 78, 102, 126, 150],
        [6, 24, 50, 76, 102, 128, 154],
        [6, 28, 54, 80, 106, 132, 158],
        [6, 32, 58, 84, 110, 136, 162],
        [6, 26, 54, 82, 110, 138, 166],
        [6, 30, 58, 86, 114, 142, 170]
      ], A = 1335, y = 7973, b = 21522, h = {}, E = function(u) {
        for (var o = 0; u != 0; )
          o += 1, u >>>= 1;
        return o;
      };
      return h.getBCHTypeInfo = function(u) {
        for (var o = u << 10; E(o) - E(A) >= 0; )
          o ^= A << E(o) - E(A);
        return (u << 10 | o) ^ b;
      }, h.getBCHTypeNumber = function(u) {
        for (var o = u << 12; E(o) - E(y) >= 0; )
          o ^= y << E(o) - E(y);
        return u << 12 | o;
      }, h.getPatternPosition = function(u) {
        return m[u - 1];
      }, h.getMaskFunction = function(u) {
        switch (u) {
          case f.PATTERN000:
            return function(o, O) {
              return (o + O) % 2 == 0;
            };
          case f.PATTERN001:
            return function(o, O) {
              return o % 2 == 0;
            };
          case f.PATTERN010:
            return function(o, O) {
              return O % 3 == 0;
            };
          case f.PATTERN011:
            return function(o, O) {
              return (o + O) % 3 == 0;
            };
          case f.PATTERN100:
            return function(o, O) {
              return (Math.floor(o / 2) + Math.floor(O / 3)) % 2 == 0;
            };
          case f.PATTERN101:
            return function(o, O) {
              return o * O % 2 + o * O % 3 == 0;
            };
          case f.PATTERN110:
            return function(o, O) {
              return (o * O % 2 + o * O % 3) % 2 == 0;
            };
          case f.PATTERN111:
            return function(o, O) {
              return (o * O % 3 + (o + O) % 2) % 2 == 0;
            };
          default:
            throw "bad maskPattern:" + u;
        }
      }, h.getErrorCorrectPolynomial = function(u) {
        for (var o = T([1], 0), O = 0; O < u; O += 1)
          o = o.multiply(T([1, w.gexp(O)], 0));
        return o;
      }, h.getLengthInBits = function(u, o) {
        if (1 <= o && o < 10)
          switch (u) {
            case a.MODE_NUMBER:
              return 10;
            case a.MODE_ALPHA_NUM:
              return 9;
            case a.MODE_8BIT_BYTE:
              return 8;
            case a.MODE_KANJI:
              return 8;
            default:
              throw "mode:" + u;
          }
        else if (o < 27)
          switch (u) {
            case a.MODE_NUMBER:
              return 12;
            case a.MODE_ALPHA_NUM:
              return 11;
            case a.MODE_8BIT_BYTE:
              return 16;
            case a.MODE_KANJI:
              return 10;
            default:
              throw "mode:" + u;
          }
        else if (o < 41)
          switch (u) {
            case a.MODE_NUMBER:
              return 14;
            case a.MODE_ALPHA_NUM:
              return 13;
            case a.MODE_8BIT_BYTE:
              return 16;
            case a.MODE_KANJI:
              return 12;
            default:
              throw "mode:" + u;
          }
        else
          throw "type:" + o;
      }, h.getLostPoint = function(u) {
        for (var o = u.getModuleCount(), O = 0, g = 0; g < o; g += 1)
          for (var p = 0; p < o; p += 1) {
            for (var P = 0, k = u.isDark(g, p), D = -1; D <= 1; D += 1)
              if (!(g + D < 0 || o <= g + D))
                for (var L = -1; L <= 1; L += 1)
                  p + L < 0 || o <= p + L || D == 0 && L == 0 || k == u.isDark(g + D, p + L) && (P += 1);
            P > 5 && (O += 3 + P - 5);
          }
        for (var g = 0; g < o - 1; g += 1)
          for (var p = 0; p < o - 1; p += 1) {
            var j = 0;
            u.isDark(g, p) && (j += 1), u.isDark(g + 1, p) && (j += 1), u.isDark(g, p + 1) && (j += 1), u.isDark(g + 1, p + 1) && (j += 1), (j == 0 || j == 4) && (O += 3);
          }
        for (var g = 0; g < o; g += 1)
          for (var p = 0; p < o - 6; p += 1)
            u.isDark(g, p) && !u.isDark(g, p + 1) && u.isDark(g, p + 2) && u.isDark(g, p + 3) && u.isDark(g, p + 4) && !u.isDark(g, p + 5) && u.isDark(g, p + 6) && (O += 40);
        for (var p = 0; p < o; p += 1)
          for (var g = 0; g < o - 6; g += 1)
            u.isDark(g, p) && !u.isDark(g + 1, p) && u.isDark(g + 2, p) && u.isDark(g + 3, p) && u.isDark(g + 4, p) && !u.isDark(g + 5, p) && u.isDark(g + 6, p) && (O += 40);
        for (var re = 0, p = 0; p < o; p += 1)
          for (var g = 0; g < o; g += 1)
            u.isDark(g, p) && (re += 1);
        var ie = Math.abs(100 * re / o / o - 50) / 5;
        return O += ie * 10, O;
      }, h;
    }(), w = function() {
      for (var m = new Array(256), A = new Array(256), y = 0; y < 8; y += 1)
        m[y] = 1 << y;
      for (var y = 8; y < 256; y += 1)
        m[y] = m[y - 4] ^ m[y - 5] ^ m[y - 6] ^ m[y - 8];
      for (var y = 0; y < 255; y += 1)
        A[m[y]] = y;
      var b = {};
      return b.glog = function(h) {
        if (h < 1)
          throw "glog(" + h + ")";
        return A[h];
      }, b.gexp = function(h) {
        for (; h < 0; )
          h += 255;
        for (; h >= 256; )
          h -= 255;
        return m[h];
      }, b;
    }();
    function T(m, A) {
      if (typeof m.length > "u")
        throw m.length + "/" + A;
      var y = function() {
        for (var h = 0; h < m.length && m[h] == 0; )
          h += 1;
        for (var E = new Array(m.length - h + A), u = 0; u < m.length - h; u += 1)
          E[u] = m[u + h];
        return E;
      }(), b = {};
      return b.getAt = function(h) {
        return y[h];
      }, b.getLength = function() {
        return y.length;
      }, b.multiply = function(h) {
        for (var E = new Array(b.getLength() + h.getLength() - 1), u = 0; u < b.getLength(); u += 1)
          for (var o = 0; o < h.getLength(); o += 1)
            E[u + o] ^= w.gexp(w.glog(b.getAt(u)) + w.glog(h.getAt(o)));
        return T(E, 0);
      }, b.mod = function(h) {
        if (b.getLength() - h.getLength() < 0)
          return b;
        for (var E = w.glog(b.getAt(0)) - w.glog(h.getAt(0)), u = new Array(b.getLength()), o = 0; o < b.getLength(); o += 1)
          u[o] = b.getAt(o);
        for (var o = 0; o < h.getLength(); o += 1)
          u[o] ^= w.gexp(w.glog(h.getAt(o)) + E);
        return T(u, 0).mod(h);
      }, b;
    }
    var N = function() {
      var m = [
        // L
        // M
        // Q
        // H
        // 1
        [1, 26, 19],
        [1, 26, 16],
        [1, 26, 13],
        [1, 26, 9],
        // 2
        [1, 44, 34],
        [1, 44, 28],
        [1, 44, 22],
        [1, 44, 16],
        // 3
        [1, 70, 55],
        [1, 70, 44],
        [2, 35, 17],
        [2, 35, 13],
        // 4
        [1, 100, 80],
        [2, 50, 32],
        [2, 50, 24],
        [4, 25, 9],
        // 5
        [1, 134, 108],
        [2, 67, 43],
        [2, 33, 15, 2, 34, 16],
        [2, 33, 11, 2, 34, 12],
        // 6
        [2, 86, 68],
        [4, 43, 27],
        [4, 43, 19],
        [4, 43, 15],
        // 7
        [2, 98, 78],
        [4, 49, 31],
        [2, 32, 14, 4, 33, 15],
        [4, 39, 13, 1, 40, 14],
        // 8
        [2, 121, 97],
        [2, 60, 38, 2, 61, 39],
        [4, 40, 18, 2, 41, 19],
        [4, 40, 14, 2, 41, 15],
        // 9
        [2, 146, 116],
        [3, 58, 36, 2, 59, 37],
        [4, 36, 16, 4, 37, 17],
        [4, 36, 12, 4, 37, 13],
        // 10
        [2, 86, 68, 2, 87, 69],
        [4, 69, 43, 1, 70, 44],
        [6, 43, 19, 2, 44, 20],
        [6, 43, 15, 2, 44, 16],
        // 11
        [4, 101, 81],
        [1, 80, 50, 4, 81, 51],
        [4, 50, 22, 4, 51, 23],
        [3, 36, 12, 8, 37, 13],
        // 12
        [2, 116, 92, 2, 117, 93],
        [6, 58, 36, 2, 59, 37],
        [4, 46, 20, 6, 47, 21],
        [7, 42, 14, 4, 43, 15],
        // 13
        [4, 133, 107],
        [8, 59, 37, 1, 60, 38],
        [8, 44, 20, 4, 45, 21],
        [12, 33, 11, 4, 34, 12],
        // 14
        [3, 145, 115, 1, 146, 116],
        [4, 64, 40, 5, 65, 41],
        [11, 36, 16, 5, 37, 17],
        [11, 36, 12, 5, 37, 13],
        // 15
        [5, 109, 87, 1, 110, 88],
        [5, 65, 41, 5, 66, 42],
        [5, 54, 24, 7, 55, 25],
        [11, 36, 12, 7, 37, 13],
        // 16
        [5, 122, 98, 1, 123, 99],
        [7, 73, 45, 3, 74, 46],
        [15, 43, 19, 2, 44, 20],
        [3, 45, 15, 13, 46, 16],
        // 17
        [1, 135, 107, 5, 136, 108],
        [10, 74, 46, 1, 75, 47],
        [1, 50, 22, 15, 51, 23],
        [2, 42, 14, 17, 43, 15],
        // 18
        [5, 150, 120, 1, 151, 121],
        [9, 69, 43, 4, 70, 44],
        [17, 50, 22, 1, 51, 23],
        [2, 42, 14, 19, 43, 15],
        // 19
        [3, 141, 113, 4, 142, 114],
        [3, 70, 44, 11, 71, 45],
        [17, 47, 21, 4, 48, 22],
        [9, 39, 13, 16, 40, 14],
        // 20
        [3, 135, 107, 5, 136, 108],
        [3, 67, 41, 13, 68, 42],
        [15, 54, 24, 5, 55, 25],
        [15, 43, 15, 10, 44, 16],
        // 21
        [4, 144, 116, 4, 145, 117],
        [17, 68, 42],
        [17, 50, 22, 6, 51, 23],
        [19, 46, 16, 6, 47, 17],
        // 22
        [2, 139, 111, 7, 140, 112],
        [17, 74, 46],
        [7, 54, 24, 16, 55, 25],
        [34, 37, 13],
        // 23
        [4, 151, 121, 5, 152, 122],
        [4, 75, 47, 14, 76, 48],
        [11, 54, 24, 14, 55, 25],
        [16, 45, 15, 14, 46, 16],
        // 24
        [6, 147, 117, 4, 148, 118],
        [6, 73, 45, 14, 74, 46],
        [11, 54, 24, 16, 55, 25],
        [30, 46, 16, 2, 47, 17],
        // 25
        [8, 132, 106, 4, 133, 107],
        [8, 75, 47, 13, 76, 48],
        [7, 54, 24, 22, 55, 25],
        [22, 45, 15, 13, 46, 16],
        // 26
        [10, 142, 114, 2, 143, 115],
        [19, 74, 46, 4, 75, 47],
        [28, 50, 22, 6, 51, 23],
        [33, 46, 16, 4, 47, 17],
        // 27
        [8, 152, 122, 4, 153, 123],
        [22, 73, 45, 3, 74, 46],
        [8, 53, 23, 26, 54, 24],
        [12, 45, 15, 28, 46, 16],
        // 28
        [3, 147, 117, 10, 148, 118],
        [3, 73, 45, 23, 74, 46],
        [4, 54, 24, 31, 55, 25],
        [11, 45, 15, 31, 46, 16],
        // 29
        [7, 146, 116, 7, 147, 117],
        [21, 73, 45, 7, 74, 46],
        [1, 53, 23, 37, 54, 24],
        [19, 45, 15, 26, 46, 16],
        // 30
        [5, 145, 115, 10, 146, 116],
        [19, 75, 47, 10, 76, 48],
        [15, 54, 24, 25, 55, 25],
        [23, 45, 15, 25, 46, 16],
        // 31
        [13, 145, 115, 3, 146, 116],
        [2, 74, 46, 29, 75, 47],
        [42, 54, 24, 1, 55, 25],
        [23, 45, 15, 28, 46, 16],
        // 32
        [17, 145, 115],
        [10, 74, 46, 23, 75, 47],
        [10, 54, 24, 35, 55, 25],
        [19, 45, 15, 35, 46, 16],
        // 33
        [17, 145, 115, 1, 146, 116],
        [14, 74, 46, 21, 75, 47],
        [29, 54, 24, 19, 55, 25],
        [11, 45, 15, 46, 46, 16],
        // 34
        [13, 145, 115, 6, 146, 116],
        [14, 74, 46, 23, 75, 47],
        [44, 54, 24, 7, 55, 25],
        [59, 46, 16, 1, 47, 17],
        // 35
        [12, 151, 121, 7, 152, 122],
        [12, 75, 47, 26, 76, 48],
        [39, 54, 24, 14, 55, 25],
        [22, 45, 15, 41, 46, 16],
        // 36
        [6, 151, 121, 14, 152, 122],
        [6, 75, 47, 34, 76, 48],
        [46, 54, 24, 10, 55, 25],
        [2, 45, 15, 64, 46, 16],
        // 37
        [17, 152, 122, 4, 153, 123],
        [29, 74, 46, 14, 75, 47],
        [49, 54, 24, 10, 55, 25],
        [24, 45, 15, 46, 46, 16],
        // 38
        [4, 152, 122, 18, 153, 123],
        [13, 74, 46, 32, 75, 47],
        [48, 54, 24, 14, 55, 25],
        [42, 45, 15, 32, 46, 16],
        // 39
        [20, 147, 117, 4, 148, 118],
        [40, 75, 47, 7, 76, 48],
        [43, 54, 24, 22, 55, 25],
        [10, 45, 15, 67, 46, 16],
        // 40
        [19, 148, 118, 6, 149, 119],
        [18, 75, 47, 31, 76, 48],
        [34, 54, 24, 34, 55, 25],
        [20, 45, 15, 61, 46, 16]
      ], A = function(h, E) {
        var u = {};
        return u.totalCount = h, u.dataCount = E, u;
      }, y = {}, b = function(h, E) {
        switch (E) {
          case i.L:
            return m[(h - 1) * 4 + 0];
          case i.M:
            return m[(h - 1) * 4 + 1];
          case i.Q:
            return m[(h - 1) * 4 + 2];
          case i.H:
            return m[(h - 1) * 4 + 3];
          default:
            return;
        }
      };
      return y.getRSBlocks = function(h, E) {
        var u = b(h, E);
        if (typeof u > "u")
          throw "bad rs block @ typeNumber:" + h + "/errorCorrectionLevel:" + E;
        for (var o = u.length / 3, O = [], g = 0; g < o; g += 1)
          for (var p = u[g * 3 + 0], P = u[g * 3 + 1], k = u[g * 3 + 2], D = 0; D < p; D += 1)
            O.push(A(P, k));
        return O;
      }, y;
    }(), fe = function() {
      var m = [], A = 0, y = {};
      return y.getBuffer = function() {
        return m;
      }, y.getAt = function(b) {
        var h = Math.floor(b / 8);
        return (m[h] >>> 7 - b % 8 & 1) == 1;
      }, y.put = function(b, h) {
        for (var E = 0; E < h; E += 1)
          y.putBit((b >>> h - E - 1 & 1) == 1);
      }, y.getLengthInBits = function() {
        return A;
      }, y.putBit = function(b) {
        var h = Math.floor(A / 8);
        m.length <= h && m.push(0), b && (m[h] |= 128 >>> A % 8), A += 1;
      }, y;
    }, V = function(m) {
      var A = a.MODE_NUMBER, y = m, b = {};
      b.getMode = function() {
        return A;
      }, b.getLength = function(u) {
        return y.length;
      }, b.write = function(u) {
        for (var o = y, O = 0; O + 2 < o.length; )
          u.put(h(o.substring(O, O + 3)), 10), O += 3;
        O < o.length && (o.length - O == 1 ? u.put(h(o.substring(O, O + 1)), 4) : o.length - O == 2 && u.put(h(o.substring(O, O + 2)), 7));
      };
      var h = function(u) {
        for (var o = 0, O = 0; O < u.length; O += 1)
          o = o * 10 + E(u.charAt(O));
        return o;
      }, E = function(u) {
        if ("0" <= u && u <= "9")
          return u.charCodeAt(0) - "0".charCodeAt(0);
        throw "illegal char :" + u;
      };
      return b;
    }, q = function(m) {
      var A = a.MODE_ALPHA_NUM, y = m, b = {};
      b.getMode = function() {
        return A;
      }, b.getLength = function(E) {
        return y.length;
      }, b.write = function(E) {
        for (var u = y, o = 0; o + 1 < u.length; )
          E.put(
            h(u.charAt(o)) * 45 + h(u.charAt(o + 1)),
            11
          ), o += 2;
        o < u.length && E.put(h(u.charAt(o)), 6);
      };
      var h = function(E) {
        if ("0" <= E && E <= "9")
          return E.charCodeAt(0) - "0".charCodeAt(0);
        if ("A" <= E && E <= "Z")
          return E.charCodeAt(0) - "A".charCodeAt(0) + 10;
        switch (E) {
          case " ":
            return 36;
          case "$":
            return 37;
          case "%":
            return 38;
          case "*":
            return 39;
          case "+":
            return 40;
          case "-":
            return 41;
          case ".":
            return 42;
          case "/":
            return 43;
          case ":":
            return 44;
          default:
            throw "illegal char :" + E;
        }
      };
      return b;
    }, Ee = function(m) {
      var A = a.MODE_8BIT_BYTE, y = r.stringToBytes(m), b = {};
      return b.getMode = function() {
        return A;
      }, b.getLength = function(h) {
        return y.length;
      }, b.write = function(h) {
        for (var E = 0; E < y.length; E += 1)
          h.put(y[E], 8);
      }, b;
    }, U = function(m) {
      var A = a.MODE_KANJI, y = r.stringToBytesFuncs.SJIS;
      if (!y)
        throw "sjis not supported.";
      (function(E, u) {
        var o = y(E);
        if (o.length != 2 || (o[0] << 8 | o[1]) != u)
          throw "sjis not supported.";
      })("友", 38726);
      var b = y(m), h = {};
      return h.getMode = function() {
        return A;
      }, h.getLength = function(E) {
        return ~~(b.length / 2);
      }, h.write = function(E) {
        for (var u = b, o = 0; o + 1 < u.length; ) {
          var O = (255 & u[o]) << 8 | 255 & u[o + 1];
          if (33088 <= O && O <= 40956)
            O -= 33088;
          else if (57408 <= O && O <= 60351)
            O -= 49472;
          else
            throw "illegal char at " + (o + 1) + "/" + O;
          O = (O >>> 8 & 255) * 192 + (O & 255), E.put(O, 13), o += 2;
        }
        if (o < u.length)
          throw "illegal char at " + (o + 1);
      }, h;
    }, te = function() {
      var m = [], A = {};
      return A.writeByte = function(y) {
        m.push(y & 255);
      }, A.writeShort = function(y) {
        A.writeByte(y), A.writeByte(y >>> 8);
      }, A.writeBytes = function(y, b, h) {
        b = b || 0, h = h || y.length;
        for (var E = 0; E < h; E += 1)
          A.writeByte(y[E + b]);
      }, A.writeString = function(y) {
        for (var b = 0; b < y.length; b += 1)
          A.writeByte(y.charCodeAt(b));
      }, A.toByteArray = function() {
        return m;
      }, A.toString = function() {
        var y = "";
        y += "[";
        for (var b = 0; b < m.length; b += 1)
          b > 0 && (y += ","), y += m[b];
        return y += "]", y;
      }, A;
    }, Oe = function() {
      var m = 0, A = 0, y = 0, b = "", h = {}, E = function(o) {
        b += String.fromCharCode(u(o & 63));
      }, u = function(o) {
        if (!(o < 0)) {
          if (o < 26)
            return 65 + o;
          if (o < 52)
            return 97 + (o - 26);
          if (o < 62)
            return 48 + (o - 52);
          if (o == 62)
            return 43;
          if (o == 63)
            return 47;
        }
        throw "n:" + o;
      };
      return h.writeByte = function(o) {
        for (m = m << 8 | o & 255, A += 8, y += 1; A >= 6; )
          E(m >>> A - 6), A -= 6;
      }, h.flush = function() {
        if (A > 0 && (E(m << 6 - A), m = 0, A = 0), y % 3 != 0)
          for (var o = 3 - y % 3, O = 0; O < o; O += 1)
            b += "=";
      }, h.toString = function() {
        return b;
      }, h;
    }, G = function(m) {
      var A = m, y = 0, b = 0, h = 0, E = {};
      E.read = function() {
        for (; h < 8; ) {
          if (y >= A.length) {
            if (h == 0)
              return -1;
            throw "unexpected end of file./" + h;
          }
          var o = A.charAt(y);
          if (y += 1, o == "=")
            return h = 0, -1;
          if (o.match(/^\s$/))
            continue;
          b = b << 6 | u(o.charCodeAt(0)), h += 6;
        }
        var O = b >>> h - 8 & 255;
        return h -= 8, O;
      };
      var u = function(o) {
        if (65 <= o && o <= 90)
          return o - 65;
        if (97 <= o && o <= 122)
          return o - 97 + 26;
        if (48 <= o && o <= 57)
          return o - 48 + 52;
        if (o == 43)
          return 62;
        if (o == 47)
          return 63;
        throw "c:" + o;
      };
      return E;
    }, M = function(m, A) {
      var y = m, b = A, h = new Array(m * A), E = {};
      E.setPixel = function(g, p, P) {
        h[p * y + g] = P;
      }, E.write = function(g) {
        g.writeString("GIF87a"), g.writeShort(y), g.writeShort(b), g.writeByte(128), g.writeByte(0), g.writeByte(0), g.writeByte(0), g.writeByte(0), g.writeByte(0), g.writeByte(255), g.writeByte(255), g.writeByte(255), g.writeString(","), g.writeShort(0), g.writeShort(0), g.writeShort(y), g.writeShort(b), g.writeByte(0);
        var p = 2, P = o(p);
        g.writeByte(p);
        for (var k = 0; P.length - k > 255; )
          g.writeByte(255), g.writeBytes(P, k, 255), k += 255;
        g.writeByte(P.length - k), g.writeBytes(P, k, P.length - k), g.writeByte(0), g.writeString(";");
      };
      var u = function(g) {
        var p = g, P = 0, k = 0, D = {};
        return D.write = function(L, j) {
          if (L >>> j)
            throw "length over";
          for (; P + j >= 8; )
            p.writeByte(255 & (L << P | k)), j -= 8 - P, L >>>= 8 - P, k = 0, P = 0;
          k = L << P | k, P = P + j;
        }, D.flush = function() {
          P > 0 && p.writeByte(k);
        }, D;
      }, o = function(g) {
        for (var p = 1 << g, P = (1 << g) + 1, k = g + 1, D = O(), L = 0; L < p; L += 1)
          D.add(String.fromCharCode(L));
        D.add(String.fromCharCode(p)), D.add(String.fromCharCode(P));
        var j = te(), re = u(j);
        re.write(p, k);
        var ie = 0, oe = String.fromCharCode(h[ie]);
        for (ie += 1; ie < h.length; ) {
          var be = String.fromCharCode(h[ie]);
          ie += 1, D.contains(oe + be) ? oe = oe + be : (re.write(D.indexOf(oe), k), D.size() < 4095 && (D.size() == 1 << k && (k += 1), D.add(oe + be)), oe = be);
        }
        return re.write(D.indexOf(oe), k), re.write(P, k), re.flush(), j.toByteArray();
      }, O = function() {
        var g = {}, p = 0, P = {};
        return P.add = function(k) {
          if (P.contains(k))
            throw "dup key:" + k;
          g[k] = p, p += 1;
        }, P.size = function() {
          return p;
        }, P.indexOf = function(k) {
          return g[k];
        }, P.contains = function(k) {
          return typeof g[k] < "u";
        }, P;
      };
      return E;
    }, W = function(m, A, y) {
      for (var b = M(m, A), h = 0; h < A; h += 1)
        for (var E = 0; E < m; E += 1)
          b.setPixel(E, h, y(E, h));
      var u = te();
      b.write(u);
      for (var o = Oe(), O = u.toByteArray(), g = 0; g < O.length; g += 1)
        o.writeByte(O[g]);
      return o.flush(), "data:image/gif;base64," + o;
    };
    return r;
  }();
  (function() {
    n.stringToBytesFuncs["UTF-8"] = function(r) {
      function a(i) {
        for (var f = [], c = 0; c < i.length; c++) {
          var w = i.charCodeAt(c);
          w < 128 ? f.push(w) : w < 2048 ? f.push(
            192 | w >> 6,
            128 | w & 63
          ) : w < 55296 || w >= 57344 ? f.push(
            224 | w >> 12,
            128 | w >> 6 & 63,
            128 | w & 63
          ) : (c++, w = 65536 + ((w & 1023) << 10 | i.charCodeAt(c) & 1023), f.push(
            240 | w >> 18,
            128 | w >> 12 & 63,
            128 | w >> 6 & 63,
            128 | w & 63
          ));
        }
        return f;
      }
      return a(r);
    };
  })(), function(r) {
    t.exports = r();
  }(function() {
    return n;
  });
})(zr);
var lf = zr.exports;
const cf = /* @__PURE__ */ Or(lf), se = 7;
function hf(t) {
  return (
    /** @satisfies {import('./types').QRConfig} */
    {
      ...t,
      margin: t.margin ?? 1,
      shape: t.shape ?? /** @type {const} */
      "square",
      logoRatio: t.logoRatio ?? 1,
      moduleFill: t.moduleFill ?? "currentcolor",
      anchorOuterFill: t.anchorOuterFill ?? "currentcolor",
      anchorInnerFill: t.anchorInnerFill ?? "currentcolor",
      typeNumber: t.typeNumber ?? 0,
      errorCorrectionLevel: t.errorCorrectionLevel ?? "H"
    }
  );
}
function vf(t, e) {
  const { data: n, margin: r, shape: a, logo: i, logoRatio: f, anchorInnerFill: c, anchorOuterFill: w, moduleFill: T, typeNumber: N, errorCorrectionLevel: fe } = hf(t);
  e || (e = cf(N, fe), e.addData(n), e.make());
  const V = e.getModuleCount(), q = V + r * 2, Ee = [
    ["top-left", r, r],
    ["top-right", V - se + r, r],
    ["bottom-left", r, V - se + r]
  ];
  let U = "";
  for (const [G, M, W] of Ee) {
    let m = `M${M} ${W} h7 v7 h-7 v-7z m1 1 v5 h5 v-5 h-5 z`, A = `M${M + 2} ${W + 2} h3 v3 h-3 v-3 z`;
    a !== "square" && (m = `M${M + 0.5} ${W}h6s0.5 0 .5 .5v6s0 .5-.5 .5h-6s-.5 0-.5-.5v-6s0-.5 .5-.5zm.75 1s-.25 0-.25 .25v4.5s0 .25 .25 .25h4.5s.25 0 .25-.25v-4.5s0-.25 -.25 -.25h-4.5z`, A = `M${M + 2.5} ${W + 2} h2 s.5 0 .5 .5 v2 s0 .5-.5 .5 h-2 s-.5 0-.5-.5 v-2 s0-.5 .5-.5 z`);
    const y = `<path class="anchor-outer" fill="${w}" d="${m}" />`, b = `<path class="anchor-outer" fill="${c}" d="${A}" />`;
    U += `<g class="anchor" data-position="${G}">${y} ${b}</g>`;
  }
  U = `<g class="anchors">${U}</g>`;
  let te = "";
  for (let G = 0; G < V; G++)
    for (let M = 0; M < V; M++) {
      if (!e.isDark(G, M) || sf(G, M, V) || i && _f(G, M, V))
        continue;
      const W = G + r, m = M + r;
      te += `<rect class="module" fill="${T}" data-column="${G}" data-row="${M}" x="${W}" y="${m}" width="1" height="1" ${a === "circle" ? 'rx="0.5"' : ""} />`;
    }
  te = `<g class="modules">${te}</g>`;
  let Oe = "";
  if (i) {
    const G = Math.floor(V * Math.sqrt(0.1)), { width: M, height: W } = gf(G * 0.8, f), m = (q - M + 1) / 2, A = (q - W + 1) / 2;
    Oe = `<image width="${M}" height="${W}" x="${m}" y="${A}" href="${i}" class="logo" />`;
  }
  return {
    attributes: {
      viewBox: `0, 0 ${q} ${q}`,
      xmlns: "http://www.w3.org/2000/svg",
      version: "1.1"
    },
    anchors: U,
    modules: te,
    logo: Oe
  };
}
function df(t) {
  const { anchors: e, attributes: n, logo: r, modules: a } = vf(t), i = { ...n };
  return t.width && (i.width = t.width), t.height && (i.height = t.height), `<svg ${Object.entries(i).map(([f, c]) => `${f}="${c}"`).join(" ")}>${e} ${a} ${r}</svg>`;
}
function sf(t, e, n) {
  return e <= se ? t <= se || t >= n - se : t <= se ? e >= n - se : !1;
}
function _f(t, e, n) {
  const r = n / 2, a = 1, i = Math.floor(n * Math.sqrt(0.1) / 2), f = i * a, c = i / a, w = r - f, T = r + f, N = r - c, fe = r + c;
  return e >= N && e <= fe && t >= w && t <= T;
}
function gf(t, e) {
  return e >= 1 ? {
    width: t,
    height: t / e
  } : {
    width: t * e,
    height: t
  };
}
function yf(t) {
  let e, n, r = (
    /*codeType*/
    t[1] === "QR Code" ? "QR Code" : "Barcode"
  ), a;
  return {
    c() {
      e = ae("p"), n = ze("Please add a value to generate your "), a = ze(r);
    },
    m(i, f) {
      he(i, e, f), ee(e, n), ee(e, a);
    },
    p(i, f) {
      f & /*codeType*/
      2 && r !== (r = /*codeType*/
      i[1] === "QR Code" ? "QR Code" : "Barcode") && gt(a, r);
    },
    d(i) {
      i && ve(e);
    }
  };
}
function pf(t) {
  let e;
  function n(i, f) {
    return (
      /*codeType*/
      i[1] === "QR Code" ? Of : Ef
    );
  }
  let r = n(t), a = r(t);
  return {
    c() {
      a.c(), e = nn();
    },
    m(i, f) {
      a.m(i, f), he(i, e, f);
    },
    p(i, f) {
      r === (r = n(i)) && a ? a.p(i, f) : (a.d(1), a = r(i), a && (a.c(), a.m(e.parentNode, e)));
    },
    d(i) {
      i && ve(e), a.d(i);
    }
  };
}
function Ef(t) {
  let e, n, r, a, i = (
    /*showLogo*/
    t[3] && /*customLogo*/
    t[4] && yr(t)
  ), f = (
    /*value*/
    t[0] && pr(t)
  ), c = (
    /*showValue*/
    t[2] && Er(t)
  );
  return {
    c() {
      e = ae("div"), n = ae("div"), i && i.c(), r = vt(), f && f.c(), a = vt(), c && c.c(), F(n, "class", "logo-and-barcode svelte-1foui59"), le(
        n,
        "height",
        /*size*/
        t[5] + "px, width: 100%"
      ), F(e, "class", "barcode-container svelte-1foui59");
    },
    m(w, T) {
      he(w, e, T), ee(e, n), i && i.m(n, null), ee(n, r), f && f.m(n, null), ee(e, a), c && c.m(e, null);
    },
    p(w, T) {
      /*showLogo*/
      w[3] && /*customLogo*/
      w[4] ? i ? i.p(w, T) : (i = yr(w), i.c(), i.m(n, r)) : i && (i.d(1), i = null), /*value*/
      w[0] ? f ? f.p(w, T) : (f = pr(w), f.c(), f.m(n, null)) : f && (f.d(1), f = null), T & /*size*/
      32 && le(
        n,
        "height",
        /*size*/
        w[5] + "px, width: 100%"
      ), /*showValue*/
      w[2] ? c ? c.p(w, T) : (c = Er(w), c.c(), c.m(e, null)) : c && (c.d(1), c = null);
    },
    d(w) {
      w && ve(e), i && i.d(), f && f.d(), c && c.d();
    }
  };
}
function Of(t) {
  let e, n, r, a, i = (
    /*showValue*/
    (t[2] ? (
      /*value*/
      t[0]
    ) : "") + ""
  ), f;
  return {
    c() {
      e = ae("div"), n = ae("div"), r = vt(), a = ae("div"), f = ze(i), F(a, "class", "qr-value svelte-1foui59"), le(
        a,
        "color",
        /*primColor*/
        t[6]
      ), le(
        a,
        "max-width",
        /*size*/
        t[5] + "px"
      ), F(e, "class", "qr-container svelte-1foui59");
    },
    m(c, w) {
      he(c, e, w), ee(e, n), t[12](n), ee(e, r), ee(e, a), ee(a, f);
    },
    p(c, w) {
      w & /*showValue, value*/
      5 && i !== (i = /*showValue*/
      (c[2] ? (
        /*value*/
        c[0]
      ) : "") + "") && gt(f, i), w & /*primColor*/
      64 && le(
        a,
        "color",
        /*primColor*/
        c[6]
      ), w & /*size*/
      32 && le(
        a,
        "max-width",
        /*size*/
        c[5] + "px"
      );
    },
    d(c) {
      c && ve(e), t[12](null);
    }
  };
}
function yr(t) {
  let e, n;
  return {
    c() {
      e = ae("img"), F(e, "class", "custom-logo svelte-1foui59"), tr(e.src, n = /*customLogo*/
      t[4]) || F(e, "src", n), F(e, "alt", "logo"), le(
        e,
        "height",
        /*size*/
        t[5] + "px"
      );
    },
    m(r, a) {
      he(r, e, a);
    },
    p(r, a) {
      a & /*customLogo*/
      16 && !tr(e.src, n = /*customLogo*/
      r[4]) && F(e, "src", n), a & /*size*/
      32 && le(
        e,
        "height",
        /*size*/
        r[5] + "px"
      );
    },
    d(r) {
      r && ve(e);
    }
  };
}
function pr(t) {
  let e;
  return {
    c() {
      e = an("svg"), F(e, "class", "barcode"), F(
        e,
        "height",
        /*size*/
        t[5]
      );
    },
    m(n, r) {
      he(n, e, r), t[13](e);
    },
    p(n, r) {
      r & /*size*/
      32 && F(
        e,
        "height",
        /*size*/
        n[5]
      );
    },
    d(n) {
      n && ve(e), t[13](null);
    }
  };
}
function Er(t) {
  let e, n, r;
  return {
    c() {
      e = ae("div"), n = ae("p"), r = ze(
        /*value*/
        t[0]
      ), F(n, "class", "svelte-1foui59"), F(e, "class", "barcode-value svelte-1foui59");
    },
    m(a, i) {
      he(a, e, i), ee(e, n), ee(n, r);
    },
    p(a, i) {
      i & /*value*/
      1 && gt(
        r,
        /*value*/
        a[0]
      );
    },
    d(a) {
      a && ve(e);
    }
  };
}
function bf(t) {
  let e, n, r, a;
  function i(w, T) {
    return (
      /*value*/
      w[0] ? pf : yf
    );
  }
  let f = i(t), c = f(t);
  return {
    c() {
      e = ae("div"), c.c(), F(e, "class", "overall svelte-1foui59"), F(e, "styles", "border: 3px solid red; width: 100px; height: 200px;");
    },
    m(w, T) {
      he(w, e, T), c.m(e, null), r || (a = Wr(n = /*styleable*/
      t[10].call(
        null,
        e,
        /*$component*/
        t[9].styles
      )), r = !0);
    },
    p(w, [T]) {
      f === (f = i(w)) && c ? c.p(w, T) : (c.d(1), c = f(w), c && (c.c(), c.m(e, null))), n && en(n.update) && T & /*$component*/
      512 && n.update.call(
        null,
        /*$component*/
        w[9].styles
      );
    },
    i: Zt,
    o: Zt,
    d(w) {
      w && ve(e), c.d(), r = !1, a();
    }
  };
}
function wf(t, e, n) {
  let r, { value: a } = e, { codeType: i } = e, { showValue: f } = e, { showLogo: c } = e, { customLogo: w } = e, { size: T } = e, { primColor: N } = e;
  const { styleable: fe } = Wt("sdk"), V = Wt("component");
  tn(t, V, (M) => n(9, r = M));
  let q;
  function Ee() {
    q && a && ff(q, a, {
      displayValue: !1,
      // Hide the library's built in value, optionally display it later
      width: T / 100,
      height: T
    });
  }
  let U;
  const te = () => {
    if (U && i === "QR Code" && a) {
      const M = df({
        data: a,
        logo: c ? w : "",
        moduleFill: N,
        anchorOuterFill: N,
        anchorInnerFill: N,
        width: T,
        height: T
      });
      n(8, U.innerHTML = M, U);
    }
  };
  rn(() => {
    i === "Barcode" ? Ee() : te();
  });
  function Oe(M) {
    er[M ? "unshift" : "push"](() => {
      U = M, n(8, U);
    });
  }
  function G(M) {
    er[M ? "unshift" : "push"](() => {
      q = M, n(7, q);
    });
  }
  return t.$$set = (M) => {
    "value" in M && n(0, a = M.value), "codeType" in M && n(1, i = M.codeType), "showValue" in M && n(2, f = M.showValue), "showLogo" in M && n(3, c = M.showLogo), "customLogo" in M && n(4, w = M.customLogo), "size" in M && n(5, T = M.size), "primColor" in M && n(6, N = M.primColor);
  }, t.$$.update = () => {
    t.$$.dirty & /*codeType, value, barcodeElement, size*/
    163 && i === "Barcode" && a && q && T && Ee(), t.$$.dirty & /*codeType, value, qrContainer, showLogo, customLogo, size, primColor*/
    379 && i === "QR Code" && a && U && (c !== void 0 || w !== void 0 || T || N) && te();
  }, [
    a,
    i,
    f,
    c,
    w,
    T,
    N,
    q,
    U,
    r,
    fe,
    V,
    Oe,
    G
  ];
}
class xf extends Jr {
  constructor(e) {
    super(), Kr(this, e, wf, bf, Zr, {
      value: 0,
      codeType: 1,
      showValue: 2,
      showLogo: 3,
      customLogo: 4,
      size: 5,
      primColor: 6
    });
  }
}
export {
  xf as default
};
