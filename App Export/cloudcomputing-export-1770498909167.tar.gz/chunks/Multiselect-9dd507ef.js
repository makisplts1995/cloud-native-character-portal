import { S as p, i as v, s as x, cn as $, ac as B, ai as G, c as ee, m as ne, aj as I, k as le, n as te, p as oe, ae as ie, ab as ae } from "./index-e79f0bb2.js";
function fe(n) {
  let o, t, r, s;
  function S(l) {
    n[30](l);
  }
  function m(l) {
    n[31](l);
  }
  let d = {
    id: (
      /*id*/
      n[2]
    ),
    disabled: (
      /*disabled*/
      n[3]
    ),
    readonly: (
      /*readonly*/
      n[7]
    ),
    fieldText: (
      /*fieldText*/
      n[22]
    ),
    options: (
      /*options*/
      n[4]
    ),
    isPlaceholder: !/*arrayValue*/
    n[19].length,
    autocomplete: (
      /*autocomplete*/
      n[8]
    ),
    isOptionSelected: (
      /*isOptionSelected*/
      n[21]
    ),
    getOptionLabel: (
      /*getOptionLabel*/
      n[5]
    ),
    getOptionValue: (
      /*getOptionValue*/
      n[6]
    ),
    onSelectOption: (
      /*toggleOption*/
      n[20]
    ),
    sort: (
      /*sort*/
      n[9]
    ),
    autoWidth: (
      /*autoWidth*/
      n[10]
    ),
    customPopoverHeight: (
      /*customPopoverHeight*/
      n[11]
    ),
    loading: (
      /*loading*/
      n[12]
    ),
    onOptionMouseenter: (
      /*onOptionMouseenter*/
      n[13]
    ),
    onOptionMouseleave: (
      /*onOptionMouseleave*/
      n[14]
    ),
    searchPlaceholder: (
      /*searchPlaceholder*/
      n[15]
    ),
    showSelectAll: (
      /*showSelectAll*/
      n[16]
    ),
    selectAllText: (
      /*selectAllText*/
      n[17]
    ),
    indeterminate: (
      /*indeterminate*/
      n[23]
    ),
    allSelected: (
      /*allSelected*/
      n[18]
    ),
    toggleSelectAll: (
      /*toggleSelectAll*/
      n[24]
    )
  };
  return (
    /*searchTerm*/
    n[0] !== void 0 && (d.searchTerm = /*searchTerm*/
    n[0]), /*open*/
    n[1] !== void 0 && (d.open = /*open*/
    n[1]), o = new $({ props: d }), B.push(() => G(o, "searchTerm", S)), B.push(() => G(o, "open", m)), o.$on(
      "loadMore",
      /*loadMore_handler*/
      n[32]
    ), {
      c() {
        ee(o.$$.fragment);
      },
      m(l, i) {
        ne(o, l, i), s = !0;
      },
      p(l, i) {
        const a = {};
        i[0] & /*id*/
        4 && (a.id = /*id*/
        l[2]), i[0] & /*disabled*/
        8 && (a.disabled = /*disabled*/
        l[3]), i[0] & /*readonly*/
        128 && (a.readonly = /*readonly*/
        l[7]), i[0] & /*fieldText*/
        4194304 && (a.fieldText = /*fieldText*/
        l[22]), i[0] & /*options*/
        16 && (a.options = /*options*/
        l[4]), i[0] & /*arrayValue*/
        524288 && (a.isPlaceholder = !/*arrayValue*/
        l[19].length), i[0] & /*autocomplete*/
        256 && (a.autocomplete = /*autocomplete*/
        l[8]), i[0] & /*isOptionSelected*/
        2097152 && (a.isOptionSelected = /*isOptionSelected*/
        l[21]), i[0] & /*getOptionLabel*/
        32 && (a.getOptionLabel = /*getOptionLabel*/
        l[5]), i[0] & /*getOptionValue*/
        64 && (a.getOptionValue = /*getOptionValue*/
        l[6]), i[0] & /*toggleOption*/
        1048576 && (a.onSelectOption = /*toggleOption*/
        l[20]), i[0] & /*sort*/
        512 && (a.sort = /*sort*/
        l[9]), i[0] & /*autoWidth*/
        1024 && (a.autoWidth = /*autoWidth*/
        l[10]), i[0] & /*customPopoverHeight*/
        2048 && (a.customPopoverHeight = /*customPopoverHeight*/
        l[11]), i[0] & /*loading*/
        4096 && (a.loading = /*loading*/
        l[12]), i[0] & /*onOptionMouseenter*/
        8192 && (a.onOptionMouseenter = /*onOptionMouseenter*/
        l[13]), i[0] & /*onOptionMouseleave*/
        16384 && (a.onOptionMouseleave = /*onOptionMouseleave*/
        l[14]), i[0] & /*searchPlaceholder*/
        32768 && (a.searchPlaceholder = /*searchPlaceholder*/
        l[15]), i[0] & /*showSelectAll*/
        65536 && (a.showSelectAll = /*showSelectAll*/
        l[16]), i[0] & /*selectAllText*/
        131072 && (a.selectAllText = /*selectAllText*/
        l[17]), i[0] & /*indeterminate*/
        8388608 && (a.indeterminate = /*indeterminate*/
        l[23]), i[0] & /*allSelected*/
        262144 && (a.allSelected = /*allSelected*/
        l[18]), !t && i[0] & /*searchTerm*/
        1 && (t = !0, a.searchTerm = /*searchTerm*/
        l[0], I(() => t = !1)), !r && i[0] & /*open*/
        2 && (r = !0, a.open = /*open*/
        l[1], I(() => r = !1)), o.$set(a);
      },
      i(l) {
        s || (le(o.$$.fragment, l), s = !0);
      },
      o(l) {
        te(o.$$.fragment, l), s = !1;
      },
      d(l) {
        oe(o, l);
      }
    }
  );
}
function ue(n, o, t) {
  let r, s, S, m, d, l, i, a, P, { value: _ = [] } = o, { id: L = void 0 } = o, { placeholder: M = null } = o, { disabled: w = !1 } = o, { options: h = [] } = o, { getOptionLabel: k = (e, f) => e } = o, { getOptionValue: O = (e, f) => e } = o, { readonly: V = !1 } = o, { autocomplete: H = !1 } = o, { sort: W = !1 } = o, { autoWidth: y = !1 } = o, { searchTerm: b = null } = o, { customPopoverHeight: E = void 0 } = o, { open: T = !1 } = o, { loading: j = !1 } = o, { onOptionMouseenter: C = () => {
  } } = o, { onOptionMouseleave: q = () => {
  } } = o, { searchPlaceholder: D = "Search" } = o, { showSelectAll: F = !1 } = o, { selectAllText: z = "Select all" } = o;
  const A = ie(), J = (e, f, u) => {
    if (Array.isArray(e) && e.length > 0) {
      if (!f)
        return "";
      const g = e.map((c) => {
        const Z = typeof c == "string" ? c : c.toString();
        return f[Z] || c;
      }).join(", ");
      return `(${e.length}) ${g}`;
    } else
      return u || "Choose some options";
  }, K = (e) => {
    const f = {};
    return Array.isArray(e) && e.length > 0 && e.forEach((u) => {
      if (u) {
        const g = typeof u == "string" ? u : u.toString();
        f[g] = !0;
      }
    }), f;
  }, N = (e) => {
    if (!(e != null && e.length))
      return null;
    const f = {};
    return e.forEach((u, g) => {
      const c = O(u, g);
      c != null && (f[c] = k(u, g) || "");
    }), f;
  }, Q = (e, f) => (u) => {
    if (e[u]) {
      const g = f.filter((c) => c.toString() !== u.toString());
      A("change", g);
    } else
      A("change", [...f, u]);
  }, R = () => {
    if (m)
      A("change", []);
    else {
      const e = h.map((f) => O(f));
      A("change", e);
    }
  };
  function U(e) {
    b = e, t(0, b);
  }
  function X(e) {
    T = e, t(1, T);
  }
  function Y(e) {
    ae.call(this, n, e);
  }
  return n.$$set = (e) => {
    "value" in e && t(25, _ = e.value), "id" in e && t(2, L = e.id), "placeholder" in e && t(26, M = e.placeholder), "disabled" in e && t(3, w = e.disabled), "options" in e && t(4, h = e.options), "getOptionLabel" in e && t(5, k = e.getOptionLabel), "getOptionValue" in e && t(6, O = e.getOptionValue), "readonly" in e && t(7, V = e.readonly), "autocomplete" in e && t(8, H = e.autocomplete), "sort" in e && t(9, W = e.sort), "autoWidth" in e && t(10, y = e.autoWidth), "searchTerm" in e && t(0, b = e.searchTerm), "customPopoverHeight" in e && t(11, E = e.customPopoverHeight), "open" in e && t(1, T = e.open), "loading" in e && t(12, j = e.loading), "onOptionMouseenter" in e && t(13, C = e.onOptionMouseenter), "onOptionMouseleave" in e && t(14, q = e.onOptionMouseleave), "searchPlaceholder" in e && t(15, D = e.searchPlaceholder), "showSelectAll" in e && t(16, F = e.showSelectAll), "selectAllText" in e && t(17, z = e.selectAllText);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*value*/
    33554432 && t(19, r = Array.isArray(_) ? _ : [_].filter((e) => !!e)), n.$$.dirty[0] & /*arrayValue*/
    524288 && t(27, s = K(r)), n.$$.dirty[0] & /*options*/
    16 && t(28, S = N(h)), n.$$.dirty[0] & /*options, arrayValue, getOptionValue*/
    524368 && t(18, m = h.length > 0 && h.every((e) => r.includes(O(e)))), n.$$.dirty[0] & /*options, arrayValue, getOptionValue*/
    524368 && t(29, d = h.length === 0 || h.every((e) => !r.includes(O(e)))), n.$$.dirty[0] & /*allSelected, noneSelected*/
    537133056 && t(23, l = !m && !d), n.$$.dirty[0] & /*arrayValue, optionLookupMap, placeholder*/
    336068608 && t(22, i = J(r, S, M)), n.$$.dirty[0] & /*selectedLookupMap*/
    134217728 && t(21, a = (e) => s[e] === !0), n.$$.dirty[0] & /*selectedLookupMap, arrayValue*/
    134742016 && t(20, P = Q(s, r));
  }, [
    b,
    T,
    L,
    w,
    h,
    k,
    O,
    V,
    H,
    W,
    y,
    E,
    j,
    C,
    q,
    D,
    F,
    z,
    m,
    r,
    P,
    a,
    i,
    l,
    R,
    _,
    M,
    s,
    S,
    d,
    U,
    X,
    Y
  ];
}
class se extends p {
  constructor(o) {
    super(), v(
      this,
      o,
      ue,
      fe,
      x,
      {
        value: 25,
        id: 2,
        placeholder: 26,
        disabled: 3,
        options: 4,
        getOptionLabel: 5,
        getOptionValue: 6,
        readonly: 7,
        autocomplete: 8,
        sort: 9,
        autoWidth: 10,
        searchTerm: 0,
        customPopoverHeight: 11,
        open: 1,
        loading: 12,
        onOptionMouseenter: 13,
        onOptionMouseleave: 14,
        searchPlaceholder: 15,
        showSelectAll: 16,
        selectAllText: 17
      },
      null,
      [-1, -1]
    );
  }
}
export {
  se as M
};
