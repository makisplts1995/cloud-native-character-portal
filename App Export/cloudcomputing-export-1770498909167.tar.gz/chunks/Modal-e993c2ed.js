import { S as Q, i as R, s as T, y as U, f as J, k as _, z as P, n as g, A, o as F, u as w, v, ay as V, c as G, m as N, p as j, F as W, e as S, a as X, b as C, aJ as M, g as q, q as Y, G as Z, H as $, J as x, h as ee, ac as le, I as ne, B as te } from "./index-e79f0bb2.js";
function D(t) {
  let e, s, l = {
    disableCancel: (
      /*$builderStore*/
      t[5].inBuilder || /*ignoreClicksOutside*/
      t[0] || /*resolvedHideCloseIcon*/
      t[6]
    ),
    zIndex: 2,
    $$slots: { default: [se] },
    $$scope: { ctx: t }
  };
  return e = new V({ props: l }), t[18](e), e.$on(
    "cancel",
    /*handleModalClose*/
    t[12]
  ), {
    c() {
      G(e.$$.fragment);
    },
    m(n, o) {
      N(e, n, o), s = !0;
    },
    p(n, o) {
      const c = {};
      o & /*$builderStore, ignoreClicksOutside, resolvedHideCloseIcon*/
      97 && (c.disableCancel = /*$builderStore*/
      n[5].inBuilder || /*ignoreClicksOutside*/
      n[0] || /*resolvedHideCloseIcon*/
      n[6]), o & /*$$scope, size, $component, resolvedHideCloseIcon*/
      524370 && (c.$$scope = { dirty: o, ctx: n }), e.$set(c);
    },
    i(n) {
      s || (_(e.$$.fragment, n), s = !0);
    },
    o(n) {
      g(e.$$.fragment, n), s = !1;
    },
    d(n) {
      t[18](null), j(e, n);
    }
  };
}
function H(t) {
  let e, s;
  return e = new ne({
    props: {
      color: "var(--spectrum-global-color-gray-800)",
      name: "x",
      hoverable: !0
    }
  }), e.$on(
    "click",
    /*handleModalClose*/
    t[12]
  ), {
    c() {
      G(e.$$.fragment);
    },
    m(l, n) {
      N(e, l, n), s = !0;
    },
    p: te,
    i(l) {
      s || (_(e.$$.fragment, l), s = !0);
    },
    o(l) {
      g(e.$$.fragment, l), s = !1;
    },
    d(l) {
      j(e, l);
    }
  };
}
function se(t) {
  let e, s, l, n, o, c, m, u, p, h, a = !/*resolvedHideCloseIcon*/
  t[6] && H(t);
  const b = (
    /*#slots*/
    t[17].default
  ), r = W(
    b,
    t,
    /*$$scope*/
    t[19],
    null
  );
  return {
    c() {
      e = S("div"), s = S("div"), a && a.c(), l = X(), n = S("div"), o = S("div"), r && r.c(), C(s, "class", "modal-header svelte-3ffq1h"), C(o, "class", "modal-main-inner svelte-3ffq1h"), C(n, "class", "modal-main svelte-3ffq1h"), C(e, "class", c = M(`modal-content ${/*size*/
      t[1]}`) + " svelte-3ffq1h");
    },
    m(f, d) {
      J(f, e, d), q(e, s), a && a.m(s, null), q(e, l), q(e, n), q(n, o), r && r.m(o, null), u = !0, p || (h = Y(m = /*styleable*/
      t[8].call(
        null,
        e,
        /*$component*/
        t[4].styles
      )), p = !0);
    },
    p(f, d) {
      /*resolvedHideCloseIcon*/
      f[6] ? a && (P(), g(a, 1, 1, () => {
        a = null;
      }), A()) : a ? (a.p(f, d), d & /*resolvedHideCloseIcon*/
      64 && _(a, 1)) : (a = H(f), a.c(), _(a, 1), a.m(s, null)), r && r.p && (!u || d & /*$$scope*/
      524288) && Z(
        r,
        b,
        f,
        /*$$scope*/
        f[19],
        u ? x(
          b,
          /*$$scope*/
          f[19],
          d,
          null
        ) : $(
          /*$$scope*/
          f[19]
        ),
        null
      ), (!u || d & /*size*/
      2 && c !== (c = M(`modal-content ${/*size*/
      f[1]}`) + " svelte-3ffq1h")) && C(e, "class", c), m && ee(m.update) && d & /*$component*/
      16 && m.update.call(
        null,
        /*$component*/
        f[4].styles
      );
    },
    i(f) {
      u || (_(a), _(r, f), u = !0);
    },
    o(f) {
      g(a), g(r, f), u = !1;
    },
    d(f) {
      f && F(e), a && a.d(), r && r.d(f), p = !1, h();
    }
  };
}
function oe(t) {
  let e, s, l = (!/*$builderStore*/
  t[5].inBuilder || /*open*/
  t[3]) && D(t);
  return {
    c() {
      l && l.c(), e = U();
    },
    m(n, o) {
      l && l.m(n, o), J(n, e, o), s = !0;
    },
    p(n, [o]) {
      !/*$builderStore*/
      n[5].inBuilder || /*open*/
      n[3] ? l ? (l.p(n, o), o & /*$builderStore, open*/
      40 && _(l, 1)) : (l = D(n), l.c(), _(l, 1), l.m(e.parentNode, e)) : l && (P(), g(l, 1, 1, () => {
        l = null;
      }), A());
    },
    i(n) {
      s || (_(l), s = !0);
    },
    o(n) {
      g(l), s = !1;
    },
    d(n) {
      n && F(e), l && l.d(n);
    }
  };
}
function ie(t, e, s) {
  let l, n, o, c, m, u, { $$slots: p = {}, $$scope: h } = e;
  const a = w("component");
  v(t, a, (i) => s(4, o = i));
  const { styleable: b, modalStore: r, builderStore: f, dndIsDragging: d } = w("sdk");
  v(t, r, (i) => s(15, c = i)), v(t, f, (i) => s(5, u = i)), v(t, d, (i) => s(16, m = i));
  let { onClose: k } = e, { ignoreClicksOutside: z } = e, { hideCloseIcon: I } = e, { size: O } = e, y;
  const E = async () => {
    k && await k(), r.actions.close();
  }, K = (i, B) => {
    B && (i ? B.show() : B.hide());
  };
  function L(i) {
    le[i ? "unshift" : "push"](() => {
      y = i, s(2, y);
    });
  }
  return t.$$set = (i) => {
    "onClose" in i && s(13, k = i.onClose), "ignoreClicksOutside" in i && s(0, z = i.ignoreClicksOutside), "hideCloseIcon" in i && s(14, I = i.hideCloseIcon), "size" in i && s(1, O = i.size), "$$scope" in i && s(19, h = i.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty & /*$builderStore, $component, $modalStore, $dndIsDragging*/
    98352 && u.inBuilder && (o.inSelectedPath && c.contentId !== o.id ? r.actions.open(o.id) : !o.inSelectedPath && c.contentId === o.id && !m && r.actions.close()), t.$$.dirty & /*$modalStore, $component*/
    32784 && s(3, l = c.contentId === o.id), t.$$.dirty & /*hideCloseIcon, ignoreClicksOutside*/
    16385 && s(6, n = I === void 0 ? !!z : I), t.$$.dirty & /*open, modal*/
    12 && K(l, y);
  }, [
    z,
    O,
    y,
    l,
    o,
    u,
    n,
    a,
    b,
    r,
    f,
    d,
    E,
    k,
    I,
    c,
    m,
    p,
    L,
    h
  ];
}
class fe extends Q {
  constructor(e) {
    super(), R(this, e, ie, oe, T, {
      onClose: 13,
      ignoreClicksOutside: 0,
      hideCloseIcon: 14,
      size: 1
    });
  }
}
export {
  fe as default
};
