import { S as g, i as p, s as y, F as b, e as d, b as _, f as v, g as k, q as h, G as q, H as B, J as C, h as I, k as S, n as F, o as G, u as m, v as H } from "./index-e79f0bb2.js";
function J(l) {
  let n, s, u, a, r, f;
  const c = (
    /*#slots*/
    l[7].default
  ), t = b(
    c,
    l,
    /*$$scope*/
    l[6],
    null
  );
  return {
    c() {
      n = d("div"), s = d("div"), t && t.c(), _(s, "class", "inner svelte-1ovy8gu"), _(
        s,
        "style",
        /*style*/
        l[0]
      ), _(n, "class", "outer svelte-1ovy8gu");
    },
    m(e, o) {
      v(e, n, o), k(n, s), t && t.m(s, null), a = !0, r || (f = h(u = /*styleable*/
      l[2].call(
        null,
        n,
        /*$component*/
        l[1].styles
      )), r = !0);
    },
    p(e, [o]) {
      t && t.p && (!a || o & /*$$scope*/
      64) && q(
        t,
        c,
        e,
        /*$$scope*/
        e[6],
        a ? C(
          c,
          /*$$scope*/
          e[6],
          o,
          null
        ) : B(
          /*$$scope*/
          e[6]
        ),
        null
      ), (!a || o & /*style*/
      1) && _(
        s,
        "style",
        /*style*/
        e[0]
      ), u && I(u.update) && o & /*$component*/
      2 && u.update.call(
        null,
        /*$component*/
        e[1].styles
      );
    },
    i(e) {
      a || (S(t, e), a = !0);
    },
    o(e) {
      F(t, e), a = !1;
    },
    d(e) {
      e && G(n), t && t.d(e), r = !1, f();
    }
  };
}
function j(l, n, s) {
  let u, { $$slots: a = {}, $$scope: r } = n;
  const { styleable: f } = m("sdk"), c = m("component");
  H(l, c, (i) => s(1, u = i));
  let { url: t } = n, { position: e } = n, o = "";
  return l.$$set = (i) => {
    "url" in i && s(4, t = i.url), "position" in i && s(5, e = i.position), "$$scope" in i && s(6, r = i.$$scope);
  }, l.$$.update = () => {
    l.$$.dirty & /*url, style, position*/
    49 && (t && s(0, o += `background-image: url("${t}");`), e && s(0, o += `background-position: ${e};`));
  }, [o, u, f, c, t, e, r, a];
}
class z extends g {
  constructor(n) {
    super(), p(this, n, j, J, y, { url: 4, position: 5 });
  }
}
export {
  z as default
};
