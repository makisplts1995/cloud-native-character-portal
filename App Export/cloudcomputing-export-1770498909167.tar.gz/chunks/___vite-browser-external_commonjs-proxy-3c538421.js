import { X as e } from "./index-e79f0bb2.js";
const t = {}, r = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: t
}, Symbol.toStringTag, { value: "Module" })), a = /* @__PURE__ */ e(r);
export {
  a as r
};
