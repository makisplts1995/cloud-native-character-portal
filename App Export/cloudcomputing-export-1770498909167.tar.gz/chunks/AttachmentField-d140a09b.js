import { S as X, i as Z, s as v, ac as D, ai as E, c as G, m as H, aj as L, k as _, n as A, p as Y, b2 as p, u as j, v as x, y as $, f as ee, z as le, A as ie, o as ne, cG as ae } from "./index-e79f0bb2.js";
import { F as te } from "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function q(n) {
  let i, a;
  return i = new ae({
    props: {
      value: (
        /*fieldApiMapper*/
        n[14].get(
          /*fieldState*/
          n[16].value
        )
      ),
      disabled: (
        /*fieldState*/
        n[16].disabled || /*fieldState*/
        n[16].readonly
      ),
      error: (
        /*fieldState*/
        n[16].error
      ),
      processFiles: (
        /*processFiles*/
        n[22]
      ),
      handleFileTooLarge: (
        /*$environmentStore*/
        n[18].cloud ? (
          /*handleFileTooLarge*/
          n[20]
        ) : null
      ),
      handleTooManyFiles: (
        /*handleTooManyFiles*/
        n[21]
      ),
      maximum: (
        /*maximum*/
        n[7]
      ),
      extensions: (
        /*extensions*/
        n[6]
      ),
      compact: (
        /*compact*/
        n[4]
      ),
      titleText: (
        /*titleText*/
        n[10]
      ),
      clickText: (
        /*clickText*/
        n[11]
      ),
      addText: (
        /*addText*/
        n[12]
      )
    }
  }), i.$on(
    "change",
    /*handleChange*/
    n[23]
  ), {
    c() {
      G(i.$$.fragment);
    },
    m(l, t) {
      H(i, l, t), a = !0;
    },
    p(l, t) {
      const d = {};
      t & /*fieldApiMapper, fieldState*/
      81920 && (d.value = /*fieldApiMapper*/
      l[14].get(
        /*fieldState*/
        l[16].value
      )), t & /*fieldState*/
      65536 && (d.disabled = /*fieldState*/
      l[16].disabled || /*fieldState*/
      l[16].readonly), t & /*fieldState*/
      65536 && (d.error = /*fieldState*/
      l[16].error), t & /*$environmentStore*/
      262144 && (d.handleFileTooLarge = /*$environmentStore*/
      l[18].cloud ? (
        /*handleFileTooLarge*/
        l[20]
      ) : null), t & /*maximum*/
      128 && (d.maximum = /*maximum*/
      l[7]), t & /*extensions*/
      64 && (d.extensions = /*extensions*/
      l[6]), t & /*compact*/
      16 && (d.compact = /*compact*/
      l[4]), t & /*titleText*/
      1024 && (d.titleText = /*titleText*/
      l[10]), t & /*clickText*/
      2048 && (d.clickText = /*clickText*/
      l[11]), t & /*addText*/
      4096 && (d.addText = /*addText*/
      l[12]), i.$set(d);
    },
    i(l) {
      a || (_(i.$$.fragment, l), a = !0);
    },
    o(l) {
      A(i.$$.fragment, l), a = !1;
    },
    d(l) {
      Y(i, l);
    }
  };
}
function fe(n) {
  let i, a, l = (
    /*fieldState*/
    n[16] && q(n)
  );
  return {
    c() {
      l && l.c(), i = $();
    },
    m(t, d) {
      l && l.m(t, d), ee(t, i, d), a = !0;
    },
    p(t, d) {
      /*fieldState*/
      t[16] ? l ? (l.p(t, d), d & /*fieldState*/
      65536 && _(l, 1)) : (l = q(t), l.c(), _(l, 1), l.m(i.parentNode, i)) : l && (le(), A(l, 1, 1, () => {
        l = null;
      }), ie());
    },
    i(t) {
      a || (_(l), a = !0);
    },
    o(t) {
      A(l), a = !1;
    },
    d(t) {
      t && ne(i), l && l.d(t);
    }
  };
}
function de(n) {
  let i, a, l, t;
  function d(f) {
    n[25](f);
  }
  function T(f) {
    n[26](f);
  }
  let c = {
    label: (
      /*label*/
      n[1]
    ),
    field: (
      /*field*/
      n[0]
    ),
    disabled: (
      /*disabled*/
      n[2]
    ),
    readonly: (
      /*readonly*/
      n[3]
    ),
    validation: (
      /*validation*/
      n[5]
    ),
    span: (
      /*span*/
      n[8]
    ),
    helpText: (
      /*helpText*/
      n[9]
    ),
    type: (
      /*type*/
      n[13]
    ),
    defaultValue: (
      /*defaultValue*/
      n[15]
    ),
    $$slots: { default: [fe] },
    $$scope: { ctx: n }
  };
  return (
    /*fieldState*/
    n[16] !== void 0 && (c.fieldState = /*fieldState*/
    n[16]), /*fieldApi*/
    n[17] !== void 0 && (c.fieldApi = /*fieldApi*/
    n[17]), i = new te({ props: c }), D.push(() => E(i, "fieldState", d)), D.push(() => E(i, "fieldApi", T)), {
      c() {
        G(i.$$.fragment);
      },
      m(f, o) {
        H(i, f, o), t = !0;
      },
      p(f, [o]) {
        const u = {};
        o & /*label*/
        2 && (u.label = /*label*/
        f[1]), o & /*field*/
        1 && (u.field = /*field*/
        f[0]), o & /*disabled*/
        4 && (u.disabled = /*disabled*/
        f[2]), o & /*readonly*/
        8 && (u.readonly = /*readonly*/
        f[3]), o & /*validation*/
        32 && (u.validation = /*validation*/
        f[5]), o & /*span*/
        256 && (u.span = /*span*/
        f[8]), o & /*helpText*/
        512 && (u.helpText = /*helpText*/
        f[9]), o & /*type*/
        8192 && (u.type = /*type*/
        f[13]), o & /*defaultValue*/
        32768 && (u.defaultValue = /*defaultValue*/
        f[15]), o & /*$$scope, fieldApiMapper, fieldState, $environmentStore, maximum, extensions, compact, titleText, clickText, addText*/
        1074093264 && (u.$$scope = { dirty: o, ctx: f }), !a && o & /*fieldState*/
        65536 && (a = !0, u.fieldState = /*fieldState*/
        f[16], L(() => a = !1)), !l && o & /*fieldApi*/
        131072 && (l = !0, u.fieldApi = /*fieldApi*/
        f[17], L(() => l = !1)), i.$set(u);
      },
      i(f) {
        t || (_(i.$$.fragment, f), t = !0);
      },
      o(f) {
        A(i.$$.fragment, f), t = !1;
      },
      d(f) {
        Y(i, f);
      }
    }
  );
}
const oe = 1e6;
function ue(n, i, a) {
  let l, { field: t } = i, { label: d } = i, { disabled: T = !1 } = i, { readonly: c = !1 } = i, { compact: f = !1 } = i, { validation: o } = i, { extensions: u } = i, { onChange: g } = i, { maximum: F = void 0 } = i, { span: M } = i, { helpText: w = null } = i, { titleText: V } = i, { clickText: C } = i, { addText: z } = i, { type: I = p.ATTACHMENTS } = i, { fieldApiMapper: S = { get: (e) => e, set: (e) => e } } = i, { defaultValue: B = [] } = i, k, b;
  const { API: J, notificationStore: N, environmentStore: P } = j("sdk");
  x(n, P, (e) => a(18, l = e));
  const s = j("form"), K = (e) => {
    N.actions.warning(`Files cannot exceed ${e / oe} MB. Please try again with smaller files.`);
  }, O = (e) => {
    N.actions.warning(`Please select a maximum of ${e} files.`);
  }, Q = async (e) => {
    var h, y;
    let r = new FormData();
    for (let m = 0; m < e.length; m++)
      r.append("file", e[m]);
    try {
      let m = (h = s == null ? void 0 : s.dataSource) == null ? void 0 : h.tableId;
      return ((y = s == null ? void 0 : s.dataSource) == null ? void 0 : y.type) === "viewV2" && (m = s.dataSource.id), await J.uploadAttachment(m, r);
    } catch {
      return [];
    }
  }, R = (e) => {
    const r = S.set(e.detail), h = b.setValue(r);
    g && h && g({ value: r });
  };
  function U(e) {
    k = e, a(16, k);
  }
  function W(e) {
    b = e, a(17, b);
  }
  return n.$$set = (e) => {
    "field" in e && a(0, t = e.field), "label" in e && a(1, d = e.label), "disabled" in e && a(2, T = e.disabled), "readonly" in e && a(3, c = e.readonly), "compact" in e && a(4, f = e.compact), "validation" in e && a(5, o = e.validation), "extensions" in e && a(6, u = e.extensions), "onChange" in e && a(24, g = e.onChange), "maximum" in e && a(7, F = e.maximum), "span" in e && a(8, M = e.span), "helpText" in e && a(9, w = e.helpText), "titleText" in e && a(10, V = e.titleText), "clickText" in e && a(11, C = e.clickText), "addText" in e && a(12, z = e.addText), "type" in e && a(13, I = e.type), "fieldApiMapper" in e && a(14, S = e.fieldApiMapper), "defaultValue" in e && a(15, B = e.defaultValue);
  }, [
    t,
    d,
    T,
    c,
    f,
    o,
    u,
    F,
    M,
    w,
    V,
    C,
    z,
    I,
    S,
    B,
    k,
    b,
    l,
    P,
    K,
    O,
    Q,
    R,
    g,
    U,
    W
  ];
}
class _e extends X {
  constructor(i) {
    super(), Z(this, i, ue, de, v, {
      field: 0,
      label: 1,
      disabled: 2,
      readonly: 3,
      compact: 4,
      validation: 5,
      extensions: 6,
      onChange: 24,
      maximum: 7,
      span: 8,
      helpText: 9,
      titleText: 10,
      clickText: 11,
      addText: 12,
      type: 13,
      fieldApiMapper: 14,
      defaultValue: 15
    });
  }
}
export {
  _e as default
};
