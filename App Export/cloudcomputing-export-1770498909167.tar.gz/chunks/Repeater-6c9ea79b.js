import { S as J, i as L, s as O, c as k, m as b, k as u, n as g, p as A, u as N, v as D, y as F, f as d, z as G, A as H, o as h, e as S, t as E, b as B, g as P, j as I, B as p, N as j, O as K, F as Q, a as T, G as U, H as V, J as W } from "./index-e79f0bb2.js";
import X from "./Placeholder-527c0fd1.js";
import Y from "./Container-5c26767f.js";
function q(r, e, l) {
  const n = r.slice();
  return n[15] = e[l], n[17] = l, n;
}
function Z(r) {
  let e, l, n;
  return {
    c() {
      e = S("div"), l = S("i"), n = E(
        /*noRowsMessage*/
        r[0]
      ), B(l, "class", "ri-list-check-2 svelte-1lkne36"), B(e, "class", "noRows svelte-1lkne36");
    },
    m(t, i) {
      d(t, e, i), P(e, l), P(e, n);
    },
    p(t, i) {
      i & /*noRowsMessage*/
      1 && I(
        n,
        /*noRowsMessage*/
        t[0]
      );
    },
    i: p,
    o: p,
    d(t) {
      t && h(e);
    }
  };
}
function x(r) {
  let e, l, n = j(
    /*rows*/
    r[7]
  ), t = [];
  for (let s = 0; s < n.length; s += 1)
    t[s] = z(q(r, n, s));
  const i = (s) => g(t[s], 1, 1, () => {
    t[s] = null;
  });
  return {
    c() {
      for (let s = 0; s < t.length; s += 1)
        t[s].c();
      e = F();
    },
    m(s, a) {
      for (let o = 0; o < t.length; o += 1)
        t[o] && t[o].m(s, a);
      d(s, e, a), l = !0;
    },
    p(s, a) {
      if (a & /*rows, scope, $$scope*/
      8352) {
        n = j(
          /*rows*/
          s[7]
        );
        let o;
        for (o = 0; o < n.length; o += 1) {
          const c = q(s, n, o);
          t[o] ? (t[o].p(c, a), u(t[o], 1)) : (t[o] = z(c), t[o].c(), u(t[o], 1), t[o].m(e.parentNode, e));
        }
        for (G(), o = n.length; o < t.length; o += 1)
          i(o);
        H();
      }
    },
    i(s) {
      if (!l) {
        for (let a = 0; a < n.length; a += 1)
          u(t[a]);
        l = !0;
      }
    },
    o(s) {
      t = t.filter(Boolean);
      for (let a = 0; a < t.length; a += 1)
        g(t[a]);
      l = !1;
    },
    d(s) {
      s && h(e), K(t, s);
    }
  };
}
function $(r) {
  let e, l;
  return e = new X({}), {
    c() {
      k(e.$$.fragment);
    },
    m(n, t) {
      b(e, n, t), l = !0;
    },
    p,
    i(n) {
      l || (u(e.$$.fragment, n), l = !0);
    },
    o(n) {
      g(e.$$.fragment, n), l = !1;
    },
    d(n) {
      A(e, n);
    }
  };
}
function ee(r) {
  let e, l;
  const n = (
    /*#slots*/
    r[12].default
  ), t = Q(
    n,
    r,
    /*$$scope*/
    r[13],
    null
  );
  return {
    c() {
      t && t.c(), e = T();
    },
    m(i, s) {
      t && t.m(i, s), d(i, e, s), l = !0;
    },
    p(i, s) {
      t && t.p && (!l || s & /*$$scope*/
      8192) && U(
        t,
        n,
        i,
        /*$$scope*/
        i[13],
        l ? W(
          n,
          /*$$scope*/
          i[13],
          s,
          null
        ) : V(
          /*$$scope*/
          i[13]
        ),
        null
      );
    },
    i(i) {
      l || (u(t, i), l = !0);
    },
    o(i) {
      g(t, i), l = !1;
    },
    d(i) {
      i && h(e), t && t.d(i);
    }
  };
}
function z(r) {
  let e, l;
  return e = new /*Provider*/
  r[9]({
    props: {
      data: {
        .../*row*/
        r[15],
        index: (
          /*index*/
          r[17]
        )
      },
      scope: (
        /*scope*/
        r[5]
      ),
      $$slots: { default: [ee] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      k(e.$$.fragment);
    },
    m(n, t) {
      b(e, n, t), l = !0;
    },
    p(n, t) {
      const i = {};
      t & /*rows*/
      128 && (i.data = {
        .../*row*/
        n[15],
        index: (
          /*index*/
          n[17]
        )
      }), t & /*scope*/
      32 && (i.scope = /*scope*/
      n[5]), t & /*$$scope*/
      8192 && (i.$$scope = { dirty: t, ctx: n }), e.$set(i);
    },
    i(n) {
      l || (u(e.$$.fragment, n), l = !0);
    },
    o(n) {
      g(e.$$.fragment, n), l = !1;
    },
    d(n) {
      A(e, n);
    }
  };
}
function te(r) {
  let e, l, n, t;
  const i = [$, x, Z], s = [];
  function a(o, c) {
    return (
      /*$component*/
      o[8].empty ? 0 : (
        /*rows*/
        o[7].length > 0 ? 1 : (
          /*loaded*/
          o[6] && /*noRowsMessage*/
          o[0] ? 2 : -1
        )
      )
    );
  }
  return ~(e = a(r)) && (l = s[e] = i[e](r)), {
    c() {
      l && l.c(), n = F();
    },
    m(o, c) {
      ~e && s[e].m(o, c), d(o, n, c), t = !0;
    },
    p(o, c) {
      let m = e;
      e = a(o), e === m ? ~e && s[e].p(o, c) : (l && (G(), g(s[m], 1, 1, () => {
        s[m] = null;
      }), H()), ~e ? (l = s[e], l ? l.p(o, c) : (l = s[e] = i[e](o), l.c()), u(l, 1), l.m(n.parentNode, n)) : l = null);
    },
    i(o) {
      t || (u(l), t = !0);
    },
    o(o) {
      g(l), t = !1;
    },
    d(o) {
      o && h(n), ~e && s[e].d(o);
    }
  };
}
function ne(r) {
  let e, l;
  return e = new Y({
    props: {
      direction: (
        /*direction*/
        r[1]
      ),
      hAlign: (
        /*hAlign*/
        r[2]
      ),
      vAlign: (
        /*vAlign*/
        r[3]
      ),
      gap: (
        /*gap*/
        r[4]
      ),
      wrap: !0,
      $$slots: { default: [te] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      k(e.$$.fragment);
    },
    m(n, t) {
      b(e, n, t), l = !0;
    },
    p(n, [t]) {
      const i = {};
      t & /*direction*/
      2 && (i.direction = /*direction*/
      n[1]), t & /*hAlign*/
      4 && (i.hAlign = /*hAlign*/
      n[2]), t & /*vAlign*/
      8 && (i.vAlign = /*vAlign*/
      n[3]), t & /*gap*/
      16 && (i.gap = /*gap*/
      n[4]), t & /*$$scope, $component, rows, scope, noRowsMessage, loaded*/
      8673 && (i.$$scope = { dirty: t, ctx: n }), e.$set(i);
    },
    i(n) {
      l || (u(e.$$.fragment, n), l = !0);
    },
    o(n) {
      g(e.$$.fragment, n), l = !1;
    },
    d(n) {
      A(e, n);
    }
  };
}
function le(r, e, l) {
  let n, t, i, { $$slots: s = {}, $$scope: a } = e;
  const { Provider: o, ContextScopes: c } = N("sdk"), m = N("component");
  D(r, m, (f) => l(8, i = f));
  let { dataProvider: _ } = e, { noRowsMessage: w } = e, { direction: v } = e, { hAlign: R } = e, { vAlign: C } = e, { gap: M } = e, { scope: y = c.Local } = e;
  return r.$$set = (f) => {
    "dataProvider" in f && l(11, _ = f.dataProvider), "noRowsMessage" in f && l(0, w = f.noRowsMessage), "direction" in f && l(1, v = f.direction), "hAlign" in f && l(2, R = f.hAlign), "vAlign" in f && l(3, C = f.vAlign), "gap" in f && l(4, M = f.gap), "scope" in f && l(5, y = f.scope), "$$scope" in f && l(13, a = f.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty & /*dataProvider*/
    2048 && l(7, n = (_ == null ? void 0 : _.rows) ?? []), r.$$.dirty & /*dataProvider*/
    2048 && l(6, t = (_ == null ? void 0 : _.loaded) ?? !0);
  }, [
    w,
    v,
    R,
    C,
    M,
    y,
    t,
    n,
    i,
    o,
    m,
    _,
    s,
    a
  ];
}
class re extends J {
  constructor(e) {
    super(), L(this, e, le, ne, O, {
      dataProvider: 11,
      noRowsMessage: 0,
      direction: 1,
      hAlign: 2,
      vAlign: 3,
      gap: 4,
      scope: 5
    });
  }
}
export {
  re as default
};
