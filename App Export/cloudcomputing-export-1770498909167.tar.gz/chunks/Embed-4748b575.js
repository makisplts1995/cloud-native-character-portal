import { S as g, i as S, s as q, y as B, f as m, z as C, n as f, A as E, k as _, o as d, u as p, v as b, e as k, c as H, m as L, q as v, h, p as M, b as T, B as y } from "./index-e79f0bb2.js";
import w from "./Placeholder-527c0fd1.js";
function z(a) {
  let e, t, o, s, r, l;
  return t = new w({}), {
    c() {
      e = k("div"), H(t.$$.fragment);
    },
    m(i, n) {
      m(i, e, n), L(t, e, null), s = !0, r || (l = v(o = /*styleable*/
      a[3].call(null, e, {
        .../*$component*/
        a[1].styles,
        empty: !0
      })), r = !0);
    },
    p(i, n) {
      o && h(o.update) && n & /*$component*/
      2 && o.update.call(null, {
        .../*$component*/
        i[1].styles,
        empty: !0
      });
    },
    i(i) {
      s || (_(t.$$.fragment, i), s = !0);
    },
    o(i) {
      f(t.$$.fragment, i), s = !1;
    },
    d(i) {
      i && d(e), M(t), r = !1, l();
    }
  };
}
function A(a) {
  let e, t, o, s;
  return {
    c() {
      e = k("div"), T(e, "class", "embed svelte-nd6hd8");
    },
    m(r, l) {
      m(r, e, l), e.innerHTML = /*embed*/
      a[0], o || (s = v(t = /*styleable*/
      a[3].call(
        null,
        e,
        /*$component*/
        a[1].styles
      )), o = !0);
    },
    p(r, l) {
      l & /*embed*/
      1 && (e.innerHTML = /*embed*/
      r[0]), t && h(t.update) && l & /*$component*/
      2 && t.update.call(
        null,
        /*$component*/
        r[1].styles
      );
    },
    i: y,
    o: y,
    d(r) {
      r && d(e), o = !1, s();
    }
  };
}
function N(a) {
  let e, t, o, s;
  const r = [A, z], l = [];
  function i(n, u) {
    return (
      /*embed*/
      n[0] ? 0 : (
        /*$builderStore*/
        n[2].inBuilder ? 1 : -1
      )
    );
  }
  return ~(e = i(a)) && (t = l[e] = r[e](a)), {
    c() {
      t && t.c(), o = B();
    },
    m(n, u) {
      ~e && l[e].m(n, u), m(n, o, u), s = !0;
    },
    p(n, [u]) {
      let c = e;
      e = i(n), e === c ? ~e && l[e].p(n, u) : (t && (C(), f(l[c], 1, 1, () => {
        l[c] = null;
      }), E()), ~e ? (t = l[e], t ? t.p(n, u) : (t = l[e] = r[e](n), t.c()), _(t, 1), t.m(o.parentNode, o)) : t = null);
    },
    i(n) {
      s || (_(t), s = !0);
    },
    o(n) {
      f(t), s = !1;
    },
    d(n) {
      n && d(o), ~e && l[e].d(n);
    }
  };
}
function P(a, e, t) {
  let o, s;
  const { styleable: r, builderStore: l } = p("sdk");
  b(a, l, (u) => t(2, s = u));
  const i = p("component");
  b(a, i, (u) => t(1, o = u));
  let { embed: n } = e;
  return a.$$set = (u) => {
    "embed" in u && t(0, n = u.embed);
  }, [n, o, s, r, l, i];
}
class F extends g {
  constructor(e) {
    super(), S(this, e, P, N, q, { embed: 0 });
  }
}
export {
  F as default
};
