import { S as d, i as v, s as f, e as p, b as o, f as D, q as _, h, B as u, o as z, u as m, v as b } from "./index-e79f0bb2.js";
function g(s) {
  let e, i, a, n, c;
  return {
    c() {
      e = p("hr"), o(e, "class", i = "spectrum-Divider spectrum-Divider--" + /*vertical*/
      (s[1] ? "vertical" : "horizontal") + " spectrum-Dialog-divider spectrum-Divider--size" + /*size*/
      s[0]);
    },
    m(t, r) {
      D(t, e, r), n || (c = _(a = /*styleable*/
      s[3].call(
        null,
        e,
        /*$component*/
        s[2].styles
      )), n = !0);
    },
    p(t, [r]) {
      r & /*vertical, size*/
      3 && i !== (i = "spectrum-Divider spectrum-Divider--" + /*vertical*/
      (t[1] ? "vertical" : "horizontal") + " spectrum-Dialog-divider spectrum-Divider--size" + /*size*/
      t[0]) && o(e, "class", i), a && h(a.update) && r & /*$component*/
      4 && a.update.call(
        null,
        /*$component*/
        t[2].styles
      );
    },
    i: u,
    o: u,
    d(t) {
      t && z(e), n = !1, c();
    }
  };
}
function y(s, e, i) {
  let a;
  const { styleable: n } = m("sdk"), c = m("component");
  b(s, c, (l) => i(2, a = l));
  let { size: t = "M" } = e, { vertical: r = !1 } = e;
  return s.$$set = (l) => {
    "size" in l && i(0, t = l.size), "vertical" in l && i(1, r = l.vertical);
  }, [t, r, a, n, c];
}
class C extends d {
  constructor(e) {
    super(), v(this, e, y, g, f, { size: 0, vertical: 1 });
  }
}
export {
  C as default
};
