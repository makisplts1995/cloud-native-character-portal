import { S as ne, i as ie, s as J, y as w, f as m, B as E, o as g, u as F, v as G, ac as te, e as y, t as B, b as d, d as r, g as P, q as S, l as I, h as T, aI as ae, r as K, j as O } from "./index-e79f0bb2.js";
function fe(l) {
  let e;
  function t(i, s) {
    return (
      /*externalLink*/
      i[7] || /*openInNewTab*/
      i[0] ? se : ue
    );
  }
  let f = t(l), n = f(l);
  return {
    c() {
      n.c(), e = w();
    },
    m(i, s) {
      n.m(i, s), m(i, e, s);
    },
    p(i, s) {
      f === (f = t(i)) && n ? n.p(i, s) : (n.d(1), n = f(i), n && (n.c(), n.m(e.parentNode, e)));
    },
    d(i) {
      i && g(e), n.d(i);
    }
  };
}
function oe(l) {
  let e, t, f, n, i, s;
  return {
    c() {
      e = y("div"), t = B(
        /*componentText*/
        l[13]
      ), d(e, "contenteditable", ""), d(e, "class", f = "align--" + /*align*/
      (l[1] || "left") + " size--" + /*size*/
      (l[5] || "M") + " svelte-1dqdd23"), r(
        e,
        "bold",
        /*bold*/
        l[2]
      ), r(
        e,
        "italic",
        /*italic*/
        l[3]
      ), r(
        e,
        "underline",
        /*underline*/
        l[4]
      );
    },
    m(o, u) {
      m(o, e, u), P(e, t), l[25](e), i || (s = [
        S(n = /*styleable*/
        l[17].call(
          null,
          e,
          /*styles*/
          l[11]
        )),
        I(e, "blur", function() {
          T(
            /*$component*/
            l[8].editing ? (
              /*updateText*/
              l[21]
            ) : null
          ) && /*$component*/
          (l[8].editing ? (
            /*updateText*/
            l[21]
          ) : null).apply(this, arguments);
        }),
        I(
          e,
          "input",
          /*input_handler*/
          l[26]
        )
      ], i = !0);
    },
    p(o, u) {
      l = o, u[0] & /*componentText*/
      8192 && ae(
        t,
        /*componentText*/
        l[13]
      ), u[0] & /*align, size*/
      34 && f !== (f = "align--" + /*align*/
      (l[1] || "left") + " size--" + /*size*/
      (l[5] || "M") + " svelte-1dqdd23") && d(e, "class", f), n && T(n.update) && u[0] & /*styles*/
      2048 && n.update.call(
        null,
        /*styles*/
        l[11]
      ), u[0] & /*align, size, bold*/
      38 && r(
        e,
        "bold",
        /*bold*/
        l[2]
      ), u[0] & /*align, size, italic*/
      42 && r(
        e,
        "italic",
        /*italic*/
        l[3]
      ), u[0] & /*align, size, underline*/
      50 && r(
        e,
        "underline",
        /*underline*/
        l[4]
      );
    },
    d(o) {
      o && g(e), l[25](null), i = !1, K(s);
    }
  };
}
function ue(l) {
  let e = (
    /*sanitizedUrl*/
    l[12]
  ), t, f = H(l);
  return {
    c() {
      f.c(), t = w();
    },
    m(n, i) {
      f.m(n, i), m(n, t, i);
    },
    p(n, i) {
      i[0] & /*sanitizedUrl*/
      4096 && J(e, e = /*sanitizedUrl*/
      n[12]) ? (f.d(1), f = H(n), f.c(), f.m(t.parentNode, t)) : f.p(n, i);
    },
    d(n) {
      n && g(t), f.d(n);
    }
  };
}
function se(l) {
  let e, t, f, n, i, s;
  return {
    c() {
      e = y("a"), t = B(
        /*componentText*/
        l[13]
      ), d(
        e,
        "target",
        /*target*/
        l[15]
      ), d(
        e,
        "href",
        /*sanitizedUrl*/
        l[12]
      ), d(e, "class", f = "align--" + /*align*/
      (l[1] || "left") + " size--" + /*size*/
      (l[5] || "M") + " svelte-1dqdd23"), r(
        e,
        "placeholder",
        /*placeholder*/
        l[14]
      ), r(
        e,
        "bold",
        /*bold*/
        l[2]
      ), r(
        e,
        "italic",
        /*italic*/
        l[3]
      ), r(
        e,
        "underline",
        /*underline*/
        l[4]
      );
    },
    m(o, u) {
      m(o, e, u), P(e, t), i || (s = S(n = /*styleable*/
      l[17].call(
        null,
        e,
        /*styles*/
        l[11]
      )), i = !0);
    },
    p(o, u) {
      u[0] & /*componentText*/
      8192 && O(
        t,
        /*componentText*/
        o[13]
      ), u[0] & /*target*/
      32768 && d(
        e,
        "target",
        /*target*/
        o[15]
      ), u[0] & /*sanitizedUrl*/
      4096 && d(
        e,
        "href",
        /*sanitizedUrl*/
        o[12]
      ), u[0] & /*align, size*/
      34 && f !== (f = "align--" + /*align*/
      (o[1] || "left") + " size--" + /*size*/
      (o[5] || "M") + " svelte-1dqdd23") && d(e, "class", f), n && T(n.update) && u[0] & /*styles*/
      2048 && n.update.call(
        null,
        /*styles*/
        o[11]
      ), u[0] & /*align, size, placeholder*/
      16418 && r(
        e,
        "placeholder",
        /*placeholder*/
        o[14]
      ), u[0] & /*align, size, bold*/
      38 && r(
        e,
        "bold",
        /*bold*/
        o[2]
      ), u[0] & /*align, size, italic*/
      42 && r(
        e,
        "italic",
        /*italic*/
        o[3]
      ), u[0] & /*align, size, underline*/
      50 && r(
        e,
        "underline",
        /*underline*/
        o[4]
      );
    },
    d(o) {
      o && g(e), i = !1, s();
    }
  };
}
function H(l) {
  let e, t, f, n, i, s;
  return {
    c() {
      e = y("a"), t = B(
        /*componentText*/
        l[13]
      ), d(
        e,
        "href",
        /*sanitizedUrl*/
        l[12]
      ), d(e, "class", f = "align--" + /*align*/
      (l[1] || "left") + " size--" + /*size*/
      (l[5] || "M") + " svelte-1dqdd23"), r(
        e,
        "placeholder",
        /*placeholder*/
        l[14]
      ), r(
        e,
        "bold",
        /*bold*/
        l[2]
      ), r(
        e,
        "italic",
        /*italic*/
        l[3]
      ), r(
        e,
        "underline",
        /*underline*/
        l[4]
      );
    },
    m(o, u) {
      m(o, e, u), P(e, t), i || (s = [
        S(
          /*linkable*/
          l[16].call(null, e)
        ),
        S(n = /*styleable*/
        l[17].call(
          null,
          e,
          /*styles*/
          l[11]
        )),
        I(
          e,
          "click",
          /*handleUrlChange*/
          l[20]
        )
      ], i = !0);
    },
    p(o, u) {
      u[0] & /*componentText*/
      8192 && O(
        t,
        /*componentText*/
        o[13]
      ), u[0] & /*sanitizedUrl*/
      4096 && d(
        e,
        "href",
        /*sanitizedUrl*/
        o[12]
      ), u[0] & /*align, size*/
      34 && f !== (f = "align--" + /*align*/
      (o[1] || "left") + " size--" + /*size*/
      (o[5] || "M") + " svelte-1dqdd23") && d(e, "class", f), n && T(n.update) && u[0] & /*styles*/
      2048 && n.update.call(
        null,
        /*styles*/
        o[11]
      ), u[0] & /*align, size, placeholder*/
      16418 && r(
        e,
        "placeholder",
        /*placeholder*/
        o[14]
      ), u[0] & /*align, size, bold*/
      38 && r(
        e,
        "bold",
        /*bold*/
        o[2]
      ), u[0] & /*align, size, italic*/
      42 && r(
        e,
        "italic",
        /*italic*/
        o[3]
      ), u[0] & /*align, size, underline*/
      50 && r(
        e,
        "underline",
        /*underline*/
        o[4]
      );
    },
    d(o) {
      o && g(e), i = !1, K(s);
    }
  };
}
function re(l) {
  let e;
  function t(i, s) {
    if (
      /*$component*/
      i[8].editing
    )
      return oe;
    if (
      /*$builderStore*/
      i[9].inBuilder || /*componentText*/
      i[13]
    )
      return fe;
  }
  let f = t(l), n = f && f(l);
  return {
    c() {
      n && n.c(), e = w();
    },
    m(i, s) {
      n && n.m(i, s), m(i, e, s);
    },
    p(i, s) {
      f === (f = t(i)) && n ? n.p(i, s) : (n && n.d(1), n = f && f(i), n && (n.c(), n.m(e.parentNode, e)));
    },
    i: E,
    o: E,
    d(i) {
      i && g(e), n && n.d(i);
    }
  };
}
function de(l, e, t) {
  let f, n, i, s, o, u, k, z;
  const { linkable: Q, styleable: R, builderStore: M, sidePanelStore: V, modalStore: X } = F("sdk");
  G(l, M, (a) => t(9, z = a));
  const U = F("component");
  G(l, U, (a) => t(8, k = a));
  let { url: c } = e, { text: p } = e, { openInNewTab: h } = e, { color: C } = e, { align: L } = e, { bold: j } = e, { italic: W } = e, { underline: A } = e, { size: D } = e, b, q = !1;
  const Y = () => {
    V.actions.close(), X.actions.close();
  }, Z = (a, _, N) => a ? _ ? a : h ? `#${a}` : a : _ || N ? "#/" : "/", v = (a, _, N) => !_.inBuilder || N.editing ? a || "" : a || N.name || "Placeholder text", x = (a, _) => _ ? {
    ...a,
    normal: { ...a == null ? void 0 : a.normal, color: _ }
  } : a, $ = (a) => {
    q && M.actions.updateProp("text", a.target.textContent), t(10, q = !1);
  };
  function ee(a) {
    te[a ? "unshift" : "push"](() => {
      b = a, t(6, b);
    });
  }
  const le = () => t(10, q = !0);
  return l.$$set = (a) => {
    "url" in a && t(22, c = a.url), "text" in a && t(23, p = a.text), "openInNewTab" in a && t(0, h = a.openInNewTab), "color" in a && t(24, C = a.color), "align" in a && t(1, L = a.align), "bold" in a && t(2, j = a.bold), "italic" in a && t(3, W = a.italic), "underline" in a && t(4, A = a.underline), "size" in a && t(5, D = a.size);
  }, l.$$.update = () => {
    l.$$.dirty[0] & /*$component, node*/
    320 && k.editing && (b == null || b.focus()), l.$$.dirty[0] & /*url*/
    4194304 && t(7, f = c && typeof c == "string" && !c.startsWith("/")), l.$$.dirty[0] & /*openInNewTab*/
    1 && t(15, n = h ? "_blank" : "_self"), l.$$.dirty[0] & /*$builderStore, text*/
    8389120 && t(14, i = z.inBuilder && !p), l.$$.dirty[0] & /*text, $builderStore, $component*/
    8389376 && t(13, s = v(p, z, k)), l.$$.dirty[0] & /*url, externalLink, openInNewTab*/
    4194433 && t(12, o = Z(c, f, h)), l.$$.dirty[0] & /*$component, color*/
    16777472 && t(11, u = x(k.styles, C));
  }, [
    h,
    L,
    j,
    W,
    A,
    D,
    b,
    f,
    k,
    z,
    q,
    u,
    o,
    s,
    i,
    n,
    Q,
    R,
    M,
    U,
    Y,
    $,
    c,
    p,
    C,
    ee,
    le
  ];
}
class ce extends ne {
  constructor(e) {
    super(), ie(
      this,
      e,
      de,
      re,
      J,
      {
        url: 22,
        text: 23,
        openInNewTab: 0,
        color: 24,
        align: 1,
        bold: 2,
        italic: 3,
        underline: 4,
        size: 5
      },
      null,
      [-1, -1]
    );
  }
}
export {
  ce as default
};
