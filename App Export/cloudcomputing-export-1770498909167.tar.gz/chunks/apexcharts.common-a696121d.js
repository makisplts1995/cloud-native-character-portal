import { R as Kt } from "./index-e79f0bb2.js";
var Ge = { exports: {} };
/*!
 * ApexCharts v3.54.1
 * (c) 2018-2024 ApexCharts
 * Released under the MIT License.
 */
(function(Ve, pt) {
  function Te(y, e) {
    (e == null || e > y.length) && (e = y.length);
    for (var t = 0, i = Array(e); t < e; t++)
      i[t] = y[t];
    return i;
  }
  function je(y) {
    if (y === void 0)
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return y;
  }
  function R(y, e) {
    if (!(y instanceof e))
      throw new TypeError("Cannot call a class as a function");
  }
  function _e(y, e) {
    for (var t = 0; t < e.length; t++) {
      var i = e[t];
      i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(y, $e(i.key), i);
    }
  }
  function F(y, e, t) {
    return e && _e(y.prototype, e), t && _e(y, t), Object.defineProperty(y, "prototype", { writable: !1 }), y;
  }
  function Ae(y, e) {
    var t = typeof Symbol < "u" && y[Symbol.iterator] || y["@@iterator"];
    if (!t) {
      if (Array.isArray(y) || (t = Xe(y)) || e && y && typeof y.length == "number") {
        t && (y = t);
        var i = 0, a = function() {
        };
        return { s: a, n: function() {
          return i >= y.length ? { done: !0 } : { done: !1, value: y[i++] };
        }, e: function(o) {
          throw o;
        }, f: a };
      }
      throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
    }
    var r, s = !0, n = !1;
    return { s: function() {
      t = t.call(y);
    }, n: function() {
      var o = t.next();
      return s = o.done, o;
    }, e: function(o) {
      n = !0, r = o;
    }, f: function() {
      try {
        s || t.return == null || t.return();
      } finally {
        if (n)
          throw r;
      }
    } };
  }
  function xe(y) {
    var e = Ue();
    return function() {
      var t, i = Ce(y);
      if (e) {
        var a = Ce(this).constructor;
        t = Reflect.construct(i, arguments, a);
      } else
        t = i.apply(this, arguments);
      return function(r, s) {
        if (s && (typeof s == "object" || typeof s == "function"))
          return s;
        if (s !== void 0)
          throw new TypeError("Derived constructors may only return object or undefined");
        return je(r);
      }(this, t);
    };
  }
  function Se(y, e, t) {
    return (e = $e(e)) in y ? Object.defineProperty(y, e, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : y[e] = t, y;
  }
  function Ce(y) {
    return Ce = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
      return e.__proto__ || Object.getPrototypeOf(e);
    }, Ce(y);
  }
  function be(y, e) {
    if (typeof e != "function" && e !== null)
      throw new TypeError("Super expression must either be null or a function");
    y.prototype = Object.create(e && e.prototype, { constructor: { value: y, writable: !0, configurable: !0 } }), Object.defineProperty(y, "prototype", { writable: !1 }), e && ze(y, e);
  }
  function Ue() {
    try {
      var y = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
      }));
    } catch {
    }
    return (Ue = function() {
      return !!y;
    })();
  }
  function qe(y, e) {
    var t = Object.keys(y);
    if (Object.getOwnPropertySymbols) {
      var i = Object.getOwnPropertySymbols(y);
      e && (i = i.filter(function(a) {
        return Object.getOwnPropertyDescriptor(y, a).enumerable;
      })), t.push.apply(t, i);
    }
    return t;
  }
  function E(y) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e] != null ? arguments[e] : {};
      e % 2 ? qe(Object(t), !0).forEach(function(i) {
        Se(y, i, t[i]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(y, Object.getOwnPropertyDescriptors(t)) : qe(Object(t)).forEach(function(i) {
        Object.defineProperty(y, i, Object.getOwnPropertyDescriptor(t, i));
      });
    }
    return y;
  }
  function ze(y, e) {
    return ze = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, i) {
      return t.__proto__ = i, t;
    }, ze(y, e);
  }
  function Ze(y, e) {
    return function(t) {
      if (Array.isArray(t))
        return t;
    }(y) || function(t, i) {
      var a = t == null ? null : typeof Symbol < "u" && t[Symbol.iterator] || t["@@iterator"];
      if (a != null) {
        var r, s, n, o, h = [], d = !0, c = !1;
        try {
          if (n = (a = a.call(t)).next, i === 0) {
            if (Object(a) !== a)
              return;
            d = !1;
          } else
            for (; !(d = (r = n.call(a)).done) && (h.push(r.value), h.length !== i); d = !0)
              ;
        } catch (g) {
          c = !0, s = g;
        } finally {
          try {
            if (!d && a.return != null && (o = a.return(), Object(o) !== o))
              return;
          } finally {
            if (c)
              throw s;
          }
        }
        return h;
      }
    }(y, e) || Xe(y, e) || function() {
      throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
    }();
  }
  function J(y) {
    return function(e) {
      if (Array.isArray(e))
        return Te(e);
    }(y) || function(e) {
      if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null)
        return Array.from(e);
    }(y) || Xe(y) || function() {
      throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
    }();
  }
  function $e(y) {
    var e = function(t, i) {
      if (typeof t != "object" || !t)
        return t;
      var a = t[Symbol.toPrimitive];
      if (a !== void 0) {
        var r = a.call(t, i || "default");
        if (typeof r != "object")
          return r;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return (i === "string" ? String : Number)(t);
    }(y, "string");
    return typeof e == "symbol" ? e : e + "";
  }
  function Q(y) {
    return Q = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
      return typeof e;
    } : function(e) {
      return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
    }, Q(y);
  }
  function Xe(y, e) {
    if (y) {
      if (typeof y == "string")
        return Te(y, e);
      var t = {}.toString.call(y).slice(8, -1);
      return t === "Object" && y.constructor && (t = y.constructor.name), t === "Map" || t === "Set" ? Array.from(y) : t === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? Te(y, e) : void 0;
    }
  }
  var P = function() {
    function y() {
      R(this, y);
    }
    return F(y, [{ key: "shadeRGBColor", value: function(e, t) {
      var i = t.split(","), a = e < 0 ? 0 : 255, r = e < 0 ? -1 * e : e, s = parseInt(i[0].slice(4), 10), n = parseInt(i[1], 10), o = parseInt(i[2], 10);
      return "rgb(" + (Math.round((a - s) * r) + s) + "," + (Math.round((a - n) * r) + n) + "," + (Math.round((a - o) * r) + o) + ")";
    } }, { key: "shadeHexColor", value: function(e, t) {
      var i = parseInt(t.slice(1), 16), a = e < 0 ? 0 : 255, r = e < 0 ? -1 * e : e, s = i >> 16, n = i >> 8 & 255, o = 255 & i;
      return "#" + (16777216 + 65536 * (Math.round((a - s) * r) + s) + 256 * (Math.round((a - n) * r) + n) + (Math.round((a - o) * r) + o)).toString(16).slice(1);
    } }, { key: "shadeColor", value: function(e, t) {
      return y.isColorHex(t) ? this.shadeHexColor(e, t) : this.shadeRGBColor(e, t);
    } }], [{ key: "bind", value: function(e, t) {
      return function() {
        return e.apply(t, arguments);
      };
    } }, { key: "isObject", value: function(e) {
      return e && Q(e) === "object" && !Array.isArray(e) && e != null;
    } }, { key: "is", value: function(e, t) {
      return Object.prototype.toString.call(t) === "[object " + e + "]";
    } }, { key: "listToArray", value: function(e) {
      var t, i = [];
      for (t = 0; t < e.length; t++)
        i[t] = e[t];
      return i;
    } }, { key: "extend", value: function(e, t) {
      var i = this;
      typeof Object.assign != "function" && (Object.assign = function(r) {
        if (r == null)
          throw new TypeError("Cannot convert undefined or null to object");
        for (var s = Object(r), n = 1; n < arguments.length; n++) {
          var o = arguments[n];
          if (o != null)
            for (var h in o)
              o.hasOwnProperty(h) && (s[h] = o[h]);
        }
        return s;
      });
      var a = Object.assign({}, e);
      return this.isObject(e) && this.isObject(t) && Object.keys(t).forEach(function(r) {
        i.isObject(t[r]) && r in e ? a[r] = i.extend(e[r], t[r]) : Object.assign(a, Se({}, r, t[r]));
      }), a;
    } }, { key: "extendArray", value: function(e, t) {
      var i = [];
      return e.map(function(a) {
        i.push(y.extend(t, a));
      }), e = i;
    } }, { key: "monthMod", value: function(e) {
      return e % 12;
    } }, { key: "clone", value: function(e) {
      if (y.is("Array", e)) {
        for (var t = [], i = 0; i < e.length; i++)
          t[i] = this.clone(e[i]);
        return t;
      }
      if (y.is("Null", e))
        return null;
      if (y.is("Date", e))
        return e;
      if (Q(e) === "object") {
        var a = {};
        for (var r in e)
          e.hasOwnProperty(r) && (a[r] = this.clone(e[r]));
        return a;
      }
      return e;
    } }, { key: "log10", value: function(e) {
      return Math.log(e) / Math.LN10;
    } }, { key: "roundToBase10", value: function(e) {
      return Math.pow(10, Math.floor(Math.log10(e)));
    } }, { key: "roundToBase", value: function(e, t) {
      return Math.pow(t, Math.floor(Math.log(e) / Math.log(t)));
    } }, { key: "parseNumber", value: function(e) {
      return e === null ? e : parseFloat(e);
    } }, { key: "stripNumber", value: function(e) {
      var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 2;
      return Number.isInteger(e) ? e : parseFloat(e.toPrecision(t));
    } }, { key: "randomId", value: function() {
      return (Math.random() + 1).toString(36).substring(4);
    } }, { key: "noExponents", value: function(e) {
      var t = String(e).split(/[eE]/);
      if (t.length === 1)
        return t[0];
      var i = "", a = e < 0 ? "-" : "", r = t[0].replace(".", ""), s = Number(t[1]) + 1;
      if (s < 0) {
        for (i = a + "0."; s++; )
          i += "0";
        return i + r.replace(/^-/, "");
      }
      for (s -= r.length; s--; )
        i += "0";
      return r + i;
    } }, { key: "getDimensions", value: function(e) {
      var t = getComputedStyle(e, null), i = e.clientHeight, a = e.clientWidth;
      return i -= parseFloat(t.paddingTop) + parseFloat(t.paddingBottom), [a -= parseFloat(t.paddingLeft) + parseFloat(t.paddingRight), i];
    } }, { key: "getBoundingClientRect", value: function(e) {
      var t = e.getBoundingClientRect();
      return { top: t.top, right: t.right, bottom: t.bottom, left: t.left, width: e.clientWidth, height: e.clientHeight, x: t.left, y: t.top };
    } }, { key: "getLargestStringFromArr", value: function(e) {
      return e.reduce(function(t, i) {
        return Array.isArray(i) && (i = i.reduce(function(a, r) {
          return a.length > r.length ? a : r;
        })), t.length > i.length ? t : i;
      }, 0);
    } }, { key: "hexToRgba", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "#999999", t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0.6;
      e.substring(0, 1) !== "#" && (e = "#999999");
      var i = e.replace("#", "");
      i = i.match(new RegExp("(.{" + i.length / 3 + "})", "g"));
      for (var a = 0; a < i.length; a++)
        i[a] = parseInt(i[a].length === 1 ? i[a] + i[a] : i[a], 16);
      return t !== void 0 && i.push(t), "rgba(" + i.join(",") + ")";
    } }, { key: "getOpacityFromRGBA", value: function(e) {
      return parseFloat(e.replace(/^.*,(.+)\)/, "$1"));
    } }, { key: "rgb2hex", value: function(e) {
      return (e = e.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i)) && e.length === 4 ? "#" + ("0" + parseInt(e[1], 10).toString(16)).slice(-2) + ("0" + parseInt(e[2], 10).toString(16)).slice(-2) + ("0" + parseInt(e[3], 10).toString(16)).slice(-2) : "";
    } }, { key: "isColorHex", value: function(e) {
      return /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)|(^#[0-9A-F]{8}$)/i.test(e);
    } }, { key: "getPolygonPos", value: function(e, t) {
      for (var i = [], a = 2 * Math.PI / t, r = 0; r < t; r++) {
        var s = {};
        s.x = e * Math.sin(r * a), s.y = -e * Math.cos(r * a), i.push(s);
      }
      return i;
    } }, { key: "polarToCartesian", value: function(e, t, i, a) {
      var r = (a - 90) * Math.PI / 180;
      return { x: e + i * Math.cos(r), y: t + i * Math.sin(r) };
    } }, { key: "escapeString", value: function(e) {
      var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "x", i = e.toString().slice();
      return i = i.replace(/[` ~!@#$%^&*()|+\=?;:'",.<>{}[\]\\/]/gi, t);
    } }, { key: "negToZero", value: function(e) {
      return e < 0 ? 0 : e;
    } }, { key: "moveIndexInArray", value: function(e, t, i) {
      if (i >= e.length)
        for (var a = i - e.length + 1; a--; )
          e.push(void 0);
      return e.splice(i, 0, e.splice(t, 1)[0]), e;
    } }, { key: "extractNumber", value: function(e) {
      return parseFloat(e.replace(/[^\d.]*/g, ""));
    } }, { key: "findAncestor", value: function(e, t) {
      for (; (e = e.parentElement) && !e.classList.contains(t); )
        ;
      return e;
    } }, { key: "setELstyles", value: function(e, t) {
      for (var i in t)
        t.hasOwnProperty(i) && (e.style.key = t[i]);
    } }, { key: "preciseAddition", value: function(e, t) {
      var i = (String(e).split(".")[1] || "").length, a = (String(t).split(".")[1] || "").length, r = Math.pow(10, Math.max(i, a));
      return (Math.round(e * r) + Math.round(t * r)) / r;
    } }, { key: "isNumber", value: function(e) {
      return !isNaN(e) && parseFloat(Number(e)) === e && !isNaN(parseInt(e, 10));
    } }, { key: "isFloat", value: function(e) {
      return Number(e) === e && e % 1 != 0;
    } }, { key: "isSafari", value: function() {
      return /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
    } }, { key: "isFirefox", value: function() {
      return navigator.userAgent.toLowerCase().indexOf("firefox") > -1;
    } }, { key: "isMsEdge", value: function() {
      var e = window.navigator.userAgent, t = e.indexOf("Edge/");
      return t > 0 && parseInt(e.substring(t + 5, e.indexOf(".", t)), 10);
    } }, { key: "getGCD", value: function(e, t) {
      var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 7, a = Math.pow(10, i - Math.floor(Math.log10(Math.max(e, t))));
      for (e = Math.round(Math.abs(e) * a), t = Math.round(Math.abs(t) * a); t; ) {
        var r = t;
        t = e % t, e = r;
      }
      return e / a;
    } }, { key: "getPrimeFactors", value: function(e) {
      for (var t = [], i = 2; e >= 2; )
        e % i == 0 ? (t.push(i), e /= i) : i++;
      return t;
    } }, { key: "mod", value: function(e, t) {
      var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 7, a = Math.pow(10, i - Math.floor(Math.log10(Math.max(e, t))));
      return (e = Math.round(Math.abs(e) * a)) % (t = Math.round(Math.abs(t) * a)) / a;
    } }]), y;
  }(), ge = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.setEasingFunctions();
    }
    return F(y, [{ key: "setEasingFunctions", value: function() {
      var e;
      if (!this.w.globals.easing) {
        switch (this.w.config.chart.animations.easing) {
          case "linear":
            e = "-";
            break;
          case "easein":
            e = "<";
            break;
          case "easeout":
            e = ">";
            break;
          case "easeinout":
          default:
            e = "<>";
            break;
          case "swing":
            e = function(t) {
              var i = 1.70158;
              return (t -= 1) * t * ((i + 1) * t + i) + 1;
            };
            break;
          case "bounce":
            e = function(t) {
              return t < 1 / 2.75 ? 7.5625 * t * t : t < 2 / 2.75 ? 7.5625 * (t -= 1.5 / 2.75) * t + 0.75 : t < 2.5 / 2.75 ? 7.5625 * (t -= 2.25 / 2.75) * t + 0.9375 : 7.5625 * (t -= 2.625 / 2.75) * t + 0.984375;
            };
            break;
          case "elastic":
            e = function(t) {
              return t === !!t ? t : Math.pow(2, -10 * t) * Math.sin((t - 0.075) * (2 * Math.PI) / 0.3) + 1;
            };
        }
        this.w.globals.easing = e;
      }
    } }, { key: "animateLine", value: function(e, t, i, a) {
      e.attr(t).animate(a).attr(i);
    } }, { key: "animateMarker", value: function(e, t, i, a) {
      e.attr({ opacity: 0 }).animate(t, i).attr({ opacity: 1 }).afterAll(function() {
        a();
      });
    } }, { key: "animateRect", value: function(e, t, i, a, r) {
      e.attr(t).animate(a).attr(i).afterAll(function() {
        return r();
      });
    } }, { key: "animatePathsGradually", value: function(e) {
      var t = e.el, i = e.realIndex, a = e.j, r = e.fill, s = e.pathFrom, n = e.pathTo, o = e.speed, h = e.delay, d = this.w, c = 0;
      d.config.chart.animations.animateGradually.enabled && (c = d.config.chart.animations.animateGradually.delay), d.config.chart.animations.dynamicAnimation.enabled && d.globals.dataChanged && d.config.chart.type !== "bar" && (c = 0), this.morphSVG(t, i, a, d.config.chart.type !== "line" || d.globals.comboCharts ? r : "stroke", s, n, o, h * c);
    } }, { key: "showDelayedElements", value: function() {
      this.w.globals.delayedElements.forEach(function(e) {
        var t = e.el;
        t.classList.remove("apexcharts-element-hidden"), t.classList.add("apexcharts-hidden-element-shown");
      });
    } }, { key: "animationCompleted", value: function(e) {
      var t = this.w;
      t.globals.animationEnded || (t.globals.animationEnded = !0, this.showDelayedElements(), typeof t.config.chart.events.animationEnd == "function" && t.config.chart.events.animationEnd(this.ctx, { el: e, w: t }));
    } }, { key: "morphSVG", value: function(e, t, i, a, r, s, n, o) {
      var h = this, d = this.w;
      r || (r = e.attr("pathFrom")), s || (s = e.attr("pathTo"));
      var c = function(g) {
        return d.config.chart.type === "radar" && (n = 1), "M 0 ".concat(d.globals.gridHeight);
      };
      (!r || r.indexOf("undefined") > -1 || r.indexOf("NaN") > -1) && (r = c()), (!s || s.indexOf("undefined") > -1 || s.indexOf("NaN") > -1) && (s = c()), d.globals.shouldAnimate || (n = 1), e.plot(r).animate(1, d.globals.easing, o).plot(r).animate(n, d.globals.easing, o).plot(s).afterAll(function() {
        P.isNumber(i) ? i === d.globals.series[d.globals.maxValsInArrayIndex].length - 2 && d.globals.shouldAnimate && h.animationCompleted(e) : a !== "none" && d.globals.shouldAnimate && (!d.globals.comboCharts && t === d.globals.series.length - 1 || d.globals.comboCharts) && h.animationCompleted(e), h.showDelayedElements();
      });
    } }]), y;
  }(), ee = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "getDefaultFilter", value: function(e, t) {
      var i = this.w;
      e.unfilter(!0), new window.SVG.Filter().size("120%", "180%", "-5%", "-40%"), i.config.states.normal.filter !== "none" ? this.applyFilter(e, t, i.config.states.normal.filter.type, i.config.states.normal.filter.value) : i.config.chart.dropShadow.enabled && this.dropShadow(e, i.config.chart.dropShadow, t);
    } }, { key: "addNormalFilter", value: function(e, t) {
      var i = this.w;
      i.config.chart.dropShadow.enabled && !e.node.classList.contains("apexcharts-marker") && this.dropShadow(e, i.config.chart.dropShadow, t);
    } }, { key: "addLightenFilter", value: function(e, t, i) {
      var a = this, r = this.w, s = i.intensity;
      e.unfilter(!0), new window.SVG.Filter(), e.filter(function(n) {
        var o = r.config.chart.dropShadow;
        (o.enabled ? a.addShadow(n, t, o) : n).componentTransfer({ rgb: { type: "linear", slope: 1.5, intercept: s } });
      }), e.filterer.node.setAttribute("filterUnits", "userSpaceOnUse"), this._scaleFilterSize(e.filterer.node);
    } }, { key: "addDarkenFilter", value: function(e, t, i) {
      var a = this, r = this.w, s = i.intensity;
      e.unfilter(!0), new window.SVG.Filter(), e.filter(function(n) {
        var o = r.config.chart.dropShadow;
        (o.enabled ? a.addShadow(n, t, o) : n).componentTransfer({ rgb: { type: "linear", slope: s } });
      }), e.filterer.node.setAttribute("filterUnits", "userSpaceOnUse"), this._scaleFilterSize(e.filterer.node);
    } }, { key: "applyFilter", value: function(e, t, i) {
      var a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : 0.5;
      switch (i) {
        case "none":
          this.addNormalFilter(e, t);
          break;
        case "lighten":
          this.addLightenFilter(e, t, { intensity: a });
          break;
        case "darken":
          this.addDarkenFilter(e, t, { intensity: a });
      }
    } }, { key: "addShadow", value: function(e, t, i) {
      var a, r = this.w, s = i.blur, n = i.top, o = i.left, h = i.color, d = i.opacity;
      if (((a = r.config.chart.dropShadow.enabledOnSeries) === null || a === void 0 ? void 0 : a.length) > 0 && r.config.chart.dropShadow.enabledOnSeries.indexOf(t) === -1)
        return e;
      var c = e.flood(Array.isArray(h) ? h[t] : h, d).composite(e.sourceAlpha, "in").offset(o, n).gaussianBlur(s).merge(e.source);
      return e.blend(e.source, c);
    } }, { key: "dropShadow", value: function(e, t) {
      var i, a, r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0, s = t.top, n = t.left, o = t.blur, h = t.color, d = t.opacity, c = t.noUserSpaceOnUse, g = this.w;
      return e.unfilter(!0), P.isMsEdge() && g.config.chart.type === "radialBar" || ((i = g.config.chart.dropShadow.enabledOnSeries) === null || i === void 0 ? void 0 : i.length) > 0 && ((a = g.config.chart.dropShadow.enabledOnSeries) === null || a === void 0 ? void 0 : a.indexOf(r)) === -1 || (h = Array.isArray(h) ? h[r] : h, e.filter(function(p) {
        var x = null;
        x = P.isSafari() || P.isFirefox() || P.isMsEdge() ? p.flood(h, d).composite(p.sourceAlpha, "in").offset(n, s).gaussianBlur(o) : p.flood(h, d).composite(p.sourceAlpha, "in").offset(n, s).gaussianBlur(o).merge(p.source), p.blend(p.source, x);
      }), c || e.filterer.node.setAttribute("filterUnits", "userSpaceOnUse"), this._scaleFilterSize(e.filterer.node)), e;
    } }, { key: "setSelectionFilter", value: function(e, t, i) {
      var a = this.w;
      if (a.globals.selectedDataPoints[t] !== void 0 && a.globals.selectedDataPoints[t].indexOf(i) > -1) {
        e.node.setAttribute("selected", !0);
        var r = a.config.states.active.filter;
        r !== "none" && this.applyFilter(e, t, r.type, r.value);
      }
    } }, { key: "_scaleFilterSize", value: function(e) {
      (function(t) {
        for (var i in t)
          t.hasOwnProperty(i) && e.setAttribute(i, t[i]);
      })({ width: "200%", height: "200%", x: "-50%", y: "-50%" });
    } }]), y;
  }(), X = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "roundPathCorners", value: function(e, t) {
      function i(S, C, L) {
        var M = C.x - S.x, T = C.y - S.y, I = Math.sqrt(M * M + T * T);
        return a(S, C, Math.min(1, L / I));
      }
      function a(S, C, L) {
        return { x: S.x + (C.x - S.x) * L, y: S.y + (C.y - S.y) * L };
      }
      function r(S, C) {
        S.length > 2 && (S[S.length - 2] = C.x, S[S.length - 1] = C.y);
      }
      function s(S) {
        return { x: parseFloat(S[S.length - 2]), y: parseFloat(S[S.length - 1]) };
      }
      e.indexOf("NaN") > -1 && (e = "");
      var n = e.split(/[,\s]/).reduce(function(S, C) {
        var L = C.match("([a-zA-Z])(.+)");
        return L ? (S.push(L[1]), S.push(L[2])) : S.push(C), S;
      }, []).reduce(function(S, C) {
        return parseFloat(C) == C && S.length ? S[S.length - 1].push(C) : S.push([C]), S;
      }, []), o = [];
      if (n.length > 1) {
        var h = s(n[0]), d = null;
        n[n.length - 1][0] == "Z" && n[0].length > 2 && (d = ["L", h.x, h.y], n[n.length - 1] = d), o.push(n[0]);
        for (var c = 1; c < n.length; c++) {
          var g = o[o.length - 1], p = n[c], x = p == d ? n[1] : n[c + 1];
          if (x && g && g.length > 2 && p[0] == "L" && x.length > 2 && x[0] == "L") {
            var f, m, v = s(g), w = s(p), l = s(x);
            f = i(w, v, t), m = i(w, l, t), r(p, f), p.origPoint = w, o.push(p);
            var u = a(f, w, 0.5), b = a(w, m, 0.5), A = ["C", u.x, u.y, b.x, b.y, m.x, m.y];
            A.origPoint = w, o.push(A);
          } else
            o.push(p);
        }
        if (d) {
          var k = s(o[o.length - 1]);
          o.push(["Z"]), r(o[0], k);
        }
      } else
        o = n;
      return o.reduce(function(S, C) {
        return S + C.join(" ") + " ";
      }, "");
    } }, { key: "drawLine", value: function(e, t, i, a) {
      var r = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : "#a8a8a8", s = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : 0, n = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : null, o = arguments.length > 7 && arguments[7] !== void 0 ? arguments[7] : "butt";
      return this.w.globals.dom.Paper.line().attr({ x1: e, y1: t, x2: i, y2: a, stroke: r, "stroke-dasharray": s, "stroke-width": n, "stroke-linecap": o });
    } }, { key: "drawRect", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : 0, r = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : 0, s = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : "#fefefe", n = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : 1, o = arguments.length > 7 && arguments[7] !== void 0 ? arguments[7] : null, h = arguments.length > 8 && arguments[8] !== void 0 ? arguments[8] : null, d = arguments.length > 9 && arguments[9] !== void 0 ? arguments[9] : 0, c = this.w.globals.dom.Paper.rect();
      return c.attr({ x: e, y: t, width: i > 0 ? i : 0, height: a > 0 ? a : 0, rx: r, ry: r, opacity: n, "stroke-width": o !== null ? o : 0, stroke: h !== null ? h : "none", "stroke-dasharray": d }), c.node.setAttribute("fill", s), c;
    } }, { key: "drawPolygon", value: function(e) {
      var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "#e1e1e1", i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "none";
      return this.w.globals.dom.Paper.polygon(e).attr({ fill: a, stroke: t, "stroke-width": i });
    } }, { key: "drawCircle", value: function(e) {
      var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
      e < 0 && (e = 0);
      var i = this.w.globals.dom.Paper.circle(2 * e);
      return t !== null && i.attr(t), i;
    } }, { key: "drawPath", value: function(e) {
      var t = e.d, i = t === void 0 ? "" : t, a = e.stroke, r = a === void 0 ? "#a8a8a8" : a, s = e.strokeWidth, n = s === void 0 ? 1 : s, o = e.fill, h = e.fillOpacity, d = h === void 0 ? 1 : h, c = e.strokeOpacity, g = c === void 0 ? 1 : c, p = e.classes, x = e.strokeLinecap, f = x === void 0 ? null : x, m = e.strokeDashArray, v = m === void 0 ? 0 : m, w = this.w;
      return f === null && (f = w.config.stroke.lineCap), (i.indexOf("undefined") > -1 || i.indexOf("NaN") > -1) && (i = "M 0 ".concat(w.globals.gridHeight)), w.globals.dom.Paper.path(i).attr({ fill: o, "fill-opacity": d, stroke: r, "stroke-opacity": g, "stroke-linecap": f, "stroke-width": n, "stroke-dasharray": v, class: p });
    } }, { key: "group", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null, t = this.w.globals.dom.Paper.group();
      return e !== null && t.attr(e), t;
    } }, { key: "move", value: function(e, t) {
      var i = ["M", e, t].join(" ");
      return i;
    } }, { key: "line", value: function(e, t) {
      var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null, a = null;
      return i === null ? a = [" L", e, t].join(" ") : i === "H" ? a = [" H", e].join(" ") : i === "V" && (a = [" V", t].join(" ")), a;
    } }, { key: "curve", value: function(e, t, i, a, r, s) {
      var n = ["C", e, t, i, a, r, s].join(" ");
      return n;
    } }, { key: "quadraticCurve", value: function(e, t, i, a) {
      return ["Q", e, t, i, a].join(" ");
    } }, { key: "arc", value: function(e, t, i, a, r, s, n) {
      var o = "A";
      arguments.length > 7 && arguments[7] !== void 0 && arguments[7] && (o = "a");
      var h = [o, e, t, i, a, r, s, n].join(" ");
      return h;
    } }, { key: "renderPaths", value: function(e) {
      var t, i = e.j, a = e.realIndex, r = e.pathFrom, s = e.pathTo, n = e.stroke, o = e.strokeWidth, h = e.strokeLinecap, d = e.fill, c = e.animationDelay, g = e.initialSpeed, p = e.dataChangeSpeed, x = e.className, f = e.chartType, m = e.shouldClipToGrid, v = m === void 0 || m, w = e.bindEventsOnPaths, l = w === void 0 || w, u = e.drawShadow, b = u === void 0 || u, A = this.w, k = new ee(this.ctx), S = new ge(this.ctx), C = this.w.config.chart.animations.enabled, L = C && this.w.config.chart.animations.dynamicAnimation.enabled, M = !!(C && !A.globals.resized || L && A.globals.dataChanged && A.globals.shouldAnimate);
      M ? t = r : (t = s, A.globals.animationEnded = !0);
      var T = A.config.stroke.dashArray, I = 0;
      I = Array.isArray(T) ? T[a] : A.config.stroke.dashArray;
      var z = this.drawPath({ d: t, stroke: n, strokeWidth: o, fill: d, fillOpacity: 1, classes: x, strokeLinecap: h, strokeDashArray: I });
      if (z.attr("index", a), v && (f === "bar" && !A.globals.isHorizontal || A.globals.comboCharts ? z.attr({ "clip-path": "url(#gridRectBarMask".concat(A.globals.cuid, ")") }) : z.attr({ "clip-path": "url(#gridRectMask".concat(A.globals.cuid, ")") })), A.config.states.normal.filter.type !== "none")
        k.getDefaultFilter(z, a);
      else if (A.config.chart.dropShadow.enabled && b) {
        var Y = A.config.chart.dropShadow;
        k.dropShadow(z, Y, a);
      }
      l && (z.node.addEventListener("mouseenter", this.pathMouseEnter.bind(this, z)), z.node.addEventListener("mouseleave", this.pathMouseLeave.bind(this, z)), z.node.addEventListener("mousedown", this.pathMouseDown.bind(this, z))), z.attr({ pathTo: s, pathFrom: r });
      var D = { el: z, j: i, realIndex: a, pathFrom: r, pathTo: s, fill: d, strokeWidth: o, delay: c };
      return !C || A.globals.resized || A.globals.dataChanged ? !A.globals.resized && A.globals.dataChanged || S.showDelayedElements() : S.animatePathsGradually(E(E({}, D), {}, { speed: g })), A.globals.dataChanged && L && M && S.animatePathsGradually(E(E({}, D), {}, { speed: p })), z;
    } }, { key: "drawPattern", value: function(e, t, i) {
      var a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "#a8a8a8", r = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : 0;
      return this.w.globals.dom.Paper.pattern(t, i, function(s) {
        e === "horizontalLines" ? s.line(0, 0, i, 0).stroke({ color: a, width: r + 1 }) : e === "verticalLines" ? s.line(0, 0, 0, t).stroke({ color: a, width: r + 1 }) : e === "slantedLines" ? s.line(0, 0, t, i).stroke({ color: a, width: r }) : e === "squares" ? s.rect(t, i).fill("none").stroke({ color: a, width: r }) : e === "circles" && s.circle(t).fill("none").stroke({ color: a, width: r });
      });
    } }, { key: "drawGradient", value: function(e, t, i, a, r) {
      var s, n = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : null, o = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : null, h = arguments.length > 7 && arguments[7] !== void 0 ? arguments[7] : null, d = arguments.length > 8 && arguments[8] !== void 0 ? arguments[8] : 0, c = this.w;
      t.length < 9 && t.indexOf("#") === 0 && (t = P.hexToRgba(t, a)), i.length < 9 && i.indexOf("#") === 0 && (i = P.hexToRgba(i, r));
      var g = 0, p = 1, x = 1, f = null;
      o !== null && (g = o[0] !== void 0 ? o[0] / 100 : 0, p = o[1] !== void 0 ? o[1] / 100 : 1, x = o[2] !== void 0 ? o[2] / 100 : 1, f = o[3] !== void 0 ? o[3] / 100 : null);
      var m = !(c.config.chart.type !== "donut" && c.config.chart.type !== "pie" && c.config.chart.type !== "polarArea" && c.config.chart.type !== "bubble");
      if (s = h === null || h.length === 0 ? c.globals.dom.Paper.gradient(m ? "radial" : "linear", function(l) {
        l.at(g, t, a), l.at(p, i, r), l.at(x, i, r), f !== null && l.at(f, t, a);
      }) : c.globals.dom.Paper.gradient(m ? "radial" : "linear", function(l) {
        (Array.isArray(h[d]) ? h[d] : h).forEach(function(u) {
          l.at(u.offset / 100, u.color, u.opacity);
        });
      }), m) {
        var v = c.globals.gridWidth / 2, w = c.globals.gridHeight / 2;
        c.config.chart.type !== "bubble" ? s.attr({ gradientUnits: "userSpaceOnUse", cx: v, cy: w, r: n }) : s.attr({ cx: 0.5, cy: 0.5, r: 0.8, fx: 0.2, fy: 0.2 });
      } else
        e === "vertical" ? s.from(0, 0).to(0, 1) : e === "diagonal" ? s.from(0, 0).to(1, 1) : e === "horizontal" ? s.from(0, 1).to(1, 1) : e === "diagonal2" && s.from(1, 0).to(0, 1);
      return s;
    } }, { key: "getTextBasedOnMaxWidth", value: function(e) {
      var t = e.text, i = e.maxWidth, a = e.fontSize, r = e.fontFamily, s = this.getTextRects(t, a, r), n = s.width / t.length, o = Math.floor(i / n);
      return i < s.width ? t.slice(0, o - 3) + "..." : t;
    } }, { key: "drawText", value: function(e) {
      var t = this, i = e.x, a = e.y, r = e.text, s = e.textAnchor, n = e.fontSize, o = e.fontFamily, h = e.fontWeight, d = e.foreColor, c = e.opacity, g = e.maxWidth, p = e.cssClass, x = p === void 0 ? "" : p, f = e.isPlainText, m = f === void 0 || f, v = e.dominantBaseline, w = v === void 0 ? "auto" : v, l = this.w;
      r === void 0 && (r = "");
      var u = r;
      s || (s = "start"), d && d.length || (d = l.config.chart.foreColor), o = o || l.config.chart.fontFamily, h = h || "regular";
      var b, A = { maxWidth: g, fontSize: n = n || "11px", fontFamily: o };
      return Array.isArray(r) ? b = l.globals.dom.Paper.text(function(k) {
        for (var S = 0; S < r.length; S++)
          u = r[S], g && (u = t.getTextBasedOnMaxWidth(E({ text: r[S] }, A))), S === 0 ? k.tspan(u) : k.tspan(u).newLine();
      }) : (g && (u = this.getTextBasedOnMaxWidth(E({ text: r }, A))), b = m ? l.globals.dom.Paper.plain(r) : l.globals.dom.Paper.text(function(k) {
        return k.tspan(u);
      })), b.attr({ x: i, y: a, "text-anchor": s, "dominant-baseline": w, "font-size": n, "font-family": o, "font-weight": h, fill: d, class: "apexcharts-text " + x }), b.node.style.fontFamily = o, b.node.style.opacity = c, b;
    } }, { key: "getMarkerPath", value: function(e, t, i, a) {
      var r = "";
      switch (i) {
        case "cross":
          r = "M ".concat(e - (a /= 1.4), " ").concat(t - a, " L ").concat(e + a, " ").concat(t + a, "  M ").concat(e - a, " ").concat(t + a, " L ").concat(e + a, " ").concat(t - a);
          break;
        case "plus":
          r = "M ".concat(e - (a /= 1.12), " ").concat(t, " L ").concat(e + a, " ").concat(t, "  M ").concat(e, " ").concat(t - a, " L ").concat(e, " ").concat(t + a);
          break;
        case "star":
        case "sparkle":
          var s = 5;
          a *= 1.15, i === "sparkle" && (a /= 1.1, s = 4);
          for (var n = Math.PI / s, o = 0; o <= 2 * s; o++) {
            var h = o * n, d = o % 2 == 0 ? a : a / 2;
            r += (o === 0 ? "M" : "L") + (e + d * Math.sin(h)) + "," + (t - d * Math.cos(h));
          }
          r += "Z";
          break;
        case "triangle":
          r = "M ".concat(e, " ").concat(t - a, ` 
             L `).concat(e + a, " ").concat(t + a, ` 
             L `).concat(e - a, " ").concat(t + a, ` 
             Z`);
          break;
        case "square":
        case "rect":
          r = "M ".concat(e - (a /= 1.125), " ").concat(t - a, ` 
           L `).concat(e + a, " ").concat(t - a, ` 
           L `).concat(e + a, " ").concat(t + a, ` 
           L `).concat(e - a, " ").concat(t + a, ` 
           Z`);
          break;
        case "diamond":
          a *= 1.05, r = "M ".concat(e, " ").concat(t - a, ` 
             L `).concat(e + a, " ").concat(t, ` 
             L `).concat(e, " ").concat(t + a, ` 
             L `).concat(e - a, " ").concat(t, ` 
            Z`);
          break;
        case "line":
          r = "M ".concat(e - (a /= 1.1), " ").concat(t, ` 
           L `).concat(e + a, " ").concat(t);
          break;
        default:
          a *= 2, r = "M ".concat(e, ", ").concat(t, ` 
           m -`).concat(a / 2, `, 0 
           a `).concat(a / 2, ",").concat(a / 2, " 0 1,0 ").concat(a, `,0 
           a `).concat(a / 2, ",").concat(a / 2, " 0 1,0 -").concat(a, ",0");
      }
      return r;
    } }, { key: "drawMarkerShape", value: function(e, t, i, a, r) {
      var s = this.drawPath({ d: this.getMarkerPath(e, t, i, a, r), stroke: r.pointStrokeColor, strokeDashArray: r.pointStrokeDashArray, strokeWidth: r.pointStrokeWidth, fill: r.pointFillColor, fillOpacity: r.pointFillOpacity, strokeOpacity: r.pointStrokeOpacity });
      return s.attr({ cx: e, cy: t, shape: r.shape, class: r.class ? r.class : "" }), s;
    } }, { key: "drawMarker", value: function(e, t, i) {
      e = e || 0;
      var a = i.pSize || 0;
      return P.isNumber(t) || (a = 0, t = 0), this.drawMarkerShape(e, t, i == null ? void 0 : i.shape, a, E(E({}, i), i.shape === "line" || i.shape === "plus" || i.shape === "cross" ? { pointStrokeColor: i.pointFillColor, pointStrokeOpacity: i.pointFillOpacity } : {}));
    } }, { key: "pathMouseEnter", value: function(e, t) {
      var i = this.w, a = new ee(this.ctx), r = parseInt(e.node.getAttribute("index"), 10), s = parseInt(e.node.getAttribute("j"), 10);
      if (typeof i.config.chart.events.dataPointMouseEnter == "function" && i.config.chart.events.dataPointMouseEnter(t, this.ctx, { seriesIndex: r, dataPointIndex: s, w: i }), this.ctx.events.fireEvent("dataPointMouseEnter", [t, this.ctx, { seriesIndex: r, dataPointIndex: s, w: i }]), (i.config.states.active.filter.type === "none" || e.node.getAttribute("selected") !== "true") && i.config.states.hover.filter.type !== "none" && !i.globals.isTouchDevice) {
        var n = i.config.states.hover.filter;
        a.applyFilter(e, r, n.type, n.value);
      }
    } }, { key: "pathMouseLeave", value: function(e, t) {
      var i = this.w, a = new ee(this.ctx), r = parseInt(e.node.getAttribute("index"), 10), s = parseInt(e.node.getAttribute("j"), 10);
      typeof i.config.chart.events.dataPointMouseLeave == "function" && i.config.chart.events.dataPointMouseLeave(t, this.ctx, { seriesIndex: r, dataPointIndex: s, w: i }), this.ctx.events.fireEvent("dataPointMouseLeave", [t, this.ctx, { seriesIndex: r, dataPointIndex: s, w: i }]), i.config.states.active.filter.type !== "none" && e.node.getAttribute("selected") === "true" || i.config.states.hover.filter.type !== "none" && a.getDefaultFilter(e, r);
    } }, { key: "pathMouseDown", value: function(e, t) {
      var i = this.w, a = new ee(this.ctx), r = parseInt(e.node.getAttribute("index"), 10), s = parseInt(e.node.getAttribute("j"), 10), n = "false";
      if (e.node.getAttribute("selected") === "true") {
        if (e.node.setAttribute("selected", "false"), i.globals.selectedDataPoints[r].indexOf(s) > -1) {
          var o = i.globals.selectedDataPoints[r].indexOf(s);
          i.globals.selectedDataPoints[r].splice(o, 1);
        }
      } else {
        if (!i.config.states.active.allowMultipleDataPointsSelection && i.globals.selectedDataPoints.length > 0) {
          i.globals.selectedDataPoints = [];
          var h = i.globals.dom.Paper.select(".apexcharts-series path").members, d = i.globals.dom.Paper.select(".apexcharts-series circle, .apexcharts-series rect").members, c = function(x) {
            Array.prototype.forEach.call(x, function(f) {
              f.node.setAttribute("selected", "false"), a.getDefaultFilter(f, r);
            });
          };
          c(h), c(d);
        }
        e.node.setAttribute("selected", "true"), n = "true", i.globals.selectedDataPoints[r] === void 0 && (i.globals.selectedDataPoints[r] = []), i.globals.selectedDataPoints[r].push(s);
      }
      if (n === "true") {
        var g = i.config.states.active.filter;
        if (g !== "none")
          a.applyFilter(e, r, g.type, g.value);
        else if (i.config.states.hover.filter !== "none" && !i.globals.isTouchDevice) {
          var p = i.config.states.hover.filter;
          a.applyFilter(e, r, p.type, p.value);
        }
      } else
        i.config.states.active.filter.type !== "none" && (i.config.states.hover.filter.type === "none" || i.globals.isTouchDevice ? a.getDefaultFilter(e, r) : (p = i.config.states.hover.filter, a.applyFilter(e, r, p.type, p.value)));
      typeof i.config.chart.events.dataPointSelection == "function" && i.config.chart.events.dataPointSelection(t, this.ctx, { selectedDataPoints: i.globals.selectedDataPoints, seriesIndex: r, dataPointIndex: s, w: i }), t && this.ctx.events.fireEvent("dataPointSelection", [t, this.ctx, { selectedDataPoints: i.globals.selectedDataPoints, seriesIndex: r, dataPointIndex: s, w: i }]);
    } }, { key: "rotateAroundCenter", value: function(e) {
      var t = {};
      return e && typeof e.getBBox == "function" && (t = e.getBBox()), { x: t.x + t.width / 2, y: t.y + t.height / 2 };
    } }, { key: "getTextRects", value: function(e, t, i, a) {
      var r = !(arguments.length > 4 && arguments[4] !== void 0) || arguments[4], s = this.w, n = this.drawText({ x: -200, y: -200, text: e, textAnchor: "start", fontSize: t, fontFamily: i, foreColor: "#fff", opacity: 0 });
      a && n.attr("transform", a), s.globals.dom.Paper.add(n);
      var o = n.bbox();
      return r || (o = n.node.getBoundingClientRect()), n.remove(), { width: o.width, height: o.height };
    } }, { key: "placeTextWithEllipsis", value: function(e, t, i) {
      if (typeof e.getComputedTextLength == "function" && (e.textContent = t, t.length > 0 && e.getComputedTextLength() >= i / 1.1)) {
        for (var a = t.length - 3; a > 0; a -= 3)
          if (e.getSubStringLength(0, a) <= i / 1.1)
            return void (e.textContent = t.substring(0, a) + "...");
        e.textContent = ".";
      }
    } }], [{ key: "setAttrs", value: function(e, t) {
      for (var i in t)
        t.hasOwnProperty(i) && e.setAttribute(i, t[i]);
    } }]), y;
  }(), $ = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "getStackedSeriesTotals", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], t = this.w, i = [];
      if (t.globals.series.length === 0)
        return i;
      for (var a = 0; a < t.globals.series[t.globals.maxValsInArrayIndex].length; a++) {
        for (var r = 0, s = 0; s < t.globals.series.length; s++)
          t.globals.series[s][a] !== void 0 && e.indexOf(s) === -1 && (r += t.globals.series[s][a]);
        i.push(r);
      }
      return i;
    } }, { key: "getSeriesTotalByIndex", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null;
      return e === null ? this.w.config.series.reduce(function(t, i) {
        return t + i;
      }, 0) : this.w.globals.series[e].reduce(function(t, i) {
        return t + i;
      }, 0);
    } }, { key: "getStackedSeriesTotalsByGroups", value: function() {
      var e = this, t = this.w, i = [];
      return t.globals.seriesGroups.forEach(function(a) {
        var r = [];
        t.config.series.forEach(function(n, o) {
          a.indexOf(t.globals.seriesNames[o]) > -1 && r.push(o);
        });
        var s = t.globals.series.map(function(n, o) {
          return r.indexOf(o) === -1 ? o : -1;
        }).filter(function(n) {
          return n !== -1;
        });
        i.push(e.getStackedSeriesTotals(s));
      }), i;
    } }, { key: "setSeriesYAxisMappings", value: function() {
      var e = this.w.globals, t = this.w.config, i = [], a = [], r = [], s = e.series.length > t.yaxis.length || t.yaxis.some(function(c) {
        return Array.isArray(c.seriesName);
      });
      t.series.forEach(function(c, g) {
        r.push(g), a.push(null);
      }), t.yaxis.forEach(function(c, g) {
        i[g] = [];
      });
      var n = [];
      t.yaxis.forEach(function(c, g) {
        var p = !1;
        if (c.seriesName) {
          var x = [];
          Array.isArray(c.seriesName) ? x = c.seriesName : x.push(c.seriesName), x.forEach(function(f) {
            t.series.forEach(function(m, v) {
              if (m.name === f) {
                var w = v;
                g === v || s ? !s || r.indexOf(v) > -1 ? i[g].push([g, v]) : console.warn("Series '" + m.name + "' referenced more than once in what looks like the new style. That is, when using either seriesName: [], or when there are more series than yaxes.") : (i[v].push([v, g]), w = g), p = !0, (w = r.indexOf(w)) !== -1 && r.splice(w, 1);
              }
            });
          });
        }
        p || n.push(g);
      }), i = i.map(function(c, g) {
        var p = [];
        return c.forEach(function(x) {
          a[x[1]] = x[0], p.push(x[1]);
        }), p;
      });
      for (var o = t.yaxis.length - 1, h = 0; h < n.length && (o = n[h], i[o] = [], r); h++) {
        var d = r[0];
        r.shift(), i[o].push(d), a[d] = o;
      }
      r.forEach(function(c) {
        i[o].push(c), a[c] = o;
      }), e.seriesYAxisMap = i.map(function(c) {
        return c;
      }), e.seriesYAxisReverseMap = a.map(function(c) {
        return c;
      }), e.seriesYAxisMap.forEach(function(c, g) {
        c.forEach(function(p) {
          t.series[p] && t.series[p].group === void 0 && (t.series[p].group = "apexcharts-axis-".concat(g.toString()));
        });
      });
    } }, { key: "isSeriesNull", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null;
      return (e === null ? this.w.config.series.filter(function(t) {
        return t !== null;
      }) : this.w.config.series[e].data.filter(function(t) {
        return t !== null;
      })).length === 0;
    } }, { key: "seriesHaveSameValues", value: function(e) {
      return this.w.globals.series[e].every(function(t, i, a) {
        return t === a[0];
      });
    } }, { key: "getCategoryLabels", value: function(e) {
      var t = this.w, i = e.slice();
      return t.config.xaxis.convertedCatToNumeric && (i = e.map(function(a, r) {
        return t.config.xaxis.labels.formatter(a - t.globals.minX + 1);
      })), i;
    } }, { key: "getLargestSeries", value: function() {
      var e = this.w;
      e.globals.maxValsInArrayIndex = e.globals.series.map(function(t) {
        return t.length;
      }).indexOf(Math.max.apply(Math, e.globals.series.map(function(t) {
        return t.length;
      })));
    } }, { key: "getLargestMarkerSize", value: function() {
      var e = this.w, t = 0;
      return e.globals.markers.size.forEach(function(i) {
        t = Math.max(t, i);
      }), e.config.markers.discrete && e.config.markers.discrete.length && e.config.markers.discrete.forEach(function(i) {
        t = Math.max(t, i.size);
      }), t > 0 && (e.config.markers.hover.size > 0 ? t = e.config.markers.hover.size : t += e.config.markers.hover.sizeOffset), e.globals.markers.largestSize = t, t;
    } }, { key: "getSeriesTotals", value: function() {
      var e = this.w;
      e.globals.seriesTotals = e.globals.series.map(function(t, i) {
        var a = 0;
        if (Array.isArray(t))
          for (var r = 0; r < t.length; r++)
            a += t[r];
        else
          a += t;
        return a;
      });
    } }, { key: "getSeriesTotalsXRange", value: function(e, t) {
      var i = this.w;
      return i.globals.series.map(function(a, r) {
        for (var s = 0, n = 0; n < a.length; n++)
          i.globals.seriesX[r][n] > e && i.globals.seriesX[r][n] < t && (s += a[n]);
        return s;
      });
    } }, { key: "getPercentSeries", value: function() {
      var e = this.w;
      e.globals.seriesPercent = e.globals.series.map(function(t, i) {
        var a = [];
        if (Array.isArray(t))
          for (var r = 0; r < t.length; r++) {
            var s = e.globals.stackedSeriesTotals[r], n = 0;
            s && (n = 100 * t[r] / s), a.push(n);
          }
        else {
          var o = 100 * t / e.globals.seriesTotals.reduce(function(h, d) {
            return h + d;
          }, 0);
          a.push(o);
        }
        return a;
      });
    } }, { key: "getCalculatedRatios", value: function() {
      var e, t, i, a = this, r = this.w, s = r.globals, n = [], o = 0, h = [], d = 0.1, c = 0;
      if (s.yRange = [], s.isMultipleYAxis)
        for (var g = 0; g < s.minYArr.length; g++)
          s.yRange.push(Math.abs(s.minYArr[g] - s.maxYArr[g])), h.push(0);
      else
        s.yRange.push(Math.abs(s.minY - s.maxY));
      s.xRange = Math.abs(s.maxX - s.minX), s.zRange = Math.abs(s.maxZ - s.minZ);
      for (var p = 0; p < s.yRange.length; p++)
        n.push(s.yRange[p] / s.gridHeight);
      if (t = s.xRange / s.gridWidth, e = s.yRange / s.gridWidth, i = s.xRange / s.gridHeight, (o = s.zRange / s.gridHeight * 16) || (o = 1), s.minY !== Number.MIN_VALUE && Math.abs(s.minY) !== 0 && (s.hasNegs = !0), r.globals.seriesYAxisReverseMap.length > 0) {
        var x = function(m, v) {
          var w = r.config.yaxis[r.globals.seriesYAxisReverseMap[v]], l = m < 0 ? -1 : 1;
          return m = Math.abs(m), w.logarithmic && (m = a.getBaseLog(w.logBase, m)), -l * m / n[v];
        };
        if (s.isMultipleYAxis) {
          h = [];
          for (var f = 0; f < n.length; f++)
            h.push(x(s.minYArr[f], f));
        } else
          (h = []).push(x(s.minY, 0)), s.minY !== Number.MIN_VALUE && Math.abs(s.minY) !== 0 && (d = -s.minY / e, c = s.minX / t);
      } else
        (h = []).push(0), d = 0, c = 0;
      return { yRatio: n, invertedYRatio: e, zRatio: o, xRatio: t, invertedXRatio: i, baseLineInvertedY: d, baseLineY: h, baseLineX: c };
    } }, { key: "getLogSeries", value: function(e) {
      var t = this, i = this.w;
      return i.globals.seriesLog = e.map(function(a, r) {
        var s = i.globals.seriesYAxisReverseMap[r];
        return i.config.yaxis[s] && i.config.yaxis[s].logarithmic ? a.map(function(n) {
          return n === null ? null : t.getLogVal(i.config.yaxis[s].logBase, n, r);
        }) : a;
      }), i.globals.invalidLogScale ? e : i.globals.seriesLog;
    } }, { key: "getBaseLog", value: function(e, t) {
      return Math.log(t) / Math.log(e);
    } }, { key: "getLogVal", value: function(e, t, i) {
      if (t <= 0)
        return 0;
      var a = this.w, r = a.globals.minYArr[i] === 0 ? -1 : this.getBaseLog(e, a.globals.minYArr[i]), s = (a.globals.maxYArr[i] === 0 ? 0 : this.getBaseLog(e, a.globals.maxYArr[i])) - r;
      return t < 1 ? t / s : (this.getBaseLog(e, t) - r) / s;
    } }, { key: "getLogYRatios", value: function(e) {
      var t = this, i = this.w, a = this.w.globals;
      return a.yLogRatio = e.slice(), a.logYRange = a.yRange.map(function(r, s) {
        var n = i.globals.seriesYAxisReverseMap[s];
        if (i.config.yaxis[n] && t.w.config.yaxis[n].logarithmic) {
          var o, h = -Number.MAX_VALUE, d = Number.MIN_VALUE;
          return a.seriesLog.forEach(function(c, g) {
            c.forEach(function(p) {
              i.config.yaxis[g] && i.config.yaxis[g].logarithmic && (h = Math.max(p, h), d = Math.min(p, d));
            });
          }), o = Math.pow(a.yRange[s], Math.abs(d - h) / a.yRange[s]), a.yLogRatio[s] = o / a.gridHeight, o;
        }
      }), a.invalidLogScale ? e.slice() : a.yLogRatio;
    } }, { key: "drawSeriesByGroup", value: function(e, t, i, a) {
      var r = this.w, s = [];
      return e.series.length > 0 && t.forEach(function(n) {
        var o = [], h = [];
        e.i.forEach(function(d, c) {
          r.config.series[d].group === n && (o.push(e.series[c]), h.push(d));
        }), o.length > 0 && s.push(a.draw(o, i, h));
      }), s;
    } }], [{ key: "checkComboSeries", value: function(e, t) {
      var i = !1, a = 0, r = 0;
      return t === void 0 && (t = "line"), e.length && e[0].type !== void 0 && e.forEach(function(s) {
        s.type !== "bar" && s.type !== "column" && s.type !== "candlestick" && s.type !== "boxPlot" || a++, s.type !== void 0 && s.type !== t && r++;
      }), r > 0 && (i = !0), { comboBarCount: a, comboCharts: i };
    } }, { key: "extendArrayProps", value: function(e, t, i) {
      var a, r, s, n, o, h;
      return (a = t) !== null && a !== void 0 && a.yaxis && (t = e.extendYAxis(t, i)), (r = t) !== null && r !== void 0 && r.annotations && (t.annotations.yaxis && (t = e.extendYAxisAnnotations(t)), (s = t) !== null && s !== void 0 && (n = s.annotations) !== null && n !== void 0 && n.xaxis && (t = e.extendXAxisAnnotations(t)), (o = t) !== null && o !== void 0 && (h = o.annotations) !== null && h !== void 0 && h.points && (t = e.extendPointAnnotations(t))), t;
    } }]), y;
  }(), Le = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.annoCtx = e;
    }
    return F(y, [{ key: "setOrientations", value: function(e) {
      var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null, i = this.w;
      if (e.label.orientation === "vertical") {
        var a = t !== null ? t : 0, r = i.globals.dom.baseEl.querySelector(".apexcharts-xaxis-annotations .apexcharts-xaxis-annotation-label[rel='".concat(a, "']"));
        if (r !== null) {
          var s = r.getBoundingClientRect();
          r.setAttribute("x", parseFloat(r.getAttribute("x")) - s.height + 4);
          var n = e.label.position === "top" ? s.width : -s.width;
          r.setAttribute("y", parseFloat(r.getAttribute("y")) + n);
          var o = this.annoCtx.graphics.rotateAroundCenter(r), h = o.x, d = o.y;
          r.setAttribute("transform", "rotate(-90 ".concat(h, " ").concat(d, ")"));
        }
      }
    } }, { key: "addBackgroundToAnno", value: function(e, t) {
      var i = this.w;
      if (!e || !t.label.text || !String(t.label.text).trim())
        return null;
      var a = i.globals.dom.baseEl.querySelector(".apexcharts-grid").getBoundingClientRect(), r = e.getBoundingClientRect(), s = t.label.style.padding, n = s.left, o = s.right, h = s.top, d = s.bottom;
      if (t.label.orientation === "vertical") {
        var c = [n, o, h, d];
        h = c[0], d = c[1], n = c[2], o = c[3];
      }
      var g = r.left - a.left - n, p = r.top - a.top - h, x = this.annoCtx.graphics.drawRect(g - i.globals.barPadForNumericAxis, p, r.width + n + o, r.height + h + d, t.label.borderRadius, t.label.style.background, 1, t.label.borderWidth, t.label.borderColor, 0);
      return t.id && x.node.classList.add(t.id), x;
    } }, { key: "annotationsBackground", value: function() {
      var e = this, t = this.w, i = function(a, r, s) {
        var n = t.globals.dom.baseEl.querySelector(".apexcharts-".concat(s, "-annotations .apexcharts-").concat(s, "-annotation-label[rel='").concat(r, "']"));
        if (n) {
          var o = n.parentNode, h = e.addBackgroundToAnno(n, a);
          h && (o.insertBefore(h.node, n), a.label.mouseEnter && h.node.addEventListener("mouseenter", a.label.mouseEnter.bind(e, a)), a.label.mouseLeave && h.node.addEventListener("mouseleave", a.label.mouseLeave.bind(e, a)), a.label.click && h.node.addEventListener("click", a.label.click.bind(e, a)));
        }
      };
      t.config.annotations.xaxis.forEach(function(a, r) {
        return i(a, r, "xaxis");
      }), t.config.annotations.yaxis.forEach(function(a, r) {
        return i(a, r, "yaxis");
      }), t.config.annotations.points.forEach(function(a, r) {
        return i(a, r, "point");
      });
    } }, { key: "getY1Y2", value: function(e, t) {
      var i, a = this.w, r = e === "y1" ? t.y : t.y2, s = !1;
      if (this.annoCtx.invertAxis) {
        var n = a.config.xaxis.convertedCatToNumeric ? a.globals.categoryLabels : a.globals.labels, o = n.indexOf(r), h = a.globals.dom.baseEl.querySelector(".apexcharts-yaxis-texts-g text:nth-child(".concat(o + 1, ")"));
        i = h ? parseFloat(h.getAttribute("y")) : (a.globals.gridHeight / n.length - 1) * (o + 1) - a.globals.barHeight, t.seriesIndex !== void 0 && a.globals.barHeight && (i -= a.globals.barHeight / 2 * (a.globals.series.length - 1) - a.globals.barHeight * t.seriesIndex);
      } else {
        var d, c = a.globals.seriesYAxisMap[t.yAxisIndex][0], g = a.config.yaxis[t.yAxisIndex].logarithmic ? new $(this.annoCtx.ctx).getLogVal(a.config.yaxis[t.yAxisIndex].logBase, r, c) / a.globals.yLogRatio[c] : (r - a.globals.minYArr[c]) / (a.globals.yRange[c] / a.globals.gridHeight);
        i = a.globals.gridHeight - Math.min(Math.max(g, 0), a.globals.gridHeight), s = g > a.globals.gridHeight || g < 0, !t.marker || t.y !== void 0 && t.y !== null || (i = 0), (d = a.config.yaxis[t.yAxisIndex]) !== null && d !== void 0 && d.reversed && (i = g);
      }
      return typeof r == "string" && r.includes("px") && (i = parseFloat(r)), { yP: i, clipped: s };
    } }, { key: "getX1X2", value: function(e, t) {
      var i = this.w, a = e === "x1" ? t.x : t.x2, r = this.annoCtx.invertAxis ? i.globals.minY : i.globals.minX, s = this.annoCtx.invertAxis ? i.globals.maxY : i.globals.maxX, n = this.annoCtx.invertAxis ? i.globals.yRange[0] : i.globals.xRange, o = !1, h = this.annoCtx.inversedReversedAxis ? (s - a) / (n / i.globals.gridWidth) : (a - r) / (n / i.globals.gridWidth);
      return i.config.xaxis.type !== "category" && !i.config.xaxis.convertedCatToNumeric || this.annoCtx.invertAxis || i.globals.dataFormatXNumeric || i.config.chart.sparkline.enabled || (h = this.getStringX(a)), typeof a == "string" && a.includes("px") && (h = parseFloat(a)), a == null && t.marker && (h = i.globals.gridWidth), t.seriesIndex !== void 0 && i.globals.barWidth && !this.annoCtx.invertAxis && (h -= i.globals.barWidth / 2 * (i.globals.series.length - 1) - i.globals.barWidth * t.seriesIndex), h > i.globals.gridWidth ? (h = i.globals.gridWidth, o = !0) : h < 0 && (h = 0, o = !0), { x: h, clipped: o };
    } }, { key: "getStringX", value: function(e) {
      var t = this.w, i = e;
      t.config.xaxis.convertedCatToNumeric && t.globals.categoryLabels.length && (e = t.globals.categoryLabels.indexOf(e) + 1);
      var a = t.globals.labels.map(function(s) {
        return Array.isArray(s) ? s.join(" ") : s;
      }).indexOf(e), r = t.globals.dom.baseEl.querySelector(".apexcharts-xaxis-texts-g text:nth-child(".concat(a + 1, ")"));
      return r && (i = parseFloat(r.getAttribute("x"))), i;
    } }]), y;
  }(), ft = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.annoCtx = e, this.invertAxis = this.annoCtx.invertAxis, this.helpers = new Le(this.annoCtx);
    }
    return F(y, [{ key: "addXaxisAnnotation", value: function(e, t, i) {
      var a, r = this.w, s = this.helpers.getX1X2("x1", e), n = s.x, o = s.clipped, h = !0, d = e.label.text, c = e.strokeDashArray;
      if (P.isNumber(n)) {
        if (e.x2 === null || e.x2 === void 0) {
          if (!o) {
            var g = this.annoCtx.graphics.drawLine(n + e.offsetX, 0 + e.offsetY, n + e.offsetX, r.globals.gridHeight + e.offsetY, e.borderColor, c, e.borderWidth);
            t.appendChild(g.node), e.id && g.node.classList.add(e.id);
          }
        } else {
          var p = this.helpers.getX1X2("x2", e);
          if (a = p.x, h = p.clipped, !o || !h) {
            if (a < n) {
              var x = n;
              n = a, a = x;
            }
            var f = this.annoCtx.graphics.drawRect(n + e.offsetX, 0 + e.offsetY, a - n, r.globals.gridHeight + e.offsetY, 0, e.fillColor, e.opacity, 1, e.borderColor, c);
            f.node.classList.add("apexcharts-annotation-rect"), f.attr("clip-path", "url(#gridRectMask".concat(r.globals.cuid, ")")), t.appendChild(f.node), e.id && f.node.classList.add(e.id);
          }
        }
        if (!o || !h) {
          var m = this.annoCtx.graphics.getTextRects(d, parseFloat(e.label.style.fontSize)), v = e.label.position === "top" ? 4 : e.label.position === "center" ? r.globals.gridHeight / 2 + (e.label.orientation === "vertical" ? m.width / 2 : 0) : r.globals.gridHeight, w = this.annoCtx.graphics.drawText({ x: n + e.label.offsetX, y: v + e.label.offsetY - (e.label.orientation === "vertical" ? e.label.position === "top" ? m.width / 2 - 12 : -m.width / 2 : 0), text: d, textAnchor: e.label.textAnchor, fontSize: e.label.style.fontSize, fontFamily: e.label.style.fontFamily, fontWeight: e.label.style.fontWeight, foreColor: e.label.style.color, cssClass: "apexcharts-xaxis-annotation-label ".concat(e.label.style.cssClass, " ").concat(e.id ? e.id : "") });
          w.attr({ rel: i }), t.appendChild(w.node), this.annoCtx.helpers.setOrientations(e, i);
        }
      }
    } }, { key: "drawXAxisAnnotations", value: function() {
      var e = this, t = this.w, i = this.annoCtx.graphics.group({ class: "apexcharts-xaxis-annotations" });
      return t.config.annotations.xaxis.map(function(a, r) {
        e.addXaxisAnnotation(a, i.node, r);
      }), i;
    } }]), y;
  }(), K = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.months31 = [1, 3, 5, 7, 8, 10, 12], this.months30 = [2, 4, 6, 9, 11], this.daysCntOfYear = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    }
    return F(y, [{ key: "isValidDate", value: function(e) {
      return typeof e != "number" && !isNaN(this.parseDate(e));
    } }, { key: "getTimeStamp", value: function(e) {
      return Date.parse(e) ? this.w.config.xaxis.labels.datetimeUTC ? new Date(new Date(e).toISOString().substr(0, 25)).getTime() : new Date(e).getTime() : e;
    } }, { key: "getDate", value: function(e) {
      return this.w.config.xaxis.labels.datetimeUTC ? new Date(new Date(e).toUTCString()) : new Date(e);
    } }, { key: "parseDate", value: function(e) {
      var t = Date.parse(e);
      if (!isNaN(t))
        return this.getTimeStamp(e);
      var i = Date.parse(e.replace(/-/g, "/").replace(/[a-z]+/gi, " "));
      return i = this.getTimeStamp(i);
    } }, { key: "parseDateWithTimezone", value: function(e) {
      return Date.parse(e.replace(/-/g, "/").replace(/[a-z]+/gi, " "));
    } }, { key: "formatDate", value: function(e, t) {
      var i = this.w.globals.locale, a = this.w.config.xaxis.labels.datetimeUTC, r = ["\0"].concat(J(i.months)), s = [""].concat(J(i.shortMonths)), n = [""].concat(J(i.days)), o = [""].concat(J(i.shortDays));
      function h(S, C) {
        var L = S + "";
        for (C = C || 2; L.length < C; )
          L = "0" + L;
        return L;
      }
      var d = a ? e.getUTCFullYear() : e.getFullYear();
      t = (t = (t = t.replace(/(^|[^\\])yyyy+/g, "$1" + d)).replace(/(^|[^\\])yy/g, "$1" + d.toString().substr(2, 2))).replace(/(^|[^\\])y/g, "$1" + d);
      var c = (a ? e.getUTCMonth() : e.getMonth()) + 1;
      t = (t = (t = (t = t.replace(/(^|[^\\])MMMM+/g, "$1" + r[0])).replace(/(^|[^\\])MMM/g, "$1" + s[0])).replace(/(^|[^\\])MM/g, "$1" + h(c))).replace(/(^|[^\\])M/g, "$1" + c);
      var g = a ? e.getUTCDate() : e.getDate();
      t = (t = (t = (t = t.replace(/(^|[^\\])dddd+/g, "$1" + n[0])).replace(/(^|[^\\])ddd/g, "$1" + o[0])).replace(/(^|[^\\])dd/g, "$1" + h(g))).replace(/(^|[^\\])d/g, "$1" + g);
      var p = a ? e.getUTCHours() : e.getHours(), x = p > 12 ? p - 12 : p === 0 ? 12 : p;
      t = (t = (t = (t = t.replace(/(^|[^\\])HH+/g, "$1" + h(p))).replace(/(^|[^\\])H/g, "$1" + p)).replace(/(^|[^\\])hh+/g, "$1" + h(x))).replace(/(^|[^\\])h/g, "$1" + x);
      var f = a ? e.getUTCMinutes() : e.getMinutes();
      t = (t = t.replace(/(^|[^\\])mm+/g, "$1" + h(f))).replace(/(^|[^\\])m/g, "$1" + f);
      var m = a ? e.getUTCSeconds() : e.getSeconds();
      t = (t = t.replace(/(^|[^\\])ss+/g, "$1" + h(m))).replace(/(^|[^\\])s/g, "$1" + m);
      var v = a ? e.getUTCMilliseconds() : e.getMilliseconds();
      t = t.replace(/(^|[^\\])fff+/g, "$1" + h(v, 3)), v = Math.round(v / 10), t = t.replace(/(^|[^\\])ff/g, "$1" + h(v)), v = Math.round(v / 10);
      var w = p < 12 ? "AM" : "PM";
      t = (t = (t = t.replace(/(^|[^\\])f/g, "$1" + v)).replace(/(^|[^\\])TT+/g, "$1" + w)).replace(/(^|[^\\])T/g, "$1" + w.charAt(0));
      var l = w.toLowerCase();
      t = (t = t.replace(/(^|[^\\])tt+/g, "$1" + l)).replace(/(^|[^\\])t/g, "$1" + l.charAt(0));
      var u = -e.getTimezoneOffset(), b = a || !u ? "Z" : u > 0 ? "+" : "-";
      if (!a) {
        var A = (u = Math.abs(u)) % 60;
        b += h(Math.floor(u / 60)) + ":" + h(A);
      }
      t = t.replace(/(^|[^\\])K/g, "$1" + b);
      var k = (a ? e.getUTCDay() : e.getDay()) + 1;
      return t = (t = (t = (t = (t = t.replace(new RegExp(n[0], "g"), n[k])).replace(new RegExp(o[0], "g"), o[k])).replace(new RegExp(r[0], "g"), r[c])).replace(new RegExp(s[0], "g"), s[c])).replace(/\\(.)/g, "$1");
    } }, { key: "getTimeUnitsfromTimestamp", value: function(e, t, i) {
      var a = this.w;
      a.config.xaxis.min !== void 0 && (e = a.config.xaxis.min), a.config.xaxis.max !== void 0 && (t = a.config.xaxis.max);
      var r = this.getDate(e), s = this.getDate(t), n = this.formatDate(r, "yyyy MM dd HH mm ss fff").split(" "), o = this.formatDate(s, "yyyy MM dd HH mm ss fff").split(" ");
      return { minMillisecond: parseInt(n[6], 10), maxMillisecond: parseInt(o[6], 10), minSecond: parseInt(n[5], 10), maxSecond: parseInt(o[5], 10), minMinute: parseInt(n[4], 10), maxMinute: parseInt(o[4], 10), minHour: parseInt(n[3], 10), maxHour: parseInt(o[3], 10), minDate: parseInt(n[2], 10), maxDate: parseInt(o[2], 10), minMonth: parseInt(n[1], 10) - 1, maxMonth: parseInt(o[1], 10) - 1, minYear: parseInt(n[0], 10), maxYear: parseInt(o[0], 10) };
    } }, { key: "isLeapYear", value: function(e) {
      return e % 4 == 0 && e % 100 != 0 || e % 400 == 0;
    } }, { key: "calculcateLastDaysOfMonth", value: function(e, t, i) {
      return this.determineDaysOfMonths(e, t) - i;
    } }, { key: "determineDaysOfYear", value: function(e) {
      var t = 365;
      return this.isLeapYear(e) && (t = 366), t;
    } }, { key: "determineRemainingDaysOfYear", value: function(e, t, i) {
      var a = this.daysCntOfYear[t] + i;
      return t > 1 && this.isLeapYear() && a++, a;
    } }, { key: "determineDaysOfMonths", value: function(e, t) {
      var i = 30;
      switch (e = P.monthMod(e), !0) {
        case this.months30.indexOf(e) > -1:
          e === 2 && (i = this.isLeapYear(t) ? 29 : 28);
          break;
        case this.months31.indexOf(e) > -1:
        default:
          i = 31;
      }
      return i;
    } }]), y;
  }(), me = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.tooltipKeyFormat = "dd MMM";
    }
    return F(y, [{ key: "xLabelFormat", value: function(e, t, i, a) {
      var r = this.w;
      if (r.config.xaxis.type === "datetime" && r.config.xaxis.labels.formatter === void 0 && r.config.tooltip.x.formatter === void 0) {
        var s = new K(this.ctx);
        return s.formatDate(s.getDate(t), r.config.tooltip.x.format);
      }
      return e(t, i, a);
    } }, { key: "defaultGeneralFormatter", value: function(e) {
      return Array.isArray(e) ? e.map(function(t) {
        return t;
      }) : e;
    } }, { key: "defaultYFormatter", value: function(e, t, i) {
      var a = this.w;
      if (P.isNumber(e))
        if (a.globals.yValueDecimal !== 0)
          e = e.toFixed(t.decimalsInFloat !== void 0 ? t.decimalsInFloat : a.globals.yValueDecimal);
        else {
          var r = e.toFixed(0);
          e = e == r ? r : e.toFixed(1);
        }
      return e;
    } }, { key: "setLabelFormatters", value: function() {
      var e = this, t = this.w;
      return t.globals.xaxisTooltipFormatter = function(i) {
        return e.defaultGeneralFormatter(i);
      }, t.globals.ttKeyFormatter = function(i) {
        return e.defaultGeneralFormatter(i);
      }, t.globals.ttZFormatter = function(i) {
        return i;
      }, t.globals.legendFormatter = function(i) {
        return e.defaultGeneralFormatter(i);
      }, t.config.xaxis.labels.formatter !== void 0 ? t.globals.xLabelFormatter = t.config.xaxis.labels.formatter : t.globals.xLabelFormatter = function(i) {
        if (P.isNumber(i)) {
          if (!t.config.xaxis.convertedCatToNumeric && t.config.xaxis.type === "numeric") {
            if (P.isNumber(t.config.xaxis.decimalsInFloat))
              return i.toFixed(t.config.xaxis.decimalsInFloat);
            var a = t.globals.maxX - t.globals.minX;
            return a > 0 && a < 100 ? i.toFixed(1) : i.toFixed(0);
          }
          return t.globals.isBarHorizontal && t.globals.maxY - t.globals.minYArr < 4 ? i.toFixed(1) : i.toFixed(0);
        }
        return i;
      }, typeof t.config.tooltip.x.formatter == "function" ? t.globals.ttKeyFormatter = t.config.tooltip.x.formatter : t.globals.ttKeyFormatter = t.globals.xLabelFormatter, typeof t.config.xaxis.tooltip.formatter == "function" && (t.globals.xaxisTooltipFormatter = t.config.xaxis.tooltip.formatter), (Array.isArray(t.config.tooltip.y) || t.config.tooltip.y.formatter !== void 0) && (t.globals.ttVal = t.config.tooltip.y), t.config.tooltip.z.formatter !== void 0 && (t.globals.ttZFormatter = t.config.tooltip.z.formatter), t.config.legend.formatter !== void 0 && (t.globals.legendFormatter = t.config.legend.formatter), t.config.yaxis.forEach(function(i, a) {
        i.labels.formatter !== void 0 ? t.globals.yLabelFormatters[a] = i.labels.formatter : t.globals.yLabelFormatters[a] = function(r) {
          return t.globals.xyCharts ? Array.isArray(r) ? r.map(function(s) {
            return e.defaultYFormatter(s, i, a);
          }) : e.defaultYFormatter(r, i, a) : r;
        };
      }), t.globals;
    } }, { key: "heatmapLabelFormatters", value: function() {
      var e = this.w;
      if (e.config.chart.type === "heatmap") {
        e.globals.yAxisScale[0].result = e.globals.seriesNames.slice();
        var t = e.globals.seriesNames.reduce(function(i, a) {
          return i.length > a.length ? i : a;
        }, 0);
        e.globals.yAxisScale[0].niceMax = t, e.globals.yAxisScale[0].niceMin = t;
      }
    } }]), y;
  }(), he = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "getLabel", value: function(e, t, i, a) {
      var r = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : [], s = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : "12px", n = !(arguments.length > 6 && arguments[6] !== void 0) || arguments[6], o = this.w, h = e[a] === void 0 ? "" : e[a], d = h, c = o.globals.xLabelFormatter, g = o.config.xaxis.labels.formatter, p = !1, x = new me(this.ctx), f = h;
      n && (d = x.xLabelFormat(c, h, f, { i: a, dateFormatter: new K(this.ctx).formatDate, w: o }), g !== void 0 && (d = g(h, e[a], { i: a, dateFormatter: new K(this.ctx).formatDate, w: o })));
      var m, v;
      t.length > 0 ? (m = t[a].unit, v = null, t.forEach(function(b) {
        b.unit === "month" ? v = "year" : b.unit === "day" ? v = "month" : b.unit === "hour" ? v = "day" : b.unit === "minute" && (v = "hour");
      }), p = v === m, i = t[a].position, d = t[a].value) : o.config.xaxis.type === "datetime" && g === void 0 && (d = ""), d === void 0 && (d = ""), d = Array.isArray(d) ? d : d.toString();
      var w = new X(this.ctx), l = {};
      l = o.globals.rotateXLabels && n ? w.getTextRects(d, parseInt(s, 10), null, "rotate(".concat(o.config.xaxis.labels.rotate, " 0 0)"), !1) : w.getTextRects(d, parseInt(s, 10));
      var u = !o.config.xaxis.labels.showDuplicates && this.ctx.timeScale;
      return !Array.isArray(d) && (String(d) === "NaN" || r.indexOf(d) >= 0 && u) && (d = ""), { x: i, text: d, textRect: l, isBold: p };
    } }, { key: "checkLabelBasedOnTickamount", value: function(e, t, i) {
      var a = this.w, r = a.config.xaxis.tickAmount;
      return r === "dataPoints" && (r = Math.round(a.globals.gridWidth / 120)), r > i || e % Math.round(i / (r + 1)) == 0 || (t.text = ""), t;
    } }, { key: "checkForOverflowingLabels", value: function(e, t, i, a, r) {
      var s = this.w;
      if (e === 0 && s.globals.skipFirstTimelinelabel && (t.text = ""), e === i - 1 && s.globals.skipLastTimelinelabel && (t.text = ""), s.config.xaxis.labels.hideOverlappingLabels && a.length > 0) {
        var n = r[r.length - 1];
        t.x < n.textRect.width / (s.globals.rotateXLabels ? Math.abs(s.config.xaxis.labels.rotate) / 12 : 1.01) + n.x && (t.text = "");
      }
      return t;
    } }, { key: "checkForReversedLabels", value: function(e, t) {
      var i = this.w;
      return i.config.yaxis[e] && i.config.yaxis[e].reversed && t.reverse(), t;
    } }, { key: "yAxisAllSeriesCollapsed", value: function(e) {
      var t = this.w.globals;
      return !t.seriesYAxisMap[e].some(function(i) {
        return t.collapsedSeriesIndices.indexOf(i) === -1;
      });
    } }, { key: "translateYAxisIndex", value: function(e) {
      var t = this.w, i = t.globals, a = t.config.yaxis;
      return i.series.length > a.length || a.some(function(r) {
        return Array.isArray(r.seriesName);
      }) ? e : i.seriesYAxisReverseMap[e];
    } }, { key: "isYAxisHidden", value: function(e) {
      var t = this.w, i = t.config.yaxis[e];
      if (!i.show || this.yAxisAllSeriesCollapsed(e))
        return !0;
      if (!i.showForNullSeries) {
        var a = t.globals.seriesYAxisMap[e], r = new $(this.ctx);
        return a.every(function(s) {
          return r.isSeriesNull(s);
        });
      }
      return !1;
    } }, { key: "getYAxisForeColor", value: function(e, t) {
      var i = this.w;
      return Array.isArray(e) && i.globals.yAxisScale[t] && this.ctx.theme.pushExtraColors(e, i.globals.yAxisScale[t].result.length, !1), e;
    } }, { key: "drawYAxisTicks", value: function(e, t, i, a, r, s, n) {
      var o = this.w, h = new X(this.ctx), d = o.globals.translateY + o.config.yaxis[r].labels.offsetY;
      if (o.globals.isBarHorizontal ? d = 0 : o.config.chart.type === "heatmap" && (d += s / 2), a.show && t > 0) {
        o.config.yaxis[r].opposite === !0 && (e += a.width);
        for (var c = t; c >= 0; c--) {
          var g = h.drawLine(e + i.offsetX - a.width + a.offsetX, d + a.offsetY, e + i.offsetX + a.offsetX, d + a.offsetY, a.color);
          n.add(g), d += s;
        }
      }
    } }]), y;
  }(), xt = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.annoCtx = e, this.helpers = new Le(this.annoCtx), this.axesUtils = new he(this.annoCtx);
    }
    return F(y, [{ key: "addYaxisAnnotation", value: function(e, t, i) {
      var a, r = this.w, s = e.strokeDashArray, n = this.helpers.getY1Y2("y1", e), o = n.yP, h = n.clipped, d = !0, c = !1, g = e.label.text;
      if (e.y2 === null || e.y2 === void 0) {
        if (!h) {
          c = !0;
          var p = this.annoCtx.graphics.drawLine(0 + e.offsetX, o + e.offsetY, this._getYAxisAnnotationWidth(e), o + e.offsetY, e.borderColor, s, e.borderWidth);
          t.appendChild(p.node), e.id && p.node.classList.add(e.id);
        }
      } else {
        if (a = (n = this.helpers.getY1Y2("y2", e)).yP, d = n.clipped, a > o) {
          var x = o;
          o = a, a = x;
        }
        if (!h || !d) {
          c = !0;
          var f = this.annoCtx.graphics.drawRect(0 + e.offsetX, a + e.offsetY, this._getYAxisAnnotationWidth(e), o - a, 0, e.fillColor, e.opacity, 1, e.borderColor, s);
          f.node.classList.add("apexcharts-annotation-rect"), f.attr("clip-path", "url(#gridRectMask".concat(r.globals.cuid, ")")), t.appendChild(f.node), e.id && f.node.classList.add(e.id);
        }
      }
      if (c) {
        var m = e.label.position === "right" ? r.globals.gridWidth : e.label.position === "center" ? r.globals.gridWidth / 2 : 0, v = this.annoCtx.graphics.drawText({ x: m + e.label.offsetX, y: (a ?? o) + e.label.offsetY - 3, text: g, textAnchor: e.label.textAnchor, fontSize: e.label.style.fontSize, fontFamily: e.label.style.fontFamily, fontWeight: e.label.style.fontWeight, foreColor: e.label.style.color, cssClass: "apexcharts-yaxis-annotation-label ".concat(e.label.style.cssClass, " ").concat(e.id ? e.id : "") });
        v.attr({ rel: i }), t.appendChild(v.node);
      }
    } }, { key: "_getYAxisAnnotationWidth", value: function(e) {
      var t = this.w;
      return t.globals.gridWidth, (e.width.indexOf("%") > -1 ? t.globals.gridWidth * parseInt(e.width, 10) / 100 : parseInt(e.width, 10)) + e.offsetX;
    } }, { key: "drawYAxisAnnotations", value: function() {
      var e = this, t = this.w, i = this.annoCtx.graphics.group({ class: "apexcharts-yaxis-annotations" });
      return t.config.annotations.yaxis.forEach(function(a, r) {
        a.yAxisIndex = e.axesUtils.translateYAxisIndex(a.yAxisIndex), e.axesUtils.isYAxisHidden(a.yAxisIndex) && e.axesUtils.yAxisAllSeriesCollapsed(a.yAxisIndex) || e.addYaxisAnnotation(a, i.node, r);
      }), i;
    } }]), y;
  }(), bt = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.annoCtx = e, this.helpers = new Le(this.annoCtx);
    }
    return F(y, [{ key: "addPointAnnotation", value: function(e, t, i) {
      if (!(this.w.globals.collapsedSeriesIndices.indexOf(e.seriesIndex) > -1)) {
        var a = this.helpers.getX1X2("x1", e), r = a.x, s = a.clipped, n = (a = this.helpers.getY1Y2("y1", e)).yP, o = a.clipped;
        if (P.isNumber(r) && !o && !s) {
          var h = { pSize: e.marker.size, pointStrokeWidth: e.marker.strokeWidth, pointFillColor: e.marker.fillColor, pointStrokeColor: e.marker.strokeColor, shape: e.marker.shape, pRadius: e.marker.radius, class: "apexcharts-point-annotation-marker ".concat(e.marker.cssClass, " ").concat(e.id ? e.id : "") }, d = this.annoCtx.graphics.drawMarker(r + e.marker.offsetX, n + e.marker.offsetY, h);
          t.appendChild(d.node);
          var c = e.label.text ? e.label.text : "", g = this.annoCtx.graphics.drawText({ x: r + e.label.offsetX, y: n + e.label.offsetY - e.marker.size - parseFloat(e.label.style.fontSize) / 1.6, text: c, textAnchor: e.label.textAnchor, fontSize: e.label.style.fontSize, fontFamily: e.label.style.fontFamily, fontWeight: e.label.style.fontWeight, foreColor: e.label.style.color, cssClass: "apexcharts-point-annotation-label ".concat(e.label.style.cssClass, " ").concat(e.id ? e.id : "") });
          if (g.attr({ rel: i }), t.appendChild(g.node), e.customSVG.SVG) {
            var p = this.annoCtx.graphics.group({ class: "apexcharts-point-annotations-custom-svg " + e.customSVG.cssClass });
            p.attr({ transform: "translate(".concat(r + e.customSVG.offsetX, ", ").concat(n + e.customSVG.offsetY, ")") }), p.node.innerHTML = e.customSVG.SVG, t.appendChild(p.node);
          }
          if (e.image.path) {
            var x = e.image.width ? e.image.width : 20, f = e.image.height ? e.image.height : 20;
            d = this.annoCtx.addImage({ x: r + e.image.offsetX - x / 2, y: n + e.image.offsetY - f / 2, width: x, height: f, path: e.image.path, appendTo: ".apexcharts-point-annotations" });
          }
          e.mouseEnter && d.node.addEventListener("mouseenter", e.mouseEnter.bind(this, e)), e.mouseLeave && d.node.addEventListener("mouseleave", e.mouseLeave.bind(this, e)), e.click && d.node.addEventListener("click", e.click.bind(this, e));
        }
      }
    } }, { key: "drawPointAnnotations", value: function() {
      var e = this, t = this.w, i = this.annoCtx.graphics.group({ class: "apexcharts-point-annotations" });
      return t.config.annotations.points.map(function(a, r) {
        e.addPointAnnotation(a, i.node, r);
      }), i;
    } }]), y;
  }(), Je = { name: "en", options: { months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], toolbar: { exportToSVG: "Download SVG", exportToPNG: "Download PNG", exportToCSV: "Download CSV", menu: "Menu", selection: "Selection", selectionZoom: "Selection Zoom", zoomIn: "Zoom In", zoomOut: "Zoom Out", pan: "Panning", reset: "Reset Zoom" } } }, ce = function() {
    function y() {
      R(this, y), this.yAxis = { show: !0, showAlways: !1, showForNullSeries: !0, seriesName: void 0, opposite: !1, reversed: !1, logarithmic: !1, logBase: 10, tickAmount: void 0, stepSize: void 0, forceNiceScale: !1, max: void 0, min: void 0, floating: !1, decimalsInFloat: void 0, labels: { show: !0, showDuplicates: !1, minWidth: 0, maxWidth: 160, offsetX: 0, offsetY: 0, align: void 0, rotate: 0, padding: 20, style: { colors: [], fontSize: "11px", fontWeight: 400, fontFamily: void 0, cssClass: "" }, formatter: void 0 }, axisBorder: { show: !1, color: "#e0e0e0", width: 1, offsetX: 0, offsetY: 0 }, axisTicks: { show: !1, color: "#e0e0e0", width: 6, offsetX: 0, offsetY: 0 }, title: { text: void 0, rotate: -90, offsetY: 0, offsetX: 0, style: { color: void 0, fontSize: "11px", fontWeight: 900, fontFamily: void 0, cssClass: "" } }, tooltip: { enabled: !1, offsetX: 0 }, crosshairs: { show: !0, position: "front", stroke: { color: "#b6b6b6", width: 1, dashArray: 0 } } }, this.pointAnnotation = { id: void 0, x: 0, y: null, yAxisIndex: 0, seriesIndex: void 0, mouseEnter: void 0, mouseLeave: void 0, click: void 0, marker: { size: 4, fillColor: "#fff", strokeWidth: 2, strokeColor: "#333", shape: "circle", offsetX: 0, offsetY: 0, cssClass: "" }, label: { borderColor: "#c2c2c2", borderWidth: 1, borderRadius: 2, text: void 0, textAnchor: "middle", offsetX: 0, offsetY: 0, mouseEnter: void 0, mouseLeave: void 0, click: void 0, style: { background: "#fff", color: void 0, fontSize: "11px", fontFamily: void 0, fontWeight: 400, cssClass: "", padding: { left: 5, right: 5, top: 2, bottom: 2 } } }, customSVG: { SVG: void 0, cssClass: void 0, offsetX: 0, offsetY: 0 }, image: { path: void 0, width: 20, height: 20, offsetX: 0, offsetY: 0 } }, this.yAxisAnnotation = { id: void 0, y: 0, y2: null, strokeDashArray: 1, fillColor: "#c2c2c2", borderColor: "#c2c2c2", borderWidth: 1, opacity: 0.3, offsetX: 0, offsetY: 0, width: "100%", yAxisIndex: 0, label: { borderColor: "#c2c2c2", borderWidth: 1, borderRadius: 2, text: void 0, textAnchor: "end", position: "right", offsetX: 0, offsetY: -3, mouseEnter: void 0, mouseLeave: void 0, click: void 0, style: { background: "#fff", color: void 0, fontSize: "11px", fontFamily: void 0, fontWeight: 400, cssClass: "", padding: { left: 5, right: 5, top: 2, bottom: 2 } } } }, this.xAxisAnnotation = { id: void 0, x: 0, x2: null, strokeDashArray: 1, fillColor: "#c2c2c2", borderColor: "#c2c2c2", borderWidth: 1, opacity: 0.3, offsetX: 0, offsetY: 0, label: { borderColor: "#c2c2c2", borderWidth: 1, borderRadius: 2, text: void 0, textAnchor: "middle", orientation: "vertical", position: "top", offsetX: 0, offsetY: 0, mouseEnter: void 0, mouseLeave: void 0, click: void 0, style: { background: "#fff", color: void 0, fontSize: "11px", fontFamily: void 0, fontWeight: 400, cssClass: "", padding: { left: 5, right: 5, top: 2, bottom: 2 } } } }, this.text = { x: 0, y: 0, text: "", textAnchor: "start", foreColor: void 0, fontSize: "13px", fontFamily: void 0, fontWeight: 400, appendTo: ".apexcharts-annotations", backgroundColor: "transparent", borderColor: "#c2c2c2", borderRadius: 0, borderWidth: 0, paddingLeft: 4, paddingRight: 4, paddingTop: 2, paddingBottom: 2 };
    }
    return F(y, [{ key: "init", value: function() {
      return { annotations: { yaxis: [this.yAxisAnnotation], xaxis: [this.xAxisAnnotation], points: [this.pointAnnotation], texts: [], images: [], shapes: [] }, chart: { animations: { enabled: !0, easing: "easeinout", speed: 800, animateGradually: { delay: 150, enabled: !0 }, dynamicAnimation: { enabled: !0, speed: 350 } }, background: "", locales: [Je], defaultLocale: "en", dropShadow: { enabled: !1, enabledOnSeries: void 0, top: 2, left: 2, blur: 4, color: "#000", opacity: 0.35 }, events: { animationEnd: void 0, beforeMount: void 0, mounted: void 0, updated: void 0, click: void 0, mouseMove: void 0, mouseLeave: void 0, xAxisLabelClick: void 0, legendClick: void 0, markerClick: void 0, selection: void 0, dataPointSelection: void 0, dataPointMouseEnter: void 0, dataPointMouseLeave: void 0, beforeZoom: void 0, beforeResetZoom: void 0, zoomed: void 0, scrolled: void 0, brushScrolled: void 0 }, foreColor: "#373d3f", fontFamily: "Helvetica, Arial, sans-serif", height: "auto", parentHeightOffset: 15, redrawOnParentResize: !0, redrawOnWindowResize: !0, id: void 0, group: void 0, nonce: void 0, offsetX: 0, offsetY: 0, selection: { enabled: !1, type: "x", fill: { color: "#24292e", opacity: 0.1 }, stroke: { width: 1, color: "#24292e", opacity: 0.4, dashArray: 3 }, xaxis: { min: void 0, max: void 0 }, yaxis: { min: void 0, max: void 0 } }, sparkline: { enabled: !1 }, brush: { enabled: !1, autoScaleYaxis: !0, target: void 0, targets: void 0 }, stacked: !1, stackOnlyBar: !0, stackType: "normal", toolbar: { show: !0, offsetX: 0, offsetY: 0, tools: { download: !0, selection: !0, zoom: !0, zoomin: !0, zoomout: !0, pan: !0, reset: !0, customIcons: [] }, export: { csv: { filename: void 0, columnDelimiter: ",", headerCategory: "category", headerValue: "value", categoryFormatter: void 0, valueFormatter: void 0 }, png: { filename: void 0 }, svg: { filename: void 0 }, scale: void 0, width: void 0 }, autoSelected: "zoom" }, type: "line", width: "100%", zoom: { enabled: !0, type: "x", autoScaleYaxis: !1, allowMouseWheelZoom: !0, zoomedArea: { fill: { color: "#90CAF9", opacity: 0.4 }, stroke: { color: "#0D47A1", opacity: 0.4, width: 1 } } } }, plotOptions: { line: { isSlopeChart: !1 }, area: { fillTo: "origin" }, bar: { horizontal: !1, columnWidth: "70%", barHeight: "70%", distributed: !1, borderRadius: 0, borderRadiusApplication: "around", borderRadiusWhenStacked: "last", rangeBarOverlap: !0, rangeBarGroupRows: !1, hideZeroBarsWhenGrouped: !1, isDumbbell: !1, dumbbellColors: void 0, isFunnel: !1, isFunnel3d: !0, colors: { ranges: [], backgroundBarColors: [], backgroundBarOpacity: 1, backgroundBarRadius: 0 }, dataLabels: { position: "top", maxItems: 100, hideOverflowingLabels: !0, orientation: "horizontal", total: { enabled: !1, formatter: void 0, offsetX: 0, offsetY: 0, style: { color: "#373d3f", fontSize: "12px", fontFamily: void 0, fontWeight: 600 } } } }, bubble: { zScaling: !0, minBubbleRadius: void 0, maxBubbleRadius: void 0 }, candlestick: { colors: { upward: "#00B746", downward: "#EF403C" }, wick: { useFillColor: !0 } }, boxPlot: { colors: { upper: "#00E396", lower: "#008FFB" } }, heatmap: { radius: 2, enableShades: !0, shadeIntensity: 0.5, reverseNegativeShade: !1, distributed: !1, useFillColorAsStroke: !1, colorScale: { inverse: !1, ranges: [], min: void 0, max: void 0 } }, treemap: { enableShades: !0, shadeIntensity: 0.5, distributed: !1, reverseNegativeShade: !1, useFillColorAsStroke: !1, borderRadius: 4, dataLabels: { format: "scale" }, colorScale: { inverse: !1, ranges: [], min: void 0, max: void 0 } }, radialBar: { inverseOrder: !1, startAngle: 0, endAngle: 360, offsetX: 0, offsetY: 0, hollow: { margin: 5, size: "50%", background: "transparent", image: void 0, imageWidth: 150, imageHeight: 150, imageOffsetX: 0, imageOffsetY: 0, imageClipped: !0, position: "front", dropShadow: { enabled: !1, top: 0, left: 0, blur: 3, color: "#000", opacity: 0.5 } }, track: { show: !0, startAngle: void 0, endAngle: void 0, background: "#f2f2f2", strokeWidth: "97%", opacity: 1, margin: 5, dropShadow: { enabled: !1, top: 0, left: 0, blur: 3, color: "#000", opacity: 0.5 } }, dataLabels: { show: !0, name: { show: !0, fontSize: "16px", fontFamily: void 0, fontWeight: 600, color: void 0, offsetY: 0, formatter: function(e) {
        return e;
      } }, value: { show: !0, fontSize: "14px", fontFamily: void 0, fontWeight: 400, color: void 0, offsetY: 16, formatter: function(e) {
        return e + "%";
      } }, total: { show: !1, label: "Total", fontSize: "16px", fontWeight: 600, fontFamily: void 0, color: void 0, formatter: function(e) {
        return e.globals.seriesTotals.reduce(function(t, i) {
          return t + i;
        }, 0) / e.globals.series.length + "%";
      } } }, barLabels: { enabled: !1, offsetX: 0, offsetY: 0, useSeriesColors: !0, fontFamily: void 0, fontWeight: 600, fontSize: "16px", formatter: function(e) {
        return e;
      }, onClick: void 0 } }, pie: { customScale: 1, offsetX: 0, offsetY: 0, startAngle: 0, endAngle: 360, expandOnClick: !0, dataLabels: { offset: 0, minAngleToShowLabel: 10 }, donut: { size: "65%", background: "transparent", labels: { show: !1, name: { show: !0, fontSize: "16px", fontFamily: void 0, fontWeight: 600, color: void 0, offsetY: -10, formatter: function(e) {
        return e;
      } }, value: { show: !0, fontSize: "20px", fontFamily: void 0, fontWeight: 400, color: void 0, offsetY: 10, formatter: function(e) {
        return e;
      } }, total: { show: !1, showAlways: !1, label: "Total", fontSize: "16px", fontWeight: 400, fontFamily: void 0, color: void 0, formatter: function(e) {
        return e.globals.seriesTotals.reduce(function(t, i) {
          return t + i;
        }, 0);
      } } } } }, polarArea: { rings: { strokeWidth: 1, strokeColor: "#e8e8e8" }, spokes: { strokeWidth: 1, connectorColors: "#e8e8e8" } }, radar: { size: void 0, offsetX: 0, offsetY: 0, polygons: { strokeWidth: 1, strokeColors: "#e8e8e8", connectorColors: "#e8e8e8", fill: { colors: void 0 } } } }, colors: void 0, dataLabels: { enabled: !0, enabledOnSeries: void 0, formatter: function(e) {
        return e !== null ? e : "";
      }, textAnchor: "middle", distributed: !1, offsetX: 0, offsetY: 0, style: { fontSize: "12px", fontFamily: void 0, fontWeight: 600, colors: void 0 }, background: { enabled: !0, foreColor: "#fff", borderRadius: 2, padding: 4, opacity: 0.9, borderWidth: 1, borderColor: "#fff", dropShadow: { enabled: !1, top: 1, left: 1, blur: 1, color: "#000", opacity: 0.45 } }, dropShadow: { enabled: !1, top: 1, left: 1, blur: 1, color: "#000", opacity: 0.45 } }, fill: { type: "solid", colors: void 0, opacity: 0.85, gradient: { shade: "dark", type: "horizontal", shadeIntensity: 0.5, gradientToColors: void 0, inverseColors: !0, opacityFrom: 1, opacityTo: 1, stops: [0, 50, 100], colorStops: [] }, image: { src: [], width: void 0, height: void 0 }, pattern: { style: "squares", width: 6, height: 6, strokeWidth: 2 } }, forecastDataPoints: { count: 0, fillOpacity: 0.5, strokeWidth: void 0, dashArray: 4 }, grid: { show: !0, borderColor: "#e0e0e0", strokeDashArray: 0, position: "back", xaxis: { lines: { show: !1 } }, yaxis: { lines: { show: !0 } }, row: { colors: void 0, opacity: 0.5 }, column: { colors: void 0, opacity: 0.5 }, padding: { top: 0, right: 10, bottom: 0, left: 12 } }, labels: [], legend: { show: !0, showForSingleSeries: !1, showForNullSeries: !0, showForZeroSeries: !0, floating: !1, position: "bottom", horizontalAlign: "center", inverseOrder: !1, fontSize: "12px", fontFamily: void 0, fontWeight: 400, width: void 0, height: void 0, formatter: void 0, tooltipHoverFormatter: void 0, offsetX: -20, offsetY: 4, customLegendItems: [], labels: { colors: void 0, useSeriesColors: !1 }, markers: { size: 7, fillColors: void 0, strokeWidth: 1, shape: void 0, offsetX: 0, offsetY: 0, customHTML: void 0, onClick: void 0 }, itemMargin: { horizontal: 5, vertical: 4 }, onItemClick: { toggleDataSeries: !0 }, onItemHover: { highlightDataSeries: !0 } }, markers: { discrete: [], size: 0, colors: void 0, strokeColors: "#fff", strokeWidth: 2, strokeOpacity: 0.9, strokeDashArray: 0, fillOpacity: 1, shape: "circle", offsetX: 0, offsetY: 0, showNullDataPoints: !0, onClick: void 0, onDblClick: void 0, hover: { size: void 0, sizeOffset: 3 } }, noData: { text: void 0, align: "center", verticalAlign: "middle", offsetX: 0, offsetY: 0, style: { color: void 0, fontSize: "14px", fontFamily: void 0 } }, responsive: [], series: void 0, states: { normal: { filter: { type: "none", value: 0 } }, hover: { filter: { type: "lighten", value: 0.1 } }, active: { allowMultipleDataPointsSelection: !1, filter: { type: "darken", value: 0.5 } } }, title: { text: void 0, align: "left", margin: 5, offsetX: 0, offsetY: 0, floating: !1, style: { fontSize: "14px", fontWeight: 900, fontFamily: void 0, color: void 0 } }, subtitle: { text: void 0, align: "left", margin: 5, offsetX: 0, offsetY: 30, floating: !1, style: { fontSize: "12px", fontWeight: 400, fontFamily: void 0, color: void 0 } }, stroke: { show: !0, curve: "smooth", lineCap: "butt", width: 2, colors: void 0, dashArray: 0, fill: { type: "solid", colors: void 0, opacity: 0.85, gradient: { shade: "dark", type: "horizontal", shadeIntensity: 0.5, gradientToColors: void 0, inverseColors: !0, opacityFrom: 1, opacityTo: 1, stops: [0, 50, 100], colorStops: [] } } }, tooltip: { enabled: !0, enabledOnSeries: void 0, shared: !0, hideEmptySeries: !1, followCursor: !1, intersect: !1, inverseOrder: !1, custom: void 0, fillSeriesColor: !1, theme: "light", cssClass: "", style: { fontSize: "12px", fontFamily: void 0 }, onDatasetHover: { highlightDataSeries: !1 }, x: { show: !0, format: "dd MMM", formatter: void 0 }, y: { formatter: void 0, title: { formatter: function(e) {
        return e ? e + ": " : "";
      } } }, z: { formatter: void 0, title: "Size: " }, marker: { show: !0, fillColors: void 0 }, items: { display: "flex" }, fixed: { enabled: !1, position: "topRight", offsetX: 0, offsetY: 0 } }, xaxis: { type: "category", categories: [], convertedCatToNumeric: !1, offsetX: 0, offsetY: 0, overwriteCategories: void 0, labels: { show: !0, rotate: -45, rotateAlways: !1, hideOverlappingLabels: !0, trim: !1, minHeight: void 0, maxHeight: 120, showDuplicates: !0, style: { colors: [], fontSize: "12px", fontWeight: 400, fontFamily: void 0, cssClass: "" }, offsetX: 0, offsetY: 0, format: void 0, formatter: void 0, datetimeUTC: !0, datetimeFormatter: { year: "yyyy", month: "MMM 'yy", day: "dd MMM", hour: "HH:mm", minute: "HH:mm:ss", second: "HH:mm:ss" } }, group: { groups: [], style: { colors: [], fontSize: "12px", fontWeight: 400, fontFamily: void 0, cssClass: "" } }, axisBorder: { show: !0, color: "#e0e0e0", width: "100%", height: 1, offsetX: 0, offsetY: 0 }, axisTicks: { show: !0, color: "#e0e0e0", height: 6, offsetX: 0, offsetY: 0 }, stepSize: void 0, tickAmount: void 0, tickPlacement: "on", min: void 0, max: void 0, range: void 0, floating: !1, decimalsInFloat: void 0, position: "bottom", title: { text: void 0, offsetX: 0, offsetY: 0, style: { color: void 0, fontSize: "12px", fontWeight: 900, fontFamily: void 0, cssClass: "" } }, crosshairs: { show: !0, width: 1, position: "back", opacity: 0.9, stroke: { color: "#b6b6b6", width: 1, dashArray: 3 }, fill: { type: "solid", color: "#B1B9C4", gradient: { colorFrom: "#D8E3F0", colorTo: "#BED1E6", stops: [0, 100], opacityFrom: 0.4, opacityTo: 0.5 } }, dropShadow: { enabled: !1, left: 0, top: 0, blur: 1, opacity: 0.4 } }, tooltip: { enabled: !0, offsetY: 0, formatter: void 0, style: { fontSize: "12px", fontFamily: void 0 } } }, yaxis: this.yAxis, theme: { mode: "", palette: "palette1", monochrome: { enabled: !1, color: "#008FFB", shadeTo: "light", shadeIntensity: 0.65 } } };
    } }]), y;
  }(), mt = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.graphics = new X(this.ctx), this.w.globals.isBarHorizontal && (this.invertAxis = !0), this.helpers = new Le(this), this.xAxisAnnotations = new ft(this), this.yAxisAnnotations = new xt(this), this.pointsAnnotations = new bt(this), this.w.globals.isBarHorizontal && this.w.config.yaxis[0].reversed && (this.inversedReversedAxis = !0), this.xDivision = this.w.globals.gridWidth / this.w.globals.dataPoints;
    }
    return F(y, [{ key: "drawAxesAnnotations", value: function() {
      var e = this.w;
      if (e.globals.axisCharts && e.globals.dataPoints) {
        for (var t = this.yAxisAnnotations.drawYAxisAnnotations(), i = this.xAxisAnnotations.drawXAxisAnnotations(), a = this.pointsAnnotations.drawPointAnnotations(), r = e.config.chart.animations.enabled, s = [t, i, a], n = [i.node, t.node, a.node], o = 0; o < 3; o++)
          e.globals.dom.elGraphical.add(s[o]), !r || e.globals.resized || e.globals.dataChanged || e.config.chart.type !== "scatter" && e.config.chart.type !== "bubble" && e.globals.dataPoints > 1 && n[o].classList.add("apexcharts-element-hidden"), e.globals.delayedElements.push({ el: n[o], index: 0 });
        this.helpers.annotationsBackground();
      }
    } }, { key: "drawImageAnnos", value: function() {
      var e = this;
      this.w.config.annotations.images.map(function(t, i) {
        e.addImage(t, i);
      });
    } }, { key: "drawTextAnnos", value: function() {
      var e = this;
      this.w.config.annotations.texts.map(function(t, i) {
        e.addText(t, i);
      });
    } }, { key: "addXaxisAnnotation", value: function(e, t, i) {
      this.xAxisAnnotations.addXaxisAnnotation(e, t, i);
    } }, { key: "addYaxisAnnotation", value: function(e, t, i) {
      this.yAxisAnnotations.addYaxisAnnotation(e, t, i);
    } }, { key: "addPointAnnotation", value: function(e, t, i) {
      this.pointsAnnotations.addPointAnnotation(e, t, i);
    } }, { key: "addText", value: function(e, t) {
      var i = e.x, a = e.y, r = e.text, s = e.textAnchor, n = e.foreColor, o = e.fontSize, h = e.fontFamily, d = e.fontWeight, c = e.cssClass, g = e.backgroundColor, p = e.borderWidth, x = e.strokeDashArray, f = e.borderRadius, m = e.borderColor, v = e.appendTo, w = v === void 0 ? ".apexcharts-svg" : v, l = e.paddingLeft, u = l === void 0 ? 4 : l, b = e.paddingRight, A = b === void 0 ? 4 : b, k = e.paddingBottom, S = k === void 0 ? 2 : k, C = e.paddingTop, L = C === void 0 ? 2 : C, M = this.w, T = this.graphics.drawText({ x: i, y: a, text: r, textAnchor: s || "start", fontSize: o || "12px", fontWeight: d || "regular", fontFamily: h || M.config.chart.fontFamily, foreColor: n || M.config.chart.foreColor, cssClass: c }), I = M.globals.dom.baseEl.querySelector(w);
      I && I.appendChild(T.node);
      var z = T.bbox();
      if (r) {
        var Y = this.graphics.drawRect(z.x - u, z.y - L, z.width + u + A, z.height + S + L, f, g || "transparent", 1, p, m, x);
        I.insertBefore(Y.node, T.node);
      }
    } }, { key: "addImage", value: function(e, t) {
      var i = this.w, a = e.path, r = e.x, s = r === void 0 ? 0 : r, n = e.y, o = n === void 0 ? 0 : n, h = e.width, d = h === void 0 ? 20 : h, c = e.height, g = c === void 0 ? 20 : c, p = e.appendTo, x = p === void 0 ? ".apexcharts-svg" : p, f = i.globals.dom.Paper.image(a);
      f.size(d, g).move(s, o);
      var m = i.globals.dom.baseEl.querySelector(x);
      return m && m.appendChild(f.node), f;
    } }, { key: "addXaxisAnnotationExternal", value: function(e, t, i) {
      return this.addAnnotationExternal({ params: e, pushToMemory: t, context: i, type: "xaxis", contextMethod: i.addXaxisAnnotation }), i;
    } }, { key: "addYaxisAnnotationExternal", value: function(e, t, i) {
      return this.addAnnotationExternal({ params: e, pushToMemory: t, context: i, type: "yaxis", contextMethod: i.addYaxisAnnotation }), i;
    } }, { key: "addPointAnnotationExternal", value: function(e, t, i) {
      return this.invertAxis === void 0 && (this.invertAxis = i.w.globals.isBarHorizontal), this.addAnnotationExternal({ params: e, pushToMemory: t, context: i, type: "point", contextMethod: i.addPointAnnotation }), i;
    } }, { key: "addAnnotationExternal", value: function(e) {
      var t = e.params, i = e.pushToMemory, a = e.context, r = e.type, s = e.contextMethod, n = a, o = n.w, h = o.globals.dom.baseEl.querySelector(".apexcharts-".concat(r, "-annotations")), d = h.childNodes.length + 1, c = new ce(), g = Object.assign({}, r === "xaxis" ? c.xAxisAnnotation : r === "yaxis" ? c.yAxisAnnotation : c.pointAnnotation), p = P.extend(g, t);
      switch (r) {
        case "xaxis":
          this.addXaxisAnnotation(p, h, d);
          break;
        case "yaxis":
          this.addYaxisAnnotation(p, h, d);
          break;
        case "point":
          this.addPointAnnotation(p, h, d);
      }
      var x = o.globals.dom.baseEl.querySelector(".apexcharts-".concat(r, "-annotations .apexcharts-").concat(r, "-annotation-label[rel='").concat(d, "']")), f = this.helpers.addBackgroundToAnno(x, p);
      return f && h.insertBefore(f.node, x), i && o.globals.memory.methodsToExec.push({ context: n, id: p.id ? p.id : P.randomId(), method: s, label: "addAnnotation", params: t }), a;
    } }, { key: "clearAnnotations", value: function(e) {
      for (var t = e.w, i = t.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxis-annotations, .apexcharts-xaxis-annotations, .apexcharts-point-annotations"), a = t.globals.memory.methodsToExec.length - 1; a >= 0; a--)
        t.globals.memory.methodsToExec[a].label !== "addText" && t.globals.memory.methodsToExec[a].label !== "addAnnotation" || t.globals.memory.methodsToExec.splice(a, 1);
      i = P.listToArray(i), Array.prototype.forEach.call(i, function(r) {
        for (; r.firstChild; )
          r.removeChild(r.firstChild);
      });
    } }, { key: "removeAnnotation", value: function(e, t) {
      var i = e.w, a = i.globals.dom.baseEl.querySelectorAll(".".concat(t));
      a && (i.globals.memory.methodsToExec.map(function(r, s) {
        r.id === t && i.globals.memory.methodsToExec.splice(s, 1);
      }), Array.prototype.forEach.call(a, function(r) {
        r.parentElement.removeChild(r);
      }));
    } }]), y;
  }(), Ee = function(y) {
    var e, t = y.isTimeline, i = y.ctx, a = y.seriesIndex, r = y.dataPointIndex, s = y.y1, n = y.y2, o = y.w, h = o.globals.seriesRangeStart[a][r], d = o.globals.seriesRangeEnd[a][r], c = o.globals.labels[r], g = o.config.series[a].name ? o.config.series[a].name : "", p = o.globals.ttKeyFormatter, x = o.config.tooltip.y.title.formatter, f = { w: o, seriesIndex: a, dataPointIndex: r, start: h, end: d };
    typeof x == "function" && (g = x(g, f)), (e = o.config.series[a].data[r]) !== null && e !== void 0 && e.x && (c = o.config.series[a].data[r].x), t || o.config.xaxis.type === "datetime" && (c = new me(i).xLabelFormat(o.globals.ttKeyFormatter, c, c, { i: void 0, dateFormatter: new K(i).formatDate, w: o })), typeof p == "function" && (c = p(c, f)), Number.isFinite(s) && Number.isFinite(n) && (h = s, d = n);
    var m = "", v = "", w = o.globals.colors[a];
    if (o.config.tooltip.x.formatter === void 0)
      if (o.config.xaxis.type === "datetime") {
        var l = new K(i);
        m = l.formatDate(l.getDate(h), o.config.tooltip.x.format), v = l.formatDate(l.getDate(d), o.config.tooltip.x.format);
      } else
        m = h, v = d;
    else
      m = o.config.tooltip.x.formatter(h), v = o.config.tooltip.x.formatter(d);
    return { start: h, end: d, startVal: m, endVal: v, ylabel: c, color: w, seriesName: g };
  }, Ye = function(y) {
    var e = y.color, t = y.seriesName, i = y.ylabel, a = y.start, r = y.end, s = y.seriesIndex, n = y.dataPointIndex, o = y.ctx.tooltip.tooltipLabels.getFormatters(s);
    a = o.yLbFormatter(a), r = o.yLbFormatter(r);
    var h = o.yLbFormatter(y.w.globals.series[s][n]), d = `<span class="value start-value">
  `.concat(a, `
  </span> <span class="separator">-</span> <span class="value end-value">
  `).concat(r, `
  </span>`);
    return '<div class="apexcharts-tooltip-rangebar"><div> <span class="series-name" style="color: ' + e + '">' + (t || "") + '</span></div><div> <span class="category">' + i + ": </span> " + (y.w.globals.comboCharts ? y.w.config.series[s].type === "rangeArea" || y.w.config.series[s].type === "rangeBar" ? d : "<span>".concat(h, "</span>") : d) + " </div></div>";
  }, ve = function() {
    function y(e) {
      R(this, y), this.opts = e;
    }
    return F(y, [{ key: "hideYAxis", value: function() {
      this.opts.yaxis[0].show = !1, this.opts.yaxis[0].title.text = "", this.opts.yaxis[0].axisBorder.show = !1, this.opts.yaxis[0].axisTicks.show = !1, this.opts.yaxis[0].floating = !0;
    } }, { key: "line", value: function() {
      return { chart: { animations: { easing: "swing" } }, dataLabels: { enabled: !1 }, stroke: { width: 5, curve: "straight" }, markers: { size: 0, hover: { sizeOffset: 6 } }, xaxis: { crosshairs: { width: 1 } } };
    } }, { key: "sparkline", value: function(e) {
      return this.hideYAxis(), P.extend(e, { grid: { show: !1, padding: { left: 0, right: 0, top: 0, bottom: 0 } }, legend: { show: !1 }, xaxis: { labels: { show: !1 }, tooltip: { enabled: !1 }, axisBorder: { show: !1 }, axisTicks: { show: !1 } }, chart: { toolbar: { show: !1 }, zoom: { enabled: !1 } }, dataLabels: { enabled: !1 } });
    } }, { key: "slope", value: function() {
      return this.hideYAxis(), { chart: { toolbar: { show: !1 }, zoom: { enabled: !1 } }, dataLabels: { enabled: !0, formatter: function(e, t) {
        var i = t.w.config.series[t.seriesIndex].name;
        return e !== null ? i + ": " + e : "";
      }, background: { enabled: !1 }, offsetX: -5 }, grid: { xaxis: { lines: { show: !0 } }, yaxis: { lines: { show: !1 } } }, xaxis: { position: "top", labels: { style: { fontSize: 14, fontWeight: 900 } }, tooltip: { enabled: !1 }, crosshairs: { show: !1 } }, markers: { size: 8, hover: { sizeOffset: 1 } }, legend: { show: !1 }, tooltip: { shared: !1, intersect: !0, followCursor: !0 }, stroke: { width: 5, curve: "straight" } };
    } }, { key: "bar", value: function() {
      return { chart: { stacked: !1, animations: { easing: "swing" } }, plotOptions: { bar: { dataLabels: { position: "center" } } }, dataLabels: { style: { colors: ["#fff"] }, background: { enabled: !1 } }, stroke: { width: 0, lineCap: "round" }, fill: { opacity: 0.85 }, legend: { markers: { shape: "square" } }, tooltip: { shared: !1, intersect: !0 }, xaxis: { tooltip: { enabled: !1 }, tickPlacement: "between", crosshairs: { width: "barWidth", position: "back", fill: { type: "gradient" }, dropShadow: { enabled: !1 }, stroke: { width: 0 } } } };
    } }, { key: "funnel", value: function() {
      return this.hideYAxis(), E(E({}, this.bar()), {}, { chart: { animations: { easing: "linear", speed: 800, animateGradually: { enabled: !1 } } }, plotOptions: { bar: { horizontal: !0, borderRadiusApplication: "around", borderRadius: 0, dataLabels: { position: "center" } } }, grid: { show: !1, padding: { left: 0, right: 0 } }, xaxis: { labels: { show: !1 }, tooltip: { enabled: !1 }, axisBorder: { show: !1 }, axisTicks: { show: !1 } } });
    } }, { key: "candlestick", value: function() {
      var e = this;
      return { stroke: { width: 1, colors: ["#333"] }, fill: { opacity: 1 }, dataLabels: { enabled: !1 }, tooltip: { shared: !0, custom: function(t) {
        var i = t.seriesIndex, a = t.dataPointIndex, r = t.w;
        return e._getBoxTooltip(r, i, a, ["Open", "High", "", "Low", "Close"], "candlestick");
      } }, states: { active: { filter: { type: "none" } } }, xaxis: { crosshairs: { width: 1 } } };
    } }, { key: "boxPlot", value: function() {
      var e = this;
      return { chart: { animations: { dynamicAnimation: { enabled: !1 } } }, stroke: { width: 1, colors: ["#24292e"] }, dataLabels: { enabled: !1 }, tooltip: { shared: !0, custom: function(t) {
        var i = t.seriesIndex, a = t.dataPointIndex, r = t.w;
        return e._getBoxTooltip(r, i, a, ["Minimum", "Q1", "Median", "Q3", "Maximum"], "boxPlot");
      } }, markers: { size: 7, strokeWidth: 1, strokeColors: "#111" }, xaxis: { crosshairs: { width: 1 } } };
    } }, { key: "rangeBar", value: function() {
      return { chart: { animations: { animateGradually: !1 } }, stroke: { width: 0, lineCap: "square" }, plotOptions: { bar: { borderRadius: 0, dataLabels: { position: "center" } } }, dataLabels: { enabled: !1, formatter: function(e, t) {
        t.ctx;
        var i = t.seriesIndex, a = t.dataPointIndex, r = t.w, s = function() {
          var n = r.globals.seriesRangeStart[i][a];
          return r.globals.seriesRangeEnd[i][a] - n;
        };
        return r.globals.comboCharts ? r.config.series[i].type === "rangeBar" || r.config.series[i].type === "rangeArea" ? s() : e : s();
      }, background: { enabled: !1 }, style: { colors: ["#fff"] } }, markers: { size: 10 }, tooltip: { shared: !1, followCursor: !0, custom: function(e) {
        return e.w.config.plotOptions && e.w.config.plotOptions.bar && e.w.config.plotOptions.bar.horizontal ? function(t) {
          var i = Ee(E(E({}, t), {}, { isTimeline: !0 })), a = i.color, r = i.seriesName, s = i.ylabel, n = i.startVal, o = i.endVal;
          return Ye(E(E({}, t), {}, { color: a, seriesName: r, ylabel: s, start: n, end: o }));
        }(e) : function(t) {
          var i = Ee(t), a = i.color, r = i.seriesName, s = i.ylabel, n = i.start, o = i.end;
          return Ye(E(E({}, t), {}, { color: a, seriesName: r, ylabel: s, start: n, end: o }));
        }(e);
      } }, xaxis: { tickPlacement: "between", tooltip: { enabled: !1 }, crosshairs: { stroke: { width: 0 } } } };
    } }, { key: "dumbbell", value: function(e) {
      var t, i;
      return (t = e.plotOptions.bar) !== null && t !== void 0 && t.barHeight || (e.plotOptions.bar.barHeight = 2), (i = e.plotOptions.bar) !== null && i !== void 0 && i.columnWidth || (e.plotOptions.bar.columnWidth = 2), e;
    } }, { key: "area", value: function() {
      return { stroke: { width: 4, fill: { type: "solid", gradient: { inverseColors: !1, shade: "light", type: "vertical", opacityFrom: 0.65, opacityTo: 0.5, stops: [0, 100, 100] } } }, fill: { type: "gradient", gradient: { inverseColors: !1, shade: "light", type: "vertical", opacityFrom: 0.65, opacityTo: 0.5, stops: [0, 100, 100] } }, markers: { size: 0, hover: { sizeOffset: 6 } }, tooltip: { followCursor: !1 } };
    } }, { key: "rangeArea", value: function() {
      return { stroke: { curve: "straight", width: 0 }, fill: { type: "solid", opacity: 0.6 }, markers: { size: 0 }, states: { hover: { filter: { type: "none" } }, active: { filter: { type: "none" } } }, tooltip: { intersect: !1, shared: !0, followCursor: !0, custom: function(e) {
        return function(t) {
          var i = Ee(t), a = i.color, r = i.seriesName, s = i.ylabel, n = i.start, o = i.end;
          return Ye(E(E({}, t), {}, { color: a, seriesName: r, ylabel: s, start: n, end: o }));
        }(e);
      } } };
    } }, { key: "brush", value: function(e) {
      return P.extend(e, { chart: { toolbar: { autoSelected: "selection", show: !1 }, zoom: { enabled: !1 } }, dataLabels: { enabled: !1 }, stroke: { width: 1 }, tooltip: { enabled: !1 }, xaxis: { tooltip: { enabled: !1 } } });
    } }, { key: "stacked100", value: function(e) {
      e.dataLabels = e.dataLabels || {}, e.dataLabels.formatter = e.dataLabels.formatter || void 0;
      var t = e.dataLabels.formatter;
      return e.yaxis.forEach(function(i, a) {
        e.yaxis[a].min = 0, e.yaxis[a].max = 100;
      }), e.chart.type === "bar" && (e.dataLabels.formatter = t || function(i) {
        return typeof i == "number" && i ? i.toFixed(0) + "%" : i;
      }), e;
    } }, { key: "stackedBars", value: function() {
      var e = this.bar();
      return E(E({}, e), {}, { plotOptions: E(E({}, e.plotOptions), {}, { bar: E(E({}, e.plotOptions.bar), {}, { borderRadiusApplication: "end", borderRadiusWhenStacked: "last" }) }) });
    } }, { key: "convertCatToNumeric", value: function(e) {
      return e.xaxis.convertedCatToNumeric = !0, e;
    } }, { key: "convertCatToNumericXaxis", value: function(e, t, i) {
      e.xaxis.type = "numeric", e.xaxis.labels = e.xaxis.labels || {}, e.xaxis.labels.formatter = e.xaxis.labels.formatter || function(s) {
        return P.isNumber(s) ? Math.floor(s) : s;
      };
      var a = e.xaxis.labels.formatter, r = e.xaxis.categories && e.xaxis.categories.length ? e.xaxis.categories : e.labels;
      return i && i.length && (r = i.map(function(s) {
        return Array.isArray(s) ? s : String(s);
      })), r && r.length && (e.xaxis.labels.formatter = function(s) {
        return P.isNumber(s) ? a(r[Math.floor(s) - 1]) : a(s);
      }), e.xaxis.categories = [], e.labels = [], e.xaxis.tickAmount = e.xaxis.tickAmount || "dataPoints", e;
    } }, { key: "bubble", value: function() {
      return { dataLabels: { style: { colors: ["#fff"] } }, tooltip: { shared: !1, intersect: !0 }, xaxis: { crosshairs: { width: 0 } }, fill: { type: "solid", gradient: { shade: "light", inverse: !0, shadeIntensity: 0.55, opacityFrom: 0.4, opacityTo: 0.8 } } };
    } }, { key: "scatter", value: function() {
      return { dataLabels: { enabled: !1 }, tooltip: { shared: !1, intersect: !0 }, markers: { size: 6, strokeWidth: 1, hover: { sizeOffset: 2 } } };
    } }, { key: "heatmap", value: function() {
      return { chart: { stacked: !1 }, fill: { opacity: 1 }, dataLabels: { style: { colors: ["#fff"] } }, stroke: { colors: ["#fff"] }, tooltip: { followCursor: !0, marker: { show: !1 }, x: { show: !1 } }, legend: { position: "top", markers: { shape: "square" } }, grid: { padding: { right: 20 } } };
    } }, { key: "treemap", value: function() {
      return { chart: { zoom: { enabled: !1 } }, dataLabels: { style: { fontSize: 14, fontWeight: 600, colors: ["#fff"] } }, stroke: { show: !0, width: 2, colors: ["#fff"] }, legend: { show: !1 }, fill: { opacity: 1, gradient: { stops: [0, 100] } }, tooltip: { followCursor: !0, x: { show: !1 } }, grid: { padding: { left: 0, right: 0 } }, xaxis: { crosshairs: { show: !1 }, tooltip: { enabled: !1 } } };
    } }, { key: "pie", value: function() {
      return { chart: { toolbar: { show: !1 } }, plotOptions: { pie: { donut: { labels: { show: !1 } } } }, dataLabels: { formatter: function(e) {
        return e.toFixed(1) + "%";
      }, style: { colors: ["#fff"] }, background: { enabled: !1 }, dropShadow: { enabled: !0 } }, stroke: { colors: ["#fff"] }, fill: { opacity: 1, gradient: { shade: "light", stops: [0, 100] } }, tooltip: { theme: "dark", fillSeriesColor: !0 }, legend: { position: "right" }, grid: { padding: { left: 0, right: 0, top: 0, bottom: 0 } } };
    } }, { key: "donut", value: function() {
      return { chart: { toolbar: { show: !1 } }, dataLabels: { formatter: function(e) {
        return e.toFixed(1) + "%";
      }, style: { colors: ["#fff"] }, background: { enabled: !1 }, dropShadow: { enabled: !0 } }, stroke: { colors: ["#fff"] }, fill: { opacity: 1, gradient: { shade: "light", shadeIntensity: 0.35, stops: [80, 100], opacityFrom: 1, opacityTo: 1 } }, tooltip: { theme: "dark", fillSeriesColor: !0 }, legend: { position: "right" }, grid: { padding: { left: 0, right: 0, top: 0, bottom: 0 } } };
    } }, { key: "polarArea", value: function() {
      return { chart: { toolbar: { show: !1 } }, dataLabels: { formatter: function(e) {
        return e.toFixed(1) + "%";
      }, enabled: !1 }, stroke: { show: !0, width: 2 }, fill: { opacity: 0.7 }, tooltip: { theme: "dark", fillSeriesColor: !0 }, legend: { position: "right" }, grid: { padding: { left: 0, right: 0, top: 0, bottom: 0 } } };
    } }, { key: "radar", value: function() {
      return this.opts.yaxis[0].labels.offsetY = this.opts.yaxis[0].labels.offsetY ? this.opts.yaxis[0].labels.offsetY : 6, { dataLabels: { enabled: !1, style: { fontSize: "11px" } }, stroke: { width: 2 }, markers: { size: 5, strokeWidth: 1, strokeOpacity: 1 }, fill: { opacity: 0.2 }, tooltip: { shared: !1, intersect: !0, followCursor: !0 }, grid: { show: !1, padding: { left: 0, right: 0, top: 0, bottom: 0 } }, xaxis: { labels: { formatter: function(e) {
        return e;
      }, style: { colors: ["#a8a8a8"], fontSize: "11px" } }, tooltip: { enabled: !1 }, crosshairs: { show: !1 } } };
    } }, { key: "radialBar", value: function() {
      return { chart: { animations: { dynamicAnimation: { enabled: !0, speed: 800 } }, toolbar: { show: !1 } }, fill: { gradient: { shade: "dark", shadeIntensity: 0.4, inverseColors: !1, type: "diagonal2", opacityFrom: 1, opacityTo: 1, stops: [70, 98, 100] } }, legend: { show: !1, position: "right" }, tooltip: { enabled: !1, fillSeriesColor: !0 }, grid: { padding: { left: 0, right: 0, top: 0, bottom: 0 } } };
    } }, { key: "_getBoxTooltip", value: function(e, t, i, a, r) {
      var s = e.globals.seriesCandleO[t][i], n = e.globals.seriesCandleH[t][i], o = e.globals.seriesCandleM[t][i], h = e.globals.seriesCandleL[t][i], d = e.globals.seriesCandleC[t][i];
      return e.config.series[t].type && e.config.series[t].type !== r ? `<div class="apexcharts-custom-tooltip">
          `.concat(e.config.series[t].name ? e.config.series[t].name : "series-" + (t + 1), ": <strong>").concat(e.globals.series[t][i], `</strong>
        </div>`) : '<div class="apexcharts-tooltip-box apexcharts-tooltip-'.concat(e.config.chart.type, '">') + "<div>".concat(a[0], ': <span class="value">') + s + "</span></div>" + "<div>".concat(a[1], ': <span class="value">') + n + "</span></div>" + (o ? "<div>".concat(a[2], ': <span class="value">') + o + "</span></div>" : "") + "<div>".concat(a[3], ': <span class="value">') + h + "</span></div>" + "<div>".concat(a[4], ': <span class="value">') + d + "</span></div></div>";
    } }]), y;
  }(), ye = function() {
    function y(e) {
      R(this, y), this.opts = e;
    }
    return F(y, [{ key: "init", value: function(e) {
      var t = e.responsiveOverride, i = this.opts, a = new ce(), r = new ve(i);
      this.chartType = i.chart.type, i = this.extendYAxis(i), i = this.extendAnnotations(i);
      var s = a.init(), n = {};
      if (i && Q(i) === "object") {
        var o, h, d, c, g, p, x, f, m, v, w = {};
        w = ["line", "area", "bar", "candlestick", "boxPlot", "rangeBar", "rangeArea", "bubble", "scatter", "heatmap", "treemap", "pie", "polarArea", "donut", "radar", "radialBar"].indexOf(i.chart.type) !== -1 ? r[i.chart.type]() : r.line(), (o = i.plotOptions) !== null && o !== void 0 && (h = o.bar) !== null && h !== void 0 && h.isFunnel && (w = r.funnel()), i.chart.stacked && i.chart.type === "bar" && (w = r.stackedBars()), (d = i.chart.brush) !== null && d !== void 0 && d.enabled && (w = r.brush(w)), (c = i.plotOptions) !== null && c !== void 0 && (g = c.line) !== null && g !== void 0 && g.isSlopeChart && (w = r.slope()), i.chart.stacked && i.chart.stackType === "100%" && (i = r.stacked100(i)), (p = i.plotOptions) !== null && p !== void 0 && (x = p.bar) !== null && x !== void 0 && x.isDumbbell && (i = r.dumbbell(i)), this.checkForDarkTheme(window.Apex), this.checkForDarkTheme(i), i.xaxis = i.xaxis || window.Apex.xaxis || {}, t || (i.xaxis.convertedCatToNumeric = !1), ((f = (i = this.checkForCatToNumericXAxis(this.chartType, w, i)).chart.sparkline) !== null && f !== void 0 && f.enabled || (m = window.Apex.chart) !== null && m !== void 0 && (v = m.sparkline) !== null && v !== void 0 && v.enabled) && (w = r.sparkline(w)), n = P.extend(s, w);
      }
      var l = P.extend(n, window.Apex);
      return s = P.extend(l, i), s = this.handleUserInputErrors(s);
    } }, { key: "checkForCatToNumericXAxis", value: function(e, t, i) {
      var a, r, s = new ve(i), n = (e === "bar" || e === "boxPlot") && ((a = i.plotOptions) === null || a === void 0 || (r = a.bar) === null || r === void 0 ? void 0 : r.horizontal), o = e === "pie" || e === "polarArea" || e === "donut" || e === "radar" || e === "radialBar" || e === "heatmap", h = i.xaxis.type !== "datetime" && i.xaxis.type !== "numeric", d = i.xaxis.tickPlacement ? i.xaxis.tickPlacement : t.xaxis && t.xaxis.tickPlacement;
      return n || o || !h || d === "between" || (i = s.convertCatToNumeric(i)), i;
    } }, { key: "extendYAxis", value: function(e, t) {
      var i = new ce();
      (e.yaxis === void 0 || !e.yaxis || Array.isArray(e.yaxis) && e.yaxis.length === 0) && (e.yaxis = {}), e.yaxis.constructor !== Array && window.Apex.yaxis && window.Apex.yaxis.constructor !== Array && (e.yaxis = P.extend(e.yaxis, window.Apex.yaxis)), e.yaxis.constructor !== Array ? e.yaxis = [P.extend(i.yAxis, e.yaxis)] : e.yaxis = P.extendArray(e.yaxis, i.yAxis);
      var a = !1;
      e.yaxis.forEach(function(s) {
        s.logarithmic && (a = !0);
      });
      var r = e.series;
      return t && !r && (r = t.config.series), a && r.length !== e.yaxis.length && r.length && (e.yaxis = r.map(function(s, n) {
        if (s.name || (r[n].name = "series-".concat(n + 1)), e.yaxis[n])
          return e.yaxis[n].seriesName = r[n].name, e.yaxis[n];
        var o = P.extend(i.yAxis, e.yaxis[0]);
        return o.show = !1, o;
      })), a && r.length > 1 && r.length !== e.yaxis.length && console.warn("A multi-series logarithmic chart should have equal number of series and y-axes"), e;
    } }, { key: "extendAnnotations", value: function(e) {
      return e.annotations === void 0 && (e.annotations = {}, e.annotations.yaxis = [], e.annotations.xaxis = [], e.annotations.points = []), e = this.extendYAxisAnnotations(e), e = this.extendXAxisAnnotations(e), e = this.extendPointAnnotations(e);
    } }, { key: "extendYAxisAnnotations", value: function(e) {
      var t = new ce();
      return e.annotations.yaxis = P.extendArray(e.annotations.yaxis !== void 0 ? e.annotations.yaxis : [], t.yAxisAnnotation), e;
    } }, { key: "extendXAxisAnnotations", value: function(e) {
      var t = new ce();
      return e.annotations.xaxis = P.extendArray(e.annotations.xaxis !== void 0 ? e.annotations.xaxis : [], t.xAxisAnnotation), e;
    } }, { key: "extendPointAnnotations", value: function(e) {
      var t = new ce();
      return e.annotations.points = P.extendArray(e.annotations.points !== void 0 ? e.annotations.points : [], t.pointAnnotation), e;
    } }, { key: "checkForDarkTheme", value: function(e) {
      e.theme && e.theme.mode === "dark" && (e.tooltip || (e.tooltip = {}), e.tooltip.theme !== "light" && (e.tooltip.theme = "dark"), e.chart.foreColor || (e.chart.foreColor = "#f6f7f8"), e.theme.palette || (e.theme.palette = "palette4"));
    } }, { key: "handleUserInputErrors", value: function(e) {
      var t = e;
      if (t.tooltip.shared && t.tooltip.intersect)
        throw new Error("tooltip.shared cannot be enabled when tooltip.intersect is true. Turn off any other option by setting it to false.");
      if (t.chart.type === "bar" && t.plotOptions.bar.horizontal) {
        if (t.yaxis.length > 1)
          throw new Error("Multiple Y Axis for bars are not supported. Switch to column chart by setting plotOptions.bar.horizontal=false");
        t.yaxis[0].reversed && (t.yaxis[0].opposite = !0), t.xaxis.tooltip.enabled = !1, t.yaxis[0].tooltip.enabled = !1, t.chart.zoom.enabled = !1;
      }
      return t.chart.type !== "bar" && t.chart.type !== "rangeBar" || t.tooltip.shared && t.xaxis.crosshairs.width === "barWidth" && t.series.length > 1 && (t.xaxis.crosshairs.width = "tickWidth"), t.chart.type !== "candlestick" && t.chart.type !== "boxPlot" || t.yaxis[0].reversed && (console.warn("Reversed y-axis in ".concat(t.chart.type, " chart is not supported.")), t.yaxis[0].reversed = !1), t;
    } }]), y;
  }(), Qe = function() {
    function y() {
      R(this, y);
    }
    return F(y, [{ key: "initGlobalVars", value: function(e) {
      e.series = [], e.seriesCandleO = [], e.seriesCandleH = [], e.seriesCandleM = [], e.seriesCandleL = [], e.seriesCandleC = [], e.seriesRangeStart = [], e.seriesRangeEnd = [], e.seriesRange = [], e.seriesPercent = [], e.seriesGoals = [], e.seriesX = [], e.seriesZ = [], e.seriesNames = [], e.seriesTotals = [], e.seriesLog = [], e.seriesColors = [], e.stackedSeriesTotals = [], e.seriesXvalues = [], e.seriesYvalues = [], e.labels = [], e.hasXaxisGroups = !1, e.groups = [], e.barGroups = [], e.lineGroups = [], e.areaGroups = [], e.hasSeriesGroups = !1, e.seriesGroups = [], e.categoryLabels = [], e.timescaleLabels = [], e.noLabelsProvided = !1, e.resizeTimer = null, e.selectionResizeTimer = null, e.lastWheelExecution = 0, e.delayedElements = [], e.pointsArray = [], e.dataLabelsRects = [], e.isXNumeric = !1, e.skipLastTimelinelabel = !1, e.skipFirstTimelinelabel = !1, e.isDataXYZ = !1, e.isMultiLineX = !1, e.isMultipleYAxis = !1, e.maxY = -Number.MAX_VALUE, e.minY = Number.MIN_VALUE, e.minYArr = [], e.maxYArr = [], e.maxX = -Number.MAX_VALUE, e.minX = Number.MAX_VALUE, e.initialMaxX = -Number.MAX_VALUE, e.initialMinX = Number.MAX_VALUE, e.maxDate = 0, e.minDate = Number.MAX_VALUE, e.minZ = Number.MAX_VALUE, e.maxZ = -Number.MAX_VALUE, e.minXDiff = Number.MAX_VALUE, e.yAxisScale = [], e.xAxisScale = null, e.xAxisTicksPositions = [], e.yLabelsCoords = [], e.yTitleCoords = [], e.barPadForNumericAxis = 0, e.padHorizontal = 0, e.xRange = 0, e.yRange = [], e.zRange = 0, e.dataPoints = 0, e.xTickAmount = 0, e.multiAxisTickAmount = 0;
    } }, { key: "globalVars", value: function(e) {
      return { chartID: null, cuid: null, events: { beforeMount: [], mounted: [], updated: [], clicked: [], selection: [], dataPointSelection: [], zoomed: [], scrolled: [] }, colors: [], clientX: null, clientY: null, fill: { colors: [] }, stroke: { colors: [] }, dataLabels: { style: { colors: [] } }, radarPolygons: { fill: { colors: [] } }, markers: { colors: [], size: e.markers.size, largestSize: 0 }, animationEnded: !1, isTouchDevice: "ontouchstart" in window || navigator.msMaxTouchPoints, isDirty: !1, isExecCalled: !1, initialConfig: null, initialSeries: [], lastXAxis: [], lastYAxis: [], columnSeries: null, labels: [], timescaleLabels: [], noLabelsProvided: !1, allSeriesCollapsed: !1, collapsedSeries: [], collapsedSeriesIndices: [], ancillaryCollapsedSeries: [], ancillaryCollapsedSeriesIndices: [], risingSeries: [], dataFormatXNumeric: !1, capturedSeriesIndex: -1, capturedDataPointIndex: -1, selectedDataPoints: [], invalidLogScale: !1, ignoreYAxisIndexes: [], maxValsInArrayIndex: 0, radialSize: 0, selection: void 0, zoomEnabled: e.chart.toolbar.autoSelected === "zoom" && e.chart.toolbar.tools.zoom && e.chart.zoom.enabled, panEnabled: e.chart.toolbar.autoSelected === "pan" && e.chart.toolbar.tools.pan, selectionEnabled: e.chart.toolbar.autoSelected === "selection" && e.chart.toolbar.tools.selection, yaxis: null, mousedown: !1, lastClientPosition: {}, visibleXRange: void 0, yValueDecimal: 0, total: 0, SVGNS: "http://www.w3.org/2000/svg", svgWidth: 0, svgHeight: 0, noData: !1, locale: {}, dom: {}, memory: { methodsToExec: [] }, shouldAnimate: !0, skipLastTimelinelabel: !1, skipFirstTimelinelabel: !1, delayedElements: [], axisCharts: !0, isDataXYZ: !1, isSlopeChart: e.plotOptions.line.isSlopeChart, resized: !1, resizeTimer: null, comboCharts: !1, dataChanged: !1, previousPaths: [], allSeriesHasEqualX: !0, pointsArray: [], dataLabelsRects: [], lastDrawnDataLabelsIndexes: [], hasNullValues: !1, easing: null, zoomed: !1, gridWidth: 0, gridHeight: 0, rotateXLabels: !1, defaultLabels: !1, xLabelFormatter: void 0, yLabelFormatters: [], xaxisTooltipFormatter: void 0, ttKeyFormatter: void 0, ttVal: void 0, ttZFormatter: void 0, LINE_HEIGHT_RATIO: 1.618, xAxisLabelsHeight: 0, xAxisGroupLabelsHeight: 0, xAxisLabelsWidth: 0, yAxisLabelsWidth: 0, scaleX: 1, scaleY: 1, translateX: 0, translateY: 0, translateYAxisX: [], yAxisWidths: [], translateXAxisY: 0, translateXAxisX: 0, tooltip: null, niceScaleAllowedMagMsd: [[1, 1, 2, 5, 5, 5, 10, 10, 10, 10, 10], [1, 1, 2, 5, 5, 5, 10, 10, 10, 10, 10]], niceScaleDefaultTicks: [1, 2, 4, 4, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 12, 12, 12, 12, 12, 12, 12, 12, 12, 24], seriesYAxisMap: [], seriesYAxisReverseMap: [] };
    } }, { key: "init", value: function(e) {
      var t = this.globalVars(e);
      return this.initGlobalVars(t), t.initialConfig = P.extend({}, e), t.initialSeries = P.clone(e.series), t.lastXAxis = P.clone(t.initialConfig.xaxis), t.lastYAxis = P.clone(t.initialConfig.yaxis), t;
    } }]), y;
  }(), vt = function() {
    function y(e) {
      R(this, y), this.opts = e;
    }
    return F(y, [{ key: "init", value: function() {
      var e = new ye(this.opts).init({ responsiveOverride: !1 });
      return { config: e, globals: new Qe().init(e) };
    } }]), y;
  }(), ne = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.opts = null, this.seriesIndex = 0, this.patternIDs = [];
    }
    return F(y, [{ key: "clippedImgArea", value: function(e) {
      var t = this.w, i = t.config, a = parseInt(t.globals.gridWidth, 10), r = parseInt(t.globals.gridHeight, 10), s = a > r ? a : r, n = e.image, o = 0, h = 0;
      e.width === void 0 && e.height === void 0 ? i.fill.image.width !== void 0 && i.fill.image.height !== void 0 ? (o = i.fill.image.width + 1, h = i.fill.image.height) : (o = s + 1, h = s) : (o = e.width, h = e.height);
      var d = document.createElementNS(t.globals.SVGNS, "pattern");
      X.setAttrs(d, { id: e.patternID, patternUnits: e.patternUnits ? e.patternUnits : "userSpaceOnUse", width: o + "px", height: h + "px" });
      var c = document.createElementNS(t.globals.SVGNS, "image");
      d.appendChild(c), c.setAttributeNS(window.SVG.xlink, "href", n), X.setAttrs(c, { x: 0, y: 0, preserveAspectRatio: "none", width: o + "px", height: h + "px" }), c.style.opacity = e.opacity, t.globals.dom.elDefs.node.appendChild(d);
    } }, { key: "getSeriesIndex", value: function(e) {
      var t = this.w, i = t.config.chart.type;
      return (i === "bar" || i === "rangeBar") && t.config.plotOptions.bar.distributed || i === "heatmap" || i === "treemap" ? this.seriesIndex = e.seriesNumber : this.seriesIndex = e.seriesNumber % t.globals.series.length, this.seriesIndex;
    } }, { key: "fillPath", value: function(e) {
      var t = this.w;
      this.opts = e;
      var i, a, r, s = this.w.config;
      this.seriesIndex = this.getSeriesIndex(e);
      var n = this.getFillColors()[this.seriesIndex];
      t.globals.seriesColors[this.seriesIndex] !== void 0 && (n = t.globals.seriesColors[this.seriesIndex]), typeof n == "function" && (n = n({ seriesIndex: this.seriesIndex, dataPointIndex: e.dataPointIndex, value: e.value, w: t }));
      var o = e.fillType ? e.fillType : this.getFillType(this.seriesIndex), h = Array.isArray(s.fill.opacity) ? s.fill.opacity[this.seriesIndex] : s.fill.opacity;
      e.color && (n = e.color), n || (n = "#fff", console.warn("undefined color - ApexCharts"));
      var d = n;
      if (n.indexOf("rgb") === -1 ? n.length < 9 && (d = P.hexToRgba(n, h)) : n.indexOf("rgba") > -1 && (h = P.getOpacityFromRGBA(n)), e.opacity && (h = e.opacity), o === "pattern" && (a = this.handlePatternFill({ fillConfig: e.fillConfig, patternFill: a, fillColor: n, fillOpacity: h, defaultColor: d })), o === "gradient" && (r = this.handleGradientFill({ fillConfig: e.fillConfig, fillColor: n, fillOpacity: h, i: this.seriesIndex })), o === "image") {
        var c = s.fill.image.src, g = e.patternID ? e.patternID : "", p = "pattern".concat(t.globals.cuid).concat(e.seriesNumber + 1).concat(g);
        this.patternIDs.indexOf(p) === -1 && (this.clippedImgArea({ opacity: h, image: Array.isArray(c) ? e.seriesNumber < c.length ? c[e.seriesNumber] : c[0] : c, width: e.width ? e.width : void 0, height: e.height ? e.height : void 0, patternUnits: e.patternUnits, patternID: p }), this.patternIDs.push(p)), i = "url(#".concat(p, ")");
      } else
        i = o === "gradient" ? r : o === "pattern" ? a : d;
      return e.solid && (i = d), i;
    } }, { key: "getFillType", value: function(e) {
      var t = this.w;
      return Array.isArray(t.config.fill.type) ? t.config.fill.type[e] : t.config.fill.type;
    } }, { key: "getFillColors", value: function() {
      var e = this.w, t = e.config, i = this.opts, a = [];
      return e.globals.comboCharts ? e.config.series[this.seriesIndex].type === "line" ? Array.isArray(e.globals.stroke.colors) ? a = e.globals.stroke.colors : a.push(e.globals.stroke.colors) : Array.isArray(e.globals.fill.colors) ? a = e.globals.fill.colors : a.push(e.globals.fill.colors) : t.chart.type === "line" ? Array.isArray(e.globals.stroke.colors) ? a = e.globals.stroke.colors : a.push(e.globals.stroke.colors) : Array.isArray(e.globals.fill.colors) ? a = e.globals.fill.colors : a.push(e.globals.fill.colors), i.fillColors !== void 0 && (a = [], Array.isArray(i.fillColors) ? a = i.fillColors.slice() : a.push(i.fillColors)), a;
    } }, { key: "handlePatternFill", value: function(e) {
      var t = e.fillConfig, i = e.patternFill, a = e.fillColor, r = e.fillOpacity, s = e.defaultColor, n = this.w.config.fill;
      t && (n = t);
      var o = this.opts, h = new X(this.ctx), d = Array.isArray(n.pattern.strokeWidth) ? n.pattern.strokeWidth[this.seriesIndex] : n.pattern.strokeWidth, c = a;
      return Array.isArray(n.pattern.style) ? i = n.pattern.style[o.seriesNumber] !== void 0 ? h.drawPattern(n.pattern.style[o.seriesNumber], n.pattern.width, n.pattern.height, c, d, r) : s : i = h.drawPattern(n.pattern.style, n.pattern.width, n.pattern.height, c, d, r), i;
    } }, { key: "handleGradientFill", value: function(e) {
      var t = e.fillColor, i = e.fillOpacity, a = e.fillConfig, r = e.i, s = this.w.config.fill;
      a && (s = E(E({}, s), a));
      var n, o = this.opts, h = new X(this.ctx), d = new P(), c = s.gradient.type, g = t, p = s.gradient.opacityFrom === void 0 ? i : Array.isArray(s.gradient.opacityFrom) ? s.gradient.opacityFrom[r] : s.gradient.opacityFrom;
      g.indexOf("rgba") > -1 && (p = P.getOpacityFromRGBA(g));
      var x = s.gradient.opacityTo === void 0 ? i : Array.isArray(s.gradient.opacityTo) ? s.gradient.opacityTo[r] : s.gradient.opacityTo;
      if (s.gradient.gradientToColors === void 0 || s.gradient.gradientToColors.length === 0)
        n = s.gradient.shade === "dark" ? d.shadeColor(-1 * parseFloat(s.gradient.shadeIntensity), t.indexOf("rgb") > -1 ? P.rgb2hex(t) : t) : d.shadeColor(parseFloat(s.gradient.shadeIntensity), t.indexOf("rgb") > -1 ? P.rgb2hex(t) : t);
      else if (s.gradient.gradientToColors[o.seriesNumber]) {
        var f = s.gradient.gradientToColors[o.seriesNumber];
        n = f, f.indexOf("rgba") > -1 && (x = P.getOpacityFromRGBA(f));
      } else
        n = t;
      if (s.gradient.gradientFrom && (g = s.gradient.gradientFrom), s.gradient.gradientTo && (n = s.gradient.gradientTo), s.gradient.inverseColors) {
        var m = g;
        g = n, n = m;
      }
      return g.indexOf("rgb") > -1 && (g = P.rgb2hex(g)), n.indexOf("rgb") > -1 && (n = P.rgb2hex(n)), h.drawGradient(c, g, n, p, x, o.size, s.gradient.stops, s.gradient.colorStops, r);
    } }]), y;
  }(), ue = function() {
    function y(e, t) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "setGlobalMarkerSize", value: function() {
      var e = this.w;
      if (e.globals.markers.size = Array.isArray(e.config.markers.size) ? e.config.markers.size : [e.config.markers.size], e.globals.markers.size.length > 0) {
        if (e.globals.markers.size.length < e.globals.series.length + 1)
          for (var t = 0; t <= e.globals.series.length; t++)
            e.globals.markers.size[t] === void 0 && e.globals.markers.size.push(e.globals.markers.size[0]);
      } else
        e.globals.markers.size = e.config.series.map(function(i) {
          return e.config.markers.size;
        });
    } }, { key: "plotChartMarkers", value: function(e, t, i, a) {
      var r, s = arguments.length > 4 && arguments[4] !== void 0 && arguments[4], n = this.w, o = t, h = e, d = null, c = new X(this.ctx), g = n.config.markers.discrete && n.config.markers.discrete.length;
      if ((n.globals.markers.size[t] > 0 || s || g) && (d = c.group({ class: s || g ? "" : "apexcharts-series-markers" })).attr("clip-path", "url(#gridRectMarkerMask".concat(n.globals.cuid, ")")), Array.isArray(h.x))
        for (var p = 0; p < h.x.length; p++) {
          var x = i;
          i === 1 && p === 0 && (x = 0), i === 1 && p === 1 && (x = 1);
          var f = "apexcharts-marker";
          if (n.config.chart.type !== "line" && n.config.chart.type !== "area" || n.globals.comboCharts || n.config.tooltip.intersect || (f += " no-pointer-events"), (Array.isArray(n.config.markers.size) ? n.globals.markers.size[t] > 0 : n.config.markers.size > 0) || s || g) {
            P.isNumber(h.y[p]) ? f += " w".concat(P.randomId()) : f = "apexcharts-nullpoint";
            var m = this.getMarkerConfig({ cssClass: f, seriesIndex: t, dataPointIndex: x });
            n.config.series[o].data[x] && (n.config.series[o].data[x].fillColor && (m.pointFillColor = n.config.series[o].data[x].fillColor), n.config.series[o].data[x].strokeColor && (m.pointStrokeColor = n.config.series[o].data[x].strokeColor)), a !== void 0 && (m.pSize = a), (h.x[p] < -n.globals.markers.largestSize || h.x[p] > n.globals.gridWidth + n.globals.markers.largestSize || h.y[p] < -n.globals.markers.largestSize || h.y[p] > n.globals.gridHeight + n.globals.markers.largestSize) && (m.pSize = 0), (r = c.drawMarker(h.x[p], h.y[p], m)).attr("rel", x), r.attr("j", x), r.attr("index", t), r.node.setAttribute("default-marker-size", m.pSize), new ee(this.ctx).setSelectionFilter(r, t, x), this.addEvents(r), d && d.add(r);
          } else
            n.globals.pointsArray[t] === void 0 && (n.globals.pointsArray[t] = []), n.globals.pointsArray[t].push([h.x[p], h.y[p]]);
        }
      return d;
    } }, { key: "getMarkerConfig", value: function(e) {
      var t = e.cssClass, i = e.seriesIndex, a = e.dataPointIndex, r = a === void 0 ? null : a, s = e.radius, n = s === void 0 ? null : s, o = e.size, h = o === void 0 ? null : o, d = e.strokeWidth, c = d === void 0 ? null : d, g = this.w, p = this.getMarkerStyle(i), x = h === null ? g.globals.markers.size[i] : h, f = g.config.markers;
      return r !== null && f.discrete.length && f.discrete.map(function(m) {
        m.seriesIndex === i && m.dataPointIndex === r && (p.pointStrokeColor = m.strokeColor, p.pointFillColor = m.fillColor, x = m.size, p.pointShape = m.shape);
      }), { pSize: n === null ? x : n, pRadius: n !== null ? n : f.radius, pointStrokeWidth: c !== null ? c : Array.isArray(f.strokeWidth) ? f.strokeWidth[i] : f.strokeWidth, pointStrokeColor: p.pointStrokeColor, pointFillColor: p.pointFillColor, shape: p.pointShape || (Array.isArray(f.shape) ? f.shape[i] : f.shape), class: t, pointStrokeOpacity: Array.isArray(f.strokeOpacity) ? f.strokeOpacity[i] : f.strokeOpacity, pointStrokeDashArray: Array.isArray(f.strokeDashArray) ? f.strokeDashArray[i] : f.strokeDashArray, pointFillOpacity: Array.isArray(f.fillOpacity) ? f.fillOpacity[i] : f.fillOpacity, seriesIndex: i };
    } }, { key: "addEvents", value: function(e) {
      var t = this.w, i = new X(this.ctx);
      e.node.addEventListener("mouseenter", i.pathMouseEnter.bind(this.ctx, e)), e.node.addEventListener("mouseleave", i.pathMouseLeave.bind(this.ctx, e)), e.node.addEventListener("mousedown", i.pathMouseDown.bind(this.ctx, e)), e.node.addEventListener("click", t.config.markers.onClick), e.node.addEventListener("dblclick", t.config.markers.onDblClick), e.node.addEventListener("touchstart", i.pathMouseDown.bind(this.ctx, e), { passive: !0 });
    } }, { key: "getMarkerStyle", value: function(e) {
      var t = this.w, i = t.globals.markers.colors, a = t.config.markers.strokeColor || t.config.markers.strokeColors;
      return { pointStrokeColor: Array.isArray(a) ? a[e] : a, pointFillColor: Array.isArray(i) ? i[e] : i };
    } }]), y;
  }(), Ke = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.initialAnim = this.w.config.chart.animations.enabled;
    }
    return F(y, [{ key: "draw", value: function(e, t, i) {
      var a = this.w, r = new X(this.ctx), s = i.realIndex, n = i.pointsPos, o = i.zRatio, h = i.elParent, d = r.group({ class: "apexcharts-series-markers apexcharts-series-".concat(a.config.chart.type) });
      if (d.attr("clip-path", "url(#gridRectMarkerMask".concat(a.globals.cuid, ")")), Array.isArray(n.x))
        for (var c = 0; c < n.x.length; c++) {
          var g = t + 1, p = !0;
          t === 0 && c === 0 && (g = 0), t === 0 && c === 1 && (g = 1);
          var x = a.globals.markers.size[s];
          if (o !== 1 / 0) {
            var f = a.config.plotOptions.bubble;
            x = a.globals.seriesZ[s][g], f.zScaling && (x /= o), f.minBubbleRadius && x < f.minBubbleRadius && (x = f.minBubbleRadius), f.maxBubbleRadius && x > f.maxBubbleRadius && (x = f.maxBubbleRadius);
          }
          var m = n.x[c], v = n.y[c];
          if (x = x || 0, v !== null && a.globals.series[s][g] !== void 0 || (p = !1), p) {
            var w = this.drawPoint(m, v, x, s, g, t);
            d.add(w);
          }
          h.add(d);
        }
    } }, { key: "drawPoint", value: function(e, t, i, a, r, s) {
      var n = this.w, o = a, h = new ge(this.ctx), d = new ee(this.ctx), c = new ne(this.ctx), g = new ue(this.ctx), p = new X(this.ctx), x = g.getMarkerConfig({ cssClass: "apexcharts-marker", seriesIndex: o, dataPointIndex: r, radius: n.config.chart.type === "bubble" || n.globals.comboCharts && n.config.series[a] && n.config.series[a].type === "bubble" ? i : null }), f = c.fillPath({ seriesNumber: a, dataPointIndex: r, color: x.pointFillColor, patternUnits: "objectBoundingBox", value: n.globals.series[a][s] }), m = p.drawMarker(e, t, x);
      if (n.config.series[o].data[r] && n.config.series[o].data[r].fillColor && (f = n.config.series[o].data[r].fillColor), m.attr({ fill: f }), n.config.chart.dropShadow.enabled) {
        var v = n.config.chart.dropShadow;
        d.dropShadow(m, v, a);
      }
      if (!this.initialAnim || n.globals.dataChanged || n.globals.resized)
        n.globals.animationEnded = !0;
      else {
        var w = n.config.chart.animations.speed;
        h.animateMarker(m, w, n.globals.easing, function() {
          window.setTimeout(function() {
            h.animationCompleted(m);
          }, 100);
        });
      }
      return m.attr({ rel: r, j: r, index: a, "default-marker-size": x.pSize }), d.setSelectionFilter(m, a, r), g.addEvents(m), m.node.classList.add("apexcharts-marker"), m;
    } }, { key: "centerTextInBubble", value: function(e) {
      var t = this.w;
      return { y: e += parseInt(t.config.dataLabels.style.fontSize, 10) / 4 };
    } }]), y;
  }(), pe = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "dataLabelsCorrection", value: function(e, t, i, a, r, s, n) {
      var o = this.w, h = !1, d = new X(this.ctx).getTextRects(i, n), c = d.width, g = d.height;
      t < 0 && (t = 0), t > o.globals.gridHeight + g && (t = o.globals.gridHeight + g / 2), o.globals.dataLabelsRects[a] === void 0 && (o.globals.dataLabelsRects[a] = []), o.globals.dataLabelsRects[a].push({ x: e, y: t, width: c, height: g });
      var p = o.globals.dataLabelsRects[a].length - 2, x = o.globals.lastDrawnDataLabelsIndexes[a] !== void 0 ? o.globals.lastDrawnDataLabelsIndexes[a][o.globals.lastDrawnDataLabelsIndexes[a].length - 1] : 0;
      if (o.globals.dataLabelsRects[a][p] !== void 0) {
        var f = o.globals.dataLabelsRects[a][x];
        (e > f.x + f.width || t > f.y + f.height || t + g < f.y || e + c < f.x) && (h = !0);
      }
      return (r === 0 || s) && (h = !0), { x: e, y: t, textRects: d, drawnextLabel: h };
    } }, { key: "drawDataLabel", value: function(e) {
      var t = this, i = e.type, a = e.pos, r = e.i, s = e.j, n = e.isRangeStart, o = e.strokeWidth, h = o === void 0 ? 2 : o, d = this.w, c = new X(this.ctx), g = d.config.dataLabels, p = 0, x = 0, f = s, m = null;
      if (d.globals.collapsedSeriesIndices.indexOf(r) !== -1 || !g.enabled || !Array.isArray(a.x))
        return m;
      m = c.group({ class: "apexcharts-data-labels" });
      for (var v = 0; v < a.x.length; v++)
        if (p = a.x[v] + g.offsetX, x = a.y[v] + g.offsetY + h, !isNaN(p)) {
          s === 1 && v === 0 && (f = 0), s === 1 && v === 1 && (f = 1);
          var w = d.globals.series[r][f];
          i === "rangeArea" && (w = n ? d.globals.seriesRangeStart[r][f] : d.globals.seriesRangeEnd[r][f]);
          var l = "", u = function(A) {
            return d.config.dataLabels.formatter(A, { ctx: t.ctx, seriesIndex: r, dataPointIndex: f, w: d });
          };
          d.config.chart.type === "bubble" ? (l = u(w = d.globals.seriesZ[r][f]), x = a.y[v], x = new Ke(this.ctx).centerTextInBubble(x, r, f).y) : w !== void 0 && (l = u(w));
          var b = d.config.dataLabels.textAnchor;
          d.globals.isSlopeChart && (b = f === 0 ? "end" : f === d.config.series[r].data.length - 1 ? "start" : "middle"), this.plotDataLabelsText({ x: p, y: x, text: l, i: r, j: f, parent: m, offsetCorrection: !0, dataLabelsConfig: d.config.dataLabels, textAnchor: b });
        }
      return m;
    } }, { key: "plotDataLabelsText", value: function(e) {
      var t = this.w, i = new X(this.ctx), a = e.x, r = e.y, s = e.i, n = e.j, o = e.text, h = e.textAnchor, d = e.fontSize, c = e.parent, g = e.dataLabelsConfig, p = e.color, x = e.alwaysDrawDataLabel, f = e.offsetCorrection, m = e.className, v = null;
      if (Array.isArray(t.config.dataLabels.enabledOnSeries) && t.config.dataLabels.enabledOnSeries.indexOf(s) < 0)
        return v;
      var w = { x: a, y: r, drawnextLabel: !0, textRects: null };
      f && (w = this.dataLabelsCorrection(a, r, o, s, n, x, parseInt(g.style.fontSize, 10))), t.globals.zoomed || (a = w.x, r = w.y), w.textRects && (a < -20 - w.textRects.width || a > t.globals.gridWidth + w.textRects.width + 30) && (o = "");
      var l = t.globals.dataLabels.style.colors[s];
      ((t.config.chart.type === "bar" || t.config.chart.type === "rangeBar") && t.config.plotOptions.bar.distributed || t.config.dataLabels.distributed) && (l = t.globals.dataLabels.style.colors[n]), typeof l == "function" && (l = l({ series: t.globals.series, seriesIndex: s, dataPointIndex: n, w: t })), p && (l = p);
      var u = g.offsetX, b = g.offsetY;
      if (t.config.chart.type !== "bar" && t.config.chart.type !== "rangeBar" || (u = 0, b = 0), t.globals.isSlopeChart && (n !== 0 && (u = -2 * g.offsetX + 5), n !== 0 && n !== t.config.series[s].data.length - 1 && (u = 0)), w.drawnextLabel) {
        if ((v = i.drawText({ width: 100, height: parseInt(g.style.fontSize, 10), x: a + u, y: r + b, foreColor: l, textAnchor: h || g.textAnchor, text: o, fontSize: d || g.style.fontSize, fontFamily: g.style.fontFamily, fontWeight: g.style.fontWeight || "normal" })).attr({ class: m || "apexcharts-datalabel", cx: a, cy: r }), g.dropShadow.enabled) {
          var A = g.dropShadow;
          new ee(this.ctx).dropShadow(v, A);
        }
        c.add(v), t.globals.lastDrawnDataLabelsIndexes[s] === void 0 && (t.globals.lastDrawnDataLabelsIndexes[s] = []), t.globals.lastDrawnDataLabelsIndexes[s].push(n);
      }
      return v;
    } }, { key: "addBackgroundToDataLabel", value: function(e, t) {
      var i = this.w, a = i.config.dataLabels.background, r = a.padding, s = a.padding / 2, n = t.width, o = t.height, h = new X(this.ctx).drawRect(t.x - r, t.y - s / 2, n + 2 * r, o + s, a.borderRadius, i.config.chart.background !== "transparent" && i.config.chart.background ? i.config.chart.background : "#fff", a.opacity, a.borderWidth, a.borderColor);
      return a.dropShadow.enabled && new ee(this.ctx).dropShadow(h, a.dropShadow), h;
    } }, { key: "dataLabelsBackground", value: function() {
      var e = this.w;
      if (e.config.chart.type !== "bubble")
        for (var t = e.globals.dom.baseEl.querySelectorAll(".apexcharts-datalabels text"), i = 0; i < t.length; i++) {
          var a = t[i], r = a.getBBox(), s = null;
          if (r.width && r.height && (s = this.addBackgroundToDataLabel(a, r)), s) {
            a.parentNode.insertBefore(s.node, a);
            var n = a.getAttribute("fill");
            e.config.chart.animations.enabled && !e.globals.resized && !e.globals.dataChanged ? s.animate().attr({ fill: n }) : s.attr({ fill: n }), a.setAttribute("fill", e.config.dataLabels.background.foreColor);
          }
        }
    } }, { key: "bringForward", value: function() {
      for (var e = this.w, t = e.globals.dom.baseEl.querySelectorAll(".apexcharts-datalabels"), i = e.globals.dom.baseEl.querySelector(".apexcharts-plot-series:last-child"), a = 0; a < t.length; a++)
        i && i.insertBefore(t[a], i.nextSibling);
    } }]), y;
  }(), re = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.legendInactiveClass = "legend-mouseover-inactive";
    }
    return F(y, [{ key: "getAllSeriesEls", value: function() {
      return this.w.globals.dom.baseEl.getElementsByClassName("apexcharts-series");
    } }, { key: "getSeriesByName", value: function(e) {
      return this.w.globals.dom.baseEl.querySelector(".apexcharts-inner .apexcharts-series[seriesName='".concat(P.escapeString(e), "']"));
    } }, { key: "isSeriesHidden", value: function(e) {
      var t = this.getSeriesByName(e), i = parseInt(t.getAttribute("data:realIndex"), 10);
      return { isHidden: t.classList.contains("apexcharts-series-collapsed"), realIndex: i };
    } }, { key: "addCollapsedClassToSeries", value: function(e, t) {
      var i = this.w;
      function a(r) {
        for (var s = 0; s < r.length; s++)
          r[s].index === t && e.node.classList.add("apexcharts-series-collapsed");
      }
      a(i.globals.collapsedSeries), a(i.globals.ancillaryCollapsedSeries);
    } }, { key: "toggleSeries", value: function(e) {
      var t = this.isSeriesHidden(e);
      return this.ctx.legend.legendHelpers.toggleDataSeries(t.realIndex, t.isHidden), t.isHidden;
    } }, { key: "showSeries", value: function(e) {
      var t = this.isSeriesHidden(e);
      t.isHidden && this.ctx.legend.legendHelpers.toggleDataSeries(t.realIndex, !0);
    } }, { key: "hideSeries", value: function(e) {
      var t = this.isSeriesHidden(e);
      t.isHidden || this.ctx.legend.legendHelpers.toggleDataSeries(t.realIndex, !1);
    } }, { key: "resetSeries", value: function() {
      var e = !(arguments.length > 0 && arguments[0] !== void 0) || arguments[0], t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2], a = this.w, r = P.clone(a.globals.initialSeries);
      a.globals.previousPaths = [], i ? (a.globals.collapsedSeries = [], a.globals.ancillaryCollapsedSeries = [], a.globals.collapsedSeriesIndices = [], a.globals.ancillaryCollapsedSeriesIndices = []) : r = this.emptyCollapsedSeries(r), a.config.series = r, e && (t && (a.globals.zoomed = !1, this.ctx.updateHelpers.revertDefaultAxisMinMax()), this.ctx.updateHelpers._updateSeries(r, a.config.chart.animations.dynamicAnimation.enabled));
    } }, { key: "emptyCollapsedSeries", value: function(e) {
      for (var t = this.w, i = 0; i < e.length; i++)
        t.globals.collapsedSeriesIndices.indexOf(i) > -1 && (e[i].data = []);
      return e;
    } }, { key: "highlightSeries", value: function(e) {
      var t = this.w, i = this.getSeriesByName(e), a = parseInt(i == null ? void 0 : i.getAttribute("data:realIndex"), 10), r = t.globals.dom.baseEl.querySelectorAll(".apexcharts-series, .apexcharts-datalabels, .apexcharts-yaxis"), s = null, n = null, o = null;
      if (t.globals.axisCharts || t.config.chart.type === "radialBar")
        if (t.globals.axisCharts) {
          s = t.globals.dom.baseEl.querySelector(".apexcharts-series[data\\:realIndex='".concat(a, "']")), n = t.globals.dom.baseEl.querySelector(".apexcharts-datalabels[data\\:realIndex='".concat(a, "']"));
          var h = t.globals.seriesYAxisReverseMap[a];
          o = t.globals.dom.baseEl.querySelector(".apexcharts-yaxis[rel='".concat(h, "']"));
        } else
          s = t.globals.dom.baseEl.querySelector(".apexcharts-series[rel='".concat(a + 1, "']"));
      else
        s = t.globals.dom.baseEl.querySelector(".apexcharts-series[rel='".concat(a + 1, "'] path"));
      for (var d = 0; d < r.length; d++)
        r[d].classList.add(this.legendInactiveClass);
      if (s)
        t.globals.axisCharts || s.parentNode.classList.remove(this.legendInactiveClass), s.classList.remove(this.legendInactiveClass), n !== null && n.classList.remove(this.legendInactiveClass), o !== null && o.classList.remove(this.legendInactiveClass);
      else
        for (var c = 0; c < r.length; c++)
          r[c].classList.remove(this.legendInactiveClass);
    } }, { key: "toggleSeriesOnHover", value: function(e, t) {
      var i = this.w;
      t || (t = e.target);
      var a = i.globals.dom.baseEl.querySelectorAll(".apexcharts-series, .apexcharts-datalabels, .apexcharts-yaxis");
      if (e.type === "mousemove") {
        var r = parseInt(t.getAttribute("rel"), 10) - 1;
        this.highlightSeries(i.globals.seriesNames[r]);
      } else if (e.type === "mouseout")
        for (var s = 0; s < a.length; s++)
          a[s].classList.remove(this.legendInactiveClass);
    } }, { key: "highlightRangeInSeries", value: function(e, t) {
      var i = this, a = this.w, r = a.globals.dom.baseEl.getElementsByClassName("apexcharts-heatmap-rect"), s = function(h) {
        for (var d = 0; d < r.length; d++)
          r[d].classList[h](i.legendInactiveClass);
      };
      if (e.type === "mousemove") {
        var n = parseInt(t.getAttribute("rel"), 10) - 1;
        s("add");
        var o = a.config.plotOptions.heatmap.colorScale.ranges;
        (function(h, d) {
          for (var c = 0; c < r.length; c++) {
            var g = Number(r[c].getAttribute("val"));
            g >= h.from && (g < h.to || h.to === d && g === d) && r[c].classList.remove(i.legendInactiveClass);
          }
        })(o[n], o.reduce(function(h, d) {
          return Math.max(h, d.to);
        }, 0));
      } else
        e.type === "mouseout" && s("remove");
    } }, { key: "getActiveConfigSeriesIndex", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "asc", t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [], i = this.w, a = 0;
      if (i.config.series.length > 1) {
        for (var r = i.config.series.map(function(n, o) {
          return n.data && n.data.length > 0 && i.globals.collapsedSeriesIndices.indexOf(o) === -1 && (!i.globals.comboCharts || t.length === 0 || t.length && t.indexOf(i.config.series[o].type) > -1) ? o : -1;
        }), s = e === "asc" ? 0 : r.length - 1; e === "asc" ? s < r.length : s >= 0; e === "asc" ? s++ : s--)
          if (r[s] !== -1) {
            a = r[s];
            break;
          }
      }
      return a;
    } }, { key: "getBarSeriesIndices", value: function() {
      return this.w.globals.comboCharts ? this.w.config.series.map(function(e, t) {
        return e.type === "bar" || e.type === "column" ? t : -1;
      }).filter(function(e) {
        return e !== -1;
      }) : this.w.config.series.map(function(e, t) {
        return t;
      });
    } }, { key: "getPreviousPaths", value: function() {
      var e = this.w;
      function t(s, n, o) {
        for (var h = s[n].childNodes, d = { type: o, paths: [], realIndex: s[n].getAttribute("data:realIndex") }, c = 0; c < h.length; c++)
          if (h[c].hasAttribute("pathTo")) {
            var g = h[c].getAttribute("pathTo");
            d.paths.push({ d: g });
          }
        e.globals.previousPaths.push(d);
      }
      e.globals.previousPaths = [], ["line", "area", "bar", "rangebar", "rangeArea", "candlestick", "radar"].forEach(function(s) {
        for (var n, o = (n = s, e.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(n, "-series .apexcharts-series"))), h = 0; h < o.length; h++)
          t(o, h, s);
      }), this.handlePrevBubbleScatterPaths("bubble"), this.handlePrevBubbleScatterPaths("scatter");
      var i = e.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e.config.chart.type, " .apexcharts-series"));
      if (i.length > 0)
        for (var a = function(s) {
          for (var n = e.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e.config.chart.type, " .apexcharts-series[data\\:realIndex='").concat(s, "'] rect")), o = [], h = function(c) {
            var g = function(x) {
              return n[c].getAttribute(x);
            }, p = { x: parseFloat(g("x")), y: parseFloat(g("y")), width: parseFloat(g("width")), height: parseFloat(g("height")) };
            o.push({ rect: p, color: n[c].getAttribute("color") });
          }, d = 0; d < n.length; d++)
            h(d);
          e.globals.previousPaths.push(o);
        }, r = 0; r < i.length; r++)
          a(r);
      e.globals.axisCharts || (e.globals.previousPaths = e.globals.series);
    } }, { key: "handlePrevBubbleScatterPaths", value: function(e) {
      var t = this.w, i = t.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e, "-series .apexcharts-series"));
      if (i.length > 0)
        for (var a = 0; a < i.length; a++) {
          for (var r = t.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e, "-series .apexcharts-series[data\\:realIndex='").concat(a, "'] circle")), s = [], n = 0; n < r.length; n++)
            s.push({ x: r[n].getAttribute("cx"), y: r[n].getAttribute("cy"), r: r[n].getAttribute("r") });
          t.globals.previousPaths.push(s);
        }
    } }, { key: "clearPreviousPaths", value: function() {
      var e = this.w;
      e.globals.previousPaths = [], e.globals.allSeriesCollapsed = !1;
    } }, { key: "handleNoData", value: function() {
      var e = this.w, t = e.config.noData, i = new X(this.ctx), a = e.globals.svgWidth / 2, r = e.globals.svgHeight / 2, s = "middle";
      if (e.globals.noData = !0, e.globals.animationEnded = !0, t.align === "left" ? (a = 10, s = "start") : t.align === "right" && (a = e.globals.svgWidth - 10, s = "end"), t.verticalAlign === "top" ? r = 50 : t.verticalAlign === "bottom" && (r = e.globals.svgHeight - 50), a += t.offsetX, r = r + parseInt(t.style.fontSize, 10) + 2 + t.offsetY, t.text !== void 0 && t.text !== "") {
        var n = i.drawText({ x: a, y: r, text: t.text, textAnchor: s, fontSize: t.style.fontSize, fontFamily: t.style.fontFamily, foreColor: t.style.color, opacity: 1, class: "apexcharts-text-nodata" });
        e.globals.dom.Paper.add(n);
      }
    } }, { key: "setNullSeriesToZeroValues", value: function(e) {
      for (var t = this.w, i = 0; i < e.length; i++)
        if (e[i].length === 0)
          for (var a = 0; a < e[t.globals.maxValsInArrayIndex].length; a++)
            e[i].push(0);
      return e;
    } }, { key: "hasAllSeriesEqualX", value: function() {
      for (var e = !0, t = this.w, i = this.filteredSeriesX(), a = 0; a < i.length - 1; a++)
        if (i[a][0] !== i[a + 1][0]) {
          e = !1;
          break;
        }
      return t.globals.allSeriesHasEqualX = e, e;
    } }, { key: "filteredSeriesX", value: function() {
      var e = this.w.globals.seriesX.map(function(t) {
        return t.length > 0 ? t : [];
      });
      return e;
    } }]), y;
  }(), Re = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.twoDSeries = [], this.threeDSeries = [], this.twoDSeriesX = [], this.seriesGoals = [], this.coreUtils = new $(this.ctx);
    }
    return F(y, [{ key: "isMultiFormat", value: function() {
      return this.isFormatXY() || this.isFormat2DArray();
    } }, { key: "isFormatXY", value: function() {
      var e = this.w.config.series.slice(), t = new re(this.ctx);
      if (this.activeSeriesIndex = t.getActiveConfigSeriesIndex(), e[this.activeSeriesIndex].data !== void 0 && e[this.activeSeriesIndex].data.length > 0 && e[this.activeSeriesIndex].data[0] !== null && e[this.activeSeriesIndex].data[0].x !== void 0 && e[this.activeSeriesIndex].data[0] !== null)
        return !0;
    } }, { key: "isFormat2DArray", value: function() {
      var e = this.w.config.series.slice(), t = new re(this.ctx);
      if (this.activeSeriesIndex = t.getActiveConfigSeriesIndex(), e[this.activeSeriesIndex].data !== void 0 && e[this.activeSeriesIndex].data.length > 0 && e[this.activeSeriesIndex].data[0] !== void 0 && e[this.activeSeriesIndex].data[0] !== null && e[this.activeSeriesIndex].data[0].constructor === Array)
        return !0;
    } }, { key: "handleFormat2DArray", value: function(e, t) {
      for (var i = this.w.config, a = this.w.globals, r = i.chart.type === "boxPlot" || i.series[t].type === "boxPlot", s = 0; s < e[t].data.length; s++)
        if (e[t].data[s][1] !== void 0 && (Array.isArray(e[t].data[s][1]) && e[t].data[s][1].length === 4 && !r ? this.twoDSeries.push(P.parseNumber(e[t].data[s][1][3])) : e[t].data[s].length >= 5 ? this.twoDSeries.push(P.parseNumber(e[t].data[s][4])) : this.twoDSeries.push(P.parseNumber(e[t].data[s][1])), a.dataFormatXNumeric = !0), i.xaxis.type === "datetime") {
          var n = new Date(e[t].data[s][0]);
          n = new Date(n).getTime(), this.twoDSeriesX.push(n);
        } else
          this.twoDSeriesX.push(e[t].data[s][0]);
      for (var o = 0; o < e[t].data.length; o++)
        e[t].data[o][2] !== void 0 && (this.threeDSeries.push(e[t].data[o][2]), a.isDataXYZ = !0);
    } }, { key: "handleFormatXY", value: function(e, t) {
      var i = this.w.config, a = this.w.globals, r = new K(this.ctx), s = t;
      a.collapsedSeriesIndices.indexOf(t) > -1 && (s = this.activeSeriesIndex);
      for (var n = 0; n < e[t].data.length; n++)
        e[t].data[n].y !== void 0 && (Array.isArray(e[t].data[n].y) ? this.twoDSeries.push(P.parseNumber(e[t].data[n].y[e[t].data[n].y.length - 1])) : this.twoDSeries.push(P.parseNumber(e[t].data[n].y))), e[t].data[n].goals !== void 0 && Array.isArray(e[t].data[n].goals) ? (this.seriesGoals[t] === void 0 && (this.seriesGoals[t] = []), this.seriesGoals[t].push(e[t].data[n].goals)) : (this.seriesGoals[t] === void 0 && (this.seriesGoals[t] = []), this.seriesGoals[t].push(null));
      for (var o = 0; o < e[s].data.length; o++) {
        var h = typeof e[s].data[o].x == "string", d = Array.isArray(e[s].data[o].x), c = !d && !!r.isValidDate(e[s].data[o].x);
        if (h || c)
          if (h || i.xaxis.convertedCatToNumeric) {
            var g = a.isBarHorizontal && a.isRangeData;
            i.xaxis.type !== "datetime" || g ? (this.fallbackToCategory = !0, this.twoDSeriesX.push(e[s].data[o].x), isNaN(e[s].data[o].x) || this.w.config.xaxis.type === "category" || typeof e[s].data[o].x == "string" || (a.isXNumeric = !0)) : this.twoDSeriesX.push(r.parseDate(e[s].data[o].x));
          } else
            i.xaxis.type === "datetime" ? this.twoDSeriesX.push(r.parseDate(e[s].data[o].x.toString())) : (a.dataFormatXNumeric = !0, a.isXNumeric = !0, this.twoDSeriesX.push(parseFloat(e[s].data[o].x)));
        else
          d ? (this.fallbackToCategory = !0, this.twoDSeriesX.push(e[s].data[o].x)) : (a.isXNumeric = !0, a.dataFormatXNumeric = !0, this.twoDSeriesX.push(e[s].data[o].x));
      }
      if (e[t].data[0] && e[t].data[0].z !== void 0) {
        for (var p = 0; p < e[t].data.length; p++)
          this.threeDSeries.push(e[t].data[p].z);
        a.isDataXYZ = !0;
      }
    } }, { key: "handleRangeData", value: function(e, t) {
      var i = this.w.globals, a = {};
      return this.isFormat2DArray() ? a = this.handleRangeDataFormat("array", e, t) : this.isFormatXY() && (a = this.handleRangeDataFormat("xy", e, t)), i.seriesRangeStart.push(a.start === void 0 ? [] : a.start), i.seriesRangeEnd.push(a.end === void 0 ? [] : a.end), i.seriesRange.push(a.rangeUniques), i.seriesRange.forEach(function(r, s) {
        r && r.forEach(function(n, o) {
          n.y.forEach(function(h, d) {
            for (var c = 0; c < n.y.length; c++)
              if (d !== c) {
                var g = h.y1, p = h.y2, x = n.y[c].y1;
                g <= n.y[c].y2 && x <= p && (n.overlaps.indexOf(h.rangeName) < 0 && n.overlaps.push(h.rangeName), n.overlaps.indexOf(n.y[c].rangeName) < 0 && n.overlaps.push(n.y[c].rangeName));
              }
          });
        });
      }), a;
    } }, { key: "handleCandleStickBoxData", value: function(e, t) {
      var i = this.w.globals, a = {};
      return this.isFormat2DArray() ? a = this.handleCandleStickBoxDataFormat("array", e, t) : this.isFormatXY() && (a = this.handleCandleStickBoxDataFormat("xy", e, t)), i.seriesCandleO[t] = a.o, i.seriesCandleH[t] = a.h, i.seriesCandleM[t] = a.m, i.seriesCandleL[t] = a.l, i.seriesCandleC[t] = a.c, a;
    } }, { key: "handleRangeDataFormat", value: function(e, t, i) {
      var a = [], r = [], s = t[i].data.filter(function(d, c, g) {
        return c === g.findIndex(function(p) {
          return p.x === d.x;
        });
      }).map(function(d, c) {
        return { x: d.x, overlaps: [], y: [] };
      });
      if (e === "array")
        for (var n = 0; n < t[i].data.length; n++)
          Array.isArray(t[i].data[n]) ? (a.push(t[i].data[n][1][0]), r.push(t[i].data[n][1][1])) : (a.push(t[i].data[n]), r.push(t[i].data[n]));
      else if (e === "xy")
        for (var o = function(d) {
          var c = Array.isArray(t[i].data[d].y), g = P.randomId(), p = t[i].data[d].x, x = { y1: c ? t[i].data[d].y[0] : t[i].data[d].y, y2: c ? t[i].data[d].y[1] : t[i].data[d].y, rangeName: g };
          t[i].data[d].rangeName = g;
          var f = s.findIndex(function(m) {
            return m.x === p;
          });
          s[f].y.push(x), a.push(x.y1), r.push(x.y2);
        }, h = 0; h < t[i].data.length; h++)
          o(h);
      return { start: a, end: r, rangeUniques: s };
    } }, { key: "handleCandleStickBoxDataFormat", value: function(e, t, i) {
      var a = this.w, r = a.config.chart.type === "boxPlot" || a.config.series[i].type === "boxPlot", s = [], n = [], o = [], h = [], d = [];
      if (e === "array")
        if (r && t[i].data[0].length === 6 || !r && t[i].data[0].length === 5)
          for (var c = 0; c < t[i].data.length; c++)
            s.push(t[i].data[c][1]), n.push(t[i].data[c][2]), r ? (o.push(t[i].data[c][3]), h.push(t[i].data[c][4]), d.push(t[i].data[c][5])) : (h.push(t[i].data[c][3]), d.push(t[i].data[c][4]));
        else
          for (var g = 0; g < t[i].data.length; g++)
            Array.isArray(t[i].data[g][1]) && (s.push(t[i].data[g][1][0]), n.push(t[i].data[g][1][1]), r ? (o.push(t[i].data[g][1][2]), h.push(t[i].data[g][1][3]), d.push(t[i].data[g][1][4])) : (h.push(t[i].data[g][1][2]), d.push(t[i].data[g][1][3])));
      else if (e === "xy")
        for (var p = 0; p < t[i].data.length; p++)
          Array.isArray(t[i].data[p].y) && (s.push(t[i].data[p].y[0]), n.push(t[i].data[p].y[1]), r ? (o.push(t[i].data[p].y[2]), h.push(t[i].data[p].y[3]), d.push(t[i].data[p].y[4])) : (h.push(t[i].data[p].y[2]), d.push(t[i].data[p].y[3])));
      return { o: s, h: n, m: o, l: h, c: d };
    } }, { key: "parseDataAxisCharts", value: function(e) {
      var t = this, i = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.ctx, a = this.w.config, r = this.w.globals, s = new K(i), n = a.labels.length > 0 ? a.labels.slice() : a.xaxis.categories.slice();
      r.isRangeBar = a.chart.type === "rangeBar" && r.isBarHorizontal, r.hasXaxisGroups = a.xaxis.type === "category" && a.xaxis.group.groups.length > 0, r.hasXaxisGroups && (r.groups = a.xaxis.group.groups), e.forEach(function(p, x) {
        p.name !== void 0 ? r.seriesNames.push(p.name) : r.seriesNames.push("series-" + parseInt(x + 1, 10));
      }), this.coreUtils.setSeriesYAxisMappings();
      var o = [], h = J(new Set(a.series.map(function(p) {
        return p.group;
      })));
      a.series.forEach(function(p, x) {
        var f = h.indexOf(p.group);
        o[f] || (o[f] = []), o[f].push(r.seriesNames[x]);
      }), r.seriesGroups = o;
      for (var d = function() {
        for (var p = 0; p < n.length; p++)
          if (typeof n[p] == "string") {
            if (!s.isValidDate(n[p]))
              throw new Error("You have provided invalid Date format. Please provide a valid JavaScript Date");
            t.twoDSeriesX.push(s.parseDate(n[p]));
          } else
            t.twoDSeriesX.push(n[p]);
      }, c = 0; c < e.length; c++) {
        if (this.twoDSeries = [], this.twoDSeriesX = [], this.threeDSeries = [], e[c].data === void 0)
          return void console.error("It is a possibility that you may have not included 'data' property in series.");
        if (a.chart.type !== "rangeBar" && a.chart.type !== "rangeArea" && e[c].type !== "rangeBar" && e[c].type !== "rangeArea" || (r.isRangeData = !0, a.chart.type !== "rangeBar" && a.chart.type !== "rangeArea" || this.handleRangeData(e, c)), this.isMultiFormat())
          this.isFormat2DArray() ? this.handleFormat2DArray(e, c) : this.isFormatXY() && this.handleFormatXY(e, c), a.chart.type !== "candlestick" && e[c].type !== "candlestick" && a.chart.type !== "boxPlot" && e[c].type !== "boxPlot" || this.handleCandleStickBoxData(e, c), r.series.push(this.twoDSeries), r.labels.push(this.twoDSeriesX), r.seriesX.push(this.twoDSeriesX), r.seriesGoals = this.seriesGoals, c !== this.activeSeriesIndex || this.fallbackToCategory || (r.isXNumeric = !0);
        else {
          a.xaxis.type === "datetime" ? (r.isXNumeric = !0, d(), r.seriesX.push(this.twoDSeriesX)) : a.xaxis.type === "numeric" && (r.isXNumeric = !0, n.length > 0 && (this.twoDSeriesX = n, r.seriesX.push(this.twoDSeriesX))), r.labels.push(this.twoDSeriesX);
          var g = e[c].data.map(function(p) {
            return P.parseNumber(p);
          });
          r.series.push(g);
        }
        r.seriesZ.push(this.threeDSeries), e[c].color !== void 0 ? r.seriesColors.push(e[c].color) : r.seriesColors.push(void 0);
      }
      return this.w;
    } }, { key: "parseDataNonAxisCharts", value: function(e) {
      var t = this.w.globals, i = this.w.config;
      t.series = e.slice(), t.seriesNames = i.labels.slice();
      for (var a = 0; a < t.series.length; a++)
        t.seriesNames[a] === void 0 && t.seriesNames.push("series-" + (a + 1));
      return this.w;
    } }, { key: "handleExternalLabelsData", value: function(e) {
      var t = this.w.config, i = this.w.globals;
      t.xaxis.categories.length > 0 ? i.labels = t.xaxis.categories : t.labels.length > 0 ? i.labels = t.labels.slice() : this.fallbackToCategory ? (i.labels = i.labels[0], i.seriesRange.length && (i.seriesRange.map(function(a) {
        a.forEach(function(r) {
          i.labels.indexOf(r.x) < 0 && r.x && i.labels.push(r.x);
        });
      }), i.labels = Array.from(new Set(i.labels.map(JSON.stringify)), JSON.parse)), t.xaxis.convertedCatToNumeric && (new ve(t).convertCatToNumericXaxis(t, this.ctx, i.seriesX[0]), this._generateExternalLabels(e))) : this._generateExternalLabels(e);
    } }, { key: "_generateExternalLabels", value: function(e) {
      var t = this.w.globals, i = this.w.config, a = [];
      if (t.axisCharts) {
        if (t.series.length > 0)
          if (this.isFormatXY())
            for (var r = i.series.map(function(c, g) {
              return c.data.filter(function(p, x, f) {
                return f.findIndex(function(m) {
                  return m.x === p.x;
                }) === x;
              });
            }), s = r.reduce(function(c, g, p, x) {
              return x[c].length > g.length ? c : p;
            }, 0), n = 0; n < r[s].length; n++)
              a.push(n + 1);
          else
            for (var o = 0; o < t.series[t.maxValsInArrayIndex].length; o++)
              a.push(o + 1);
        t.seriesX = [];
        for (var h = 0; h < e.length; h++)
          t.seriesX.push(a);
        this.w.globals.isBarHorizontal || (t.isXNumeric = !0);
      }
      if (a.length === 0) {
        a = t.axisCharts ? [] : t.series.map(function(c, g) {
          return g + 1;
        });
        for (var d = 0; d < e.length; d++)
          t.seriesX.push(a);
      }
      t.labels = a, i.xaxis.convertedCatToNumeric && (t.categoryLabels = a.map(function(c) {
        return i.xaxis.labels.formatter(c);
      })), t.noLabelsProvided = !0;
    } }, { key: "parseData", value: function(e) {
      var t = this.w, i = t.config, a = t.globals;
      if (this.excludeCollapsedSeriesInYAxis(), this.fallbackToCategory = !1, this.ctx.core.resetGlobals(), this.ctx.core.isMultipleY(), a.axisCharts ? (this.parseDataAxisCharts(e), this.coreUtils.getLargestSeries()) : this.parseDataNonAxisCharts(e), i.chart.stacked) {
        var r = new re(this.ctx);
        a.series = r.setNullSeriesToZeroValues(a.series);
      }
      this.coreUtils.getSeriesTotals(), a.axisCharts && (a.stackedSeriesTotals = this.coreUtils.getStackedSeriesTotals(), a.stackedSeriesTotalsByGroups = this.coreUtils.getStackedSeriesTotalsByGroups()), this.coreUtils.getPercentSeries(), a.dataFormatXNumeric || a.isXNumeric && (i.xaxis.type !== "numeric" || i.labels.length !== 0 || i.xaxis.categories.length !== 0) || this.handleExternalLabelsData(e);
      for (var s = this.coreUtils.getCategoryLabels(a.labels), n = 0; n < s.length; n++)
        if (Array.isArray(s[n])) {
          a.isMultiLineX = !0;
          break;
        }
    } }, { key: "excludeCollapsedSeriesInYAxis", value: function() {
      var e = this.w, t = [];
      e.globals.seriesYAxisMap.forEach(function(i, a) {
        var r = 0;
        i.forEach(function(s) {
          e.globals.collapsedSeriesIndices.indexOf(s) !== -1 && r++;
        }), r > 0 && r == i.length && t.push(a);
      }), e.globals.ignoreYAxisIndexes = t.map(function(i) {
        return i;
      });
    } }]), y;
  }(), Pe = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "scaleSvgNode", value: function(e, t) {
      var i = parseFloat(e.getAttributeNS(null, "width")), a = parseFloat(e.getAttributeNS(null, "height"));
      e.setAttributeNS(null, "width", i * t), e.setAttributeNS(null, "height", a * t), e.setAttributeNS(null, "viewBox", "0 0 " + i + " " + a);
    } }, { key: "getSvgString", value: function() {
      var e = this;
      return new Promise(function(t) {
        var i = e.w, a = i.config.chart.toolbar.export.width, r = i.config.chart.toolbar.export.scale || a / i.globals.svgWidth;
        r || (r = 1);
        var s = e.w.globals.dom.Paper.svg(), n = e.w.globals.dom.Paper.node.cloneNode(!0);
        r !== 1 && e.scaleSvgNode(n, r), e.convertImagesToBase64(n).then(function() {
          s = new XMLSerializer().serializeToString(n), t(s.replace(/&nbsp;/g, "&#160;"));
        });
      });
    } }, { key: "convertImagesToBase64", value: function(e) {
      var t = this, i = e.getElementsByTagName("image"), a = Array.from(i).map(function(r) {
        var s = r.getAttributeNS("http://www.w3.org/1999/xlink", "href");
        return s && !s.startsWith("data:") ? t.getBase64FromUrl(s).then(function(n) {
          r.setAttributeNS("http://www.w3.org/1999/xlink", "href", n);
        }).catch(function(n) {
          console.error("Error converting image to base64:", n);
        }) : Promise.resolve();
      });
      return Promise.all(a);
    } }, { key: "getBase64FromUrl", value: function(e) {
      return new Promise(function(t, i) {
        var a = new Image();
        a.crossOrigin = "Anonymous", a.onload = function() {
          var r = document.createElement("canvas");
          r.width = a.width, r.height = a.height, r.getContext("2d").drawImage(a, 0, 0), t(r.toDataURL());
        }, a.onerror = i, a.src = e;
      });
    } }, { key: "cleanup", value: function() {
      var e = this.w, t = e.globals.dom.baseEl.getElementsByClassName("apexcharts-xcrosshairs"), i = e.globals.dom.baseEl.getElementsByClassName("apexcharts-ycrosshairs"), a = e.globals.dom.baseEl.querySelectorAll(".apexcharts-zoom-rect, .apexcharts-selection-rect");
      Array.prototype.forEach.call(a, function(r) {
        r.setAttribute("width", 0);
      }), t && t[0] && (t[0].setAttribute("x", -500), t[0].setAttribute("x1", -500), t[0].setAttribute("x2", -500)), i && i[0] && (i[0].setAttribute("y", -100), i[0].setAttribute("y1", -100), i[0].setAttribute("y2", -100));
    } }, { key: "svgUrl", value: function() {
      var e = this;
      return new Promise(function(t) {
        e.cleanup(), e.getSvgString().then(function(i) {
          var a = new Blob([i], { type: "image/svg+xml;charset=utf-8" });
          t(URL.createObjectURL(a));
        });
      });
    } }, { key: "dataURI", value: function(e) {
      var t = this;
      return new Promise(function(i) {
        var a = t.w, r = e ? e.scale || e.width / a.globals.svgWidth : 1;
        t.cleanup();
        var s = document.createElement("canvas");
        s.width = a.globals.svgWidth * r, s.height = parseInt(a.globals.dom.elWrap.style.height, 10) * r;
        var n = a.config.chart.background !== "transparent" && a.config.chart.background ? a.config.chart.background : "#fff", o = s.getContext("2d");
        o.fillStyle = n, o.fillRect(0, 0, s.width * r, s.height * r), t.getSvgString().then(function(h) {
          var d = "data:image/svg+xml," + encodeURIComponent(h), c = new Image();
          c.crossOrigin = "anonymous", c.onload = function() {
            if (o.drawImage(c, 0, 0), s.msToBlob) {
              var g = s.msToBlob();
              i({ blob: g });
            } else {
              var p = s.toDataURL("image/png");
              i({ imgURI: p });
            }
          }, c.src = d;
        });
      });
    } }, { key: "exportToSVG", value: function() {
      var e = this;
      this.svgUrl().then(function(t) {
        e.triggerDownload(t, e.w.config.chart.toolbar.export.svg.filename, ".svg");
      });
    } }, { key: "exportToPng", value: function() {
      var e = this, t = this.w.config.chart.toolbar.export.scale, i = this.w.config.chart.toolbar.export.width, a = t ? { scale: t } : i ? { width: i } : void 0;
      this.dataURI(a).then(function(r) {
        var s = r.imgURI, n = r.blob;
        n ? navigator.msSaveOrOpenBlob(n, e.w.globals.chartID + ".png") : e.triggerDownload(s, e.w.config.chart.toolbar.export.png.filename, ".png");
      });
    } }, { key: "exportToCSV", value: function(e) {
      var t = this, i = e.series, a = e.fileName, r = e.columnDelimiter, s = r === void 0 ? "," : r, n = e.lineDelimiter, o = n === void 0 ? `
` : n, h = this.w;
      i || (i = h.config.series);
      var d, c, g = [], p = [], x = "", f = h.globals.series.map(function(k, S) {
        return h.globals.collapsedSeriesIndices.indexOf(S) === -1 ? k : [];
      }), m = function(k) {
        return typeof h.config.chart.toolbar.export.csv.categoryFormatter == "function" ? h.config.chart.toolbar.export.csv.categoryFormatter(k) : h.config.xaxis.type === "datetime" && String(k).length >= 10 ? new Date(k).toDateString() : P.isNumber(k) ? k : k.split(s).join("");
      }, v = function(k) {
        return typeof h.config.chart.toolbar.export.csv.valueFormatter == "function" ? h.config.chart.toolbar.export.csv.valueFormatter(k) : k;
      }, w = Math.max.apply(Math, J(i.map(function(k) {
        return k.data ? k.data.length : 0;
      }))), l = new Re(this.ctx), u = new he(this.ctx), b = function(k) {
        var S = "";
        if (h.globals.axisCharts) {
          if (h.config.xaxis.type === "category" || h.config.xaxis.convertedCatToNumeric)
            if (h.globals.isBarHorizontal) {
              var C = h.globals.yLabelFormatters[0], L = new re(t.ctx).getActiveConfigSeriesIndex();
              S = C(h.globals.labels[k], { seriesIndex: L, dataPointIndex: k, w: h });
            } else
              S = u.getLabel(h.globals.labels, h.globals.timescaleLabels, 0, k).text;
          h.config.xaxis.type === "datetime" && (h.config.xaxis.categories.length ? S = h.config.xaxis.categories[k] : h.config.labels.length && (S = h.config.labels[k]));
        } else
          S = h.config.labels[k];
        return S === null ? "nullvalue" : (Array.isArray(S) && (S = S.join(" ")), P.isNumber(S) ? S : S.split(s).join(""));
      }, A = function(k, S) {
        if (g.length && S === 0 && p.push(g.join(s)), k.data) {
          k.data = k.data.length && k.data || J(Array(w)).map(function() {
            return "";
          });
          for (var C = 0; C < k.data.length; C++) {
            g = [];
            var L = b(C);
            if (L !== "nullvalue") {
              if (L || (l.isFormatXY() ? L = i[S].data[C].x : l.isFormat2DArray() && (L = i[S].data[C] ? i[S].data[C][0] : "")), S === 0) {
                g.push(m(L));
                for (var M = 0; M < h.globals.series.length; M++) {
                  var T, I = l.isFormatXY() ? (T = i[M].data[C]) === null || T === void 0 ? void 0 : T.y : f[M][C];
                  g.push(v(I));
                }
              }
              (h.config.chart.type === "candlestick" || k.type && k.type === "candlestick") && (g.pop(), g.push(h.globals.seriesCandleO[S][C]), g.push(h.globals.seriesCandleH[S][C]), g.push(h.globals.seriesCandleL[S][C]), g.push(h.globals.seriesCandleC[S][C])), (h.config.chart.type === "boxPlot" || k.type && k.type === "boxPlot") && (g.pop(), g.push(h.globals.seriesCandleO[S][C]), g.push(h.globals.seriesCandleH[S][C]), g.push(h.globals.seriesCandleM[S][C]), g.push(h.globals.seriesCandleL[S][C]), g.push(h.globals.seriesCandleC[S][C])), h.config.chart.type === "rangeBar" && (g.pop(), g.push(h.globals.seriesRangeStart[S][C]), g.push(h.globals.seriesRangeEnd[S][C])), g.length && p.push(g.join(s));
            }
          }
        }
      };
      g.push(h.config.chart.toolbar.export.csv.headerCategory), h.config.chart.type === "boxPlot" ? (g.push("minimum"), g.push("q1"), g.push("median"), g.push("q3"), g.push("maximum")) : h.config.chart.type === "candlestick" ? (g.push("open"), g.push("high"), g.push("low"), g.push("close")) : h.config.chart.type === "rangeBar" ? (g.push("minimum"), g.push("maximum")) : i.map(function(k, S) {
        var C = (k.name ? k.name : "series-".concat(S)) + "";
        h.globals.axisCharts && g.push(C.split(s).join("") ? C.split(s).join("") : "series-".concat(S));
      }), h.globals.axisCharts || (g.push(h.config.chart.toolbar.export.csv.headerValue), p.push(g.join(s))), h.globals.allSeriesHasEqualX || !h.globals.axisCharts || h.config.xaxis.categories.length || h.config.labels.length ? i.map(function(k, S) {
        h.globals.axisCharts ? A(k, S) : ((g = []).push(m(h.globals.labels[S])), g.push(v(f[S])), p.push(g.join(s)));
      }) : (d = /* @__PURE__ */ new Set(), c = {}, i.forEach(function(k, S) {
        k == null || k.data.forEach(function(C) {
          var L, M;
          if (l.isFormatXY())
            L = C.x, M = C.y;
          else {
            if (!l.isFormat2DArray())
              return;
            L = C[0], M = C[1];
          }
          c[L] || (c[L] = Array(i.length).fill("")), c[L][S] = v(M), d.add(L);
        });
      }), g.length && p.push(g.join(s)), Array.from(d).sort().forEach(function(k) {
        p.push([m(k), c[k].join(s)]);
      })), x += p.join(o), this.triggerDownload("data:text/csv; charset=utf-8," + encodeURIComponent("\uFEFF" + x), a || h.config.chart.toolbar.export.csv.filename, ".csv");
    } }, { key: "triggerDownload", value: function(e, t, i) {
      var a = document.createElement("a");
      a.href = e, a.download = (t || this.w.globals.chartID) + i, document.body.appendChild(a), a.click(), document.body.removeChild(a);
    } }]), y;
  }(), we = function() {
    function y(e, t) {
      R(this, y), this.ctx = e, this.elgrid = t, this.w = e.w;
      var i = this.w;
      this.axesUtils = new he(e), this.xaxisLabels = i.globals.labels.slice(), i.globals.timescaleLabels.length > 0 && !i.globals.isBarHorizontal && (this.xaxisLabels = i.globals.timescaleLabels.slice()), i.config.xaxis.overwriteCategories && (this.xaxisLabels = i.config.xaxis.overwriteCategories), this.drawnLabels = [], this.drawnLabelsRects = [], i.config.xaxis.position === "top" ? this.offY = 0 : this.offY = i.globals.gridHeight, this.offY = this.offY + i.config.xaxis.axisBorder.offsetY, this.isCategoryBarHorizontal = i.config.chart.type === "bar" && i.config.plotOptions.bar.horizontal, this.xaxisFontSize = i.config.xaxis.labels.style.fontSize, this.xaxisFontFamily = i.config.xaxis.labels.style.fontFamily, this.xaxisForeColors = i.config.xaxis.labels.style.colors, this.xaxisBorderWidth = i.config.xaxis.axisBorder.width, this.isCategoryBarHorizontal && (this.xaxisBorderWidth = i.config.yaxis[0].axisBorder.width.toString()), this.xaxisBorderWidth.indexOf("%") > -1 ? this.xaxisBorderWidth = i.globals.gridWidth * parseInt(this.xaxisBorderWidth, 10) / 100 : this.xaxisBorderWidth = parseInt(this.xaxisBorderWidth, 10), this.xaxisBorderHeight = i.config.xaxis.axisBorder.height, this.yaxis = i.config.yaxis[0];
    }
    return F(y, [{ key: "drawXaxis", value: function() {
      var e = this.w, t = new X(this.ctx), i = t.group({ class: "apexcharts-xaxis", transform: "translate(".concat(e.config.xaxis.offsetX, ", ").concat(e.config.xaxis.offsetY, ")") }), a = t.group({ class: "apexcharts-xaxis-texts-g", transform: "translate(".concat(e.globals.translateXAxisX, ", ").concat(e.globals.translateXAxisY, ")") });
      i.add(a);
      for (var r = [], s = 0; s < this.xaxisLabels.length; s++)
        r.push(this.xaxisLabels[s]);
      if (this.drawXAxisLabelAndGroup(!0, t, a, r, e.globals.isXNumeric, function(x, f) {
        return f;
      }), e.globals.hasXaxisGroups) {
        var n = e.globals.groups;
        r = [];
        for (var o = 0; o < n.length; o++)
          r.push(n[o].title);
        var h = {};
        e.config.xaxis.group.style && (h.xaxisFontSize = e.config.xaxis.group.style.fontSize, h.xaxisFontFamily = e.config.xaxis.group.style.fontFamily, h.xaxisForeColors = e.config.xaxis.group.style.colors, h.fontWeight = e.config.xaxis.group.style.fontWeight, h.cssClass = e.config.xaxis.group.style.cssClass), this.drawXAxisLabelAndGroup(!1, t, a, r, !1, function(x, f) {
          return n[x].cols * f;
        }, h);
      }
      if (e.config.xaxis.title.text !== void 0) {
        var d = t.group({ class: "apexcharts-xaxis-title" }), c = t.drawText({ x: e.globals.gridWidth / 2 + e.config.xaxis.title.offsetX, y: this.offY + parseFloat(this.xaxisFontSize) + (e.config.xaxis.position === "bottom" ? e.globals.xAxisLabelsHeight : -e.globals.xAxisLabelsHeight - 10) + e.config.xaxis.title.offsetY, text: e.config.xaxis.title.text, textAnchor: "middle", fontSize: e.config.xaxis.title.style.fontSize, fontFamily: e.config.xaxis.title.style.fontFamily, fontWeight: e.config.xaxis.title.style.fontWeight, foreColor: e.config.xaxis.title.style.color, cssClass: "apexcharts-xaxis-title-text " + e.config.xaxis.title.style.cssClass });
        d.add(c), i.add(d);
      }
      if (e.config.xaxis.axisBorder.show) {
        var g = e.globals.barPadForNumericAxis, p = t.drawLine(e.globals.padHorizontal + e.config.xaxis.axisBorder.offsetX - g, this.offY, this.xaxisBorderWidth + g, this.offY, e.config.xaxis.axisBorder.color, 0, this.xaxisBorderHeight);
        this.elgrid && this.elgrid.elGridBorders && e.config.grid.show ? this.elgrid.elGridBorders.add(p) : i.add(p);
      }
      return i;
    } }, { key: "drawXAxisLabelAndGroup", value: function(e, t, i, a, r, s) {
      var n, o = this, h = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : {}, d = [], c = [], g = this.w, p = h.xaxisFontSize || this.xaxisFontSize, x = h.xaxisFontFamily || this.xaxisFontFamily, f = h.xaxisForeColors || this.xaxisForeColors, m = h.fontWeight || g.config.xaxis.labels.style.fontWeight, v = h.cssClass || g.config.xaxis.labels.style.cssClass, w = g.globals.padHorizontal, l = a.length, u = g.config.xaxis.type === "category" ? g.globals.dataPoints : l;
      if (u === 0 && l > u && (u = l), r) {
        var b = u > 1 ? u - 1 : u;
        n = g.globals.gridWidth / Math.min(b, l - 1), w = w + s(0, n) / 2 + g.config.xaxis.labels.offsetX;
      } else
        n = g.globals.gridWidth / u, w = w + s(0, n) + g.config.xaxis.labels.offsetX;
      for (var A = function(S) {
        var C = w - s(S, n) / 2 + g.config.xaxis.labels.offsetX;
        S === 0 && l === 1 && n / 2 === w && u === 1 && (C = g.globals.gridWidth / 2);
        var L = o.axesUtils.getLabel(a, g.globals.timescaleLabels, C, S, d, p, e), M = 28;
        if (g.globals.rotateXLabels && e && (M = 22), g.config.xaxis.title.text && g.config.xaxis.position === "top" && (M += parseFloat(g.config.xaxis.title.style.fontSize) + 2), e || (M = M + parseFloat(p) + (g.globals.xAxisLabelsHeight - g.globals.xAxisGroupLabelsHeight) + (g.globals.rotateXLabels ? 10 : 0)), L = g.config.xaxis.tickAmount !== void 0 && g.config.xaxis.tickAmount !== "dataPoints" && g.config.xaxis.type !== "datetime" ? o.axesUtils.checkLabelBasedOnTickamount(S, L, l) : o.axesUtils.checkForOverflowingLabels(S, L, l, d, c), g.config.xaxis.labels.show) {
          var T = t.drawText({ x: L.x, y: o.offY + g.config.xaxis.labels.offsetY + M - (g.config.xaxis.position === "top" ? g.globals.xAxisHeight + g.config.xaxis.axisTicks.height - 2 : 0), text: L.text, textAnchor: "middle", fontWeight: L.isBold ? 600 : m, fontSize: p, fontFamily: x, foreColor: Array.isArray(f) ? e && g.config.xaxis.convertedCatToNumeric ? f[g.globals.minX + S - 1] : f[S] : f, isPlainText: !1, cssClass: (e ? "apexcharts-xaxis-label " : "apexcharts-xaxis-group-label ") + v });
          if (i.add(T), T.on("click", function(z) {
            if (typeof g.config.chart.events.xAxisLabelClick == "function") {
              var Y = Object.assign({}, g, { labelIndex: S });
              g.config.chart.events.xAxisLabelClick(z, o.ctx, Y);
            }
          }), e) {
            var I = document.createElementNS(g.globals.SVGNS, "title");
            I.textContent = Array.isArray(L.text) ? L.text.join(" ") : L.text, T.node.appendChild(I), L.text !== "" && (d.push(L.text), c.push(L));
          }
        }
        S < l - 1 && (w += s(S + 1, n));
      }, k = 0; k <= l - 1; k++)
        A(k);
    } }, { key: "drawXaxisInversed", value: function(e) {
      var t, i, a = this, r = this.w, s = new X(this.ctx), n = r.config.yaxis[0].opposite ? r.globals.translateYAxisX[e] : 0, o = s.group({ class: "apexcharts-yaxis apexcharts-xaxis-inversed", rel: e }), h = s.group({ class: "apexcharts-yaxis-texts-g apexcharts-xaxis-inversed-texts-g", transform: "translate(" + n + ", 0)" });
      o.add(h);
      var d = [];
      if (r.config.yaxis[e].show)
        for (var c = 0; c < this.xaxisLabels.length; c++)
          d.push(this.xaxisLabels[c]);
      t = r.globals.gridHeight / d.length, i = -t / 2.2;
      var g = r.globals.yLabelFormatters[0], p = r.config.yaxis[0].labels;
      if (p.show)
        for (var x = function(b) {
          var A = d[b] === void 0 ? "" : d[b];
          A = g(A, { seriesIndex: e, dataPointIndex: b, w: r });
          var k = a.axesUtils.getYAxisForeColor(p.style.colors, e), S = 0;
          Array.isArray(A) && (S = A.length / 2 * parseInt(p.style.fontSize, 10));
          var C = p.offsetX - 15, L = "end";
          a.yaxis.opposite && (L = "start"), r.config.yaxis[0].labels.align === "left" ? (C = p.offsetX, L = "start") : r.config.yaxis[0].labels.align === "center" ? (C = p.offsetX, L = "middle") : r.config.yaxis[0].labels.align === "right" && (L = "end");
          var M = s.drawText({ x: C, y: i + t + p.offsetY - S, text: A, textAnchor: L, foreColor: Array.isArray(k) ? k[b] : k, fontSize: p.style.fontSize, fontFamily: p.style.fontFamily, fontWeight: p.style.fontWeight, isPlainText: !1, cssClass: "apexcharts-yaxis-label " + p.style.cssClass, maxWidth: p.maxWidth });
          h.add(M), M.on("click", function(z) {
            if (typeof r.config.chart.events.xAxisLabelClick == "function") {
              var Y = Object.assign({}, r, { labelIndex: b });
              r.config.chart.events.xAxisLabelClick(z, a.ctx, Y);
            }
          });
          var T = document.createElementNS(r.globals.SVGNS, "title");
          if (T.textContent = Array.isArray(A) ? A.join(" ") : A, M.node.appendChild(T), r.config.yaxis[e].labels.rotate !== 0) {
            var I = s.rotateAroundCenter(M.node);
            M.node.setAttribute("transform", "rotate(".concat(r.config.yaxis[e].labels.rotate, " 0 ").concat(I.y, ")"));
          }
          i += t;
        }, f = 0; f <= d.length - 1; f++)
          x(f);
      if (r.config.yaxis[0].title.text !== void 0) {
        var m = s.group({ class: "apexcharts-yaxis-title apexcharts-xaxis-title-inversed", transform: "translate(" + n + ", 0)" }), v = s.drawText({ x: r.config.yaxis[0].title.offsetX, y: r.globals.gridHeight / 2 + r.config.yaxis[0].title.offsetY, text: r.config.yaxis[0].title.text, textAnchor: "middle", foreColor: r.config.yaxis[0].title.style.color, fontSize: r.config.yaxis[0].title.style.fontSize, fontWeight: r.config.yaxis[0].title.style.fontWeight, fontFamily: r.config.yaxis[0].title.style.fontFamily, cssClass: "apexcharts-yaxis-title-text " + r.config.yaxis[0].title.style.cssClass });
        m.add(v), o.add(m);
      }
      var w = 0;
      this.isCategoryBarHorizontal && r.config.yaxis[0].opposite && (w = r.globals.gridWidth);
      var l = r.config.xaxis.axisBorder;
      if (l.show) {
        var u = s.drawLine(r.globals.padHorizontal + l.offsetX + w, 1 + l.offsetY, r.globals.padHorizontal + l.offsetX + w, r.globals.gridHeight + l.offsetY, l.color, 0);
        this.elgrid && this.elgrid.elGridBorders && r.config.grid.show ? this.elgrid.elGridBorders.add(u) : o.add(u);
      }
      return r.config.yaxis[0].axisTicks.show && this.axesUtils.drawYAxisTicks(w, d.length, r.config.yaxis[0].axisBorder, r.config.yaxis[0].axisTicks, 0, t, o), o;
    } }, { key: "drawXaxisTicks", value: function(e, t, i) {
      var a = this.w, r = e;
      if (!(e < 0 || e - 2 > a.globals.gridWidth)) {
        var s = this.offY + a.config.xaxis.axisTicks.offsetY;
        if (t = t + s + a.config.xaxis.axisTicks.height, a.config.xaxis.position === "top" && (t = s - a.config.xaxis.axisTicks.height), a.config.xaxis.axisTicks.show) {
          var n = new X(this.ctx).drawLine(e + a.config.xaxis.axisTicks.offsetX, s + a.config.xaxis.offsetY, r + a.config.xaxis.axisTicks.offsetX, t + a.config.xaxis.offsetY, a.config.xaxis.axisTicks.color);
          i.add(n), n.node.classList.add("apexcharts-xaxis-tick");
        }
      }
    } }, { key: "getXAxisTicksPositions", value: function() {
      var e = this.w, t = [], i = this.xaxisLabels.length, a = e.globals.padHorizontal;
      if (e.globals.timescaleLabels.length > 0)
        for (var r = 0; r < i; r++)
          a = this.xaxisLabels[r].position, t.push(a);
      else
        for (var s = i, n = 0; n < s; n++) {
          var o = s;
          e.globals.isXNumeric && e.config.chart.type !== "bar" && (o -= 1), a += e.globals.gridWidth / o, t.push(a);
        }
      return t;
    } }, { key: "xAxisLabelCorrections", value: function() {
      var e = this.w, t = new X(this.ctx), i = e.globals.dom.baseEl.querySelector(".apexcharts-xaxis-texts-g"), a = e.globals.dom.baseEl.querySelectorAll(".apexcharts-xaxis-texts-g text:not(.apexcharts-xaxis-group-label)"), r = e.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxis-inversed text"), s = e.globals.dom.baseEl.querySelectorAll(".apexcharts-xaxis-inversed-texts-g text tspan");
      if (e.globals.rotateXLabels || e.config.xaxis.labels.rotateAlways)
        for (var n = 0; n < a.length; n++) {
          var o = t.rotateAroundCenter(a[n]);
          o.y = o.y - 1, o.x = o.x + 1, a[n].setAttribute("transform", "rotate(".concat(e.config.xaxis.labels.rotate, " ").concat(o.x, " ").concat(o.y, ")")), a[n].setAttribute("text-anchor", "end"), i.setAttribute("transform", "translate(0, ".concat(-10, ")"));
          var h = a[n].childNodes;
          e.config.xaxis.labels.trim && Array.prototype.forEach.call(h, function(p) {
            t.placeTextWithEllipsis(p, p.textContent, e.globals.xAxisLabelsHeight - (e.config.legend.position === "bottom" ? 20 : 10));
          });
        }
      else
        (function() {
          for (var p = e.globals.gridWidth / (e.globals.labels.length + 1), x = 0; x < a.length; x++) {
            var f = a[x].childNodes;
            e.config.xaxis.labels.trim && e.config.xaxis.type !== "datetime" && Array.prototype.forEach.call(f, function(m) {
              t.placeTextWithEllipsis(m, m.textContent, p);
            });
          }
        })();
      if (r.length > 0) {
        var d = r[r.length - 1].getBBox(), c = r[0].getBBox();
        d.x < -20 && r[r.length - 1].parentNode.removeChild(r[r.length - 1]), c.x + c.width > e.globals.gridWidth && !e.globals.isBarHorizontal && r[0].parentNode.removeChild(r[0]);
        for (var g = 0; g < s.length; g++)
          t.placeTextWithEllipsis(s[g], s[g].textContent, e.config.yaxis[0].labels.maxWidth - (e.config.yaxis[0].title.text ? 2 * parseFloat(e.config.yaxis[0].title.style.fontSize) : 0) - 15);
      }
    } }]), y;
  }(), et = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
      var t = this.w;
      this.xaxisLabels = t.globals.labels.slice(), this.axesUtils = new he(e), this.isRangeBar = t.globals.seriesRange.length && t.globals.isBarHorizontal, t.globals.timescaleLabels.length > 0 && (this.xaxisLabels = t.globals.timescaleLabels.slice());
    }
    return F(y, [{ key: "drawGridArea", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null, t = this.w, i = new X(this.ctx);
      e || (e = i.group({ class: "apexcharts-grid" }));
      var a = i.drawLine(t.globals.padHorizontal, 1, t.globals.padHorizontal, t.globals.gridHeight, "transparent"), r = i.drawLine(t.globals.padHorizontal, t.globals.gridHeight, t.globals.gridWidth, t.globals.gridHeight, "transparent");
      return e.add(r), e.add(a), e;
    } }, { key: "drawGrid", value: function() {
      if (this.w.globals.axisCharts) {
        var e = this.renderGrid();
        return this.drawGridArea(e.el), e;
      }
      return null;
    } }, { key: "createGridMask", value: function() {
      var e = this.w, t = e.globals, i = new X(this.ctx), a = Array.isArray(e.config.stroke.width) ? Math.max.apply(Math, J(e.config.stroke.width)) : e.config.stroke.width, r = function(d) {
        var c = document.createElementNS(t.SVGNS, "clipPath");
        return c.setAttribute("id", d), c;
      };
      t.dom.elGridRectMask = r("gridRectMask".concat(t.cuid)), t.dom.elGridRectBarMask = r("gridRectBarMask".concat(t.cuid)), t.dom.elGridRectMarkerMask = r("gridRectMarkerMask".concat(t.cuid)), t.dom.elForecastMask = r("forecastMask".concat(t.cuid)), t.dom.elNonForecastMask = r("nonForecastMask".concat(t.cuid));
      var s = 0, n = 0;
      (["bar", "rangeBar", "candlestick", "boxPlot"].includes(e.config.chart.type) || e.globals.comboBarCount > 0) && e.globals.isXNumeric && !e.globals.isBarHorizontal && (s = Math.max(e.config.grid.padding.left, t.barPadForNumericAxis), n = Math.max(e.config.grid.padding.right, t.barPadForNumericAxis)), t.dom.elGridRect = i.drawRect(0, 0, t.gridWidth, t.gridHeight, 0, "#fff"), t.dom.elGridRectBar = i.drawRect(-a / 2 - s - 2, -a / 2 - 2, t.gridWidth + a + n + s + 4, t.gridHeight + a + 4, 0, "#fff");
      var o = e.globals.markers.largestSize;
      t.dom.elGridRectMarker = i.drawRect(-o, -o, t.gridWidth + 2 * o, t.gridHeight + 2 * o, 0, "#fff"), t.dom.elGridRectMask.appendChild(t.dom.elGridRect.node), t.dom.elGridRectBarMask.appendChild(t.dom.elGridRectBar.node), t.dom.elGridRectMarkerMask.appendChild(t.dom.elGridRectMarker.node);
      var h = t.dom.baseEl.querySelector("defs");
      h.appendChild(t.dom.elGridRectMask), h.appendChild(t.dom.elGridRectBarMask), h.appendChild(t.dom.elGridRectMarkerMask), h.appendChild(t.dom.elForecastMask), h.appendChild(t.dom.elNonForecastMask);
    } }, { key: "_drawGridLines", value: function(e) {
      var t = e.i, i = e.x1, a = e.y1, r = e.x2, s = e.y2, n = e.xCount, o = e.parent, h = this.w;
      if (!(t === 0 && h.globals.skipFirstTimelinelabel || t === n - 1 && h.globals.skipLastTimelinelabel && !h.config.xaxis.labels.formatter || h.config.chart.type === "radar")) {
        h.config.grid.xaxis.lines.show && this._drawGridLine({ i: t, x1: i, y1: a, x2: r, y2: s, xCount: n, parent: o });
        var d = 0;
        if (h.globals.hasXaxisGroups && h.config.xaxis.tickPlacement === "between") {
          var c = h.globals.groups;
          if (c) {
            for (var g = 0, p = 0; g < t && p < c.length; p++)
              g += c[p].cols;
            g === t && (d = 0.6 * h.globals.xAxisLabelsHeight);
          }
        }
        new we(this.ctx).drawXaxisTicks(i, d, h.globals.dom.elGraphical);
      }
    } }, { key: "_drawGridLine", value: function(e) {
      var t = e.i, i = e.x1, a = e.y1, r = e.x2, s = e.y2, n = e.xCount, o = e.parent, h = this.w, d = o.node.classList.contains("apexcharts-gridlines-horizontal"), c = h.globals.barPadForNumericAxis, g = a === 0 && s === 0 || i === 0 && r === 0 || a === h.globals.gridHeight && s === h.globals.gridHeight || h.globals.isBarHorizontal && (t === 0 || t === n - 1), p = new X(this).drawLine(i - (d ? c : 0), a, r + (d ? c : 0), s, h.config.grid.borderColor, h.config.grid.strokeDashArray);
      p.node.classList.add("apexcharts-gridline"), g && h.config.grid.show ? this.elGridBorders.add(p) : o.add(p);
    } }, { key: "_drawGridBandRect", value: function(e) {
      var t = e.c, i = e.x1, a = e.y1, r = e.x2, s = e.y2, n = e.type, o = this.w, h = new X(this.ctx), d = o.globals.barPadForNumericAxis, c = o.config.grid[n].colors[t], g = h.drawRect(i - (n === "row" ? d : 0), a, r + (n === "row" ? 2 * d : 0), s, 0, c, o.config.grid[n].opacity);
      this.elg.add(g), g.attr("clip-path", "url(#gridRectMask".concat(o.globals.cuid, ")")), g.node.classList.add("apexcharts-grid-".concat(n));
    } }, { key: "_drawXYLines", value: function(e) {
      var t = this, i = e.xCount, a = e.tickAmount, r = this.w;
      if (r.config.grid.xaxis.lines.show || r.config.xaxis.axisTicks.show) {
        var s, n = r.globals.padHorizontal, o = r.globals.gridHeight;
        r.globals.timescaleLabels.length ? function(x) {
          for (var f = x.xC, m = x.x1, v = x.y1, w = x.x2, l = x.y2, u = 0; u < f; u++)
            m = t.xaxisLabels[u].position, w = t.xaxisLabels[u].position, t._drawGridLines({ i: u, x1: m, y1: v, x2: w, y2: l, xCount: i, parent: t.elgridLinesV });
        }({ xC: i, x1: n, y1: 0, x2: s, y2: o }) : (r.globals.isXNumeric && (i = r.globals.xAxisScale.result.length), function(x) {
          for (var f = x.xC, m = x.x1, v = x.y1, w = x.x2, l = x.y2, u = 0; u < f + (r.globals.isXNumeric ? 0 : 1); u++)
            u === 0 && f === 1 && r.globals.dataPoints === 1 && (w = m = r.globals.gridWidth / 2), t._drawGridLines({ i: u, x1: m, y1: v, x2: w, y2: l, xCount: i, parent: t.elgridLinesV }), w = m += r.globals.gridWidth / (r.globals.isXNumeric ? f - 1 : f);
        }({ xC: i, x1: n, y1: 0, x2: s, y2: o }));
      }
      if (r.config.grid.yaxis.lines.show) {
        var h = 0, d = 0, c = r.globals.gridWidth, g = a + 1;
        this.isRangeBar && (g = r.globals.labels.length);
        for (var p = 0; p < g + (this.isRangeBar ? 1 : 0); p++)
          this._drawGridLine({ i: p, xCount: g + (this.isRangeBar ? 1 : 0), x1: 0, y1: h, x2: c, y2: d, parent: this.elgridLinesH }), d = h += r.globals.gridHeight / (this.isRangeBar ? g : a);
      }
    } }, { key: "_drawInvertedXYLines", value: function(e) {
      var t = e.xCount, i = this.w;
      if (i.config.grid.xaxis.lines.show || i.config.xaxis.axisTicks.show)
        for (var a, r = i.globals.padHorizontal, s = i.globals.gridHeight, n = 0; n < t + 1; n++)
          i.config.grid.xaxis.lines.show && this._drawGridLine({ i: n, xCount: t + 1, x1: r, y1: 0, x2: a, y2: s, parent: this.elgridLinesV }), new we(this.ctx).drawXaxisTicks(r, 0, i.globals.dom.elGraphical), a = r += i.globals.gridWidth / t;
      if (i.config.grid.yaxis.lines.show)
        for (var o = 0, h = 0, d = i.globals.gridWidth, c = 0; c < i.globals.dataPoints + 1; c++)
          this._drawGridLine({ i: c, xCount: i.globals.dataPoints + 1, x1: 0, y1: o, x2: d, y2: h, parent: this.elgridLinesH }), h = o += i.globals.gridHeight / i.globals.dataPoints;
    } }, { key: "renderGrid", value: function() {
      var e = this.w, t = e.globals, i = new X(this.ctx);
      this.elg = i.group({ class: "apexcharts-grid" }), this.elgridLinesH = i.group({ class: "apexcharts-gridlines-horizontal" }), this.elgridLinesV = i.group({ class: "apexcharts-gridlines-vertical" }), this.elGridBorders = i.group({ class: "apexcharts-grid-borders" }), this.elg.add(this.elgridLinesH), this.elg.add(this.elgridLinesV), e.config.grid.show || (this.elgridLinesV.hide(), this.elgridLinesH.hide(), this.elGridBorders.hide());
      for (var a = 0; a < t.seriesYAxisMap.length && t.ignoreYAxisIndexes.includes(a); )
        a++;
      a === t.seriesYAxisMap.length && (a = 0);
      var r, s = t.yAxisScale[a].result.length - 1;
      if (!t.isBarHorizontal || this.isRangeBar) {
        var n, o, h;
        r = this.xaxisLabels.length, this.isRangeBar && (s = t.labels.length, e.config.xaxis.tickAmount && e.config.xaxis.labels.formatter && (r = e.config.xaxis.tickAmount), ((n = t.yAxisScale) === null || n === void 0 || (o = n[a]) === null || o === void 0 || (h = o.result) === null || h === void 0 ? void 0 : h.length) > 0 && e.config.xaxis.type !== "datetime" && (r = t.yAxisScale[a].result.length - 1)), this._drawXYLines({ xCount: r, tickAmount: s });
      } else
        r = s, s = t.xTickAmount, this._drawInvertedXYLines({ xCount: r, tickAmount: s });
      return this.drawGridBands(r, s), { el: this.elg, elGridBorders: this.elGridBorders, xAxisTickWidth: t.gridWidth / r };
    } }, { key: "drawGridBands", value: function(e, t) {
      var i, a, r = this, s = this.w;
      if (((i = s.config.grid.row.colors) === null || i === void 0 ? void 0 : i.length) > 0 && function(x, f, m, v, w, l) {
        for (var u = 0, b = 0; u < f; u++, b++)
          b >= s.config.grid[x].colors.length && (b = 0), r._drawGridBandRect({ c: b, x1: m, y1: v, x2: w, y2: l, type: x }), v += s.globals.gridHeight / t;
      }("row", t, 0, 0, s.globals.gridWidth, s.globals.gridHeight / t), ((a = s.config.grid.column.colors) === null || a === void 0 ? void 0 : a.length) > 0) {
        var n = s.globals.isBarHorizontal || s.config.xaxis.tickPlacement !== "on" || s.config.xaxis.type !== "category" && !s.config.xaxis.convertedCatToNumeric ? e : e - 1;
        s.globals.isXNumeric && (n = s.globals.xAxisScale.result.length - 1);
        for (var o = s.globals.padHorizontal, h = s.globals.padHorizontal + s.globals.gridWidth / n, d = s.globals.gridHeight, c = 0, g = 0; c < e; c++, g++) {
          var p;
          g >= s.config.grid.column.colors.length && (g = 0), s.config.xaxis.type === "datetime" && (o = this.xaxisLabels[c].position, h = (((p = this.xaxisLabels[c + 1]) === null || p === void 0 ? void 0 : p.position) || s.globals.gridWidth) - this.xaxisLabels[c].position), this._drawGridBandRect({ c: g, x1: o, y1: 0, x2: h, y2: d, type: "column" }), o += s.globals.gridWidth / n;
        }
      }
    } }]), y;
  }(), tt = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.coreUtils = new $(this.ctx);
    }
    return F(y, [{ key: "niceScale", value: function(e, t) {
      var i, a, r, s, n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0, o = 1e-11, h = this.w, d = h.globals;
      d.isBarHorizontal ? (i = h.config.xaxis, a = Math.max((d.svgWidth - 100) / 25, 2)) : (i = h.config.yaxis[n], a = Math.max((d.svgHeight - 100) / 15, 2)), P.isNumber(a) || (a = 10), r = i.min !== void 0 && i.min !== null, s = i.max !== void 0 && i.min !== null;
      var c = i.stepSize !== void 0 && i.stepSize !== null, g = i.tickAmount !== void 0 && i.tickAmount !== null, p = g ? i.tickAmount : d.niceScaleDefaultTicks[Math.min(Math.round(a / 2), d.niceScaleDefaultTicks.length - 1)];
      if (d.isMultipleYAxis && !g && d.multiAxisTickAmount > 0 && (p = d.multiAxisTickAmount, g = !0), p = p === "dataPoints" ? d.dataPoints - 1 : Math.abs(Math.round(p)), (e === Number.MIN_VALUE && t === 0 || !P.isNumber(e) && !P.isNumber(t) || e === Number.MIN_VALUE && t === -Number.MAX_VALUE) && (e = P.isNumber(i.min) ? i.min : 0, t = P.isNumber(i.max) ? i.max : e + p, d.allSeriesCollapsed = !1), e > t) {
        console.warn("axis.min cannot be greater than axis.max: swapping min and max");
        var x = t;
        t = e, e = x;
      } else
        e === t && (e = e === 0 ? 0 : e - 1, t = t === 0 ? 2 : t + 1);
      var f = [];
      p < 1 && (p = 1);
      var m = p, v = Math.abs(t - e);
      !r && e > 0 && e / v < 0.15 && (e = 0, r = !0), !s && t < 0 && -t / v < 0.15 && (t = 0, s = !0);
      var w = (v = Math.abs(t - e)) / m, l = w, u = Math.floor(Math.log10(l)), b = Math.pow(10, u), A = Math.ceil(l / b);
      if (w = l = (A = d.niceScaleAllowedMagMsd[d.yValueDecimal === 0 ? 0 : 1][A]) * b, d.isBarHorizontal && i.stepSize && i.type !== "datetime" ? (w = i.stepSize, c = !0) : c && (w = i.stepSize), c && i.forceNiceScale) {
        var k = Math.floor(Math.log10(w));
        w *= Math.pow(10, u - k);
      }
      if (r && s) {
        var S = v / m;
        if (g)
          if (c)
            if (P.mod(v, w) != 0) {
              var C = P.getGCD(w, S);
              w = S / C < 10 ? C : S;
            } else
              P.mod(w, S) == 0 ? w = S : (S = w, g = !1);
          else
            w = S;
        else if (c)
          P.mod(v, w) == 0 ? S = w : w = S;
        else if (P.mod(v, w) == 0)
          S = w;
        else {
          S = v / (m = Math.ceil(v / w));
          var L = P.getGCD(v, w);
          v / L < a && (S = L), w = S;
        }
        m = Math.round(v / w);
      } else {
        if (r || s) {
          if (s)
            if (g)
              e = t - w * m;
            else {
              var M = e;
              e = w * Math.floor(e / w), Math.abs(t - e) / P.getGCD(v, w) > a && (e = t - w * p, e += w * Math.floor((M - e) / w));
            }
          else if (r)
            if (g)
              t = e + w * m;
            else {
              var T = t;
              t = w * Math.ceil(t / w), Math.abs(t - e) / P.getGCD(v, w) > a && (t = e + w * p, t += w * Math.ceil((T - t) / w));
            }
        } else if (d.isMultipleYAxis && g) {
          var I = w * Math.floor(e / w), z = I + w * m;
          z < t && (w *= 2), z = t, t = (e = I) + w * m, v = Math.abs(t - e), e > 0 && e < Math.abs(z - t) && (e = 0, t = w * m), t < 0 && -t < Math.abs(I - e) && (t = 0, e = -w * m);
        } else
          e = w * Math.floor(e / w), t = w * Math.ceil(t / w);
        v = Math.abs(t - e), w = P.getGCD(v, w), m = Math.round(v / w);
      }
      if (g || r || s || (m = Math.ceil((v - o) / (w + o))) > 16 && P.getPrimeFactors(m).length < 2 && m++, !g && i.forceNiceScale && d.yValueDecimal === 0 && m > v && (m = v, w = Math.round(v / m)), m > a && (!g && !c || i.forceNiceScale)) {
        var Y = P.getPrimeFactors(m), D = Y.length - 1, H = m;
        e:
          for (var O = 0; O < D; O++)
            for (var B = 0; B <= D - O; B++) {
              for (var N = Math.min(B + O, D), W = H, q = 1, Z = B; Z <= N; Z++)
                q *= Y[Z];
              if ((W /= q) < a) {
                H = W;
                break e;
              }
            }
        w = H === m ? v : v / H, m = Math.round(v / w);
      }
      d.isMultipleYAxis && d.multiAxisTickAmount == 0 && d.ignoreYAxisIndexes.indexOf(n) < 0 && (d.multiAxisTickAmount = m);
      var U = e - w, se = w * o;
      do
        U += w, f.push(P.stripNumber(U, 7));
      while (t - U > se);
      return { result: f, niceMin: f[0], niceMax: f[f.length - 1] };
    } }, { key: "linearScale", value: function(e, t) {
      var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 10, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : 0, r = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : void 0, s = Math.abs(t - e), n = [];
      if (e === t)
        return { result: n = [e], niceMin: n[0], niceMax: n[n.length - 1] };
      (i = this._adjustTicksForSmallRange(i, a, s)) === "dataPoints" && (i = this.w.globals.dataPoints - 1), r || (r = s / i), r = Math.round(10 * (r + Number.EPSILON)) / 10, i === Number.MAX_VALUE && (i = 5, r = 1);
      for (var o = e; i >= 0; )
        n.push(o), o = P.preciseAddition(o, r), i -= 1;
      return { result: n, niceMin: n[0], niceMax: n[n.length - 1] };
    } }, { key: "logarithmicScaleNice", value: function(e, t, i) {
      t <= 0 && (t = Math.max(e, i)), e <= 0 && (e = Math.min(t, i));
      for (var a = [], r = Math.ceil(Math.log(t) / Math.log(i) + 1), s = Math.floor(Math.log(e) / Math.log(i)); s < r; s++)
        a.push(Math.pow(i, s));
      return { result: a, niceMin: a[0], niceMax: a[a.length - 1] };
    } }, { key: "logarithmicScale", value: function(e, t, i) {
      t <= 0 && (t = Math.max(e, i)), e <= 0 && (e = Math.min(t, i));
      for (var a = [], r = Math.log(t) / Math.log(i), s = Math.log(e) / Math.log(i), n = r - s, o = Math.round(n), h = n / o, d = 0, c = s; d < o; d++, c += h)
        a.push(Math.pow(i, c));
      return a.push(Math.pow(i, r)), { result: a, niceMin: e, niceMax: t };
    } }, { key: "_adjustTicksForSmallRange", value: function(e, t, i) {
      var a = e;
      if (t !== void 0 && this.w.config.yaxis[t].labels.formatter && this.w.config.yaxis[t].tickAmount === void 0) {
        var r = Number(this.w.config.yaxis[t].labels.formatter(1));
        P.isNumber(r) && this.w.globals.yValueDecimal === 0 && (a = Math.ceil(i));
      }
      return a < e ? a : e;
    } }, { key: "setYScaleForIndex", value: function(e, t, i) {
      var a = this.w.globals, r = this.w.config, s = a.isBarHorizontal ? r.xaxis : r.yaxis[e];
      a.yAxisScale[e] === void 0 && (a.yAxisScale[e] = []);
      var n = Math.abs(i - t);
      s.logarithmic && n <= 5 && (a.invalidLogScale = !0), s.logarithmic && n > 5 ? (a.allSeriesCollapsed = !1, a.yAxisScale[e] = s.forceNiceScale ? this.logarithmicScaleNice(t, i, s.logBase) : this.logarithmicScale(t, i, s.logBase)) : i !== -Number.MAX_VALUE && P.isNumber(i) && t !== Number.MAX_VALUE && P.isNumber(t) ? (a.allSeriesCollapsed = !1, a.yAxisScale[e] = this.niceScale(t, i, e)) : a.yAxisScale[e] = this.niceScale(Number.MIN_VALUE, 0, e);
    } }, { key: "setXScale", value: function(e, t) {
      var i = this.w, a = i.globals, r = Math.abs(t - e);
      if (t !== -Number.MAX_VALUE && P.isNumber(t)) {
        var s = a.xTickAmount + 1;
        r < 10 && r > 1 && (s = r), a.xAxisScale = this.linearScale(e, t, s, 0, i.config.xaxis.stepSize);
      } else
        a.xAxisScale = this.linearScale(0, 10, 10);
      return a.xAxisScale;
    } }, { key: "scaleMultipleYAxes", value: function() {
      var e = this, t = this.w.config, i = this.w.globals;
      this.coreUtils.setSeriesYAxisMappings();
      var a = i.seriesYAxisMap, r = i.minYArr, s = i.maxYArr;
      i.allSeriesCollapsed = !0, i.barGroups = [], a.forEach(function(n, o) {
        var h = [];
        n.forEach(function(d) {
          var c = t.series[d].group;
          h.indexOf(c) < 0 && h.push(c);
        }), n.length > 0 ? function() {
          var d, c, g = Number.MAX_VALUE, p = -Number.MAX_VALUE, x = g, f = p;
          if (t.chart.stacked)
            (function() {
              var w = new Array(i.dataPoints).fill(0), l = [], u = [], b = [];
              h.forEach(function() {
                l.push(w.map(function() {
                  return Number.MIN_VALUE;
                })), u.push(w.map(function() {
                  return Number.MIN_VALUE;
                })), b.push(w.map(function() {
                  return Number.MIN_VALUE;
                }));
              });
              for (var A = function(S) {
                !d && t.series[n[S]].type && (d = t.series[n[S]].type);
                var C = n[S];
                c = t.series[C].group ? t.series[C].group : "axis-".concat(o), !(i.collapsedSeriesIndices.indexOf(C) < 0 && i.ancillaryCollapsedSeriesIndices.indexOf(C) < 0) || (i.allSeriesCollapsed = !1, h.forEach(function(L, M) {
                  if (t.series[C].group === L)
                    for (var T = 0; T < i.series[C].length; T++) {
                      var I = i.series[C][T];
                      I >= 0 ? u[M][T] += I : b[M][T] += I, l[M][T] += I, x = Math.min(x, I), f = Math.max(f, I);
                    }
                })), d !== "bar" && d !== "column" || i.barGroups.push(c);
              }, k = 0; k < n.length; k++)
                A(k);
              d || (d = t.chart.type), d === "bar" || d === "column" ? h.forEach(function(S, C) {
                g = Math.min(g, Math.min.apply(null, b[C])), p = Math.max(p, Math.max.apply(null, u[C]));
              }) : (h.forEach(function(S, C) {
                x = Math.min(x, Math.min.apply(null, l[C])), f = Math.max(f, Math.max.apply(null, l[C]));
              }), g = x, p = f), g === Number.MIN_VALUE && p === Number.MIN_VALUE && (p = -Number.MAX_VALUE);
            })();
          else
            for (var m = 0; m < n.length; m++) {
              var v = n[m];
              g = Math.min(g, r[v]), p = Math.max(p, s[v]), !(i.collapsedSeriesIndices.indexOf(v) < 0 && i.ancillaryCollapsedSeriesIndices.indexOf(v) < 0) || (i.allSeriesCollapsed = !1);
            }
          t.yaxis[o].min !== void 0 && (g = typeof t.yaxis[o].min == "function" ? t.yaxis[o].min(g) : t.yaxis[o].min), t.yaxis[o].max !== void 0 && (p = typeof t.yaxis[o].max == "function" ? t.yaxis[o].max(p) : t.yaxis[o].max), i.barGroups = i.barGroups.filter(function(w, l, u) {
            return u.indexOf(w) === l;
          }), e.setYScaleForIndex(o, g, p), n.forEach(function(w) {
            r[w] = i.yAxisScale[o].niceMin, s[w] = i.yAxisScale[o].niceMax;
          });
        }() : e.setYScaleForIndex(o, 0, -Number.MAX_VALUE);
      });
    } }]), y;
  }(), Fe = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.scales = new tt(e);
    }
    return F(y, [{ key: "init", value: function() {
      this.setYRange(), this.setXRange(), this.setZRange();
    } }, { key: "getMinYMaxY", value: function(e) {
      var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : Number.MAX_VALUE, i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : -Number.MAX_VALUE, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : null, r = this.w.config, s = this.w.globals, n = -Number.MAX_VALUE, o = Number.MIN_VALUE;
      a === null && (a = e + 1);
      var h = s.series, d = h, c = h;
      r.chart.type === "candlestick" ? (d = s.seriesCandleL, c = s.seriesCandleH) : r.chart.type === "boxPlot" ? (d = s.seriesCandleO, c = s.seriesCandleC) : s.isRangeData && (d = s.seriesRangeStart, c = s.seriesRangeEnd);
      var g = !1;
      if (s.seriesX.length >= a) {
        var p, x = (p = s.brushSource) === null || p === void 0 ? void 0 : p.w.config.chart.brush;
        (r.chart.zoom.enabled && r.chart.zoom.autoScaleYaxis || x != null && x.enabled && x != null && x.autoScaleYaxis) && (g = !0);
      }
      for (var f = e; f < a; f++) {
        s.dataPoints = Math.max(s.dataPoints, h[f].length);
        var m = r.series[f].type;
        s.categoryLabels.length && (s.dataPoints = s.categoryLabels.filter(function(b) {
          return b !== void 0;
        }).length), s.labels.length && r.xaxis.type !== "datetime" && s.series.reduce(function(b, A) {
          return b + A.length;
        }, 0) !== 0 && (s.dataPoints = Math.max(s.dataPoints, s.labels.length));
        var v = 0, w = h[f].length - 1;
        if (g) {
          if (r.xaxis.min)
            for (; v < w && s.seriesX[f][v] < r.xaxis.min; v++)
              ;
          if (r.xaxis.max)
            for (; w > v && s.seriesX[f][w] > r.xaxis.max; w--)
              ;
        }
        for (var l = v; l <= w && l < s.series[f].length; l++) {
          var u = h[f][l];
          if (u !== null && P.isNumber(u)) {
            switch (c[f][l] !== void 0 && (n = Math.max(n, c[f][l]), t = Math.min(t, c[f][l])), d[f][l] !== void 0 && (t = Math.min(t, d[f][l]), i = Math.max(i, d[f][l])), m) {
              case "candlestick":
                s.seriesCandleC[f][l] !== void 0 && (n = Math.max(n, s.seriesCandleH[f][l]), t = Math.min(t, s.seriesCandleL[f][l]));
                break;
              case "boxPlot":
                s.seriesCandleC[f][l] !== void 0 && (n = Math.max(n, s.seriesCandleC[f][l]), t = Math.min(t, s.seriesCandleO[f][l]));
            }
            m && m !== "candlestick" && m !== "boxPlot" && m !== "rangeArea" && m !== "rangeBar" && (n = Math.max(n, s.series[f][l]), t = Math.min(t, s.series[f][l])), i = n, s.seriesGoals[f] && s.seriesGoals[f][l] && Array.isArray(s.seriesGoals[f][l]) && s.seriesGoals[f][l].forEach(function(b) {
              o !== Number.MIN_VALUE && (o = Math.min(o, b.value), t = o), n = Math.max(n, b.value), i = n;
            }), P.isFloat(u) && (u = P.noExponents(u), s.yValueDecimal = Math.max(s.yValueDecimal, u.toString().split(".")[1].length)), o > d[f][l] && d[f][l] < 0 && (o = d[f][l]);
          } else
            s.hasNullValues = !0;
        }
        m !== "bar" && m !== "column" || (o < 0 && n < 0 && (n = 0, i = Math.max(i, 0)), o === Number.MIN_VALUE && (o = 0, t = Math.min(t, 0)));
      }
      return r.chart.type === "rangeBar" && s.seriesRangeStart.length && s.isBarHorizontal && (o = t), r.chart.type === "bar" && (o < 0 && n < 0 && (n = 0), o === Number.MIN_VALUE && (o = 0)), { minY: o, maxY: n, lowestY: t, highestY: i };
    } }, { key: "setYRange", value: function() {
      var e = this.w.globals, t = this.w.config;
      e.maxY = -Number.MAX_VALUE, e.minY = Number.MIN_VALUE;
      var i, a = Number.MAX_VALUE;
      if (e.isMultipleYAxis) {
        a = Number.MAX_VALUE;
        for (var r = 0; r < e.series.length; r++)
          i = this.getMinYMaxY(r), e.minYArr[r] = i.lowestY, e.maxYArr[r] = i.highestY, a = Math.min(a, i.lowestY);
      }
      return i = this.getMinYMaxY(0, a, null, e.series.length), t.chart.type === "bar" ? (e.minY = i.minY, e.maxY = i.maxY) : (e.minY = i.lowestY, e.maxY = i.highestY), a = i.lowestY, t.chart.stacked && this._setStackedMinMax(), t.chart.type === "line" || t.chart.type === "area" || t.chart.type === "scatter" || t.chart.type === "candlestick" || t.chart.type === "boxPlot" || t.chart.type === "rangeBar" && !e.isBarHorizontal ? e.minY === Number.MIN_VALUE && a !== -Number.MAX_VALUE && a !== e.maxY && (e.minY = a) : e.minY = e.minY !== Number.MIN_VALUE ? Math.min(i.minY, e.minY) : i.minY, t.yaxis.forEach(function(s, n) {
        s.max !== void 0 && (typeof s.max == "number" ? e.maxYArr[n] = s.max : typeof s.max == "function" && (e.maxYArr[n] = s.max(e.isMultipleYAxis ? e.maxYArr[n] : e.maxY)), e.maxY = e.maxYArr[n]), s.min !== void 0 && (typeof s.min == "number" ? e.minYArr[n] = s.min : typeof s.min == "function" && (e.minYArr[n] = s.min(e.isMultipleYAxis ? e.minYArr[n] === Number.MIN_VALUE ? 0 : e.minYArr[n] : e.minY)), e.minY = e.minYArr[n]);
      }), e.isBarHorizontal && ["min", "max"].forEach(function(s) {
        t.xaxis[s] !== void 0 && typeof t.xaxis[s] == "number" && (s === "min" ? e.minY = t.xaxis[s] : e.maxY = t.xaxis[s]);
      }), e.isMultipleYAxis ? (this.scales.scaleMultipleYAxes(), e.minY = a) : (this.scales.setYScaleForIndex(0, e.minY, e.maxY), e.minY = e.yAxisScale[0].niceMin, e.maxY = e.yAxisScale[0].niceMax, e.minYArr[0] = e.minY, e.maxYArr[0] = e.maxY), e.barGroups = [], e.lineGroups = [], e.areaGroups = [], t.series.forEach(function(s) {
        switch (s.type || t.chart.type) {
          case "bar":
          case "column":
            e.barGroups.push(s.group);
            break;
          case "line":
            e.lineGroups.push(s.group);
            break;
          case "area":
            e.areaGroups.push(s.group);
        }
      }), e.barGroups = e.barGroups.filter(function(s, n, o) {
        return o.indexOf(s) === n;
      }), e.lineGroups = e.lineGroups.filter(function(s, n, o) {
        return o.indexOf(s) === n;
      }), e.areaGroups = e.areaGroups.filter(function(s, n, o) {
        return o.indexOf(s) === n;
      }), { minY: e.minY, maxY: e.maxY, minYArr: e.minYArr, maxYArr: e.maxYArr, yAxisScale: e.yAxisScale };
    } }, { key: "setXRange", value: function() {
      var e = this.w.globals, t = this.w.config, i = t.xaxis.type === "numeric" || t.xaxis.type === "datetime" || t.xaxis.type === "category" && !e.noLabelsProvided || e.noLabelsProvided || e.isXNumeric;
      if (e.isXNumeric && function() {
        for (var o = 0; o < e.series.length; o++)
          if (e.labels[o])
            for (var h = 0; h < e.labels[o].length; h++)
              e.labels[o][h] !== null && P.isNumber(e.labels[o][h]) && (e.maxX = Math.max(e.maxX, e.labels[o][h]), e.initialMaxX = Math.max(e.maxX, e.labels[o][h]), e.minX = Math.min(e.minX, e.labels[o][h]), e.initialMinX = Math.min(e.minX, e.labels[o][h]));
      }(), e.noLabelsProvided && t.xaxis.categories.length === 0 && (e.maxX = e.labels[e.labels.length - 1], e.initialMaxX = e.labels[e.labels.length - 1], e.minX = 1, e.initialMinX = 1), e.isXNumeric || e.noLabelsProvided || e.dataFormatXNumeric) {
        var a = 10;
        if (t.xaxis.tickAmount === void 0)
          a = Math.round(e.svgWidth / 150), t.xaxis.type === "numeric" && e.dataPoints < 30 && (a = e.dataPoints - 1), a > e.dataPoints && e.dataPoints !== 0 && (a = e.dataPoints - 1);
        else if (t.xaxis.tickAmount === "dataPoints") {
          if (e.series.length > 1 && (a = e.series[e.maxValsInArrayIndex].length - 1), e.isXNumeric) {
            var r = e.maxX - e.minX;
            r < 30 && (a = r - 1);
          }
        } else
          a = t.xaxis.tickAmount;
        if (e.xTickAmount = a, t.xaxis.max !== void 0 && typeof t.xaxis.max == "number" && (e.maxX = t.xaxis.max), t.xaxis.min !== void 0 && typeof t.xaxis.min == "number" && (e.minX = t.xaxis.min), t.xaxis.range !== void 0 && (e.minX = e.maxX - t.xaxis.range), e.minX !== Number.MAX_VALUE && e.maxX !== -Number.MAX_VALUE)
          if (t.xaxis.convertedCatToNumeric && !e.dataFormatXNumeric) {
            for (var s = [], n = e.minX - 1; n < e.maxX; n++)
              s.push(n + 1);
            e.xAxisScale = { result: s, niceMin: s[0], niceMax: s[s.length - 1] };
          } else
            e.xAxisScale = this.scales.setXScale(e.minX, e.maxX);
        else
          e.xAxisScale = this.scales.linearScale(0, a, a, 0, t.xaxis.stepSize), e.noLabelsProvided && e.labels.length > 0 && (e.xAxisScale = this.scales.linearScale(1, e.labels.length, a - 1, 0, t.xaxis.stepSize), e.seriesX = e.labels.slice());
        i && (e.labels = e.xAxisScale.result.slice());
      }
      return e.isBarHorizontal && e.labels.length && (e.xTickAmount = e.labels.length), this._handleSingleDataPoint(), this._getMinXDiff(), { minX: e.minX, maxX: e.maxX };
    } }, { key: "setZRange", value: function() {
      var e = this.w.globals;
      if (e.isDataXYZ) {
        for (var t = 0; t < e.series.length; t++)
          if (e.seriesZ[t] !== void 0)
            for (var i = 0; i < e.seriesZ[t].length; i++)
              e.seriesZ[t][i] !== null && P.isNumber(e.seriesZ[t][i]) && (e.maxZ = Math.max(e.maxZ, e.seriesZ[t][i]), e.minZ = Math.min(e.minZ, e.seriesZ[t][i]));
      }
    } }, { key: "_handleSingleDataPoint", value: function() {
      var e = this.w.globals, t = this.w.config;
      if (e.minX === e.maxX) {
        var i = new K(this.ctx);
        if (t.xaxis.type === "datetime") {
          var a = i.getDate(e.minX);
          t.xaxis.labels.datetimeUTC ? a.setUTCDate(a.getUTCDate() - 2) : a.setDate(a.getDate() - 2), e.minX = new Date(a).getTime();
          var r = i.getDate(e.maxX);
          t.xaxis.labels.datetimeUTC ? r.setUTCDate(r.getUTCDate() + 2) : r.setDate(r.getDate() + 2), e.maxX = new Date(r).getTime();
        } else
          (t.xaxis.type === "numeric" || t.xaxis.type === "category" && !e.noLabelsProvided) && (e.minX = e.minX - 2, e.initialMinX = e.minX, e.maxX = e.maxX + 2, e.initialMaxX = e.maxX);
      }
    } }, { key: "_getMinXDiff", value: function() {
      var e = this.w.globals;
      e.isXNumeric && e.seriesX.forEach(function(t, i) {
        t.length === 1 && t.push(e.seriesX[e.maxValsInArrayIndex][e.seriesX[e.maxValsInArrayIndex].length - 1]);
        var a = t.slice();
        a.sort(function(r, s) {
          return r - s;
        }), a.forEach(function(r, s) {
          if (s > 0) {
            var n = r - a[s - 1];
            n > 0 && (e.minXDiff = Math.min(n, e.minXDiff));
          }
        }), e.dataPoints !== 1 && e.minXDiff !== Number.MAX_VALUE || (e.minXDiff = 0.5);
      });
    } }, { key: "_setStackedMinMax", value: function() {
      var e = this, t = this.w.globals;
      if (t.series.length) {
        var i = t.seriesGroups;
        i.length || (i = [this.w.globals.seriesNames.map(function(s) {
          return s;
        })]);
        var a = {}, r = {};
        i.forEach(function(s) {
          a[s] = [], r[s] = [], e.w.config.series.map(function(n, o) {
            return s.indexOf(t.seriesNames[o]) > -1 ? o : null;
          }).filter(function(n) {
            return n !== null;
          }).forEach(function(n) {
            for (var o = 0; o < t.series[t.maxValsInArrayIndex].length; o++) {
              var h, d, c, g;
              a[s][o] === void 0 && (a[s][o] = 0, r[s][o] = 0), (e.w.config.chart.stacked && !t.comboCharts || e.w.config.chart.stacked && t.comboCharts && (!e.w.config.chart.stackOnlyBar || ((h = e.w.config.series) === null || h === void 0 || (d = h[n]) === null || d === void 0 ? void 0 : d.type) === "bar" || ((c = e.w.config.series) === null || c === void 0 || (g = c[n]) === null || g === void 0 ? void 0 : g.type) === "column")) && t.series[n][o] !== null && P.isNumber(t.series[n][o]) && (t.series[n][o] > 0 ? a[s][o] += parseFloat(t.series[n][o]) + 1e-4 : r[s][o] += parseFloat(t.series[n][o]));
            }
          });
        }), Object.entries(a).forEach(function(s) {
          var n = Ze(s, 1)[0];
          a[n].forEach(function(o, h) {
            t.maxY = Math.max(t.maxY, a[n][h]), t.minY = Math.min(t.minY, r[n][h]);
          });
        });
      }
    } }]), y;
  }(), De = function() {
    function y(e, t) {
      R(this, y), this.ctx = e, this.elgrid = t, this.w = e.w;
      var i = this.w;
      this.xaxisFontSize = i.config.xaxis.labels.style.fontSize, this.axisFontFamily = i.config.xaxis.labels.style.fontFamily, this.xaxisForeColors = i.config.xaxis.labels.style.colors, this.isCategoryBarHorizontal = i.config.chart.type === "bar" && i.config.plotOptions.bar.horizontal, this.xAxisoffX = i.config.xaxis.position === "bottom" ? i.globals.gridHeight : 0, this.drawnLabels = [], this.axesUtils = new he(e);
    }
    return F(y, [{ key: "drawYaxis", value: function(e) {
      var t = this.w, i = new X(this.ctx), a = t.config.yaxis[e].labels.style, r = a.fontSize, s = a.fontFamily, n = a.fontWeight, o = i.group({ class: "apexcharts-yaxis", rel: e, transform: "translate(".concat(t.globals.translateYAxisX[e], ", 0)") });
      if (this.axesUtils.isYAxisHidden(e))
        return o;
      var h = i.group({ class: "apexcharts-yaxis-texts-g" });
      o.add(h);
      var d = t.globals.yAxisScale[e].result.length - 1, c = t.globals.gridHeight / d, g = t.globals.yLabelFormatters[e], p = this.axesUtils.checkForReversedLabels(e, t.globals.yAxisScale[e].result.slice());
      if (t.config.yaxis[e].labels.show) {
        var x = t.globals.translateY + t.config.yaxis[e].labels.offsetY;
        t.globals.isBarHorizontal ? x = 0 : t.config.chart.type === "heatmap" && (x -= c / 2), x += parseInt(r, 10) / 3;
        for (var f = d; f >= 0; f--) {
          var m = g(p[f], f, t), v = t.config.yaxis[e].labels.padding;
          t.config.yaxis[e].opposite && t.config.yaxis.length !== 0 && (v *= -1);
          var w = this.getTextAnchor(t.config.yaxis[e].labels.align, t.config.yaxis[e].opposite), l = this.axesUtils.getYAxisForeColor(a.colors, e), u = Array.isArray(l) ? l[f] : l, b = P.listToArray(t.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxis[rel='".concat(e, "'] .apexcharts-yaxis-label tspan"))).map(function(k) {
            return k.textContent;
          }), A = i.drawText({ x: v, y: x, text: b.includes(m) && !t.config.yaxis[e].labels.showDuplicates ? "" : m, textAnchor: w, fontSize: r, fontFamily: s, fontWeight: n, maxWidth: t.config.yaxis[e].labels.maxWidth, foreColor: u, isPlainText: !1, cssClass: "apexcharts-yaxis-label ".concat(a.cssClass) });
          h.add(A), this.addTooltip(A, m), t.config.yaxis[e].labels.rotate !== 0 && this.rotateLabel(i, A, firstLabel, t.config.yaxis[e].labels.rotate), x += c;
        }
      }
      return this.addYAxisTitle(i, o, e), this.addAxisBorder(i, o, e, d, c), o;
    } }, { key: "getTextAnchor", value: function(e, t) {
      return e === "left" ? "start" : e === "center" ? "middle" : e === "right" ? "end" : t ? "start" : "end";
    } }, { key: "addTooltip", value: function(e, t) {
      var i = document.createElementNS(this.w.globals.SVGNS, "title");
      i.textContent = Array.isArray(t) ? t.join(" ") : t, e.node.appendChild(i);
    } }, { key: "rotateLabel", value: function(e, t, i, a) {
      var r = e.rotateAroundCenter(i.node), s = e.rotateAroundCenter(t.node);
      t.node.setAttribute("transform", "rotate(".concat(a, " ").concat(r.x, " ").concat(s.y, ")"));
    } }, { key: "addYAxisTitle", value: function(e, t, i) {
      var a = this.w;
      if (a.config.yaxis[i].title.text !== void 0) {
        var r = e.group({ class: "apexcharts-yaxis-title" }), s = a.config.yaxis[i].opposite ? a.globals.translateYAxisX[i] : 0, n = e.drawText({ x: s, y: a.globals.gridHeight / 2 + a.globals.translateY + a.config.yaxis[i].title.offsetY, text: a.config.yaxis[i].title.text, textAnchor: "end", foreColor: a.config.yaxis[i].title.style.color, fontSize: a.config.yaxis[i].title.style.fontSize, fontWeight: a.config.yaxis[i].title.style.fontWeight, fontFamily: a.config.yaxis[i].title.style.fontFamily, cssClass: "apexcharts-yaxis-title-text ".concat(a.config.yaxis[i].title.style.cssClass) });
        r.add(n), t.add(r);
      }
    } }, { key: "addAxisBorder", value: function(e, t, i, a, r) {
      var s = this.w, n = s.config.yaxis[i].axisBorder, o = 31 + n.offsetX;
      if (s.config.yaxis[i].opposite && (o = -31 - n.offsetX), n.show) {
        var h = e.drawLine(o, s.globals.translateY + n.offsetY - 2, o, s.globals.gridHeight + s.globals.translateY + n.offsetY + 2, n.color, 0, n.width);
        t.add(h);
      }
      s.config.yaxis[i].axisTicks.show && this.axesUtils.drawYAxisTicks(o, a, n, s.config.yaxis[i].axisTicks, i, r, t);
    } }, { key: "drawYaxisInversed", value: function(e) {
      var t = this.w, i = new X(this.ctx), a = i.group({ class: "apexcharts-xaxis apexcharts-yaxis-inversed" }), r = i.group({ class: "apexcharts-xaxis-texts-g", transform: "translate(".concat(t.globals.translateXAxisX, ", ").concat(t.globals.translateXAxisY, ")") });
      a.add(r);
      var s = t.globals.yAxisScale[e].result.length - 1, n = t.globals.gridWidth / s + 0.1, o = n + t.config.xaxis.labels.offsetX, h = t.globals.xLabelFormatter, d = this.axesUtils.checkForReversedLabels(e, t.globals.yAxisScale[e].result.slice()), c = t.globals.timescaleLabels;
      if (c.length > 0 && (this.xaxisLabels = c.slice(), s = (d = c.slice()).length), t.config.xaxis.labels.show)
        for (var g = c.length ? 0 : s; c.length ? g < c.length : g >= 0; c.length ? g++ : g--) {
          var p = h(d[g], g, t), x = t.globals.gridWidth + t.globals.padHorizontal - (o - n + t.config.xaxis.labels.offsetX);
          if (c.length) {
            var f = this.axesUtils.getLabel(d, c, x, g, this.drawnLabels, this.xaxisFontSize);
            x = f.x, p = f.text, this.drawnLabels.push(f.text), g === 0 && t.globals.skipFirstTimelinelabel && (p = ""), g === d.length - 1 && t.globals.skipLastTimelinelabel && (p = "");
          }
          var m = i.drawText({ x, y: this.xAxisoffX + t.config.xaxis.labels.offsetY + 30 - (t.config.xaxis.position === "top" ? t.globals.xAxisHeight + t.config.xaxis.axisTicks.height - 2 : 0), text: p, textAnchor: "middle", foreColor: Array.isArray(this.xaxisForeColors) ? this.xaxisForeColors[e] : this.xaxisForeColors, fontSize: this.xaxisFontSize, fontFamily: this.xaxisFontFamily, fontWeight: t.config.xaxis.labels.style.fontWeight, isPlainText: !1, cssClass: "apexcharts-xaxis-label ".concat(t.config.xaxis.labels.style.cssClass) });
          r.add(m), m.tspan(p), this.addTooltip(m, p), o += n;
        }
      return this.inversedYAxisTitleText(a), this.inversedYAxisBorder(a), a;
    } }, { key: "inversedYAxisBorder", value: function(e) {
      var t = this.w, i = new X(this.ctx), a = t.config.xaxis.axisBorder;
      if (a.show) {
        var r = 0;
        t.config.chart.type === "bar" && t.globals.isXNumeric && (r -= 15);
        var s = i.drawLine(t.globals.padHorizontal + r + a.offsetX, this.xAxisoffX, t.globals.gridWidth, this.xAxisoffX, a.color, 0, a.height);
        this.elgrid && this.elgrid.elGridBorders && t.config.grid.show ? this.elgrid.elGridBorders.add(s) : e.add(s);
      }
    } }, { key: "inversedYAxisTitleText", value: function(e) {
      var t = this.w, i = new X(this.ctx);
      if (t.config.xaxis.title.text !== void 0) {
        var a = i.group({ class: "apexcharts-xaxis-title apexcharts-yaxis-title-inversed" }), r = i.drawText({ x: t.globals.gridWidth / 2 + t.config.xaxis.title.offsetX, y: this.xAxisoffX + parseFloat(this.xaxisFontSize) + parseFloat(t.config.xaxis.title.style.fontSize) + t.config.xaxis.title.offsetY + 20, text: t.config.xaxis.title.text, textAnchor: "middle", fontSize: t.config.xaxis.title.style.fontSize, fontFamily: t.config.xaxis.title.style.fontFamily, fontWeight: t.config.xaxis.title.style.fontWeight, foreColor: t.config.xaxis.title.style.color, cssClass: "apexcharts-xaxis-title-text ".concat(t.config.xaxis.title.style.cssClass) });
        a.add(r), e.add(a);
      }
    } }, { key: "yAxisTitleRotate", value: function(e, t) {
      var i = this.w, a = new X(this.ctx), r = i.globals.dom.baseEl.querySelector(".apexcharts-yaxis[rel='".concat(e, "'] .apexcharts-yaxis-texts-g")), s = r ? r.getBoundingClientRect() : { width: 0, height: 0 }, n = i.globals.dom.baseEl.querySelector(".apexcharts-yaxis[rel='".concat(e, "'] .apexcharts-yaxis-title text")), o = n ? n.getBoundingClientRect() : { width: 0, height: 0 };
      if (n) {
        var h = this.xPaddingForYAxisTitle(e, s, o, t);
        n.setAttribute("x", h.xPos - (t ? 10 : 0));
        var d = a.rotateAroundCenter(n);
        n.setAttribute("transform", "rotate(".concat(t ? -1 * i.config.yaxis[e].title.rotate : i.config.yaxis[e].title.rotate, " ").concat(d.x, " ").concat(d.y, ")"));
      }
    } }, { key: "xPaddingForYAxisTitle", value: function(e, t, i, a) {
      var r = this.w, s = 0, n = 10;
      return r.config.yaxis[e].title.text === void 0 || e < 0 ? { xPos: s, padd: 0 } : (a ? s = t.width + r.config.yaxis[e].title.offsetX + i.width / 2 + n / 2 : (s = -1 * t.width + r.config.yaxis[e].title.offsetX + n / 2 + i.width / 2, r.globals.isBarHorizontal && (n = 25, s = -1 * t.width - r.config.yaxis[e].title.offsetX - n)), { xPos: s, padd: n });
    } }, { key: "setYAxisXPosition", value: function(e, t) {
      var i = this.w, a = 0, r = 0, s = 18, n = 1;
      i.config.yaxis.length > 1 && (this.multipleYs = !0), i.config.yaxis.forEach(function(o, h) {
        var d = i.globals.ignoreYAxisIndexes.includes(h) || !o.show || o.floating || e[h].width === 0, c = e[h].width + t[h].width;
        o.opposite ? i.globals.isBarHorizontal ? (r = i.globals.gridWidth + i.globals.translateX - 1, i.globals.translateYAxisX[h] = r - o.labels.offsetX) : (r = i.globals.gridWidth + i.globals.translateX + n, d || (n += c + 20), i.globals.translateYAxisX[h] = r - o.labels.offsetX + 20) : (a = i.globals.translateX - s, d || (s += c + 20), i.globals.translateYAxisX[h] = a + o.labels.offsetX);
      });
    } }, { key: "setYAxisTextAlignments", value: function() {
      var e = this.w;
      P.listToArray(e.globals.dom.baseEl.getElementsByClassName("apexcharts-yaxis")).forEach(function(t, i) {
        var a = e.config.yaxis[i];
        if (a && !a.floating && a.labels.align !== void 0) {
          var r = e.globals.dom.baseEl.querySelector(".apexcharts-yaxis[rel='".concat(i, "'] .apexcharts-yaxis-texts-g")), s = P.listToArray(e.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxis[rel='".concat(i, "'] .apexcharts-yaxis-label"))), n = r.getBoundingClientRect();
          s.forEach(function(o) {
            o.setAttribute("text-anchor", a.labels.align);
          }), a.labels.align !== "left" || a.opposite ? a.labels.align === "center" ? r.setAttribute("transform", "translate(".concat(n.width / 2 * (a.opposite ? 1 : -1), ", 0)")) : a.labels.align === "right" && a.opposite && r.setAttribute("transform", "translate(".concat(n.width, ", 0)")) : r.setAttribute("transform", "translate(-".concat(n.width, ", 0)"));
        }
      });
    } }]), y;
  }(), yt = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.documentEvent = P.bind(this.documentEvent, this);
    }
    return F(y, [{ key: "addEventListener", value: function(e, t) {
      var i = this.w;
      i.globals.events.hasOwnProperty(e) ? i.globals.events[e].push(t) : i.globals.events[e] = [t];
    } }, { key: "removeEventListener", value: function(e, t) {
      var i = this.w;
      if (i.globals.events.hasOwnProperty(e)) {
        var a = i.globals.events[e].indexOf(t);
        a !== -1 && i.globals.events[e].splice(a, 1);
      }
    } }, { key: "fireEvent", value: function(e, t) {
      var i = this.w;
      if (i.globals.events.hasOwnProperty(e)) {
        t && t.length || (t = []);
        for (var a = i.globals.events[e], r = a.length, s = 0; s < r; s++)
          a[s].apply(null, t);
      }
    } }, { key: "setupEventHandlers", value: function() {
      var e = this, t = this.w, i = this.ctx, a = t.globals.dom.baseEl.querySelector(t.globals.chartClass);
      this.ctx.eventList.forEach(function(r) {
        a.addEventListener(r, function(s) {
          var n = Object.assign({}, t, { seriesIndex: t.globals.axisCharts ? t.globals.capturedSeriesIndex : 0, dataPointIndex: t.globals.capturedDataPointIndex });
          s.type === "mousemove" || s.type === "touchmove" ? typeof t.config.chart.events.mouseMove == "function" && t.config.chart.events.mouseMove(s, i, n) : s.type === "mouseleave" || s.type === "touchleave" ? typeof t.config.chart.events.mouseLeave == "function" && t.config.chart.events.mouseLeave(s, i, n) : (s.type === "mouseup" && s.which === 1 || s.type === "touchend") && (typeof t.config.chart.events.click == "function" && t.config.chart.events.click(s, i, n), i.ctx.events.fireEvent("click", [s, i, n]));
        }, { capture: !1, passive: !0 });
      }), this.ctx.eventList.forEach(function(r) {
        t.globals.dom.baseEl.addEventListener(r, e.documentEvent, { passive: !0 });
      }), this.ctx.core.setupBrushHandler();
    } }, { key: "documentEvent", value: function(e) {
      var t = this.w, i = e.target.className;
      if (e.type === "click") {
        var a = t.globals.dom.baseEl.querySelector(".apexcharts-menu");
        a && a.classList.contains("apexcharts-menu-open") && i !== "apexcharts-menu-icon" && a.classList.remove("apexcharts-menu-open");
      }
      t.globals.clientX = e.type === "touchmove" ? e.touches[0].clientX : e.clientX, t.globals.clientY = e.type === "touchmove" ? e.touches[0].clientY : e.clientY;
    } }]), y;
  }(), wt = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "setCurrentLocaleValues", value: function(e) {
      var t = this.w.config.chart.locales;
      window.Apex.chart && window.Apex.chart.locales && window.Apex.chart.locales.length > 0 && (t = this.w.config.chart.locales.concat(window.Apex.chart.locales));
      var i = t.filter(function(r) {
        return r.name === e;
      })[0];
      if (!i)
        throw new Error("Wrong locale name provided. Please make sure you set the correct locale name in options");
      var a = P.extend(Je, i);
      this.w.globals.locale = a.options;
    } }]), y;
  }(), kt = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "drawAxis", value: function(e, t) {
      var i, a, r = this, s = this.w.globals, n = this.w.config, o = new we(this.ctx, t), h = new De(this.ctx, t);
      s.axisCharts && e !== "radar" && (s.isBarHorizontal ? (a = h.drawYaxisInversed(0), i = o.drawXaxisInversed(0), s.dom.elGraphical.add(i), s.dom.elGraphical.add(a)) : (i = o.drawXaxis(), s.dom.elGraphical.add(i), n.yaxis.map(function(d, c) {
        if (s.ignoreYAxisIndexes.indexOf(c) === -1 && (a = h.drawYaxis(c), s.dom.Paper.add(a), r.w.config.grid.position === "back")) {
          var g = s.dom.Paper.children()[1];
          g.remove(), s.dom.Paper.add(g);
        }
      })));
    } }]), y;
  }(), He = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "drawXCrosshairs", value: function() {
      var e = this.w, t = new X(this.ctx), i = new ee(this.ctx), a = e.config.xaxis.crosshairs.fill.gradient, r = e.config.xaxis.crosshairs.dropShadow, s = e.config.xaxis.crosshairs.fill.type, n = a.colorFrom, o = a.colorTo, h = a.opacityFrom, d = a.opacityTo, c = a.stops, g = r.enabled, p = r.left, x = r.top, f = r.blur, m = r.color, v = r.opacity, w = e.config.xaxis.crosshairs.fill.color;
      if (e.config.xaxis.crosshairs.show) {
        s === "gradient" && (w = t.drawGradient("vertical", n, o, h, d, null, c, null));
        var l = t.drawRect();
        e.config.xaxis.crosshairs.width === 1 && (l = t.drawLine());
        var u = e.globals.gridHeight;
        (!P.isNumber(u) || u < 0) && (u = 0);
        var b = e.config.xaxis.crosshairs.width;
        (!P.isNumber(b) || b < 0) && (b = 0), l.attr({ class: "apexcharts-xcrosshairs", x: 0, y: 0, y2: u, width: b, height: u, fill: w, filter: "none", "fill-opacity": e.config.xaxis.crosshairs.opacity, stroke: e.config.xaxis.crosshairs.stroke.color, "stroke-width": e.config.xaxis.crosshairs.stroke.width, "stroke-dasharray": e.config.xaxis.crosshairs.stroke.dashArray }), g && (l = i.dropShadow(l, { left: p, top: x, blur: f, color: m, opacity: v })), e.globals.dom.elGraphical.add(l);
      }
    } }, { key: "drawYCrosshairs", value: function() {
      var e = this.w, t = new X(this.ctx), i = e.config.yaxis[0].crosshairs, a = e.globals.barPadForNumericAxis;
      if (e.config.yaxis[0].crosshairs.show) {
        var r = t.drawLine(-a, 0, e.globals.gridWidth + a, 0, i.stroke.color, i.stroke.dashArray, i.stroke.width);
        r.attr({ class: "apexcharts-ycrosshairs" }), e.globals.dom.elGraphical.add(r);
      }
      var s = t.drawLine(-a, 0, e.globals.gridWidth + a, 0, i.stroke.color, 0, 0);
      s.attr({ class: "apexcharts-ycrosshairs-hidden" }), e.globals.dom.elGraphical.add(s);
    } }]), y;
  }(), At = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "checkResponsiveConfig", value: function(e) {
      var t = this, i = this.w, a = i.config;
      if (a.responsive.length !== 0) {
        var r = a.responsive.slice();
        r.sort(function(h, d) {
          return h.breakpoint > d.breakpoint ? 1 : d.breakpoint > h.breakpoint ? -1 : 0;
        }).reverse();
        var s = new ye({}), n = function() {
          var h = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, d = r[0].breakpoint, c = window.innerWidth > 0 ? window.innerWidth : screen.width;
          if (c > d) {
            var g = P.clone(i.globals.initialConfig);
            g.series = P.clone(i.config.series);
            var p = $.extendArrayProps(s, g, i);
            h = P.extend(p, h), h = P.extend(i.config, h), t.overrideResponsiveOptions(h);
          } else
            for (var x = 0; x < r.length; x++)
              c < r[x].breakpoint && (h = $.extendArrayProps(s, r[x].options, i), h = P.extend(i.config, h), t.overrideResponsiveOptions(h));
        };
        if (e) {
          var o = $.extendArrayProps(s, e, i);
          o = P.extend(i.config, o), n(o = P.extend(o, e));
        } else
          n({});
      }
    } }, { key: "overrideResponsiveOptions", value: function(e) {
      var t = new ye(e).init({ responsiveOverride: !0 });
      this.w.config = t;
    } }]), y;
  }(), St = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.colors = [], this.isColorFn = !1, this.isHeatmapDistributed = this.checkHeatmapDistributed(), this.isBarDistributed = this.checkBarDistributed();
    }
    return F(y, [{ key: "checkHeatmapDistributed", value: function() {
      var e = this.w.config, t = e.chart, i = e.plotOptions;
      return t.type === "treemap" && i.treemap && i.treemap.distributed || t.type === "heatmap" && i.heatmap && i.heatmap.distributed;
    } }, { key: "checkBarDistributed", value: function() {
      var e = this.w.config, t = e.chart, i = e.plotOptions;
      return i.bar && i.bar.distributed && (t.type === "bar" || t.type === "rangeBar");
    } }, { key: "init", value: function() {
      this.setDefaultColors();
    } }, { key: "setDefaultColors", value: function() {
      var e = this.w, t = new P();
      e.globals.dom.elWrap.classList.add("apexcharts-theme-".concat(e.config.theme.mode));
      var i = J(e.config.colors || e.config.fill.colors || []);
      e.globals.colors = this.getColors(i), this.applySeriesColors(e.globals.seriesColors, e.globals.colors), e.config.theme.monochrome.enabled && (e.globals.colors = this.getMonochromeColors(e.config.theme.monochrome, e.globals.series, t));
      var a = e.globals.colors.slice();
      this.pushExtraColors(e.globals.colors), this.applyColorTypes(["fill", "stroke"], a), this.applyDataLabelsColors(a), this.applyRadarPolygonsColors(), this.applyMarkersColors(a);
    } }, { key: "getColors", value: function(e) {
      var t = this, i = this.w;
      return e && e.length !== 0 ? Array.isArray(e) && e.length > 0 && typeof e[0] == "function" ? (this.isColorFn = !0, i.config.series.map(function(a, r) {
        var s = e[r] || e[0];
        return typeof s == "function" ? s({ value: i.globals.axisCharts ? i.globals.series[r][0] || 0 : i.globals.series[r], seriesIndex: r, dataPointIndex: r, w: t.w }) : s;
      })) : e : this.predefined();
    } }, { key: "applySeriesColors", value: function(e, t) {
      e.forEach(function(i, a) {
        i && (t[a] = i);
      });
    } }, { key: "getMonochromeColors", value: function(e, t, i) {
      var a = e.color, r = e.shadeIntensity, s = e.shadeTo, n = this.isBarDistributed || this.isHeatmapDistributed ? t[0].length * t.length : t.length, o = 1 / (n / r), h = 0;
      return Array.from({ length: n }, function() {
        var d = s === "dark" ? i.shadeColor(-1 * h, a) : i.shadeColor(h, a);
        return h += o, d;
      });
    } }, { key: "applyColorTypes", value: function(e, t) {
      var i = this, a = this.w;
      e.forEach(function(r) {
        a.globals[r].colors = a.config[r].colors === void 0 ? i.isColorFn ? a.config.colors : t : a.config[r].colors.slice(), i.pushExtraColors(a.globals[r].colors);
      });
    } }, { key: "applyDataLabelsColors", value: function(e) {
      var t = this.w;
      t.globals.dataLabels.style.colors = t.config.dataLabels.style.colors === void 0 ? e : t.config.dataLabels.style.colors.slice(), this.pushExtraColors(t.globals.dataLabels.style.colors, 50);
    } }, { key: "applyRadarPolygonsColors", value: function() {
      var e = this.w;
      e.globals.radarPolygons.fill.colors = e.config.plotOptions.radar.polygons.fill.colors === void 0 ? [e.config.theme.mode === "dark" ? "#424242" : "none"] : e.config.plotOptions.radar.polygons.fill.colors.slice(), this.pushExtraColors(e.globals.radarPolygons.fill.colors, 20);
    } }, { key: "applyMarkersColors", value: function(e) {
      var t = this.w;
      t.globals.markers.colors = t.config.markers.colors === void 0 ? e : t.config.markers.colors.slice(), this.pushExtraColors(t.globals.markers.colors);
    } }, { key: "pushExtraColors", value: function(e, t) {
      var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null, a = this.w, r = t || a.globals.series.length;
      if (i === null && (i = this.isBarDistributed || this.isHeatmapDistributed || a.config.chart.type === "heatmap" && a.config.plotOptions.heatmap && a.config.plotOptions.heatmap.colorScale.inverse), i && a.globals.series.length && (r = a.globals.series[a.globals.maxValsInArrayIndex].length * a.globals.series.length), e.length < r)
        for (var s = r - e.length, n = 0; n < s; n++)
          e.push(e[n]);
    } }, { key: "updateThemeOptions", value: function(e) {
      e.chart = e.chart || {}, e.tooltip = e.tooltip || {};
      var t = e.theme.mode, i = t === "dark" ? "palette4" : t === "light" ? "palette1" : e.theme.palette || "palette1", a = t === "dark" ? "#f6f7f8" : t === "light" ? "#373d3f" : e.chart.foreColor || "#373d3f";
      return e.tooltip.theme = t || "light", e.chart.foreColor = a, e.theme.palette = i, e;
    } }, { key: "predefined", value: function() {
      var e = { palette1: ["#008FFB", "#00E396", "#FEB019", "#FF4560", "#775DD0"], palette2: ["#3f51b5", "#03a9f4", "#4caf50", "#f9ce1d", "#FF9800"], palette3: ["#33b2df", "#546E7A", "#d4526e", "#13d8aa", "#A5978B"], palette4: ["#4ecdc4", "#c7f464", "#81D4FA", "#fd6a6a", "#546E7A"], palette5: ["#2b908f", "#f9a3a4", "#90ee7e", "#fa4443", "#69d2e7"], palette6: ["#449DD1", "#F86624", "#EA3546", "#662E9B", "#C5D86D"], palette7: ["#D7263D", "#1B998B", "#2E294E", "#F46036", "#E2C044"], palette8: ["#662E9B", "#F86624", "#F9C80E", "#EA3546", "#43BCCD"], palette9: ["#5C4742", "#A5978B", "#8D5B4C", "#5A2A27", "#C4BBAF"], palette10: ["#A300D6", "#7D02EB", "#5653FE", "#2983FF", "#00B1F2"], default: ["#008FFB", "#00E396", "#FEB019", "#FF4560", "#775DD0"] };
      return e[this.w.config.theme.palette] || e.default;
    } }]), y;
  }(), Ct = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "draw", value: function() {
      this.drawTitleSubtitle("title"), this.drawTitleSubtitle("subtitle");
    } }, { key: "drawTitleSubtitle", value: function(e) {
      var t = this.w, i = e === "title" ? t.config.title : t.config.subtitle, a = t.globals.svgWidth / 2, r = i.offsetY, s = "middle";
      if (i.align === "left" ? (a = 10, s = "start") : i.align === "right" && (a = t.globals.svgWidth - 10, s = "end"), a += i.offsetX, r = r + parseInt(i.style.fontSize, 10) + i.margin / 2, i.text !== void 0) {
        var n = new X(this.ctx).drawText({ x: a, y: r, text: i.text, textAnchor: s, fontSize: i.style.fontSize, fontFamily: i.style.fontFamily, fontWeight: i.style.fontWeight, foreColor: i.style.color, opacity: 1 });
        n.node.setAttribute("class", "apexcharts-".concat(e, "-text")), t.globals.dom.Paper.add(n);
      }
    } }]), y;
  }(), Lt = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.dCtx = e;
    }
    return F(y, [{ key: "getTitleSubtitleCoords", value: function(e) {
      var t = this.w, i = 0, a = 0, r = e === "title" ? t.config.title.floating : t.config.subtitle.floating, s = t.globals.dom.baseEl.querySelector(".apexcharts-".concat(e, "-text"));
      if (s !== null && !r) {
        var n = s.getBoundingClientRect();
        i = n.width, a = t.globals.axisCharts ? n.height + 5 : n.height;
      }
      return { width: i, height: a };
    } }, { key: "getLegendsRect", value: function() {
      var e = this.w, t = e.globals.dom.elLegendWrap;
      e.config.legend.height || e.config.legend.position !== "top" && e.config.legend.position !== "bottom" || (t.style.maxHeight = e.globals.svgHeight / 2 + "px");
      var i = Object.assign({}, P.getBoundingClientRect(t));
      return t !== null && !e.config.legend.floating && e.config.legend.show ? this.dCtx.lgRect = { x: i.x, y: i.y, height: i.height, width: i.height === 0 ? 0 : i.width } : this.dCtx.lgRect = { x: 0, y: 0, height: 0, width: 0 }, e.config.legend.position !== "left" && e.config.legend.position !== "right" || 1.5 * this.dCtx.lgRect.width > e.globals.svgWidth && (this.dCtx.lgRect.width = e.globals.svgWidth / 1.5), this.dCtx.lgRect;
    } }, { key: "getDatalabelsRect", value: function() {
      var e = this, t = this.w, i = [];
      t.config.series.forEach(function(o, h) {
        o.data.forEach(function(d, c) {
          var g;
          g = t.globals.series[h][c], a = t.config.dataLabels.formatter(g, { ctx: e.dCtx.ctx, seriesIndex: h, dataPointIndex: c, w: t }), i.push(a);
        });
      });
      var a = P.getLargestStringFromArr(i), r = new X(this.dCtx.ctx), s = t.config.dataLabels.style, n = r.getTextRects(a, parseInt(s.fontSize), s.fontFamily);
      return { width: 1.05 * n.width, height: n.height };
    } }, { key: "getLargestStringFromMultiArr", value: function(e, t) {
      var i = e;
      if (this.w.globals.isMultiLineX) {
        var a = t.map(function(s, n) {
          return Array.isArray(s) ? s.length : 1;
        }), r = Math.max.apply(Math, J(a));
        i = t[a.indexOf(r)];
      }
      return i;
    } }]), y;
  }(), Pt = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.dCtx = e;
    }
    return F(y, [{ key: "getxAxisLabelsCoords", value: function() {
      var e, t = this.w, i = t.globals.labels.slice();
      if (t.config.xaxis.convertedCatToNumeric && i.length === 0 && (i = t.globals.categoryLabels), t.globals.timescaleLabels.length > 0) {
        var a = this.getxAxisTimeScaleLabelsCoords();
        e = { width: a.width, height: a.height }, t.globals.rotateXLabels = !1;
      } else {
        this.dCtx.lgWidthForSideLegends = t.config.legend.position !== "left" && t.config.legend.position !== "right" || t.config.legend.floating ? 0 : this.dCtx.lgRect.width;
        var r = t.globals.xLabelFormatter, s = P.getLargestStringFromArr(i), n = this.dCtx.dimHelpers.getLargestStringFromMultiArr(s, i);
        t.globals.isBarHorizontal && (n = s = t.globals.yAxisScale[0].result.reduce(function(x, f) {
          return x.length > f.length ? x : f;
        }, 0));
        var o = new me(this.dCtx.ctx), h = s;
        s = o.xLabelFormat(r, s, h, { i: void 0, dateFormatter: new K(this.dCtx.ctx).formatDate, w: t }), n = o.xLabelFormat(r, n, h, { i: void 0, dateFormatter: new K(this.dCtx.ctx).formatDate, w: t }), (t.config.xaxis.convertedCatToNumeric && s === void 0 || String(s).trim() === "") && (n = s = "1");
        var d = new X(this.dCtx.ctx), c = d.getTextRects(s, t.config.xaxis.labels.style.fontSize), g = c;
        if (s !== n && (g = d.getTextRects(n, t.config.xaxis.labels.style.fontSize)), (e = { width: c.width >= g.width ? c.width : g.width, height: c.height >= g.height ? c.height : g.height }).width * i.length > t.globals.svgWidth - this.dCtx.lgWidthForSideLegends - this.dCtx.yAxisWidth - this.dCtx.gridPad.left - this.dCtx.gridPad.right && t.config.xaxis.labels.rotate !== 0 || t.config.xaxis.labels.rotateAlways) {
          if (!t.globals.isBarHorizontal) {
            t.globals.rotateXLabels = !0;
            var p = function(x) {
              return d.getTextRects(x, t.config.xaxis.labels.style.fontSize, t.config.xaxis.labels.style.fontFamily, "rotate(".concat(t.config.xaxis.labels.rotate, " 0 0)"), !1);
            };
            c = p(s), s !== n && (g = p(n)), e.height = (c.height > g.height ? c.height : g.height) / 1.5, e.width = c.width > g.width ? c.width : g.width;
          }
        } else
          t.globals.rotateXLabels = !1;
      }
      return t.config.xaxis.labels.show || (e = { width: 0, height: 0 }), { width: e.width, height: e.height };
    } }, { key: "getxAxisGroupLabelsCoords", value: function() {
      var e, t = this.w;
      if (!t.globals.hasXaxisGroups)
        return { width: 0, height: 0 };
      var i, a = ((e = t.config.xaxis.group.style) === null || e === void 0 ? void 0 : e.fontSize) || t.config.xaxis.labels.style.fontSize, r = t.globals.groups.map(function(c) {
        return c.title;
      }), s = P.getLargestStringFromArr(r), n = this.dCtx.dimHelpers.getLargestStringFromMultiArr(s, r), o = new X(this.dCtx.ctx), h = o.getTextRects(s, a), d = h;
      return s !== n && (d = o.getTextRects(n, a)), i = { width: h.width >= d.width ? h.width : d.width, height: h.height >= d.height ? h.height : d.height }, t.config.xaxis.labels.show || (i = { width: 0, height: 0 }), { width: i.width, height: i.height };
    } }, { key: "getxAxisTitleCoords", value: function() {
      var e = this.w, t = 0, i = 0;
      if (e.config.xaxis.title.text !== void 0) {
        var a = new X(this.dCtx.ctx).getTextRects(e.config.xaxis.title.text, e.config.xaxis.title.style.fontSize);
        t = a.width, i = a.height;
      }
      return { width: t, height: i };
    } }, { key: "getxAxisTimeScaleLabelsCoords", value: function() {
      var e, t = this.w;
      this.dCtx.timescaleLabels = t.globals.timescaleLabels.slice();
      var i = this.dCtx.timescaleLabels.map(function(r) {
        return r.value;
      }), a = i.reduce(function(r, s) {
        return r === void 0 ? (console.error("You have possibly supplied invalid Date format. Please supply a valid JavaScript Date"), 0) : r.length > s.length ? r : s;
      }, 0);
      return 1.05 * (e = new X(this.dCtx.ctx).getTextRects(a, t.config.xaxis.labels.style.fontSize)).width * i.length > t.globals.gridWidth && t.config.xaxis.labels.rotate !== 0 && (t.globals.overlappingXLabels = !0), e;
    } }, { key: "additionalPaddingXLabels", value: function(e) {
      var t = this, i = this.w, a = i.globals, r = i.config, s = r.xaxis.type, n = e.width;
      a.skipLastTimelinelabel = !1, a.skipFirstTimelinelabel = !1;
      var o = i.config.yaxis[0].opposite && i.globals.isBarHorizontal, h = function(d, c) {
        r.yaxis.length > 1 && function(g) {
          return a.collapsedSeriesIndices.indexOf(g) !== -1;
        }(c) || function(g) {
          if (t.dCtx.timescaleLabels && t.dCtx.timescaleLabels.length) {
            var p = t.dCtx.timescaleLabels[0], x = t.dCtx.timescaleLabels[t.dCtx.timescaleLabels.length - 1].position + n / 1.75 - t.dCtx.yAxisWidthRight, f = p.position - n / 1.75 + t.dCtx.yAxisWidthLeft, m = i.config.legend.position === "right" && t.dCtx.lgRect.width > 0 ? t.dCtx.lgRect.width : 0;
            x > a.svgWidth - a.translateX - m && (a.skipLastTimelinelabel = !0), f < -(g.show && !g.floating || r.chart.type !== "bar" && r.chart.type !== "candlestick" && r.chart.type !== "rangeBar" && r.chart.type !== "boxPlot" ? 10 : n / 1.75) && (a.skipFirstTimelinelabel = !0);
          } else
            s === "datetime" ? t.dCtx.gridPad.right < n && !a.rotateXLabels && (a.skipLastTimelinelabel = !0) : s !== "datetime" && t.dCtx.gridPad.right < n / 2 - t.dCtx.yAxisWidthRight && !a.rotateXLabels && !i.config.xaxis.labels.trim && (t.dCtx.xPadRight = n / 2 + 1);
        }(d);
      };
      r.yaxis.forEach(function(d, c) {
        o ? (t.dCtx.gridPad.left < n && (t.dCtx.xPadLeft = n / 2 + 1), t.dCtx.xPadRight = n / 2 + 1) : h(d, c);
      });
    } }]), y;
  }(), Mt = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.dCtx = e;
    }
    return F(y, [{ key: "getyAxisLabelsCoords", value: function() {
      var e = this, t = this.w, i = [], a = 10, r = new he(this.dCtx.ctx);
      return t.config.yaxis.map(function(s, n) {
        var o = { seriesIndex: n, dataPointIndex: -1, w: t }, h = t.globals.yAxisScale[n], d = 0;
        if (!r.isYAxisHidden(n) && s.labels.show && s.labels.minWidth !== void 0 && (d = s.labels.minWidth), !r.isYAxisHidden(n) && s.labels.show && h.result.length) {
          var c = t.globals.yLabelFormatters[n], g = h.niceMin === Number.MIN_VALUE ? 0 : h.niceMin, p = h.result.reduce(function(u, b) {
            var A, k;
            return ((A = String(c(u, o))) === null || A === void 0 ? void 0 : A.length) > ((k = String(c(b, o))) === null || k === void 0 ? void 0 : k.length) ? u : b;
          }, g), x = p = c(p, o);
          if (p !== void 0 && p.length !== 0 || (p = h.niceMax), t.globals.isBarHorizontal) {
            a = 0;
            var f = t.globals.labels.slice();
            p = P.getLargestStringFromArr(f), p = c(p, { seriesIndex: n, dataPointIndex: -1, w: t }), x = e.dCtx.dimHelpers.getLargestStringFromMultiArr(p, f);
          }
          var m = new X(e.dCtx.ctx), v = "rotate(".concat(s.labels.rotate, " 0 0)"), w = m.getTextRects(p, s.labels.style.fontSize, s.labels.style.fontFamily, v, !1), l = w;
          p !== x && (l = m.getTextRects(x, s.labels.style.fontSize, s.labels.style.fontFamily, v, !1)), i.push({ width: (d > l.width || d > w.width ? d : l.width > w.width ? l.width : w.width) + a, height: l.height > w.height ? l.height : w.height });
        } else
          i.push({ width: 0, height: 0 });
      }), i;
    } }, { key: "getyAxisTitleCoords", value: function() {
      var e = this, t = this.w, i = [];
      return t.config.yaxis.map(function(a, r) {
        if (a.show && a.title.text !== void 0) {
          var s = new X(e.dCtx.ctx), n = "rotate(".concat(a.title.rotate, " 0 0)"), o = s.getTextRects(a.title.text, a.title.style.fontSize, a.title.style.fontFamily, n, !1);
          i.push({ width: o.width, height: o.height });
        } else
          i.push({ width: 0, height: 0 });
      }), i;
    } }, { key: "getTotalYAxisWidth", value: function() {
      var e = this.w, t = 0, i = 0, a = 0, r = e.globals.yAxisScale.length > 1 ? 10 : 0, s = new he(this.dCtx.ctx), n = function(o, h) {
        var d = e.config.yaxis[h].floating, c = 0;
        o.width > 0 && !d ? (c = o.width + r, function(g) {
          return e.globals.ignoreYAxisIndexes.indexOf(g) > -1;
        }(h) && (c = c - o.width - r)) : c = d || s.isYAxisHidden(h) ? 0 : 5, e.config.yaxis[h].opposite ? a += c : i += c, t += c;
      };
      return e.globals.yLabelsCoords.map(function(o, h) {
        n(o, h);
      }), e.globals.yTitleCoords.map(function(o, h) {
        n(o, h);
      }), e.globals.isBarHorizontal && !e.config.yaxis[0].floating && (t = e.globals.yLabelsCoords[0].width + e.globals.yTitleCoords[0].width + 15), this.dCtx.yAxisWidthLeft = i, this.dCtx.yAxisWidthRight = a, t;
    } }]), y;
  }(), It = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.dCtx = e;
    }
    return F(y, [{ key: "gridPadForColumnsInNumericAxis", value: function(e) {
      var t = this.w, i = t.config, a = t.globals;
      if (a.noData || a.collapsedSeries.length + a.ancillaryCollapsedSeries.length === i.series.length)
        return 0;
      var r = function(p) {
        return ["bar", "rangeBar", "candlestick", "boxPlot"].includes(p);
      }, s = i.chart.type, n = 0, o = r(s) ? i.series.length : 1;
      a.comboBarCount > 0 && (o = a.comboBarCount), a.collapsedSeries.forEach(function(p) {
        r(p.type) && (o -= 1);
      }), i.chart.stacked && (o = 1);
      var h = r(s) || a.comboBarCount > 0, d = Math.abs(a.initialMaxX - a.initialMinX);
      if (h && a.isXNumeric && !a.isBarHorizontal && o > 0 && d !== 0) {
        d <= 3 && (d = a.dataPoints);
        var c = d / e, g = a.minXDiff && a.minXDiff / c > 0 ? a.minXDiff / c : 0;
        g > e / 2 && (g /= 2), (n = g * parseInt(i.plotOptions.bar.columnWidth, 10) / 100) < 1 && (n = 1), a.barPadForNumericAxis = n;
      }
      return n;
    } }, { key: "gridPadFortitleSubtitle", value: function() {
      var e = this, t = this.w, i = t.globals, a = this.dCtx.isSparkline || !i.axisCharts ? 0 : 10;
      ["title", "subtitle"].forEach(function(n) {
        t.config[n].text !== void 0 ? a += t.config[n].margin : a += e.dCtx.isSparkline || !i.axisCharts ? 0 : 5;
      }), !t.config.legend.show || t.config.legend.position !== "bottom" || t.config.legend.floating || i.axisCharts || (a += 10);
      var r = this.dCtx.dimHelpers.getTitleSubtitleCoords("title"), s = this.dCtx.dimHelpers.getTitleSubtitleCoords("subtitle");
      i.gridHeight -= r.height + s.height + a, i.translateY += r.height + s.height + a;
    } }, { key: "setGridXPosForDualYAxis", value: function(e, t) {
      var i = this.w, a = new he(this.dCtx.ctx);
      i.config.yaxis.forEach(function(r, s) {
        i.globals.ignoreYAxisIndexes.indexOf(s) !== -1 || r.floating || a.isYAxisHidden(s) || (r.opposite && (i.globals.translateX -= t[s].width + e[s].width + parseInt(r.labels.style.fontSize, 10) / 1.2 + 12), i.globals.translateX < 2 && (i.globals.translateX = 2));
      });
    } }]), y;
  }(), Me = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.lgRect = {}, this.yAxisWidth = 0, this.yAxisWidthLeft = 0, this.yAxisWidthRight = 0, this.xAxisHeight = 0, this.isSparkline = this.w.config.chart.sparkline.enabled, this.dimHelpers = new Lt(this), this.dimYAxis = new Mt(this), this.dimXAxis = new Pt(this), this.dimGrid = new It(this), this.lgWidthForSideLegends = 0, this.gridPad = this.w.config.grid.padding, this.xPadRight = 0, this.xPadLeft = 0;
    }
    return F(y, [{ key: "plotCoords", value: function() {
      var e = this, t = this.w, i = t.globals;
      this.lgRect = this.dimHelpers.getLegendsRect(), this.datalabelsCoords = { width: 0, height: 0 };
      var a = Array.isArray(t.config.stroke.width) ? Math.max.apply(Math, J(t.config.stroke.width)) : t.config.stroke.width;
      this.isSparkline && ((t.config.markers.discrete.length > 0 || t.config.markers.size > 0) && Object.entries(this.gridPad).forEach(function(s) {
        var n = Ze(s, 2), o = n[0], h = n[1];
        e.gridPad[o] = Math.max(h, e.w.globals.markers.largestSize / 1.5);
      }), this.gridPad.top = Math.max(a / 2, this.gridPad.top), this.gridPad.bottom = Math.max(a / 2, this.gridPad.bottom)), i.axisCharts ? this.setDimensionsForAxisCharts() : this.setDimensionsForNonAxisCharts(), this.dimGrid.gridPadFortitleSubtitle(), i.gridHeight = i.gridHeight - this.gridPad.top - this.gridPad.bottom, i.gridWidth = i.gridWidth - this.gridPad.left - this.gridPad.right - this.xPadRight - this.xPadLeft;
      var r = this.dimGrid.gridPadForColumnsInNumericAxis(i.gridWidth);
      i.gridWidth = i.gridWidth - 2 * r, i.translateX = i.translateX + this.gridPad.left + this.xPadLeft + (r > 0 ? r : 0), i.translateY = i.translateY + this.gridPad.top;
    } }, { key: "setDimensionsForAxisCharts", value: function() {
      var e = this, t = this.w, i = t.globals, a = this.dimYAxis.getyAxisLabelsCoords(), r = this.dimYAxis.getyAxisTitleCoords();
      i.isSlopeChart && (this.datalabelsCoords = this.dimHelpers.getDatalabelsRect()), t.globals.yLabelsCoords = [], t.globals.yTitleCoords = [], t.config.yaxis.map(function(p, x) {
        t.globals.yLabelsCoords.push({ width: a[x].width, index: x }), t.globals.yTitleCoords.push({ width: r[x].width, index: x });
      }), this.yAxisWidth = this.dimYAxis.getTotalYAxisWidth();
      var s = this.dimXAxis.getxAxisLabelsCoords(), n = this.dimXAxis.getxAxisGroupLabelsCoords(), o = this.dimXAxis.getxAxisTitleCoords();
      this.conditionalChecksForAxisCoords(s, o, n), i.translateXAxisY = t.globals.rotateXLabels ? this.xAxisHeight / 8 : -4, i.translateXAxisX = t.globals.rotateXLabels && t.globals.isXNumeric && t.config.xaxis.labels.rotate <= -45 ? -this.xAxisWidth / 4 : 0, t.globals.isBarHorizontal && (i.rotateXLabels = !1, i.translateXAxisY = parseInt(t.config.xaxis.labels.style.fontSize, 10) / 1.5 * -1), i.translateXAxisY = i.translateXAxisY + t.config.xaxis.labels.offsetY, i.translateXAxisX = i.translateXAxisX + t.config.xaxis.labels.offsetX;
      var h = this.yAxisWidth, d = this.xAxisHeight;
      i.xAxisLabelsHeight = this.xAxisHeight - o.height, i.xAxisGroupLabelsHeight = i.xAxisLabelsHeight - s.height, i.xAxisLabelsWidth = this.xAxisWidth, i.xAxisHeight = this.xAxisHeight;
      var c = 10;
      (t.config.chart.type === "radar" || this.isSparkline) && (h = 0, d = 0), this.isSparkline && (this.lgRect = { height: 0, width: 0 }), (this.isSparkline || t.config.chart.type === "treemap") && (h = 0, d = 0, c = 0), this.isSparkline || t.config.chart.type === "treemap" || this.dimXAxis.additionalPaddingXLabels(s);
      var g = function() {
        i.translateX = h + e.datalabelsCoords.width, i.gridHeight = i.svgHeight - e.lgRect.height - d - (e.isSparkline || t.config.chart.type === "treemap" ? 0 : t.globals.rotateXLabels ? 10 : 15), i.gridWidth = i.svgWidth - h - 2 * e.datalabelsCoords.width;
      };
      switch (t.config.xaxis.position === "top" && (c = i.xAxisHeight - t.config.xaxis.axisTicks.height - 5), t.config.legend.position) {
        case "bottom":
          i.translateY = c, g();
          break;
        case "top":
          i.translateY = this.lgRect.height + c, g();
          break;
        case "left":
          i.translateY = c, i.translateX = this.lgRect.width + h + this.datalabelsCoords.width, i.gridHeight = i.svgHeight - d - 12, i.gridWidth = i.svgWidth - this.lgRect.width - h - 2 * this.datalabelsCoords.width;
          break;
        case "right":
          i.translateY = c, i.translateX = h + this.datalabelsCoords.width, i.gridHeight = i.svgHeight - d - 12, i.gridWidth = i.svgWidth - this.lgRect.width - h - 2 * this.datalabelsCoords.width - 5;
          break;
        default:
          throw new Error("Legend position not supported");
      }
      this.dimGrid.setGridXPosForDualYAxis(r, a), new De(this.ctx).setYAxisXPosition(a, r);
    } }, { key: "setDimensionsForNonAxisCharts", value: function() {
      var e = this.w, t = e.globals, i = e.config, a = 0;
      e.config.legend.show && !e.config.legend.floating && (a = 20);
      var r = i.chart.type === "pie" || i.chart.type === "polarArea" || i.chart.type === "donut" ? "pie" : "radialBar", s = i.plotOptions[r].offsetY, n = i.plotOptions[r].offsetX;
      if (!i.legend.show || i.legend.floating) {
        t.gridHeight = t.svgHeight;
        var o = t.dom.elWrap.getBoundingClientRect().width;
        return t.gridWidth = Math.min(o, t.gridHeight), t.translateY = s, void (t.translateX = n + (t.svgWidth - t.gridWidth) / 2);
      }
      switch (i.legend.position) {
        case "bottom":
          t.gridHeight = t.svgHeight - this.lgRect.height, t.gridWidth = t.svgWidth, t.translateY = s - 10, t.translateX = n + (t.svgWidth - t.gridWidth) / 2;
          break;
        case "top":
          t.gridHeight = t.svgHeight - this.lgRect.height, t.gridWidth = t.svgWidth, t.translateY = this.lgRect.height + s + 10, t.translateX = n + (t.svgWidth - t.gridWidth) / 2;
          break;
        case "left":
          t.gridWidth = t.svgWidth - this.lgRect.width - a, t.gridHeight = i.chart.height !== "auto" ? t.svgHeight : t.gridWidth, t.translateY = s, t.translateX = n + this.lgRect.width + a;
          break;
        case "right":
          t.gridWidth = t.svgWidth - this.lgRect.width - a - 5, t.gridHeight = i.chart.height !== "auto" ? t.svgHeight : t.gridWidth, t.translateY = s, t.translateX = n + 10;
          break;
        default:
          throw new Error("Legend position not supported");
      }
    } }, { key: "conditionalChecksForAxisCoords", value: function(e, t, i) {
      var a = this.w, r = a.globals.hasXaxisGroups ? 2 : 1, s = i.height + e.height + t.height, n = a.globals.isMultiLineX ? 1.2 : a.globals.LINE_HEIGHT_RATIO, o = a.globals.rotateXLabels ? 22 : 10, h = a.globals.rotateXLabels && a.config.legend.position === "bottom" ? 10 : 0;
      this.xAxisHeight = s * n + r * o + h, this.xAxisWidth = e.width, this.xAxisHeight - t.height > a.config.xaxis.labels.maxHeight && (this.xAxisHeight = a.config.xaxis.labels.maxHeight), a.config.xaxis.labels.minHeight && this.xAxisHeight < a.config.xaxis.labels.minHeight && (this.xAxisHeight = a.config.xaxis.labels.minHeight), a.config.xaxis.floating && (this.xAxisHeight = 0);
      var d = 0, c = 0;
      a.config.yaxis.forEach(function(g) {
        d += g.labels.minWidth, c += g.labels.maxWidth;
      }), this.yAxisWidth < d && (this.yAxisWidth = d), this.yAxisWidth > c && (this.yAxisWidth = c);
    } }]), y;
  }(), Tt = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.lgCtx = e;
    }
    return F(y, [{ key: "getLegendStyles", value: function() {
      var e, t, i, a = document.createElement("style");
      a.setAttribute("type", "text/css");
      var r = ((e = this.lgCtx.ctx) === null || e === void 0 || (t = e.opts) === null || t === void 0 || (i = t.chart) === null || i === void 0 ? void 0 : i.nonce) || this.w.config.chart.nonce;
      r && a.setAttribute("nonce", r);
      var s = document.createTextNode(`
      .apexcharts-flip-y {
        transform: scaleY(-1) translateY(-100%);
        transform-origin: top;
        transform-box: fill-box;
      }
      .apexcharts-flip-x {
        transform: scaleX(-1);
        transform-origin: center;
        transform-box: fill-box;
      }
      .apexcharts-legend {
        display: flex;
        overflow: auto;
        padding: 0 10px;
      }
      .apexcharts-legend.apx-legend-position-bottom, .apexcharts-legend.apx-legend-position-top {
        flex-wrap: wrap
      }
      .apexcharts-legend.apx-legend-position-right, .apexcharts-legend.apx-legend-position-left {
        flex-direction: column;
        bottom: 0;
      }
      .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-left, .apexcharts-legend.apx-legend-position-top.apexcharts-align-left, .apexcharts-legend.apx-legend-position-right, .apexcharts-legend.apx-legend-position-left {
        justify-content: flex-start;
      }
      .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-center, .apexcharts-legend.apx-legend-position-top.apexcharts-align-center {
        justify-content: center;
      }
      .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-right, .apexcharts-legend.apx-legend-position-top.apexcharts-align-right {
        justify-content: flex-end;
      }
      .apexcharts-legend-series {
        cursor: pointer;
        line-height: normal;
        display: flex;
        align-items: center;
      }
      .apexcharts-legend-text {
        position: relative;
        font-size: 14px;
      }
      .apexcharts-legend-text *, .apexcharts-legend-marker * {
        pointer-events: none;
      }
      .apexcharts-legend-marker {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        margin-right: 1px;
      }

      .apexcharts-legend-series.apexcharts-no-click {
        cursor: auto;
      }
      .apexcharts-legend .apexcharts-hidden-zero-series, .apexcharts-legend .apexcharts-hidden-null-series {
        display: none !important;
      }
      .apexcharts-inactive-legend {
        opacity: 0.45;
      }`);
      return a.appendChild(s), a;
    } }, { key: "getLegendDimensions", value: function() {
      var e = this.w.globals.dom.baseEl.querySelector(".apexcharts-legend").getBoundingClientRect(), t = e.width;
      return { clwh: e.height, clww: t };
    } }, { key: "appendToForeignObject", value: function() {
      this.w.globals.dom.elLegendForeign.appendChild(this.getLegendStyles());
    } }, { key: "toggleDataSeries", value: function(e, t) {
      var i = this, a = this.w;
      if (a.globals.axisCharts || a.config.chart.type === "radialBar") {
        a.globals.resized = !0;
        var r = null, s = null;
        a.globals.risingSeries = [], a.globals.axisCharts ? (r = a.globals.dom.baseEl.querySelector(".apexcharts-series[data\\:realIndex='".concat(e, "']")), s = parseInt(r.getAttribute("data:realIndex"), 10)) : (r = a.globals.dom.baseEl.querySelector(".apexcharts-series[rel='".concat(e + 1, "']")), s = parseInt(r.getAttribute("rel"), 10) - 1), t ? [{ cs: a.globals.collapsedSeries, csi: a.globals.collapsedSeriesIndices }, { cs: a.globals.ancillaryCollapsedSeries, csi: a.globals.ancillaryCollapsedSeriesIndices }].forEach(function(d) {
          i.riseCollapsedSeries(d.cs, d.csi, s);
        }) : this.hideSeries({ seriesEl: r, realIndex: s });
      } else {
        var n = a.globals.dom.Paper.select(" .apexcharts-series[rel='".concat(e + 1, "'] path")), o = a.config.chart.type;
        if (o === "pie" || o === "polarArea" || o === "donut") {
          var h = a.config.plotOptions.pie.donut.labels;
          new X(this.lgCtx.ctx).pathMouseDown(n.members[0], null), this.lgCtx.ctx.pie.printDataLabelsInner(n.members[0].node, h);
        }
        n.fire("click");
      }
    } }, { key: "getSeriesAfterCollapsing", value: function(e) {
      var t = e.realIndex, i = this.w, a = i.globals, r = P.clone(i.config.series);
      if (a.axisCharts) {
        var s = i.config.yaxis[a.seriesYAxisReverseMap[t]], n = { index: t, data: r[t].data.slice(), type: r[t].type || i.config.chart.type };
        if (s && s.show && s.showAlways)
          a.ancillaryCollapsedSeriesIndices.indexOf(t) < 0 && (a.ancillaryCollapsedSeries.push(n), a.ancillaryCollapsedSeriesIndices.push(t));
        else if (a.collapsedSeriesIndices.indexOf(t) < 0) {
          a.collapsedSeries.push(n), a.collapsedSeriesIndices.push(t);
          var o = a.risingSeries.indexOf(t);
          a.risingSeries.splice(o, 1);
        }
      } else
        a.collapsedSeries.push({ index: t, data: r[t] }), a.collapsedSeriesIndices.push(t);
      return a.allSeriesCollapsed = a.collapsedSeries.length + a.ancillaryCollapsedSeries.length === i.config.series.length, this._getSeriesBasedOnCollapsedState(r);
    } }, { key: "hideSeries", value: function(e) {
      for (var t = e.seriesEl, i = e.realIndex, a = this.w, r = this.getSeriesAfterCollapsing({ realIndex: i }), s = t.childNodes, n = 0; n < s.length; n++)
        s[n].classList.contains("apexcharts-series-markers-wrap") && (s[n].classList.contains("apexcharts-hide") ? s[n].classList.remove("apexcharts-hide") : s[n].classList.add("apexcharts-hide"));
      this.lgCtx.ctx.updateHelpers._updateSeries(r, a.config.chart.animations.dynamicAnimation.enabled);
    } }, { key: "riseCollapsedSeries", value: function(e, t, i) {
      var a = this.w, r = P.clone(a.config.series);
      if (e.length > 0) {
        for (var s = 0; s < e.length; s++)
          e[s].index === i && (a.globals.axisCharts ? r[i].data = e[s].data.slice() : r[i] = e[s].data, r[i].hidden = !1, e.splice(s, 1), t.splice(s, 1), a.globals.risingSeries.push(i));
        r = this._getSeriesBasedOnCollapsedState(r), this.lgCtx.ctx.updateHelpers._updateSeries(r, a.config.chart.animations.dynamicAnimation.enabled);
      }
    } }, { key: "_getSeriesBasedOnCollapsedState", value: function(e) {
      var t = this.w, i = 0;
      return t.globals.axisCharts ? e.forEach(function(a, r) {
        t.globals.collapsedSeriesIndices.indexOf(r) < 0 && t.globals.ancillaryCollapsedSeriesIndices.indexOf(r) < 0 || (e[r].data = [], i++);
      }) : e.forEach(function(a, r) {
        !t.globals.collapsedSeriesIndices.indexOf(r) < 0 && (e[r] = 0, i++);
      }), t.globals.allSeriesCollapsed = i === e.length, e;
    } }]), y;
  }(), it = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.onLegendClick = this.onLegendClick.bind(this), this.onLegendHovered = this.onLegendHovered.bind(this), this.isBarsDistributed = this.w.config.chart.type === "bar" && this.w.config.plotOptions.bar.distributed && this.w.config.series.length === 1, this.legendHelpers = new Tt(this);
    }
    return F(y, [{ key: "init", value: function() {
      var e = this.w, t = e.globals, i = e.config, a = i.legend.showForSingleSeries && t.series.length === 1 || this.isBarsDistributed || t.series.length > 1;
      if (this.legendHelpers.appendToForeignObject(), (a || !t.axisCharts) && i.legend.show) {
        for (; t.dom.elLegendWrap.firstChild; )
          t.dom.elLegendWrap.removeChild(t.dom.elLegendWrap.firstChild);
        this.drawLegends(), i.legend.position === "bottom" || i.legend.position === "top" ? this.legendAlignHorizontal() : i.legend.position !== "right" && i.legend.position !== "left" || this.legendAlignVertical();
      }
    } }, { key: "createLegendMarker", value: function(e) {
      var t = e.i, i = e.fillcolor, a = this.w, r = document.createElement("span");
      r.classList.add("apexcharts-legend-marker");
      var s = a.config.legend.markers.shape || a.config.markers.shape, n = s;
      Array.isArray(s) && (n = s[t]);
      var o = Array.isArray(a.config.legend.markers.size) ? parseFloat(a.config.legend.markers.size[t]) : parseFloat(a.config.legend.markers.size), h = Array.isArray(a.config.legend.markers.offsetX) ? parseFloat(a.config.legend.markers.offsetX[t]) : parseFloat(a.config.legend.markers.offsetX), d = Array.isArray(a.config.legend.markers.offsetY) ? parseFloat(a.config.legend.markers.offsetY[t]) : parseFloat(a.config.legend.markers.offsetY), c = Array.isArray(a.config.legend.markers.strokeWidth) ? parseFloat(a.config.legend.markers.strokeWidth[t]) : parseFloat(a.config.legend.markers.strokeWidth), g = r.style;
      if (g.height = 2 * (o + c) + "px", g.width = 2 * (o + c) + "px", g.left = h + "px", g.top = d + "px", a.config.legend.markers.customHTML)
        g.background = "transparent", g.color = i[t], Array.isArray(a.config.legend.markers.customHTML) ? a.config.legend.markers.customHTML[t] && (r.innerHTML = a.config.legend.markers.customHTML[t]()) : r.innerHTML = a.config.legend.markers.customHTML();
      else {
        var p = new ue(this.ctx).getMarkerConfig({ cssClass: "apexcharts-legend-marker apexcharts-marker apexcharts-marker-".concat(n), seriesIndex: t, strokeWidth: c, size: o }), x = SVG(r).size("100%", "100%"), f = new X(this.ctx).drawMarker(0, 0, E(E({}, p), {}, { pointFillColor: Array.isArray(i) ? i[t] : p.pointFillColor, shape: n }));
        SVG.select(".apexcharts-legend-marker.apexcharts-marker").members.forEach(function(m) {
          m.node.classList.contains("apexcharts-marker-triangle") ? m.node.style.transform = "translate(50%, 45%)" : m.node.style.transform = "translate(50%, 50%)";
        }), x.add(f);
      }
      return r;
    } }, { key: "drawLegends", value: function() {
      var e = this, t = this.w, i = t.config.legend.fontFamily, a = t.globals.seriesNames, r = t.config.legend.markers.fillColors ? t.config.legend.markers.fillColors.slice() : t.globals.colors.slice();
      if (t.config.chart.type === "heatmap") {
        var s = t.config.plotOptions.heatmap.colorScale.ranges;
        a = s.map(function(b) {
          return b.name ? b.name : b.from + " - " + b.to;
        }), r = s.map(function(b) {
          return b.color;
        });
      } else
        this.isBarsDistributed && (a = t.globals.labels.slice());
      t.config.legend.customLegendItems.length && (a = t.config.legend.customLegendItems);
      for (var n = t.globals.legendFormatter, o = t.config.legend.inverseOrder, h = o ? a.length - 1 : 0; o ? h >= 0 : h <= a.length - 1; o ? h-- : h++) {
        var d, c = n(a[h], { seriesIndex: h, w: t }), g = !1, p = !1;
        if (t.globals.collapsedSeries.length > 0)
          for (var x = 0; x < t.globals.collapsedSeries.length; x++)
            t.globals.collapsedSeries[x].index === h && (g = !0);
        if (t.globals.ancillaryCollapsedSeriesIndices.length > 0)
          for (var f = 0; f < t.globals.ancillaryCollapsedSeriesIndices.length; f++)
            t.globals.ancillaryCollapsedSeriesIndices[f] === h && (p = !0);
        var m = this.createLegendMarker({ i: h, fillcolor: r });
        X.setAttrs(m, { rel: h + 1, "data:collapsed": g || p }), (g || p) && m.classList.add("apexcharts-inactive-legend");
        var v = document.createElement("div"), w = document.createElement("span");
        w.classList.add("apexcharts-legend-text"), w.innerHTML = Array.isArray(c) ? c.join(" ") : c;
        var l = t.config.legend.labels.useSeriesColors ? t.globals.colors[h] : Array.isArray(t.config.legend.labels.colors) ? (d = t.config.legend.labels.colors) === null || d === void 0 ? void 0 : d[h] : t.config.legend.labels.colors;
        l || (l = t.config.chart.foreColor), w.style.color = l, w.style.fontSize = parseFloat(t.config.legend.fontSize) + "px", w.style.fontWeight = t.config.legend.fontWeight, w.style.fontFamily = i || t.config.chart.fontFamily, X.setAttrs(w, { rel: h + 1, i: h, "data:default-text": encodeURIComponent(c), "data:collapsed": g || p }), v.appendChild(m), v.appendChild(w);
        var u = new $(this.ctx);
        t.config.legend.showForZeroSeries || u.getSeriesTotalByIndex(h) === 0 && u.seriesHaveSameValues(h) && !u.isSeriesNull(h) && t.globals.collapsedSeriesIndices.indexOf(h) === -1 && t.globals.ancillaryCollapsedSeriesIndices.indexOf(h) === -1 && v.classList.add("apexcharts-hidden-zero-series"), t.config.legend.showForNullSeries || u.isSeriesNull(h) && t.globals.collapsedSeriesIndices.indexOf(h) === -1 && t.globals.ancillaryCollapsedSeriesIndices.indexOf(h) === -1 && v.classList.add("apexcharts-hidden-null-series"), t.globals.dom.elLegendWrap.appendChild(v), t.globals.dom.elLegendWrap.classList.add("apexcharts-align-".concat(t.config.legend.horizontalAlign)), t.globals.dom.elLegendWrap.classList.add("apx-legend-position-" + t.config.legend.position), v.classList.add("apexcharts-legend-series"), v.style.margin = "".concat(t.config.legend.itemMargin.vertical, "px ").concat(t.config.legend.itemMargin.horizontal, "px"), t.globals.dom.elLegendWrap.style.width = t.config.legend.width ? t.config.legend.width + "px" : "", t.globals.dom.elLegendWrap.style.height = t.config.legend.height ? t.config.legend.height + "px" : "", X.setAttrs(v, { rel: h + 1, seriesName: P.escapeString(a[h]), "data:collapsed": g || p }), (g || p) && v.classList.add("apexcharts-inactive-legend"), t.config.legend.onItemClick.toggleDataSeries || v.classList.add("apexcharts-no-click");
      }
      t.globals.dom.elWrap.addEventListener("click", e.onLegendClick, !0), t.config.legend.onItemHover.highlightDataSeries && t.config.legend.customLegendItems.length === 0 && (t.globals.dom.elWrap.addEventListener("mousemove", e.onLegendHovered, !0), t.globals.dom.elWrap.addEventListener("mouseout", e.onLegendHovered, !0));
    } }, { key: "setLegendWrapXY", value: function(e, t) {
      var i = this.w, a = i.globals.dom.elLegendWrap, r = a.clientHeight, s = 0, n = 0;
      if (i.config.legend.position === "bottom")
        n = i.globals.svgHeight - Math.min(r, i.globals.svgHeight / 2) - 5;
      else if (i.config.legend.position === "top") {
        var o = new Me(this.ctx), h = o.dimHelpers.getTitleSubtitleCoords("title").height, d = o.dimHelpers.getTitleSubtitleCoords("subtitle").height;
        n = (h > 0 ? h - 10 : 0) + (d > 0 ? d - 10 : 0);
      }
      a.style.position = "absolute", s = s + e + i.config.legend.offsetX, n = n + t + i.config.legend.offsetY, a.style.left = s + "px", a.style.top = n + "px", i.config.legend.position === "right" && (a.style.left = "auto", a.style.right = 25 + i.config.legend.offsetX + "px"), ["width", "height"].forEach(function(c) {
        a.style[c] && (a.style[c] = parseInt(i.config.legend[c], 10) + "px");
      });
    } }, { key: "legendAlignHorizontal", value: function() {
      var e = this.w;
      e.globals.dom.elLegendWrap.style.right = 0;
      var t = new Me(this.ctx), i = t.dimHelpers.getTitleSubtitleCoords("title"), a = t.dimHelpers.getTitleSubtitleCoords("subtitle"), r = 0;
      e.config.legend.position === "top" && (r = i.height + a.height + e.config.title.margin + e.config.subtitle.margin - 10), this.setLegendWrapXY(20, r);
    } }, { key: "legendAlignVertical", value: function() {
      var e = this.w, t = this.legendHelpers.getLegendDimensions(), i = 0;
      e.config.legend.position === "left" && (i = 20), e.config.legend.position === "right" && (i = e.globals.svgWidth - t.clww - 10), this.setLegendWrapXY(i, 20);
    } }, { key: "onLegendHovered", value: function(e) {
      var t = this.w, i = e.target.classList.contains("apexcharts-legend-series") || e.target.classList.contains("apexcharts-legend-text") || e.target.classList.contains("apexcharts-legend-marker");
      if (t.config.chart.type === "heatmap" || this.isBarsDistributed) {
        if (i) {
          var a = parseInt(e.target.getAttribute("rel"), 10) - 1;
          this.ctx.events.fireEvent("legendHover", [this.ctx, a, this.w]), new re(this.ctx).highlightRangeInSeries(e, e.target);
        }
      } else
        !e.target.classList.contains("apexcharts-inactive-legend") && i && new re(this.ctx).toggleSeriesOnHover(e, e.target);
    } }, { key: "onLegendClick", value: function(e) {
      var t = this.w;
      if (!t.config.legend.customLegendItems.length && (e.target.classList.contains("apexcharts-legend-series") || e.target.classList.contains("apexcharts-legend-text") || e.target.classList.contains("apexcharts-legend-marker"))) {
        var i = parseInt(e.target.getAttribute("rel"), 10) - 1, a = e.target.getAttribute("data:collapsed") === "true", r = this.w.config.chart.events.legendClick;
        typeof r == "function" && r(this.ctx, i, this.w), this.ctx.events.fireEvent("legendClick", [this.ctx, i, this.w]);
        var s = this.w.config.legend.markers.onClick;
        typeof s == "function" && e.target.classList.contains("apexcharts-legend-marker") && (s(this.ctx, i, this.w), this.ctx.events.fireEvent("legendMarkerClick", [this.ctx, i, this.w])), t.config.chart.type !== "treemap" && t.config.chart.type !== "heatmap" && !this.isBarsDistributed && t.config.legend.onItemClick.toggleDataSeries && this.legendHelpers.toggleDataSeries(i, a);
      }
    } }]), y;
  }(), at = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
      var t = this.w;
      this.ev = this.w.config.chart.events, this.selectedClass = "apexcharts-selected", this.localeValues = this.w.globals.locale.toolbar, this.minX = t.globals.minX, this.maxX = t.globals.maxX;
    }
    return F(y, [{ key: "createToolbar", value: function() {
      var e = this, t = this.w, i = function() {
        return document.createElement("div");
      }, a = i();
      if (a.setAttribute("class", "apexcharts-toolbar"), a.style.top = t.config.chart.toolbar.offsetY + "px", a.style.right = 3 - t.config.chart.toolbar.offsetX + "px", t.globals.dom.elWrap.appendChild(a), this.elZoom = i(), this.elZoomIn = i(), this.elZoomOut = i(), this.elPan = i(), this.elSelection = i(), this.elZoomReset = i(), this.elMenuIcon = i(), this.elMenu = i(), this.elCustomIcons = [], this.t = t.config.chart.toolbar.tools, Array.isArray(this.t.customIcons))
        for (var r = 0; r < this.t.customIcons.length; r++)
          this.elCustomIcons.push(i());
      var s = [], n = function(c, g, p) {
        var x = c.toLowerCase();
        e.t[x] && t.config.chart.zoom.enabled && s.push({ el: g, icon: typeof e.t[x] == "string" ? e.t[x] : p, title: e.localeValues[c], class: "apexcharts-".concat(x, "-icon") });
      };
      n("zoomIn", this.elZoomIn, `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
    <path d="M0 0h24v24H0z" fill="none"/>
    <path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
</svg>
`), n("zoomOut", this.elZoomOut, `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
    <path d="M0 0h24v24H0z" fill="none"/>
    <path d="M7 11v2h10v-2H7zm5-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
</svg>
`);
      var o = function(c) {
        e.t[c] && t.config.chart[c].enabled && s.push({ el: c === "zoom" ? e.elZoom : e.elSelection, icon: typeof e.t[c] == "string" ? e.t[c] : c === "zoom" ? `<svg xmlns="http://www.w3.org/2000/svg" fill="#000000" height="24" viewBox="0 0 24 24" width="24">
    <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M12 10h-2v2H9v-2H7V9h2V7h1v2h2v1z"/>
</svg>` : `<svg fill="#6E8192" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
    <path d="M0 0h24v24H0z" fill="none"/>
    <path d="M3 5h2V3c-1.1 0-2 .9-2 2zm0 8h2v-2H3v2zm4 8h2v-2H7v2zM3 9h2V7H3v2zm10-6h-2v2h2V3zm6 0v2h2c0-1.1-.9-2-2-2zM5 21v-2H3c0 1.1.9 2 2 2zm-2-4h2v-2H3v2zM9 3H7v2h2V3zm2 18h2v-2h-2v2zm8-8h2v-2h-2v2zm0 8c1.1 0 2-.9 2-2h-2v2zm0-12h2V7h-2v2zm0 8h2v-2h-2v2zm-4 4h2v-2h-2v2zm0-16h2V3h-2v2z"/>
</svg>`, title: e.localeValues[c === "zoom" ? "selectionZoom" : "selection"], class: t.globals.isTouchDevice ? "apexcharts-element-hidden" : "apexcharts-".concat(c, "-icon") });
      };
      o("zoom"), o("selection"), this.t.pan && t.config.chart.zoom.enabled && s.push({ el: this.elPan, icon: typeof this.t.pan == "string" ? this.t.pan : `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" height="24" viewBox="0 0 24 24" width="24">
    <defs>
        <path d="M0 0h24v24H0z" id="a"/>
    </defs>
    <clipPath id="b">
        <use overflow="visible" xlink:href="#a"/>
    </clipPath>
    <path clip-path="url(#b)" d="M23 5.5V20c0 2.2-1.8 4-4 4h-7.3c-1.08 0-2.1-.43-2.85-1.19L1 14.83s1.26-1.23 1.3-1.25c.22-.19.49-.29.79-.29.22 0 .42.06.6.16.04.01 4.31 2.46 4.31 2.46V4c0-.83.67-1.5 1.5-1.5S11 3.17 11 4v7h1V1.5c0-.83.67-1.5 1.5-1.5S15 .67 15 1.5V11h1V2.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5V11h1V5.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5z"/>
</svg>`, title: this.localeValues.pan, class: t.globals.isTouchDevice ? "apexcharts-element-hidden" : "apexcharts-pan-icon" }), n("reset", this.elZoomReset, `<svg fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
    <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
    <path d="M0 0h24v24H0z" fill="none"/>
</svg>`), this.t.download && s.push({ el: this.elMenuIcon, icon: typeof this.t.download == "string" ? this.t.download : '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0V0z"/><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>', title: this.localeValues.menu, class: "apexcharts-menu-icon" });
      for (var h = 0; h < this.elCustomIcons.length; h++)
        s.push({ el: this.elCustomIcons[h], icon: this.t.customIcons[h].icon, title: this.t.customIcons[h].title, index: this.t.customIcons[h].index, class: "apexcharts-toolbar-custom-icon " + this.t.customIcons[h].class });
      s.forEach(function(c, g) {
        c.index && P.moveIndexInArray(s, g, c.index);
      });
      for (var d = 0; d < s.length; d++)
        X.setAttrs(s[d].el, { class: s[d].class, title: s[d].title }), s[d].el.innerHTML = s[d].icon, a.appendChild(s[d].el);
      this._createHamburgerMenu(a), t.globals.zoomEnabled ? this.elZoom.classList.add(this.selectedClass) : t.globals.panEnabled ? this.elPan.classList.add(this.selectedClass) : t.globals.selectionEnabled && this.elSelection.classList.add(this.selectedClass), this.addToolbarEventListeners();
    } }, { key: "_createHamburgerMenu", value: function(e) {
      this.elMenuItems = [], e.appendChild(this.elMenu), X.setAttrs(this.elMenu, { class: "apexcharts-menu" });
      for (var t = [{ name: "exportSVG", title: this.localeValues.exportToSVG }, { name: "exportPNG", title: this.localeValues.exportToPNG }, { name: "exportCSV", title: this.localeValues.exportToCSV }], i = 0; i < t.length; i++)
        this.elMenuItems.push(document.createElement("div")), this.elMenuItems[i].innerHTML = t[i].title, X.setAttrs(this.elMenuItems[i], { class: "apexcharts-menu-item ".concat(t[i].name), title: t[i].title }), this.elMenu.appendChild(this.elMenuItems[i]);
    } }, { key: "addToolbarEventListeners", value: function() {
      var e = this;
      this.elZoomReset.addEventListener("click", this.handleZoomReset.bind(this)), this.elSelection.addEventListener("click", this.toggleZoomSelection.bind(this, "selection")), this.elZoom.addEventListener("click", this.toggleZoomSelection.bind(this, "zoom")), this.elZoomIn.addEventListener("click", this.handleZoomIn.bind(this)), this.elZoomOut.addEventListener("click", this.handleZoomOut.bind(this)), this.elPan.addEventListener("click", this.togglePanning.bind(this)), this.elMenuIcon.addEventListener("click", this.toggleMenu.bind(this)), this.elMenuItems.forEach(function(i) {
        i.classList.contains("exportSVG") ? i.addEventListener("click", e.handleDownload.bind(e, "svg")) : i.classList.contains("exportPNG") ? i.addEventListener("click", e.handleDownload.bind(e, "png")) : i.classList.contains("exportCSV") && i.addEventListener("click", e.handleDownload.bind(e, "csv"));
      });
      for (var t = 0; t < this.t.customIcons.length; t++)
        this.elCustomIcons[t].addEventListener("click", this.t.customIcons[t].click.bind(this, this.ctx, this.ctx.w));
    } }, { key: "toggleZoomSelection", value: function(e) {
      this.ctx.getSyncedCharts().forEach(function(t) {
        t.ctx.toolbar.toggleOtherControls();
        var i = e === "selection" ? t.ctx.toolbar.elSelection : t.ctx.toolbar.elZoom, a = e === "selection" ? "selectionEnabled" : "zoomEnabled";
        t.w.globals[a] = !t.w.globals[a], i.classList.contains(t.ctx.toolbar.selectedClass) ? i.classList.remove(t.ctx.toolbar.selectedClass) : i.classList.add(t.ctx.toolbar.selectedClass);
      });
    } }, { key: "getToolbarIconsReference", value: function() {
      var e = this.w;
      this.elZoom || (this.elZoom = e.globals.dom.baseEl.querySelector(".apexcharts-zoom-icon")), this.elPan || (this.elPan = e.globals.dom.baseEl.querySelector(".apexcharts-pan-icon")), this.elSelection || (this.elSelection = e.globals.dom.baseEl.querySelector(".apexcharts-selection-icon"));
    } }, { key: "enableZoomPanFromToolbar", value: function(e) {
      this.toggleOtherControls(), e === "pan" ? this.w.globals.panEnabled = !0 : this.w.globals.zoomEnabled = !0;
      var t = e === "pan" ? this.elPan : this.elZoom, i = e === "pan" ? this.elZoom : this.elPan;
      t && t.classList.add(this.selectedClass), i && i.classList.remove(this.selectedClass);
    } }, { key: "togglePanning", value: function() {
      this.ctx.getSyncedCharts().forEach(function(e) {
        e.ctx.toolbar.toggleOtherControls(), e.w.globals.panEnabled = !e.w.globals.panEnabled, e.ctx.toolbar.elPan.classList.contains(e.ctx.toolbar.selectedClass) ? e.ctx.toolbar.elPan.classList.remove(e.ctx.toolbar.selectedClass) : e.ctx.toolbar.elPan.classList.add(e.ctx.toolbar.selectedClass);
      });
    } }, { key: "toggleOtherControls", value: function() {
      var e = this, t = this.w;
      t.globals.panEnabled = !1, t.globals.zoomEnabled = !1, t.globals.selectionEnabled = !1, this.getToolbarIconsReference(), [this.elPan, this.elSelection, this.elZoom].forEach(function(i) {
        i && i.classList.remove(e.selectedClass);
      });
    } }, { key: "handleZoomIn", value: function() {
      var e = this.w;
      e.globals.isRangeBar && (this.minX = e.globals.minY, this.maxX = e.globals.maxY);
      var t = (this.minX + this.maxX) / 2, i = (this.minX + t) / 2, a = (this.maxX + t) / 2, r = this._getNewMinXMaxX(i, a);
      e.globals.disableZoomIn || this.zoomUpdateOptions(r.minX, r.maxX);
    } }, { key: "handleZoomOut", value: function() {
      var e = this.w;
      if (e.globals.isRangeBar && (this.minX = e.globals.minY, this.maxX = e.globals.maxY), !(e.config.xaxis.type === "datetime" && new Date(this.minX).getUTCFullYear() < 1e3)) {
        var t = (this.minX + this.maxX) / 2, i = this.minX - (t - this.minX), a = this.maxX - (t - this.maxX), r = this._getNewMinXMaxX(i, a);
        e.globals.disableZoomOut || this.zoomUpdateOptions(r.minX, r.maxX);
      }
    } }, { key: "_getNewMinXMaxX", value: function(e, t) {
      var i = this.w.config.xaxis.convertedCatToNumeric;
      return { minX: i ? Math.floor(e) : e, maxX: i ? Math.floor(t) : t };
    } }, { key: "zoomUpdateOptions", value: function(e, t) {
      var i = this.w;
      if (e !== void 0 || t !== void 0) {
        if (!(i.config.xaxis.convertedCatToNumeric && (e < 1 && (e = 1, t = i.globals.dataPoints), t - e < 2))) {
          var a = { min: e, max: t }, r = this.getBeforeZoomRange(a);
          r && (a = r.xaxis);
          var s = { xaxis: a }, n = P.clone(i.globals.initialConfig.yaxis);
          i.config.chart.group || (s.yaxis = n), this.w.globals.zoomed = !0, this.ctx.updateHelpers._updateOptions(s, !1, this.w.config.chart.animations.dynamicAnimation.enabled), this.zoomCallback(a, n);
        }
      } else
        this.handleZoomReset();
    } }, { key: "zoomCallback", value: function(e, t) {
      typeof this.ev.zoomed == "function" && this.ev.zoomed(this.ctx, { xaxis: e, yaxis: t });
    } }, { key: "getBeforeZoomRange", value: function(e, t) {
      var i = null;
      return typeof this.ev.beforeZoom == "function" && (i = this.ev.beforeZoom(this, { xaxis: e, yaxis: t })), i;
    } }, { key: "toggleMenu", value: function() {
      var e = this;
      window.setTimeout(function() {
        e.elMenu.classList.contains("apexcharts-menu-open") ? e.elMenu.classList.remove("apexcharts-menu-open") : e.elMenu.classList.add("apexcharts-menu-open");
      }, 0);
    } }, { key: "handleDownload", value: function(e) {
      var t = this.w, i = new Pe(this.ctx);
      switch (e) {
        case "svg":
          i.exportToSVG(this.ctx);
          break;
        case "png":
          i.exportToPng(this.ctx);
          break;
        case "csv":
          i.exportToCSV({ series: t.config.series, columnDelimiter: t.config.chart.toolbar.export.csv.columnDelimiter });
      }
    } }, { key: "handleZoomReset", value: function(e) {
      this.ctx.getSyncedCharts().forEach(function(t) {
        var i = t.w;
        if (i.globals.lastXAxis.min = i.globals.initialConfig.xaxis.min, i.globals.lastXAxis.max = i.globals.initialConfig.xaxis.max, t.updateHelpers.revertDefaultAxisMinMax(), typeof i.config.chart.events.beforeResetZoom == "function") {
          var a = i.config.chart.events.beforeResetZoom(t, i);
          a && t.updateHelpers.revertDefaultAxisMinMax(a);
        }
        typeof i.config.chart.events.zoomed == "function" && t.ctx.toolbar.zoomCallback({ min: i.config.xaxis.min, max: i.config.xaxis.max }), i.globals.zoomed = !1;
        var r = t.ctx.series.emptyCollapsedSeries(P.clone(i.globals.initialSeries));
        t.updateHelpers._updateSeries(r, i.config.chart.animations.dynamicAnimation.enabled);
      });
    } }, { key: "destroy", value: function() {
      this.elZoom = null, this.elZoomIn = null, this.elZoomOut = null, this.elPan = null, this.elSelection = null, this.elZoomReset = null, this.elMenuIcon = null;
    } }]), y;
  }(), zt = function(y) {
    be(t, at);
    var e = xe(t);
    function t(i) {
      var a;
      return R(this, t), (a = e.call(this, i)).ctx = i, a.w = i.w, a.dragged = !1, a.graphics = new X(a.ctx), a.eventList = ["mousedown", "mouseleave", "mousemove", "touchstart", "touchmove", "mouseup", "touchend", "wheel"], a.clientX = 0, a.clientY = 0, a.startX = 0, a.endX = 0, a.dragX = 0, a.startY = 0, a.endY = 0, a.dragY = 0, a.moveDirection = "none", a.debounceTimer = null, a.debounceDelay = 100, a.wheelDelay = 400, a;
    }
    return F(t, [{ key: "init", value: function(i) {
      var a = this, r = i.xyRatios, s = this.w, n = this;
      this.xyRatios = r, this.zoomRect = this.graphics.drawRect(0, 0, 0, 0), this.selectionRect = this.graphics.drawRect(0, 0, 0, 0), this.gridRect = s.globals.dom.baseEl.querySelector(".apexcharts-grid"), this.zoomRect.node.classList.add("apexcharts-zoom-rect"), this.selectionRect.node.classList.add("apexcharts-selection-rect"), s.globals.dom.elGraphical.add(this.zoomRect), s.globals.dom.elGraphical.add(this.selectionRect), s.config.chart.selection.type === "x" ? this.slDraggableRect = this.selectionRect.draggable({ minX: 0, minY: 0, maxX: s.globals.gridWidth, maxY: s.globals.gridHeight }).on("dragmove", this.selectionDragging.bind(this, "dragging")) : s.config.chart.selection.type === "y" ? this.slDraggableRect = this.selectionRect.draggable({ minX: 0, maxX: s.globals.gridWidth }).on("dragmove", this.selectionDragging.bind(this, "dragging")) : this.slDraggableRect = this.selectionRect.draggable().on("dragmove", this.selectionDragging.bind(this, "dragging")), this.preselectedSelection(), this.hoverArea = s.globals.dom.baseEl.querySelector("".concat(s.globals.chartClass, " .apexcharts-svg")), this.hoverArea.classList.add("apexcharts-zoomable"), this.eventList.forEach(function(o) {
        a.hoverArea.addEventListener(o, n.svgMouseEvents.bind(n, r), { capture: !1, passive: !0 });
      }), s.config.chart.zoom.allowMouseWheelZoom && this.hoverArea.addEventListener("wheel", n.mouseWheelEvent.bind(n), { capture: !1, passive: !1 });
    } }, { key: "destroy", value: function() {
      this.slDraggableRect && (this.slDraggableRect.draggable(!1), this.slDraggableRect.off(), this.selectionRect.off()), this.selectionRect = null, this.zoomRect = null, this.gridRect = null;
    } }, { key: "svgMouseEvents", value: function(i, a) {
      var r = this.w, s = this, n = this.ctx.toolbar, o = r.globals.zoomEnabled ? r.config.chart.zoom.type : r.config.chart.selection.type, h = r.config.chart.toolbar.autoSelected;
      if (a.shiftKey ? (this.shiftWasPressed = !0, n.enableZoomPanFromToolbar(h === "pan" ? "zoom" : "pan")) : this.shiftWasPressed && (n.enableZoomPanFromToolbar(h), this.shiftWasPressed = !1), a.target) {
        var d, c = a.target.classList;
        if (a.target.parentNode && a.target.parentNode !== null && (d = a.target.parentNode.classList), !(c.contains("apexcharts-selection-rect") || c.contains("apexcharts-legend-marker") || c.contains("apexcharts-legend-text") || d && d.contains("apexcharts-toolbar"))) {
          if (s.clientX = a.type === "touchmove" || a.type === "touchstart" ? a.touches[0].clientX : a.type === "touchend" ? a.changedTouches[0].clientX : a.clientX, s.clientY = a.type === "touchmove" || a.type === "touchstart" ? a.touches[0].clientY : a.type === "touchend" ? a.changedTouches[0].clientY : a.clientY, a.type === "mousedown" && a.which === 1) {
            var g = s.gridRect.getBoundingClientRect();
            s.startX = s.clientX - g.left, s.startY = s.clientY - g.top, s.dragged = !1, s.w.globals.mousedown = !0;
          }
          if ((a.type === "mousemove" && a.which === 1 || a.type === "touchmove") && (s.dragged = !0, r.globals.panEnabled ? (r.globals.selection = null, s.w.globals.mousedown && s.panDragging({ context: s, zoomtype: o, xyRatios: i })) : (s.w.globals.mousedown && r.globals.zoomEnabled || s.w.globals.mousedown && r.globals.selectionEnabled) && (s.selection = s.selectionDrawing({ context: s, zoomtype: o }))), a.type === "mouseup" || a.type === "touchend" || a.type === "mouseleave") {
            var p, x = (p = s.gridRect) === null || p === void 0 ? void 0 : p.getBoundingClientRect();
            x && s.w.globals.mousedown && (s.endX = s.clientX - x.left, s.endY = s.clientY - x.top, s.dragX = Math.abs(s.endX - s.startX), s.dragY = Math.abs(s.endY - s.startY), (r.globals.zoomEnabled || r.globals.selectionEnabled) && s.selectionDrawn({ context: s, zoomtype: o }), r.globals.panEnabled && r.config.xaxis.convertedCatToNumeric && s.delayedPanScrolled()), r.globals.zoomEnabled && s.hideSelectionRect(this.selectionRect), s.dragged = !1, s.w.globals.mousedown = !1;
          }
          this.makeSelectionRectDraggable();
        }
      }
    } }, { key: "mouseWheelEvent", value: function(i) {
      var a = this, r = this.w;
      i.preventDefault();
      var s = Date.now();
      s - r.globals.lastWheelExecution > this.wheelDelay && (this.executeMouseWheelZoom(i), r.globals.lastWheelExecution = s), this.debounceTimer && clearTimeout(this.debounceTimer), this.debounceTimer = setTimeout(function() {
        s - r.globals.lastWheelExecution > a.wheelDelay && (a.executeMouseWheelZoom(i), r.globals.lastWheelExecution = s);
      }, this.debounceDelay);
    } }, { key: "executeMouseWheelZoom", value: function(i) {
      var a, r = this.w;
      this.minX = r.globals.isRangeBar ? r.globals.minY : r.globals.minX, this.maxX = r.globals.isRangeBar ? r.globals.maxY : r.globals.maxX;
      var s = (a = this.gridRect) === null || a === void 0 ? void 0 : a.getBoundingClientRect();
      if (s) {
        var n, o, h, d = (i.clientX - s.left) / s.width, c = this.minX, g = this.maxX, p = g - c;
        if (i.deltaY < 0) {
          var x = c + d * p;
          o = x - (n = 0.5 * p) / 2, h = x + n / 2;
        } else
          o = c - (n = 1.5 * p) / 2, h = g + n / 2;
        if (!r.globals.isRangeBar) {
          o = Math.max(o, r.globals.initialMinX), h = Math.min(h, r.globals.initialMaxX);
          var f = 0.01 * (r.globals.initialMaxX - r.globals.initialMinX);
          if (h - o < f) {
            var m = (o + h) / 2;
            o = m - f / 2, h = m + f / 2;
          }
        }
        var v = this._getNewMinXMaxX(o, h);
        isNaN(v.minX) || isNaN(v.maxX) || this.zoomUpdateOptions(v.minX, v.maxX);
      }
    } }, { key: "makeSelectionRectDraggable", value: function() {
      var i = this.w;
      if (this.selectionRect) {
        var a = this.selectionRect.node.getBoundingClientRect();
        a.width > 0 && a.height > 0 && this.slDraggableRect.selectize({ points: "l, r", pointSize: 8, pointType: "rect" }).resize({ constraint: { minX: 0, minY: 0, maxX: i.globals.gridWidth, maxY: i.globals.gridHeight } }).on("resizing", this.selectionDragging.bind(this, "resizing"));
      }
    } }, { key: "preselectedSelection", value: function() {
      var i = this.w, a = this.xyRatios;
      if (!i.globals.zoomEnabled) {
        if (i.globals.selection !== void 0 && i.globals.selection !== null)
          this.drawSelectionRect(i.globals.selection);
        else if (i.config.chart.selection.xaxis.min !== void 0 && i.config.chart.selection.xaxis.max !== void 0) {
          var r = (i.config.chart.selection.xaxis.min - i.globals.minX) / a.xRatio, s = i.globals.gridWidth - (i.globals.maxX - i.config.chart.selection.xaxis.max) / a.xRatio - r;
          i.globals.isRangeBar && (r = (i.config.chart.selection.xaxis.min - i.globals.yAxisScale[0].niceMin) / a.invertedYRatio, s = (i.config.chart.selection.xaxis.max - i.config.chart.selection.xaxis.min) / a.invertedYRatio);
          var n = { x: r, y: 0, width: s, height: i.globals.gridHeight, translateX: 0, translateY: 0, selectionEnabled: !0 };
          this.drawSelectionRect(n), this.makeSelectionRectDraggable(), typeof i.config.chart.events.selection == "function" && i.config.chart.events.selection(this.ctx, { xaxis: { min: i.config.chart.selection.xaxis.min, max: i.config.chart.selection.xaxis.max }, yaxis: {} });
        }
      }
    } }, { key: "drawSelectionRect", value: function(i) {
      var a = i.x, r = i.y, s = i.width, n = i.height, o = i.translateX, h = o === void 0 ? 0 : o, d = i.translateY, c = d === void 0 ? 0 : d, g = this.w, p = this.zoomRect, x = this.selectionRect;
      if (this.dragged || g.globals.selection !== null) {
        var f = { transform: "translate(" + h + ", " + c + ")" };
        g.globals.zoomEnabled && this.dragged && (s < 0 && (s = 1), p.attr({ x: a, y: r, width: s, height: n, fill: g.config.chart.zoom.zoomedArea.fill.color, "fill-opacity": g.config.chart.zoom.zoomedArea.fill.opacity, stroke: g.config.chart.zoom.zoomedArea.stroke.color, "stroke-width": g.config.chart.zoom.zoomedArea.stroke.width, "stroke-opacity": g.config.chart.zoom.zoomedArea.stroke.opacity }), X.setAttrs(p.node, f)), g.globals.selectionEnabled && (x.attr({ x: a, y: r, width: s > 0 ? s : 0, height: n > 0 ? n : 0, fill: g.config.chart.selection.fill.color, "fill-opacity": g.config.chart.selection.fill.opacity, stroke: g.config.chart.selection.stroke.color, "stroke-width": g.config.chart.selection.stroke.width, "stroke-dasharray": g.config.chart.selection.stroke.dashArray, "stroke-opacity": g.config.chart.selection.stroke.opacity }), X.setAttrs(x.node, f));
      }
    } }, { key: "hideSelectionRect", value: function(i) {
      i && i.attr({ x: 0, y: 0, width: 0, height: 0 });
    } }, { key: "selectionDrawing", value: function(i) {
      var a = i.context, r = i.zoomtype, s = this.w, n = a, o = this.gridRect.getBoundingClientRect(), h = n.startX - 1, d = n.startY, c = !1, g = !1, p = n.clientX - o.left - h, x = n.clientY - o.top - d, f = {};
      return Math.abs(p + h) > s.globals.gridWidth ? p = s.globals.gridWidth - h : n.clientX - o.left < 0 && (p = h), h > n.clientX - o.left && (c = !0, p = Math.abs(p)), d > n.clientY - o.top && (g = !0, x = Math.abs(x)), f = r === "x" ? { x: c ? h - p : h, y: 0, width: p, height: s.globals.gridHeight } : r === "y" ? { x: 0, y: g ? d - x : d, width: s.globals.gridWidth, height: x } : { x: c ? h - p : h, y: g ? d - x : d, width: p, height: x }, n.drawSelectionRect(f), n.selectionDragging("resizing"), f;
    } }, { key: "selectionDragging", value: function(i, a) {
      var r = this, s = this.w, n = this.xyRatios, o = this.selectionRect, h = 0;
      i === "resizing" && (h = 30);
      var d = function(g) {
        return parseFloat(o.node.getAttribute(g));
      }, c = { x: d("x"), y: d("y"), width: d("width"), height: d("height") };
      s.globals.selection = c, typeof s.config.chart.events.selection == "function" && s.globals.selectionEnabled && (clearTimeout(this.w.globals.selectionResizeTimer), this.w.globals.selectionResizeTimer = window.setTimeout(function() {
        var g, p, x, f, m = r.gridRect.getBoundingClientRect(), v = o.node.getBoundingClientRect();
        s.globals.isRangeBar ? (g = s.globals.yAxisScale[0].niceMin + (v.left - m.left) * n.invertedYRatio, p = s.globals.yAxisScale[0].niceMin + (v.right - m.left) * n.invertedYRatio, x = 0, f = 1) : (g = s.globals.xAxisScale.niceMin + (v.left - m.left) * n.xRatio, p = s.globals.xAxisScale.niceMin + (v.right - m.left) * n.xRatio, x = s.globals.yAxisScale[0].niceMin + (m.bottom - v.bottom) * n.yRatio[0], f = s.globals.yAxisScale[0].niceMax - (v.top - m.top) * n.yRatio[0]);
        var w = { xaxis: { min: g, max: p }, yaxis: { min: x, max: f } };
        s.config.chart.events.selection(r.ctx, w), s.config.chart.brush.enabled && s.config.chart.events.brushScrolled !== void 0 && s.config.chart.events.brushScrolled(r.ctx, w);
      }, h));
    } }, { key: "selectionDrawn", value: function(i) {
      var a = i.context, r = i.zoomtype, s = this.w, n = a, o = this.xyRatios, h = this.ctx.toolbar;
      if (n.startX > n.endX) {
        var d = n.startX;
        n.startX = n.endX, n.endX = d;
      }
      if (n.startY > n.endY) {
        var c = n.startY;
        n.startY = n.endY, n.endY = c;
      }
      var g = void 0, p = void 0;
      s.globals.isRangeBar ? (g = s.globals.yAxisScale[0].niceMin + n.startX * o.invertedYRatio, p = s.globals.yAxisScale[0].niceMin + n.endX * o.invertedYRatio) : (g = s.globals.xAxisScale.niceMin + n.startX * o.xRatio, p = s.globals.xAxisScale.niceMin + n.endX * o.xRatio);
      var x = [], f = [];
      if (s.config.yaxis.forEach(function(A, k) {
        var S = s.globals.seriesYAxisMap[k][0];
        x.push(s.globals.yAxisScale[k].niceMax - o.yRatio[S] * n.startY), f.push(s.globals.yAxisScale[k].niceMax - o.yRatio[S] * n.endY);
      }), n.dragged && (n.dragX > 10 || n.dragY > 10) && g !== p) {
        if (s.globals.zoomEnabled) {
          var m = P.clone(s.globals.initialConfig.yaxis), v = P.clone(s.globals.initialConfig.xaxis);
          if (s.globals.zoomed = !0, s.config.xaxis.convertedCatToNumeric && (g = Math.floor(g), p = Math.floor(p), g < 1 && (g = 1, p = s.globals.dataPoints), p - g < 2 && (p = g + 1)), r !== "xy" && r !== "x" || (v = { min: g, max: p }), r !== "xy" && r !== "y" || m.forEach(function(A, k) {
            m[k].min = f[k], m[k].max = x[k];
          }), h) {
            var w = h.getBeforeZoomRange(v, m);
            w && (v = w.xaxis ? w.xaxis : v, m = w.yaxis ? w.yaxis : m);
          }
          var l = { xaxis: v };
          s.config.chart.group || (l.yaxis = m), n.ctx.updateHelpers._updateOptions(l, !1, n.w.config.chart.animations.dynamicAnimation.enabled), typeof s.config.chart.events.zoomed == "function" && h.zoomCallback(v, m);
        } else if (s.globals.selectionEnabled) {
          var u, b = null;
          u = { min: g, max: p }, r !== "xy" && r !== "y" || (b = P.clone(s.config.yaxis)).forEach(function(A, k) {
            b[k].min = f[k], b[k].max = x[k];
          }), s.globals.selection = n.selection, typeof s.config.chart.events.selection == "function" && s.config.chart.events.selection(n.ctx, { xaxis: u, yaxis: b });
        }
      }
    } }, { key: "panDragging", value: function(i) {
      var a = i.context, r = this.w, s = a;
      if (r.globals.lastClientPosition.x !== void 0) {
        var n = r.globals.lastClientPosition.x - s.clientX, o = r.globals.lastClientPosition.y - s.clientY;
        Math.abs(n) > Math.abs(o) && n > 0 ? this.moveDirection = "left" : Math.abs(n) > Math.abs(o) && n < 0 ? this.moveDirection = "right" : Math.abs(o) > Math.abs(n) && o > 0 ? this.moveDirection = "up" : Math.abs(o) > Math.abs(n) && o < 0 && (this.moveDirection = "down");
      }
      r.globals.lastClientPosition = { x: s.clientX, y: s.clientY };
      var h = r.globals.isRangeBar ? r.globals.minY : r.globals.minX, d = r.globals.isRangeBar ? r.globals.maxY : r.globals.maxX;
      r.config.xaxis.convertedCatToNumeric || s.panScrolled(h, d);
    } }, { key: "delayedPanScrolled", value: function() {
      var i = this.w, a = i.globals.minX, r = i.globals.maxX, s = (i.globals.maxX - i.globals.minX) / 2;
      this.moveDirection === "left" ? (a = i.globals.minX + s, r = i.globals.maxX + s) : this.moveDirection === "right" && (a = i.globals.minX - s, r = i.globals.maxX - s), a = Math.floor(a), r = Math.floor(r), this.updateScrolledChart({ xaxis: { min: a, max: r } }, a, r);
    } }, { key: "panScrolled", value: function(i, a) {
      var r = this.w, s = this.xyRatios, n = P.clone(r.globals.initialConfig.yaxis), o = s.xRatio, h = r.globals.minX, d = r.globals.maxX;
      r.globals.isRangeBar && (o = s.invertedYRatio, h = r.globals.minY, d = r.globals.maxY), this.moveDirection === "left" ? (i = h + r.globals.gridWidth / 15 * o, a = d + r.globals.gridWidth / 15 * o) : this.moveDirection === "right" && (i = h - r.globals.gridWidth / 15 * o, a = d - r.globals.gridWidth / 15 * o), r.globals.isRangeBar || (i < r.globals.initialMinX || a > r.globals.initialMaxX) && (i = h, a = d);
      var c = { xaxis: { min: i, max: a } };
      r.config.chart.group || (c.yaxis = n), this.updateScrolledChart(c, i, a);
    } }, { key: "updateScrolledChart", value: function(i, a, r) {
      var s = this.w;
      this.ctx.updateHelpers._updateOptions(i, !1, !1), typeof s.config.chart.events.scrolled == "function" && s.config.chart.events.scrolled(this.ctx, { xaxis: { min: a, max: r } });
    } }]), t;
  }(), st = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.ttCtx = e, this.ctx = e.ctx;
    }
    return F(y, [{ key: "getNearestValues", value: function(e) {
      var t = e.hoverArea, i = e.elGrid, a = e.clientX, r = e.clientY, s = this.w, n = i.getBoundingClientRect(), o = n.width, h = n.height, d = o / (s.globals.dataPoints - 1), c = h / s.globals.dataPoints, g = this.hasBars();
      !s.globals.comboCharts && !g || s.config.xaxis.convertedCatToNumeric || (d = o / s.globals.dataPoints);
      var p = a - n.left - s.globals.barPadForNumericAxis, x = r - n.top;
      p < 0 || x < 0 || p > o || x > h ? (t.classList.remove("hovering-zoom"), t.classList.remove("hovering-pan")) : s.globals.zoomEnabled ? (t.classList.remove("hovering-pan"), t.classList.add("hovering-zoom")) : s.globals.panEnabled && (t.classList.remove("hovering-zoom"), t.classList.add("hovering-pan"));
      var f = Math.round(p / d), m = Math.floor(x / c);
      g && !s.config.xaxis.convertedCatToNumeric && (f = Math.ceil(p / d), f -= 1);
      var v = null, w = null, l = s.globals.seriesXvalues.map(function(S) {
        return S.filter(function(C) {
          return P.isNumber(C);
        });
      }), u = s.globals.seriesYvalues.map(function(S) {
        return S.filter(function(C) {
          return P.isNumber(C);
        });
      });
      if (s.globals.isXNumeric) {
        var b = this.ttCtx.getElGrid().getBoundingClientRect(), A = p * (b.width / o), k = x * (b.height / h);
        v = (w = this.closestInMultiArray(A, k, l, u)).index, f = w.j, v !== null && (l = s.globals.seriesXvalues[v], f = (w = this.closestInArray(A, l)).index);
      }
      return s.globals.capturedSeriesIndex = v === null ? -1 : v, (!f || f < 1) && (f = 0), s.globals.isBarHorizontal ? s.globals.capturedDataPointIndex = m : s.globals.capturedDataPointIndex = f, { capturedSeries: v, j: s.globals.isBarHorizontal ? m : f, hoverX: p, hoverY: x };
    } }, { key: "closestInMultiArray", value: function(e, t, i, a) {
      var r = this.w, s = 0, n = null, o = -1;
      r.globals.series.length > 1 ? s = this.getFirstActiveXArray(i) : n = 0;
      var h = i[s][0], d = Math.abs(e - h);
      if (i.forEach(function(p) {
        p.forEach(function(x, f) {
          var m = Math.abs(e - x);
          m <= d && (d = m, o = f);
        });
      }), o !== -1) {
        var c = a[s][o], g = Math.abs(t - c);
        n = s, a.forEach(function(p, x) {
          var f = Math.abs(t - p[o]);
          f <= g && (g = f, n = x);
        });
      }
      return { index: n, j: o };
    } }, { key: "getFirstActiveXArray", value: function(e) {
      for (var t = this.w, i = 0, a = e.map(function(s, n) {
        return s.length > 0 ? n : -1;
      }), r = 0; r < a.length; r++)
        if (a[r] !== -1 && t.globals.collapsedSeriesIndices.indexOf(r) === -1 && t.globals.ancillaryCollapsedSeriesIndices.indexOf(r) === -1) {
          i = a[r];
          break;
        }
      return i;
    } }, { key: "closestInArray", value: function(e, t) {
      for (var i = t[0], a = null, r = Math.abs(e - i), s = 0; s < t.length; s++) {
        var n = Math.abs(e - t[s]);
        n < r && (r = n, a = s);
      }
      return { index: a };
    } }, { key: "isXoverlap", value: function(e) {
      var t = [], i = this.w.globals.seriesX.filter(function(r) {
        return r[0] !== void 0;
      });
      if (i.length > 0)
        for (var a = 0; a < i.length - 1; a++)
          i[a][e] !== void 0 && i[a + 1][e] !== void 0 && i[a][e] !== i[a + 1][e] && t.push("unEqual");
      return t.length === 0;
    } }, { key: "isInitialSeriesSameLen", value: function() {
      for (var e = !0, t = this.w.globals.initialSeries, i = 0; i < t.length - 1; i++)
        if (t[i].data.length !== t[i + 1].data.length) {
          e = !1;
          break;
        }
      return e;
    } }, { key: "getBarsHeight", value: function(e) {
      return J(e).reduce(function(t, i) {
        return t + i.getBBox().height;
      }, 0);
    } }, { key: "getElMarkers", value: function(e) {
      return typeof e == "number" ? this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series[data\\:realIndex='".concat(e, "'] .apexcharts-series-markers-wrap > *")) : this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series-markers-wrap > *");
    } }, { key: "getAllMarkers", value: function() {
      var e = this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series-markers-wrap");
      (e = J(e)).sort(function(i, a) {
        var r = Number(i.getAttribute("data:realIndex")), s = Number(a.getAttribute("data:realIndex"));
        return s < r ? 1 : s > r ? -1 : 0;
      });
      var t = [];
      return e.forEach(function(i) {
        t.push(i.querySelector(".apexcharts-marker"));
      }), t;
    } }, { key: "hasMarkers", value: function(e) {
      return this.getElMarkers(e).length > 0;
    } }, { key: "getPathFromPoint", value: function(e, t) {
      var i = Number(e.getAttribute("cx")), a = Number(e.getAttribute("cy")), r = e.getAttribute("shape");
      return new X(this.ctx).getMarkerPath(i, a, r, t);
    } }, { key: "getElBars", value: function() {
      return this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-bar-series,  .apexcharts-candlestick-series, .apexcharts-boxPlot-series, .apexcharts-rangebar-series");
    } }, { key: "hasBars", value: function() {
      return this.getElBars().length > 0;
    } }, { key: "getHoverMarkerSize", value: function(e) {
      var t = this.w, i = t.config.markers.hover.size;
      return i === void 0 && (i = t.globals.markers.size[e] + t.config.markers.hover.sizeOffset), i;
    } }, { key: "toggleAllTooltipSeriesGroups", value: function(e) {
      var t = this.w, i = this.ttCtx;
      i.allTooltipSeriesGroups.length === 0 && (i.allTooltipSeriesGroups = t.globals.dom.baseEl.querySelectorAll(".apexcharts-tooltip-series-group"));
      for (var a = i.allTooltipSeriesGroups, r = 0; r < a.length; r++)
        e === "enable" ? (a[r].classList.add("apexcharts-active"), a[r].style.display = t.config.tooltip.items.display) : (a[r].classList.remove("apexcharts-active"), a[r].style.display = "none");
    } }]), y;
  }(), Xt = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.ctx = e.ctx, this.ttCtx = e, this.tooltipUtil = new st(e);
    }
    return F(y, [{ key: "drawSeriesTexts", value: function(e) {
      var t = e.shared, i = t === void 0 || t, a = e.ttItems, r = e.i, s = r === void 0 ? 0 : r, n = e.j, o = n === void 0 ? null : n, h = e.y1, d = e.y2, c = e.e, g = this.w;
      g.config.tooltip.custom !== void 0 ? this.handleCustomTooltip({ i: s, j: o, y1: h, y2: d, w: g }) : this.toggleActiveInactiveSeries(i, s);
      var p = this.getValuesToPrint({ i: s, j: o });
      this.printLabels({ i: s, j: o, values: p, ttItems: a, shared: i, e: c });
      var x = this.ttCtx.getElTooltip();
      this.ttCtx.tooltipRect.ttWidth = x.getBoundingClientRect().width, this.ttCtx.tooltipRect.ttHeight = x.getBoundingClientRect().height;
    } }, { key: "printLabels", value: function(e) {
      var t, i = this, a = e.i, r = e.j, s = e.values, n = e.ttItems, o = e.shared, h = e.e, d = this.w, c = [], g = function(b) {
        return d.globals.seriesGoals[b] && d.globals.seriesGoals[b][r] && Array.isArray(d.globals.seriesGoals[b][r]);
      }, p = s.xVal, x = s.zVal, f = s.xAxisTTVal, m = "", v = d.globals.colors[a];
      r !== null && d.config.plotOptions.bar.distributed && (v = d.globals.colors[r]);
      for (var w = function(b, A) {
        var k = i.getFormatters(a);
        m = i.getSeriesName({ fn: k.yLbTitleFormatter, index: a, seriesIndex: a, j: r }), d.config.chart.type === "treemap" && (m = k.yLbTitleFormatter(String(d.config.series[a].data[r].x), { series: d.globals.series, seriesIndex: a, dataPointIndex: r, w: d }));
        var S = d.config.tooltip.inverseOrder ? A : b;
        if (d.globals.axisCharts) {
          var C = function(T) {
            var I, z, Y, D;
            return d.globals.isRangeData ? k.yLbFormatter((I = d.globals.seriesRangeStart) === null || I === void 0 || (z = I[T]) === null || z === void 0 ? void 0 : z[r], { series: d.globals.seriesRangeStart, seriesIndex: T, dataPointIndex: r, w: d }) + " - " + k.yLbFormatter((Y = d.globals.seriesRangeEnd) === null || Y === void 0 || (D = Y[T]) === null || D === void 0 ? void 0 : D[r], { series: d.globals.seriesRangeEnd, seriesIndex: T, dataPointIndex: r, w: d }) : k.yLbFormatter(d.globals.series[T][r], { series: d.globals.series, seriesIndex: T, dataPointIndex: r, w: d });
          };
          if (o)
            k = i.getFormatters(S), m = i.getSeriesName({ fn: k.yLbTitleFormatter, index: S, seriesIndex: a, j: r }), v = d.globals.colors[S], t = C(S), g(S) && (c = d.globals.seriesGoals[S][r].map(function(T) {
              return { attrs: T, val: k.yLbFormatter(T.value, { seriesIndex: S, dataPointIndex: r, w: d }) };
            }));
          else {
            var L, M = h == null || (L = h.target) === null || L === void 0 ? void 0 : L.getAttribute("fill");
            M && (M.indexOf("url") !== -1 ? M.indexOf("Pattern") !== -1 && (v = d.globals.dom.baseEl.querySelector(M.substr(4).slice(0, -1)).childNodes[0].getAttribute("stroke")) : v = M), t = C(a), g(a) && Array.isArray(d.globals.seriesGoals[a][r]) && (c = d.globals.seriesGoals[a][r].map(function(T) {
              return { attrs: T, val: k.yLbFormatter(T.value, { seriesIndex: a, dataPointIndex: r, w: d }) };
            }));
          }
        }
        r === null && (t = k.yLbFormatter(d.globals.series[a], E(E({}, d), {}, { seriesIndex: a, dataPointIndex: a }))), i.DOMHandling({ i: a, t: S, j: r, ttItems: n, values: { val: t, goalVals: c, xVal: p, xAxisTTVal: f, zVal: x }, seriesName: m, shared: o, pColor: v });
      }, l = 0, u = d.globals.series.length - 1; l < d.globals.series.length; l++, u--)
        w(l, u);
    } }, { key: "getFormatters", value: function(e) {
      var t, i = this.w, a = i.globals.yLabelFormatters[e];
      return i.globals.ttVal !== void 0 ? Array.isArray(i.globals.ttVal) ? (a = i.globals.ttVal[e] && i.globals.ttVal[e].formatter, t = i.globals.ttVal[e] && i.globals.ttVal[e].title && i.globals.ttVal[e].title.formatter) : (a = i.globals.ttVal.formatter, typeof i.globals.ttVal.title.formatter == "function" && (t = i.globals.ttVal.title.formatter)) : t = i.config.tooltip.y.title.formatter, typeof a != "function" && (a = i.globals.yLabelFormatters[0] ? i.globals.yLabelFormatters[0] : function(r) {
        return r;
      }), typeof t != "function" && (t = function(r) {
        return r;
      }), { yLbFormatter: a, yLbTitleFormatter: t };
    } }, { key: "getSeriesName", value: function(e) {
      var t = e.fn, i = e.index, a = e.seriesIndex, r = e.j, s = this.w;
      return t(String(s.globals.seriesNames[i]), { series: s.globals.series, seriesIndex: a, dataPointIndex: r, w: s });
    } }, { key: "DOMHandling", value: function(e) {
      e.i;
      var t = e.t, i = e.j, a = e.ttItems, r = e.values, s = e.seriesName, n = e.shared, o = e.pColor, h = this.w, d = this.ttCtx, c = r.val, g = r.goalVals, p = r.xVal, x = r.xAxisTTVal, f = r.zVal, m = null;
      m = a[t].children, h.config.tooltip.fillSeriesColor && (a[t].style.backgroundColor = o, m[0].style.display = "none"), d.showTooltipTitle && (d.tooltipTitle === null && (d.tooltipTitle = h.globals.dom.baseEl.querySelector(".apexcharts-tooltip-title")), d.tooltipTitle.innerHTML = p), d.isXAxisTooltipEnabled && (d.xaxisTooltipText.innerHTML = x !== "" ? x : p);
      var v = a[t].querySelector(".apexcharts-tooltip-text-y-label");
      v && (v.innerHTML = s || "");
      var w = a[t].querySelector(".apexcharts-tooltip-text-y-value");
      w && (w.innerHTML = c !== void 0 ? c : ""), m[0] && m[0].classList.contains("apexcharts-tooltip-marker") && (h.config.tooltip.marker.fillColors && Array.isArray(h.config.tooltip.marker.fillColors) && (o = h.config.tooltip.marker.fillColors[t]), m[0].style.backgroundColor = o), h.config.tooltip.marker.show || (m[0].style.display = "none");
      var l = a[t].querySelector(".apexcharts-tooltip-text-goals-label"), u = a[t].querySelector(".apexcharts-tooltip-text-goals-value");
      if (g.length && h.globals.seriesGoals[t]) {
        var b = function() {
          var S = "<div >", C = "<div>";
          g.forEach(function(L, M) {
            S += ' <div style="display: flex"><span class="apexcharts-tooltip-marker" style="background-color: '.concat(L.attrs.strokeColor, '; height: 3px; border-radius: 0; top: 5px;"></span> ').concat(L.attrs.name, "</div>"), C += "<div>".concat(L.val, "</div>");
          }), l.innerHTML = S + "</div>", u.innerHTML = C + "</div>";
        };
        n ? h.globals.seriesGoals[t][i] && Array.isArray(h.globals.seriesGoals[t][i]) ? b() : (l.innerHTML = "", u.innerHTML = "") : b();
      } else
        l.innerHTML = "", u.innerHTML = "";
      if (f !== null && (a[t].querySelector(".apexcharts-tooltip-text-z-label").innerHTML = h.config.tooltip.z.title, a[t].querySelector(".apexcharts-tooltip-text-z-value").innerHTML = f !== void 0 ? f : ""), n && m[0]) {
        if (h.config.tooltip.hideEmptySeries) {
          var A = a[t].querySelector(".apexcharts-tooltip-marker"), k = a[t].querySelector(".apexcharts-tooltip-text");
          parseFloat(c) == 0 ? (A.style.display = "none", k.style.display = "none") : (A.style.display = "block", k.style.display = "block");
        }
        c == null || h.globals.ancillaryCollapsedSeriesIndices.indexOf(t) > -1 || h.globals.collapsedSeriesIndices.indexOf(t) > -1 || Array.isArray(d.tConfig.enabledOnSeries) && d.tConfig.enabledOnSeries.indexOf(t) === -1 ? m[0].parentNode.style.display = "none" : m[0].parentNode.style.display = h.config.tooltip.items.display;
      } else
        Array.isArray(d.tConfig.enabledOnSeries) && d.tConfig.enabledOnSeries.indexOf(t) === -1 && (m[0].parentNode.style.display = "none");
    } }, { key: "toggleActiveInactiveSeries", value: function(e, t) {
      var i = this.w;
      if (e)
        this.tooltipUtil.toggleAllTooltipSeriesGroups("enable");
      else {
        this.tooltipUtil.toggleAllTooltipSeriesGroups("disable");
        var a = i.globals.dom.baseEl.querySelector(".apexcharts-tooltip-series-group-".concat(t));
        a && (a.classList.add("apexcharts-active"), a.style.display = i.config.tooltip.items.display);
      }
    } }, { key: "getValuesToPrint", value: function(e) {
      var t = e.i, i = e.j, a = this.w, r = this.ctx.series.filteredSeriesX(), s = "", n = "", o = null, h = null, d = { series: a.globals.series, seriesIndex: t, dataPointIndex: i, w: a }, c = a.globals.ttZFormatter;
      i === null ? h = a.globals.series[t] : a.globals.isXNumeric && a.config.chart.type !== "treemap" ? (s = r[t][i], r[t].length === 0 && (s = r[this.tooltipUtil.getFirstActiveXArray(r)][i])) : s = new Re(this.ctx).isFormatXY() ? a.config.series[t].data[i] !== void 0 ? a.config.series[t].data[i].x : "" : a.globals.labels[i] !== void 0 ? a.globals.labels[i] : "";
      var g = s;
      return a.globals.isXNumeric && a.config.xaxis.type === "datetime" ? s = new me(this.ctx).xLabelFormat(a.globals.ttKeyFormatter, g, g, { i: void 0, dateFormatter: new K(this.ctx).formatDate, w: this.w }) : s = a.globals.isBarHorizontal ? a.globals.yLabelFormatters[0](g, d) : a.globals.xLabelFormatter(g, d), a.config.tooltip.x.formatter !== void 0 && (s = a.globals.ttKeyFormatter(g, d)), a.globals.seriesZ.length > 0 && a.globals.seriesZ[t].length > 0 && (o = c(a.globals.seriesZ[t][i], a)), n = typeof a.config.xaxis.tooltip.formatter == "function" ? a.globals.xaxisTooltipFormatter(g, d) : s, { val: Array.isArray(h) ? h.join(" ") : h, xVal: Array.isArray(s) ? s.join(" ") : s, xAxisTTVal: Array.isArray(n) ? n.join(" ") : n, zVal: o };
    } }, { key: "handleCustomTooltip", value: function(e) {
      var t = e.i, i = e.j, a = e.y1, r = e.y2, s = e.w, n = this.ttCtx.getElTooltip(), o = s.config.tooltip.custom;
      Array.isArray(o) && o[t] && (o = o[t]), n.innerHTML = o({ ctx: this.ctx, series: s.globals.series, seriesIndex: t, dataPointIndex: i, y1: a, y2: r, w: s });
    } }]), y;
  }(), rt = function() {
    function y(e) {
      R(this, y), this.ttCtx = e, this.ctx = e.ctx, this.w = e.w;
    }
    return F(y, [{ key: "moveXCrosshairs", value: function(e) {
      var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null, i = this.ttCtx, a = this.w, r = i.getElXCrosshairs(), s = e - i.xcrosshairsWidth / 2, n = a.globals.labels.slice().length;
      if (t !== null && (s = a.globals.gridWidth / n * t), r === null || a.globals.isBarHorizontal || (r.setAttribute("x", s), r.setAttribute("x1", s), r.setAttribute("x2", s), r.setAttribute("y2", a.globals.gridHeight), r.classList.add("apexcharts-active")), s < 0 && (s = 0), s > a.globals.gridWidth && (s = a.globals.gridWidth), i.isXAxisTooltipEnabled) {
        var o = s;
        a.config.xaxis.crosshairs.width !== "tickWidth" && a.config.xaxis.crosshairs.width !== "barWidth" || (o = s + i.xcrosshairsWidth / 2), this.moveXAxisTooltip(o);
      }
    } }, { key: "moveYCrosshairs", value: function(e) {
      var t = this.ttCtx;
      t.ycrosshairs !== null && X.setAttrs(t.ycrosshairs, { y1: e, y2: e }), t.ycrosshairsHidden !== null && X.setAttrs(t.ycrosshairsHidden, { y1: e, y2: e });
    } }, { key: "moveXAxisTooltip", value: function(e) {
      var t = this.w, i = this.ttCtx;
      if (i.xaxisTooltip !== null && i.xcrosshairsWidth !== 0) {
        i.xaxisTooltip.classList.add("apexcharts-active");
        var a = i.xaxisOffY + t.config.xaxis.tooltip.offsetY + t.globals.translateY + 1 + t.config.xaxis.offsetY;
        if (e -= i.xaxisTooltip.getBoundingClientRect().width / 2, !isNaN(e)) {
          e += t.globals.translateX;
          var r;
          r = new X(this.ctx).getTextRects(i.xaxisTooltipText.innerHTML), i.xaxisTooltipText.style.minWidth = r.width + "px", i.xaxisTooltip.style.left = e + "px", i.xaxisTooltip.style.top = a + "px";
        }
      }
    } }, { key: "moveYAxisTooltip", value: function(e) {
      var t = this.w, i = this.ttCtx;
      i.yaxisTTEls === null && (i.yaxisTTEls = t.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxistooltip"));
      var a = parseInt(i.ycrosshairsHidden.getAttribute("y1"), 10), r = t.globals.translateY + a, s = i.yaxisTTEls[e].getBoundingClientRect().height, n = t.globals.translateYAxisX[e] - 2;
      t.config.yaxis[e].opposite && (n -= 26), r -= s / 2, t.globals.ignoreYAxisIndexes.indexOf(e) === -1 ? (i.yaxisTTEls[e].classList.add("apexcharts-active"), i.yaxisTTEls[e].style.top = r + "px", i.yaxisTTEls[e].style.left = n + t.config.yaxis[e].tooltip.offsetX + "px") : i.yaxisTTEls[e].classList.remove("apexcharts-active");
    } }, { key: "moveTooltip", value: function(e, t) {
      var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null, a = this.w, r = this.ttCtx, s = r.getElTooltip(), n = r.tooltipRect, o = i !== null ? parseFloat(i) : 1, h = parseFloat(e) + o + 5, d = parseFloat(t) + o / 2;
      if (h > a.globals.gridWidth / 2 && (h = h - n.ttWidth - o - 10), h > a.globals.gridWidth - n.ttWidth - 10 && (h = a.globals.gridWidth - n.ttWidth), h < -20 && (h = -20), a.config.tooltip.followCursor) {
        var c = r.getElGrid().getBoundingClientRect();
        (h = r.e.clientX - c.left) > a.globals.gridWidth / 2 && (h -= r.tooltipRect.ttWidth), (d = r.e.clientY + a.globals.translateY - c.top) > a.globals.gridHeight / 2 && (d -= r.tooltipRect.ttHeight);
      } else
        a.globals.isBarHorizontal || n.ttHeight / 2 + d > a.globals.gridHeight && (d = a.globals.gridHeight - n.ttHeight + a.globals.translateY);
      isNaN(h) || (h += a.globals.translateX, s.style.left = h + "px", s.style.top = d + "px");
    } }, { key: "moveMarkers", value: function(e, t) {
      var i = this.w, a = this.ttCtx;
      if (i.globals.markers.size[e] > 0)
        for (var r = i.globals.dom.baseEl.querySelectorAll(" .apexcharts-series[data\\:realIndex='".concat(e, "'] .apexcharts-marker")), s = 0; s < r.length; s++)
          parseInt(r[s].getAttribute("rel"), 10) === t && (a.marker.resetPointsSize(), a.marker.enlargeCurrentPoint(t, r[s]));
      else
        a.marker.resetPointsSize(), this.moveDynamicPointOnHover(t, e);
    } }, { key: "moveDynamicPointOnHover", value: function(e, t) {
      var i, a, r, s, n = this.w, o = this.ttCtx, h = new X(this.ctx), d = n.globals.pointsArray, c = o.tooltipUtil.getHoverMarkerSize(t), g = n.config.series[t].type;
      if (!g || g !== "column" && g !== "candlestick" && g !== "boxPlot") {
        r = (i = d[t][e]) === null || i === void 0 ? void 0 : i[0], s = ((a = d[t][e]) === null || a === void 0 ? void 0 : a[1]) || 0;
        var p = n.globals.dom.baseEl.querySelector(".apexcharts-series[data\\:realIndex='".concat(t, "'] .apexcharts-series-markers path"));
        if (p && s < n.globals.gridHeight && s > 0) {
          var x = p.getAttribute("shape"), f = h.getMarkerPath(r, s, x, 1.5 * c);
          p.setAttribute("d", f);
        }
        this.moveXCrosshairs(r), o.fixedTooltip || this.moveTooltip(r, s, c);
      }
    } }, { key: "moveDynamicPointsOnHover", value: function(e) {
      var t, i = this.ttCtx, a = i.w, r = 0, s = 0, n = a.globals.pointsArray, o = new re(this.ctx), h = new X(this.ctx);
      t = o.getActiveConfigSeriesIndex("asc", ["line", "area", "scatter", "bubble"]);
      var d = i.tooltipUtil.getHoverMarkerSize(t);
      n[t] && (r = n[t][e][0], s = n[t][e][1]);
      var c = i.tooltipUtil.getAllMarkers();
      if (c !== null)
        for (var g = 0; g < a.globals.series.length; g++) {
          var p = n[g];
          if (a.globals.comboCharts && p === void 0 && c.splice(g, 0, null), p && p.length) {
            var x = n[g][e][1], f = void 0;
            c[g].setAttribute("cx", r);
            var m = c[g].getAttribute("shape");
            if (a.config.chart.type === "rangeArea" && !a.globals.comboCharts) {
              var v = e + a.globals.series[g].length;
              f = n[g][v][1], x -= Math.abs(x - f) / 2;
            }
            if (x !== null && !isNaN(x) && x < a.globals.gridHeight + d && x + d > 0) {
              var w = h.getMarkerPath(r, x, m, d);
              c[g].setAttribute("d", w);
            } else
              c[g].setAttribute("d", "");
          }
        }
      this.moveXCrosshairs(r), i.fixedTooltip || this.moveTooltip(r, s || a.globals.gridHeight, d);
    } }, { key: "moveStickyTooltipOverBars", value: function(e, t) {
      var i = this.w, a = this.ttCtx, r = i.globals.columnSeries ? i.globals.columnSeries.length : i.globals.series.length, s = r >= 2 && r % 2 == 0 ? Math.floor(r / 2) : Math.floor(r / 2) + 1;
      i.globals.isBarHorizontal && (s = new re(this.ctx).getActiveConfigSeriesIndex("desc") + 1);
      var n = i.globals.dom.baseEl.querySelector(".apexcharts-bar-series .apexcharts-series[rel='".concat(s, "'] path[j='").concat(e, "'], .apexcharts-candlestick-series .apexcharts-series[rel='").concat(s, "'] path[j='").concat(e, "'], .apexcharts-boxPlot-series .apexcharts-series[rel='").concat(s, "'] path[j='").concat(e, "'], .apexcharts-rangebar-series .apexcharts-series[rel='").concat(s, "'] path[j='").concat(e, "']"));
      n || typeof t != "number" || (n = i.globals.dom.baseEl.querySelector(".apexcharts-bar-series .apexcharts-series[data\\:realIndex='".concat(t, "'] path[j='").concat(e, `'],
        .apexcharts-candlestick-series .apexcharts-series[data\\:realIndex='`).concat(t, "'] path[j='").concat(e, `'],
        .apexcharts-boxPlot-series .apexcharts-series[data\\:realIndex='`).concat(t, "'] path[j='").concat(e, `'],
        .apexcharts-rangebar-series .apexcharts-series[data\\:realIndex='`).concat(t, "'] path[j='").concat(e, "']")));
      var o = n ? parseFloat(n.getAttribute("cx")) : 0, h = n ? parseFloat(n.getAttribute("cy")) : 0, d = n ? parseFloat(n.getAttribute("barWidth")) : 0, c = a.getElGrid().getBoundingClientRect(), g = n && (n.classList.contains("apexcharts-candlestick-area") || n.classList.contains("apexcharts-boxPlot-area"));
      i.globals.isXNumeric ? (n && !g && (o -= r % 2 != 0 ? d / 2 : 0), n && g && i.globals.comboCharts && (o -= d / 2)) : i.globals.isBarHorizontal || (o = a.xAxisTicksPositions[e - 1] + a.dataPointsDividedWidth / 2, isNaN(o) && (o = a.xAxisTicksPositions[e] - a.dataPointsDividedWidth / 2)), i.globals.isBarHorizontal ? h -= a.tooltipRect.ttHeight : i.config.tooltip.followCursor ? h = a.e.clientY - c.top - a.tooltipRect.ttHeight / 2 : h + a.tooltipRect.ttHeight + 15 > i.globals.gridHeight && (h = i.globals.gridHeight), i.globals.isBarHorizontal || this.moveXCrosshairs(o), a.fixedTooltip || this.moveTooltip(o, h || i.globals.gridHeight);
    } }]), y;
  }(), Et = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.ttCtx = e, this.ctx = e.ctx, this.tooltipPosition = new rt(e);
    }
    return F(y, [{ key: "drawDynamicPoints", value: function() {
      var e = this.w, t = new X(this.ctx), i = new ue(this.ctx), a = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series");
      a = J(a), e.config.chart.stacked && a.sort(function(c, g) {
        return parseFloat(c.getAttribute("data:realIndex")) - parseFloat(g.getAttribute("data:realIndex"));
      });
      for (var r = 0; r < a.length; r++) {
        var s = a[r].querySelector(".apexcharts-series-markers-wrap");
        if (s !== null) {
          var n = void 0, o = "apexcharts-marker w".concat((Math.random() + 1).toString(36).substring(4));
          e.config.chart.type !== "line" && e.config.chart.type !== "area" || e.globals.comboCharts || e.config.tooltip.intersect || (o += " no-pointer-events");
          var h = i.getMarkerConfig({ cssClass: o, seriesIndex: Number(s.getAttribute("data:realIndex")) });
          (n = t.drawMarker(0, 0, h)).node.setAttribute("default-marker-size", 0);
          var d = document.createElementNS(e.globals.SVGNS, "g");
          d.classList.add("apexcharts-series-markers"), d.appendChild(n.node), s.appendChild(d);
        }
      }
    } }, { key: "enlargeCurrentPoint", value: function(e, t) {
      var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : null, r = this.w;
      r.config.chart.type !== "bubble" && this.newPointSize(e, t);
      var s = t.getAttribute("cx"), n = t.getAttribute("cy");
      if (i !== null && a !== null && (s = i, n = a), this.tooltipPosition.moveXCrosshairs(s), !this.fixedTooltip) {
        if (r.config.chart.type === "radar") {
          var o = this.ttCtx.getElGrid().getBoundingClientRect();
          s = this.ttCtx.e.clientX - o.left;
        }
        this.tooltipPosition.moveTooltip(s, n, r.config.markers.hover.size);
      }
    } }, { key: "enlargePoints", value: function(e) {
      for (var t = this.w, i = this, a = this.ttCtx, r = e, s = t.globals.dom.baseEl.querySelectorAll(".apexcharts-series:not(.apexcharts-series-collapsed) .apexcharts-marker"), n = t.config.markers.hover.size, o = 0; o < s.length; o++) {
        var h = s[o].getAttribute("rel"), d = s[o].getAttribute("index");
        if (n === void 0 && (n = t.globals.markers.size[d] + t.config.markers.hover.sizeOffset), r === parseInt(h, 10)) {
          i.newPointSize(r, s[o]);
          var c = s[o].getAttribute("cx"), g = s[o].getAttribute("cy");
          i.tooltipPosition.moveXCrosshairs(c), a.fixedTooltip || i.tooltipPosition.moveTooltip(c, g, n);
        } else
          i.oldPointSize(s[o]);
      }
    } }, { key: "newPointSize", value: function(e, t) {
      var i = this.w, a = i.config.markers.hover.size, r = e === 0 ? t.parentNode.firstChild : t.parentNode.lastChild;
      if (r.getAttribute("default-marker-size") !== "0") {
        var s = parseInt(r.getAttribute("index"), 10);
        a === void 0 && (a = i.globals.markers.size[s] + i.config.markers.hover.sizeOffset), a < 0 && (a = 0);
        var n = this.ttCtx.tooltipUtil.getPathFromPoint(t, a);
        t.setAttribute("d", n);
      }
    } }, { key: "oldPointSize", value: function(e) {
      var t = parseFloat(e.getAttribute("default-marker-size")), i = this.ttCtx.tooltipUtil.getPathFromPoint(e, t);
      e.setAttribute("d", i);
    } }, { key: "resetPointsSize", value: function() {
      for (var e = this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series:not(.apexcharts-series-collapsed) .apexcharts-marker"), t = 0; t < e.length; t++) {
        var i = parseFloat(e[t].getAttribute("default-marker-size"));
        if (P.isNumber(i) && i >= 0) {
          var a = this.ttCtx.tooltipUtil.getPathFromPoint(e[t], i);
          e[t].setAttribute("d", a);
        } else
          e[t].setAttribute("d", "M0,0");
      }
    } }]), y;
  }(), Yt = function() {
    function y(e) {
      R(this, y), this.w = e.w;
      var t = this.w;
      this.ttCtx = e, this.isVerticalGroupedRangeBar = !t.globals.isBarHorizontal && t.config.chart.type === "rangeBar" && t.config.plotOptions.bar.rangeBarGroupRows;
    }
    return F(y, [{ key: "getAttr", value: function(e, t) {
      return parseFloat(e.target.getAttribute(t));
    } }, { key: "handleHeatTreeTooltip", value: function(e) {
      var t = e.e, i = e.opt, a = e.x, r = e.y, s = e.type, n = this.ttCtx, o = this.w;
      if (t.target.classList.contains("apexcharts-".concat(s, "-rect"))) {
        var h = this.getAttr(t, "i"), d = this.getAttr(t, "j"), c = this.getAttr(t, "cx"), g = this.getAttr(t, "cy"), p = this.getAttr(t, "width"), x = this.getAttr(t, "height");
        if (n.tooltipLabels.drawSeriesTexts({ ttItems: i.ttItems, i: h, j: d, shared: !1, e: t }), o.globals.capturedSeriesIndex = h, o.globals.capturedDataPointIndex = d, a = c + n.tooltipRect.ttWidth / 2 + p, r = g + n.tooltipRect.ttHeight / 2 - x / 2, n.tooltipPosition.moveXCrosshairs(c + p / 2), a > o.globals.gridWidth / 2 && (a = c - n.tooltipRect.ttWidth / 2 + p), n.w.config.tooltip.followCursor) {
          var f = o.globals.dom.elWrap.getBoundingClientRect();
          a = o.globals.clientX - f.left - (a > o.globals.gridWidth / 2 ? n.tooltipRect.ttWidth : 0), r = o.globals.clientY - f.top - (r > o.globals.gridHeight / 2 ? n.tooltipRect.ttHeight : 0);
        }
      }
      return { x: a, y: r };
    } }, { key: "handleMarkerTooltip", value: function(e) {
      var t, i, a = e.e, r = e.opt, s = e.x, n = e.y, o = this.w, h = this.ttCtx;
      if (a.target.classList.contains("apexcharts-marker")) {
        var d = parseInt(r.paths.getAttribute("cx"), 10), c = parseInt(r.paths.getAttribute("cy"), 10), g = parseFloat(r.paths.getAttribute("val"));
        if (i = parseInt(r.paths.getAttribute("rel"), 10), t = parseInt(r.paths.parentNode.parentNode.parentNode.getAttribute("rel"), 10) - 1, h.intersect) {
          var p = P.findAncestor(r.paths, "apexcharts-series");
          p && (t = parseInt(p.getAttribute("data:realIndex"), 10));
        }
        if (h.tooltipLabels.drawSeriesTexts({ ttItems: r.ttItems, i: t, j: i, shared: !h.showOnIntersect && o.config.tooltip.shared, e: a }), a.type === "mouseup" && h.markerClick(a, t, i), o.globals.capturedSeriesIndex = t, o.globals.capturedDataPointIndex = i, s = d, n = c + o.globals.translateY - 1.4 * h.tooltipRect.ttHeight, h.w.config.tooltip.followCursor) {
          var x = h.getElGrid().getBoundingClientRect();
          n = h.e.clientY + o.globals.translateY - x.top;
        }
        g < 0 && (n = c), h.marker.enlargeCurrentPoint(i, r.paths, s, n);
      }
      return { x: s, y: n };
    } }, { key: "handleBarTooltip", value: function(e) {
      var t, i, a = e.e, r = e.opt, s = this.w, n = this.ttCtx, o = n.getElTooltip(), h = 0, d = 0, c = 0, g = this.getBarTooltipXY({ e: a, opt: r });
      t = g.i;
      var p = g.j;
      s.globals.capturedSeriesIndex = t, s.globals.capturedDataPointIndex = p, s.globals.isBarHorizontal && n.tooltipUtil.hasBars() || !s.config.tooltip.shared ? (d = g.x, c = g.y, i = Array.isArray(s.config.stroke.width) ? s.config.stroke.width[t] : s.config.stroke.width, h = d) : s.globals.comboCharts || s.config.tooltip.shared || (h /= 2), isNaN(c) && (c = s.globals.svgHeight - n.tooltipRect.ttHeight);
      var x = parseInt(r.paths.parentNode.getAttribute("data:realIndex"), 10);
      if (s.globals.isMultipleYAxis ? s.config.yaxis[x] && s.config.yaxis[x].reversed : s.config.yaxis[0].reversed, d + n.tooltipRect.ttWidth > s.globals.gridWidth ? d -= n.tooltipRect.ttWidth : d < 0 && (d = 0), n.w.config.tooltip.followCursor) {
        var f = n.getElGrid().getBoundingClientRect();
        c = n.e.clientY - f.top;
      }
      n.tooltip === null && (n.tooltip = s.globals.dom.baseEl.querySelector(".apexcharts-tooltip")), s.config.tooltip.shared || (s.globals.comboBarCount > 0 ? n.tooltipPosition.moveXCrosshairs(h + i / 2) : n.tooltipPosition.moveXCrosshairs(h)), !n.fixedTooltip && (!s.config.tooltip.shared || s.globals.isBarHorizontal && n.tooltipUtil.hasBars()) && (c = c + s.globals.translateY - n.tooltipRect.ttHeight / 2, o.style.left = d + s.globals.translateX + "px", o.style.top = c + "px");
    } }, { key: "getBarTooltipXY", value: function(e) {
      var t = this, i = e.e, a = e.opt, r = this.w, s = null, n = this.ttCtx, o = 0, h = 0, d = 0, c = 0, g = 0, p = i.target.classList;
      if (p.contains("apexcharts-bar-area") || p.contains("apexcharts-candlestick-area") || p.contains("apexcharts-boxPlot-area") || p.contains("apexcharts-rangebar-area")) {
        var x = i.target, f = x.getBoundingClientRect(), m = a.elGrid.getBoundingClientRect(), v = f.height;
        g = f.height;
        var w = f.width, l = parseInt(x.getAttribute("cx"), 10), u = parseInt(x.getAttribute("cy"), 10);
        c = parseFloat(x.getAttribute("barWidth"));
        var b = i.type === "touchmove" ? i.touches[0].clientX : i.clientX;
        s = parseInt(x.getAttribute("j"), 10), o = parseInt(x.parentNode.getAttribute("rel"), 10) - 1;
        var A = x.getAttribute("data-range-y1"), k = x.getAttribute("data-range-y2");
        r.globals.comboCharts && (o = parseInt(x.parentNode.getAttribute("data:realIndex"), 10));
        var S = function(L) {
          return r.globals.isXNumeric ? l - w / 2 : t.isVerticalGroupedRangeBar ? l + w / 2 : l - n.dataPointsDividedWidth + w / 2;
        }, C = function() {
          return u - n.dataPointsDividedHeight + v / 2 - n.tooltipRect.ttHeight / 2;
        };
        n.tooltipLabels.drawSeriesTexts({ ttItems: a.ttItems, i: o, j: s, y1: A ? parseInt(A, 10) : null, y2: k ? parseInt(k, 10) : null, shared: !n.showOnIntersect && r.config.tooltip.shared, e: i }), r.config.tooltip.followCursor ? r.globals.isBarHorizontal ? (h = b - m.left + 15, d = C()) : (h = S(), d = i.clientY - m.top - n.tooltipRect.ttHeight / 2 - 15) : r.globals.isBarHorizontal ? ((h = l) < n.xyRatios.baseLineInvertedY && (h = l - n.tooltipRect.ttWidth), d = C()) : (h = S(), d = u);
      }
      return { x: h, y: d, barHeight: g, barWidth: c, i: o, j: s };
    } }]), y;
  }(), Rt = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.ttCtx = e;
    }
    return F(y, [{ key: "drawXaxisTooltip", value: function() {
      var e = this.w, t = this.ttCtx, i = e.config.xaxis.position === "bottom";
      t.xaxisOffY = i ? e.globals.gridHeight + 1 : -e.globals.xAxisHeight - e.config.xaxis.axisTicks.height + 3;
      var a = i ? "apexcharts-xaxistooltip apexcharts-xaxistooltip-bottom" : "apexcharts-xaxistooltip apexcharts-xaxistooltip-top", r = e.globals.dom.elWrap;
      t.isXAxisTooltipEnabled && e.globals.dom.baseEl.querySelector(".apexcharts-xaxistooltip") === null && (t.xaxisTooltip = document.createElement("div"), t.xaxisTooltip.setAttribute("class", a + " apexcharts-theme-" + e.config.tooltip.theme), r.appendChild(t.xaxisTooltip), t.xaxisTooltipText = document.createElement("div"), t.xaxisTooltipText.classList.add("apexcharts-xaxistooltip-text"), t.xaxisTooltipText.style.fontFamily = e.config.xaxis.tooltip.style.fontFamily || e.config.chart.fontFamily, t.xaxisTooltipText.style.fontSize = e.config.xaxis.tooltip.style.fontSize, t.xaxisTooltip.appendChild(t.xaxisTooltipText));
    } }, { key: "drawYaxisTooltip", value: function() {
      for (var e = this.w, t = this.ttCtx, i = 0; i < e.config.yaxis.length; i++) {
        var a = e.config.yaxis[i].opposite || e.config.yaxis[i].crosshairs.opposite;
        t.yaxisOffX = a ? e.globals.gridWidth + 1 : 1;
        var r = "apexcharts-yaxistooltip apexcharts-yaxistooltip-".concat(i, a ? " apexcharts-yaxistooltip-right" : " apexcharts-yaxistooltip-left"), s = e.globals.dom.elWrap;
        e.globals.dom.baseEl.querySelector(".apexcharts-yaxistooltip apexcharts-yaxistooltip-".concat(i)) === null && (t.yaxisTooltip = document.createElement("div"), t.yaxisTooltip.setAttribute("class", r + " apexcharts-theme-" + e.config.tooltip.theme), s.appendChild(t.yaxisTooltip), i === 0 && (t.yaxisTooltipText = []), t.yaxisTooltipText[i] = document.createElement("div"), t.yaxisTooltipText[i].classList.add("apexcharts-yaxistooltip-text"), t.yaxisTooltip.appendChild(t.yaxisTooltipText[i]));
      }
    } }, { key: "setXCrosshairWidth", value: function() {
      var e = this.w, t = this.ttCtx, i = t.getElXCrosshairs();
      if (t.xcrosshairsWidth = parseInt(e.config.xaxis.crosshairs.width, 10), e.globals.comboCharts) {
        var a = e.globals.dom.baseEl.querySelector(".apexcharts-bar-area");
        if (a !== null && e.config.xaxis.crosshairs.width === "barWidth") {
          var r = parseFloat(a.getAttribute("barWidth"));
          t.xcrosshairsWidth = r;
        } else if (e.config.xaxis.crosshairs.width === "tickWidth") {
          var s = e.globals.labels.length;
          t.xcrosshairsWidth = e.globals.gridWidth / s;
        }
      } else if (e.config.xaxis.crosshairs.width === "tickWidth") {
        var n = e.globals.labels.length;
        t.xcrosshairsWidth = e.globals.gridWidth / n;
      } else if (e.config.xaxis.crosshairs.width === "barWidth") {
        var o = e.globals.dom.baseEl.querySelector(".apexcharts-bar-area");
        if (o !== null) {
          var h = parseFloat(o.getAttribute("barWidth"));
          t.xcrosshairsWidth = h;
        } else
          t.xcrosshairsWidth = 1;
      }
      e.globals.isBarHorizontal && (t.xcrosshairsWidth = 0), i !== null && t.xcrosshairsWidth > 0 && i.setAttribute("width", t.xcrosshairsWidth);
    } }, { key: "handleYCrosshair", value: function() {
      var e = this.w, t = this.ttCtx;
      t.ycrosshairs = e.globals.dom.baseEl.querySelector(".apexcharts-ycrosshairs"), t.ycrosshairsHidden = e.globals.dom.baseEl.querySelector(".apexcharts-ycrosshairs-hidden");
    } }, { key: "drawYaxisTooltipText", value: function(e, t, i) {
      var a = this.ttCtx, r = this.w, s = r.globals, n = s.seriesYAxisMap[e];
      if (a.yaxisTooltips[e] && n.length > 0) {
        var o = s.yLabelFormatters[e], h = a.getElGrid().getBoundingClientRect(), d = n[0], c = 0;
        i.yRatio.length > 1 && (c = d);
        var g = (t - h.top) * i.yRatio[c], p = s.maxYArr[d] - s.minYArr[d], x = s.minYArr[d] + (p - g);
        r.config.yaxis[e].reversed && (x = s.maxYArr[d] - (p - g)), a.tooltipPosition.moveYCrosshairs(t - h.top), a.yaxisTooltipText[e].innerHTML = o(x), a.tooltipPosition.moveYAxisTooltip(e);
      }
    } }]), y;
  }(), nt = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
      var t = this.w;
      this.tConfig = t.config.tooltip, this.tooltipUtil = new st(this), this.tooltipLabels = new Xt(this), this.tooltipPosition = new rt(this), this.marker = new Et(this), this.intersect = new Yt(this), this.axesTooltip = new Rt(this), this.showOnIntersect = this.tConfig.intersect, this.showTooltipTitle = this.tConfig.x.show, this.fixedTooltip = this.tConfig.fixed.enabled, this.xaxisTooltip = null, this.yaxisTTEls = null, this.isBarShared = !t.globals.isBarHorizontal && this.tConfig.shared, this.lastHoverTime = Date.now();
    }
    return F(y, [{ key: "getElTooltip", value: function(e) {
      return e || (e = this), e.w.globals.dom.baseEl ? e.w.globals.dom.baseEl.querySelector(".apexcharts-tooltip") : null;
    } }, { key: "getElXCrosshairs", value: function() {
      return this.w.globals.dom.baseEl.querySelector(".apexcharts-xcrosshairs");
    } }, { key: "getElGrid", value: function() {
      return this.w.globals.dom.baseEl.querySelector(".apexcharts-grid");
    } }, { key: "drawTooltip", value: function(e) {
      var t = this.w;
      this.xyRatios = e, this.isXAxisTooltipEnabled = t.config.xaxis.tooltip.enabled && t.globals.axisCharts, this.yaxisTooltips = t.config.yaxis.map(function(s, n) {
        return !!(s.show && s.tooltip.enabled && t.globals.axisCharts);
      }), this.allTooltipSeriesGroups = [], t.globals.axisCharts || (this.showTooltipTitle = !1);
      var i = document.createElement("div");
      if (i.classList.add("apexcharts-tooltip"), t.config.tooltip.cssClass && i.classList.add(t.config.tooltip.cssClass), i.classList.add("apexcharts-theme-".concat(this.tConfig.theme)), t.globals.dom.elWrap.appendChild(i), t.globals.axisCharts) {
        this.axesTooltip.drawXaxisTooltip(), this.axesTooltip.drawYaxisTooltip(), this.axesTooltip.setXCrosshairWidth(), this.axesTooltip.handleYCrosshair();
        var a = new we(this.ctx);
        this.xAxisTicksPositions = a.getXAxisTicksPositions();
      }
      if (!t.globals.comboCharts && !this.tConfig.intersect && t.config.chart.type !== "rangeBar" || this.tConfig.shared || (this.showOnIntersect = !0), t.config.markers.size !== 0 && t.globals.markers.largestSize !== 0 || this.marker.drawDynamicPoints(this), t.globals.collapsedSeries.length !== t.globals.series.length) {
        this.dataPointsDividedHeight = t.globals.gridHeight / t.globals.dataPoints, this.dataPointsDividedWidth = t.globals.gridWidth / t.globals.dataPoints, this.showTooltipTitle && (this.tooltipTitle = document.createElement("div"), this.tooltipTitle.classList.add("apexcharts-tooltip-title"), this.tooltipTitle.style.fontFamily = this.tConfig.style.fontFamily || t.config.chart.fontFamily, this.tooltipTitle.style.fontSize = this.tConfig.style.fontSize, i.appendChild(this.tooltipTitle));
        var r = t.globals.series.length;
        (t.globals.xyCharts || t.globals.comboCharts) && this.tConfig.shared && (r = this.showOnIntersect ? 1 : t.globals.series.length), this.legendLabels = t.globals.dom.baseEl.querySelectorAll(".apexcharts-legend-text"), this.ttItems = this.createTTElements(r), this.addSVGEvents();
      }
    } }, { key: "createTTElements", value: function(e) {
      for (var t = this, i = this.w, a = [], r = this.getElTooltip(), s = function(o) {
        var h = document.createElement("div");
        h.classList.add("apexcharts-tooltip-series-group", "apexcharts-tooltip-series-group-".concat(o)), h.style.order = i.config.tooltip.inverseOrder ? e - o : o + 1;
        var d = document.createElement("span");
        d.classList.add("apexcharts-tooltip-marker"), d.style.backgroundColor = i.globals.colors[o], h.appendChild(d);
        var c = document.createElement("div");
        c.classList.add("apexcharts-tooltip-text"), c.style.fontFamily = t.tConfig.style.fontFamily || i.config.chart.fontFamily, c.style.fontSize = t.tConfig.style.fontSize, ["y", "goals", "z"].forEach(function(g) {
          var p = document.createElement("div");
          p.classList.add("apexcharts-tooltip-".concat(g, "-group"));
          var x = document.createElement("span");
          x.classList.add("apexcharts-tooltip-text-".concat(g, "-label")), p.appendChild(x);
          var f = document.createElement("span");
          f.classList.add("apexcharts-tooltip-text-".concat(g, "-value")), p.appendChild(f), c.appendChild(p);
        }), h.appendChild(c), r.appendChild(h), a.push(h);
      }, n = 0; n < e; n++)
        s(n);
      return a;
    } }, { key: "addSVGEvents", value: function() {
      var e = this.w, t = e.config.chart.type, i = this.getElTooltip(), a = !(t !== "bar" && t !== "candlestick" && t !== "boxPlot" && t !== "rangeBar"), r = t === "area" || t === "line" || t === "scatter" || t === "bubble" || t === "radar", s = e.globals.dom.Paper.node, n = this.getElGrid();
      n && (this.seriesBound = n.getBoundingClientRect());
      var o, h = [], d = [], c = { hoverArea: s, elGrid: n, tooltipEl: i, tooltipY: h, tooltipX: d, ttItems: this.ttItems };
      if (e.globals.axisCharts && (r ? o = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series[data\\:longestSeries='true'] .apexcharts-marker") : a ? o = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series .apexcharts-bar-area, .apexcharts-series .apexcharts-candlestick-area, .apexcharts-series .apexcharts-boxPlot-area, .apexcharts-series .apexcharts-rangebar-area") : t !== "heatmap" && t !== "treemap" || (o = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series .apexcharts-heatmap, .apexcharts-series .apexcharts-treemap")), o && o.length))
        for (var g = 0; g < o.length; g++)
          h.push(o[g].getAttribute("cy")), d.push(o[g].getAttribute("cx"));
      if (e.globals.xyCharts && !this.showOnIntersect || e.globals.comboCharts && !this.showOnIntersect || a && this.tooltipUtil.hasBars() && this.tConfig.shared)
        this.addPathsEventListeners([s], c);
      else if (a && !e.globals.comboCharts || r && this.showOnIntersect)
        this.addDatapointEventsListeners(c);
      else if (!e.globals.axisCharts || t === "heatmap" || t === "treemap") {
        var p = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series");
        this.addPathsEventListeners(p, c);
      }
      if (this.showOnIntersect) {
        var x = e.globals.dom.baseEl.querySelectorAll(".apexcharts-line-series .apexcharts-marker, .apexcharts-area-series .apexcharts-marker");
        x.length > 0 && this.addPathsEventListeners(x, c), this.tooltipUtil.hasBars() && !this.tConfig.shared && this.addDatapointEventsListeners(c);
      }
    } }, { key: "drawFixedTooltipRect", value: function() {
      var e = this.w, t = this.getElTooltip(), i = t.getBoundingClientRect(), a = i.width + 10, r = i.height + 10, s = this.tConfig.fixed.offsetX, n = this.tConfig.fixed.offsetY, o = this.tConfig.fixed.position.toLowerCase();
      return o.indexOf("right") > -1 && (s = s + e.globals.svgWidth - a + 10), o.indexOf("bottom") > -1 && (n = n + e.globals.svgHeight - r - 10), t.style.left = s + "px", t.style.top = n + "px", { x: s, y: n, ttWidth: a, ttHeight: r };
    } }, { key: "addDatapointEventsListeners", value: function(e) {
      var t = this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series-markers .apexcharts-marker, .apexcharts-bar-area, .apexcharts-candlestick-area, .apexcharts-boxPlot-area, .apexcharts-rangebar-area");
      this.addPathsEventListeners(t, e);
    } }, { key: "addPathsEventListeners", value: function(e, t) {
      for (var i = this, a = function(s) {
        var n = { paths: e[s], tooltipEl: t.tooltipEl, tooltipY: t.tooltipY, tooltipX: t.tooltipX, elGrid: t.elGrid, hoverArea: t.hoverArea, ttItems: t.ttItems };
        ["mousemove", "mouseup", "touchmove", "mouseout", "touchend"].map(function(o) {
          return e[s].addEventListener(o, i.onSeriesHover.bind(i, n), { capture: !1, passive: !0 });
        });
      }, r = 0; r < e.length; r++)
        a(r);
    } }, { key: "onSeriesHover", value: function(e, t) {
      var i = this, a = Date.now() - this.lastHoverTime;
      a >= 100 ? this.seriesHover(e, t) : (clearTimeout(this.seriesHoverTimeout), this.seriesHoverTimeout = setTimeout(function() {
        i.seriesHover(e, t);
      }, 100 - a));
    } }, { key: "seriesHover", value: function(e, t) {
      var i = this;
      this.lastHoverTime = Date.now();
      var a = [], r = this.w;
      r.config.chart.group && (a = this.ctx.getGroupedCharts()), r.globals.axisCharts && (r.globals.minX === -1 / 0 && r.globals.maxX === 1 / 0 || r.globals.dataPoints === 0) || (a.length ? a.forEach(function(s) {
        var n = i.getElTooltip(s), o = { paths: e.paths, tooltipEl: n, tooltipY: e.tooltipY, tooltipX: e.tooltipX, elGrid: e.elGrid, hoverArea: e.hoverArea, ttItems: s.w.globals.tooltip.ttItems };
        s.w.globals.minX === i.w.globals.minX && s.w.globals.maxX === i.w.globals.maxX && s.w.globals.tooltip.seriesHoverByContext({ chartCtx: s, ttCtx: s.w.globals.tooltip, opt: o, e: t });
      }) : this.seriesHoverByContext({ chartCtx: this.ctx, ttCtx: this.w.globals.tooltip, opt: e, e: t }));
    } }, { key: "seriesHoverByContext", value: function(e) {
      var t = e.chartCtx, i = e.ttCtx, a = e.opt, r = e.e, s = t.w, n = this.getElTooltip(t);
      n && (i.tooltipRect = { x: 0, y: 0, ttWidth: n.getBoundingClientRect().width, ttHeight: n.getBoundingClientRect().height }, i.e = r, i.tooltipUtil.hasBars() && !s.globals.comboCharts && !i.isBarShared && this.tConfig.onDatasetHover.highlightDataSeries && new re(t).toggleSeriesOnHover(r, r.target.parentNode), i.fixedTooltip && i.drawFixedTooltipRect(), s.globals.axisCharts ? i.axisChartsTooltips({ e: r, opt: a, tooltipRect: i.tooltipRect }) : i.nonAxisChartsTooltips({ e: r, opt: a, tooltipRect: i.tooltipRect }));
    } }, { key: "axisChartsTooltips", value: function(e) {
      var t, i, a = e.e, r = e.opt, s = this.w, n = r.elGrid.getBoundingClientRect(), o = a.type === "touchmove" ? a.touches[0].clientX : a.clientX, h = a.type === "touchmove" ? a.touches[0].clientY : a.clientY;
      if (this.clientY = h, this.clientX = o, s.globals.capturedSeriesIndex = -1, s.globals.capturedDataPointIndex = -1, h < n.top || h > n.top + n.height)
        this.handleMouseOut(r);
      else {
        if (Array.isArray(this.tConfig.enabledOnSeries) && !s.config.tooltip.shared) {
          var d = parseInt(r.paths.getAttribute("index"), 10);
          if (this.tConfig.enabledOnSeries.indexOf(d) < 0)
            return void this.handleMouseOut(r);
        }
        var c = this.getElTooltip(), g = this.getElXCrosshairs(), p = [];
        s.config.chart.group && (p = this.ctx.getSyncedCharts());
        var x = s.globals.xyCharts || s.config.chart.type === "bar" && !s.globals.isBarHorizontal && this.tooltipUtil.hasBars() && this.tConfig.shared || s.globals.comboCharts && this.tooltipUtil.hasBars();
        if (a.type === "mousemove" || a.type === "touchmove" || a.type === "mouseup") {
          if (s.globals.collapsedSeries.length + s.globals.ancillaryCollapsedSeries.length === s.globals.series.length)
            return;
          g !== null && g.classList.add("apexcharts-active");
          var f = this.yaxisTooltips.filter(function(w) {
            return w === !0;
          });
          if (this.ycrosshairs !== null && f.length && this.ycrosshairs.classList.add("apexcharts-active"), x && !this.showOnIntersect || p.length > 1)
            this.handleStickyTooltip(a, o, h, r);
          else if (s.config.chart.type === "heatmap" || s.config.chart.type === "treemap") {
            var m = this.intersect.handleHeatTreeTooltip({ e: a, opt: r, x: t, y: i, type: s.config.chart.type });
            t = m.x, i = m.y, c.style.left = t + "px", c.style.top = i + "px";
          } else
            this.tooltipUtil.hasBars() && this.intersect.handleBarTooltip({ e: a, opt: r }), this.tooltipUtil.hasMarkers() && this.intersect.handleMarkerTooltip({ e: a, opt: r, x: t, y: i });
          if (this.yaxisTooltips.length)
            for (var v = 0; v < s.config.yaxis.length; v++)
              this.axesTooltip.drawYaxisTooltipText(v, h, this.xyRatios);
          s.globals.dom.baseEl.classList.add("apexcharts-tooltip-active"), r.tooltipEl.classList.add("apexcharts-active");
        } else
          a.type !== "mouseout" && a.type !== "touchend" || this.handleMouseOut(r);
      }
    } }, { key: "nonAxisChartsTooltips", value: function(e) {
      var t = e.e, i = e.opt, a = e.tooltipRect, r = this.w, s = i.paths.getAttribute("rel"), n = this.getElTooltip(), o = r.globals.dom.elWrap.getBoundingClientRect();
      if (t.type === "mousemove" || t.type === "touchmove") {
        r.globals.dom.baseEl.classList.add("apexcharts-tooltip-active"), n.classList.add("apexcharts-active"), this.tooltipLabels.drawSeriesTexts({ ttItems: i.ttItems, i: parseInt(s, 10) - 1, shared: !1 });
        var h = r.globals.clientX - o.left - a.ttWidth / 2, d = r.globals.clientY - o.top - a.ttHeight - 10;
        if (n.style.left = h + "px", n.style.top = d + "px", r.config.legend.tooltipHoverFormatter) {
          var c = s - 1, g = (0, r.config.legend.tooltipHoverFormatter)(this.legendLabels[c].getAttribute("data:default-text"), { seriesIndex: c, dataPointIndex: c, w: r });
          this.legendLabels[c].innerHTML = g;
        }
      } else
        t.type !== "mouseout" && t.type !== "touchend" || (n.classList.remove("apexcharts-active"), r.globals.dom.baseEl.classList.remove("apexcharts-tooltip-active"), r.config.legend.tooltipHoverFormatter && this.legendLabels.forEach(function(p) {
          var x = p.getAttribute("data:default-text");
          p.innerHTML = decodeURIComponent(x);
        }));
    } }, { key: "handleStickyTooltip", value: function(e, t, i, a) {
      var r = this.w, s = this.tooltipUtil.getNearestValues({ context: this, hoverArea: a.hoverArea, elGrid: a.elGrid, clientX: t, clientY: i }), n = s.j, o = s.capturedSeries;
      r.globals.collapsedSeriesIndices.includes(o) && (o = null);
      var h = a.elGrid.getBoundingClientRect();
      if (s.hoverX < 0 || s.hoverX > h.width)
        this.handleMouseOut(a);
      else if (o !== null)
        this.handleStickyCapturedSeries(e, o, a, n);
      else if (this.tooltipUtil.isXoverlap(n) || r.globals.isBarHorizontal) {
        var d = r.globals.series.findIndex(function(c, g) {
          return !r.globals.collapsedSeriesIndices.includes(g);
        });
        this.create(e, this, d, n, a.ttItems);
      }
    } }, { key: "handleStickyCapturedSeries", value: function(e, t, i, a) {
      var r = this.w;
      if (!this.tConfig.shared && r.globals.series[t][a] === null)
        return void this.handleMouseOut(i);
      if (r.globals.series[t][a] !== void 0)
        this.tConfig.shared && this.tooltipUtil.isXoverlap(a) && this.tooltipUtil.isInitialSeriesSameLen() ? this.create(e, this, t, a, i.ttItems) : this.create(e, this, t, a, i.ttItems, !1);
      else if (this.tooltipUtil.isXoverlap(a)) {
        var s = r.globals.series.findIndex(function(n, o) {
          return !r.globals.collapsedSeriesIndices.includes(o);
        });
        this.create(e, this, s, a, i.ttItems);
      }
    } }, { key: "deactivateHoverFilter", value: function() {
      for (var e = this.w, t = new X(this.ctx), i = e.globals.dom.Paper.select(".apexcharts-bar-area"), a = 0; a < i.length; a++)
        t.pathMouseLeave(i[a]);
    } }, { key: "handleMouseOut", value: function(e) {
      var t = this.w, i = this.getElXCrosshairs();
      if (t.globals.dom.baseEl.classList.remove("apexcharts-tooltip-active"), e.tooltipEl.classList.remove("apexcharts-active"), this.deactivateHoverFilter(), t.config.chart.type !== "bubble" && this.marker.resetPointsSize(), i !== null && i.classList.remove("apexcharts-active"), this.ycrosshairs !== null && this.ycrosshairs.classList.remove("apexcharts-active"), this.isXAxisTooltipEnabled && this.xaxisTooltip.classList.remove("apexcharts-active"), this.yaxisTooltips.length) {
        this.yaxisTTEls === null && (this.yaxisTTEls = t.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxistooltip"));
        for (var a = 0; a < this.yaxisTTEls.length; a++)
          this.yaxisTTEls[a].classList.remove("apexcharts-active");
      }
      t.config.legend.tooltipHoverFormatter && this.legendLabels.forEach(function(r) {
        var s = r.getAttribute("data:default-text");
        r.innerHTML = decodeURIComponent(s);
      });
    } }, { key: "markerClick", value: function(e, t, i) {
      var a = this.w;
      typeof a.config.chart.events.markerClick == "function" && a.config.chart.events.markerClick(e, this.ctx, { seriesIndex: t, dataPointIndex: i, w: a }), this.ctx.events.fireEvent("markerClick", [e, this.ctx, { seriesIndex: t, dataPointIndex: i, w: a }]);
    } }, { key: "create", value: function(e, t, i, a, r) {
      var s, n, o, h, d, c, g, p, x, f, m, v, w, l, u, b, A = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : null, k = this.w, S = t;
      e.type === "mouseup" && this.markerClick(e, i, a), A === null && (A = this.tConfig.shared);
      var C = this.tooltipUtil.hasMarkers(i), L = this.tooltipUtil.getElBars();
      if (k.config.legend.tooltipHoverFormatter) {
        var M = k.config.legend.tooltipHoverFormatter, T = Array.from(this.legendLabels);
        T.forEach(function(q) {
          var Z = q.getAttribute("data:default-text");
          q.innerHTML = decodeURIComponent(Z);
        });
        for (var I = 0; I < T.length; I++) {
          var z = T[I], Y = parseInt(z.getAttribute("i"), 10), D = decodeURIComponent(z.getAttribute("data:default-text")), H = M(D, { seriesIndex: A ? Y : i, dataPointIndex: a, w: k });
          if (A)
            z.innerHTML = k.globals.collapsedSeriesIndices.indexOf(Y) < 0 ? H : D;
          else if (z.innerHTML = Y === i ? H : D, i === Y)
            break;
        }
      }
      var O = E(E({ ttItems: r, i, j: a }, ((s = k.globals.seriesRange) === null || s === void 0 || (n = s[i]) === null || n === void 0 || (o = n[a]) === null || o === void 0 || (h = o.y[0]) === null || h === void 0 ? void 0 : h.y1) !== void 0 && { y1: (d = k.globals.seriesRange) === null || d === void 0 || (c = d[i]) === null || c === void 0 || (g = c[a]) === null || g === void 0 || (p = g.y[0]) === null || p === void 0 ? void 0 : p.y1 }), ((x = k.globals.seriesRange) === null || x === void 0 || (f = x[i]) === null || f === void 0 || (m = f[a]) === null || m === void 0 || (v = m.y[0]) === null || v === void 0 ? void 0 : v.y2) !== void 0 && { y2: (w = k.globals.seriesRange) === null || w === void 0 || (l = w[i]) === null || l === void 0 || (u = l[a]) === null || u === void 0 || (b = u.y[0]) === null || b === void 0 ? void 0 : b.y2 });
      if (A) {
        if (S.tooltipLabels.drawSeriesTexts(E(E({}, O), {}, { shared: !this.showOnIntersect && this.tConfig.shared })), C)
          k.globals.markers.largestSize > 0 ? S.marker.enlargePoints(a) : S.tooltipPosition.moveDynamicPointsOnHover(a);
        else if (this.tooltipUtil.hasBars() && (this.barSeriesHeight = this.tooltipUtil.getBarsHeight(L), this.barSeriesHeight > 0)) {
          var B = new X(this.ctx), N = k.globals.dom.Paper.select(".apexcharts-bar-area[j='".concat(a, "']"));
          this.deactivateHoverFilter(), this.tooltipPosition.moveStickyTooltipOverBars(a, i);
          for (var W = 0; W < N.length; W++)
            B.pathMouseEnter(N[W]);
        }
      } else
        S.tooltipLabels.drawSeriesTexts(E({ shared: !1 }, O)), this.tooltipUtil.hasBars() && S.tooltipPosition.moveStickyTooltipOverBars(a, i), C && S.tooltipPosition.moveMarkers(i, a);
    } }]), y;
  }(), Ft = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.barCtx = e, this.totalFormatter = this.w.config.plotOptions.bar.dataLabels.total.formatter, this.totalFormatter || (this.totalFormatter = this.w.config.dataLabels.formatter);
    }
    return F(y, [{ key: "handleBarDataLabels", value: function(e) {
      var t, i, a = e.x, r = e.y, s = e.y1, n = e.y2, o = e.i, h = e.j, d = e.realIndex, c = e.columnGroupIndex, g = e.series, p = e.barHeight, x = e.barWidth, f = e.barXPosition, m = e.barYPosition, v = e.visibleSeries, w = e.renderedPath, l = this.w, u = new X(this.barCtx.ctx), b = Array.isArray(this.barCtx.strokeWidth) ? this.barCtx.strokeWidth[d] : this.barCtx.strokeWidth;
      l.globals.isXNumeric && !l.globals.isBarHorizontal ? (t = a + parseFloat(x * (v + 1)), i = r + parseFloat(p * (v + 1)) - b) : (t = a + parseFloat(x * v), i = r + parseFloat(p * v));
      var A, k = null, S = a, C = r, L = {}, M = l.config.dataLabels, T = this.barCtx.barOptions.dataLabels, I = this.barCtx.barOptions.dataLabels.total;
      m !== void 0 && this.barCtx.isRangeBar && (i = m, C = m), f !== void 0 && this.barCtx.isVerticalGroupedRangeBar && (t = f, S = f);
      var z = M.offsetX, Y = M.offsetY, D = { width: 0, height: 0 };
      if (l.config.dataLabels.enabled) {
        var H = l.globals.series[o][h];
        D = u.getTextRects(l.config.dataLabels.formatter ? l.config.dataLabels.formatter(H, E(E({}, l), {}, { seriesIndex: o, dataPointIndex: h, w: l })) : l.globals.yLabelFormatters[0](H), parseFloat(M.style.fontSize));
      }
      var O = { x: a, y: r, i: o, j: h, realIndex: d, columnGroupIndex: c, renderedPath: w, bcx: t, bcy: i, barHeight: p, barWidth: x, textRects: D, strokeWidth: b, dataLabelsX: S, dataLabelsY: C, dataLabelsConfig: M, barDataLabelsConfig: T, barTotalDataLabelsConfig: I, offX: z, offY: Y };
      return L = this.barCtx.isHorizontal ? this.calculateBarsDataLabelsPosition(O) : this.calculateColumnsDataLabelsPosition(O), w.attr({ cy: L.bcy, cx: L.bcx, j: h, val: l.globals.series[o][h], barHeight: p, barWidth: x }), A = this.drawCalculatedDataLabels({ x: L.dataLabelsX, y: L.dataLabelsY, val: this.barCtx.isRangeBar ? [s, n] : l.config.chart.stackType === "100%" ? g[d][h] : l.globals.series[d][h], i: d, j: h, barWidth: x, barHeight: p, textRects: D, dataLabelsConfig: M }), l.config.chart.stacked && I.enabled && (k = this.drawTotalDataLabels({ x: L.totalDataLabelsX, y: L.totalDataLabelsY, barWidth: x, barHeight: p, realIndex: d, textAnchor: L.totalDataLabelsAnchor, val: this.getStackedTotalDataLabel({ realIndex: d, j: h }), dataLabelsConfig: M, barTotalDataLabelsConfig: I })), { dataLabels: A, totalDataLabels: k };
    } }, { key: "getStackedTotalDataLabel", value: function(e) {
      var t = e.realIndex, i = e.j, a = this.w, r = this.barCtx.stackedSeriesTotals[i];
      return this.totalFormatter && (r = this.totalFormatter(r, E(E({}, a), {}, { seriesIndex: t, dataPointIndex: i, w: a }))), r;
    } }, { key: "calculateColumnsDataLabelsPosition", value: function(e) {
      var t = this.w, i = e.i, a = e.j, r = e.realIndex;
      e.columnGroupIndex;
      var s, n, o = e.y, h = e.bcx, d = e.barWidth, c = e.barHeight, g = e.textRects, p = e.dataLabelsX, x = e.dataLabelsY, f = e.dataLabelsConfig, m = e.barDataLabelsConfig, v = e.barTotalDataLabelsConfig, w = e.strokeWidth, l = e.offX, u = e.offY, b = h;
      c = Math.abs(c);
      var A = t.config.plotOptions.bar.dataLabels.orientation === "vertical", k = this.barCtx.barHelpers.getZeroValueEncounters({ i, j: a }).zeroEncounters;
      h -= w / 2;
      var S = t.globals.gridWidth / t.globals.dataPoints;
      this.barCtx.isVerticalGroupedRangeBar ? p += d / 2 : (p = t.globals.isXNumeric ? h - d / 2 + l : h - S + d / 2 + l, k > 0 && t.config.plotOptions.bar.hideZeroBarsWhenGrouped && (p -= d * k)), A && (p = p + g.height / 2 - w / 2 - 2);
      var C = t.globals.series[i][a] < 0, L = o;
      switch (this.barCtx.isReversed && (L = o + (C ? c : -c)), m.position) {
        case "center":
          x = A ? C ? L - c / 2 + u : L + c / 2 - u : C ? L - c / 2 + g.height / 2 + u : L + c / 2 + g.height / 2 - u;
          break;
        case "bottom":
          x = A ? C ? L - c + u : L + c - u : C ? L - c + g.height + w + u : L + c - g.height / 2 + w - u;
          break;
        case "top":
          x = A ? C ? L + u : L - u : C ? L - g.height / 2 - u : L + g.height + u;
      }
      if (this.barCtx.lastActiveBarSerieIndex === r && v.enabled) {
        var M = new X(this.barCtx.ctx).getTextRects(this.getStackedTotalDataLabel({ realIndex: r, j: a }), f.fontSize);
        s = C ? L - M.height / 2 - u - v.offsetY + 18 : L + M.height + u + v.offsetY - 18;
        var T = S;
        n = b + (t.globals.isXNumeric ? -d * t.globals.barGroups.length / 2 : t.globals.barGroups.length * d / 2 - (t.globals.barGroups.length - 1) * d - T) + v.offsetX;
      }
      return t.config.chart.stacked || (x < 0 ? x = 0 + w : x + g.height / 3 > t.globals.gridHeight && (x = t.globals.gridHeight - w)), { bcx: h, bcy: o, dataLabelsX: p, dataLabelsY: x, totalDataLabelsX: n, totalDataLabelsY: s, totalDataLabelsAnchor: "middle" };
    } }, { key: "calculateBarsDataLabelsPosition", value: function(e) {
      var t = this.w, i = e.x, a = e.i, r = e.j, s = e.realIndex, n = e.bcy, o = e.barHeight, h = e.barWidth, d = e.textRects, c = e.dataLabelsX, g = e.strokeWidth, p = e.dataLabelsConfig, x = e.barDataLabelsConfig, f = e.barTotalDataLabelsConfig, m = e.offX, v = e.offY, w = t.globals.gridHeight / t.globals.dataPoints;
      h = Math.abs(h);
      var l, u, b = n - (this.barCtx.isRangeBar ? 0 : w) + o / 2 + d.height / 2 + v - 3, A = "start", k = t.globals.series[a][r] < 0, S = i;
      switch (this.barCtx.isReversed && (S = i + (k ? -h : h), A = k ? "start" : "end"), x.position) {
        case "center":
          c = k ? S + h / 2 - m : Math.max(d.width / 2, S - h / 2) + m;
          break;
        case "bottom":
          c = k ? S + h - g - m : S - h + g + m;
          break;
        case "top":
          c = k ? S - g - m : S - g + m;
      }
      if (this.barCtx.lastActiveBarSerieIndex === s && f.enabled) {
        var C = new X(this.barCtx.ctx).getTextRects(this.getStackedTotalDataLabel({ realIndex: s, j: r }), p.fontSize);
        k ? (l = S - g - m - f.offsetX, A = "end") : l = S + m + f.offsetX + (this.barCtx.isReversed ? -(h + g) : g), u = b - d.height / 2 + C.height / 2 + f.offsetY + g;
      }
      return t.config.chart.stacked || (p.textAnchor === "start" ? c - d.width < 0 ? c = k ? d.width + g : g : c + d.width > t.globals.gridWidth && (c = k ? t.globals.gridWidth - g : t.globals.gridWidth - d.width - g) : p.textAnchor === "middle" ? c - d.width / 2 < 0 ? c = d.width / 2 + g : c + d.width / 2 > t.globals.gridWidth && (c = t.globals.gridWidth - d.width / 2 - g) : p.textAnchor === "end" && (c < 1 ? c = d.width + g : c + 1 > t.globals.gridWidth && (c = t.globals.gridWidth - d.width - g))), { bcx: i, bcy: n, dataLabelsX: c, dataLabelsY: b, totalDataLabelsX: l, totalDataLabelsY: u, totalDataLabelsAnchor: A };
    } }, { key: "drawCalculatedDataLabels", value: function(e) {
      var t = e.x, i = e.y, a = e.val, r = e.i, s = e.j, n = e.textRects, o = e.barHeight, h = e.barWidth, d = e.dataLabelsConfig, c = this.w, g = "rotate(0)";
      c.config.plotOptions.bar.dataLabels.orientation === "vertical" && (g = "rotate(-90, ".concat(t, ", ").concat(i, ")"));
      var p = new pe(this.barCtx.ctx), x = new X(this.barCtx.ctx), f = d.formatter, m = null, v = c.globals.collapsedSeriesIndices.indexOf(r) > -1;
      if (d.enabled && !v) {
        m = x.group({ class: "apexcharts-data-labels", transform: g });
        var w = "";
        a !== void 0 && (w = f(a, E(E({}, c), {}, { seriesIndex: r, dataPointIndex: s, w: c }))), !a && c.config.plotOptions.bar.hideZeroBarsWhenGrouped && (w = "");
        var l = c.globals.series[r][s] < 0, u = c.config.plotOptions.bar.dataLabels.position;
        c.config.plotOptions.bar.dataLabels.orientation === "vertical" && (u === "top" && (d.textAnchor = l ? "end" : "start"), u === "center" && (d.textAnchor = "middle"), u === "bottom" && (d.textAnchor = l ? "end" : "start")), this.barCtx.isRangeBar && this.barCtx.barOptions.dataLabels.hideOverflowingLabels && h < x.getTextRects(w, parseFloat(d.style.fontSize)).width && (w = ""), c.config.chart.stacked && this.barCtx.barOptions.dataLabels.hideOverflowingLabels && (this.barCtx.isHorizontal ? n.width / 1.6 > Math.abs(h) && (w = "") : n.height / 1.6 > Math.abs(o) && (w = ""));
        var b = E({}, d);
        this.barCtx.isHorizontal && a < 0 && (d.textAnchor === "start" ? b.textAnchor = "end" : d.textAnchor === "end" && (b.textAnchor = "start")), p.plotDataLabelsText({ x: t, y: i, text: w, i: r, j: s, parent: m, dataLabelsConfig: b, alwaysDrawDataLabel: !0, offsetCorrection: !0 });
      }
      return m;
    } }, { key: "drawTotalDataLabels", value: function(e) {
      var t = e.x, i = e.y, a = e.val, r = e.realIndex, s = e.textAnchor, n = e.barTotalDataLabelsConfig;
      this.w;
      var o, h = new X(this.barCtx.ctx);
      return n.enabled && t !== void 0 && i !== void 0 && this.barCtx.lastActiveBarSerieIndex === r && (o = h.drawText({ x: t, y: i, foreColor: n.style.color, text: a, textAnchor: s, fontFamily: n.style.fontFamily, fontSize: n.style.fontSize, fontWeight: n.style.fontWeight })), o;
    } }]), y;
  }(), Dt = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.barCtx = e;
    }
    return F(y, [{ key: "initVariables", value: function(e) {
      var t = this.w;
      this.barCtx.series = e, this.barCtx.totalItems = 0, this.barCtx.seriesLen = 0, this.barCtx.visibleI = -1, this.barCtx.visibleItems = 1;
      for (var i = 0; i < e.length; i++)
        if (e[i].length > 0 && (this.barCtx.seriesLen = this.barCtx.seriesLen + 1, this.barCtx.totalItems += e[i].length), t.globals.isXNumeric)
          for (var a = 0; a < e[i].length; a++)
            t.globals.seriesX[i][a] > t.globals.minX && t.globals.seriesX[i][a] < t.globals.maxX && this.barCtx.visibleItems++;
        else
          this.barCtx.visibleItems = t.globals.dataPoints;
      this.arrBorderRadius = this.createBorderRadiusArr(t.globals.series), this.barCtx.seriesLen === 0 && (this.barCtx.seriesLen = 1), this.barCtx.zeroSerieses = [], t.globals.comboCharts || this.checkZeroSeries({ series: e });
    } }, { key: "initialPositions", value: function() {
      var e, t, i, a, r, s, n, o, h = this.w, d = h.globals.dataPoints;
      this.barCtx.isRangeBar && (d = h.globals.labels.length);
      var c = this.barCtx.seriesLen;
      if (h.config.plotOptions.bar.rangeBarGroupRows && (c = 1), this.barCtx.isHorizontal)
        r = (i = h.globals.gridHeight / d) / c, h.globals.isXNumeric && (r = (i = h.globals.gridHeight / this.barCtx.totalItems) / this.barCtx.seriesLen), r = r * parseInt(this.barCtx.barOptions.barHeight, 10) / 100, String(this.barCtx.barOptions.barHeight).indexOf("%") === -1 && (r = parseInt(this.barCtx.barOptions.barHeight, 10)), o = this.barCtx.baseLineInvertedY + h.globals.padHorizontal + (this.barCtx.isReversed ? h.globals.gridWidth : 0) - (this.barCtx.isReversed ? 2 * this.barCtx.baseLineInvertedY : 0), this.barCtx.isFunnel && (o = h.globals.gridWidth / 2), t = (i - r * this.barCtx.seriesLen) / 2;
      else {
        if (a = h.globals.gridWidth / this.barCtx.visibleItems, h.config.xaxis.convertedCatToNumeric && (a = h.globals.gridWidth / h.globals.dataPoints), s = a / c * parseInt(this.barCtx.barOptions.columnWidth, 10) / 100, h.globals.isXNumeric) {
          var g = this.barCtx.xRatio;
          h.globals.minXDiff && h.globals.minXDiff !== 0.5 && h.globals.minXDiff / g > 0 && (a = h.globals.minXDiff / g), (s = a / c * parseInt(this.barCtx.barOptions.columnWidth, 10) / 100) < 1 && (s = 1);
        }
        String(this.barCtx.barOptions.columnWidth).indexOf("%") === -1 && (s = parseInt(this.barCtx.barOptions.columnWidth, 10)), n = h.globals.gridHeight - this.barCtx.baseLineY[this.barCtx.translationsIndex] - (this.barCtx.isReversed ? h.globals.gridHeight : 0) + (this.barCtx.isReversed ? 2 * this.barCtx.baseLineY[this.barCtx.translationsIndex] : 0), e = h.globals.padHorizontal + (a - s * this.barCtx.seriesLen) / 2;
      }
      return h.globals.barHeight = r, h.globals.barWidth = s, { x: e, y: t, yDivision: i, xDivision: a, barHeight: r, barWidth: s, zeroH: n, zeroW: o };
    } }, { key: "initializeStackedPrevVars", value: function(e) {
      e.w.globals.seriesGroups.forEach(function(t) {
        e[t] || (e[t] = {}), e[t].prevY = [], e[t].prevX = [], e[t].prevYF = [], e[t].prevXF = [], e[t].prevYVal = [], e[t].prevXVal = [];
      });
    } }, { key: "initializeStackedXYVars", value: function(e) {
      e.w.globals.seriesGroups.forEach(function(t) {
        e[t] || (e[t] = {}), e[t].xArrj = [], e[t].xArrjF = [], e[t].xArrjVal = [], e[t].yArrj = [], e[t].yArrjF = [], e[t].yArrjVal = [];
      });
    } }, { key: "getPathFillColor", value: function(e, t, i, a) {
      var r, s, n, o, h, d = this.w, c = this.barCtx.ctx.fill, g = null, p = this.barCtx.barOptions.distributed ? i : t;
      return this.barCtx.barOptions.colors.ranges.length > 0 && this.barCtx.barOptions.colors.ranges.map(function(x) {
        e[t][i] >= x.from && e[t][i] <= x.to && (g = x.color);
      }), (r = d.config.series[t].data[i]) !== null && r !== void 0 && r.fillColor && (g = d.config.series[t].data[i].fillColor), c.fillPath({ seriesNumber: this.barCtx.barOptions.distributed ? p : a, dataPointIndex: i, color: g, value: e[t][i], fillConfig: (s = d.config.series[t].data[i]) === null || s === void 0 ? void 0 : s.fill, fillType: (n = d.config.series[t].data[i]) !== null && n !== void 0 && (o = n.fill) !== null && o !== void 0 && o.type ? (h = d.config.series[t].data[i]) === null || h === void 0 ? void 0 : h.fill.type : Array.isArray(d.config.fill.type) ? d.config.fill.type[a] : d.config.fill.type });
    } }, { key: "getStrokeWidth", value: function(e, t, i) {
      var a = 0, r = this.w;
      return this.barCtx.series[e][t] ? this.barCtx.isNullValue = !1 : this.barCtx.isNullValue = !0, r.config.stroke.show && (this.barCtx.isNullValue || (a = Array.isArray(this.barCtx.strokeWidth) ? this.barCtx.strokeWidth[i] : this.barCtx.strokeWidth)), a;
    } }, { key: "createBorderRadiusArr", value: function(e) {
      var t = this.w, i = !this.w.config.chart.stacked || t.config.plotOptions.bar.borderRadiusWhenStacked !== "last" || t.config.plotOptions.bar.borderRadius <= 0, a = e.length, r = e[0].length, s = Array.from({ length: a }, function() {
        return Array(r).fill(i ? "top" : "none");
      });
      if (i)
        return s;
      for (var n = 0; n < r; n++) {
        for (var o = [], h = [], d = 0, c = 0; c < a; c++) {
          var g = e[c][n];
          g > 0 ? (o.push(c), d++) : g < 0 && (h.push(c), d++);
        }
        if (o.length > 0 && h.length === 0)
          if (o.length === 1)
            s[o[0]][n] = "both";
          else {
            var p, x = o[0], f = o[o.length - 1], m = Ae(o);
            try {
              for (m.s(); !(p = m.n()).done; ) {
                var v = p.value;
                s[v][n] = v === x ? "bottom" : v === f ? "top" : "none";
              }
            } catch (Y) {
              m.e(Y);
            } finally {
              m.f();
            }
          }
        else if (h.length > 0 && o.length === 0)
          if (h.length === 1)
            s[h[0]][n] = "both";
          else {
            var w, l = h[0], u = h[h.length - 1], b = Ae(h);
            try {
              for (b.s(); !(w = b.n()).done; ) {
                var A = w.value;
                s[A][n] = A === l ? "bottom" : A === u ? "top" : "none";
              }
            } catch (Y) {
              b.e(Y);
            } finally {
              b.f();
            }
          }
        else if (o.length > 0 && h.length > 0) {
          var k, S = o[o.length - 1], C = Ae(o);
          try {
            for (C.s(); !(k = C.n()).done; ) {
              var L = k.value;
              s[L][n] = L === S ? "top" : "none";
            }
          } catch (Y) {
            C.e(Y);
          } finally {
            C.f();
          }
          var M, T = h[h.length - 1], I = Ae(h);
          try {
            for (I.s(); !(M = I.n()).done; ) {
              var z = M.value;
              s[z][n] = z === T ? "bottom" : "none";
            }
          } catch (Y) {
            I.e(Y);
          } finally {
            I.f();
          }
        } else
          d === 1 && (s[o[0] || h[0]][n] = "both");
      }
      return s;
    } }, { key: "barBackground", value: function(e) {
      var t = e.j, i = e.i, a = e.x1, r = e.x2, s = e.y1, n = e.y2, o = e.elSeries, h = this.w, d = new X(this.barCtx.ctx), c = new re(this.barCtx.ctx).getActiveConfigSeriesIndex();
      if (this.barCtx.barOptions.colors.backgroundBarColors.length > 0 && c === i) {
        t >= this.barCtx.barOptions.colors.backgroundBarColors.length && (t %= this.barCtx.barOptions.colors.backgroundBarColors.length);
        var g = this.barCtx.barOptions.colors.backgroundBarColors[t], p = d.drawRect(a !== void 0 ? a : 0, s !== void 0 ? s : 0, r !== void 0 ? r : h.globals.gridWidth, n !== void 0 ? n : h.globals.gridHeight, this.barCtx.barOptions.colors.backgroundBarRadius, g, this.barCtx.barOptions.colors.backgroundBarOpacity);
        o.add(p), p.node.classList.add("apexcharts-backgroundBar");
      }
    } }, { key: "getColumnPaths", value: function(e) {
      var t, i = e.barWidth, a = e.barXPosition, r = e.y1, s = e.y2, n = e.strokeWidth, o = e.isReversed, h = e.series, d = e.seriesGroup, c = e.realIndex, g = e.i, p = e.j, x = e.w, f = new X(this.barCtx.ctx);
      (n = Array.isArray(n) ? n[c] : n) || (n = 0);
      var m = i, v = a;
      (t = x.config.series[c].data[p]) !== null && t !== void 0 && t.columnWidthOffset && (v = a - x.config.series[c].data[p].columnWidthOffset / 2, m = i + x.config.series[c].data[p].columnWidthOffset);
      var w = n / 2, l = v + w, u = v + m - w, b = (h[g][p] >= 0 ? 1 : -1) * (o ? -1 : 1);
      r += 1e-3 - w * b, s += 1e-3 + w * b;
      var A = f.move(l, r), k = f.move(l, r), S = f.line(u, r);
      if (x.globals.previousPaths.length > 0 && (k = this.barCtx.getPreviousPath(c, p, !1)), A = A + f.line(l, s) + f.line(u, s) + S + (x.config.plotOptions.bar.borderRadiusApplication === "around" || this.arrBorderRadius[c][p] === "both" ? " Z" : " z"), k = k + f.line(l, r) + S + S + S + S + S + f.line(l, r) + (x.config.plotOptions.bar.borderRadiusApplication === "around" || this.arrBorderRadius[c][p] === "both" ? " Z" : " z"), this.arrBorderRadius[c][p] !== "none" && (A = f.roundPathCorners(A, x.config.plotOptions.bar.borderRadius)), x.config.chart.stacked) {
        var C = this.barCtx;
        (C = this.barCtx[d]).yArrj.push(s - w * b), C.yArrjF.push(Math.abs(r - s + n * b)), C.yArrjVal.push(this.barCtx.series[g][p]);
      }
      return { pathTo: A, pathFrom: k };
    } }, { key: "getBarpaths", value: function(e) {
      var t, i = e.barYPosition, a = e.barHeight, r = e.x1, s = e.x2, n = e.strokeWidth, o = e.isReversed, h = e.series, d = e.seriesGroup, c = e.realIndex, g = e.i, p = e.j, x = e.w, f = new X(this.barCtx.ctx);
      (n = Array.isArray(n) ? n[c] : n) || (n = 0);
      var m = i, v = a;
      (t = x.config.series[c].data[p]) !== null && t !== void 0 && t.barHeightOffset && (m = i - x.config.series[c].data[p].barHeightOffset / 2, v = a + x.config.series[c].data[p].barHeightOffset);
      var w = n / 2, l = m + w, u = m + v - w, b = (h[g][p] >= 0 ? 1 : -1) * (o ? -1 : 1);
      r += 1e-3 + w * b, s += 1e-3 - w * b;
      var A = f.move(r, l), k = f.move(r, l);
      x.globals.previousPaths.length > 0 && (k = this.barCtx.getPreviousPath(c, p, !1));
      var S = f.line(r, u);
      if (A = A + f.line(s, l) + f.line(s, u) + S + (x.config.plotOptions.bar.borderRadiusApplication === "around" || this.arrBorderRadius[c][p] === "both" ? " Z" : " z"), k = k + f.line(r, l) + S + S + S + S + S + f.line(r, l) + (x.config.plotOptions.bar.borderRadiusApplication === "around" || this.arrBorderRadius[c][p] === "both" ? " Z" : " z"), this.arrBorderRadius[c][p] !== "none" && (A = f.roundPathCorners(A, x.config.plotOptions.bar.borderRadius)), x.config.chart.stacked) {
        var C = this.barCtx;
        (C = this.barCtx[d]).xArrj.push(s + w * b), C.xArrjF.push(Math.abs(r - s - n * b)), C.xArrjVal.push(this.barCtx.series[g][p]);
      }
      return { pathTo: A, pathFrom: k };
    } }, { key: "checkZeroSeries", value: function(e) {
      for (var t = e.series, i = this.w, a = 0; a < t.length; a++) {
        for (var r = 0, s = 0; s < t[i.globals.maxValsInArrayIndex].length; s++)
          r += t[a][s];
        r === 0 && this.barCtx.zeroSerieses.push(a);
      }
    } }, { key: "getXForValue", value: function(e, t) {
      var i = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2] ? t : null;
      return e != null && (i = t + e / this.barCtx.invertedYRatio - 2 * (this.barCtx.isReversed ? e / this.barCtx.invertedYRatio : 0)), i;
    } }, { key: "getYForValue", value: function(e, t, i) {
      var a = !(arguments.length > 3 && arguments[3] !== void 0) || arguments[3] ? t : null;
      return e != null && (a = t - e / this.barCtx.yRatio[i] + 2 * (this.barCtx.isReversed ? e / this.barCtx.yRatio[i] : 0)), a;
    } }, { key: "getGoalValues", value: function(e, t, i, a, r, s) {
      var n = this, o = this.w, h = [], d = function(p, x) {
        var f;
        h.push((Se(f = {}, e, e === "x" ? n.getXForValue(p, t, !1) : n.getYForValue(p, i, s, !1)), Se(f, "attrs", x), f));
      };
      if (o.globals.seriesGoals[a] && o.globals.seriesGoals[a][r] && Array.isArray(o.globals.seriesGoals[a][r]) && o.globals.seriesGoals[a][r].forEach(function(p) {
        d(p.value, p);
      }), this.barCtx.barOptions.isDumbbell && o.globals.seriesRange.length) {
        var c = this.barCtx.barOptions.dumbbellColors ? this.barCtx.barOptions.dumbbellColors : o.globals.colors, g = { strokeHeight: e === "x" ? 0 : o.globals.markers.size[a], strokeWidth: e === "x" ? o.globals.markers.size[a] : 0, strokeDashArray: 0, strokeLineCap: "round", strokeColor: Array.isArray(c[a]) ? c[a][0] : c[a] };
        d(o.globals.seriesRangeStart[a][r], g), d(o.globals.seriesRangeEnd[a][r], E(E({}, g), {}, { strokeColor: Array.isArray(c[a]) ? c[a][1] : c[a] }));
      }
      return h;
    } }, { key: "drawGoalLine", value: function(e) {
      var t = e.barXPosition, i = e.barYPosition, a = e.goalX, r = e.goalY, s = e.barWidth, n = e.barHeight, o = new X(this.barCtx.ctx), h = o.group({ className: "apexcharts-bar-goals-groups" });
      h.node.classList.add("apexcharts-element-hidden"), this.barCtx.w.globals.delayedElements.push({ el: h.node }), h.attr("clip-path", "url(#gridRectMarkerMask".concat(this.barCtx.w.globals.cuid, ")"));
      var d = null;
      return this.barCtx.isHorizontal ? Array.isArray(a) && a.forEach(function(c) {
        if (c.x >= -1 && c.x <= o.w.globals.gridWidth + 1) {
          var g = c.attrs.strokeHeight !== void 0 ? c.attrs.strokeHeight : n / 2, p = i + g + n / 2;
          d = o.drawLine(c.x, p - 2 * g, c.x, p, c.attrs.strokeColor ? c.attrs.strokeColor : void 0, c.attrs.strokeDashArray, c.attrs.strokeWidth ? c.attrs.strokeWidth : 2, c.attrs.strokeLineCap), h.add(d);
        }
      }) : Array.isArray(r) && r.forEach(function(c) {
        if (c.y >= -1 && c.y <= o.w.globals.gridHeight + 1) {
          var g = c.attrs.strokeWidth !== void 0 ? c.attrs.strokeWidth : s / 2, p = t + g + s / 2;
          d = o.drawLine(p - 2 * g, c.y, p, c.y, c.attrs.strokeColor ? c.attrs.strokeColor : void 0, c.attrs.strokeDashArray, c.attrs.strokeHeight ? c.attrs.strokeHeight : 2, c.attrs.strokeLineCap), h.add(d);
        }
      }), h;
    } }, { key: "drawBarShadow", value: function(e) {
      var t = e.prevPaths, i = e.currPaths, a = e.color, r = this.w, s = t.x, n = t.x1, o = t.barYPosition, h = i.x, d = i.x1, c = i.barYPosition, g = o + i.barHeight, p = new X(this.barCtx.ctx), x = new P(), f = p.move(n, g) + p.line(s, g) + p.line(h, c) + p.line(d, c) + p.line(n, g) + (r.config.plotOptions.bar.borderRadiusApplication === "around" || this.arrBorderRadius[realIndex][j] === "both" ? " Z" : " z");
      return p.drawPath({ d: f, fill: x.shadeColor(0.5, P.rgb2hex(a)), stroke: "none", strokeWidth: 0, fillOpacity: 1, classes: "apexcharts-bar-shadows" });
    } }, { key: "getZeroValueEncounters", value: function(e) {
      var t, i = e.i, a = e.j, r = this.w, s = 0, n = 0;
      return (r.config.plotOptions.bar.horizontal ? r.globals.series.map(function(o, h) {
        return h;
      }) : ((t = r.globals.columnSeries) === null || t === void 0 ? void 0 : t.i.map(function(o) {
        return o;
      })) || []).forEach(function(o) {
        var h = r.globals.seriesPercent[o][a];
        h && s++, o < i && h === 0 && n++;
      }), { nonZeroColumns: s, zeroEncounters: n };
    } }, { key: "getGroupIndex", value: function(e) {
      var t = this.w, i = t.globals.seriesGroups.findIndex(function(s) {
        return s.indexOf(t.globals.seriesNames[e]) > -1;
      }), a = this.barCtx.columnGroupIndices, r = a.indexOf(i);
      return r < 0 && (a.push(i), r = a.length - 1), { groupIndex: i, columnGroupIndex: r };
    } }]), y;
  }(), fe = function() {
    function y(e, t) {
      R(this, y), this.ctx = e, this.w = e.w;
      var i = this.w;
      this.barOptions = i.config.plotOptions.bar, this.isHorizontal = this.barOptions.horizontal, this.strokeWidth = i.config.stroke.width, this.isNullValue = !1, this.isRangeBar = i.globals.seriesRange.length && this.isHorizontal, this.isVerticalGroupedRangeBar = !i.globals.isBarHorizontal && i.globals.seriesRange.length && i.config.plotOptions.bar.rangeBarGroupRows, this.isFunnel = this.barOptions.isFunnel, this.xyRatios = t, this.xyRatios !== null && (this.xRatio = t.xRatio, this.yRatio = t.yRatio, this.invertedXRatio = t.invertedXRatio, this.invertedYRatio = t.invertedYRatio, this.baseLineY = t.baseLineY, this.baseLineInvertedY = t.baseLineInvertedY), this.yaxisIndex = 0, this.translationsIndex = 0, this.seriesLen = 0, this.pathArr = [];
      var a = new re(this.ctx);
      this.lastActiveBarSerieIndex = a.getActiveConfigSeriesIndex("desc", ["bar", "column"]), this.columnGroupIndices = [];
      var r = a.getBarSeriesIndices(), s = new $(this.ctx);
      this.stackedSeriesTotals = s.getStackedSeriesTotals(this.w.config.series.map(function(n, o) {
        return r.indexOf(o) === -1 ? o : -1;
      }).filter(function(n) {
        return n !== -1;
      })), this.barHelpers = new Dt(this);
    }
    return F(y, [{ key: "draw", value: function(e, t) {
      var i = this.w, a = new X(this.ctx), r = new $(this.ctx, i);
      e = r.getLogSeries(e), this.series = e, this.yRatio = r.getLogYRatios(this.yRatio), this.barHelpers.initVariables(e);
      var s = a.group({ class: "apexcharts-bar-series apexcharts-plot-series" });
      i.config.dataLabels.enabled && this.totalItems > this.barOptions.dataLabels.maxItems && console.warn("WARNING: DataLabels are enabled but there are too many to display. This may cause performance issue when rendering - ApexCharts");
      for (var n = 0, o = 0; n < e.length; n++, o++) {
        var h, d, c, g, p = void 0, x = void 0, f = [], m = [], v = i.globals.comboCharts ? t[n] : n, w = this.barHelpers.getGroupIndex(v).columnGroupIndex, l = a.group({ class: "apexcharts-series", rel: n + 1, seriesName: P.escapeString(i.globals.seriesNames[v]), "data:realIndex": v });
        this.ctx.series.addCollapsedClassToSeries(l, v), e[n].length > 0 && (this.visibleI = this.visibleI + 1);
        var u = 0, b = 0;
        this.yRatio.length > 1 && (this.yaxisIndex = i.globals.seriesYAxisReverseMap[v], this.translationsIndex = v);
        var A = this.translationsIndex;
        this.isReversed = i.config.yaxis[this.yaxisIndex] && i.config.yaxis[this.yaxisIndex].reversed;
        var k = this.barHelpers.initialPositions();
        x = k.y, u = k.barHeight, d = k.yDivision, g = k.zeroW, p = k.x, b = k.barWidth, h = k.xDivision, c = k.zeroH, this.horizontal || m.push(p + b / 2);
        var S = a.group({ class: "apexcharts-datalabels", "data:realIndex": v });
        i.globals.delayedElements.push({ el: S.node }), S.node.classList.add("apexcharts-element-hidden");
        var C = a.group({ class: "apexcharts-bar-goals-markers" }), L = a.group({ class: "apexcharts-bar-shadows" });
        i.globals.delayedElements.push({ el: L.node }), L.node.classList.add("apexcharts-element-hidden");
        for (var M = 0; M < e[n].length; M++) {
          var T = this.barHelpers.getStrokeWidth(n, M, v), I = null, z = { indexes: { i: n, j: M, realIndex: v, translationsIndex: A, bc: o }, x: p, y: x, strokeWidth: T, elSeries: l };
          this.isHorizontal ? (I = this.drawBarPaths(E(E({}, z), {}, { barHeight: u, zeroW: g, yDivision: d })), b = this.series[n][M] / this.invertedYRatio) : (I = this.drawColumnPaths(E(E({}, z), {}, { xDivision: h, barWidth: b, zeroH: c })), u = this.series[n][M] / this.yRatio[A]);
          var Y = this.barHelpers.getPathFillColor(e, n, M, v);
          if (this.isFunnel && this.barOptions.isFunnel3d && this.pathArr.length && M > 0) {
            var D = this.barHelpers.drawBarShadow({ color: typeof Y == "string" && (Y == null ? void 0 : Y.indexOf("url")) === -1 ? Y : P.hexToRgba(i.globals.colors[n]), prevPaths: this.pathArr[this.pathArr.length - 1], currPaths: I });
            D && L.add(D);
          }
          this.pathArr.push(I);
          var H = this.barHelpers.drawGoalLine({ barXPosition: I.barXPosition, barYPosition: I.barYPosition, goalX: I.goalX, goalY: I.goalY, barHeight: u, barWidth: b });
          H && C.add(H), x = I.y, p = I.x, M > 0 && m.push(p + b / 2), f.push(x), this.renderSeries({ realIndex: v, pathFill: Y, j: M, i: n, columnGroupIndex: w, pathFrom: I.pathFrom, pathTo: I.pathTo, strokeWidth: T, elSeries: l, x: p, y: x, series: e, barHeight: Math.abs(I.barHeight ? I.barHeight : u), barWidth: Math.abs(I.barWidth ? I.barWidth : b), elDataLabelsWrap: S, elGoalsMarkers: C, elBarShadows: L, visibleSeries: this.visibleI, type: "bar" });
        }
        i.globals.seriesXvalues[v] = m, i.globals.seriesYvalues[v] = f, s.add(l);
      }
      return s;
    } }, { key: "renderSeries", value: function(e) {
      var t = e.realIndex, i = e.pathFill, a = e.lineFill, r = e.j, s = e.i, n = e.columnGroupIndex, o = e.pathFrom, h = e.pathTo, d = e.strokeWidth, c = e.elSeries, g = e.x, p = e.y, x = e.y1, f = e.y2, m = e.series, v = e.barHeight, w = e.barWidth, l = e.barXPosition, u = e.barYPosition, b = e.elDataLabelsWrap, A = e.elGoalsMarkers, k = e.elBarShadows, S = e.visibleSeries, C = e.type, L = e.classes, M = this.w, T = new X(this.ctx);
      if (!a) {
        var I = typeof M.globals.stroke.colors[t] == "function" ? function(O) {
          var B, N = M.config.stroke.colors;
          return Array.isArray(N) && N.length > 0 && ((B = N[O]) || (B = ""), typeof B == "function") ? B({ value: M.globals.series[O][r], dataPointIndex: r, w: M }) : B;
        }(t) : M.globals.stroke.colors[t];
        a = this.barOptions.distributed ? M.globals.stroke.colors[r] : I;
      }
      M.config.series[s].data[r] && M.config.series[s].data[r].strokeColor && (a = M.config.series[s].data[r].strokeColor), this.isNullValue && (i = "none");
      var z = r / M.config.chart.animations.animateGradually.delay * (M.config.chart.animations.speed / M.globals.dataPoints) / 2.4, Y = T.renderPaths({ i: s, j: r, realIndex: t, pathFrom: o, pathTo: h, stroke: a, strokeWidth: d, strokeLineCap: M.config.stroke.lineCap, fill: i, animationDelay: z, initialSpeed: M.config.chart.animations.speed, dataChangeSpeed: M.config.chart.animations.dynamicAnimation.speed, className: "apexcharts-".concat(C, "-area ").concat(L), chartType: C });
      Y.attr("clip-path", "url(#gridRectBarMask".concat(M.globals.cuid, ")"));
      var D = M.config.forecastDataPoints;
      D.count > 0 && r >= M.globals.dataPoints - D.count && (Y.node.setAttribute("stroke-dasharray", D.dashArray), Y.node.setAttribute("stroke-width", D.strokeWidth), Y.node.setAttribute("fill-opacity", D.fillOpacity)), x !== void 0 && f !== void 0 && (Y.attr("data-range-y1", x), Y.attr("data-range-y2", f)), new ee(this.ctx).setSelectionFilter(Y, t, r), c.add(Y);
      var H = new Ft(this).handleBarDataLabels({ x: g, y: p, y1: x, y2: f, i: s, j: r, series: m, realIndex: t, columnGroupIndex: n, barHeight: v, barWidth: w, barXPosition: l, barYPosition: u, renderedPath: Y, visibleSeries: S });
      return H.dataLabels !== null && b.add(H.dataLabels), H.totalDataLabels && b.add(H.totalDataLabels), c.add(b), A && c.add(A), k && c.add(k), c;
    } }, { key: "drawBarPaths", value: function(e) {
      var t, i = e.indexes, a = e.barHeight, r = e.strokeWidth, s = e.zeroW, n = e.x, o = e.y, h = e.yDivision, d = e.elSeries, c = this.w, g = i.i, p = i.j;
      if (c.globals.isXNumeric)
        t = (o = (c.globals.seriesX[g][p] - c.globals.minX) / this.invertedXRatio - a) + a * this.visibleI;
      else if (c.config.plotOptions.bar.hideZeroBarsWhenGrouped) {
        var x = 0, f = 0;
        c.globals.seriesPercent.forEach(function(v, w) {
          v[p] && x++, w < g && v[p] === 0 && f++;
        }), x > 0 && (a = this.seriesLen * a / x), t = o + a * this.visibleI, t -= a * f;
      } else
        t = o + a * this.visibleI;
      this.isFunnel && (s -= (this.barHelpers.getXForValue(this.series[g][p], s) - s) / 2), n = this.barHelpers.getXForValue(this.series[g][p], s);
      var m = this.barHelpers.getBarpaths({ barYPosition: t, barHeight: a, x1: s, x2: n, strokeWidth: r, isReversed: this.isReversed, series: this.series, realIndex: i.realIndex, i: g, j: p, w: c });
      return c.globals.isXNumeric || (o += h), this.barHelpers.barBackground({ j: p, i: g, y1: t - a * this.visibleI, y2: a * this.seriesLen, elSeries: d }), { pathTo: m.pathTo, pathFrom: m.pathFrom, x1: s, x: n, y: o, goalX: this.barHelpers.getGoalValues("x", s, null, g, p), barYPosition: t, barHeight: a };
    } }, { key: "drawColumnPaths", value: function(e) {
      var t, i = e.indexes, a = e.x, r = e.y, s = e.xDivision, n = e.barWidth, o = e.zeroH, h = e.strokeWidth, d = e.elSeries, c = this.w, g = i.realIndex, p = i.translationsIndex, x = i.i, f = i.j, m = i.bc;
      if (c.globals.isXNumeric) {
        var v = this.getBarXForNumericXAxis({ x: a, j: f, realIndex: g, barWidth: n });
        a = v.x, t = v.barXPosition;
      } else if (c.config.plotOptions.bar.hideZeroBarsWhenGrouped) {
        var w = this.barHelpers.getZeroValueEncounters({ i: x, j: f }), l = w.nonZeroColumns, u = w.zeroEncounters;
        l > 0 && (n = this.seriesLen * n / l), t = a + n * this.visibleI, t -= n * u;
      } else
        t = a + n * this.visibleI;
      r = this.barHelpers.getYForValue(this.series[x][f], o, p);
      var b = this.barHelpers.getColumnPaths({ barXPosition: t, barWidth: n, y1: o, y2: r, strokeWidth: h, isReversed: this.isReversed, series: this.series, realIndex: g, i: x, j: f, w: c });
      return c.globals.isXNumeric || (a += s), this.barHelpers.barBackground({ bc: m, j: f, i: x, x1: t - h / 2 - n * this.visibleI, x2: n * this.seriesLen + h / 2, elSeries: d }), { pathTo: b.pathTo, pathFrom: b.pathFrom, x: a, y: r, goalY: this.barHelpers.getGoalValues("y", null, o, x, f, p), barXPosition: t, barWidth: n };
    } }, { key: "getBarXForNumericXAxis", value: function(e) {
      var t = e.x, i = e.barWidth, a = e.realIndex, r = e.j, s = this.w, n = a;
      return s.globals.seriesX[a].length || (n = s.globals.maxValsInArrayIndex), s.globals.seriesX[n][r] && (t = (s.globals.seriesX[n][r] - s.globals.minX) / this.xRatio - i * this.seriesLen / 2), { barXPosition: t + i * this.visibleI, x: t };
    } }, { key: "getPreviousPath", value: function(e, t) {
      for (var i, a = this.w, r = 0; r < a.globals.previousPaths.length; r++) {
        var s = a.globals.previousPaths[r];
        s.paths && s.paths.length > 0 && parseInt(s.realIndex, 10) === parseInt(e, 10) && a.globals.previousPaths[r].paths[t] !== void 0 && (i = a.globals.previousPaths[r].paths[t].d);
      }
      return i;
    } }]), y;
  }(), ot = function(y) {
    be(t, fe);
    var e = xe(t);
    function t() {
      return R(this, t), e.apply(this, arguments);
    }
    return F(t, [{ key: "draw", value: function(i, a) {
      var r = this, s = this.w;
      this.graphics = new X(this.ctx), this.bar = new fe(this.ctx, this.xyRatios);
      var n = new $(this.ctx, s);
      i = n.getLogSeries(i), this.yRatio = n.getLogYRatios(this.yRatio), this.barHelpers.initVariables(i), s.config.chart.stackType === "100%" && (i = s.globals.comboCharts ? a.map(function(x) {
        return s.globals.seriesPercent[x];
      }) : s.globals.seriesPercent.slice()), this.series = i, this.barHelpers.initializeStackedPrevVars(this);
      for (var o = this.graphics.group({ class: "apexcharts-bar-series apexcharts-plot-series" }), h = 0, d = 0, c = function(x, f) {
        var m = void 0, v = void 0, w = void 0, l = void 0, u = s.globals.comboCharts ? a[x] : x, b = r.barHelpers.getGroupIndex(u), A = b.groupIndex, k = b.columnGroupIndex;
        r.groupCtx = r[s.globals.seriesGroups[A]];
        var S = [], C = [], L = 0;
        r.yRatio.length > 1 && (r.yaxisIndex = s.globals.seriesYAxisReverseMap[u][0], L = u), r.isReversed = s.config.yaxis[r.yaxisIndex] && s.config.yaxis[r.yaxisIndex].reversed;
        var M = r.graphics.group({ class: "apexcharts-series", seriesName: P.escapeString(s.globals.seriesNames[u]), rel: x + 1, "data:realIndex": u });
        r.ctx.series.addCollapsedClassToSeries(M, u);
        var T = r.graphics.group({ class: "apexcharts-datalabels", "data:realIndex": u }), I = r.graphics.group({ class: "apexcharts-bar-goals-markers" }), z = 0, Y = 0, D = r.initialPositions(h, d, m, v, w, l, L);
        d = D.y, z = D.barHeight, v = D.yDivision, l = D.zeroW, h = D.x, Y = D.barWidth, m = D.xDivision, w = D.zeroH, s.globals.barHeight = z, s.globals.barWidth = Y, r.barHelpers.initializeStackedXYVars(r), r.groupCtx.prevY.length === 1 && r.groupCtx.prevY[0].every(function(U) {
          return isNaN(U);
        }) && (r.groupCtx.prevY[0] = r.groupCtx.prevY[0].map(function() {
          return w;
        }), r.groupCtx.prevYF[0] = r.groupCtx.prevYF[0].map(function() {
          return 0;
        }));
        for (var H = 0; H < s.globals.dataPoints; H++) {
          var O = r.barHelpers.getStrokeWidth(x, H, u), B = { indexes: { i: x, j: H, realIndex: u, translationsIndex: L, bc: f }, strokeWidth: O, x: h, y: d, elSeries: M, columnGroupIndex: k, seriesGroup: s.globals.seriesGroups[A] }, N = null;
          r.isHorizontal ? (N = r.drawStackedBarPaths(E(E({}, B), {}, { zeroW: l, barHeight: z, yDivision: v })), Y = r.series[x][H] / r.invertedYRatio) : (N = r.drawStackedColumnPaths(E(E({}, B), {}, { xDivision: m, barWidth: Y, zeroH: w })), z = r.series[x][H] / r.yRatio[L]);
          var W = r.barHelpers.drawGoalLine({ barXPosition: N.barXPosition, barYPosition: N.barYPosition, goalX: N.goalX, goalY: N.goalY, barHeight: z, barWidth: Y });
          W && I.add(W), d = N.y, h = N.x, S.push(h), C.push(d);
          var q = r.barHelpers.getPathFillColor(i, x, H, u), Z = "";
          s.globals.isBarHorizontal ? r.barHelpers.arrBorderRadius[u][H] === "bottom" && s.globals.series[u][H] > 0 && (Z = "apexcharts-flip-x") : r.barHelpers.arrBorderRadius[u][H] === "bottom" && s.globals.series[u][H] > 0 && (Z = "apexcharts-flip-y"), M = r.renderSeries({ realIndex: u, pathFill: q, j: H, i: x, columnGroupIndex: k, pathFrom: N.pathFrom, pathTo: N.pathTo, strokeWidth: O, elSeries: M, x: h, y: d, series: i, barHeight: z, barWidth: Y, elDataLabelsWrap: T, elGoalsMarkers: I, type: "bar", visibleSeries: k, classes: Z });
        }
        s.globals.seriesXvalues[u] = S, s.globals.seriesYvalues[u] = C, r.groupCtx.prevY.push(r.groupCtx.yArrj), r.groupCtx.prevYF.push(r.groupCtx.yArrjF), r.groupCtx.prevYVal.push(r.groupCtx.yArrjVal), r.groupCtx.prevX.push(r.groupCtx.xArrj), r.groupCtx.prevXF.push(r.groupCtx.xArrjF), r.groupCtx.prevXVal.push(r.groupCtx.xArrjVal), o.add(M);
      }, g = 0, p = 0; g < i.length; g++, p++)
        c(g, p);
      return o;
    } }, { key: "initialPositions", value: function(i, a, r, s, n, o, h) {
      var d, c, g = this.w;
      if (this.isHorizontal) {
        s = g.globals.gridHeight / g.globals.dataPoints;
        var p = g.config.plotOptions.bar.barHeight;
        d = String(p).indexOf("%") === -1 ? parseInt(p, 10) : s * parseInt(p, 10) / 100, o = g.globals.padHorizontal + (this.isReversed ? g.globals.gridWidth - this.baseLineInvertedY : this.baseLineInvertedY), a = (s - d) / 2;
      } else {
        c = r = g.globals.gridWidth / g.globals.dataPoints;
        var x = g.config.plotOptions.bar.columnWidth;
        g.globals.isXNumeric && g.globals.dataPoints > 1 ? c = (r = g.globals.minXDiff / this.xRatio) * parseInt(this.barOptions.columnWidth, 10) / 100 : String(x).indexOf("%") === -1 ? c = parseInt(x, 10) : c *= parseInt(x, 10) / 100, n = this.isReversed ? this.baseLineY[h] : g.globals.gridHeight - this.baseLineY[h], i = g.globals.padHorizontal + (r - c) / 2;
      }
      var f = g.globals.barGroups.length || 1;
      return { x: i, y: a, yDivision: s, xDivision: r, barHeight: d / f, barWidth: c / f, zeroH: n, zeroW: o };
    } }, { key: "drawStackedBarPaths", value: function(i) {
      for (var a, r = i.indexes, s = i.barHeight, n = i.strokeWidth, o = i.zeroW, h = i.x, d = i.y, c = i.columnGroupIndex, g = i.seriesGroup, p = i.yDivision, x = i.elSeries, f = this.w, m = d + c * s, v = r.i, w = r.j, l = r.realIndex, u = r.translationsIndex, b = 0, A = 0; A < this.groupCtx.prevXF.length; A++)
        b += this.groupCtx.prevXF[A][w];
      var k;
      if ((k = g.indexOf(f.config.series[l].name)) > 0) {
        var S = o;
        this.groupCtx.prevXVal[k - 1][w] < 0 ? S = this.series[v][w] >= 0 ? this.groupCtx.prevX[k - 1][w] + b - 2 * (this.isReversed ? b : 0) : this.groupCtx.prevX[k - 1][w] : this.groupCtx.prevXVal[k - 1][w] >= 0 && (S = this.series[v][w] >= 0 ? this.groupCtx.prevX[k - 1][w] : this.groupCtx.prevX[k - 1][w] - b + 2 * (this.isReversed ? b : 0)), a = S;
      } else
        a = o;
      h = this.series[v][w] === null ? a : a + this.series[v][w] / this.invertedYRatio - 2 * (this.isReversed ? this.series[v][w] / this.invertedYRatio : 0);
      var C = this.barHelpers.getBarpaths({ barYPosition: m, barHeight: s, x1: a, x2: h, strokeWidth: n, isReversed: this.isReversed, series: this.series, realIndex: r.realIndex, seriesGroup: g, i: v, j: w, w: f });
      return this.barHelpers.barBackground({ j: w, i: v, y1: m, y2: s, elSeries: x }), d += p, { pathTo: C.pathTo, pathFrom: C.pathFrom, goalX: this.barHelpers.getGoalValues("x", o, null, v, w, u), barXPosition: a, barYPosition: m, x: h, y: d };
    } }, { key: "drawStackedColumnPaths", value: function(i) {
      var a = i.indexes, r = i.x, s = i.y, n = i.xDivision, o = i.barWidth, h = i.zeroH, d = i.columnGroupIndex, c = i.seriesGroup, g = i.elSeries, p = this.w, x = a.i, f = a.j, m = a.bc, v = a.realIndex, w = a.translationsIndex;
      if (p.globals.isXNumeric) {
        var l = p.globals.seriesX[v][f];
        l || (l = 0), r = (l - p.globals.minX) / this.xRatio - o / 2 * p.globals.barGroups.length;
      }
      for (var u, b = r + d * o, A = 0, k = 0; k < this.groupCtx.prevYF.length; k++)
        A += isNaN(this.groupCtx.prevYF[k][f]) ? 0 : this.groupCtx.prevYF[k][f];
      var S = x;
      if (c && (S = c.indexOf(p.globals.seriesNames[v])), S > 0 && !p.globals.isXNumeric || S > 0 && p.globals.isXNumeric && p.globals.seriesX[v - 1][f] === p.globals.seriesX[v][f]) {
        var C, L, M, T = Math.min(this.yRatio.length + 1, v + 1);
        if (this.groupCtx.prevY[S - 1] !== void 0 && this.groupCtx.prevY[S - 1].length)
          for (var I = 1; I < T; I++) {
            var z;
            if (!isNaN((z = this.groupCtx.prevY[S - I]) === null || z === void 0 ? void 0 : z[f])) {
              M = this.groupCtx.prevY[S - I][f];
              break;
            }
          }
        for (var Y = 1; Y < T; Y++) {
          var D, H;
          if (((D = this.groupCtx.prevYVal[S - Y]) === null || D === void 0 ? void 0 : D[f]) < 0) {
            L = this.series[x][f] >= 0 ? M - A + 2 * (this.isReversed ? A : 0) : M;
            break;
          }
          if (((H = this.groupCtx.prevYVal[S - Y]) === null || H === void 0 ? void 0 : H[f]) >= 0) {
            L = this.series[x][f] >= 0 ? M : M + A - 2 * (this.isReversed ? A : 0);
            break;
          }
        }
        L === void 0 && (L = p.globals.gridHeight), u = (C = this.groupCtx.prevYF[0]) !== null && C !== void 0 && C.every(function(B) {
          return B === 0;
        }) && this.groupCtx.prevYF.slice(1, S).every(function(B) {
          return B.every(function(N) {
            return isNaN(N);
          });
        }) ? h : L;
      } else
        u = h;
      s = this.series[x][f] ? u - this.series[x][f] / this.yRatio[w] + 2 * (this.isReversed ? this.series[x][f] / this.yRatio[w] : 0) : u;
      var O = this.barHelpers.getColumnPaths({ barXPosition: b, barWidth: o, y1: u, y2: s, yRatio: this.yRatio[w], strokeWidth: this.strokeWidth, isReversed: this.isReversed, series: this.series, seriesGroup: c, realIndex: a.realIndex, i: x, j: f, w: p });
      return this.barHelpers.barBackground({ bc: m, j: f, i: x, x1: b, x2: o, elSeries: g }), { pathTo: O.pathTo, pathFrom: O.pathFrom, goalY: this.barHelpers.getGoalValues("y", null, h, x, f), barXPosition: b, x: p.globals.isXNumeric ? r : r + n, y: s };
    } }]), t;
  }(), Oe = function(y) {
    be(t, fe);
    var e = xe(t);
    function t() {
      return R(this, t), e.apply(this, arguments);
    }
    return F(t, [{ key: "draw", value: function(i, a, r) {
      var s = this, n = this.w, o = new X(this.ctx), h = n.globals.comboCharts ? a : n.config.chart.type, d = new ne(this.ctx);
      this.candlestickOptions = this.w.config.plotOptions.candlestick, this.boxOptions = this.w.config.plotOptions.boxPlot, this.isHorizontal = n.config.plotOptions.bar.horizontal;
      var c = new $(this.ctx, n);
      i = c.getLogSeries(i), this.series = i, this.yRatio = c.getLogYRatios(this.yRatio), this.barHelpers.initVariables(i);
      for (var g = o.group({ class: "apexcharts-".concat(h, "-series apexcharts-plot-series") }), p = function(f) {
        s.isBoxPlot = n.config.chart.type === "boxPlot" || n.config.series[f].type === "boxPlot";
        var m, v, w, l, u = void 0, b = void 0, A = [], k = [], S = n.globals.comboCharts ? r[f] : f, C = s.barHelpers.getGroupIndex(S).columnGroupIndex, L = o.group({ class: "apexcharts-series", seriesName: P.escapeString(n.globals.seriesNames[S]), rel: f + 1, "data:realIndex": S });
        s.ctx.series.addCollapsedClassToSeries(L, S), i[f].length > 0 && (s.visibleI = s.visibleI + 1);
        var M, T, I = 0;
        s.yRatio.length > 1 && (s.yaxisIndex = n.globals.seriesYAxisReverseMap[S][0], I = S);
        var z = s.barHelpers.initialPositions();
        b = z.y, M = z.barHeight, v = z.yDivision, l = z.zeroW, u = z.x, T = z.barWidth, m = z.xDivision, w = z.zeroH, k.push(u + T / 2);
        for (var Y = o.group({ class: "apexcharts-datalabels", "data:realIndex": S }), D = function(O) {
          var B = s.barHelpers.getStrokeWidth(f, O, S), N = null, W = { indexes: { i: f, j: O, realIndex: S, translationsIndex: I }, x: u, y: b, strokeWidth: B, elSeries: L };
          N = s.isHorizontal ? s.drawHorizontalBoxPaths(E(E({}, W), {}, { yDivision: v, barHeight: M, zeroW: l })) : s.drawVerticalBoxPaths(E(E({}, W), {}, { xDivision: m, barWidth: T, zeroH: w })), b = N.y, u = N.x, O > 0 && k.push(u + T / 2), A.push(b), N.pathTo.forEach(function(q, Z) {
            var U = !s.isBoxPlot && s.candlestickOptions.wick.useFillColor ? N.color[Z] : n.globals.stroke.colors[f], se = d.fillPath({ seriesNumber: S, dataPointIndex: O, color: N.color[Z], value: i[f][O] });
            s.renderSeries({ realIndex: S, pathFill: se, lineFill: U, j: O, i: f, pathFrom: N.pathFrom, pathTo: q, strokeWidth: B, elSeries: L, x: u, y: b, series: i, columnGroupIndex: C, barHeight: M, barWidth: T, elDataLabelsWrap: Y, visibleSeries: s.visibleI, type: n.config.chart.type });
          });
        }, H = 0; H < n.globals.dataPoints; H++)
          D(H);
        n.globals.seriesXvalues[S] = k, n.globals.seriesYvalues[S] = A, g.add(L);
      }, x = 0; x < i.length; x++)
        p(x);
      return g;
    } }, { key: "drawVerticalBoxPaths", value: function(i) {
      var a = i.indexes, r = i.x;
      i.y;
      var s = i.xDivision, n = i.barWidth, o = i.zeroH, h = i.strokeWidth, d = this.w, c = new X(this.ctx), g = a.i, p = a.j, x = !0, f = d.config.plotOptions.candlestick.colors.upward, m = d.config.plotOptions.candlestick.colors.downward, v = "";
      this.isBoxPlot && (v = [this.boxOptions.colors.lower, this.boxOptions.colors.upper]);
      var w = this.yRatio[a.translationsIndex], l = a.realIndex, u = this.getOHLCValue(l, p), b = o, A = o;
      u.o > u.c && (x = !1);
      var k = Math.min(u.o, u.c), S = Math.max(u.o, u.c), C = u.m;
      d.globals.isXNumeric && (r = (d.globals.seriesX[l][p] - d.globals.minX) / this.xRatio - n / 2);
      var L = r + n * this.visibleI;
      this.series[g][p] === void 0 || this.series[g][p] === null ? (k = o, S = o) : (k = o - k / w, S = o - S / w, b = o - u.h / w, A = o - u.l / w, C = o - u.m / w);
      var M = c.move(L, o), T = c.move(L + n / 2, k);
      return d.globals.previousPaths.length > 0 && (T = this.getPreviousPath(l, p, !0)), M = this.isBoxPlot ? [c.move(L, k) + c.line(L + n / 2, k) + c.line(L + n / 2, b) + c.line(L + n / 4, b) + c.line(L + n - n / 4, b) + c.line(L + n / 2, b) + c.line(L + n / 2, k) + c.line(L + n, k) + c.line(L + n, C) + c.line(L, C) + c.line(L, k + h / 2), c.move(L, C) + c.line(L + n, C) + c.line(L + n, S) + c.line(L + n / 2, S) + c.line(L + n / 2, A) + c.line(L + n - n / 4, A) + c.line(L + n / 4, A) + c.line(L + n / 2, A) + c.line(L + n / 2, S) + c.line(L, S) + c.line(L, C) + "z"] : [c.move(L, S) + c.line(L + n / 2, S) + c.line(L + n / 2, b) + c.line(L + n / 2, S) + c.line(L + n, S) + c.line(L + n, k) + c.line(L + n / 2, k) + c.line(L + n / 2, A) + c.line(L + n / 2, k) + c.line(L, k) + c.line(L, S - h / 2)], T += c.move(L, k), d.globals.isXNumeric || (r += s), { pathTo: M, pathFrom: T, x: r, y: S, barXPosition: L, color: this.isBoxPlot ? v : x ? [f] : [m] };
    } }, { key: "drawHorizontalBoxPaths", value: function(i) {
      var a = i.indexes;
      i.x;
      var r = i.y, s = i.yDivision, n = i.barHeight, o = i.zeroW, h = i.strokeWidth, d = this.w, c = new X(this.ctx), g = a.i, p = a.j, x = this.boxOptions.colors.lower;
      this.isBoxPlot && (x = [this.boxOptions.colors.lower, this.boxOptions.colors.upper]);
      var f = this.invertedYRatio, m = a.realIndex, v = this.getOHLCValue(m, p), w = o, l = o, u = Math.min(v.o, v.c), b = Math.max(v.o, v.c), A = v.m;
      d.globals.isXNumeric && (r = (d.globals.seriesX[m][p] - d.globals.minX) / this.invertedXRatio - n / 2);
      var k = r + n * this.visibleI;
      this.series[g][p] === void 0 || this.series[g][p] === null ? (u = o, b = o) : (u = o + u / f, b = o + b / f, w = o + v.h / f, l = o + v.l / f, A = o + v.m / f);
      var S = c.move(o, k), C = c.move(u, k + n / 2);
      return d.globals.previousPaths.length > 0 && (C = this.getPreviousPath(m, p, !0)), S = [c.move(u, k) + c.line(u, k + n / 2) + c.line(w, k + n / 2) + c.line(w, k + n / 2 - n / 4) + c.line(w, k + n / 2 + n / 4) + c.line(w, k + n / 2) + c.line(u, k + n / 2) + c.line(u, k + n) + c.line(A, k + n) + c.line(A, k) + c.line(u + h / 2, k), c.move(A, k) + c.line(A, k + n) + c.line(b, k + n) + c.line(b, k + n / 2) + c.line(l, k + n / 2) + c.line(l, k + n - n / 4) + c.line(l, k + n / 4) + c.line(l, k + n / 2) + c.line(b, k + n / 2) + c.line(b, k) + c.line(A, k) + "z"], C += c.move(u, k), d.globals.isXNumeric || (r += s), { pathTo: S, pathFrom: C, x: b, y: r, barYPosition: k, color: x };
    } }, { key: "getOHLCValue", value: function(i, a) {
      var r = this.w;
      return { o: this.isBoxPlot ? r.globals.seriesCandleH[i][a] : r.globals.seriesCandleO[i][a], h: this.isBoxPlot ? r.globals.seriesCandleO[i][a] : r.globals.seriesCandleH[i][a], m: r.globals.seriesCandleM[i][a], l: this.isBoxPlot ? r.globals.seriesCandleC[i][a] : r.globals.seriesCandleL[i][a], c: this.isBoxPlot ? r.globals.seriesCandleL[i][a] : r.globals.seriesCandleC[i][a] };
    } }]), t;
  }(), lt = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "checkColorRange", value: function() {
      var e = this.w, t = !1, i = e.config.plotOptions[e.config.chart.type];
      return i.colorScale.ranges.length > 0 && i.colorScale.ranges.map(function(a, r) {
        a.from <= 0 && (t = !0);
      }), t;
    } }, { key: "getShadeColor", value: function(e, t, i, a) {
      var r = this.w, s = 1, n = r.config.plotOptions[e].shadeIntensity, o = this.determineColor(e, t, i);
      r.globals.hasNegs || a ? s = r.config.plotOptions[e].reverseNegativeShade ? o.percent < 0 ? o.percent / 100 * (1.25 * n) : (1 - o.percent / 100) * (1.25 * n) : o.percent <= 0 ? 1 - (1 + o.percent / 100) * n : (1 - o.percent / 100) * n : (s = 1 - o.percent / 100, e === "treemap" && (s = (1 - o.percent / 100) * (1.25 * n)));
      var h = o.color, d = new P();
      if (r.config.plotOptions[e].enableShades)
        if (this.w.config.theme.mode === "dark") {
          var c = d.shadeColor(-1 * s, o.color);
          h = P.hexToRgba(P.isColorHex(c) ? c : P.rgb2hex(c), r.config.fill.opacity);
        } else {
          var g = d.shadeColor(s, o.color);
          h = P.hexToRgba(P.isColorHex(g) ? g : P.rgb2hex(g), r.config.fill.opacity);
        }
      return { color: h, colorProps: o };
    } }, { key: "determineColor", value: function(e, t, i) {
      var a = this.w, r = a.globals.series[t][i], s = a.config.plotOptions[e], n = s.colorScale.inverse ? i : t;
      s.distributed && a.config.chart.type === "treemap" && (n = i);
      var o = a.globals.colors[n], h = null, d = Math.min.apply(Math, J(a.globals.series[t])), c = Math.max.apply(Math, J(a.globals.series[t]));
      s.distributed || e !== "heatmap" || (d = a.globals.minY, c = a.globals.maxY), s.colorScale.min !== void 0 && (d = s.colorScale.min < a.globals.minY ? s.colorScale.min : a.globals.minY, c = s.colorScale.max > a.globals.maxY ? s.colorScale.max : a.globals.maxY);
      var g = Math.abs(c) + Math.abs(d), p = 100 * r / (g === 0 ? g - 1e-6 : g);
      return s.colorScale.ranges.length > 0 && s.colorScale.ranges.map(function(x, f) {
        if (r >= x.from && r <= x.to) {
          o = x.color, h = x.foreColor ? x.foreColor : null, d = x.from, c = x.to;
          var m = Math.abs(c) + Math.abs(d);
          p = 100 * r / (m === 0 ? m - 1e-6 : m);
        }
      }), { color: o, foreColor: h, percent: p };
    } }, { key: "calculateDataLabels", value: function(e) {
      var t = e.text, i = e.x, a = e.y, r = e.i, s = e.j, n = e.colorProps, o = e.fontSize, h = this.w.config.dataLabels, d = new X(this.ctx), c = new pe(this.ctx), g = null;
      if (h.enabled) {
        g = d.group({ class: "apexcharts-data-labels" });
        var p = h.offsetX, x = h.offsetY, f = i + p, m = a + parseFloat(h.style.fontSize) / 3 + x;
        c.plotDataLabelsText({ x: f, y: m, text: t, i: r, j: s, color: n.foreColor, parent: g, fontSize: o, dataLabelsConfig: h });
      }
      return g;
    } }, { key: "addListeners", value: function(e) {
      var t = new X(this.ctx);
      e.node.addEventListener("mouseenter", t.pathMouseEnter.bind(this, e)), e.node.addEventListener("mouseleave", t.pathMouseLeave.bind(this, e)), e.node.addEventListener("mousedown", t.pathMouseDown.bind(this, e));
    } }]), y;
  }(), Ht = function() {
    function y(e, t) {
      R(this, y), this.ctx = e, this.w = e.w, this.xRatio = t.xRatio, this.yRatio = t.yRatio, this.dynamicAnim = this.w.config.chart.animations.dynamicAnimation, this.helpers = new lt(e), this.rectRadius = this.w.config.plotOptions.heatmap.radius, this.strokeWidth = this.w.config.stroke.show ? this.w.config.stroke.width : 0;
    }
    return F(y, [{ key: "draw", value: function(e) {
      var t = this.w, i = new X(this.ctx), a = i.group({ class: "apexcharts-heatmap" });
      a.attr("clip-path", "url(#gridRectMask".concat(t.globals.cuid, ")"));
      var r = t.globals.gridWidth / t.globals.dataPoints, s = t.globals.gridHeight / t.globals.series.length, n = 0, o = !1;
      this.negRange = this.helpers.checkColorRange();
      var h = e.slice();
      t.config.yaxis[0].reversed && (o = !0, h.reverse());
      for (var d = o ? 0 : h.length - 1; o ? d < h.length : d >= 0; o ? d++ : d--) {
        var c = i.group({ class: "apexcharts-series apexcharts-heatmap-series", seriesName: P.escapeString(t.globals.seriesNames[d]), rel: d + 1, "data:realIndex": d });
        if (this.ctx.series.addCollapsedClassToSeries(c, d), t.config.chart.dropShadow.enabled) {
          var g = t.config.chart.dropShadow;
          new ee(this.ctx).dropShadow(c, g, d);
        }
        for (var p = 0, x = t.config.plotOptions.heatmap.shadeIntensity, f = 0; f < h[d].length; f++) {
          var m = this.helpers.getShadeColor(t.config.chart.type, d, f, this.negRange), v = m.color, w = m.colorProps;
          t.config.fill.type === "image" && (v = new ne(this.ctx).fillPath({ seriesNumber: d, dataPointIndex: f, opacity: t.globals.hasNegs ? w.percent < 0 ? 1 - (1 + w.percent / 100) : x + w.percent / 100 : w.percent / 100, patternID: P.randomId(), width: t.config.fill.image.width ? t.config.fill.image.width : r, height: t.config.fill.image.height ? t.config.fill.image.height : s }));
          var l = this.rectRadius, u = i.drawRect(p, n, r, s, l);
          if (u.attr({ cx: p, cy: n }), u.node.classList.add("apexcharts-heatmap-rect"), c.add(u), u.attr({ fill: v, i: d, index: d, j: f, val: e[d][f], "stroke-width": this.strokeWidth, stroke: t.config.plotOptions.heatmap.useFillColorAsStroke ? v : t.globals.stroke.colors[0], color: v }), this.helpers.addListeners(u), t.config.chart.animations.enabled && !t.globals.dataChanged) {
            var b = 1;
            t.globals.resized || (b = t.config.chart.animations.speed), this.animateHeatMap(u, p, n, r, s, b);
          }
          if (t.globals.dataChanged) {
            var A = 1;
            if (this.dynamicAnim.enabled && t.globals.shouldAnimate) {
              A = this.dynamicAnim.speed;
              var k = t.globals.previousPaths[d] && t.globals.previousPaths[d][f] && t.globals.previousPaths[d][f].color;
              k || (k = "rgba(255, 255, 255, 0)"), this.animateHeatColor(u, P.isColorHex(k) ? k : P.rgb2hex(k), P.isColorHex(v) ? v : P.rgb2hex(v), A);
            }
          }
          var S = (0, t.config.dataLabels.formatter)(t.globals.series[d][f], { value: t.globals.series[d][f], seriesIndex: d, dataPointIndex: f, w: t }), C = this.helpers.calculateDataLabels({ text: S, x: p + r / 2, y: n + s / 2, i: d, j: f, colorProps: w, series: h });
          C !== null && c.add(C), p += r;
        }
        n += s, a.add(c);
      }
      var L = t.globals.yAxisScale[0].result.slice();
      return t.config.yaxis[0].reversed ? L.unshift("") : L.push(""), t.globals.yAxisScale[0].result = L, a;
    } }, { key: "animateHeatMap", value: function(e, t, i, a, r, s) {
      var n = new ge(this.ctx);
      n.animateRect(e, { x: t + a / 2, y: i + r / 2, width: 0, height: 0 }, { x: t, y: i, width: a, height: r }, s, function() {
        n.animationCompleted(e);
      });
    } }, { key: "animateHeatColor", value: function(e, t, i, a) {
      e.attr({ fill: t }).animate(a).attr({ fill: i });
    } }]), y;
  }(), ht = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "drawYAxisTexts", value: function(e, t, i, a) {
      var r = this.w, s = r.config.yaxis[0], n = r.globals.yLabelFormatters[0];
      return new X(this.ctx).drawText({ x: e + s.labels.offsetX, y: t + s.labels.offsetY, text: n(a, i), textAnchor: "middle", fontSize: s.labels.style.fontSize, fontFamily: s.labels.style.fontFamily, foreColor: Array.isArray(s.labels.style.colors) ? s.labels.style.colors[i] : s.labels.style.colors });
    } }]), y;
  }(), ct = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
      var t = this.w;
      this.chartType = this.w.config.chart.type, this.initialAnim = this.w.config.chart.animations.enabled, this.dynamicAnim = this.initialAnim && this.w.config.chart.animations.dynamicAnimation.enabled, this.animBeginArr = [0], this.animDur = 0, this.donutDataLabels = this.w.config.plotOptions.pie.donut.labels, this.lineColorArr = t.globals.stroke.colors !== void 0 ? t.globals.stroke.colors : t.globals.colors, this.defaultSize = Math.min(t.globals.gridWidth, t.globals.gridHeight), this.centerY = this.defaultSize / 2, this.centerX = t.globals.gridWidth / 2, t.config.chart.type === "radialBar" ? this.fullAngle = 360 : this.fullAngle = Math.abs(t.config.plotOptions.pie.endAngle - t.config.plotOptions.pie.startAngle), this.initialAngle = t.config.plotOptions.pie.startAngle % this.fullAngle, t.globals.radialSize = this.defaultSize / 2.05 - t.config.stroke.width - (t.config.chart.sparkline.enabled ? 0 : t.config.chart.dropShadow.blur), this.donutSize = t.globals.radialSize * parseInt(t.config.plotOptions.pie.donut.size, 10) / 100;
      var i = t.config.plotOptions.pie.customScale, a = t.globals.gridWidth / 2, r = t.globals.gridHeight / 2;
      this.translateX = a - a * i, this.translateY = r - r * i, this.dataLabelsGroup = new X(this.ctx).group({ class: "apexcharts-datalabels-group", transform: "translate(".concat(this.translateX, ", ").concat(this.translateY, ") scale(").concat(i, ")") }), this.maxY = 0, this.sliceLabels = [], this.sliceSizes = [], this.prevSectorAngleArr = [];
    }
    return F(y, [{ key: "draw", value: function(e) {
      var t = this, i = this.w, a = new X(this.ctx), r = a.group({ class: "apexcharts-pie" });
      if (i.globals.noData)
        return r;
      for (var s = 0, n = 0; n < e.length; n++)
        s += P.negToZero(e[n]);
      var o = [], h = a.group();
      s === 0 && (s = 1e-5), e.forEach(function(l) {
        t.maxY = Math.max(t.maxY, l);
      }), i.config.yaxis[0].max && (this.maxY = i.config.yaxis[0].max), i.config.grid.position === "back" && this.chartType === "polarArea" && this.drawPolarElements(r);
      for (var d = 0; d < e.length; d++) {
        var c = this.fullAngle * P.negToZero(e[d]) / s;
        o.push(c), this.chartType === "polarArea" ? (o[d] = this.fullAngle / e.length, this.sliceSizes.push(i.globals.radialSize * e[d] / this.maxY)) : this.sliceSizes.push(i.globals.radialSize);
      }
      if (i.globals.dataChanged) {
        for (var g, p = 0, x = 0; x < i.globals.previousPaths.length; x++)
          p += P.negToZero(i.globals.previousPaths[x]);
        for (var f = 0; f < i.globals.previousPaths.length; f++)
          g = this.fullAngle * P.negToZero(i.globals.previousPaths[f]) / p, this.prevSectorAngleArr.push(g);
      }
      if (this.donutSize < 0 && (this.donutSize = 0), this.chartType === "donut") {
        var m = a.drawCircle(this.donutSize);
        m.attr({ cx: this.centerX, cy: this.centerY, fill: i.config.plotOptions.pie.donut.background ? i.config.plotOptions.pie.donut.background : "transparent" }), h.add(m);
      }
      var v = this.drawArcs(o, e);
      if (this.sliceLabels.forEach(function(l) {
        v.add(l);
      }), h.attr({ transform: "translate(".concat(this.translateX, ", ").concat(this.translateY, ") scale(").concat(i.config.plotOptions.pie.customScale, ")") }), h.add(v), r.add(h), this.donutDataLabels.show) {
        var w = this.renderInnerDataLabels(this.dataLabelsGroup, this.donutDataLabels, { hollowSize: this.donutSize, centerX: this.centerX, centerY: this.centerY, opacity: this.donutDataLabels.show });
        r.add(w);
      }
      return i.config.grid.position === "front" && this.chartType === "polarArea" && this.drawPolarElements(r), r;
    } }, { key: "drawArcs", value: function(e, t) {
      var i = this.w, a = new ee(this.ctx), r = new X(this.ctx), s = new ne(this.ctx), n = r.group({ class: "apexcharts-slices" }), o = this.initialAngle, h = this.initialAngle, d = this.initialAngle, c = this.initialAngle;
      this.strokeWidth = i.config.stroke.show ? i.config.stroke.width : 0;
      for (var g = 0; g < e.length; g++) {
        var p = r.group({ class: "apexcharts-series apexcharts-pie-series", seriesName: P.escapeString(i.globals.seriesNames[g]), rel: g + 1, "data:realIndex": g });
        n.add(p), h = c, d = (o = d) + e[g], c = h + this.prevSectorAngleArr[g];
        var x = d < o ? this.fullAngle + d - o : d - o, f = s.fillPath({ seriesNumber: g, size: this.sliceSizes[g], value: t[g] }), m = this.getChangedPath(h, c), v = r.drawPath({ d: m, stroke: Array.isArray(this.lineColorArr) ? this.lineColorArr[g] : this.lineColorArr, strokeWidth: 0, fill: f, fillOpacity: i.config.fill.opacity, classes: "apexcharts-pie-area apexcharts-".concat(this.chartType.toLowerCase(), "-slice-").concat(g) });
        if (v.attr({ index: 0, j: g }), a.setSelectionFilter(v, 0, g), i.config.chart.dropShadow.enabled) {
          var w = i.config.chart.dropShadow;
          a.dropShadow(v, w, g);
        }
        this.addListeners(v, this.donutDataLabels), X.setAttrs(v.node, { "data:angle": x, "data:startAngle": o, "data:strokeWidth": this.strokeWidth, "data:value": t[g] });
        var l = { x: 0, y: 0 };
        this.chartType === "pie" || this.chartType === "polarArea" ? l = P.polarToCartesian(this.centerX, this.centerY, i.globals.radialSize / 1.25 + i.config.plotOptions.pie.dataLabels.offset, (o + x / 2) % this.fullAngle) : this.chartType === "donut" && (l = P.polarToCartesian(this.centerX, this.centerY, (i.globals.radialSize + this.donutSize) / 2 + i.config.plotOptions.pie.dataLabels.offset, (o + x / 2) % this.fullAngle)), p.add(v);
        var u = 0;
        if (!this.initialAnim || i.globals.resized || i.globals.dataChanged ? this.animBeginArr.push(0) : ((u = x / this.fullAngle * i.config.chart.animations.speed) === 0 && (u = 1), this.animDur = u + this.animDur, this.animBeginArr.push(this.animDur)), this.dynamicAnim && i.globals.dataChanged ? this.animatePaths(v, { size: this.sliceSizes[g], endAngle: d, startAngle: o, prevStartAngle: h, prevEndAngle: c, animateStartingPos: !0, i: g, animBeginArr: this.animBeginArr, shouldSetPrevPaths: !0, dur: i.config.chart.animations.dynamicAnimation.speed }) : this.animatePaths(v, { size: this.sliceSizes[g], endAngle: d, startAngle: o, i: g, totalItems: e.length - 1, animBeginArr: this.animBeginArr, dur: u }), i.config.plotOptions.pie.expandOnClick && this.chartType !== "polarArea" && v.node.addEventListener("mouseup", this.pieClicked.bind(this, g)), i.globals.selectedDataPoints[0] !== void 0 && i.globals.selectedDataPoints[0].indexOf(g) > -1 && this.pieClicked(g), i.config.dataLabels.enabled) {
          var b = l.x, A = l.y, k = 100 * x / this.fullAngle + "%";
          if (x !== 0 && i.config.plotOptions.pie.dataLabels.minAngleToShowLabel < e[g]) {
            var S = i.config.dataLabels.formatter;
            S !== void 0 && (k = S(i.globals.seriesPercent[g][0], { seriesIndex: g, w: i }));
            var C = i.globals.dataLabels.style.colors[g], L = r.group({ class: "apexcharts-datalabels" }), M = r.drawText({ x: b, y: A, text: k, textAnchor: "middle", fontSize: i.config.dataLabels.style.fontSize, fontFamily: i.config.dataLabels.style.fontFamily, fontWeight: i.config.dataLabels.style.fontWeight, foreColor: C });
            if (L.add(M), i.config.dataLabels.dropShadow.enabled) {
              var T = i.config.dataLabels.dropShadow;
              a.dropShadow(M, T);
            }
            M.node.classList.add("apexcharts-pie-label"), i.config.chart.animations.animate && i.globals.resized === !1 && (M.node.classList.add("apexcharts-pie-label-delay"), M.node.style.animationDelay = i.config.chart.animations.speed / 940 + "s"), this.sliceLabels.push(L);
          }
        }
      }
      return n;
    } }, { key: "addListeners", value: function(e, t) {
      var i = new X(this.ctx);
      e.node.addEventListener("mouseenter", i.pathMouseEnter.bind(this, e)), e.node.addEventListener("mouseleave", i.pathMouseLeave.bind(this, e)), e.node.addEventListener("mouseleave", this.revertDataLabelsInner.bind(this, e.node, t)), e.node.addEventListener("mousedown", i.pathMouseDown.bind(this, e)), this.donutDataLabels.total.showAlways || (e.node.addEventListener("mouseenter", this.printDataLabelsInner.bind(this, e.node, t)), e.node.addEventListener("mousedown", this.printDataLabelsInner.bind(this, e.node, t)));
    } }, { key: "animatePaths", value: function(e, t) {
      var i = this.w, a = t.endAngle < t.startAngle ? this.fullAngle + t.endAngle - t.startAngle : t.endAngle - t.startAngle, r = a, s = t.startAngle, n = t.startAngle;
      t.prevStartAngle !== void 0 && t.prevEndAngle !== void 0 && (s = t.prevEndAngle, r = t.prevEndAngle < t.prevStartAngle ? this.fullAngle + t.prevEndAngle - t.prevStartAngle : t.prevEndAngle - t.prevStartAngle), t.i === i.config.series.length - 1 && (a + n > this.fullAngle ? t.endAngle = t.endAngle - (a + n) : a + n < this.fullAngle && (t.endAngle = t.endAngle + (this.fullAngle - (a + n)))), a === this.fullAngle && (a = this.fullAngle - 0.01), this.animateArc(e, s, n, a, r, t);
    } }, { key: "animateArc", value: function(e, t, i, a, r, s) {
      var n, o = this, h = this.w, d = new ge(this.ctx), c = s.size;
      (isNaN(t) || isNaN(r)) && (t = i, r = a, s.dur = 0);
      var g = a, p = i, x = t < i ? this.fullAngle + t - i : t - i;
      h.globals.dataChanged && s.shouldSetPrevPaths && s.prevEndAngle && (n = o.getPiePath({ me: o, startAngle: s.prevStartAngle, angle: s.prevEndAngle < s.prevStartAngle ? this.fullAngle + s.prevEndAngle - s.prevStartAngle : s.prevEndAngle - s.prevStartAngle, size: c }), e.attr({ d: n })), s.dur !== 0 ? e.animate(s.dur, h.globals.easing, s.animBeginArr[s.i]).afterAll(function() {
        o.chartType !== "pie" && o.chartType !== "donut" && o.chartType !== "polarArea" || this.animate(h.config.chart.animations.dynamicAnimation.speed).attr({ "stroke-width": o.strokeWidth }), s.i === h.config.series.length - 1 && d.animationCompleted(e);
      }).during(function(f) {
        g = x + (a - x) * f, s.animateStartingPos && (g = r + (a - r) * f, p = t - r + (i - (t - r)) * f), n = o.getPiePath({ me: o, startAngle: p, angle: g, size: c }), e.node.setAttribute("data:pathOrig", n), e.attr({ d: n });
      }) : (n = o.getPiePath({ me: o, startAngle: p, angle: a, size: c }), s.isTrack || (h.globals.animationEnded = !0), e.node.setAttribute("data:pathOrig", n), e.attr({ d: n, "stroke-width": o.strokeWidth }));
    } }, { key: "pieClicked", value: function(e) {
      var t, i = this.w, a = this, r = a.sliceSizes[e] + (i.config.plotOptions.pie.expandOnClick ? 4 : 0), s = i.globals.dom.Paper.select(".apexcharts-".concat(a.chartType.toLowerCase(), "-slice-").concat(e)).members[0];
      if (s.attr("data:pieClicked") !== "true") {
        var n = i.globals.dom.baseEl.getElementsByClassName("apexcharts-pie-area");
        Array.prototype.forEach.call(n, function(c) {
          c.setAttribute("data:pieClicked", "false");
          var g = c.getAttribute("data:pathOrig");
          g && c.setAttribute("d", g);
        }), i.globals.capturedDataPointIndex = e, s.attr("data:pieClicked", "true");
        var o = parseInt(s.attr("data:startAngle"), 10), h = parseInt(s.attr("data:angle"), 10);
        t = a.getPiePath({ me: a, startAngle: o, angle: h, size: r }), h !== 360 && s.plot(t);
      } else {
        s.attr({ "data:pieClicked": "false" }), this.revertDataLabelsInner(s.node, this.donutDataLabels);
        var d = s.attr("data:pathOrig");
        s.attr({ d });
      }
    } }, { key: "getChangedPath", value: function(e, t) {
      var i = "";
      return this.dynamicAnim && this.w.globals.dataChanged && (i = this.getPiePath({ me: this, startAngle: e, angle: t - e, size: this.size })), i;
    } }, { key: "getPiePath", value: function(e) {
      var t, i = e.me, a = e.startAngle, r = e.angle, s = e.size, n = new X(this.ctx), o = a, h = Math.PI * (o - 90) / 180, d = r + a;
      Math.ceil(d) >= this.fullAngle + this.w.config.plotOptions.pie.startAngle % this.fullAngle && (d = this.fullAngle + this.w.config.plotOptions.pie.startAngle % this.fullAngle - 0.01), Math.ceil(d) > this.fullAngle && (d -= this.fullAngle);
      var c = Math.PI * (d - 90) / 180, g = i.centerX + s * Math.cos(h), p = i.centerY + s * Math.sin(h), x = i.centerX + s * Math.cos(c), f = i.centerY + s * Math.sin(c), m = P.polarToCartesian(i.centerX, i.centerY, i.donutSize, d), v = P.polarToCartesian(i.centerX, i.centerY, i.donutSize, o), w = r > 180 ? 1 : 0, l = ["M", g, p, "A", s, s, 0, w, 1, x, f];
      return t = i.chartType === "donut" ? [].concat(l, ["L", m.x, m.y, "A", i.donutSize, i.donutSize, 0, w, 0, v.x, v.y, "L", g, p, "z"]).join(" ") : i.chartType === "pie" || i.chartType === "polarArea" ? [].concat(l, ["L", i.centerX, i.centerY, "L", g, p]).join(" ") : [].concat(l).join(" "), n.roundPathCorners(t, 2 * this.strokeWidth);
    } }, { key: "drawPolarElements", value: function(e) {
      var t = this.w, i = new tt(this.ctx), a = new X(this.ctx), r = new ht(this.ctx), s = a.group(), n = a.group(), o = i.niceScale(0, Math.ceil(this.maxY), 0), h = o.result.reverse(), d = o.result.length;
      this.maxY = o.niceMax;
      for (var c = t.globals.radialSize, g = c / (d - 1), p = 0; p < d - 1; p++) {
        var x = a.drawCircle(c);
        if (x.attr({ cx: this.centerX, cy: this.centerY, fill: "none", "stroke-width": t.config.plotOptions.polarArea.rings.strokeWidth, stroke: t.config.plotOptions.polarArea.rings.strokeColor }), t.config.yaxis[0].show) {
          var f = r.drawYAxisTexts(this.centerX, this.centerY - c + parseInt(t.config.yaxis[0].labels.style.fontSize, 10) / 2, p, h[p]);
          n.add(f);
        }
        s.add(x), c -= g;
      }
      this.drawSpokes(e), e.add(s), e.add(n);
    } }, { key: "renderInnerDataLabels", value: function(e, t, i) {
      var a = this.w, r = new X(this.ctx), s = t.total.show;
      e.node.innerHTML = "", e.node.style.opacity = i.opacity;
      var n, o, h = i.centerX, d = this.donutDataLabels.total.label ? i.centerY : i.centerY - i.centerY / 6;
      n = t.name.color === void 0 ? a.globals.colors[0] : t.name.color;
      var c = t.name.fontSize, g = t.name.fontFamily, p = t.name.fontWeight;
      o = t.value.color === void 0 ? a.config.chart.foreColor : t.value.color;
      var x = t.value.formatter, f = "", m = "";
      if (s ? (n = t.total.color, c = t.total.fontSize, g = t.total.fontFamily, p = t.total.fontWeight, m = this.donutDataLabels.total.label ? t.total.label : "", f = t.total.formatter(a)) : a.globals.series.length === 1 && (f = x(a.globals.series[0], a), m = a.globals.seriesNames[0]), m && (m = t.name.formatter(m, t.total.show, a)), t.name.show) {
        var v = r.drawText({ x: h, y: d + parseFloat(t.name.offsetY), text: m, textAnchor: "middle", foreColor: n, fontSize: c, fontWeight: p, fontFamily: g });
        v.node.classList.add("apexcharts-datalabel-label"), e.add(v);
      }
      if (t.value.show) {
        var w = t.name.show ? parseFloat(t.value.offsetY) + 16 : t.value.offsetY, l = r.drawText({ x: h, y: d + w, text: f, textAnchor: "middle", foreColor: o, fontWeight: t.value.fontWeight, fontSize: t.value.fontSize, fontFamily: t.value.fontFamily });
        l.node.classList.add("apexcharts-datalabel-value"), e.add(l);
      }
      return e;
    } }, { key: "printInnerLabels", value: function(e, t, i, a) {
      var r, s = this.w;
      a ? r = e.name.color === void 0 ? s.globals.colors[parseInt(a.parentNode.getAttribute("rel"), 10) - 1] : e.name.color : s.globals.series.length > 1 && e.total.show && (r = e.total.color);
      var n = s.globals.dom.baseEl.querySelector(".apexcharts-datalabel-label"), o = s.globals.dom.baseEl.querySelector(".apexcharts-datalabel-value");
      i = (0, e.value.formatter)(i, s), a || typeof e.total.formatter != "function" || (i = e.total.formatter(s));
      var h = t === e.total.label;
      t = this.donutDataLabels.total.label ? e.name.formatter(t, h, s) : "", n !== null && (n.textContent = t), o !== null && (o.textContent = i), n !== null && (n.style.fill = r);
    } }, { key: "printDataLabelsInner", value: function(e, t) {
      var i = this.w, a = e.getAttribute("data:value"), r = i.globals.seriesNames[parseInt(e.parentNode.getAttribute("rel"), 10) - 1];
      i.globals.series.length > 1 && this.printInnerLabels(t, r, a, e);
      var s = i.globals.dom.baseEl.querySelector(".apexcharts-datalabels-group");
      s !== null && (s.style.opacity = 1);
    } }, { key: "drawSpokes", value: function(e) {
      var t = this, i = this.w, a = new X(this.ctx), r = i.config.plotOptions.polarArea.spokes;
      if (r.strokeWidth !== 0) {
        for (var s = [], n = 360 / i.globals.series.length, o = 0; o < i.globals.series.length; o++)
          s.push(P.polarToCartesian(this.centerX, this.centerY, i.globals.radialSize, i.config.plotOptions.pie.startAngle + n * o));
        s.forEach(function(h, d) {
          var c = a.drawLine(h.x, h.y, t.centerX, t.centerY, Array.isArray(r.connectorColors) ? r.connectorColors[d] : r.connectorColors);
          e.add(c);
        });
      }
    } }, { key: "revertDataLabelsInner", value: function() {
      var e = this.w;
      if (this.donutDataLabels.show) {
        var t = e.globals.dom.Paper.select(".apexcharts-datalabels-group").members[0], i = this.renderInnerDataLabels(t, this.donutDataLabels, { hollowSize: this.donutSize, centerX: this.centerX, centerY: this.centerY, opacity: this.donutDataLabels.show });
        e.globals.dom.Paper.select(".apexcharts-radialbar, .apexcharts-pie").members[0].add(i);
      }
    } }]), y;
  }(), Ot = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.chartType = this.w.config.chart.type, this.initialAnim = this.w.config.chart.animations.enabled, this.dynamicAnim = this.initialAnim && this.w.config.chart.animations.dynamicAnimation.enabled, this.animDur = 0;
      var t = this.w;
      this.graphics = new X(this.ctx), this.lineColorArr = t.globals.stroke.colors !== void 0 ? t.globals.stroke.colors : t.globals.colors, this.defaultSize = t.globals.svgHeight < t.globals.svgWidth ? t.globals.gridHeight : t.globals.gridWidth, this.isLog = t.config.yaxis[0].logarithmic, this.logBase = t.config.yaxis[0].logBase, this.coreUtils = new $(this.ctx), this.maxValue = this.isLog ? this.coreUtils.getLogVal(this.logBase, t.globals.maxY, 0) : t.globals.maxY, this.minValue = this.isLog ? this.coreUtils.getLogVal(this.logBase, this.w.globals.minY, 0) : t.globals.minY, this.polygons = t.config.plotOptions.radar.polygons, this.strokeWidth = t.config.stroke.show ? t.config.stroke.width : 0, this.size = this.defaultSize / 2.1 - this.strokeWidth - t.config.chart.dropShadow.blur, t.config.xaxis.labels.show && (this.size = this.size - t.globals.xAxisLabelsWidth / 1.75), t.config.plotOptions.radar.size !== void 0 && (this.size = t.config.plotOptions.radar.size), this.dataRadiusOfPercent = [], this.dataRadius = [], this.angleArr = [], this.yaxisLabelsTextsPos = [];
    }
    return F(y, [{ key: "draw", value: function(e) {
      var t = this, i = this.w, a = new ne(this.ctx), r = [], s = new pe(this.ctx);
      e.length && (this.dataPointsLen = e[i.globals.maxValsInArrayIndex].length), this.disAngle = 2 * Math.PI / this.dataPointsLen;
      var n = i.globals.gridWidth / 2, o = i.globals.gridHeight / 2, h = n + i.config.plotOptions.radar.offsetX, d = o + i.config.plotOptions.radar.offsetY, c = this.graphics.group({ class: "apexcharts-radar-series apexcharts-plot-series", transform: "translate(".concat(h || 0, ", ").concat(d || 0, ")") }), g = [], p = null, x = null;
      if (this.yaxisLabels = this.graphics.group({ class: "apexcharts-yaxis" }), e.forEach(function(m, v) {
        var w = m.length === i.globals.dataPoints, l = t.graphics.group().attr({ class: "apexcharts-series", "data:longestSeries": w, seriesName: P.escapeString(i.globals.seriesNames[v]), rel: v + 1, "data:realIndex": v });
        t.dataRadiusOfPercent[v] = [], t.dataRadius[v] = [], t.angleArr[v] = [], m.forEach(function(I, z) {
          var Y = Math.abs(t.maxValue - t.minValue);
          I -= t.minValue, t.isLog && (I = t.coreUtils.getLogVal(t.logBase, I, 0)), t.dataRadiusOfPercent[v][z] = I / Y, t.dataRadius[v][z] = t.dataRadiusOfPercent[v][z] * t.size, t.angleArr[v][z] = z * t.disAngle;
        }), g = t.getDataPointsPos(t.dataRadius[v], t.angleArr[v]);
        var u = t.createPaths(g, { x: 0, y: 0 });
        p = t.graphics.group({ class: "apexcharts-series-markers-wrap apexcharts-element-hidden" }), x = t.graphics.group({ class: "apexcharts-datalabels", "data:realIndex": v }), i.globals.delayedElements.push({ el: p.node, index: v });
        var b = { i: v, realIndex: v, animationDelay: v, initialSpeed: i.config.chart.animations.speed, dataChangeSpeed: i.config.chart.animations.dynamicAnimation.speed, className: "apexcharts-radar", shouldClipToGrid: !1, bindEventsOnPaths: !1, stroke: i.globals.stroke.colors[v], strokeLineCap: i.config.stroke.lineCap }, A = null;
        i.globals.previousPaths.length > 0 && (A = t.getPreviousPath(v));
        for (var k = 0; k < u.linePathsTo.length; k++) {
          var S = t.graphics.renderPaths(E(E({}, b), {}, { pathFrom: A === null ? u.linePathsFrom[k] : A, pathTo: u.linePathsTo[k], strokeWidth: Array.isArray(t.strokeWidth) ? t.strokeWidth[v] : t.strokeWidth, fill: "none", drawShadow: !1 }));
          l.add(S);
          var C = a.fillPath({ seriesNumber: v }), L = t.graphics.renderPaths(E(E({}, b), {}, { pathFrom: A === null ? u.areaPathsFrom[k] : A, pathTo: u.areaPathsTo[k], strokeWidth: 0, fill: C, drawShadow: !1 }));
          if (i.config.chart.dropShadow.enabled) {
            var M = new ee(t.ctx), T = i.config.chart.dropShadow;
            M.dropShadow(L, Object.assign({}, T, { noUserSpaceOnUse: !0 }), v);
          }
          l.add(L);
        }
        m.forEach(function(I, z) {
          var Y = new ue(t.ctx).getMarkerConfig({ cssClass: "apexcharts-marker", seriesIndex: v, dataPointIndex: z }), D = t.graphics.drawMarker(g[z].x, g[z].y, Y);
          D.attr("rel", z), D.attr("j", z), D.attr("index", v), D.node.setAttribute("default-marker-size", Y.pSize);
          var H = t.graphics.group({ class: "apexcharts-series-markers" });
          H && H.add(D), p.add(H), l.add(p);
          var O = i.config.dataLabels;
          if (O.enabled) {
            var B = O.formatter(i.globals.series[v][z], { seriesIndex: v, dataPointIndex: z, w: i });
            s.plotDataLabelsText({ x: g[z].x, y: g[z].y, text: B, textAnchor: "middle", i: v, j: v, parent: x, offsetCorrection: !1, dataLabelsConfig: E({}, O) });
          }
          l.add(x);
        }), r.push(l);
      }), this.drawPolygons({ parent: c }), i.config.xaxis.labels.show) {
        var f = this.drawXAxisTexts();
        c.add(f);
      }
      return r.forEach(function(m) {
        c.add(m);
      }), c.add(this.yaxisLabels), c;
    } }, { key: "drawPolygons", value: function(e) {
      for (var t = this, i = this.w, a = e.parent, r = new ht(this.ctx), s = i.globals.yAxisScale[0].result.reverse(), n = s.length, o = [], h = this.size / (n - 1), d = 0; d < n; d++)
        o[d] = h * d;
      o.reverse();
      var c = [], g = [];
      o.forEach(function(p, x) {
        var f = P.getPolygonPos(p, t.dataPointsLen), m = "";
        f.forEach(function(v, w) {
          if (x === 0) {
            var l = t.graphics.drawLine(v.x, v.y, 0, 0, Array.isArray(t.polygons.connectorColors) ? t.polygons.connectorColors[w] : t.polygons.connectorColors);
            g.push(l);
          }
          w === 0 && t.yaxisLabelsTextsPos.push({ x: v.x, y: v.y }), m += v.x + "," + v.y + " ";
        }), c.push(m);
      }), c.forEach(function(p, x) {
        var f = t.polygons.strokeColors, m = t.polygons.strokeWidth, v = t.graphics.drawPolygon(p, Array.isArray(f) ? f[x] : f, Array.isArray(m) ? m[x] : m, i.globals.radarPolygons.fill.colors[x]);
        a.add(v);
      }), g.forEach(function(p) {
        a.add(p);
      }), i.config.yaxis[0].show && this.yaxisLabelsTextsPos.forEach(function(p, x) {
        var f = r.drawYAxisTexts(p.x, p.y, x, s[x]);
        t.yaxisLabels.add(f);
      });
    } }, { key: "drawXAxisTexts", value: function() {
      var e = this, t = this.w, i = t.config.xaxis.labels, a = this.graphics.group({ class: "apexcharts-xaxis" }), r = P.getPolygonPos(this.size, this.dataPointsLen);
      return t.globals.labels.forEach(function(s, n) {
        var o = t.config.xaxis.labels.formatter, h = new pe(e.ctx);
        if (r[n]) {
          var d = e.getTextPos(r[n], e.size), c = o(s, { seriesIndex: -1, dataPointIndex: n, w: t });
          h.plotDataLabelsText({ x: d.newX, y: d.newY, text: c, textAnchor: d.textAnchor, i: n, j: n, parent: a, className: "apexcharts-xaxis-label", color: Array.isArray(i.style.colors) && i.style.colors[n] ? i.style.colors[n] : "#a8a8a8", dataLabelsConfig: E({ textAnchor: d.textAnchor, dropShadow: { enabled: !1 } }, i), offsetCorrection: !1 }).on("click", function(g) {
            if (typeof t.config.chart.events.xAxisLabelClick == "function") {
              var p = Object.assign({}, t, { labelIndex: n });
              t.config.chart.events.xAxisLabelClick(g, e.ctx, p);
            }
          });
        }
      }), a;
    } }, { key: "createPaths", value: function(e, t) {
      var i = this, a = [], r = [], s = [], n = [];
      if (e.length) {
        r = [this.graphics.move(t.x, t.y)], n = [this.graphics.move(t.x, t.y)];
        var o = this.graphics.move(e[0].x, e[0].y), h = this.graphics.move(e[0].x, e[0].y);
        e.forEach(function(d, c) {
          o += i.graphics.line(d.x, d.y), h += i.graphics.line(d.x, d.y), c === e.length - 1 && (o += "Z", h += "Z");
        }), a.push(o), s.push(h);
      }
      return { linePathsFrom: r, linePathsTo: a, areaPathsFrom: n, areaPathsTo: s };
    } }, { key: "getTextPos", value: function(e, t) {
      var i = "middle", a = e.x, r = e.y;
      return Math.abs(e.x) >= 10 ? e.x > 0 ? (i = "start", a += 10) : e.x < 0 && (i = "end", a -= 10) : i = "middle", Math.abs(e.y) >= t - 10 && (e.y < 0 ? r -= 10 : e.y > 0 && (r += 10)), { textAnchor: i, newX: a, newY: r };
    } }, { key: "getPreviousPath", value: function(e) {
      for (var t = this.w, i = null, a = 0; a < t.globals.previousPaths.length; a++) {
        var r = t.globals.previousPaths[a];
        r.paths.length > 0 && parseInt(r.realIndex, 10) === parseInt(e, 10) && t.globals.previousPaths[a].paths[0] !== void 0 && (i = t.globals.previousPaths[a].paths[0].d);
      }
      return i;
    } }, { key: "getDataPointsPos", value: function(e, t) {
      var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.dataPointsLen;
      e = e || [], t = t || [];
      for (var a = [], r = 0; r < i; r++) {
        var s = {};
        s.x = e[r] * Math.sin(t[r]), s.y = -e[r] * Math.cos(t[r]), a.push(s);
      }
      return a;
    } }]), y;
  }(), Nt = function(y) {
    be(t, ct);
    var e = xe(t);
    function t(i) {
      var a;
      R(this, t), (a = e.call(this, i)).ctx = i, a.w = i.w, a.animBeginArr = [0], a.animDur = 0;
      var r = a.w;
      return a.startAngle = r.config.plotOptions.radialBar.startAngle, a.endAngle = r.config.plotOptions.radialBar.endAngle, a.totalAngle = Math.abs(r.config.plotOptions.radialBar.endAngle - r.config.plotOptions.radialBar.startAngle), a.trackStartAngle = r.config.plotOptions.radialBar.track.startAngle, a.trackEndAngle = r.config.plotOptions.radialBar.track.endAngle, a.barLabels = a.w.config.plotOptions.radialBar.barLabels, a.donutDataLabels = a.w.config.plotOptions.radialBar.dataLabels, a.radialDataLabels = a.donutDataLabels, a.trackStartAngle || (a.trackStartAngle = a.startAngle), a.trackEndAngle || (a.trackEndAngle = a.endAngle), a.endAngle === 360 && (a.endAngle = 359.99), a.margin = parseInt(r.config.plotOptions.radialBar.track.margin, 10), a.onBarLabelClick = a.onBarLabelClick.bind(je(a)), a;
    }
    return F(t, [{ key: "draw", value: function(i) {
      var a = this.w, r = new X(this.ctx), s = r.group({ class: "apexcharts-radialbar" });
      if (a.globals.noData)
        return s;
      var n = r.group(), o = this.defaultSize / 2, h = a.globals.gridWidth / 2, d = this.defaultSize / 2.05;
      a.config.chart.sparkline.enabled || (d = d - a.config.stroke.width - a.config.chart.dropShadow.blur);
      var c = a.globals.fill.colors;
      if (a.config.plotOptions.radialBar.track.show) {
        var g = this.drawTracks({ size: d, centerX: h, centerY: o, colorArr: c, series: i });
        n.add(g);
      }
      var p = this.drawArcs({ size: d, centerX: h, centerY: o, colorArr: c, series: i }), x = 360;
      a.config.plotOptions.radialBar.startAngle < 0 && (x = this.totalAngle);
      var f = (360 - x) / 360;
      if (a.globals.radialSize = d - d * f, this.radialDataLabels.value.show) {
        var m = Math.max(this.radialDataLabels.value.offsetY, this.radialDataLabels.name.offsetY);
        a.globals.radialSize += m * f;
      }
      return n.add(p.g), a.config.plotOptions.radialBar.hollow.position === "front" && (p.g.add(p.elHollow), p.dataLabels && p.g.add(p.dataLabels)), s.add(n), s;
    } }, { key: "drawTracks", value: function(i) {
      var a = this.w, r = new X(this.ctx), s = r.group({ class: "apexcharts-tracks" }), n = new ee(this.ctx), o = new ne(this.ctx), h = this.getStrokeWidth(i);
      i.size = i.size - h / 2;
      for (var d = 0; d < i.series.length; d++) {
        var c = r.group({ class: "apexcharts-radialbar-track apexcharts-track" });
        s.add(c), c.attr({ rel: d + 1 }), i.size = i.size - h - this.margin;
        var g = a.config.plotOptions.radialBar.track, p = o.fillPath({ seriesNumber: 0, size: i.size, fillColors: Array.isArray(g.background) ? g.background[d] : g.background, solid: !0 }), x = this.trackStartAngle, f = this.trackEndAngle;
        Math.abs(f) + Math.abs(x) >= 360 && (f = 360 - Math.abs(this.startAngle) - 0.1);
        var m = r.drawPath({ d: "", stroke: p, strokeWidth: h * parseInt(g.strokeWidth, 10) / 100, fill: "none", strokeOpacity: g.opacity, classes: "apexcharts-radialbar-area" });
        if (g.dropShadow.enabled) {
          var v = g.dropShadow;
          n.dropShadow(m, v);
        }
        c.add(m), m.attr("id", "apexcharts-radialbarTrack-" + d), this.animatePaths(m, { centerX: i.centerX, centerY: i.centerY, endAngle: f, startAngle: x, size: i.size, i: d, totalItems: 2, animBeginArr: 0, dur: 0, isTrack: !0, easing: a.globals.easing });
      }
      return s;
    } }, { key: "drawArcs", value: function(i) {
      var a = this.w, r = new X(this.ctx), s = new ne(this.ctx), n = new ee(this.ctx), o = r.group(), h = this.getStrokeWidth(i);
      i.size = i.size - h / 2;
      var d = a.config.plotOptions.radialBar.hollow.background, c = i.size - h * i.series.length - this.margin * i.series.length - h * parseInt(a.config.plotOptions.radialBar.track.strokeWidth, 10) / 100 / 2, g = c - a.config.plotOptions.radialBar.hollow.margin;
      a.config.plotOptions.radialBar.hollow.image !== void 0 && (d = this.drawHollowImage(i, o, c, d));
      var p = this.drawHollow({ size: g, centerX: i.centerX, centerY: i.centerY, fill: d || "transparent" });
      if (a.config.plotOptions.radialBar.hollow.dropShadow.enabled) {
        var x = a.config.plotOptions.radialBar.hollow.dropShadow;
        n.dropShadow(p, x);
      }
      var f = 1;
      !this.radialDataLabels.total.show && a.globals.series.length > 1 && (f = 0);
      var m = null;
      if (this.radialDataLabels.show) {
        var v = a.globals.dom.Paper.select(".apexcharts-datalabels-group").members[0];
        m = this.renderInnerDataLabels(v, this.radialDataLabels, { hollowSize: c, centerX: i.centerX, centerY: i.centerY, opacity: f });
      }
      a.config.plotOptions.radialBar.hollow.position === "back" && (o.add(p), m && o.add(m));
      var w = !1;
      a.config.plotOptions.radialBar.inverseOrder && (w = !0);
      for (var l = w ? i.series.length - 1 : 0; w ? l >= 0 : l < i.series.length; w ? l-- : l++) {
        var u = r.group({ class: "apexcharts-series apexcharts-radial-series", seriesName: P.escapeString(a.globals.seriesNames[l]) });
        o.add(u), u.attr({ rel: l + 1, "data:realIndex": l }), this.ctx.series.addCollapsedClassToSeries(u, l), i.size = i.size - h - this.margin;
        var b = s.fillPath({ seriesNumber: l, size: i.size, value: i.series[l] }), A = this.startAngle, k = void 0, S = P.negToZero(i.series[l] > 100 ? 100 : i.series[l]) / 100, C = Math.round(this.totalAngle * S) + this.startAngle, L = void 0;
        a.globals.dataChanged && (k = this.startAngle, L = Math.round(this.totalAngle * P.negToZero(a.globals.previousPaths[l]) / 100) + k), Math.abs(C) + Math.abs(A) > 360 && (C -= 0.01), Math.abs(L) + Math.abs(k) > 360 && (L -= 0.01);
        var M = C - A, T = Array.isArray(a.config.stroke.dashArray) ? a.config.stroke.dashArray[l] : a.config.stroke.dashArray, I = r.drawPath({ d: "", stroke: b, strokeWidth: h, fill: "none", fillOpacity: a.config.fill.opacity, classes: "apexcharts-radialbar-area apexcharts-radialbar-slice-" + l, strokeDashArray: T });
        if (X.setAttrs(I.node, { "data:angle": M, "data:value": i.series[l] }), a.config.chart.dropShadow.enabled) {
          var z = a.config.chart.dropShadow;
          n.dropShadow(I, z, l);
        }
        if (n.setSelectionFilter(I, 0, l), this.addListeners(I, this.radialDataLabels), u.add(I), I.attr({ index: 0, j: l }), this.barLabels.enabled) {
          var Y = P.polarToCartesian(i.centerX, i.centerY, i.size, A), D = this.barLabels.formatter(a.globals.seriesNames[l], { seriesIndex: l, w: a }), H = ["apexcharts-radialbar-label"];
          this.barLabels.onClick || H.push("apexcharts-no-click");
          var O = this.barLabels.useSeriesColors ? a.globals.colors[l] : a.config.chart.foreColor;
          O || (O = a.config.chart.foreColor);
          var B = Y.x + this.barLabels.offsetX, N = Y.y + this.barLabels.offsetY, W = r.drawText({ x: B, y: N, text: D, textAnchor: "end", dominantBaseline: "middle", fontFamily: this.barLabels.fontFamily, fontWeight: this.barLabels.fontWeight, fontSize: this.barLabels.fontSize, foreColor: O, cssClass: H.join(" ") });
          W.on("click", this.onBarLabelClick), W.attr({ rel: l + 1 }), A !== 0 && W.attr({ "transform-origin": "".concat(B, " ").concat(N), transform: "rotate(".concat(A, " 0 0)") }), u.add(W);
        }
        var q = 0;
        !this.initialAnim || a.globals.resized || a.globals.dataChanged || (q = a.config.chart.animations.speed), a.globals.dataChanged && (q = a.config.chart.animations.dynamicAnimation.speed), this.animDur = q / (1.2 * i.series.length) + this.animDur, this.animBeginArr.push(this.animDur), this.animatePaths(I, { centerX: i.centerX, centerY: i.centerY, endAngle: C, startAngle: A, prevEndAngle: L, prevStartAngle: k, size: i.size, i: l, totalItems: 2, animBeginArr: this.animBeginArr, dur: q, shouldSetPrevPaths: !0, easing: a.globals.easing });
      }
      return { g: o, elHollow: p, dataLabels: m };
    } }, { key: "drawHollow", value: function(i) {
      var a = new X(this.ctx).drawCircle(2 * i.size);
      return a.attr({ class: "apexcharts-radialbar-hollow", cx: i.centerX, cy: i.centerY, r: i.size, fill: i.fill }), a;
    } }, { key: "drawHollowImage", value: function(i, a, r, s) {
      var n = this.w, o = new ne(this.ctx), h = P.randomId(), d = n.config.plotOptions.radialBar.hollow.image;
      if (n.config.plotOptions.radialBar.hollow.imageClipped)
        o.clippedImgArea({ width: r, height: r, image: d, patternID: "pattern".concat(n.globals.cuid).concat(h) }), s = "url(#pattern".concat(n.globals.cuid).concat(h, ")");
      else {
        var c = n.config.plotOptions.radialBar.hollow.imageWidth, g = n.config.plotOptions.radialBar.hollow.imageHeight;
        if (c === void 0 && g === void 0) {
          var p = n.globals.dom.Paper.image(d).loaded(function(f) {
            this.move(i.centerX - f.width / 2 + n.config.plotOptions.radialBar.hollow.imageOffsetX, i.centerY - f.height / 2 + n.config.plotOptions.radialBar.hollow.imageOffsetY);
          });
          a.add(p);
        } else {
          var x = n.globals.dom.Paper.image(d).loaded(function(f) {
            this.move(i.centerX - c / 2 + n.config.plotOptions.radialBar.hollow.imageOffsetX, i.centerY - g / 2 + n.config.plotOptions.radialBar.hollow.imageOffsetY), this.size(c, g);
          });
          a.add(x);
        }
      }
      return s;
    } }, { key: "getStrokeWidth", value: function(i) {
      var a = this.w;
      return i.size * (100 - parseInt(a.config.plotOptions.radialBar.hollow.size, 10)) / 100 / (i.series.length + 1) - this.margin;
    } }, { key: "onBarLabelClick", value: function(i) {
      var a = parseInt(i.target.getAttribute("rel"), 10) - 1, r = this.barLabels.onClick, s = this.w;
      r && r(s.globals.seriesNames[a], { w: s, seriesIndex: a });
    } }]), t;
  }(), Bt = function(y) {
    be(t, fe);
    var e = xe(t);
    function t() {
      return R(this, t), e.apply(this, arguments);
    }
    return F(t, [{ key: "draw", value: function(i, a) {
      var r = this.w, s = new X(this.ctx);
      this.rangeBarOptions = this.w.config.plotOptions.rangeBar, this.series = i, this.seriesRangeStart = r.globals.seriesRangeStart, this.seriesRangeEnd = r.globals.seriesRangeEnd, this.barHelpers.initVariables(i);
      for (var n = s.group({ class: "apexcharts-rangebar-series apexcharts-plot-series" }), o = 0; o < i.length; o++) {
        var h, d, c, g, p = void 0, x = void 0, f = r.globals.comboCharts ? a[o] : o, m = this.barHelpers.getGroupIndex(f).columnGroupIndex, v = s.group({ class: "apexcharts-series", seriesName: P.escapeString(r.globals.seriesNames[f]), rel: o + 1, "data:realIndex": f });
        this.ctx.series.addCollapsedClassToSeries(v, f), i[o].length > 0 && (this.visibleI = this.visibleI + 1);
        var w = 0, l = 0, u = 0;
        this.yRatio.length > 1 && (this.yaxisIndex = r.globals.seriesYAxisReverseMap[f][0], u = f);
        var b = this.barHelpers.initialPositions();
        x = b.y, g = b.zeroW, p = b.x, l = b.barWidth, w = b.barHeight, h = b.xDivision, d = b.yDivision, c = b.zeroH;
        for (var A = s.group({ class: "apexcharts-datalabels", "data:realIndex": f }), k = s.group({ class: "apexcharts-rangebar-goals-markers" }), S = 0; S < r.globals.dataPoints; S++) {
          var C = this.barHelpers.getStrokeWidth(o, S, f), L = this.seriesRangeStart[o][S], M = this.seriesRangeEnd[o][S], T = null, I = null, z = null, Y = { x: p, y: x, strokeWidth: C, elSeries: v }, D = this.seriesLen;
          if (r.config.plotOptions.bar.rangeBarGroupRows && (D = 1), r.config.series[o].data[S] === void 0)
            break;
          if (this.isHorizontal) {
            z = x + w * this.visibleI;
            var H = (d - w * D) / 2;
            if (r.config.series[o].data[S].x) {
              var O = this.detectOverlappingBars({ i: o, j: S, barYPosition: z, srty: H, barHeight: w, yDivision: d, initPositions: b });
              w = O.barHeight, z = O.barYPosition;
            }
            l = (T = this.drawRangeBarPaths(E({ indexes: { i: o, j: S, realIndex: f }, barHeight: w, barYPosition: z, zeroW: g, yDivision: d, y1: L, y2: M }, Y))).barWidth;
          } else {
            r.globals.isXNumeric && (p = (r.globals.seriesX[o][S] - r.globals.minX) / this.xRatio - l / 2), I = p + l * this.visibleI;
            var B = (h - l * D) / 2;
            if (r.config.series[o].data[S].x) {
              var N = this.detectOverlappingBars({ i: o, j: S, barXPosition: I, srtx: B, barWidth: l, xDivision: h, initPositions: b });
              l = N.barWidth, I = N.barXPosition;
            }
            w = (T = this.drawRangeColumnPaths(E({ indexes: { i: o, j: S, realIndex: f, translationsIndex: u }, barWidth: l, barXPosition: I, zeroH: c, xDivision: h }, Y))).barHeight;
          }
          var W = this.barHelpers.drawGoalLine({ barXPosition: T.barXPosition, barYPosition: z, goalX: T.goalX, goalY: T.goalY, barHeight: w, barWidth: l });
          W && k.add(W), x = T.y, p = T.x;
          var q = this.barHelpers.getPathFillColor(i, o, S, f), Z = r.globals.stroke.colors[f];
          this.renderSeries({ realIndex: f, pathFill: q, lineFill: Z, j: S, i: o, x: p, y: x, y1: L, y2: M, pathFrom: T.pathFrom, pathTo: T.pathTo, strokeWidth: C, elSeries: v, series: i, barHeight: w, barWidth: l, barXPosition: I, barYPosition: z, columnGroupIndex: m, elDataLabelsWrap: A, elGoalsMarkers: k, visibleSeries: this.visibleI, type: "rangebar" });
        }
        n.add(v);
      }
      return n;
    } }, { key: "detectOverlappingBars", value: function(i) {
      var a = i.i, r = i.j, s = i.barYPosition, n = i.barXPosition, o = i.srty, h = i.srtx, d = i.barHeight, c = i.barWidth, g = i.yDivision, p = i.xDivision, x = i.initPositions, f = this.w, m = [], v = f.config.series[a].data[r].rangeName, w = f.config.series[a].data[r].x, l = Array.isArray(w) ? w.join(" ") : w, u = f.globals.labels.map(function(A) {
        return Array.isArray(A) ? A.join(" ") : A;
      }).indexOf(l), b = f.globals.seriesRange[a].findIndex(function(A) {
        return A.x === l && A.overlaps.length > 0;
      });
      return this.isHorizontal ? (s = f.config.plotOptions.bar.rangeBarGroupRows ? o + g * u : o + d * this.visibleI + g * u, b > -1 && !f.config.plotOptions.bar.rangeBarOverlap && (m = f.globals.seriesRange[a][b].overlaps).indexOf(v) > -1 && (s = (d = x.barHeight / m.length) * this.visibleI + g * (100 - parseInt(this.barOptions.barHeight, 10)) / 100 / 2 + d * (this.visibleI + m.indexOf(v)) + g * u)) : (u > -1 && !f.globals.timescaleLabels.length && (n = f.config.plotOptions.bar.rangeBarGroupRows ? h + p * u : h + c * this.visibleI + p * u), b > -1 && !f.config.plotOptions.bar.rangeBarOverlap && (m = f.globals.seriesRange[a][b].overlaps).indexOf(v) > -1 && (n = (c = x.barWidth / m.length) * this.visibleI + p * (100 - parseInt(this.barOptions.barWidth, 10)) / 100 / 2 + c * (this.visibleI + m.indexOf(v)) + p * u)), { barYPosition: s, barXPosition: n, barHeight: d, barWidth: c };
    } }, { key: "drawRangeColumnPaths", value: function(i) {
      var a = i.indexes, r = i.x, s = i.xDivision, n = i.barWidth, o = i.barXPosition, h = i.zeroH, d = this.w, c = a.i, g = a.j, p = a.realIndex, x = a.translationsIndex, f = this.yRatio[x], m = this.getRangeValue(p, g), v = Math.min(m.start, m.end), w = Math.max(m.start, m.end);
      this.series[c][g] === void 0 || this.series[c][g] === null ? v = h : (v = h - v / f, w = h - w / f);
      var l = Math.abs(w - v), u = this.barHelpers.getColumnPaths({ barXPosition: o, barWidth: n, y1: v, y2: w, strokeWidth: this.strokeWidth, series: this.seriesRangeEnd, realIndex: p, i: p, j: g, w: d });
      if (d.globals.isXNumeric) {
        var b = this.getBarXForNumericXAxis({ x: r, j: g, realIndex: p, barWidth: n });
        r = b.x, o = b.barXPosition;
      } else
        r += s;
      return { pathTo: u.pathTo, pathFrom: u.pathFrom, barHeight: l, x: r, y: m.start < 0 && m.end < 0 ? v : w, goalY: this.barHelpers.getGoalValues("y", null, h, c, g, x), barXPosition: o };
    } }, { key: "preventBarOverflow", value: function(i) {
      var a = this.w;
      return i < 0 && (i = 0), i > a.globals.gridWidth && (i = a.globals.gridWidth), i;
    } }, { key: "drawRangeBarPaths", value: function(i) {
      var a = i.indexes, r = i.y, s = i.y1, n = i.y2, o = i.yDivision, h = i.barHeight, d = i.barYPosition, c = i.zeroW, g = this.w, p = a.realIndex, x = a.j, f = this.preventBarOverflow(c + s / this.invertedYRatio), m = this.preventBarOverflow(c + n / this.invertedYRatio), v = this.getRangeValue(p, x), w = Math.abs(m - f), l = this.barHelpers.getBarpaths({ barYPosition: d, barHeight: h, x1: f, x2: m, strokeWidth: this.strokeWidth, series: this.seriesRangeEnd, i: p, realIndex: p, j: x, w: g });
      return g.globals.isXNumeric || (r += o), { pathTo: l.pathTo, pathFrom: l.pathFrom, barWidth: w, x: v.start < 0 && v.end < 0 ? f : m, goalX: this.barHelpers.getGoalValues("x", c, null, p, x), y: r };
    } }, { key: "getRangeValue", value: function(i, a) {
      var r = this.w;
      return { start: r.globals.seriesRangeStart[i][a], end: r.globals.seriesRangeEnd[i][a] };
    } }]), t;
  }(), Wt = function() {
    function y(e) {
      R(this, y), this.w = e.w, this.lineCtx = e;
    }
    return F(y, [{ key: "sameValueSeriesFix", value: function(e, t) {
      var i = this.w;
      if ((i.config.fill.type === "gradient" || i.config.fill.type[e] === "gradient") && new $(this.lineCtx.ctx, i).seriesHaveSameValues(e)) {
        var a = t[e].slice();
        a[a.length - 1] = a[a.length - 1] + 1e-6, t[e] = a;
      }
      return t;
    } }, { key: "calculatePoints", value: function(e) {
      var t = e.series, i = e.realIndex, a = e.x, r = e.y, s = e.i, n = e.j, o = e.prevY, h = this.w, d = [], c = [];
      if (n === 0) {
        var g = this.lineCtx.categoryAxisCorrection + h.config.markers.offsetX;
        h.globals.isXNumeric && (g = (h.globals.seriesX[i][0] - h.globals.minX) / this.lineCtx.xRatio + h.config.markers.offsetX), d.push(g), c.push(P.isNumber(t[s][0]) ? o + h.config.markers.offsetY : null), d.push(a + h.config.markers.offsetX), c.push(P.isNumber(t[s][n + 1]) ? r + h.config.markers.offsetY : null);
      } else
        d.push(a + h.config.markers.offsetX), c.push(P.isNumber(t[s][n + 1]) ? r + h.config.markers.offsetY : null);
      return { x: d, y: c };
    } }, { key: "checkPreviousPaths", value: function(e) {
      for (var t = e.pathFromLine, i = e.pathFromArea, a = e.realIndex, r = this.w, s = 0; s < r.globals.previousPaths.length; s++) {
        var n = r.globals.previousPaths[s];
        (n.type === "line" || n.type === "area") && n.paths.length > 0 && parseInt(n.realIndex, 10) === parseInt(a, 10) && (n.type === "line" ? (this.lineCtx.appendPathFrom = !1, t = r.globals.previousPaths[s].paths[0].d) : n.type === "area" && (this.lineCtx.appendPathFrom = !1, i = r.globals.previousPaths[s].paths[0].d, r.config.stroke.show && r.globals.previousPaths[s].paths[1] && (t = r.globals.previousPaths[s].paths[1].d)));
      }
      return { pathFromLine: t, pathFromArea: i };
    } }, { key: "determineFirstPrevY", value: function(e) {
      var t, i, a, r = e.i, s = e.realIndex, n = e.series, o = e.prevY, h = e.lineYPosition, d = e.translationsIndex, c = this.w, g = c.config.chart.stacked && !c.globals.comboCharts || c.config.chart.stacked && c.globals.comboCharts && (!this.w.config.chart.stackOnlyBar || ((t = this.w.config.series[s]) === null || t === void 0 ? void 0 : t.type) === "bar" || ((i = this.w.config.series[s]) === null || i === void 0 ? void 0 : i.type) === "column");
      if (((a = n[r]) === null || a === void 0 ? void 0 : a[0]) !== void 0)
        o = (h = g && r > 0 ? this.lineCtx.prevSeriesY[r - 1][0] : this.lineCtx.zeroY) - n[r][0] / this.lineCtx.yRatio[d] + 2 * (this.lineCtx.isReversed ? n[r][0] / this.lineCtx.yRatio[d] : 0);
      else if (g && r > 0 && n[r][0] === void 0) {
        for (var p = r - 1; p >= 0; p--)
          if (n[p][0] !== null && n[p][0] !== void 0) {
            o = h = this.lineCtx.prevSeriesY[p][0];
            break;
          }
      }
      return { prevY: o, lineYPosition: h };
    } }]), y;
  }(), Gt = function(y) {
    for (var e, t, i, a, r = function(d) {
      for (var c = [], g = d[0], p = d[1], x = c[0] = Ne(g, p), f = 1, m = d.length - 1; f < m; f++)
        g = p, p = d[f + 1], c[f] = 0.5 * (x + (x = Ne(g, p)));
      return c[f] = x, c;
    }(y), s = y.length - 1, n = [], o = 0; o < s; o++)
      i = Ne(y[o], y[o + 1]), Math.abs(i) < 1e-6 ? r[o] = r[o + 1] = 0 : (a = (e = r[o] / i) * e + (t = r[o + 1] / i) * t) > 9 && (a = 3 * i / Math.sqrt(a), r[o] = a * e, r[o + 1] = a * t);
    for (var h = 0; h <= s; h++)
      a = (y[Math.min(s, h + 1)][0] - y[Math.max(0, h - 1)][0]) / (6 * (1 + r[h] * r[h])), n.push([a || 0, r[h] * a || 0]);
    return n;
  }, Vt = function(y) {
    var e = Gt(y), t = y[1], i = y[0], a = [], r = e[1], s = e[0];
    a.push(i, [i[0] + s[0], i[1] + s[1], t[0] - r[0], t[1] - r[1], t[0], t[1]]);
    for (var n = 2, o = e.length; n < o; n++) {
      var h = y[n], d = e[n];
      a.push([h[0] - d[0], h[1] - d[1], h[0], h[1]]);
    }
    return a;
  }, jt = function(y, e, t) {
    var i = y.slice(e, t);
    if (e) {
      if (t - e > 1 && i[1].length < 6) {
        var a = i[0].length;
        i[1] = [2 * i[0][a - 2] - i[0][a - 4], 2 * i[0][a - 1] - i[0][a - 3]].concat(i[1]);
      }
      i[0] = i[0].slice(-2);
    }
    return i;
  };
  function Ne(y, e) {
    return (e[1] - y[1]) / (e[0] - y[0]);
  }
  var Be = function() {
    function y(e, t, i) {
      R(this, y), this.ctx = e, this.w = e.w, this.xyRatios = t, this.pointsChart = !(this.w.config.chart.type !== "bubble" && this.w.config.chart.type !== "scatter") || i, this.scatter = new Ke(this.ctx), this.noNegatives = this.w.globals.minX === Number.MAX_VALUE, this.lineHelpers = new Wt(this), this.markers = new ue(this.ctx), this.prevSeriesY = [], this.categoryAxisCorrection = 0, this.yaxisIndex = 0;
    }
    return F(y, [{ key: "draw", value: function(e, t, i, a) {
      var r, s = this.w, n = new X(this.ctx), o = s.globals.comboCharts ? t : s.config.chart.type, h = n.group({ class: "apexcharts-".concat(o, "-series apexcharts-plot-series") }), d = new $(this.ctx, s);
      this.yRatio = this.xyRatios.yRatio, this.zRatio = this.xyRatios.zRatio, this.xRatio = this.xyRatios.xRatio, this.baseLineY = this.xyRatios.baseLineY, e = d.getLogSeries(e), this.yRatio = d.getLogYRatios(this.yRatio), this.prevSeriesY = [];
      for (var c = [], g = 0; g < e.length; g++) {
        e = this.lineHelpers.sameValueSeriesFix(g, e);
        var p = s.globals.comboCharts ? i[g] : g, x = this.yRatio.length > 1 ? p : 0;
        this._initSerieVariables(e, g, p);
        var f = [], m = [], v = [], w = s.globals.padHorizontal + this.categoryAxisCorrection;
        this.ctx.series.addCollapsedClassToSeries(this.elSeries, p), s.globals.isXNumeric && s.globals.seriesX.length > 0 && (w = (s.globals.seriesX[p][0] - s.globals.minX) / this.xRatio), v.push(w);
        var l, u = w, b = void 0, A = u, k = this.zeroY, S = this.zeroY;
        k = this.lineHelpers.determineFirstPrevY({ i: g, realIndex: p, series: e, prevY: k, lineYPosition: 0, translationsIndex: x }).prevY, s.config.stroke.curve === "monotoneCubic" && e[g][0] === null ? f.push(null) : f.push(k), l = k, o === "rangeArea" && (b = S = this.lineHelpers.determineFirstPrevY({ i: g, realIndex: p, series: a, prevY: S, lineYPosition: 0, translationsIndex: x }).prevY, m.push(f[0] !== null ? S : null));
        var C = this._calculatePathsFrom({ type: o, series: e, i: g, realIndex: p, translationsIndex: x, prevX: A, prevY: k, prevY2: S }), L = [f[0]], M = [m[0]], T = { type: o, series: e, realIndex: p, translationsIndex: x, i: g, x: w, y: 1, pX: u, pY: l, pathsFrom: C, linePaths: [], areaPaths: [], seriesIndex: i, lineYPosition: 0, xArrj: v, yArrj: f, y2Arrj: m, seriesRangeEnd: a }, I = this._iterateOverDataPoints(E(E({}, T), {}, { iterations: o === "rangeArea" ? e[g].length - 1 : void 0, isRangeStart: !0 }));
        if (o === "rangeArea") {
          for (var z = this._calculatePathsFrom({ series: a, i: g, realIndex: p, prevX: A, prevY: S }), Y = this._iterateOverDataPoints(E(E({}, T), {}, { series: a, xArrj: [w], yArrj: L, y2Arrj: M, pY: b, areaPaths: I.areaPaths, pathsFrom: z, iterations: a[g].length - 1, isRangeStart: !1 })), D = I.linePaths.length / 2, H = 0; H < D; H++)
            I.linePaths[H] = Y.linePaths[H + D] + I.linePaths[H];
          I.linePaths.splice(D), I.pathFromLine = Y.pathFromLine + I.pathFromLine;
        } else
          I.pathFromArea += "z";
        this._handlePaths({ type: o, realIndex: p, i: g, paths: I }), this.elSeries.add(this.elPointsMain), this.elSeries.add(this.elDataLabelsWrap), c.push(this.elSeries);
      }
      if (((r = s.config.series[0]) === null || r === void 0 ? void 0 : r.zIndex) !== void 0 && c.sort(function(N, W) {
        return Number(N.node.getAttribute("zIndex")) - Number(W.node.getAttribute("zIndex"));
      }), s.config.chart.stacked)
        for (var O = c.length - 1; O >= 0; O--)
          h.add(c[O]);
      else
        for (var B = 0; B < c.length; B++)
          h.add(c[B]);
      return h;
    } }, { key: "_initSerieVariables", value: function(e, t, i) {
      var a = this.w, r = new X(this.ctx);
      this.xDivision = a.globals.gridWidth / (a.globals.dataPoints - (a.config.xaxis.tickPlacement === "on" ? 1 : 0)), this.strokeWidth = Array.isArray(a.config.stroke.width) ? a.config.stroke.width[i] : a.config.stroke.width;
      var s = 0;
      this.yRatio.length > 1 && (this.yaxisIndex = a.globals.seriesYAxisReverseMap[i], s = i), this.isReversed = a.config.yaxis[this.yaxisIndex] && a.config.yaxis[this.yaxisIndex].reversed, this.zeroY = a.globals.gridHeight - this.baseLineY[s] - (this.isReversed ? a.globals.gridHeight : 0) + (this.isReversed ? 2 * this.baseLineY[s] : 0), this.areaBottomY = this.zeroY, (this.zeroY > a.globals.gridHeight || a.config.plotOptions.area.fillTo === "end") && (this.areaBottomY = a.globals.gridHeight), this.categoryAxisCorrection = this.xDivision / 2, this.elSeries = r.group({ class: "apexcharts-series", zIndex: a.config.series[i].zIndex !== void 0 ? a.config.series[i].zIndex : i, seriesName: P.escapeString(a.globals.seriesNames[i]) }), this.elPointsMain = r.group({ class: "apexcharts-series-markers-wrap", "data:realIndex": i }), this.elDataLabelsWrap = r.group({ class: "apexcharts-datalabels", "data:realIndex": i });
      var n = e[t].length === a.globals.dataPoints;
      this.elSeries.attr({ "data:longestSeries": n, rel: t + 1, "data:realIndex": i }), this.appendPathFrom = !0;
    } }, { key: "_calculatePathsFrom", value: function(e) {
      var t, i, a, r, s = e.type, n = e.series, o = e.i, h = e.realIndex, d = e.translationsIndex, c = e.prevX, g = e.prevY, p = e.prevY2, x = this.w, f = new X(this.ctx);
      if (n[o][0] === null) {
        for (var m = 0; m < n[o].length; m++)
          if (n[o][m] !== null) {
            c = this.xDivision * m, g = this.zeroY - n[o][m] / this.yRatio[d], t = f.move(c, g), i = f.move(c, this.areaBottomY);
            break;
          }
      } else
        t = f.move(c, g), s === "rangeArea" && (t = f.move(c, p) + f.line(c, g)), i = f.move(c, this.areaBottomY) + f.line(c, g);
      if (a = f.move(0, this.zeroY) + f.line(0, this.zeroY), r = f.move(0, this.zeroY) + f.line(0, this.zeroY), x.globals.previousPaths.length > 0) {
        var v = this.lineHelpers.checkPreviousPaths({ pathFromLine: a, pathFromArea: r, realIndex: h });
        a = v.pathFromLine, r = v.pathFromArea;
      }
      return { prevX: c, prevY: g, linePath: t, areaPath: i, pathFromLine: a, pathFromArea: r };
    } }, { key: "_handlePaths", value: function(e) {
      var t = e.type, i = e.realIndex, a = e.i, r = e.paths, s = this.w, n = new X(this.ctx), o = new ne(this.ctx);
      this.prevSeriesY.push(r.yArrj), s.globals.seriesXvalues[i] = r.xArrj, s.globals.seriesYvalues[i] = r.yArrj;
      var h = s.config.forecastDataPoints;
      if (h.count > 0 && t !== "rangeArea") {
        var d = s.globals.seriesXvalues[i][s.globals.seriesXvalues[i].length - h.count - 1], c = n.drawRect(d, 0, s.globals.gridWidth, s.globals.gridHeight, 0);
        s.globals.dom.elForecastMask.appendChild(c.node);
        var g = n.drawRect(0, 0, d, s.globals.gridHeight, 0);
        s.globals.dom.elNonForecastMask.appendChild(g.node);
      }
      this.pointsChart || s.globals.delayedElements.push({ el: this.elPointsMain.node, index: i });
      var p = { i: a, realIndex: i, animationDelay: a, initialSpeed: s.config.chart.animations.speed, dataChangeSpeed: s.config.chart.animations.dynamicAnimation.speed, className: "apexcharts-".concat(t) };
      if (t === "area")
        for (var x = o.fillPath({ seriesNumber: i }), f = 0; f < r.areaPaths.length; f++) {
          var m = n.renderPaths(E(E({}, p), {}, { pathFrom: r.pathFromArea, pathTo: r.areaPaths[f], stroke: "none", strokeWidth: 0, strokeLineCap: null, fill: x }));
          this.elSeries.add(m);
        }
      if (s.config.stroke.show && !this.pointsChart) {
        var v = null;
        if (t === "line")
          v = o.fillPath({ seriesNumber: i, i: a });
        else if (s.config.stroke.fill.type === "solid")
          v = s.globals.stroke.colors[i];
        else {
          var w = s.config.fill;
          s.config.fill = s.config.stroke.fill, v = o.fillPath({ seriesNumber: i, i: a }), s.config.fill = w;
        }
        for (var l = 0; l < r.linePaths.length; l++) {
          var u = v;
          t === "rangeArea" && (u = o.fillPath({ seriesNumber: i }));
          var b = E(E({}, p), {}, { pathFrom: r.pathFromLine, pathTo: r.linePaths[l], stroke: v, strokeWidth: this.strokeWidth, strokeLineCap: s.config.stroke.lineCap, fill: t === "rangeArea" ? u : "none" }), A = n.renderPaths(b);
          if (this.elSeries.add(A), A.attr("fill-rule", "evenodd"), h.count > 0 && t !== "rangeArea") {
            var k = n.renderPaths(b);
            k.node.setAttribute("stroke-dasharray", h.dashArray), h.strokeWidth && k.node.setAttribute("stroke-width", h.strokeWidth), this.elSeries.add(k), k.attr("clip-path", "url(#forecastMask".concat(s.globals.cuid, ")")), A.attr("clip-path", "url(#nonForecastMask".concat(s.globals.cuid, ")"));
          }
        }
      }
    } }, { key: "_iterateOverDataPoints", value: function(e) {
      var t, i, a = this, r = e.type, s = e.series, n = e.iterations, o = e.realIndex, h = e.translationsIndex, d = e.i, c = e.x, g = e.y, p = e.pX, x = e.pY, f = e.pathsFrom, m = e.linePaths, v = e.areaPaths, w = e.seriesIndex, l = e.lineYPosition, u = e.xArrj, b = e.yArrj, A = e.y2Arrj, k = e.isRangeStart, S = e.seriesRangeEnd, C = this.w, L = new X(this.ctx), M = this.yRatio, T = f.prevY, I = f.linePath, z = f.areaPath, Y = f.pathFromLine, D = f.pathFromArea, H = P.isNumber(C.globals.minYArr[o]) ? C.globals.minYArr[o] : C.globals.minY;
      n || (n = C.globals.dataPoints > 1 ? C.globals.dataPoints - 1 : C.globals.dataPoints);
      var O = function(te, ie) {
        return ie - te / M[h] + 2 * (a.isReversed ? te / M[h] : 0);
      }, B = g, N = C.config.chart.stacked && !C.globals.comboCharts || C.config.chart.stacked && C.globals.comboCharts && (!this.w.config.chart.stackOnlyBar || ((t = this.w.config.series[o]) === null || t === void 0 ? void 0 : t.type) === "bar" || ((i = this.w.config.series[o]) === null || i === void 0 ? void 0 : i.type) === "column"), W = C.config.stroke.curve;
      Array.isArray(W) && (W = Array.isArray(w) ? W[w[d]] : W[d]);
      for (var q, Z = 0, U = 0; U < n; U++) {
        var se = s[d][U + 1] === void 0 || s[d][U + 1] === null;
        if (C.globals.isXNumeric) {
          var V = C.globals.seriesX[o][U + 1];
          C.globals.seriesX[o][U + 1] === void 0 && (V = C.globals.seriesX[o][n - 1]), c = (V - C.globals.minX) / this.xRatio;
        } else
          c += this.xDivision;
        N ? d > 0 && C.globals.collapsedSeries.length < C.config.series.length - 1 ? l = this.prevSeriesY[function(te) {
          for (var ie = te; ie > 0; ie--) {
            if (!(C.globals.collapsedSeriesIndices.indexOf((w == null ? void 0 : w[ie]) || ie) > -1))
              return ie;
            ie--;
          }
          return 0;
        }(d - 1)][U + 1] : l = this.zeroY : l = this.zeroY, se ? g = O(H, l) : (g = O(s[d][U + 1], l), r === "rangeArea" && (B = O(S[d][U + 1], l))), u.push(c), !se || C.config.stroke.curve !== "smooth" && C.config.stroke.curve !== "monotoneCubic" ? (b.push(g), A.push(B)) : (b.push(null), A.push(null));
        var G = this.lineHelpers.calculatePoints({ series: s, x: c, y: g, realIndex: o, i: d, j: U, prevY: T }), _ = this._createPaths({ type: r, series: s, i: d, realIndex: o, j: U, x: c, y: g, y2: B, xArrj: u, yArrj: b, y2Arrj: A, pX: p, pY: x, pathState: Z, segmentStartX: q, linePath: I, areaPath: z, linePaths: m, areaPaths: v, curve: W, isRangeStart: k });
        v = _.areaPaths, m = _.linePaths, p = _.pX, x = _.pY, Z = _.pathState, q = _.segmentStartX, z = _.areaPath, I = _.linePath, !this.appendPathFrom || W === "monotoneCubic" && r === "rangeArea" || (Y += L.line(c, this.zeroY), D += L.line(c, this.zeroY)), this.handleNullDataPoints(s, G, d, U, o), this._handleMarkersAndLabels({ type: r, pointsPos: G, i: d, j: U, realIndex: o, isRangeStart: k });
      }
      return { yArrj: b, xArrj: u, pathFromArea: D, areaPaths: v, pathFromLine: Y, linePaths: m, linePath: I, areaPath: z };
    } }, { key: "_handleMarkersAndLabels", value: function(e) {
      var t = e.type, i = e.pointsPos, a = e.isRangeStart, r = e.i, s = e.j, n = e.realIndex, o = this.w, h = new pe(this.ctx);
      if (this.pointsChart)
        this.scatter.draw(this.elSeries, s, { realIndex: n, pointsPos: i, zRatio: this.zRatio, elParent: this.elPointsMain });
      else {
        o.globals.series[r].length > 1 && this.elPointsMain.node.classList.add("apexcharts-element-hidden");
        var d = this.markers.plotChartMarkers(i, n, s + 1);
        d !== null && this.elPointsMain.add(d);
      }
      var c = h.drawDataLabel({ type: t, isRangeStart: a, pos: i, i: n, j: s + 1 });
      c !== null && this.elDataLabelsWrap.add(c);
    } }, { key: "_createPaths", value: function(e) {
      var t = e.type, i = e.series, a = e.i;
      e.realIndex;
      var r, s = e.j, n = e.x, o = e.y, h = e.xArrj, d = e.yArrj, c = e.y2, g = e.y2Arrj, p = e.pX, x = e.pY, f = e.pathState, m = e.segmentStartX, v = e.linePath, w = e.areaPath, l = e.linePaths, u = e.areaPaths, b = e.curve, A = e.isRangeStart, k = new X(this.ctx), S = this.areaBottomY, C = t === "rangeArea", L = t === "rangeArea" && A;
      switch (b) {
        case "monotoneCubic":
          var M = A ? d : g;
          switch (f) {
            case 0:
              if (M[s + 1] === null)
                break;
              f = 1;
            case 1:
              if (!(C ? h.length === i[a].length : s === i[a].length - 2))
                break;
            case 2:
              var T = A ? h : h.slice().reverse(), I = A ? M : M.slice().reverse(), z = (r = I, T.map(function(V, G) {
                return [V, r[G]];
              }).filter(function(V) {
                return V[1] !== null;
              })), Y = z.length > 1 ? Vt(z) : z, D = [];
              C && (L ? u = z : D = u.reverse());
              var H = 0, O = 0;
              if (function(V, G) {
                for (var _ = function(ke) {
                  var ae = [], le = 0;
                  return ke.forEach(function(Qt) {
                    Qt !== null ? le++ : le > 0 && (ae.push(le), le = 0);
                  }), le > 0 && ae.push(le), ae;
                }(V), te = [], ie = 0, oe = 0; ie < _.length; oe += _[ie++])
                  te[ie] = jt(G, oe, oe + _[ie]);
                return te;
              }(I, Y).forEach(function(V) {
                H++;
                var G = function(ie) {
                  for (var oe = "", ke = 0; ke < ie.length; ke++) {
                    var ae = ie[ke], le = ae.length;
                    le > 4 ? (oe += "C".concat(ae[0], ", ").concat(ae[1]), oe += ", ".concat(ae[2], ", ").concat(ae[3]), oe += ", ".concat(ae[4], ", ").concat(ae[5])) : le > 2 && (oe += "S".concat(ae[0], ", ").concat(ae[1]), oe += ", ".concat(ae[2], ", ").concat(ae[3]));
                  }
                  return oe;
                }(V), _ = O, te = (O += V.length) - 1;
                L ? v = k.move(z[_][0], z[_][1]) + G : C ? v = k.move(D[_][0], D[_][1]) + k.line(z[_][0], z[_][1]) + G + k.line(D[te][0], D[te][1]) : (v = k.move(z[_][0], z[_][1]) + G, w = v + k.line(z[te][0], S) + k.line(z[_][0], S) + "z", u.push(w)), l.push(v);
              }), C && H > 1 && !L) {
                var B = l.slice(H).reverse();
                l.splice(H), B.forEach(function(V) {
                  return l.push(V);
                });
              }
              f = 0;
          }
          break;
        case "smooth":
          var N = 0.35 * (n - p);
          if (i[a][s] === null)
            f = 0;
          else
            switch (f) {
              case 0:
                if (m = p, v = L ? k.move(p, g[s]) + k.line(p, x) : k.move(p, x), w = k.move(p, x), i[a][s + 1] === null) {
                  l.push(v), u.push(w);
                  break;
                }
                if (f = 1, s < i[a].length - 2) {
                  var W = k.curve(p + N, x, n - N, o, n, o);
                  v += W, w += W;
                  break;
                }
              case 1:
                if (i[a][s + 1] === null)
                  v += L ? k.line(p, c) : k.move(p, x), w += k.line(p, S) + k.line(m, S) + "z", l.push(v), u.push(w), f = -1;
                else {
                  var q = k.curve(p + N, x, n - N, o, n, o);
                  v += q, w += q, s >= i[a].length - 2 && (L && (v += k.curve(n, o, n, o, n, c) + k.move(n, c)), w += k.curve(n, o, n, o, n, S) + k.line(m, S) + "z", l.push(v), u.push(w), f = -1);
                }
            }
          p = n, x = o;
          break;
        default:
          var Z = function(V, G, _) {
            var te = [];
            switch (V) {
              case "stepline":
                te = k.line(G, null, "H") + k.line(null, _, "V");
                break;
              case "linestep":
                te = k.line(null, _, "V") + k.line(G, null, "H");
                break;
              case "straight":
                te = k.line(G, _);
            }
            return te;
          };
          if (i[a][s] === null)
            f = 0;
          else
            switch (f) {
              case 0:
                if (m = p, v = L ? k.move(p, g[s]) + k.line(p, x) : k.move(p, x), w = k.move(p, x), i[a][s + 1] === null) {
                  l.push(v), u.push(w);
                  break;
                }
                if (f = 1, s < i[a].length - 2) {
                  var U = Z(b, n, o);
                  v += U, w += U;
                  break;
                }
              case 1:
                if (i[a][s + 1] === null)
                  v += L ? k.line(p, c) : k.move(p, x), w += k.line(p, S) + k.line(m, S) + "z", l.push(v), u.push(w), f = -1;
                else {
                  var se = Z(b, n, o);
                  v += se, w += se, s >= i[a].length - 2 && (L && (v += k.line(n, c)), w += k.line(n, S) + k.line(m, S) + "z", l.push(v), u.push(w), f = -1);
                }
            }
          p = n, x = o;
      }
      return { linePaths: l, areaPaths: u, pX: p, pY: x, pathState: f, segmentStartX: m, linePath: v, areaPath: w };
    } }, { key: "handleNullDataPoints", value: function(e, t, i, a, r) {
      var s = this.w;
      if (e[i][a] === null && s.config.markers.showNullDataPoints || e[i].length === 1) {
        var n = this.strokeWidth - s.config.markers.strokeWidth / 2;
        n > 0 || (n = 0);
        var o = this.markers.plotChartMarkers(t, r, a + 1, n, !0);
        o !== null && this.elPointsMain.add(o);
      }
    } }]), y;
  }();
  window.TreemapSquared = {}, window.TreemapSquared.generate = function() {
    function y(n, o, h, d) {
      this.xoffset = n, this.yoffset = o, this.height = d, this.width = h, this.shortestEdge = function() {
        return Math.min(this.height, this.width);
      }, this.getCoordinates = function(c) {
        var g, p = [], x = this.xoffset, f = this.yoffset, m = r(c) / this.height, v = r(c) / this.width;
        if (this.width >= this.height)
          for (g = 0; g < c.length; g++)
            p.push([x, f, x + m, f + c[g] / m]), f += c[g] / m;
        else
          for (g = 0; g < c.length; g++)
            p.push([x, f, x + c[g] / v, f + v]), x += c[g] / v;
        return p;
      }, this.cutArea = function(c) {
        var g;
        if (this.width >= this.height) {
          var p = c / this.height, x = this.width - p;
          g = new y(this.xoffset + p, this.yoffset, x, this.height);
        } else {
          var f = c / this.width, m = this.height - f;
          g = new y(this.xoffset, this.yoffset + f, this.width, m);
        }
        return g;
      };
    }
    function e(n, o, h, d, c) {
      d = d === void 0 ? 0 : d, c = c === void 0 ? 0 : c;
      var g = t(function(p, x) {
        var f, m = [], v = x / r(p);
        for (f = 0; f < p.length; f++)
          m[f] = p[f] * v;
        return m;
      }(n, o * h), [], new y(d, c, o, h), []);
      return function(p) {
        var x, f, m = [];
        for (x = 0; x < p.length; x++)
          for (f = 0; f < p[x].length; f++)
            m.push(p[x][f]);
        return m;
      }(g);
    }
    function t(n, o, h, d) {
      var c, g, p;
      if (n.length !== 0)
        return c = h.shortestEdge(), function(x, f, m) {
          var v;
          if (x.length === 0)
            return !0;
          (v = x.slice()).push(f);
          var w = i(x, m), l = i(v, m);
          return w >= l;
        }(o, g = n[0], c) ? (o.push(g), t(n.slice(1), o, h, d)) : (p = h.cutArea(r(o), d), d.push(h.getCoordinates(o)), t(n, [], p, d)), d;
      d.push(h.getCoordinates(o));
    }
    function i(n, o) {
      var h = Math.min.apply(Math, n), d = Math.max.apply(Math, n), c = r(n);
      return Math.max(Math.pow(o, 2) * d / Math.pow(c, 2), Math.pow(c, 2) / (Math.pow(o, 2) * h));
    }
    function a(n) {
      return n && n.constructor === Array;
    }
    function r(n) {
      var o, h = 0;
      for (o = 0; o < n.length; o++)
        h += n[o];
      return h;
    }
    function s(n) {
      var o, h = 0;
      if (a(n[0]))
        for (o = 0; o < n.length; o++)
          h += s(n[o]);
      else
        h = r(n);
      return h;
    }
    return function n(o, h, d, c, g) {
      c = c === void 0 ? 0 : c, g = g === void 0 ? 0 : g;
      var p, x, f = [], m = [];
      if (a(o[0])) {
        for (x = 0; x < o.length; x++)
          f[x] = s(o[x]);
        for (p = e(f, h, d, c, g), x = 0; x < o.length; x++)
          m.push(n(o[x], p[x][2] - p[x][0], p[x][3] - p[x][1], p[x][0], p[x][1]));
      } else
        m = e(o, h, d, c, g);
      return m;
    };
  }();
  var de, Ie, _t = function() {
    function y(e, t) {
      R(this, y), this.ctx = e, this.w = e.w, this.strokeWidth = this.w.config.stroke.width, this.helpers = new lt(e), this.dynamicAnim = this.w.config.chart.animations.dynamicAnimation, this.labels = [];
    }
    return F(y, [{ key: "draw", value: function(e) {
      var t = this, i = this.w, a = new X(this.ctx), r = new ne(this.ctx), s = a.group({ class: "apexcharts-treemap" });
      if (i.globals.noData)
        return s;
      var n = [];
      return e.forEach(function(o) {
        var h = o.map(function(d) {
          return Math.abs(d);
        });
        n.push(h);
      }), this.negRange = this.helpers.checkColorRange(), i.config.series.forEach(function(o, h) {
        o.data.forEach(function(d) {
          Array.isArray(t.labels[h]) || (t.labels[h] = []), t.labels[h].push(d.x);
        });
      }), window.TreemapSquared.generate(n, i.globals.gridWidth, i.globals.gridHeight).forEach(function(o, h) {
        var d = a.group({ class: "apexcharts-series apexcharts-treemap-series", seriesName: P.escapeString(i.globals.seriesNames[h]), rel: h + 1, "data:realIndex": h });
        if (i.config.chart.dropShadow.enabled) {
          var c = i.config.chart.dropShadow;
          new ee(t.ctx).dropShadow(s, c, h);
        }
        var g = a.group({ class: "apexcharts-data-labels" });
        o.forEach(function(p, x) {
          var f = p[0], m = p[1], v = p[2], w = p[3], l = a.drawRect(f, m, v - f, w - m, i.config.plotOptions.treemap.borderRadius, "#fff", 1, t.strokeWidth, i.config.plotOptions.treemap.useFillColorAsStroke ? b : i.globals.stroke.colors[h]);
          l.attr({ cx: f, cy: m, index: h, i: h, j: x, width: v - f, height: w - m });
          var u = t.helpers.getShadeColor(i.config.chart.type, h, x, t.negRange), b = u.color;
          i.config.series[h].data[x] !== void 0 && i.config.series[h].data[x].fillColor && (b = i.config.series[h].data[x].fillColor);
          var A = r.fillPath({ color: b, seriesNumber: h, dataPointIndex: x });
          l.node.classList.add("apexcharts-treemap-rect"), l.attr({ fill: A }), t.helpers.addListeners(l);
          var k = { x: f + (v - f) / 2, y: m + (w - m) / 2, width: 0, height: 0 }, S = { x: f, y: m, width: v - f, height: w - m };
          if (i.config.chart.animations.enabled && !i.globals.dataChanged) {
            var C = 1;
            i.globals.resized || (C = i.config.chart.animations.speed), t.animateTreemap(l, k, S, C);
          }
          if (i.globals.dataChanged) {
            var L = 1;
            t.dynamicAnim.enabled && i.globals.shouldAnimate && (L = t.dynamicAnim.speed, i.globals.previousPaths[h] && i.globals.previousPaths[h][x] && i.globals.previousPaths[h][x].rect && (k = i.globals.previousPaths[h][x].rect), t.animateTreemap(l, k, S, L));
          }
          var M = t.getFontSize(p), T = i.config.dataLabels.formatter(t.labels[h][x], { value: i.globals.series[h][x], seriesIndex: h, dataPointIndex: x, w: i });
          i.config.plotOptions.treemap.dataLabels.format === "truncate" && (M = parseInt(i.config.dataLabels.style.fontSize, 10), T = t.truncateLabels(T, M, f, m, v, w));
          var I = null;
          i.globals.series[h][x] && (I = t.helpers.calculateDataLabels({ text: T, x: (f + v) / 2, y: (m + w) / 2 + t.strokeWidth / 2 + M / 3, i: h, j: x, colorProps: u, fontSize: M, series: e })), i.config.dataLabels.enabled && I && t.rotateToFitLabel(I, M, T, f, m, v, w), d.add(l), I !== null && d.add(I);
        }), d.add(g), s.add(d);
      }), s;
    } }, { key: "getFontSize", value: function(e) {
      var t = this.w, i, a, r, s, n = function o(h) {
        var d, c = 0;
        if (Array.isArray(h[0]))
          for (d = 0; d < h.length; d++)
            c += o(h[d]);
        else
          for (d = 0; d < h.length; d++)
            c += h[d].length;
        return c;
      }(this.labels) / function o(h) {
        var d, c = 0;
        if (Array.isArray(h[0]))
          for (d = 0; d < h.length; d++)
            c += o(h[d]);
        else
          for (d = 0; d < h.length; d++)
            c += 1;
        return c;
      }(this.labels);
      return i = e[2] - e[0], a = e[3] - e[1], r = i * a, s = Math.pow(r, 0.5), Math.min(s / n, parseInt(t.config.dataLabels.style.fontSize, 10));
    } }, { key: "rotateToFitLabel", value: function(e, t, i, a, r, s, n) {
      var o = new X(this.ctx), h = o.getTextRects(i, t);
      if (h.width + this.w.config.stroke.width + 5 > s - a && h.width <= n - r) {
        var d = o.rotateAroundCenter(e.node);
        e.node.setAttribute("transform", "rotate(-90 ".concat(d.x, " ").concat(d.y, ") translate(").concat(h.height / 3, ")"));
      }
    } }, { key: "truncateLabels", value: function(e, t, i, a, r, s) {
      var n = new X(this.ctx), o = n.getTextRects(e, t).width + this.w.config.stroke.width + 5 > r - i && s - a > r - i ? s - a : r - i, h = n.getTextBasedOnMaxWidth({ text: e, maxWidth: o, fontSize: t });
      return e.length !== h.length && o / t < 5 ? "" : h;
    } }, { key: "animateTreemap", value: function(e, t, i, a) {
      var r = new ge(this.ctx);
      r.animateRect(e, { x: t.x, y: t.y, width: t.width, height: t.height }, { x: i.x, y: i.y, width: i.width, height: i.height }, a, function() {
        r.animationCompleted(e);
      });
    } }]), y;
  }(), dt = 86400, Ut = 10 / dt, qt = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w, this.timeScaleArray = [], this.utc = this.w.config.xaxis.labels.datetimeUTC;
    }
    return F(y, [{ key: "calculateTimeScaleTicks", value: function(e, t) {
      var i = this, a = this.w;
      if (a.globals.allSeriesCollapsed)
        return a.globals.labels = [], a.globals.timescaleLabels = [], [];
      var r = new K(this.ctx), s = (t - e) / 864e5;
      this.determineInterval(s), a.globals.disableZoomIn = !1, a.globals.disableZoomOut = !1, s < Ut ? a.globals.disableZoomIn = !0 : s > 5e4 && (a.globals.disableZoomOut = !0);
      var n = r.getTimeUnitsfromTimestamp(e, t, this.utc), o = a.globals.gridWidth / s, h = o / 24, d = h / 60, c = d / 60, g = Math.floor(24 * s), p = Math.floor(1440 * s), x = Math.floor(s * dt), f = Math.floor(s), m = Math.floor(s / 30), v = Math.floor(s / 365), w = { minMillisecond: n.minMillisecond, minSecond: n.minSecond, minMinute: n.minMinute, minHour: n.minHour, minDate: n.minDate, minMonth: n.minMonth, minYear: n.minYear }, l = { firstVal: w, currentMillisecond: w.minMillisecond, currentSecond: w.minSecond, currentMinute: w.minMinute, currentHour: w.minHour, currentMonthDate: w.minDate, currentDate: w.minDate, currentMonth: w.minMonth, currentYear: w.minYear, daysWidthOnXAxis: o, hoursWidthOnXAxis: h, minutesWidthOnXAxis: d, secondsWidthOnXAxis: c, numberOfSeconds: x, numberOfMinutes: p, numberOfHours: g, numberOfDays: f, numberOfMonths: m, numberOfYears: v };
      switch (this.tickInterval) {
        case "years":
          this.generateYearScale(l);
          break;
        case "months":
        case "half_year":
          this.generateMonthScale(l);
          break;
        case "months_days":
        case "months_fortnight":
        case "days":
        case "week_days":
          this.generateDayScale(l);
          break;
        case "hours":
          this.generateHourScale(l);
          break;
        case "minutes_fives":
        case "minutes":
          this.generateMinuteScale(l);
          break;
        case "seconds_tens":
        case "seconds_fives":
        case "seconds":
          this.generateSecondScale(l);
      }
      var u = this.timeScaleArray.map(function(b) {
        var A = { position: b.position, unit: b.unit, year: b.year, day: b.day ? b.day : 1, hour: b.hour ? b.hour : 0, month: b.month + 1 };
        return b.unit === "month" ? E(E({}, A), {}, { day: 1, value: b.value + 1 }) : b.unit === "day" || b.unit === "hour" ? E(E({}, A), {}, { value: b.value }) : b.unit === "minute" ? E(E({}, A), {}, { value: b.value, minute: b.value }) : b.unit === "second" ? E(E({}, A), {}, { value: b.value, minute: b.minute, second: b.second }) : b;
      });
      return u.filter(function(b) {
        var A = 1, k = Math.ceil(a.globals.gridWidth / 120), S = b.value;
        a.config.xaxis.tickAmount !== void 0 && (k = a.config.xaxis.tickAmount), u.length > k && (A = Math.floor(u.length / k));
        var C = !1, L = !1;
        switch (i.tickInterval) {
          case "years":
            b.unit === "year" && (C = !0);
            break;
          case "half_year":
            A = 7, b.unit === "year" && (C = !0);
            break;
          case "months":
            A = 1, b.unit === "year" && (C = !0);
            break;
          case "months_fortnight":
            A = 15, b.unit !== "year" && b.unit !== "month" || (C = !0), S === 30 && (L = !0);
            break;
          case "months_days":
            A = 10, b.unit === "month" && (C = !0), S === 30 && (L = !0);
            break;
          case "week_days":
            A = 8, b.unit === "month" && (C = !0);
            break;
          case "days":
            A = 1, b.unit === "month" && (C = !0);
            break;
          case "hours":
            b.unit === "day" && (C = !0);
            break;
          case "minutes_fives":
          case "seconds_fives":
            S % 5 != 0 && (L = !0);
            break;
          case "seconds_tens":
            S % 10 != 0 && (L = !0);
        }
        if (i.tickInterval === "hours" || i.tickInterval === "minutes_fives" || i.tickInterval === "seconds_tens" || i.tickInterval === "seconds_fives") {
          if (!L)
            return !0;
        } else if ((S % A == 0 || C) && !L)
          return !0;
      });
    } }, { key: "recalcDimensionsBasedOnFormat", value: function(e, t) {
      var i = this.w, a = this.formatDates(e), r = this.removeOverlappingTS(a);
      i.globals.timescaleLabels = r.slice(), new Me(this.ctx).plotCoords();
    } }, { key: "determineInterval", value: function(e) {
      var t = 24 * e, i = 60 * t;
      switch (!0) {
        case e / 365 > 5:
          this.tickInterval = "years";
          break;
        case e > 800:
          this.tickInterval = "half_year";
          break;
        case e > 180:
          this.tickInterval = "months";
          break;
        case e > 90:
          this.tickInterval = "months_fortnight";
          break;
        case e > 60:
          this.tickInterval = "months_days";
          break;
        case e > 30:
          this.tickInterval = "week_days";
          break;
        case e > 2:
          this.tickInterval = "days";
          break;
        case t > 2.4:
          this.tickInterval = "hours";
          break;
        case i > 15:
          this.tickInterval = "minutes_fives";
          break;
        case i > 5:
          this.tickInterval = "minutes";
          break;
        case i > 1:
          this.tickInterval = "seconds_tens";
          break;
        case 60 * i > 20:
          this.tickInterval = "seconds_fives";
          break;
        default:
          this.tickInterval = "seconds";
      }
    } }, { key: "generateYearScale", value: function(e) {
      var t = e.firstVal, i = e.currentMonth, a = e.currentYear, r = e.daysWidthOnXAxis, s = e.numberOfYears, n = t.minYear, o = 0, h = new K(this.ctx), d = "year";
      if (t.minDate > 1 || t.minMonth > 0) {
        var c = h.determineRemainingDaysOfYear(t.minYear, t.minMonth, t.minDate);
        o = (h.determineDaysOfYear(t.minYear) - c + 1) * r, n = t.minYear + 1, this.timeScaleArray.push({ position: o, value: n, unit: d, year: n, month: P.monthMod(i + 1) });
      } else
        t.minDate === 1 && t.minMonth === 0 && this.timeScaleArray.push({ position: o, value: n, unit: d, year: a, month: P.monthMod(i + 1) });
      for (var g = n, p = o, x = 0; x < s; x++)
        g++, p = h.determineDaysOfYear(g - 1) * r + p, this.timeScaleArray.push({ position: p, value: g, unit: d, year: g, month: 1 });
    } }, { key: "generateMonthScale", value: function(e) {
      var t = e.firstVal, i = e.currentMonthDate, a = e.currentMonth, r = e.currentYear, s = e.daysWidthOnXAxis, n = e.numberOfMonths, o = a, h = 0, d = new K(this.ctx), c = "month", g = 0;
      if (t.minDate > 1) {
        h = (d.determineDaysOfMonths(a + 1, t.minYear) - i + 1) * s, o = P.monthMod(a + 1);
        var p = r + g, x = P.monthMod(o), f = o;
        o === 0 && (c = "year", f = p, x = 1, p += g += 1), this.timeScaleArray.push({ position: h, value: f, unit: c, year: p, month: x });
      } else
        this.timeScaleArray.push({ position: h, value: o, unit: c, year: r, month: P.monthMod(a) });
      for (var m = o + 1, v = h, w = 0, l = 1; w < n; w++, l++) {
        (m = P.monthMod(m)) === 0 ? (c = "year", g += 1) : c = "month";
        var u = this._getYear(r, m, g);
        v = d.determineDaysOfMonths(m, u) * s + v;
        var b = m === 0 ? u : m;
        this.timeScaleArray.push({ position: v, value: b, unit: c, year: u, month: m === 0 ? 1 : m }), m++;
      }
    } }, { key: "generateDayScale", value: function(e) {
      var t = e.firstVal, i = e.currentMonth, a = e.currentYear, r = e.hoursWidthOnXAxis, s = e.numberOfDays, n = new K(this.ctx), o = "day", h = t.minDate + 1, d = h, c = function(l, u, b) {
        return l > n.determineDaysOfMonths(u + 1, b) && (d = 1, o = "month", p = u += 1), u;
      }, g = (24 - t.minHour) * r, p = h, x = c(d, i, a);
      t.minHour === 0 && t.minDate === 1 ? (g = 0, p = P.monthMod(t.minMonth), o = "month", d = t.minDate) : t.minDate !== 1 && t.minHour === 0 && t.minMinute === 0 && (g = 0, h = t.minDate, p = h, x = c(d = h, i, a)), this.timeScaleArray.push({ position: g, value: p, unit: o, year: this._getYear(a, x, 0), month: P.monthMod(x), day: d });
      for (var f = g, m = 0; m < s; m++) {
        o = "day", x = c(d += 1, x, this._getYear(a, x, 0));
        var v = this._getYear(a, x, 0);
        f = 24 * r + f;
        var w = d === 1 ? P.monthMod(x) : d;
        this.timeScaleArray.push({ position: f, value: w, unit: o, year: v, month: P.monthMod(x), day: w });
      }
    } }, { key: "generateHourScale", value: function(e) {
      var t = e.firstVal, i = e.currentDate, a = e.currentMonth, r = e.currentYear, s = e.minutesWidthOnXAxis, n = e.numberOfHours, o = new K(this.ctx), h = "hour", d = function(A, k) {
        return A > o.determineDaysOfMonths(k + 1, r) && (m = 1, k += 1), { month: k, date: m };
      }, c = function(A, k) {
        return A > o.determineDaysOfMonths(k + 1, r) ? k += 1 : k;
      }, g = 60 - (t.minMinute + t.minSecond / 60), p = g * s, x = t.minHour + 1, f = x;
      g === 60 && (p = 0, f = x = t.minHour);
      var m = i;
      f >= 24 && (f = 0, m += 1, h = "day");
      var v = d(m, a).month;
      v = c(m, v), this.timeScaleArray.push({ position: p, value: x, unit: h, day: m, hour: f, year: r, month: P.monthMod(v) }), f++;
      for (var w = p, l = 0; l < n; l++) {
        h = "hour", f >= 24 && (f = 0, h = "day", v = d(m += 1, v).month, v = c(m, v));
        var u = this._getYear(r, v, 0);
        w = 60 * s + w;
        var b = f === 0 ? m : f;
        this.timeScaleArray.push({ position: w, value: b, unit: h, hour: f, day: m, year: u, month: P.monthMod(v) }), f++;
      }
    } }, { key: "generateMinuteScale", value: function(e) {
      for (var t = e.currentMillisecond, i = e.currentSecond, a = e.currentMinute, r = e.currentHour, s = e.currentDate, n = e.currentMonth, o = e.currentYear, h = e.minutesWidthOnXAxis, d = e.secondsWidthOnXAxis, c = e.numberOfMinutes, g = a + 1, p = s, x = n, f = o, m = r, v = (60 - i - t / 1e3) * d, w = 0; w < c; w++)
        g >= 60 && (g = 0, (m += 1) === 24 && (m = 0)), this.timeScaleArray.push({ position: v, value: g, unit: "minute", hour: m, minute: g, day: p, year: this._getYear(f, x, 0), month: P.monthMod(x) }), v += h, g++;
    } }, { key: "generateSecondScale", value: function(e) {
      for (var t = e.currentMillisecond, i = e.currentSecond, a = e.currentMinute, r = e.currentHour, s = e.currentDate, n = e.currentMonth, o = e.currentYear, h = e.secondsWidthOnXAxis, d = e.numberOfSeconds, c = i + 1, g = a, p = s, x = n, f = o, m = r, v = (1e3 - t) / 1e3 * h, w = 0; w < d; w++)
        c >= 60 && (c = 0, ++g >= 60 && (g = 0, ++m === 24 && (m = 0))), this.timeScaleArray.push({ position: v, value: c, unit: "second", hour: m, minute: g, second: c, day: p, year: this._getYear(f, x, 0), month: P.monthMod(x) }), v += h, c++;
    } }, { key: "createRawDateString", value: function(e, t) {
      var i = e.year;
      return e.month === 0 && (e.month = 1), i += "-" + ("0" + e.month.toString()).slice(-2), e.unit === "day" ? i += e.unit === "day" ? "-" + ("0" + t).slice(-2) : "-01" : i += "-" + ("0" + (e.day ? e.day : "1")).slice(-2), e.unit === "hour" ? i += e.unit === "hour" ? "T" + ("0" + t).slice(-2) : "T00" : i += "T" + ("0" + (e.hour ? e.hour : "0")).slice(-2), e.unit === "minute" ? i += ":" + ("0" + t).slice(-2) : i += ":" + (e.minute ? ("0" + e.minute).slice(-2) : "00"), e.unit === "second" ? i += ":" + ("0" + t).slice(-2) : i += ":00", this.utc && (i += ".000Z"), i;
    } }, { key: "formatDates", value: function(e) {
      var t = this, i = this.w;
      return e.map(function(a) {
        var r = a.value.toString(), s = new K(t.ctx), n = t.createRawDateString(a, r), o = s.getDate(s.parseDate(n));
        if (t.utc || (o = s.getDate(s.parseDateWithTimezone(n))), i.config.xaxis.labels.format === void 0) {
          var h = "dd MMM", d = i.config.xaxis.labels.datetimeFormatter;
          a.unit === "year" && (h = d.year), a.unit === "month" && (h = d.month), a.unit === "day" && (h = d.day), a.unit === "hour" && (h = d.hour), a.unit === "minute" && (h = d.minute), a.unit === "second" && (h = d.second), r = s.formatDate(o, h);
        } else
          r = s.formatDate(o, i.config.xaxis.labels.format);
        return { dateString: n, position: a.position, value: r, unit: a.unit, year: a.year, month: a.month };
      });
    } }, { key: "removeOverlappingTS", value: function(e) {
      var t, i = this, a = new X(this.ctx), r = !1;
      e.length > 0 && e[0].value && e.every(function(o) {
        return o.value.length === e[0].value.length;
      }) && (r = !0, t = a.getTextRects(e[0].value).width);
      var s = 0, n = e.map(function(o, h) {
        if (h > 0 && i.w.config.xaxis.labels.hideOverlappingLabels) {
          var d = r ? t : a.getTextRects(e[s].value).width, c = e[s].position;
          return o.position > c + d + 10 ? (s = h, o) : null;
        }
        return o;
      });
      return n = n.filter(function(o) {
        return o !== null;
      });
    } }, { key: "_getYear", value: function(e, t, i) {
      return e + Math.floor(t / 12) + i;
    } }]), y;
  }(), Zt = function() {
    function y(e, t) {
      R(this, y), this.ctx = t, this.w = t.w, this.el = e;
    }
    return F(y, [{ key: "setupElements", value: function() {
      var e = this.w, t = e.globals, i = e.config, a = i.chart.type;
      t.axisCharts = ["line", "area", "bar", "rangeBar", "rangeArea", "candlestick", "boxPlot", "scatter", "bubble", "radar", "heatmap", "treemap"].includes(a), t.xyCharts = ["line", "area", "bar", "rangeBar", "rangeArea", "candlestick", "boxPlot", "scatter", "bubble"].includes(a), t.isBarHorizontal = ["bar", "rangeBar", "boxPlot"].includes(a) && i.plotOptions.bar.horizontal, t.chartClass = ".apexcharts".concat(t.chartID), t.dom.baseEl = this.el, t.dom.elWrap = document.createElement("div"), X.setAttrs(t.dom.elWrap, { id: t.chartClass.substring(1), class: "apexcharts-canvas ".concat(t.chartClass.substring(1)) }), this.el.appendChild(t.dom.elWrap), t.dom.Paper = new window.SVG.Doc(t.dom.elWrap), t.dom.Paper.attr({ class: "apexcharts-svg", "xmlns:data": "ApexChartsNS", transform: "translate(".concat(i.chart.offsetX, ", ").concat(i.chart.offsetY, ")") }), t.dom.Paper.node.style.background = i.theme.mode !== "dark" || i.chart.background ? i.theme.mode !== "light" || i.chart.background ? i.chart.background : "#fff" : "#424242", this.setSVGDimensions(), t.dom.elLegendForeign = document.createElementNS(t.SVGNS, "foreignObject"), X.setAttrs(t.dom.elLegendForeign, { x: 0, y: 0, width: t.svgWidth, height: t.svgHeight }), t.dom.elLegendWrap = document.createElement("div"), t.dom.elLegendWrap.classList.add("apexcharts-legend"), t.dom.elLegendWrap.setAttribute("xmlns", "http://www.w3.org/1999/xhtml"), t.dom.elLegendForeign.appendChild(t.dom.elLegendWrap), t.dom.Paper.node.appendChild(t.dom.elLegendForeign), t.dom.elGraphical = t.dom.Paper.group().attr({ class: "apexcharts-inner apexcharts-graphical" }), t.dom.elDefs = t.dom.Paper.defs(), t.dom.Paper.add(t.dom.elGraphical), t.dom.elGraphical.add(t.dom.elDefs);
    } }, { key: "plotChartType", value: function(e, t) {
      var i = this.w, a = this.ctx, r = i.config, s = i.globals, n = { line: { series: [], i: [] }, area: { series: [], i: [] }, scatter: { series: [], i: [] }, bubble: { series: [], i: [] }, column: { series: [], i: [] }, candlestick: { series: [], i: [] }, boxPlot: { series: [], i: [] }, rangeBar: { series: [], i: [] }, rangeArea: { series: [], seriesRangeEnd: [], i: [] } }, o = r.chart.type || "line", h = null, d = 0;
      s.series.forEach(function(A, k) {
        var S = e[k].type || o;
        n[S] ? (S === "rangeArea" ? (n[S].series.push(s.seriesRangeStart[k]), n[S].seriesRangeEnd.push(s.seriesRangeEnd[k])) : n[S].series.push(A), n[S].i.push(k), S !== "column" && S !== "bar" || (i.globals.columnSeries = n.column)) : ["heatmap", "treemap", "pie", "donut", "polarArea", "radialBar", "radar"].includes(S) ? h = S : S === "bar" ? (n.column.series.push(A), n.column.i.push(k)) : console.warn("You have specified an unrecognized series type (".concat(S, ").")), o !== S && S !== "scatter" && d++;
      }), d > 0 && (h && console.warn("Chart or series type ".concat(h, " cannot appear with other chart or series types.")), n.column.series.length > 0 && r.plotOptions.bar.horizontal && (d -= n.column.series.length, n.column = { series: [], i: [] }, i.globals.columnSeries = { series: [], i: [] }, console.warn("Horizontal bars are not supported in a mixed/combo chart. Please turn off `plotOptions.bar.horizontal`"))), s.comboCharts || (s.comboCharts = d > 0);
      var c = new Be(a, t), g = new Oe(a, t);
      a.pie = new ct(a);
      var p = new Nt(a);
      a.rangeBar = new Bt(a, t);
      var x = new Ot(a), f = [];
      if (s.comboCharts) {
        var m, v, w = new $(a);
        if (n.area.series.length > 0 && (m = f).push.apply(m, J(w.drawSeriesByGroup(n.area, s.areaGroups, "area", c))), n.column.series.length > 0)
          if (r.chart.stacked) {
            var l = new ot(a, t);
            f.push(l.draw(n.column.series, n.column.i));
          } else
            a.bar = new fe(a, t), f.push(a.bar.draw(n.column.series, n.column.i));
        if (n.rangeArea.series.length > 0 && f.push(c.draw(n.rangeArea.series, "rangeArea", n.rangeArea.i, n.rangeArea.seriesRangeEnd)), n.line.series.length > 0 && (v = f).push.apply(v, J(w.drawSeriesByGroup(n.line, s.lineGroups, "line", c))), n.candlestick.series.length > 0 && f.push(g.draw(n.candlestick.series, "candlestick", n.candlestick.i)), n.boxPlot.series.length > 0 && f.push(g.draw(n.boxPlot.series, "boxPlot", n.boxPlot.i)), n.rangeBar.series.length > 0 && f.push(a.rangeBar.draw(n.rangeBar.series, n.rangeBar.i)), n.scatter.series.length > 0) {
          var u = new Be(a, t, !0);
          f.push(u.draw(n.scatter.series, "scatter", n.scatter.i));
        }
        if (n.bubble.series.length > 0) {
          var b = new Be(a, t, !0);
          f.push(b.draw(n.bubble.series, "bubble", n.bubble.i));
        }
      } else
        switch (r.chart.type) {
          case "line":
            f = c.draw(s.series, "line");
            break;
          case "area":
            f = c.draw(s.series, "area");
            break;
          case "bar":
            r.chart.stacked ? f = new ot(a, t).draw(s.series) : (a.bar = new fe(a, t), f = a.bar.draw(s.series));
            break;
          case "candlestick":
            f = new Oe(a, t).draw(s.series, "candlestick");
            break;
          case "boxPlot":
            f = new Oe(a, t).draw(s.series, r.chart.type);
            break;
          case "rangeBar":
            f = a.rangeBar.draw(s.series);
            break;
          case "rangeArea":
            f = c.draw(s.seriesRangeStart, "rangeArea", void 0, s.seriesRangeEnd);
            break;
          case "heatmap":
            f = new Ht(a, t).draw(s.series);
            break;
          case "treemap":
            f = new _t(a, t).draw(s.series);
            break;
          case "pie":
          case "donut":
          case "polarArea":
            f = a.pie.draw(s.series);
            break;
          case "radialBar":
            f = p.draw(s.series);
            break;
          case "radar":
            f = x.draw(s.series);
            break;
          default:
            f = c.draw(s.series);
        }
      return f;
    } }, { key: "setSVGDimensions", value: function() {
      var e = this.w, t = e.globals, i = e.config;
      i.chart.width = i.chart.width || "100%", i.chart.height = i.chart.height || "auto", t.svgWidth = i.chart.width, t.svgHeight = i.chart.height;
      var a = P.getDimensions(this.el), r = i.chart.width.toString().split(/[0-9]+/g).pop();
      r === "%" ? P.isNumber(a[0]) && (a[0].width === 0 && (a = P.getDimensions(this.el.parentNode)), t.svgWidth = a[0] * parseInt(i.chart.width, 10) / 100) : r !== "px" && r !== "" || (t.svgWidth = parseInt(i.chart.width, 10));
      var s = String(i.chart.height).toString().split(/[0-9]+/g).pop();
      if (t.svgHeight !== "auto" && t.svgHeight !== "")
        if (s === "%") {
          var n = P.getDimensions(this.el.parentNode);
          t.svgHeight = n[1] * parseInt(i.chart.height, 10) / 100;
        } else
          t.svgHeight = parseInt(i.chart.height, 10);
      else
        t.svgHeight = t.axisCharts ? t.svgWidth / 1.61 : t.svgWidth / 1.2;
      if (t.svgWidth = Math.max(t.svgWidth, 0), t.svgHeight = Math.max(t.svgHeight, 0), X.setAttrs(t.dom.Paper.node, { width: t.svgWidth, height: t.svgHeight }), s !== "%") {
        var o = i.chart.sparkline.enabled ? 0 : t.axisCharts ? i.chart.parentHeightOffset : 0;
        t.dom.Paper.node.parentNode.parentNode.style.minHeight = "".concat(t.svgHeight + o, "px");
      }
      t.dom.elWrap.style.width = "".concat(t.svgWidth, "px"), t.dom.elWrap.style.height = "".concat(t.svgHeight, "px");
    } }, { key: "shiftGraphPosition", value: function() {
      var e = this.w.globals, t = e.translateY, i = e.translateX;
      X.setAttrs(e.dom.elGraphical.node, { transform: "translate(".concat(i, ", ").concat(t, ")") });
    } }, { key: "resizeNonAxisCharts", value: function() {
      var e = this.w, t = e.globals, i = 0, a = e.config.chart.sparkline.enabled ? 1 : 15;
      a += e.config.grid.padding.bottom, ["top", "bottom"].includes(e.config.legend.position) && e.config.legend.show && !e.config.legend.floating && (i = new it(this.ctx).legendHelpers.getLegendDimensions().clwh + 7);
      var r = e.globals.dom.baseEl.querySelector(".apexcharts-radialbar, .apexcharts-pie"), s = 2.05 * e.globals.radialSize;
      if (r && !e.config.chart.sparkline.enabled && e.config.plotOptions.radialBar.startAngle !== 0) {
        var n = P.getBoundingClientRect(r);
        s = n.bottom;
        var o = n.bottom - n.top;
        s = Math.max(2.05 * e.globals.radialSize, o);
      }
      var h = Math.ceil(s + t.translateY + i + a);
      t.dom.elLegendForeign && t.dom.elLegendForeign.setAttribute("height", h), e.config.chart.height && String(e.config.chart.height).includes("%") || (t.dom.elWrap.style.height = "".concat(h, "px"), X.setAttrs(t.dom.Paper.node, { height: h }), t.dom.Paper.node.parentNode.parentNode.style.minHeight = "".concat(h, "px"));
    } }, { key: "coreCalculations", value: function() {
      new Fe(this.ctx).init();
    } }, { key: "resetGlobals", value: function() {
      var e = this, t = function() {
        return e.w.config.series.map(function() {
          return [];
        });
      }, i = new Qe(), a = this.w.globals;
      i.initGlobalVars(a), a.seriesXvalues = t(), a.seriesYvalues = t();
    } }, { key: "isMultipleY", value: function() {
      return !!(Array.isArray(this.w.config.yaxis) && this.w.config.yaxis.length > 1) && (this.w.globals.isMultipleYAxis = !0, !0);
    } }, { key: "xySettings", value: function() {
      var e = this.w, t = null;
      if (e.globals.axisCharts) {
        if (e.config.xaxis.crosshairs.position === "back" && new He(this.ctx).drawXCrosshairs(), e.config.yaxis[0].crosshairs.position === "back" && new He(this.ctx).drawYCrosshairs(), e.config.xaxis.type === "datetime" && e.config.xaxis.labels.formatter === void 0) {
          this.ctx.timeScale = new qt(this.ctx);
          var i = [];
          isFinite(e.globals.minX) && isFinite(e.globals.maxX) && !e.globals.isBarHorizontal ? i = this.ctx.timeScale.calculateTimeScaleTicks(e.globals.minX, e.globals.maxX) : e.globals.isBarHorizontal && (i = this.ctx.timeScale.calculateTimeScaleTicks(e.globals.minY, e.globals.maxY)), this.ctx.timeScale.recalcDimensionsBasedOnFormat(i);
        }
        t = new $(this.ctx).getCalculatedRatios();
      }
      return t;
    } }, { key: "updateSourceChart", value: function(e) {
      this.ctx.w.globals.selection = void 0, this.ctx.updateHelpers._updateOptions({ chart: { selection: { xaxis: { min: e.w.globals.minX, max: e.w.globals.maxX } } } }, !1, !1);
    } }, { key: "setupBrushHandler", value: function() {
      var e = this, t = this.w;
      if (t.config.chart.brush.enabled && typeof t.config.chart.events.selection != "function") {
        var i = Array.isArray(t.config.chart.brush.targets) ? t.config.chart.brush.targets : [t.config.chart.brush.target];
        i.forEach(function(a) {
          var r = ApexCharts.getChartByID(a);
          r.w.globals.brushSource = e.ctx, typeof r.w.config.chart.events.zoomed != "function" && (r.w.config.chart.events.zoomed = function() {
            return e.updateSourceChart(r);
          }), typeof r.w.config.chart.events.scrolled != "function" && (r.w.config.chart.events.scrolled = function() {
            return e.updateSourceChart(r);
          });
        }), t.config.chart.events.selection = function(a, r) {
          i.forEach(function(s) {
            ApexCharts.getChartByID(s).ctx.updateHelpers._updateOptions({ xaxis: { min: r.xaxis.min, max: r.xaxis.max } }, !1, !1, !1, !1);
          });
        };
      }
    } }]), y;
  }(), $t = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "_updateOptions", value: function(e) {
      var t = this, i = arguments.length > 1 && arguments[1] !== void 0 && arguments[1], a = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2], r = !(arguments.length > 3 && arguments[3] !== void 0) || arguments[3], s = arguments.length > 4 && arguments[4] !== void 0 && arguments[4];
      return new Promise(function(n) {
        var o = [t.ctx];
        r && (o = t.ctx.getSyncedCharts()), t.ctx.w.globals.isExecCalled && (o = [t.ctx], t.ctx.w.globals.isExecCalled = !1), o.forEach(function(h, d) {
          var c = h.w;
          if (c.globals.shouldAnimate = a, i || (c.globals.resized = !0, c.globals.dataChanged = !0, a && h.series.getPreviousPaths()), e && Q(e) === "object" && (h.config = new ye(e), e = $.extendArrayProps(h.config, e, c), h.w.globals.chartID !== t.ctx.w.globals.chartID && delete e.series, c.config = P.extend(c.config, e), s && (c.globals.lastXAxis = e.xaxis ? P.clone(e.xaxis) : [], c.globals.lastYAxis = e.yaxis ? P.clone(e.yaxis) : [], c.globals.initialConfig = P.extend({}, c.config), c.globals.initialSeries = P.clone(c.config.series), e.series))) {
            for (var g = 0; g < c.globals.collapsedSeriesIndices.length; g++) {
              var p = c.config.series[c.globals.collapsedSeriesIndices[g]];
              c.globals.collapsedSeries[g].data = c.globals.axisCharts ? p.data.slice() : p;
            }
            for (var x = 0; x < c.globals.ancillaryCollapsedSeriesIndices.length; x++) {
              var f = c.config.series[c.globals.ancillaryCollapsedSeriesIndices[x]];
              c.globals.ancillaryCollapsedSeries[x].data = c.globals.axisCharts ? f.data.slice() : f;
            }
            h.series.emptyCollapsedSeries(c.config.series);
          }
          return h.update(e).then(function() {
            d === o.length - 1 && n(h);
          });
        });
      });
    } }, { key: "_updateSeries", value: function(e, t) {
      var i = this, a = arguments.length > 2 && arguments[2] !== void 0 && arguments[2];
      return new Promise(function(r) {
        var s, n = i.w;
        return n.globals.shouldAnimate = t, n.globals.dataChanged = !0, t && i.ctx.series.getPreviousPaths(), n.globals.axisCharts ? ((s = e.map(function(o, h) {
          return i._extendSeries(o, h);
        })).length === 0 && (s = [{ data: [] }]), n.config.series = s) : n.config.series = e.slice(), a && (n.globals.initialConfig.series = P.clone(n.config.series), n.globals.initialSeries = P.clone(n.config.series)), i.ctx.update().then(function() {
          r(i.ctx);
        });
      });
    } }, { key: "_extendSeries", value: function(e, t) {
      var i = this.w, a = i.config.series[t];
      return E(E({}, i.config.series[t]), {}, { name: e.name ? e.name : a == null ? void 0 : a.name, color: e.color ? e.color : a == null ? void 0 : a.color, type: e.type ? e.type : a == null ? void 0 : a.type, group: e.group ? e.group : a == null ? void 0 : a.group, hidden: e.hidden !== void 0 ? e.hidden : a == null ? void 0 : a.hidden, data: e.data ? e.data : a == null ? void 0 : a.data, zIndex: e.zIndex !== void 0 ? e.zIndex : t });
    } }, { key: "toggleDataPointSelection", value: function(e, t) {
      var i = this.w, a = null, r = ".apexcharts-series[data\\:realIndex='".concat(e, "']");
      return i.globals.axisCharts ? a = i.globals.dom.Paper.select("".concat(r, " path[j='").concat(t, "'], ").concat(r, " circle[j='").concat(t, "'], ").concat(r, " rect[j='").concat(t, "']")).members[0] : t === void 0 && (a = i.globals.dom.Paper.select("".concat(r, " path[j='").concat(e, "']")).members[0], i.config.chart.type !== "pie" && i.config.chart.type !== "polarArea" && i.config.chart.type !== "donut" || this.ctx.pie.pieClicked(e)), a ? (new X(this.ctx).pathMouseDown(a, null), a.node ? a.node : null) : (console.warn("toggleDataPointSelection: Element not found"), null);
    } }, { key: "forceXAxisUpdate", value: function(e) {
      var t = this.w;
      if (["min", "max"].forEach(function(a) {
        e.xaxis[a] !== void 0 && (t.config.xaxis[a] = e.xaxis[a], t.globals.lastXAxis[a] = e.xaxis[a]);
      }), e.xaxis.categories && e.xaxis.categories.length && (t.config.xaxis.categories = e.xaxis.categories), t.config.xaxis.convertedCatToNumeric) {
        var i = new ve(e);
        e = i.convertCatToNumericXaxis(e, this.ctx);
      }
      return e;
    } }, { key: "forceYAxisUpdate", value: function(e) {
      return e.chart && e.chart.stacked && e.chart.stackType === "100%" && (Array.isArray(e.yaxis) ? e.yaxis.forEach(function(t, i) {
        e.yaxis[i].min = 0, e.yaxis[i].max = 100;
      }) : (e.yaxis.min = 0, e.yaxis.max = 100)), e;
    } }, { key: "revertDefaultAxisMinMax", value: function(e) {
      var t = this, i = this.w, a = i.globals.lastXAxis, r = i.globals.lastYAxis;
      e && e.xaxis && (a = e.xaxis), e && e.yaxis && (r = e.yaxis), i.config.xaxis.min = a.min, i.config.xaxis.max = a.max;
      var s = function(n) {
        r[n] !== void 0 && (i.config.yaxis[n].min = r[n].min, i.config.yaxis[n].max = r[n].max);
      };
      i.config.yaxis.map(function(n, o) {
        i.globals.zoomed || r[o] !== void 0 ? s(o) : t.ctx.opts.yaxis[o] !== void 0 && (n.min = t.ctx.opts.yaxis[o].min, n.max = t.ctx.opts.yaxis[o].max);
      });
    } }]), y;
  }();
  de = typeof window < "u" ? window : void 0, Ie = function(y, e) {
    var t = (this !== void 0 ? this : y).SVG = function(l) {
      if (t.supported)
        return l = new t.Doc(l), t.parser.draw || t.prepare(), l;
    };
    if (t.ns = "http://www.w3.org/2000/svg", t.xmlns = "http://www.w3.org/2000/xmlns/", t.xlink = "http://www.w3.org/1999/xlink", t.svgjs = "http://svgjs.dev", t.supported = !0, !t.supported)
      return !1;
    t.did = 1e3, t.eid = function(l) {
      return "Svgjs" + d(l) + t.did++;
    }, t.create = function(l) {
      var u = e.createElementNS(this.ns, l);
      return u.setAttribute("id", this.eid(l)), u;
    }, t.extend = function() {
      var l, u;
      u = (l = [].slice.call(arguments)).pop();
      for (var b = l.length - 1; b >= 0; b--)
        if (l[b])
          for (var A in u)
            l[b].prototype[A] = u[A];
      t.Set && t.Set.inherit && t.Set.inherit();
    }, t.invent = function(l) {
      var u = typeof l.create == "function" ? l.create : function() {
        this.constructor.call(this, t.create(l.create));
      };
      return l.inherit && (u.prototype = new l.inherit()), l.extend && t.extend(u, l.extend), l.construct && t.extend(l.parent || t.Container, l.construct), u;
    }, t.adopt = function(l) {
      return l ? l.instance ? l.instance : ((u = l.nodeName == "svg" ? l.parentNode instanceof y.SVGElement ? new t.Nested() : new t.Doc() : l.nodeName == "linearGradient" ? new t.Gradient("linear") : l.nodeName == "radialGradient" ? new t.Gradient("radial") : t[d(l.nodeName)] ? new t[d(l.nodeName)]() : new t.Element(l)).type = l.nodeName, u.node = l, l.instance = u, u instanceof t.Doc && u.namespace().defs(), u.setData(JSON.parse(l.getAttribute("svgjs:data")) || {}), u) : null;
      var u;
    }, t.prepare = function() {
      var l = e.getElementsByTagName("body")[0], u = (l ? new t.Doc(l) : t.adopt(e.documentElement).nested()).size(2, 0);
      t.parser = { body: l || e.documentElement, draw: u.style("opacity:0;position:absolute;left:-100%;top:-100%;overflow:hidden").node, poly: u.polyline().node, path: u.path().node, native: t.create("svg") };
    }, t.parser = { native: t.create("svg") }, e.addEventListener("DOMContentLoaded", function() {
      t.parser.draw || t.prepare();
    }, !1), t.regex = { numberAndUnit: /^([+-]?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?)([a-z%]*)$/i, hex: /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i, rgb: /rgb\((\d+),(\d+),(\d+)\)/, reference: /#([a-z0-9\-_]+)/i, transforms: /\)\s*,?\s*/, whitespace: /\s/g, isHex: /^#[a-f0-9]{3,6}$/i, isRgb: /^rgb\(/, isCss: /[^:]+:[^;]+;?/, isBlank: /^(\s+)?$/, isNumber: /^[+-]?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i, isPercent: /^-?[\d\.]+%$/, isImage: /\.(jpg|jpeg|png|gif|svg)(\?[^=]+.*)?/i, delimiter: /[\s,]+/, hyphen: /([^e])\-/gi, pathLetters: /[MLHVCSQTAZ]/gi, isPathLetter: /[MLHVCSQTAZ]/i, numbersWithDots: /((\d?\.\d+(?:e[+-]?\d+)?)((?:\.\d+(?:e[+-]?\d+)?)+))+/gi, dots: /\./g }, t.utils = { map: function(l, u) {
      for (var b = l.length, A = [], k = 0; k < b; k++)
        A.push(u(l[k]));
      return A;
    }, filter: function(l, u) {
      for (var b = l.length, A = [], k = 0; k < b; k++)
        u(l[k]) && A.push(l[k]);
      return A;
    }, filterSVGElements: function(l) {
      return this.filter(l, function(u) {
        return u instanceof y.SVGElement;
      });
    } }, t.defaults = { attrs: { "fill-opacity": 1, "stroke-opacity": 1, "stroke-width": 0, "stroke-linejoin": "miter", "stroke-linecap": "butt", fill: "#000000", stroke: "#000000", opacity: 1, x: 0, y: 0, cx: 0, cy: 0, width: 0, height: 0, r: 0, rx: 0, ry: 0, offset: 0, "stop-opacity": 1, "stop-color": "#000000", "font-size": 16, "font-family": "Helvetica, Arial, sans-serif", "text-anchor": "start" } }, t.Color = function(l) {
      var u, b;
      this.r = 0, this.g = 0, this.b = 0, l && (typeof l == "string" ? t.regex.isRgb.test(l) ? (u = t.regex.rgb.exec(l.replace(t.regex.whitespace, "")), this.r = parseInt(u[1]), this.g = parseInt(u[2]), this.b = parseInt(u[3])) : t.regex.isHex.test(l) && (u = t.regex.hex.exec((b = l).length == 4 ? ["#", b.substring(1, 2), b.substring(1, 2), b.substring(2, 3), b.substring(2, 3), b.substring(3, 4), b.substring(3, 4)].join("") : b), this.r = parseInt(u[1], 16), this.g = parseInt(u[2], 16), this.b = parseInt(u[3], 16)) : Q(l) === "object" && (this.r = l.r, this.g = l.g, this.b = l.b));
    }, t.extend(t.Color, { toString: function() {
      return this.toHex();
    }, toHex: function() {
      return "#" + c(this.r) + c(this.g) + c(this.b);
    }, toRgb: function() {
      return "rgb(" + [this.r, this.g, this.b].join() + ")";
    }, brightness: function() {
      return this.r / 255 * 0.3 + this.g / 255 * 0.59 + this.b / 255 * 0.11;
    }, morph: function(l) {
      return this.destination = new t.Color(l), this;
    }, at: function(l) {
      return this.destination ? (l = l < 0 ? 0 : l > 1 ? 1 : l, new t.Color({ r: ~~(this.r + (this.destination.r - this.r) * l), g: ~~(this.g + (this.destination.g - this.g) * l), b: ~~(this.b + (this.destination.b - this.b) * l) })) : this;
    } }), t.Color.test = function(l) {
      return l += "", t.regex.isHex.test(l) || t.regex.isRgb.test(l);
    }, t.Color.isRgb = function(l) {
      return l && typeof l.r == "number" && typeof l.g == "number" && typeof l.b == "number";
    }, t.Color.isColor = function(l) {
      return t.Color.isRgb(l) || t.Color.test(l);
    }, t.Array = function(l, u) {
      (l = (l || []).valueOf()).length == 0 && u && (l = u.valueOf()), this.value = this.parse(l);
    }, t.extend(t.Array, { toString: function() {
      return this.value.join(" ");
    }, valueOf: function() {
      return this.value;
    }, parse: function(l) {
      return l = l.valueOf(), Array.isArray(l) ? l : this.split(l);
    } }), t.PointArray = function(l, u) {
      t.Array.call(this, l, u || [[0, 0]]);
    }, t.PointArray.prototype = new t.Array(), t.PointArray.prototype.constructor = t.PointArray;
    for (var i = { M: function(l, u, b) {
      return u.x = b.x = l[0], u.y = b.y = l[1], ["M", u.x, u.y];
    }, L: function(l, u) {
      return u.x = l[0], u.y = l[1], ["L", l[0], l[1]];
    }, H: function(l, u) {
      return u.x = l[0], ["H", l[0]];
    }, V: function(l, u) {
      return u.y = l[0], ["V", l[0]];
    }, C: function(l, u) {
      return u.x = l[4], u.y = l[5], ["C", l[0], l[1], l[2], l[3], l[4], l[5]];
    }, Q: function(l, u) {
      return u.x = l[2], u.y = l[3], ["Q", l[0], l[1], l[2], l[3]];
    }, S: function(l, u) {
      return u.x = l[2], u.y = l[3], ["S", l[0], l[1], l[2], l[3]];
    }, Z: function(l, u, b) {
      return u.x = b.x, u.y = b.y, ["Z"];
    } }, a = "mlhvqtcsaz".split(""), r = 0, s = a.length; r < s; ++r)
      i[a[r]] = function(l) {
        return function(u, b, A) {
          if (l == "H")
            u[0] = u[0] + b.x;
          else if (l == "V")
            u[0] = u[0] + b.y;
          else if (l == "A")
            u[5] = u[5] + b.x, u[6] = u[6] + b.y;
          else
            for (var k = 0, S = u.length; k < S; ++k)
              u[k] = u[k] + (k % 2 ? b.y : b.x);
          if (i && typeof i[l] == "function")
            return i[l](u, b, A);
        };
      }(a[r].toUpperCase());
    t.PathArray = function(l, u) {
      t.Array.call(this, l, u || [["M", 0, 0]]);
    }, t.PathArray.prototype = new t.Array(), t.PathArray.prototype.constructor = t.PathArray, t.extend(t.PathArray, { toString: function() {
      return function(l) {
        for (var u = 0, b = l.length, A = ""; u < b; u++)
          A += l[u][0], l[u][1] != null && (A += l[u][1], l[u][2] != null && (A += " ", A += l[u][2], l[u][3] != null && (A += " ", A += l[u][3], A += " ", A += l[u][4], l[u][5] != null && (A += " ", A += l[u][5], A += " ", A += l[u][6], l[u][7] != null && (A += " ", A += l[u][7])))));
        return A + " ";
      }(this.value);
    }, move: function(l, u) {
      var b = this.bbox();
      return b.x, b.y, this;
    }, at: function(l) {
      if (!this.destination)
        return this;
      for (var u = this.value, b = this.destination.value, A = [], k = new t.PathArray(), S = 0, C = u.length; S < C; S++) {
        A[S] = [u[S][0]];
        for (var L = 1, M = u[S].length; L < M; L++)
          A[S][L] = u[S][L] + (b[S][L] - u[S][L]) * l;
        A[S][0] === "A" && (A[S][4] = +(A[S][4] != 0), A[S][5] = +(A[S][5] != 0));
      }
      return k.value = A, k;
    }, parse: function(l) {
      if (l instanceof t.PathArray)
        return l.valueOf();
      var u, b = { M: 2, L: 2, H: 1, V: 1, C: 6, S: 4, Q: 4, T: 2, A: 7, Z: 0 };
      l = typeof l == "string" ? l.replace(t.regex.numbersWithDots, o).replace(t.regex.pathLetters, " $& ").replace(t.regex.hyphen, "$1 -").trim().split(t.regex.delimiter) : l.reduce(function(M, T) {
        return [].concat.call(M, T);
      }, []);
      var A = [], k = new t.Point(), S = new t.Point(), C = 0, L = l.length;
      do
        t.regex.isPathLetter.test(l[C]) ? (u = l[C], ++C) : u == "M" ? u = "L" : u == "m" && (u = "l"), A.push(i[u].call(null, l.slice(C, C += b[u.toUpperCase()]).map(parseFloat), k, S));
      while (L > C);
      return A;
    }, bbox: function() {
      return t.parser.draw || t.prepare(), t.parser.path.setAttribute("d", this.toString()), t.parser.path.getBBox();
    } }), t.Number = t.invent({ create: function(l, u) {
      this.value = 0, this.unit = u || "", typeof l == "number" ? this.value = isNaN(l) ? 0 : isFinite(l) ? l : l < 0 ? -34e37 : 34e37 : typeof l == "string" ? (u = l.match(t.regex.numberAndUnit)) && (this.value = parseFloat(u[1]), u[5] == "%" ? this.value /= 100 : u[5] == "s" && (this.value *= 1e3), this.unit = u[5]) : l instanceof t.Number && (this.value = l.valueOf(), this.unit = l.unit);
    }, extend: { toString: function() {
      return (this.unit == "%" ? ~~(1e8 * this.value) / 1e6 : this.unit == "s" ? this.value / 1e3 : this.value) + this.unit;
    }, toJSON: function() {
      return this.toString();
    }, valueOf: function() {
      return this.value;
    }, plus: function(l) {
      return l = new t.Number(l), new t.Number(this + l, this.unit || l.unit);
    }, minus: function(l) {
      return l = new t.Number(l), new t.Number(this - l, this.unit || l.unit);
    }, times: function(l) {
      return l = new t.Number(l), new t.Number(this * l, this.unit || l.unit);
    }, divide: function(l) {
      return l = new t.Number(l), new t.Number(this / l, this.unit || l.unit);
    }, to: function(l) {
      var u = new t.Number(this);
      return typeof l == "string" && (u.unit = l), u;
    }, morph: function(l) {
      return this.destination = new t.Number(l), l.relative && (this.destination.value += this.value), this;
    }, at: function(l) {
      return this.destination ? new t.Number(this.destination).minus(this).times(l).plus(this) : this;
    } } }), t.Element = t.invent({ create: function(l) {
      this._stroke = t.defaults.attrs.stroke, this._event = null, this.dom = {}, (this.node = l) && (this.type = l.nodeName, this.node.instance = this, this._stroke = l.getAttribute("stroke") || this._stroke);
    }, extend: { x: function(l) {
      return this.attr("x", l);
    }, y: function(l) {
      return this.attr("y", l);
    }, cx: function(l) {
      return l == null ? this.x() + this.width() / 2 : this.x(l - this.width() / 2);
    }, cy: function(l) {
      return l == null ? this.y() + this.height() / 2 : this.y(l - this.height() / 2);
    }, move: function(l, u) {
      return this.x(l).y(u);
    }, center: function(l, u) {
      return this.cx(l).cy(u);
    }, width: function(l) {
      return this.attr("width", l);
    }, height: function(l) {
      return this.attr("height", l);
    }, size: function(l, u) {
      var b = g(this, l, u);
      return this.width(new t.Number(b.width)).height(new t.Number(b.height));
    }, clone: function(l) {
      this.writeDataToDom();
      var u = f(this.node.cloneNode(!0));
      return l ? l.add(u) : this.after(u), u;
    }, remove: function() {
      return this.parent() && this.parent().removeElement(this), this;
    }, replace: function(l) {
      return this.after(l).remove(), l;
    }, addTo: function(l) {
      return l.put(this);
    }, putIn: function(l) {
      return l.add(this);
    }, id: function(l) {
      return this.attr("id", l);
    }, show: function() {
      return this.style("display", "");
    }, hide: function() {
      return this.style("display", "none");
    }, visible: function() {
      return this.style("display") != "none";
    }, toString: function() {
      return this.attr("id");
    }, classes: function() {
      var l = this.attr("class");
      return l == null ? [] : l.trim().split(t.regex.delimiter);
    }, hasClass: function(l) {
      return this.classes().indexOf(l) != -1;
    }, addClass: function(l) {
      if (!this.hasClass(l)) {
        var u = this.classes();
        u.push(l), this.attr("class", u.join(" "));
      }
      return this;
    }, removeClass: function(l) {
      return this.hasClass(l) && this.attr("class", this.classes().filter(function(u) {
        return u != l;
      }).join(" ")), this;
    }, toggleClass: function(l) {
      return this.hasClass(l) ? this.removeClass(l) : this.addClass(l);
    }, reference: function(l) {
      return t.get(this.attr(l));
    }, parent: function(l) {
      var u = this;
      if (!u.node.parentNode)
        return null;
      if (u = t.adopt(u.node.parentNode), !l)
        return u;
      for (; u && u.node instanceof y.SVGElement; ) {
        if (typeof l == "string" ? u.matches(l) : u instanceof l)
          return u;
        if (!u.node.parentNode || u.node.parentNode.nodeName == "#document")
          return null;
        u = t.adopt(u.node.parentNode);
      }
    }, doc: function() {
      return this instanceof t.Doc ? this : this.parent(t.Doc);
    }, parents: function(l) {
      var u = [], b = this;
      do {
        if (!(b = b.parent(l)) || !b.node)
          break;
        u.push(b);
      } while (b.parent);
      return u;
    }, matches: function(l) {
      return function(u, b) {
        return (u.matches || u.matchesSelector || u.msMatchesSelector || u.mozMatchesSelector || u.webkitMatchesSelector || u.oMatchesSelector).call(u, b);
      }(this.node, l);
    }, native: function() {
      return this.node;
    }, svg: function(l) {
      var u = e.createElementNS("http://www.w3.org/2000/svg", "svg");
      if (!(l && this instanceof t.Parent))
        return u.appendChild(l = e.createElementNS("http://www.w3.org/2000/svg", "svg")), this.writeDataToDom(), l.appendChild(this.node.cloneNode(!0)), u.innerHTML.replace(/^<svg>/, "").replace(/<\/svg>$/, "");
      u.innerHTML = "<svg>" + l.replace(/\n/, "").replace(/<([\w:-]+)([^<]+?)\/>/g, "<$1$2></$1>") + "</svg>";
      for (var b = 0, A = u.firstChild.childNodes.length; b < A; b++)
        this.node.appendChild(u.firstChild.firstChild);
      return this;
    }, writeDataToDom: function() {
      return (this.each || this.lines) && (this.each ? this : this.lines()).each(function() {
        this.writeDataToDom();
      }), this.node.removeAttribute("svgjs:data"), Object.keys(this.dom).length && this.node.setAttribute("svgjs:data", JSON.stringify(this.dom)), this;
    }, setData: function(l) {
      return this.dom = l, this;
    }, is: function(l) {
      return function(u, b) {
        return u instanceof b;
      }(this, l);
    } } }), t.easing = { "-": function(l) {
      return l;
    }, "<>": function(l) {
      return -Math.cos(l * Math.PI) / 2 + 0.5;
    }, ">": function(l) {
      return Math.sin(l * Math.PI / 2);
    }, "<": function(l) {
      return 1 - Math.cos(l * Math.PI / 2);
    } }, t.morph = function(l) {
      return function(u, b) {
        return new t.MorphObj(u, b).at(l);
      };
    }, t.Situation = t.invent({ create: function(l) {
      this.init = !1, this.reversed = !1, this.reversing = !1, this.duration = new t.Number(l.duration).valueOf(), this.delay = new t.Number(l.delay).valueOf(), this.start = +/* @__PURE__ */ new Date() + this.delay, this.finish = this.start + this.duration, this.ease = l.ease, this.loop = 0, this.loops = !1, this.animations = {}, this.attrs = {}, this.styles = {}, this.transforms = [], this.once = {};
    } }), t.FX = t.invent({ create: function(l) {
      this._target = l, this.situations = [], this.active = !1, this.situation = null, this.paused = !1, this.lastPos = 0, this.pos = 0, this.absPos = 0, this._speed = 1;
    }, extend: { animate: function(l, u, b) {
      Q(l) === "object" && (u = l.ease, b = l.delay, l = l.duration);
      var A = new t.Situation({ duration: l || 1e3, delay: b || 0, ease: t.easing[u || "-"] || u });
      return this.queue(A), this;
    }, target: function(l) {
      return l && l instanceof t.Element ? (this._target = l, this) : this._target;
    }, timeToAbsPos: function(l) {
      return (l - this.situation.start) / (this.situation.duration / this._speed);
    }, absPosToTime: function(l) {
      return this.situation.duration / this._speed * l + this.situation.start;
    }, startAnimFrame: function() {
      this.stopAnimFrame(), this.animationFrame = y.requestAnimationFrame((function() {
        this.step();
      }).bind(this));
    }, stopAnimFrame: function() {
      y.cancelAnimationFrame(this.animationFrame);
    }, start: function() {
      return !this.active && this.situation && (this.active = !0, this.startCurrent()), this;
    }, startCurrent: function() {
      return this.situation.start = +/* @__PURE__ */ new Date() + this.situation.delay / this._speed, this.situation.finish = this.situation.start + this.situation.duration / this._speed, this.initAnimations().step();
    }, queue: function(l) {
      return (typeof l == "function" || l instanceof t.Situation) && this.situations.push(l), this.situation || (this.situation = this.situations.shift()), this;
    }, dequeue: function() {
      return this.stop(), this.situation = this.situations.shift(), this.situation && (this.situation instanceof t.Situation ? this.start() : this.situation.call(this)), this;
    }, initAnimations: function() {
      var l, u = this.situation;
      if (u.init)
        return this;
      for (var b in u.animations) {
        l = this.target()[b](), Array.isArray(l) || (l = [l]), Array.isArray(u.animations[b]) || (u.animations[b] = [u.animations[b]]);
        for (var A = l.length; A--; )
          u.animations[b][A] instanceof t.Number && (l[A] = new t.Number(l[A])), u.animations[b][A] = l[A].morph(u.animations[b][A]);
      }
      for (var b in u.attrs)
        u.attrs[b] = new t.MorphObj(this.target().attr(b), u.attrs[b]);
      for (var b in u.styles)
        u.styles[b] = new t.MorphObj(this.target().style(b), u.styles[b]);
      return u.initialTransformation = this.target().matrixify(), u.init = !0, this;
    }, clearQueue: function() {
      return this.situations = [], this;
    }, clearCurrent: function() {
      return this.situation = null, this;
    }, stop: function(l, u) {
      var b = this.active;
      return this.active = !1, u && this.clearQueue(), l && this.situation && (!b && this.startCurrent(), this.atEnd()), this.stopAnimFrame(), this.clearCurrent();
    }, after: function(l) {
      var u = this.last();
      return this.target().on("finished.fx", function b(A) {
        A.detail.situation == u && (l.call(this, u), this.off("finished.fx", b));
      }), this._callStart();
    }, during: function(l) {
      var u = this.last(), b = function(A) {
        A.detail.situation == u && l.call(this, A.detail.pos, t.morph(A.detail.pos), A.detail.eased, u);
      };
      return this.target().off("during.fx", b).on("during.fx", b), this.after(function() {
        this.off("during.fx", b);
      }), this._callStart();
    }, afterAll: function(l) {
      var u = function b(A) {
        l.call(this), this.off("allfinished.fx", b);
      };
      return this.target().off("allfinished.fx", u).on("allfinished.fx", u), this._callStart();
    }, last: function() {
      return this.situations.length ? this.situations[this.situations.length - 1] : this.situation;
    }, add: function(l, u, b) {
      return this.last()[b || "animations"][l] = u, this._callStart();
    }, step: function(l) {
      var u, b, A;
      l || (this.absPos = this.timeToAbsPos(+/* @__PURE__ */ new Date())), this.situation.loops !== !1 ? (u = Math.max(this.absPos, 0), b = Math.floor(u), this.situation.loops === !0 || b < this.situation.loops ? (this.pos = u - b, A = this.situation.loop, this.situation.loop = b) : (this.absPos = this.situation.loops, this.pos = 1, A = this.situation.loop - 1, this.situation.loop = this.situation.loops), this.situation.reversing && (this.situation.reversed = this.situation.reversed != !!((this.situation.loop - A) % 2))) : (this.absPos = Math.min(this.absPos, 1), this.pos = this.absPos), this.pos < 0 && (this.pos = 0), this.situation.reversed && (this.pos = 1 - this.pos);
      var k = this.situation.ease(this.pos);
      for (var S in this.situation.once)
        S > this.lastPos && S <= k && (this.situation.once[S].call(this.target(), this.pos, k), delete this.situation.once[S]);
      return this.active && this.target().fire("during", { pos: this.pos, eased: k, fx: this, situation: this.situation }), this.situation ? (this.eachAt(), this.pos == 1 && !this.situation.reversed || this.situation.reversed && this.pos == 0 ? (this.stopAnimFrame(), this.target().fire("finished", { fx: this, situation: this.situation }), this.situations.length || (this.target().fire("allfinished"), this.situations.length || (this.target().off(".fx"), this.active = !1)), this.active ? this.dequeue() : this.clearCurrent()) : !this.paused && this.active && this.startAnimFrame(), this.lastPos = k, this) : this;
    }, eachAt: function() {
      var l, u = this, b = this.target(), A = this.situation;
      for (var k in A.animations)
        l = [].concat(A.animations[k]).map(function(L) {
          return typeof L != "string" && L.at ? L.at(A.ease(u.pos), u.pos) : L;
        }), b[k].apply(b, l);
      for (var k in A.attrs)
        l = [k].concat(A.attrs[k]).map(function(M) {
          return typeof M != "string" && M.at ? M.at(A.ease(u.pos), u.pos) : M;
        }), b.attr.apply(b, l);
      for (var k in A.styles)
        l = [k].concat(A.styles[k]).map(function(M) {
          return typeof M != "string" && M.at ? M.at(A.ease(u.pos), u.pos) : M;
        }), b.style.apply(b, l);
      if (A.transforms.length) {
        l = A.initialTransformation, k = 0;
        for (var S = A.transforms.length; k < S; k++) {
          var C = A.transforms[k];
          C instanceof t.Matrix ? l = C.relative ? l.multiply(new t.Matrix().morph(C).at(A.ease(this.pos))) : l.morph(C).at(A.ease(this.pos)) : (C.relative || C.undo(l.extract()), l = l.multiply(C.at(A.ease(this.pos))));
        }
        b.matrix(l);
      }
      return this;
    }, once: function(l, u, b) {
      var A = this.last();
      return b || (l = A.ease(l)), A.once[l] = u, this;
    }, _callStart: function() {
      return setTimeout((function() {
        this.start();
      }).bind(this), 0), this;
    } }, parent: t.Element, construct: { animate: function(l, u, b) {
      return (this.fx || (this.fx = new t.FX(this))).animate(l, u, b);
    }, delay: function(l) {
      return (this.fx || (this.fx = new t.FX(this))).delay(l);
    }, stop: function(l, u) {
      return this.fx && this.fx.stop(l, u), this;
    }, finish: function() {
      return this.fx && this.fx.finish(), this;
    } } }), t.MorphObj = t.invent({ create: function(l, u) {
      return t.Color.isColor(u) ? new t.Color(l).morph(u) : t.regex.delimiter.test(l) ? t.regex.pathLetters.test(l) ? new t.PathArray(l).morph(u) : new t.Array(l).morph(u) : t.regex.numberAndUnit.test(u) ? new t.Number(l).morph(u) : (this.value = l, void (this.destination = u));
    }, extend: { at: function(l, u) {
      return u < 1 ? this.value : this.destination;
    }, valueOf: function() {
      return this.value;
    } } }), t.extend(t.FX, { attr: function(l, u, b) {
      if (Q(l) === "object")
        for (var A in l)
          this.attr(A, l[A]);
      else
        this.add(l, u, "attrs");
      return this;
    }, plot: function(l, u, b, A) {
      return arguments.length == 4 ? this.plot([l, u, b, A]) : this.add("plot", new (this.target()).morphArray(l));
    } }), t.Box = t.invent({ create: function(l, u, b, A) {
      if (!(Q(l) !== "object" || l instanceof t.Element))
        return t.Box.call(this, l.left != null ? l.left : l.x, l.top != null ? l.top : l.y, l.width, l.height);
      var k;
      arguments.length == 4 && (this.x = l, this.y = u, this.width = b, this.height = A), (k = this).x == null && (k.x = 0, k.y = 0, k.width = 0, k.height = 0), k.w = k.width, k.h = k.height, k.x2 = k.x + k.width, k.y2 = k.y + k.height, k.cx = k.x + k.width / 2, k.cy = k.y + k.height / 2;
    } }), t.BBox = t.invent({ create: function(l) {
      if (t.Box.apply(this, [].slice.call(arguments)), l instanceof t.Element) {
        var u;
        try {
          if (!e.documentElement.contains) {
            for (var b = l.node; b.parentNode; )
              b = b.parentNode;
            if (b != e)
              throw new Error("Element not in the dom");
          }
          u = l.node.getBBox();
        } catch {
          if (l instanceof t.Shape) {
            t.parser.draw || t.prepare();
            var A = l.clone(t.parser.draw.instance).show();
            A && A.node && typeof A.node.getBBox == "function" && (u = A.node.getBBox()), A && typeof A.remove == "function" && A.remove();
          } else
            u = { x: l.node.clientLeft, y: l.node.clientTop, width: l.node.clientWidth, height: l.node.clientHeight };
        }
        t.Box.call(this, u);
      }
    }, inherit: t.Box, parent: t.Element, construct: { bbox: function() {
      return new t.BBox(this);
    } } }), t.BBox.prototype.constructor = t.BBox, t.Matrix = t.invent({ create: function(l) {
      var u = x([1, 0, 0, 1, 0, 0]);
      l = l === null ? u : l instanceof t.Element ? l.matrixify() : typeof l == "string" ? x(l.split(t.regex.delimiter).map(parseFloat)) : arguments.length == 6 ? x([].slice.call(arguments)) : Array.isArray(l) ? x(l) : l && Q(l) === "object" ? l : u;
      for (var b = v.length - 1; b >= 0; --b)
        this[v[b]] = l[v[b]] != null ? l[v[b]] : u[v[b]];
    }, extend: { extract: function() {
      var l = p(this, 0, 1);
      p(this, 1, 0);
      var u = 180 / Math.PI * Math.atan2(l.y, l.x) - 90;
      return { x: this.e, y: this.f, transformedX: (this.e * Math.cos(u * Math.PI / 180) + this.f * Math.sin(u * Math.PI / 180)) / Math.sqrt(this.a * this.a + this.b * this.b), transformedY: (this.f * Math.cos(u * Math.PI / 180) + this.e * Math.sin(-u * Math.PI / 180)) / Math.sqrt(this.c * this.c + this.d * this.d), rotation: u, a: this.a, b: this.b, c: this.c, d: this.d, e: this.e, f: this.f, matrix: new t.Matrix(this) };
    }, clone: function() {
      return new t.Matrix(this);
    }, morph: function(l) {
      return this.destination = new t.Matrix(l), this;
    }, multiply: function(l) {
      return new t.Matrix(this.native().multiply(function(u) {
        return u instanceof t.Matrix || (u = new t.Matrix(u)), u;
      }(l).native()));
    }, inverse: function() {
      return new t.Matrix(this.native().inverse());
    }, translate: function(l, u) {
      return new t.Matrix(this.native().translate(l || 0, u || 0));
    }, native: function() {
      for (var l = t.parser.native.createSVGMatrix(), u = v.length - 1; u >= 0; u--)
        l[v[u]] = this[v[u]];
      return l;
    }, toString: function() {
      return "matrix(" + m(this.a) + "," + m(this.b) + "," + m(this.c) + "," + m(this.d) + "," + m(this.e) + "," + m(this.f) + ")";
    } }, parent: t.Element, construct: { ctm: function() {
      return new t.Matrix(this.node.getCTM());
    }, screenCTM: function() {
      if (this instanceof t.Nested) {
        var l = this.rect(1, 1), u = l.node.getScreenCTM();
        return l.remove(), new t.Matrix(u);
      }
      return new t.Matrix(this.node.getScreenCTM());
    } } }), t.Point = t.invent({ create: function(l, u) {
      var b;
      b = Array.isArray(l) ? { x: l[0], y: l[1] } : Q(l) === "object" ? { x: l.x, y: l.y } : l != null ? { x: l, y: u ?? l } : { x: 0, y: 0 }, this.x = b.x, this.y = b.y;
    }, extend: { clone: function() {
      return new t.Point(this);
    }, morph: function(l, u) {
      return this.destination = new t.Point(l, u), this;
    } } }), t.extend(t.Element, { point: function(l, u) {
      return new t.Point(l, u).transform(this.screenCTM().inverse());
    } }), t.extend(t.Element, { attr: function(l, u, b) {
      if (l == null) {
        for (l = {}, b = (u = this.node.attributes).length - 1; b >= 0; b--)
          l[u[b].nodeName] = t.regex.isNumber.test(u[b].nodeValue) ? parseFloat(u[b].nodeValue) : u[b].nodeValue;
        return l;
      }
      if (Q(l) === "object")
        for (var A in l)
          this.attr(A, l[A]);
      else if (u === null)
        this.node.removeAttribute(l);
      else {
        if (u == null)
          return (u = this.node.getAttribute(l)) == null ? t.defaults.attrs[l] : t.regex.isNumber.test(u) ? parseFloat(u) : u;
        l == "stroke-width" ? this.attr("stroke", parseFloat(u) > 0 ? this._stroke : null) : l == "stroke" && (this._stroke = u), l != "fill" && l != "stroke" || (t.regex.isImage.test(u) && (u = this.doc().defs().image(u, 0, 0)), u instanceof t.Image && (u = this.doc().defs().pattern(0, 0, function() {
          this.add(u);
        }))), typeof u == "number" ? u = new t.Number(u) : t.Color.isColor(u) ? u = new t.Color(u) : Array.isArray(u) && (u = new t.Array(u)), l == "leading" ? this.leading && this.leading(u) : typeof b == "string" ? this.node.setAttributeNS(b, l, u.toString()) : this.node.setAttribute(l, u.toString()), !this.rebuild || l != "font-size" && l != "x" || this.rebuild(l, u);
      }
      return this;
    } }), t.extend(t.Element, { transform: function(l, u) {
      var b;
      return Q(l) !== "object" ? (b = new t.Matrix(this).extract(), typeof l == "string" ? b[l] : b) : (b = new t.Matrix(this), u = !!u || !!l.relative, l.a != null && (b = u ? b.multiply(new t.Matrix(l)) : new t.Matrix(l)), this.attr("transform", b));
    } }), t.extend(t.Element, { untransform: function() {
      return this.attr("transform", null);
    }, matrixify: function() {
      return (this.attr("transform") || "").split(t.regex.transforms).slice(0, -1).map(function(l) {
        var u = l.trim().split("(");
        return [u[0], u[1].split(t.regex.delimiter).map(function(b) {
          return parseFloat(b);
        })];
      }).reduce(function(l, u) {
        return u[0] == "matrix" ? l.multiply(x(u[1])) : l[u[0]].apply(l, u[1]);
      }, new t.Matrix());
    }, toParent: function(l) {
      if (this == l)
        return this;
      var u = this.screenCTM(), b = l.screenCTM().inverse();
      return this.addTo(l).untransform().transform(b.multiply(u)), this;
    }, toDoc: function() {
      return this.toParent(this.doc());
    } }), t.Transformation = t.invent({ create: function(l, u) {
      if (arguments.length > 1 && typeof u != "boolean")
        return this.constructor.call(this, [].slice.call(arguments));
      if (Array.isArray(l))
        for (var b = 0, A = this.arguments.length; b < A; ++b)
          this[this.arguments[b]] = l[b];
      else if (l && Q(l) === "object")
        for (b = 0, A = this.arguments.length; b < A; ++b)
          this[this.arguments[b]] = l[this.arguments[b]];
      this.inversed = !1, u === !0 && (this.inversed = !0);
    } }), t.Translate = t.invent({ parent: t.Matrix, inherit: t.Transformation, create: function(l, u) {
      this.constructor.apply(this, [].slice.call(arguments));
    }, extend: { arguments: ["transformedX", "transformedY"], method: "translate" } }), t.extend(t.Element, { style: function(l, u) {
      if (arguments.length == 0)
        return this.node.style.cssText || "";
      if (arguments.length < 2)
        if (Q(l) === "object")
          for (var b in l)
            this.style(b, l[b]);
        else {
          if (!t.regex.isCss.test(l))
            return this.node.style[h(l)];
          for (l = l.split(/\s*;\s*/).filter(function(A) {
            return !!A;
          }).map(function(A) {
            return A.split(/\s*:\s*/);
          }); u = l.pop(); )
            this.style(u[0], u[1]);
        }
      else
        this.node.style[h(l)] = u === null || t.regex.isBlank.test(u) ? "" : u;
      return this;
    } }), t.Parent = t.invent({ create: function(l) {
      this.constructor.call(this, l);
    }, inherit: t.Element, extend: { children: function() {
      return t.utils.map(t.utils.filterSVGElements(this.node.childNodes), function(l) {
        return t.adopt(l);
      });
    }, add: function(l, u) {
      return u == null ? this.node.appendChild(l.node) : l.node != this.node.childNodes[u] && this.node.insertBefore(l.node, this.node.childNodes[u]), this;
    }, put: function(l, u) {
      return this.add(l, u), l;
    }, has: function(l) {
      return this.index(l) >= 0;
    }, index: function(l) {
      return [].slice.call(this.node.childNodes).indexOf(l.node);
    }, get: function(l) {
      return t.adopt(this.node.childNodes[l]);
    }, first: function() {
      return this.get(0);
    }, last: function() {
      return this.get(this.node.childNodes.length - 1);
    }, each: function(l, u) {
      for (var b = this.children(), A = 0, k = b.length; A < k; A++)
        b[A] instanceof t.Element && l.apply(b[A], [A, b]), u && b[A] instanceof t.Container && b[A].each(l, u);
      return this;
    }, removeElement: function(l) {
      return this.node.removeChild(l.node), this;
    }, clear: function() {
      for (; this.node.hasChildNodes(); )
        this.node.removeChild(this.node.lastChild);
      return delete this._defs, this;
    }, defs: function() {
      return this.doc().defs();
    } } }), t.extend(t.Parent, { ungroup: function(l, u) {
      return u === 0 || this instanceof t.Defs || this.node == t.parser.draw || (l = l || (this instanceof t.Doc ? this : this.parent(t.Parent)), u = u || 1 / 0, this.each(function() {
        return this instanceof t.Defs ? this : this instanceof t.Parent ? this.ungroup(l, u - 1) : this.toParent(l);
      }), this.node.firstChild || this.remove()), this;
    }, flatten: function(l, u) {
      return this.ungroup(l, u);
    } }), t.Container = t.invent({ create: function(l) {
      this.constructor.call(this, l);
    }, inherit: t.Parent }), t.ViewBox = t.invent({ parent: t.Container, construct: {} }), ["click", "dblclick", "mousedown", "mouseup", "mouseover", "mouseout", "mousemove", "touchstart", "touchmove", "touchleave", "touchend", "touchcancel"].forEach(function(l) {
      t.Element.prototype[l] = function(u) {
        return t.on(this.node, l, u), this;
      };
    }), t.listeners = [], t.handlerMap = [], t.listenerId = 0, t.on = function(l, u, b, A, k) {
      var S = b.bind(A || l.instance || l), C = (t.handlerMap.indexOf(l) + 1 || t.handlerMap.push(l)) - 1, L = u.split(".")[0], M = u.split(".")[1] || "*";
      t.listeners[C] = t.listeners[C] || {}, t.listeners[C][L] = t.listeners[C][L] || {}, t.listeners[C][L][M] = t.listeners[C][L][M] || {}, b._svgjsListenerId || (b._svgjsListenerId = ++t.listenerId), t.listeners[C][L][M][b._svgjsListenerId] = S, l.addEventListener(L, S, k || { passive: !1 });
    }, t.off = function(l, u, b) {
      var A = t.handlerMap.indexOf(l), k = u && u.split(".")[0], S = u && u.split(".")[1], C = "";
      if (A != -1)
        if (b) {
          if (typeof b == "function" && (b = b._svgjsListenerId), !b)
            return;
          t.listeners[A][k] && t.listeners[A][k][S || "*"] && (l.removeEventListener(k, t.listeners[A][k][S || "*"][b], !1), delete t.listeners[A][k][S || "*"][b]);
        } else if (S && k) {
          if (t.listeners[A][k] && t.listeners[A][k][S]) {
            for (var L in t.listeners[A][k][S])
              t.off(l, [k, S].join("."), L);
            delete t.listeners[A][k][S];
          }
        } else if (S)
          for (var M in t.listeners[A])
            for (var C in t.listeners[A][M])
              S === C && t.off(l, [M, S].join("."));
        else if (k) {
          if (t.listeners[A][k]) {
            for (var C in t.listeners[A][k])
              t.off(l, [k, C].join("."));
            delete t.listeners[A][k];
          }
        } else {
          for (var M in t.listeners[A])
            t.off(l, M);
          delete t.listeners[A], delete t.handlerMap[A];
        }
    }, t.extend(t.Element, { on: function(l, u, b, A) {
      return t.on(this.node, l, u, b, A), this;
    }, off: function(l, u) {
      return t.off(this.node, l, u), this;
    }, fire: function(l, u) {
      return l instanceof y.Event ? this.node.dispatchEvent(l) : this.node.dispatchEvent(l = new t.CustomEvent(l, { detail: u, cancelable: !0 })), this._event = l, this;
    }, event: function() {
      return this._event;
    } }), t.Defs = t.invent({ create: "defs", inherit: t.Container }), t.G = t.invent({ create: "g", inherit: t.Container, extend: { x: function(l) {
      return l == null ? this.transform("x") : this.transform({ x: l - this.x() }, !0);
    } }, construct: { group: function() {
      return this.put(new t.G());
    } } }), t.Doc = t.invent({ create: function(l) {
      l && ((l = typeof l == "string" ? e.getElementById(l) : l).nodeName == "svg" ? this.constructor.call(this, l) : (this.constructor.call(this, t.create("svg")), l.appendChild(this.node), this.size("100%", "100%")), this.namespace().defs());
    }, inherit: t.Container, extend: { namespace: function() {
      return this.attr({ xmlns: t.ns, version: "1.1" }).attr("xmlns:xlink", t.xlink, t.xmlns).attr("xmlns:svgjs", t.svgjs, t.xmlns);
    }, defs: function() {
      var l;
      return this._defs || ((l = this.node.getElementsByTagName("defs")[0]) ? this._defs = t.adopt(l) : this._defs = new t.Defs(), this.node.appendChild(this._defs.node)), this._defs;
    }, parent: function() {
      return this.node.parentNode && this.node.parentNode.nodeName != "#document" ? this.node.parentNode : null;
    }, remove: function() {
      return this.parent() && this.parent().removeChild(this.node), this;
    }, clear: function() {
      for (; this.node.hasChildNodes(); )
        this.node.removeChild(this.node.lastChild);
      return delete this._defs, t.parser.draw && !t.parser.draw.parentNode && this.node.appendChild(t.parser.draw), this;
    }, clone: function(l) {
      this.writeDataToDom();
      var u = this.node, b = f(u.cloneNode(!0));
      return l ? (l.node || l).appendChild(b.node) : u.parentNode.insertBefore(b.node, u.nextSibling), b;
    } } }), t.extend(t.Element, {}), t.Gradient = t.invent({ create: function(l) {
      this.constructor.call(this, t.create(l + "Gradient")), this.type = l;
    }, inherit: t.Container, extend: { at: function(l, u, b) {
      return this.put(new t.Stop()).update(l, u, b);
    }, update: function(l) {
      return this.clear(), typeof l == "function" && l.call(this, this), this;
    }, fill: function() {
      return "url(#" + this.id() + ")";
    }, toString: function() {
      return this.fill();
    }, attr: function(l, u, b) {
      return l == "transform" && (l = "gradientTransform"), t.Container.prototype.attr.call(this, l, u, b);
    } }, construct: { gradient: function(l, u) {
      return this.defs().gradient(l, u);
    } } }), t.extend(t.Gradient, t.FX, { from: function(l, u) {
      return (this._target || this).type == "radial" ? this.attr({ fx: new t.Number(l), fy: new t.Number(u) }) : this.attr({ x1: new t.Number(l), y1: new t.Number(u) });
    }, to: function(l, u) {
      return (this._target || this).type == "radial" ? this.attr({ cx: new t.Number(l), cy: new t.Number(u) }) : this.attr({ x2: new t.Number(l), y2: new t.Number(u) });
    } }), t.extend(t.Defs, { gradient: function(l, u) {
      return this.put(new t.Gradient(l)).update(u);
    } }), t.Stop = t.invent({ create: "stop", inherit: t.Element, extend: { update: function(l) {
      return (typeof l == "number" || l instanceof t.Number) && (l = { offset: arguments[0], color: arguments[1], opacity: arguments[2] }), l.opacity != null && this.attr("stop-opacity", l.opacity), l.color != null && this.attr("stop-color", l.color), l.offset != null && this.attr("offset", new t.Number(l.offset)), this;
    } } }), t.Pattern = t.invent({ create: "pattern", inherit: t.Container, extend: { fill: function() {
      return "url(#" + this.id() + ")";
    }, update: function(l) {
      return this.clear(), typeof l == "function" && l.call(this, this), this;
    }, toString: function() {
      return this.fill();
    }, attr: function(l, u, b) {
      return l == "transform" && (l = "patternTransform"), t.Container.prototype.attr.call(this, l, u, b);
    } }, construct: { pattern: function(l, u, b) {
      return this.defs().pattern(l, u, b);
    } } }), t.extend(t.Defs, { pattern: function(l, u, b) {
      return this.put(new t.Pattern()).update(b).attr({ x: 0, y: 0, width: l, height: u, patternUnits: "userSpaceOnUse" });
    } }), t.Shape = t.invent({ create: function(l) {
      this.constructor.call(this, l);
    }, inherit: t.Element }), t.Symbol = t.invent({ create: "symbol", inherit: t.Container, construct: { symbol: function() {
      return this.put(new t.Symbol());
    } } }), t.Use = t.invent({ create: "use", inherit: t.Shape, extend: { element: function(l, u) {
      return this.attr("href", (u || "") + "#" + l, t.xlink);
    } }, construct: { use: function(l, u) {
      return this.put(new t.Use()).element(l, u);
    } } }), t.Rect = t.invent({ create: "rect", inherit: t.Shape, construct: { rect: function(l, u) {
      return this.put(new t.Rect()).size(l, u);
    } } }), t.Circle = t.invent({ create: "circle", inherit: t.Shape, construct: { circle: function(l) {
      return this.put(new t.Circle()).rx(new t.Number(l).divide(2)).move(0, 0);
    } } }), t.extend(t.Circle, t.FX, { rx: function(l) {
      return this.attr("r", l);
    }, ry: function(l) {
      return this.rx(l);
    } }), t.Ellipse = t.invent({ create: "ellipse", inherit: t.Shape, construct: { ellipse: function(l, u) {
      return this.put(new t.Ellipse()).size(l, u).move(0, 0);
    } } }), t.extend(t.Ellipse, t.Rect, t.FX, { rx: function(l) {
      return this.attr("rx", l);
    }, ry: function(l) {
      return this.attr("ry", l);
    } }), t.extend(t.Circle, t.Ellipse, { x: function(l) {
      return l == null ? this.cx() - this.rx() : this.cx(l + this.rx());
    }, y: function(l) {
      return l == null ? this.cy() - this.ry() : this.cy(l + this.ry());
    }, cx: function(l) {
      return l == null ? this.attr("cx") : this.attr("cx", l);
    }, cy: function(l) {
      return l == null ? this.attr("cy") : this.attr("cy", l);
    }, width: function(l) {
      return l == null ? 2 * this.rx() : this.rx(new t.Number(l).divide(2));
    }, height: function(l) {
      return l == null ? 2 * this.ry() : this.ry(new t.Number(l).divide(2));
    }, size: function(l, u) {
      var b = g(this, l, u);
      return this.rx(new t.Number(b.width).divide(2)).ry(new t.Number(b.height).divide(2));
    } }), t.Line = t.invent({ create: "line", inherit: t.Shape, extend: { array: function() {
      return new t.PointArray([[this.attr("x1"), this.attr("y1")], [this.attr("x2"), this.attr("y2")]]);
    }, plot: function(l, u, b, A) {
      return l == null ? this.array() : (l = u !== void 0 ? { x1: l, y1: u, x2: b, y2: A } : new t.PointArray(l).toLine(), this.attr(l));
    }, move: function(l, u) {
      return this.attr(this.array().move(l, u).toLine());
    }, size: function(l, u) {
      var b = g(this, l, u);
      return this.attr(this.array().size(b.width, b.height).toLine());
    } }, construct: { line: function(l, u, b, A) {
      return t.Line.prototype.plot.apply(this.put(new t.Line()), l != null ? [l, u, b, A] : [0, 0, 0, 0]);
    } } }), t.Polyline = t.invent({ create: "polyline", inherit: t.Shape, construct: { polyline: function(l) {
      return this.put(new t.Polyline()).plot(l || new t.PointArray());
    } } }), t.Polygon = t.invent({ create: "polygon", inherit: t.Shape, construct: { polygon: function(l) {
      return this.put(new t.Polygon()).plot(l || new t.PointArray());
    } } }), t.extend(t.Polyline, t.Polygon, { array: function() {
      return this._array || (this._array = new t.PointArray(this.attr("points")));
    }, plot: function(l) {
      return l == null ? this.array() : this.clear().attr("points", typeof l == "string" ? l : this._array = new t.PointArray(l));
    }, clear: function() {
      return delete this._array, this;
    }, move: function(l, u) {
      return this.attr("points", this.array().move(l, u));
    }, size: function(l, u) {
      var b = g(this, l, u);
      return this.attr("points", this.array().size(b.width, b.height));
    } }), t.extend(t.Line, t.Polyline, t.Polygon, { morphArray: t.PointArray, x: function(l) {
      return l == null ? this.bbox().x : this.move(l, this.bbox().y);
    }, y: function(l) {
      return l == null ? this.bbox().y : this.move(this.bbox().x, l);
    }, width: function(l) {
      var u = this.bbox();
      return l == null ? u.width : this.size(l, u.height);
    }, height: function(l) {
      var u = this.bbox();
      return l == null ? u.height : this.size(u.width, l);
    } }), t.Path = t.invent({ create: "path", inherit: t.Shape, extend: { morphArray: t.PathArray, array: function() {
      return this._array || (this._array = new t.PathArray(this.attr("d")));
    }, plot: function(l) {
      return l == null ? this.array() : this.clear().attr("d", typeof l == "string" ? l : this._array = new t.PathArray(l));
    }, clear: function() {
      return delete this._array, this;
    } }, construct: { path: function(l) {
      return this.put(new t.Path()).plot(l || new t.PathArray());
    } } }), t.Image = t.invent({ create: "image", inherit: t.Shape, extend: { load: function(l) {
      if (!l)
        return this;
      var u = this, b = new y.Image();
      return t.on(b, "load", function() {
        t.off(b);
        var A = u.parent(t.Pattern);
        A !== null && (u.width() == 0 && u.height() == 0 && u.size(b.width, b.height), A && A.width() == 0 && A.height() == 0 && A.size(u.width(), u.height()), typeof u._loaded == "function" && u._loaded.call(u, { width: b.width, height: b.height, ratio: b.width / b.height, url: l }));
      }), t.on(b, "error", function(A) {
        t.off(b), typeof u._error == "function" && u._error.call(u, A);
      }), this.attr("href", b.src = this.src = l, t.xlink);
    }, loaded: function(l) {
      return this._loaded = l, this;
    }, error: function(l) {
      return this._error = l, this;
    } }, construct: { image: function(l, u, b) {
      return this.put(new t.Image()).load(l).size(u || 0, b || u || 0);
    } } }), t.Text = t.invent({ create: function() {
      this.constructor.call(this, t.create("text")), this.dom.leading = new t.Number(1.3), this._rebuild = !0, this._build = !1, this.attr("font-family", t.defaults.attrs["font-family"]);
    }, inherit: t.Shape, extend: { x: function(l) {
      return l == null ? this.attr("x") : this.attr("x", l);
    }, text: function(l) {
      if (l === void 0) {
        l = "";
        for (var u = this.node.childNodes, b = 0, A = u.length; b < A; ++b)
          b != 0 && u[b].nodeType != 3 && t.adopt(u[b]).dom.newLined == 1 && (l += `
`), l += u[b].textContent;
        return l;
      }
      if (this.clear().build(!0), typeof l == "function")
        l.call(this, this);
      else {
        b = 0;
        for (var k = (l = l.split(`
`)).length; b < k; b++)
          this.tspan(l[b]).newLine();
      }
      return this.build(!1).rebuild();
    }, size: function(l) {
      return this.attr("font-size", l).rebuild();
    }, leading: function(l) {
      return l == null ? this.dom.leading : (this.dom.leading = new t.Number(l), this.rebuild());
    }, lines: function() {
      var l = (this.textPath && this.textPath() || this).node, u = t.utils.map(t.utils.filterSVGElements(l.childNodes), function(b) {
        return t.adopt(b);
      });
      return new t.Set(u);
    }, rebuild: function(l) {
      if (typeof l == "boolean" && (this._rebuild = l), this._rebuild) {
        var u = this, b = 0, A = this.dom.leading * new t.Number(this.attr("font-size"));
        this.lines().each(function() {
          this.dom.newLined && (u.textPath() || this.attr("x", u.attr("x")), this.text() == `
` ? b += A : (this.attr("dy", A + b), b = 0));
        }), this.fire("rebuild");
      }
      return this;
    }, build: function(l) {
      return this._build = !!l, this;
    }, setData: function(l) {
      return this.dom = l, this.dom.leading = new t.Number(l.leading || 1.3), this;
    } }, construct: { text: function(l) {
      return this.put(new t.Text()).text(l);
    }, plain: function(l) {
      return this.put(new t.Text()).plain(l);
    } } }), t.Tspan = t.invent({ create: "tspan", inherit: t.Shape, extend: { text: function(l) {
      return l == null ? this.node.textContent + (this.dom.newLined ? `
` : "") : (typeof l == "function" ? l.call(this, this) : this.plain(l), this);
    }, dx: function(l) {
      return this.attr("dx", l);
    }, dy: function(l) {
      return this.attr("dy", l);
    }, newLine: function() {
      var l = this.parent(t.Text);
      return this.dom.newLined = !0, this.dy(l.dom.leading * l.attr("font-size")).attr("x", l.x());
    } } }), t.extend(t.Text, t.Tspan, { plain: function(l) {
      return this._build === !1 && this.clear(), this.node.appendChild(e.createTextNode(l)), this;
    }, tspan: function(l) {
      var u = (this.textPath && this.textPath() || this).node, b = new t.Tspan();
      return this._build === !1 && this.clear(), u.appendChild(b.node), b.text(l);
    }, clear: function() {
      for (var l = (this.textPath && this.textPath() || this).node; l.hasChildNodes(); )
        l.removeChild(l.lastChild);
      return this;
    }, length: function() {
      return this.node.getComputedTextLength();
    } }), t.TextPath = t.invent({ create: "textPath", inherit: t.Parent, parent: t.Text, construct: { morphArray: t.PathArray, array: function() {
      var l = this.track();
      return l ? l.array() : null;
    }, plot: function(l) {
      var u = this.track(), b = null;
      return u && (b = u.plot(l)), l == null ? b : this;
    }, track: function() {
      var l = this.textPath();
      if (l)
        return l.reference("href");
    }, textPath: function() {
      if (this.node.firstChild && this.node.firstChild.nodeName == "textPath")
        return t.adopt(this.node.firstChild);
    } } }), t.Nested = t.invent({ create: function() {
      this.constructor.call(this, t.create("svg")), this.style("overflow", "visible");
    }, inherit: t.Container, construct: { nested: function() {
      return this.put(new t.Nested());
    } } });
    var n = { stroke: ["color", "width", "opacity", "linecap", "linejoin", "miterlimit", "dasharray", "dashoffset"], fill: ["color", "opacity", "rule"], prefix: function(l, u) {
      return u == "color" ? l : l + "-" + u;
    } };
    function o(l, u, b, A) {
      return b + A.replace(t.regex.dots, " .");
    }
    function h(l) {
      return l.toLowerCase().replace(/-(.)/g, function(u, b) {
        return b.toUpperCase();
      });
    }
    function d(l) {
      return l.charAt(0).toUpperCase() + l.slice(1);
    }
    function c(l) {
      var u = l.toString(16);
      return u.length == 1 ? "0" + u : u;
    }
    function g(l, u, b) {
      if (u == null || b == null) {
        var A = l.bbox();
        u == null ? u = A.width / A.height * b : b == null && (b = A.height / A.width * u);
      }
      return { width: u, height: b };
    }
    function p(l, u, b) {
      return { x: u * l.a + b * l.c + 0, y: u * l.b + b * l.d + 0 };
    }
    function x(l) {
      return { a: l[0], b: l[1], c: l[2], d: l[3], e: l[4], f: l[5] };
    }
    function f(l) {
      for (var u = l.childNodes.length - 1; u >= 0; u--)
        l.childNodes[u] instanceof y.SVGElement && f(l.childNodes[u]);
      return t.adopt(l).id(t.eid(l.nodeName));
    }
    function m(l) {
      return Math.abs(l) > 1e-37 ? l : 0;
    }
    ["fill", "stroke"].forEach(function(l) {
      var u = {};
      u[l] = function(b) {
        if (b === void 0)
          return this;
        if (typeof b == "string" || t.Color.isRgb(b) || b && typeof b.fill == "function")
          this.attr(l, b);
        else
          for (var A = n[l].length - 1; A >= 0; A--)
            b[n[l][A]] != null && this.attr(n.prefix(l, n[l][A]), b[n[l][A]]);
        return this;
      }, t.extend(t.Element, t.FX, u);
    }), t.extend(t.Element, t.FX, { translate: function(l, u) {
      return this.transform({ x: l, y: u });
    }, matrix: function(l) {
      return this.attr("transform", new t.Matrix(arguments.length == 6 ? [].slice.call(arguments) : l));
    }, opacity: function(l) {
      return this.attr("opacity", l);
    }, dx: function(l) {
      return this.x(new t.Number(l).plus(this instanceof t.FX ? 0 : this.x()), !0);
    }, dy: function(l) {
      return this.y(new t.Number(l).plus(this instanceof t.FX ? 0 : this.y()), !0);
    } }), t.extend(t.Path, { length: function() {
      return this.node.getTotalLength();
    }, pointAt: function(l) {
      return this.node.getPointAtLength(l);
    } }), t.Set = t.invent({ create: function(l) {
      Array.isArray(l) ? this.members = l : this.clear();
    }, extend: { add: function() {
      for (var l = [].slice.call(arguments), u = 0, b = l.length; u < b; u++)
        this.members.push(l[u]);
      return this;
    }, remove: function(l) {
      var u = this.index(l);
      return u > -1 && this.members.splice(u, 1), this;
    }, each: function(l) {
      for (var u = 0, b = this.members.length; u < b; u++)
        l.apply(this.members[u], [u, this.members]);
      return this;
    }, clear: function() {
      return this.members = [], this;
    }, length: function() {
      return this.members.length;
    }, has: function(l) {
      return this.index(l) >= 0;
    }, index: function(l) {
      return this.members.indexOf(l);
    }, get: function(l) {
      return this.members[l];
    }, first: function() {
      return this.get(0);
    }, last: function() {
      return this.get(this.members.length - 1);
    }, valueOf: function() {
      return this.members;
    } }, construct: { set: function(l) {
      return new t.Set(l);
    } } }), t.FX.Set = t.invent({ create: function(l) {
      this.set = l;
    } }), t.Set.inherit = function() {
      var l = [];
      for (var u in t.Shape.prototype)
        typeof t.Shape.prototype[u] == "function" && typeof t.Set.prototype[u] != "function" && l.push(u);
      for (var u in l.forEach(function(A) {
        t.Set.prototype[A] = function() {
          for (var k = 0, S = this.members.length; k < S; k++)
            this.members[k] && typeof this.members[k][A] == "function" && this.members[k][A].apply(this.members[k], arguments);
          return A == "animate" ? this.fx || (this.fx = new t.FX.Set(this)) : this;
        };
      }), l = [], t.FX.prototype)
        typeof t.FX.prototype[u] == "function" && typeof t.FX.Set.prototype[u] != "function" && l.push(u);
      l.forEach(function(b) {
        t.FX.Set.prototype[b] = function() {
          for (var A = 0, k = this.set.members.length; A < k; A++)
            this.set.members[A].fx[b].apply(this.set.members[A].fx, arguments);
          return this;
        };
      });
    }, t.extend(t.Element, {}), t.extend(t.Element, { remember: function(l, u) {
      if (Q(arguments[0]) === "object")
        for (var b in l)
          this.remember(b, l[b]);
      else {
        if (arguments.length == 1)
          return this.memory()[l];
        this.memory()[l] = u;
      }
      return this;
    }, forget: function() {
      if (arguments.length == 0)
        this._memory = {};
      else
        for (var l = arguments.length - 1; l >= 0; l--)
          delete this.memory()[arguments[l]];
      return this;
    }, memory: function() {
      return this._memory || (this._memory = {});
    } }), t.get = function(l) {
      var u = e.getElementById(function(b) {
        var A = (b || "").toString().match(t.regex.reference);
        if (A)
          return A[1];
      }(l) || l);
      return t.adopt(u);
    }, t.select = function(l, u) {
      return new t.Set(t.utils.map((u || e).querySelectorAll(l), function(b) {
        return t.adopt(b);
      }));
    }, t.extend(t.Parent, { select: function(l) {
      return t.select(l, this.node);
    } });
    var v = "abcdef".split("");
    if (typeof y.CustomEvent != "function") {
      var w = function(l, u) {
        u = u || { bubbles: !1, cancelable: !1, detail: void 0 };
        var b = e.createEvent("CustomEvent");
        return b.initCustomEvent(l, u.bubbles, u.cancelable, u.detail), b;
      };
      w.prototype = y.Event.prototype, t.CustomEvent = w;
    } else
      t.CustomEvent = y.CustomEvent;
    return t;
  }, Q(pt) === "object" ? Ve.exports = de.document ? Ie(de, de.document) : function(y) {
    return Ie(y, y.document);
  } : de.SVG = Ie(de, de.document), /*! svg.filter.js - v2.0.2 - 2016-02-24
  * https://github.com/wout/svg.filter.js
  * Copyright (c) 2016 Wout Fierens; Licensed MIT */
  (function() {
    SVG.Filter = SVG.invent({ create: "filter", inherit: SVG.Parent, extend: { source: "SourceGraphic", sourceAlpha: "SourceAlpha", background: "BackgroundImage", backgroundAlpha: "BackgroundAlpha", fill: "FillPaint", stroke: "StrokePaint", autoSetIn: !0, put: function(s, n) {
      return this.add(s, n), !s.attr("in") && this.autoSetIn && s.attr("in", this.source), s.attr("result") || s.attr("result", s), s;
    }, blend: function(s, n, o) {
      return this.put(new SVG.BlendEffect(s, n, o));
    }, colorMatrix: function(s, n) {
      return this.put(new SVG.ColorMatrixEffect(s, n));
    }, convolveMatrix: function(s) {
      return this.put(new SVG.ConvolveMatrixEffect(s));
    }, componentTransfer: function(s) {
      return this.put(new SVG.ComponentTransferEffect(s));
    }, composite: function(s, n, o) {
      return this.put(new SVG.CompositeEffect(s, n, o));
    }, flood: function(s, n) {
      return this.put(new SVG.FloodEffect(s, n));
    }, offset: function(s, n) {
      return this.put(new SVG.OffsetEffect(s, n));
    }, image: function(s) {
      return this.put(new SVG.ImageEffect(s));
    }, merge: function() {
      var s = [void 0];
      for (var n in arguments)
        s.push(arguments[n]);
      return this.put(new (SVG.MergeEffect.bind.apply(SVG.MergeEffect, s))());
    }, gaussianBlur: function(s, n) {
      return this.put(new SVG.GaussianBlurEffect(s, n));
    }, morphology: function(s, n) {
      return this.put(new SVG.MorphologyEffect(s, n));
    }, diffuseLighting: function(s, n, o) {
      return this.put(new SVG.DiffuseLightingEffect(s, n, o));
    }, displacementMap: function(s, n, o, h, d) {
      return this.put(new SVG.DisplacementMapEffect(s, n, o, h, d));
    }, specularLighting: function(s, n, o, h) {
      return this.put(new SVG.SpecularLightingEffect(s, n, o, h));
    }, tile: function() {
      return this.put(new SVG.TileEffect());
    }, turbulence: function(s, n, o, h, d) {
      return this.put(new SVG.TurbulenceEffect(s, n, o, h, d));
    }, toString: function() {
      return "url(#" + this.attr("id") + ")";
    } } }), SVG.extend(SVG.Defs, { filter: function(s) {
      var n = this.put(new SVG.Filter());
      return typeof s == "function" && s.call(n, n), n;
    } }), SVG.extend(SVG.Container, { filter: function(s) {
      return this.defs().filter(s);
    } }), SVG.extend(SVG.Element, SVG.G, SVG.Nested, { filter: function(s) {
      return this.filterer = s instanceof SVG.Element ? s : this.doc().filter(s), this.doc() && this.filterer.doc() !== this.doc() && this.doc().defs().add(this.filterer), this.attr("filter", this.filterer), this.filterer;
    }, unfilter: function(s) {
      return this.filterer && s === !0 && this.filterer.remove(), delete this.filterer, this.attr("filter", null);
    } }), SVG.Effect = SVG.invent({ create: function() {
      this.constructor.call(this);
    }, inherit: SVG.Element, extend: { in: function(s) {
      return s == null ? this.parent() && this.parent().select('[result="' + this.attr("in") + '"]').get(0) || this.attr("in") : this.attr("in", s);
    }, result: function(s) {
      return s == null ? this.attr("result") : this.attr("result", s);
    }, toString: function() {
      return this.result();
    } } }), SVG.ParentEffect = SVG.invent({ create: function() {
      this.constructor.call(this);
    }, inherit: SVG.Parent, extend: { in: function(s) {
      return s == null ? this.parent() && this.parent().select('[result="' + this.attr("in") + '"]').get(0) || this.attr("in") : this.attr("in", s);
    }, result: function(s) {
      return s == null ? this.attr("result") : this.attr("result", s);
    }, toString: function() {
      return this.result();
    } } });
    var y = { blend: function(s, n) {
      return this.parent() && this.parent().blend(this, s, n);
    }, colorMatrix: function(s, n) {
      return this.parent() && this.parent().colorMatrix(s, n).in(this);
    }, convolveMatrix: function(s) {
      return this.parent() && this.parent().convolveMatrix(s).in(this);
    }, componentTransfer: function(s) {
      return this.parent() && this.parent().componentTransfer(s).in(this);
    }, composite: function(s, n) {
      return this.parent() && this.parent().composite(this, s, n);
    }, flood: function(s, n) {
      return this.parent() && this.parent().flood(s, n);
    }, offset: function(s, n) {
      return this.parent() && this.parent().offset(s, n).in(this);
    }, image: function(s) {
      return this.parent() && this.parent().image(s);
    }, merge: function() {
      return this.parent() && this.parent().merge.apply(this.parent(), [this].concat(arguments));
    }, gaussianBlur: function(s, n) {
      return this.parent() && this.parent().gaussianBlur(s, n).in(this);
    }, morphology: function(s, n) {
      return this.parent() && this.parent().morphology(s, n).in(this);
    }, diffuseLighting: function(s, n, o) {
      return this.parent() && this.parent().diffuseLighting(s, n, o).in(this);
    }, displacementMap: function(s, n, o, h) {
      return this.parent() && this.parent().displacementMap(this, s, n, o, h);
    }, specularLighting: function(s, n, o, h) {
      return this.parent() && this.parent().specularLighting(s, n, o, h).in(this);
    }, tile: function() {
      return this.parent() && this.parent().tile().in(this);
    }, turbulence: function(s, n, o, h, d) {
      return this.parent() && this.parent().turbulence(s, n, o, h, d).in(this);
    } };
    SVG.extend(SVG.Effect, y), SVG.extend(SVG.ParentEffect, y), SVG.ChildEffect = SVG.invent({ create: function() {
      this.constructor.call(this);
    }, inherit: SVG.Element, extend: { in: function(s) {
      this.attr("in", s);
    } } });
    var e = { blend: function(s, n, o) {
      this.attr({ in: s, in2: n, mode: o || "normal" });
    }, colorMatrix: function(s, n) {
      s == "matrix" && (n = a(n)), this.attr({ type: s, values: n === void 0 ? null : n });
    }, convolveMatrix: function(s) {
      s = a(s), this.attr({ order: Math.sqrt(s.split(" ").length), kernelMatrix: s });
    }, composite: function(s, n, o) {
      this.attr({ in: s, in2: n, operator: o });
    }, flood: function(s, n) {
      this.attr("flood-color", s), n != null && this.attr("flood-opacity", n);
    }, offset: function(s, n) {
      this.attr({ dx: s, dy: n });
    }, image: function(s) {
      this.attr("href", s, SVG.xlink);
    }, displacementMap: function(s, n, o, h, d) {
      this.attr({ in: s, in2: n, scale: o, xChannelSelector: h, yChannelSelector: d });
    }, gaussianBlur: function(s, n) {
      s != null || n != null ? this.attr("stdDeviation", function(o) {
        if (!Array.isArray(o))
          return o;
        for (var h = 0, d = o.length, c = []; h < d; h++)
          c.push(o[h]);
        return c.join(" ");
      }(Array.prototype.slice.call(arguments))) : this.attr("stdDeviation", "0 0");
    }, morphology: function(s, n) {
      this.attr({ operator: s, radius: n });
    }, tile: function() {
    }, turbulence: function(s, n, o, h, d) {
      this.attr({ numOctaves: n, seed: o, stitchTiles: h, baseFrequency: s, type: d });
    } }, t = { merge: function() {
      var s;
      if (arguments[0] instanceof SVG.Set) {
        var n = this;
        arguments[0].each(function(h) {
          this instanceof SVG.MergeNode ? n.put(this) : (this instanceof SVG.Effect || this instanceof SVG.ParentEffect) && n.put(new SVG.MergeNode(this));
        });
      } else {
        s = Array.isArray(arguments[0]) ? arguments[0] : arguments;
        for (var o = 0; o < s.length; o++)
          s[o] instanceof SVG.MergeNode ? this.put(s[o]) : this.put(new SVG.MergeNode(s[o]));
      }
    }, componentTransfer: function(s) {
      if (this.rgb = new SVG.Set(), ["r", "g", "b", "a"].forEach((function(o) {
        this[o] = new SVG["Func" + o.toUpperCase()]("identity"), this.rgb.add(this[o]), this.node.appendChild(this[o].node);
      }).bind(this)), s)
        for (var n in s.rgb && (["r", "g", "b"].forEach((function(o) {
          this[o].attr(s.rgb);
        }).bind(this)), delete s.rgb), s)
          this[n].attr(s[n]);
    }, diffuseLighting: function(s, n, o) {
      this.attr({ surfaceScale: s, diffuseConstant: n, kernelUnitLength: o });
    }, specularLighting: function(s, n, o, h) {
      this.attr({ surfaceScale: s, diffuseConstant: n, specularExponent: o, kernelUnitLength: h });
    } }, i = { distantLight: function(s, n) {
      this.attr({ azimuth: s, elevation: n });
    }, pointLight: function(s, n, o) {
      this.attr({ x: s, y: n, z: o });
    }, spotLight: function(s, n, o, h, d, c) {
      this.attr({ x: s, y: n, z: o, pointsAtX: h, pointsAtY: d, pointsAtZ: c });
    }, mergeNode: function(s) {
      this.attr("in", s);
    } };
    function a(s) {
      return Array.isArray(s) && (s = new SVG.Array(s)), s.toString().replace(/^\s+/, "").replace(/\s+$/, "").replace(/\s+/g, " ");
    }
    function r() {
      var s = function() {
      };
      for (var n in typeof arguments[arguments.length - 1] == "function" && (s = arguments[arguments.length - 1], Array.prototype.splice.call(arguments, arguments.length - 1, 1)), arguments)
        for (var o in arguments[n])
          s(arguments[n][o], o, arguments[n]);
    }
    ["r", "g", "b", "a"].forEach(function(s) {
      i["Func" + s.toUpperCase()] = function(n) {
        switch (this.attr("type", n), n) {
          case "table":
            this.attr("tableValues", arguments[1]);
            break;
          case "linear":
            this.attr("slope", arguments[1]), this.attr("intercept", arguments[2]);
            break;
          case "gamma":
            this.attr("amplitude", arguments[1]), this.attr("exponent", arguments[2]), this.attr("offset", arguments[2]);
        }
      };
    }), r(e, function(s, n) {
      var o = n.charAt(0).toUpperCase() + n.slice(1);
      SVG[o + "Effect"] = SVG.invent({ create: function() {
        this.constructor.call(this, SVG.create("fe" + o)), s.apply(this, arguments), this.result(this.attr("id") + "Out");
      }, inherit: SVG.Effect, extend: {} });
    }), r(t, function(s, n) {
      var o = n.charAt(0).toUpperCase() + n.slice(1);
      SVG[o + "Effect"] = SVG.invent({ create: function() {
        this.constructor.call(this, SVG.create("fe" + o)), s.apply(this, arguments), this.result(this.attr("id") + "Out");
      }, inherit: SVG.ParentEffect, extend: {} });
    }), r(i, function(s, n) {
      var o = n.charAt(0).toUpperCase() + n.slice(1);
      SVG[o] = SVG.invent({ create: function() {
        this.constructor.call(this, SVG.create("fe" + o)), s.apply(this, arguments);
      }, inherit: SVG.ChildEffect, extend: {} });
    }), SVG.extend(SVG.MergeEffect, { in: function(s) {
      return s instanceof SVG.MergeNode ? this.add(s, 0) : this.add(new SVG.MergeNode(s), 0), this;
    } }), SVG.extend(SVG.CompositeEffect, SVG.BlendEffect, SVG.DisplacementMapEffect, { in2: function(s) {
      return s == null ? this.parent() && this.parent().select('[result="' + this.attr("in2") + '"]').get(0) || this.attr("in2") : this.attr("in2", s);
    } }), SVG.filter = { sepiatone: [0.343, 0.669, 0.119, 0, 0, 0.249, 0.626, 0.13, 0, 0, 0.172, 0.334, 0.111, 0, 0, 0, 0, 0, 1, 0] };
  }).call(void 0), function() {
    function y(r, s, n, o, h, d, c) {
      for (var g = r.slice(s, n || c), p = o.slice(h, d || c), x = 0, f = { pos: [0, 0], start: [0, 0] }, m = { pos: [0, 0], start: [0, 0] }; g[x] = e.call(f, g[x]), p[x] = e.call(m, p[x]), g[x][0] != p[x][0] || g[x][0] == "M" || g[x][0] == "A" && (g[x][4] != p[x][4] || g[x][5] != p[x][5]) ? (Array.prototype.splice.apply(g, [x, 1].concat(i.call(f, g[x]))), Array.prototype.splice.apply(p, [x, 1].concat(i.call(m, p[x])))) : (g[x] = t.call(f, g[x]), p[x] = t.call(m, p[x])), !(++x == g.length && x == p.length); )
        x == g.length && g.push(["C", f.pos[0], f.pos[1], f.pos[0], f.pos[1], f.pos[0], f.pos[1]]), x == p.length && p.push(["C", m.pos[0], m.pos[1], m.pos[0], m.pos[1], m.pos[0], m.pos[1]]);
      return { start: g, dest: p };
    }
    function e(r) {
      switch (r[0]) {
        case "z":
        case "Z":
          r[0] = "L", r[1] = this.start[0], r[2] = this.start[1];
          break;
        case "H":
          r[0] = "L", r[2] = this.pos[1];
          break;
        case "V":
          r[0] = "L", r[2] = r[1], r[1] = this.pos[0];
          break;
        case "T":
          r[0] = "Q", r[3] = r[1], r[4] = r[2], r[1] = this.reflection[1], r[2] = this.reflection[0];
          break;
        case "S":
          r[0] = "C", r[6] = r[4], r[5] = r[3], r[4] = r[2], r[3] = r[1], r[2] = this.reflection[1], r[1] = this.reflection[0];
      }
      return r;
    }
    function t(r) {
      var s = r.length;
      return this.pos = [r[s - 2], r[s - 1]], "SCQT".indexOf(r[0]) != -1 && (this.reflection = [2 * this.pos[0] - r[s - 4], 2 * this.pos[1] - r[s - 3]]), r;
    }
    function i(r) {
      var s = [r];
      switch (r[0]) {
        case "M":
          return this.pos = this.start = [r[1], r[2]], s;
        case "L":
          r[5] = r[3] = r[1], r[6] = r[4] = r[2], r[1] = this.pos[0], r[2] = this.pos[1];
          break;
        case "Q":
          r[6] = r[4], r[5] = r[3], r[4] = 1 * r[4] / 3 + 2 * r[2] / 3, r[3] = 1 * r[3] / 3 + 2 * r[1] / 3, r[2] = 1 * this.pos[1] / 3 + 2 * r[2] / 3, r[1] = 1 * this.pos[0] / 3 + 2 * r[1] / 3;
          break;
        case "A":
          s = function(n, o) {
            var h, d, c, g, p, x, f, m, v, w, l, u, b, A, k, S, C, L, M, T, I, z, Y, D, H, O, B = Math.abs(o[1]), N = Math.abs(o[2]), W = o[3] % 360, q = o[4], Z = o[5], U = o[6], se = o[7], V = new SVG.Point(n), G = new SVG.Point(U, se), _ = [];
            if (B === 0 || N === 0 || V.x === G.x && V.y === G.y)
              return [["C", V.x, V.y, G.x, G.y, G.x, G.y]];
            for (h = new SVG.Point((V.x - G.x) / 2, (V.y - G.y) / 2).transform(new SVG.Matrix().rotate(W)), (d = h.x * h.x / (B * B) + h.y * h.y / (N * N)) > 1 && (B *= d = Math.sqrt(d), N *= d), c = new SVG.Matrix().rotate(W).scale(1 / B, 1 / N).rotate(-W), V = V.transform(c), G = G.transform(c), g = [G.x - V.x, G.y - V.y], x = g[0] * g[0] + g[1] * g[1], p = Math.sqrt(x), g[0] /= p, g[1] /= p, f = x < 4 ? Math.sqrt(1 - x / 4) : 0, q === Z && (f *= -1), m = new SVG.Point((G.x + V.x) / 2 + f * -g[1], (G.y + V.y) / 2 + f * g[0]), v = new SVG.Point(V.x - m.x, V.y - m.y), w = new SVG.Point(G.x - m.x, G.y - m.y), l = Math.acos(v.x / Math.sqrt(v.x * v.x + v.y * v.y)), v.y < 0 && (l *= -1), u = Math.acos(w.x / Math.sqrt(w.x * w.x + w.y * w.y)), w.y < 0 && (u *= -1), Z && l > u && (u += 2 * Math.PI), !Z && l < u && (u -= 2 * Math.PI), A = Math.ceil(2 * Math.abs(l - u) / Math.PI), S = [], C = l, b = (u - l) / A, k = 4 * Math.tan(b / 4) / 3, I = 0; I <= A; I++)
              M = Math.cos(C), L = Math.sin(C), T = new SVG.Point(m.x + M, m.y + L), S[I] = [new SVG.Point(T.x + k * L, T.y - k * M), T, new SVG.Point(T.x - k * L, T.y + k * M)], C += b;
            for (S[0][0] = S[0][1].clone(), S[S.length - 1][2] = S[S.length - 1][1].clone(), c = new SVG.Matrix().rotate(W).scale(B, N).rotate(-W), I = 0, z = S.length; I < z; I++)
              S[I][0] = S[I][0].transform(c), S[I][1] = S[I][1].transform(c), S[I][2] = S[I][2].transform(c);
            for (I = 1, z = S.length; I < z; I++)
              Y = (T = S[I - 1][2]).x, D = T.y, H = (T = S[I][0]).x, O = T.y, U = (T = S[I][1]).x, se = T.y, _.push(["C", Y, D, H, O, U, se]);
            return _;
          }(this.pos, r), r = s[0];
      }
      return r[0] = "C", this.pos = [r[5], r[6]], this.reflection = [2 * r[5] - r[3], 2 * r[6] - r[4]], s;
    }
    function a(r, s) {
      if (s === !1)
        return !1;
      for (var n = s, o = r.length; n < o; ++n)
        if (r[n][0] == "M")
          return n;
      return !1;
    }
    SVG.extend(SVG.PathArray, { morph: function(r) {
      for (var s = this.value, n = this.parse(r), o = 0, h = 0, d = !1, c = !1; o !== !1 || h !== !1; ) {
        var g;
        d = a(s, o !== !1 && o + 1), c = a(n, h !== !1 && h + 1), o === !1 && (o = (g = new SVG.PathArray(p.start).bbox()).height == 0 || g.width == 0 ? s.push(s[0]) - 1 : s.push(["M", g.x + g.width / 2, g.y + g.height / 2]) - 1), h === !1 && (h = (g = new SVG.PathArray(p.dest).bbox()).height == 0 || g.width == 0 ? n.push(n[0]) - 1 : n.push(["M", g.x + g.width / 2, g.y + g.height / 2]) - 1);
        var p = y(s, o, d, n, h, c);
        s = s.slice(0, o).concat(p.start, d === !1 ? [] : s.slice(d)), n = n.slice(0, h).concat(p.dest, c === !1 ? [] : n.slice(c)), o = d !== !1 && o + p.start.length, h = c !== !1 && h + p.dest.length;
      }
      return this.value = s, this.destination = new SVG.PathArray(), this.destination.value = n, this;
    } });
  }(), /*! svg.draggable.js - v2.2.2 - 2019-01-08
  * https://github.com/svgdotjs/svg.draggable.js
  * Copyright (c) 2019 Wout Fierens; Licensed MIT */
  (function() {
    function y(e) {
      e.remember("_draggable", this), this.el = e;
    }
    y.prototype.init = function(e, t) {
      var i = this;
      this.constraint = e, this.value = t, this.el.on("mousedown.drag", function(a) {
        i.start(a);
      }), this.el.on("touchstart.drag", function(a) {
        i.start(a);
      });
    }, y.prototype.transformPoint = function(e, t) {
      var i = (e = e || window.event).changedTouches && e.changedTouches[0] || e;
      return this.p.x = i.clientX - (t || 0), this.p.y = i.clientY, this.p.matrixTransform(this.m);
    }, y.prototype.getBBox = function() {
      var e = this.el.bbox();
      return this.el instanceof SVG.Nested && (e = this.el.rbox()), (this.el instanceof SVG.G || this.el instanceof SVG.Use || this.el instanceof SVG.Nested) && (e.x = this.el.x(), e.y = this.el.y()), e;
    }, y.prototype.start = function(e) {
      if (e.type != "click" && e.type != "mousedown" && e.type != "mousemove" || (e.which || e.buttons) == 1) {
        var t = this;
        if (this.el.fire("beforedrag", { event: e, handler: this }), !this.el.event().defaultPrevented) {
          e.preventDefault(), e.stopPropagation(), this.parent = this.parent || this.el.parent(SVG.Nested) || this.el.parent(SVG.Doc), this.p = this.parent.node.createSVGPoint(), this.m = this.el.node.getScreenCTM().inverse();
          var i, a = this.getBBox();
          if (this.el instanceof SVG.Text)
            switch (i = this.el.node.getComputedTextLength(), this.el.attr("text-anchor")) {
              case "middle":
                i /= 2;
                break;
              case "start":
                i = 0;
            }
          this.startPoints = { point: this.transformPoint(e, i), box: a, transform: this.el.transform() }, SVG.on(window, "mousemove.drag", function(r) {
            t.drag(r);
          }), SVG.on(window, "touchmove.drag", function(r) {
            t.drag(r);
          }), SVG.on(window, "mouseup.drag", function(r) {
            t.end(r);
          }), SVG.on(window, "touchend.drag", function(r) {
            t.end(r);
          }), this.el.fire("dragstart", { event: e, p: this.startPoints.point, m: this.m, handler: this });
        }
      }
    }, y.prototype.drag = function(e) {
      var t = this.getBBox(), i = this.transformPoint(e), a = this.startPoints.box.x + i.x - this.startPoints.point.x, r = this.startPoints.box.y + i.y - this.startPoints.point.y, s = this.constraint, n = i.x - this.startPoints.point.x, o = i.y - this.startPoints.point.y;
      if (this.el.fire("dragmove", { event: e, p: i, m: this.m, handler: this }), this.el.event().defaultPrevented)
        return i;
      if (typeof s == "function") {
        var h = s.call(this.el, a, r, this.m);
        typeof h == "boolean" && (h = { x: h, y: h }), h.x === !0 ? this.el.x(a) : h.x !== !1 && this.el.x(h.x), h.y === !0 ? this.el.y(r) : h.y !== !1 && this.el.y(h.y);
      } else
        typeof s == "object" && (s.minX != null && a < s.minX ? n = (a = s.minX) - this.startPoints.box.x : s.maxX != null && a > s.maxX - t.width && (n = (a = s.maxX - t.width) - this.startPoints.box.x), s.minY != null && r < s.minY ? o = (r = s.minY) - this.startPoints.box.y : s.maxY != null && r > s.maxY - t.height && (o = (r = s.maxY - t.height) - this.startPoints.box.y), s.snapToGrid != null && (a -= a % s.snapToGrid, r -= r % s.snapToGrid, n -= n % s.snapToGrid, o -= o % s.snapToGrid), this.el instanceof SVG.G ? this.el.matrix(this.startPoints.transform).transform({ x: n, y: o }, !0) : this.el.move(a, r));
      return i;
    }, y.prototype.end = function(e) {
      var t = this.drag(e);
      this.el.fire("dragend", { event: e, p: t, m: this.m, handler: this }), SVG.off(window, "mousemove.drag"), SVG.off(window, "touchmove.drag"), SVG.off(window, "mouseup.drag"), SVG.off(window, "touchend.drag");
    }, SVG.extend(SVG.Element, { draggable: function(e, t) {
      typeof e != "function" && typeof e != "object" || (t = e, e = !0);
      var i = this.remember("_draggable") || new y(this);
      return (e = e === void 0 || e) ? i.init(t || {}, e) : (this.off("mousedown.drag"), this.off("touchstart.drag")), this;
    } });
  }).call(void 0), function() {
    function y(e) {
      this.el = e, e.remember("_selectHandler", this), this.pointSelection = { isSelected: !1 }, this.rectSelection = { isSelected: !1 }, this.pointsList = { lt: [0, 0], rt: ["width", 0], rb: ["width", "height"], lb: [0, "height"], t: ["width", 0], r: ["width", "height"], b: ["width", "height"], l: [0, "height"] }, this.pointCoord = function(t, i, a) {
        var r = typeof t != "string" ? t : i[t];
        return a ? r / 2 : r;
      }, this.pointCoords = function(t, i) {
        var a = this.pointsList[t];
        return { x: this.pointCoord(a[0], i, t === "t" || t === "b"), y: this.pointCoord(a[1], i, t === "r" || t === "l") };
      };
    }
    y.prototype.init = function(e, t) {
      var i = this.el.bbox();
      this.options = {};
      var a = this.el.selectize.defaults.points;
      for (var r in this.el.selectize.defaults)
        this.options[r] = this.el.selectize.defaults[r], t[r] !== void 0 && (this.options[r] = t[r]);
      var s = ["points", "pointsExclude"];
      for (var r in s) {
        var n = this.options[s[r]];
        typeof n == "string" ? n = n.length > 0 ? n.split(/\s*,\s*/i) : [] : typeof n == "boolean" && s[r] === "points" && (n = n ? a : []), this.options[s[r]] = n;
      }
      this.options.points = [a, this.options.points].reduce(function(o, h) {
        return o.filter(function(d) {
          return h.indexOf(d) > -1;
        });
      }), this.options.points = [this.options.points, this.options.pointsExclude].reduce(function(o, h) {
        return o.filter(function(d) {
          return h.indexOf(d) < 0;
        });
      }), this.parent = this.el.parent(), this.nested = this.nested || this.parent.group(), this.nested.matrix(new SVG.Matrix(this.el).translate(i.x, i.y)), this.options.deepSelect && ["line", "polyline", "polygon"].indexOf(this.el.type) !== -1 ? this.selectPoints(e) : this.selectRect(e), this.observe(), this.cleanup();
    }, y.prototype.selectPoints = function(e) {
      return this.pointSelection.isSelected = e, this.pointSelection.set || (this.pointSelection.set = this.parent.set(), this.drawPoints()), this;
    }, y.prototype.getPointArray = function() {
      var e = this.el.bbox();
      return this.el.array().valueOf().map(function(t) {
        return [t[0] - e.x, t[1] - e.y];
      });
    }, y.prototype.drawPoints = function() {
      for (var e = this, t = this.getPointArray(), i = 0, a = t.length; i < a; ++i) {
        var r = function(n) {
          return function(o) {
            (o = o || window.event).preventDefault ? o.preventDefault() : o.returnValue = !1, o.stopPropagation();
            var h = o.pageX || o.touches[0].pageX, d = o.pageY || o.touches[0].pageY;
            e.el.fire("point", { x: h, y: d, i: n, event: o });
          };
        }(i), s = this.drawPoint(t[i][0], t[i][1]).addClass(this.options.classPoints).addClass(this.options.classPoints + "_point").on("touchstart", r).on("mousedown", r);
        this.pointSelection.set.add(s);
      }
    }, y.prototype.drawPoint = function(e, t) {
      var i = this.options.pointType;
      switch (i) {
        case "circle":
          return this.drawCircle(e, t);
        case "rect":
          return this.drawRect(e, t);
        default:
          if (typeof i == "function")
            return i.call(this, e, t);
          throw new Error("Unknown " + i + " point type!");
      }
    }, y.prototype.drawCircle = function(e, t) {
      return this.nested.circle(this.options.pointSize).center(e, t);
    }, y.prototype.drawRect = function(e, t) {
      return this.nested.rect(this.options.pointSize, this.options.pointSize).center(e, t);
    }, y.prototype.updatePointSelection = function() {
      var e = this.getPointArray();
      this.pointSelection.set.each(function(t) {
        this.cx() === e[t][0] && this.cy() === e[t][1] || this.center(e[t][0], e[t][1]);
      });
    }, y.prototype.updateRectSelection = function() {
      var e = this, t = this.el.bbox();
      if (this.rectSelection.set.get(0).attr({ width: t.width, height: t.height }), this.options.points.length && this.options.points.map(function(a, r) {
        var s = e.pointCoords(a, t);
        e.rectSelection.set.get(r + 1).center(s.x, s.y);
      }), this.options.rotationPoint) {
        var i = this.rectSelection.set.length();
        this.rectSelection.set.get(i - 1).center(t.width / 2, 20);
      }
    }, y.prototype.selectRect = function(e) {
      var t = this, i = this.el.bbox();
      function a(n) {
        return function(o) {
          (o = o || window.event).preventDefault ? o.preventDefault() : o.returnValue = !1, o.stopPropagation();
          var h = o.pageX || o.touches[0].pageX, d = o.pageY || o.touches[0].pageY;
          t.el.fire(n, { x: h, y: d, event: o });
        };
      }
      if (this.rectSelection.isSelected = e, this.rectSelection.set = this.rectSelection.set || this.parent.set(), this.rectSelection.set.get(0) || this.rectSelection.set.add(this.nested.rect(i.width, i.height).addClass(this.options.classRect)), this.options.points.length && this.rectSelection.set.length() < 2 && (this.options.points.map(function(n, o) {
        var h = t.pointCoords(n, i), d = t.drawPoint(h.x, h.y).attr("class", t.options.classPoints + "_" + n).on("mousedown", a(n)).on("touchstart", a(n));
        t.rectSelection.set.add(d);
      }), this.rectSelection.set.each(function() {
        this.addClass(t.options.classPoints);
      })), this.options.rotationPoint && (this.options.points && !this.rectSelection.set.get(9) || !this.options.points && !this.rectSelection.set.get(1))) {
        var r = function(n) {
          (n = n || window.event).preventDefault ? n.preventDefault() : n.returnValue = !1, n.stopPropagation();
          var o = n.pageX || n.touches[0].pageX, h = n.pageY || n.touches[0].pageY;
          t.el.fire("rot", { x: o, y: h, event: n });
        }, s = this.drawPoint(i.width / 2, 20).attr("class", this.options.classPoints + "_rot").on("touchstart", r).on("mousedown", r);
        this.rectSelection.set.add(s);
      }
    }, y.prototype.handler = function() {
      var e = this.el.bbox();
      this.nested.matrix(new SVG.Matrix(this.el).translate(e.x, e.y)), this.rectSelection.isSelected && this.updateRectSelection(), this.pointSelection.isSelected && this.updatePointSelection();
    }, y.prototype.observe = function() {
      var e = this;
      if (MutationObserver)
        if (this.rectSelection.isSelected || this.pointSelection.isSelected)
          this.observerInst = this.observerInst || new MutationObserver(function() {
            e.handler();
          }), this.observerInst.observe(this.el.node, { attributes: !0 });
        else
          try {
            this.observerInst.disconnect(), delete this.observerInst;
          } catch {
          }
      else
        this.el.off("DOMAttrModified.select"), (this.rectSelection.isSelected || this.pointSelection.isSelected) && this.el.on("DOMAttrModified.select", function() {
          e.handler();
        });
    }, y.prototype.cleanup = function() {
      !this.rectSelection.isSelected && this.rectSelection.set && (this.rectSelection.set.each(function() {
        this.remove();
      }), this.rectSelection.set.clear(), delete this.rectSelection.set), !this.pointSelection.isSelected && this.pointSelection.set && (this.pointSelection.set.each(function() {
        this.remove();
      }), this.pointSelection.set.clear(), delete this.pointSelection.set), this.pointSelection.isSelected || this.rectSelection.isSelected || (this.nested.remove(), delete this.nested);
    }, SVG.extend(SVG.Element, { selectize: function(e, t) {
      return typeof e == "object" && (t = e, e = !0), (this.remember("_selectHandler") || new y(this)).init(e === void 0 || e, t || {}), this;
    } }), SVG.Element.prototype.selectize.defaults = { points: ["lt", "rt", "rb", "lb", "t", "r", "b", "l"], pointsExclude: [], classRect: "svg_select_boundingRect", classPoints: "svg_select_points", pointSize: 7, rotationPoint: !0, deepSelect: !1, pointType: "circle" };
  }(), function() {
    (function() {
      function y(e) {
        e.remember("_resizeHandler", this), this.el = e, this.parameters = {}, this.lastUpdateCall = null, this.p = e.doc().node.createSVGPoint();
      }
      y.prototype.transformPoint = function(e, t, i) {
        return this.p.x = e - (this.offset.x - window.pageXOffset), this.p.y = t - (this.offset.y - window.pageYOffset), this.p.matrixTransform(i || this.m);
      }, y.prototype._extractPosition = function(e) {
        return { x: e.clientX != null ? e.clientX : e.touches[0].clientX, y: e.clientY != null ? e.clientY : e.touches[0].clientY };
      }, y.prototype.init = function(e) {
        var t = this;
        if (this.stop(), e !== "stop") {
          for (var i in this.options = {}, this.el.resize.defaults)
            this.options[i] = this.el.resize.defaults[i], e[i] !== void 0 && (this.options[i] = e[i]);
          this.el.on("lt.resize", function(a) {
            t.resize(a || window.event);
          }), this.el.on("rt.resize", function(a) {
            t.resize(a || window.event);
          }), this.el.on("rb.resize", function(a) {
            t.resize(a || window.event);
          }), this.el.on("lb.resize", function(a) {
            t.resize(a || window.event);
          }), this.el.on("t.resize", function(a) {
            t.resize(a || window.event);
          }), this.el.on("r.resize", function(a) {
            t.resize(a || window.event);
          }), this.el.on("b.resize", function(a) {
            t.resize(a || window.event);
          }), this.el.on("l.resize", function(a) {
            t.resize(a || window.event);
          }), this.el.on("rot.resize", function(a) {
            t.resize(a || window.event);
          }), this.el.on("point.resize", function(a) {
            t.resize(a || window.event);
          }), this.update();
        }
      }, y.prototype.stop = function() {
        return this.el.off("lt.resize"), this.el.off("rt.resize"), this.el.off("rb.resize"), this.el.off("lb.resize"), this.el.off("t.resize"), this.el.off("r.resize"), this.el.off("b.resize"), this.el.off("l.resize"), this.el.off("rot.resize"), this.el.off("point.resize"), this;
      }, y.prototype.resize = function(e) {
        var t = this;
        this.m = this.el.node.getScreenCTM().inverse(), this.offset = { x: window.pageXOffset, y: window.pageYOffset };
        var i = this._extractPosition(e.detail.event);
        if (this.parameters = { type: this.el.type, p: this.transformPoint(i.x, i.y), x: e.detail.x, y: e.detail.y, box: this.el.bbox(), rotation: this.el.transform().rotation }, this.el.type === "text" && (this.parameters.fontSize = this.el.attr()["font-size"]), e.detail.i !== void 0) {
          var a = this.el.array().valueOf();
          this.parameters.i = e.detail.i, this.parameters.pointCoords = [a[e.detail.i][0], a[e.detail.i][1]];
        }
        switch (e.type) {
          case "lt":
            this.calc = function(r, s) {
              var n = this.snapToGrid(r, s);
              if (this.parameters.box.width - n[0] > 0 && this.parameters.box.height - n[1] > 0) {
                if (this.parameters.type === "text")
                  return this.el.move(this.parameters.box.x + n[0], this.parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize - n[0]);
                n = this.checkAspectRatio(n), this.el.move(this.parameters.box.x + n[0], this.parameters.box.y + n[1]).size(this.parameters.box.width - n[0], this.parameters.box.height - n[1]);
              }
            };
            break;
          case "rt":
            this.calc = function(r, s) {
              var n = this.snapToGrid(r, s, 2);
              if (this.parameters.box.width + n[0] > 0 && this.parameters.box.height - n[1] > 0) {
                if (this.parameters.type === "text")
                  return this.el.move(this.parameters.box.x - n[0], this.parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize + n[0]);
                n = this.checkAspectRatio(n, !0), this.el.move(this.parameters.box.x, this.parameters.box.y + n[1]).size(this.parameters.box.width + n[0], this.parameters.box.height - n[1]);
              }
            };
            break;
          case "rb":
            this.calc = function(r, s) {
              var n = this.snapToGrid(r, s, 0);
              if (this.parameters.box.width + n[0] > 0 && this.parameters.box.height + n[1] > 0) {
                if (this.parameters.type === "text")
                  return this.el.move(this.parameters.box.x - n[0], this.parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize + n[0]);
                n = this.checkAspectRatio(n), this.el.move(this.parameters.box.x, this.parameters.box.y).size(this.parameters.box.width + n[0], this.parameters.box.height + n[1]);
              }
            };
            break;
          case "lb":
            this.calc = function(r, s) {
              var n = this.snapToGrid(r, s, 1);
              if (this.parameters.box.width - n[0] > 0 && this.parameters.box.height + n[1] > 0) {
                if (this.parameters.type === "text")
                  return this.el.move(this.parameters.box.x + n[0], this.parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize - n[0]);
                n = this.checkAspectRatio(n, !0), this.el.move(this.parameters.box.x + n[0], this.parameters.box.y).size(this.parameters.box.width - n[0], this.parameters.box.height + n[1]);
              }
            };
            break;
          case "t":
            this.calc = function(r, s) {
              var n = this.snapToGrid(r, s, 2);
              if (this.parameters.box.height - n[1] > 0) {
                if (this.parameters.type === "text")
                  return;
                this.el.move(this.parameters.box.x, this.parameters.box.y + n[1]).height(this.parameters.box.height - n[1]);
              }
            };
            break;
          case "r":
            this.calc = function(r, s) {
              var n = this.snapToGrid(r, s, 0);
              if (this.parameters.box.width + n[0] > 0) {
                if (this.parameters.type === "text")
                  return;
                this.el.move(this.parameters.box.x, this.parameters.box.y).width(this.parameters.box.width + n[0]);
              }
            };
            break;
          case "b":
            this.calc = function(r, s) {
              var n = this.snapToGrid(r, s, 0);
              if (this.parameters.box.height + n[1] > 0) {
                if (this.parameters.type === "text")
                  return;
                this.el.move(this.parameters.box.x, this.parameters.box.y).height(this.parameters.box.height + n[1]);
              }
            };
            break;
          case "l":
            this.calc = function(r, s) {
              var n = this.snapToGrid(r, s, 1);
              if (this.parameters.box.width - n[0] > 0) {
                if (this.parameters.type === "text")
                  return;
                this.el.move(this.parameters.box.x + n[0], this.parameters.box.y).width(this.parameters.box.width - n[0]);
              }
            };
            break;
          case "rot":
            this.calc = function(r, s) {
              var n = r + this.parameters.p.x, o = s + this.parameters.p.y, h = Math.atan2(this.parameters.p.y - this.parameters.box.y - this.parameters.box.height / 2, this.parameters.p.x - this.parameters.box.x - this.parameters.box.width / 2), d = Math.atan2(o - this.parameters.box.y - this.parameters.box.height / 2, n - this.parameters.box.x - this.parameters.box.width / 2), c = this.parameters.rotation + 180 * (d - h) / Math.PI + this.options.snapToAngle / 2;
              this.el.center(this.parameters.box.cx, this.parameters.box.cy).rotate(c - c % this.options.snapToAngle, this.parameters.box.cx, this.parameters.box.cy);
            };
            break;
          case "point":
            this.calc = function(r, s) {
              var n = this.snapToGrid(r, s, this.parameters.pointCoords[0], this.parameters.pointCoords[1]), o = this.el.array().valueOf();
              o[this.parameters.i][0] = this.parameters.pointCoords[0] + n[0], o[this.parameters.i][1] = this.parameters.pointCoords[1] + n[1], this.el.plot(o);
            };
        }
        this.el.fire("resizestart", { dx: this.parameters.x, dy: this.parameters.y, event: e }), SVG.on(window, "touchmove.resize", function(r) {
          t.update(r || window.event);
        }), SVG.on(window, "touchend.resize", function() {
          t.done();
        }), SVG.on(window, "mousemove.resize", function(r) {
          t.update(r || window.event);
        }), SVG.on(window, "mouseup.resize", function() {
          t.done();
        });
      }, y.prototype.update = function(e) {
        if (e) {
          var t = this._extractPosition(e), i = this.transformPoint(t.x, t.y), a = i.x - this.parameters.p.x, r = i.y - this.parameters.p.y;
          this.lastUpdateCall = [a, r], this.calc(a, r), this.el.fire("resizing", { dx: a, dy: r, event: e });
        } else
          this.lastUpdateCall && this.calc(this.lastUpdateCall[0], this.lastUpdateCall[1]);
      }, y.prototype.done = function() {
        this.lastUpdateCall = null, SVG.off(window, "mousemove.resize"), SVG.off(window, "mouseup.resize"), SVG.off(window, "touchmove.resize"), SVG.off(window, "touchend.resize"), this.el.fire("resizedone");
      }, y.prototype.snapToGrid = function(e, t, i, a) {
        var r;
        return a !== void 0 ? r = [(i + e) % this.options.snapToGrid, (a + t) % this.options.snapToGrid] : (i = i ?? 3, r = [(this.parameters.box.x + e + (1 & i ? 0 : this.parameters.box.width)) % this.options.snapToGrid, (this.parameters.box.y + t + (2 & i ? 0 : this.parameters.box.height)) % this.options.snapToGrid]), e < 0 && (r[0] -= this.options.snapToGrid), t < 0 && (r[1] -= this.options.snapToGrid), e -= Math.abs(r[0]) < this.options.snapToGrid / 2 ? r[0] : r[0] - (e < 0 ? -this.options.snapToGrid : this.options.snapToGrid), t -= Math.abs(r[1]) < this.options.snapToGrid / 2 ? r[1] : r[1] - (t < 0 ? -this.options.snapToGrid : this.options.snapToGrid), this.constraintToBox(e, t, i, a);
      }, y.prototype.constraintToBox = function(e, t, i, a) {
        var r, s, n = this.options.constraint || {};
        return a !== void 0 ? (r = i, s = a) : (r = this.parameters.box.x + (1 & i ? 0 : this.parameters.box.width), s = this.parameters.box.y + (2 & i ? 0 : this.parameters.box.height)), n.minX !== void 0 && r + e < n.minX && (e = n.minX - r), n.maxX !== void 0 && r + e > n.maxX && (e = n.maxX - r), n.minY !== void 0 && s + t < n.minY && (t = n.minY - s), n.maxY !== void 0 && s + t > n.maxY && (t = n.maxY - s), [e, t];
      }, y.prototype.checkAspectRatio = function(e, t) {
        if (!this.options.saveAspectRatio)
          return e;
        var i = e.slice(), a = this.parameters.box.width / this.parameters.box.height, r = this.parameters.box.width + e[0], s = this.parameters.box.height - e[1], n = r / s;
        return n < a ? (i[1] = r / a - this.parameters.box.height, t && (i[1] = -i[1])) : n > a && (i[0] = this.parameters.box.width - s * a, t && (i[0] = -i[0])), i;
      }, SVG.extend(SVG.Element, { resize: function(e) {
        return (this.remember("_resizeHandler") || new y(this)).init(e || {}), this;
      } }), SVG.Element.prototype.resize.defaults = { snapToAngle: 0.1, snapToGrid: 1, constraint: {}, saveAspectRatio: !1 };
    }).call(this);
  }(), window.Apex === void 0 && (window.Apex = {});
  var gt = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "initModules", value: function() {
      this.ctx.publicMethods = ["updateOptions", "updateSeries", "appendData", "appendSeries", "isSeriesHidden", "highlightSeries", "toggleSeries", "showSeries", "hideSeries", "setLocale", "resetSeries", "zoomX", "toggleDataPointSelection", "dataURI", "exportToCSV", "addXaxisAnnotation", "addYaxisAnnotation", "addPointAnnotation", "clearAnnotations", "removeAnnotation", "paper", "destroy"], this.ctx.eventList = ["click", "mousedown", "mousemove", "mouseleave", "touchstart", "touchmove", "touchleave", "mouseup", "touchend"], this.ctx.animations = new ge(this.ctx), this.ctx.axes = new kt(this.ctx), this.ctx.core = new Zt(this.ctx.el, this.ctx), this.ctx.config = new ye({}), this.ctx.data = new Re(this.ctx), this.ctx.grid = new et(this.ctx), this.ctx.graphics = new X(this.ctx), this.ctx.coreUtils = new $(this.ctx), this.ctx.crosshairs = new He(this.ctx), this.ctx.events = new yt(this.ctx), this.ctx.exports = new Pe(this.ctx), this.ctx.fill = new ne(this.ctx), this.ctx.localization = new wt(this.ctx), this.ctx.options = new ce(), this.ctx.responsive = new At(this.ctx), this.ctx.series = new re(this.ctx), this.ctx.theme = new St(this.ctx), this.ctx.formatters = new me(this.ctx), this.ctx.titleSubtitle = new Ct(this.ctx), this.ctx.legend = new it(this.ctx), this.ctx.toolbar = new at(this.ctx), this.ctx.tooltip = new nt(this.ctx), this.ctx.dimensions = new Me(this.ctx), this.ctx.updateHelpers = new $t(this.ctx), this.ctx.zoomPanSelection = new zt(this.ctx), this.ctx.w.globals.tooltip = new nt(this.ctx);
    } }]), y;
  }(), ut = function() {
    function y(e) {
      R(this, y), this.ctx = e, this.w = e.w;
    }
    return F(y, [{ key: "clear", value: function(e) {
      var t = e.isUpdating;
      this.ctx.zoomPanSelection && this.ctx.zoomPanSelection.destroy(), this.ctx.toolbar && this.ctx.toolbar.destroy(), this.ctx.animations = null, this.ctx.axes = null, this.ctx.annotations = null, this.ctx.core = null, this.ctx.data = null, this.ctx.grid = null, this.ctx.series = null, this.ctx.responsive = null, this.ctx.theme = null, this.ctx.formatters = null, this.ctx.titleSubtitle = null, this.ctx.legend = null, this.ctx.dimensions = null, this.ctx.options = null, this.ctx.crosshairs = null, this.ctx.zoomPanSelection = null, this.ctx.updateHelpers = null, this.ctx.toolbar = null, this.ctx.localization = null, this.ctx.w.globals.tooltip = null, this.clearDomElements({ isUpdating: t });
    } }, { key: "killSVG", value: function(e) {
      e.each(function() {
        this.removeClass("*"), this.off(), this.stop();
      }, !0), e.ungroup(), e.clear();
    } }, { key: "clearDomElements", value: function(e) {
      var t = this, i = e.isUpdating, a = this.w.globals.dom.Paper.node;
      a.parentNode && a.parentNode.parentNode && !i && (a.parentNode.parentNode.style.minHeight = "unset");
      var r = this.w.globals.dom.baseEl;
      r && this.ctx.eventList.forEach(function(n) {
        r.removeEventListener(n, t.ctx.events.documentEvent);
      });
      var s = this.w.globals.dom;
      if (this.ctx.el !== null)
        for (; this.ctx.el.firstChild; )
          this.ctx.el.removeChild(this.ctx.el.firstChild);
      this.killSVG(s.Paper), s.Paper.remove(), s.elWrap = null, s.elGraphical = null, s.elLegendWrap = null, s.elLegendForeign = null, s.baseEl = null, s.elGridRect = null, s.elGridRectMask = null, s.elGridRectBarMask = null, s.elGridRectMarkerMask = null, s.elForecastMask = null, s.elNonForecastMask = null, s.elDefs = null;
    } }]), y;
  }(), We = /* @__PURE__ */ new WeakMap(), Jt = function() {
    function y(e, t) {
      R(this, y), this.opts = t, this.ctx = this, this.w = new vt(t).init(), this.el = e, this.w.globals.cuid = P.randomId(), this.w.globals.chartID = this.w.config.chart.id ? P.escapeString(this.w.config.chart.id) : this.w.globals.cuid, new gt(this).initModules(), this.create = P.bind(this.create, this), this.windowResizeHandler = this._windowResizeHandler.bind(this), this.parentResizeHandler = this._parentResizeCallback.bind(this);
    }
    return F(y, [{ key: "render", value: function() {
      var e = this;
      return new Promise(function(t, i) {
        if (e.el !== null) {
          Apex._chartInstances === void 0 && (Apex._chartInstances = []), e.w.config.chart.id && Apex._chartInstances.push({ id: e.w.globals.chartID, group: e.w.config.chart.group, chart: e }), e.setLocale(e.w.config.chart.defaultLocale);
          var a = e.w.config.chart.events.beforeMount;
          typeof a == "function" && a(e, e.w), e.events.fireEvent("beforeMount", [e, e.w]), window.addEventListener("resize", e.windowResizeHandler), function(g, p) {
            var x = !1;
            if (g.nodeType !== Node.DOCUMENT_FRAGMENT_NODE) {
              var f = g.getBoundingClientRect();
              g.style.display !== "none" && f.width !== 0 || (x = !0);
            }
            var m = new ResizeObserver(function(v) {
              x && p.call(g, v), x = !0;
            });
            g.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? Array.from(g.children).forEach(function(v) {
              return m.observe(v);
            }) : m.observe(g), We.set(p, m);
          }(e.el.parentNode, e.parentResizeHandler);
          var r = e.el.getRootNode && e.el.getRootNode(), s = P.is("ShadowRoot", r), n = e.el.ownerDocument, o = s ? r.getElementById("apexcharts-css") : n.getElementById("apexcharts-css");
          if (!o) {
            var h;
            (o = document.createElement("style")).id = "apexcharts-css", o.textContent = `@keyframes opaque {
  0% {
    opacity: 0
  }

  to {
    opacity: 1
  }
}

@keyframes resizeanim {

  0%,
  to {
    opacity: 0
  }
}

.apexcharts-canvas {
  position: relative;
  direction: ltr !important;
  user-select: none
}

.apexcharts-canvas ::-webkit-scrollbar {
  -webkit-appearance: none;
  width: 6px
}

.apexcharts-canvas ::-webkit-scrollbar-thumb {
  border-radius: 4px;
  background-color: rgba(0, 0, 0, .5);
  box-shadow: 0 0 1px rgba(255, 255, 255, .5);
  -webkit-box-shadow: 0 0 1px rgba(255, 255, 255, .5)
}

.apexcharts-inner {
  position: relative
}

.apexcharts-text tspan {
  font-family: inherit
}

rect.legend-mouseover-inactive,
.legend-mouseover-inactive rect,
.legend-mouseover-inactive path,
.legend-mouseover-inactive circle,
.legend-mouseover-inactive line,
.legend-mouseover-inactive text.apexcharts-yaxis-title-text,
.legend-mouseover-inactive text.apexcharts-yaxis-label {
  transition: .15s ease all;
  opacity: .2
}

.apexcharts-legend-text {
  padding-left: 15px;
  margin-left: -15px;
}

.apexcharts-series-collapsed {
  opacity: 0
}

.apexcharts-tooltip {
  border-radius: 5px;
  box-shadow: 2px 2px 6px -4px #999;
  cursor: default;
  font-size: 14px;
  left: 62px;
  opacity: 0;
  pointer-events: none;
  position: absolute;
  top: 20px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  white-space: nowrap;
  z-index: 12;
  transition: .15s ease all
}

.apexcharts-tooltip.apexcharts-active {
  opacity: 1;
  transition: .15s ease all
}

.apexcharts-tooltip.apexcharts-theme-light {
  border: 1px solid #e3e3e3;
  background: rgba(255, 255, 255, .96)
}

.apexcharts-tooltip.apexcharts-theme-dark {
  color: #fff;
  background: rgba(30, 30, 30, .8)
}

.apexcharts-tooltip * {
  font-family: inherit
}

.apexcharts-tooltip-title {
  padding: 6px;
  font-size: 15px;
  margin-bottom: 4px
}

.apexcharts-tooltip.apexcharts-theme-light .apexcharts-tooltip-title {
  background: #eceff1;
  border-bottom: 1px solid #ddd
}

.apexcharts-tooltip.apexcharts-theme-dark .apexcharts-tooltip-title {
  background: rgba(0, 0, 0, .7);
  border-bottom: 1px solid #333
}

.apexcharts-tooltip-text-goals-value,
.apexcharts-tooltip-text-y-value,
.apexcharts-tooltip-text-z-value {
  display: inline-block;
  margin-left: 5px;
  font-weight: 600
}

.apexcharts-tooltip-text-goals-label:empty,
.apexcharts-tooltip-text-goals-value:empty,
.apexcharts-tooltip-text-y-label:empty,
.apexcharts-tooltip-text-y-value:empty,
.apexcharts-tooltip-text-z-value:empty,
.apexcharts-tooltip-title:empty {
  display: none
}

.apexcharts-tooltip-text-goals-label,
.apexcharts-tooltip-text-goals-value {
  padding: 6px 0 5px
}

.apexcharts-tooltip-goals-group,
.apexcharts-tooltip-text-goals-label,
.apexcharts-tooltip-text-goals-value {
  display: flex
}

.apexcharts-tooltip-text-goals-label:not(:empty),
.apexcharts-tooltip-text-goals-value:not(:empty) {
  margin-top: -6px
}

.apexcharts-tooltip-marker {
  width: 12px;
  height: 12px;
  position: relative;
  top: 0;
  margin-right: 10px;
  border-radius: 50%
}

.apexcharts-tooltip-series-group {
  padding: 0 10px;
  display: none;
  text-align: left;
  justify-content: left;
  align-items: center
}

.apexcharts-tooltip-series-group.apexcharts-active .apexcharts-tooltip-marker {
  opacity: 1
}

.apexcharts-tooltip-series-group.apexcharts-active,
.apexcharts-tooltip-series-group:last-child {
  padding-bottom: 4px
}

.apexcharts-tooltip-y-group {
  padding: 6px 0 5px
}

.apexcharts-custom-tooltip,
.apexcharts-tooltip-box {
  padding: 4px 8px
}

.apexcharts-tooltip-boxPlot {
  display: flex;
  flex-direction: column-reverse
}

.apexcharts-tooltip-box>div {
  margin: 4px 0
}

.apexcharts-tooltip-box span.value {
  font-weight: 700
}

.apexcharts-tooltip-rangebar {
  padding: 5px 8px
}

.apexcharts-tooltip-rangebar .category {
  font-weight: 600;
  color: #777
}

.apexcharts-tooltip-rangebar .series-name {
  font-weight: 700;
  display: block;
  margin-bottom: 5px
}

.apexcharts-xaxistooltip,
.apexcharts-yaxistooltip {
  opacity: 0;
  pointer-events: none;
  color: #373d3f;
  font-size: 13px;
  text-align: center;
  border-radius: 2px;
  position: absolute;
  z-index: 10;
  background: #eceff1;
  border: 1px solid #90a4ae
}

.apexcharts-xaxistooltip {
  padding: 9px 10px;
  transition: .15s ease all
}

.apexcharts-xaxistooltip.apexcharts-theme-dark {
  background: rgba(0, 0, 0, .7);
  border: 1px solid rgba(0, 0, 0, .5);
  color: #fff
}

.apexcharts-xaxistooltip:after,
.apexcharts-xaxistooltip:before {
  left: 50%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none
}

.apexcharts-xaxistooltip:after {
  border-color: transparent;
  border-width: 6px;
  margin-left: -6px
}

.apexcharts-xaxistooltip:before {
  border-color: transparent;
  border-width: 7px;
  margin-left: -7px
}

.apexcharts-xaxistooltip-bottom:after,
.apexcharts-xaxistooltip-bottom:before {
  bottom: 100%
}

.apexcharts-xaxistooltip-top:after,
.apexcharts-xaxistooltip-top:before {
  top: 100%
}

.apexcharts-xaxistooltip-bottom:after {
  border-bottom-color: #eceff1
}

.apexcharts-xaxistooltip-bottom:before {
  border-bottom-color: #90a4ae
}

.apexcharts-xaxistooltip-bottom.apexcharts-theme-dark:after,
.apexcharts-xaxistooltip-bottom.apexcharts-theme-dark:before {
  border-bottom-color: rgba(0, 0, 0, .5)
}

.apexcharts-xaxistooltip-top:after {
  border-top-color: #eceff1
}

.apexcharts-xaxistooltip-top:before {
  border-top-color: #90a4ae
}

.apexcharts-xaxistooltip-top.apexcharts-theme-dark:after,
.apexcharts-xaxistooltip-top.apexcharts-theme-dark:before {
  border-top-color: rgba(0, 0, 0, .5)
}

.apexcharts-xaxistooltip.apexcharts-active {
  opacity: 1;
  transition: .15s ease all
}

.apexcharts-yaxistooltip {
  padding: 4px 10px
}

.apexcharts-yaxistooltip.apexcharts-theme-dark {
  background: rgba(0, 0, 0, .7);
  border: 1px solid rgba(0, 0, 0, .5);
  color: #fff
}

.apexcharts-yaxistooltip:after,
.apexcharts-yaxistooltip:before {
  top: 50%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none
}

.apexcharts-yaxistooltip:after {
  border-color: transparent;
  border-width: 6px;
  margin-top: -6px
}

.apexcharts-yaxistooltip:before {
  border-color: transparent;
  border-width: 7px;
  margin-top: -7px
}

.apexcharts-yaxistooltip-left:after,
.apexcharts-yaxistooltip-left:before {
  left: 100%
}

.apexcharts-yaxistooltip-right:after,
.apexcharts-yaxistooltip-right:before {
  right: 100%
}

.apexcharts-yaxistooltip-left:after {
  border-left-color: #eceff1
}

.apexcharts-yaxistooltip-left:before {
  border-left-color: #90a4ae
}

.apexcharts-yaxistooltip-left.apexcharts-theme-dark:after,
.apexcharts-yaxistooltip-left.apexcharts-theme-dark:before {
  border-left-color: rgba(0, 0, 0, .5)
}

.apexcharts-yaxistooltip-right:after {
  border-right-color: #eceff1
}

.apexcharts-yaxistooltip-right:before {
  border-right-color: #90a4ae
}

.apexcharts-yaxistooltip-right.apexcharts-theme-dark:after,
.apexcharts-yaxistooltip-right.apexcharts-theme-dark:before {
  border-right-color: rgba(0, 0, 0, .5)
}

.apexcharts-yaxistooltip.apexcharts-active {
  opacity: 1
}

.apexcharts-yaxistooltip-hidden {
  display: none
}

.apexcharts-xcrosshairs,
.apexcharts-ycrosshairs {
  pointer-events: none;
  opacity: 0;
  transition: .15s ease all
}

.apexcharts-xcrosshairs.apexcharts-active,
.apexcharts-ycrosshairs.apexcharts-active {
  opacity: 1;
  transition: .15s ease all
}

.apexcharts-ycrosshairs-hidden {
  opacity: 0
}

.apexcharts-selection-rect {
  cursor: move
}

.svg_select_boundingRect,
.svg_select_points_rot {
  pointer-events: none;
  opacity: 0;
  visibility: hidden
}

.apexcharts-selection-rect+g .svg_select_boundingRect,
.apexcharts-selection-rect+g .svg_select_points_rot {
  opacity: 0;
  visibility: hidden
}

.apexcharts-selection-rect+g .svg_select_points_l,
.apexcharts-selection-rect+g .svg_select_points_r {
  cursor: ew-resize;
  opacity: 1;
  visibility: visible
}

.svg_select_points {
  fill: #efefef;
  stroke: #333;
  rx: 2
}

.apexcharts-svg.apexcharts-zoomable.hovering-zoom {
  cursor: crosshair
}

.apexcharts-svg.apexcharts-zoomable.hovering-pan {
  cursor: move
}

.apexcharts-menu-icon,
.apexcharts-pan-icon,
.apexcharts-reset-icon,
.apexcharts-selection-icon,
.apexcharts-toolbar-custom-icon,
.apexcharts-zoom-icon,
.apexcharts-zoomin-icon,
.apexcharts-zoomout-icon {
  cursor: pointer;
  width: 20px;
  height: 20px;
  line-height: 24px;
  color: #6e8192;
  text-align: center
}

.apexcharts-menu-icon svg,
.apexcharts-reset-icon svg,
.apexcharts-zoom-icon svg,
.apexcharts-zoomin-icon svg,
.apexcharts-zoomout-icon svg {
  fill: #6e8192
}

.apexcharts-selection-icon svg {
  fill: #444;
  transform: scale(.76)
}

.apexcharts-theme-dark .apexcharts-menu-icon svg,
.apexcharts-theme-dark .apexcharts-pan-icon svg,
.apexcharts-theme-dark .apexcharts-reset-icon svg,
.apexcharts-theme-dark .apexcharts-selection-icon svg,
.apexcharts-theme-dark .apexcharts-toolbar-custom-icon svg,
.apexcharts-theme-dark .apexcharts-zoom-icon svg,
.apexcharts-theme-dark .apexcharts-zoomin-icon svg,
.apexcharts-theme-dark .apexcharts-zoomout-icon svg {
  fill: #f3f4f5
}

.apexcharts-canvas .apexcharts-reset-zoom-icon.apexcharts-selected svg,
.apexcharts-canvas .apexcharts-selection-icon.apexcharts-selected svg,
.apexcharts-canvas .apexcharts-zoom-icon.apexcharts-selected svg {
  fill: #008ffb
}

.apexcharts-theme-light .apexcharts-menu-icon:hover svg,
.apexcharts-theme-light .apexcharts-reset-icon:hover svg,
.apexcharts-theme-light .apexcharts-selection-icon:not(.apexcharts-selected):hover svg,
.apexcharts-theme-light .apexcharts-zoom-icon:not(.apexcharts-selected):hover svg,
.apexcharts-theme-light .apexcharts-zoomin-icon:hover svg,
.apexcharts-theme-light .apexcharts-zoomout-icon:hover svg {
  fill: #333
}

.apexcharts-menu-icon,
.apexcharts-selection-icon {
  position: relative
}

.apexcharts-reset-icon {
  margin-left: 5px
}

.apexcharts-menu-icon,
.apexcharts-reset-icon,
.apexcharts-zoom-icon {
  transform: scale(.85)
}

.apexcharts-zoomin-icon,
.apexcharts-zoomout-icon {
  transform: scale(.7)
}

.apexcharts-zoomout-icon {
  margin-right: 3px
}

.apexcharts-pan-icon {
  transform: scale(.62);
  position: relative;
  left: 1px;
  top: 0
}

.apexcharts-pan-icon svg {
  fill: #fff;
  stroke: #6e8192;
  stroke-width: 2
}

.apexcharts-pan-icon.apexcharts-selected svg {
  stroke: #008ffb
}

.apexcharts-pan-icon:not(.apexcharts-selected):hover svg {
  stroke: #333
}

.apexcharts-toolbar {
  position: absolute;
  z-index: 11;
  max-width: 176px;
  text-align: right;
  border-radius: 3px;
  padding: 0 6px 2px;
  display: flex;
  justify-content: space-between;
  align-items: center
}

.apexcharts-menu {
  background: #fff;
  position: absolute;
  top: 100%;
  border: 1px solid #ddd;
  border-radius: 3px;
  padding: 3px;
  right: 10px;
  opacity: 0;
  min-width: 110px;
  transition: .15s ease all;
  pointer-events: none
}

.apexcharts-menu.apexcharts-menu-open {
  opacity: 1;
  pointer-events: all;
  transition: .15s ease all
}

.apexcharts-menu-item {
  padding: 6px 7px;
  font-size: 12px;
  cursor: pointer
}

.apexcharts-theme-light .apexcharts-menu-item:hover {
  background: #eee
}

.apexcharts-theme-dark .apexcharts-menu {
  background: rgba(0, 0, 0, .7);
  color: #fff
}

@media screen and (min-width:768px) {
  .apexcharts-canvas:hover .apexcharts-toolbar {
    opacity: 1
  }
}

.apexcharts-canvas .apexcharts-element-hidden,
.apexcharts-datalabel.apexcharts-element-hidden,
.apexcharts-hide .apexcharts-series-points {
  opacity: 0;
}

.apexcharts-hidden-element-shown {
  opacity: 1;
  transition: 0.25s ease all;
}

.apexcharts-datalabel,
.apexcharts-datalabel-label,
.apexcharts-datalabel-value,
.apexcharts-datalabels,
.apexcharts-pie-label {
  cursor: default;
  pointer-events: none
}

.apexcharts-pie-label-delay {
  opacity: 0;
  animation-name: opaque;
  animation-duration: .3s;
  animation-fill-mode: forwards;
  animation-timing-function: ease
}

.apexcharts-radialbar-label {
  cursor: pointer;
}

.apexcharts-annotation-rect,
.apexcharts-area-series .apexcharts-area,
.apexcharts-area-series .apexcharts-series-markers .apexcharts-marker.no-pointer-events,
.apexcharts-gridline,
.apexcharts-line,
.apexcharts-line-series .apexcharts-series-markers .apexcharts-marker.no-pointer-events,
.apexcharts-point-annotation-label,
.apexcharts-radar-series path:not(.apexcharts-marker),
.apexcharts-radar-series polygon,
.apexcharts-toolbar svg,
.apexcharts-tooltip .apexcharts-marker,
.apexcharts-xaxis-annotation-label,
.apexcharts-yaxis-annotation-label,
.apexcharts-zoom-rect {
  pointer-events: none
}

.apexcharts-tooltip-active .apexcharts-marker {
  transition: .15s ease all
}

.resize-triggers {
  animation: 1ms resizeanim;
  visibility: hidden;
  opacity: 0;
  height: 100%;
  width: 100%;
  overflow: hidden
}

.contract-trigger:before,
.resize-triggers,
.resize-triggers>div {
  content: " ";
  display: block;
  position: absolute;
  top: 0;
  left: 0
}

.resize-triggers>div {
  height: 100%;
  width: 100%;
  background: #eee;
  overflow: auto
}

.contract-trigger:before {
  overflow: hidden;
  width: 200%;
  height: 200%
}

.apexcharts-bar-goals-markers {
  pointer-events: none
}

.apexcharts-bar-shadows {
  pointer-events: none
}

.apexcharts-rangebar-goals-markers {
  pointer-events: none
}
`;
            var d = ((h = e.opts.chart) === null || h === void 0 ? void 0 : h.nonce) || e.w.config.chart.nonce;
            d && o.setAttribute("nonce", d), s ? r.prepend(o) : n.head.appendChild(o);
          }
          var c = e.create(e.w.config.series, {});
          if (!c)
            return t(e);
          e.mount(c).then(function() {
            typeof e.w.config.chart.events.mounted == "function" && e.w.config.chart.events.mounted(e, e.w), e.events.fireEvent("mounted", [e, e.w]), t(c);
          }).catch(function(g) {
            i(g);
          });
        } else
          i(new Error("Element not found"));
      });
    } }, { key: "create", value: function(e, t) {
      var i = this, a = this.w;
      new gt(this).initModules();
      var r = this.w.globals;
      if (r.noData = !1, r.animationEnded = !1, this.responsive.checkResponsiveConfig(t), a.config.xaxis.convertedCatToNumeric && new ve(a.config).convertCatToNumericXaxis(a.config, this.ctx), this.el === null || (this.core.setupElements(), a.config.chart.type === "treemap" && (a.config.grid.show = !1, a.config.yaxis[0].show = !1), r.svgWidth === 0))
        return r.animationEnded = !0, null;
      var s = e;
      e.forEach(function(g, p) {
        g.hidden && (s = i.legend.legendHelpers.getSeriesAfterCollapsing({ realIndex: p }));
      });
      var n = $.checkComboSeries(s, a.config.chart.type);
      r.comboCharts = n.comboCharts, r.comboBarCount = n.comboBarCount;
      var o = s.every(function(g) {
        return g.data && g.data.length === 0;
      });
      (s.length === 0 || o && r.collapsedSeries.length < 1) && this.series.handleNoData(), this.events.setupEventHandlers(), this.data.parseData(s), this.theme.init(), new ue(this).setGlobalMarkerSize(), this.formatters.setLabelFormatters(), this.titleSubtitle.draw(), r.noData && r.collapsedSeries.length !== r.series.length && !a.config.legend.showForSingleSeries || this.legend.init(), this.series.hasAllSeriesEqualX(), r.axisCharts && (this.core.coreCalculations(), a.config.xaxis.type !== "category" && this.formatters.setLabelFormatters(), this.ctx.toolbar.minX = a.globals.minX, this.ctx.toolbar.maxX = a.globals.maxX), this.formatters.heatmapLabelFormatters(), new $(this).getLargestMarkerSize(), this.dimensions.plotCoords();
      var h = this.core.xySettings();
      this.grid.createGridMask();
      var d = this.core.plotChartType(s, h), c = new pe(this);
      return c.bringForward(), a.config.dataLabels.background.enabled && c.dataLabelsBackground(), this.core.shiftGraphPosition(), { elGraph: d, xyRatios: h, dimensions: { plot: { left: a.globals.translateX, top: a.globals.translateY, width: a.globals.gridWidth, height: a.globals.gridHeight } } };
    } }, { key: "mount", value: function() {
      var e = this, t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null, i = this, a = i.w;
      return new Promise(function(r, s) {
        if (i.el === null)
          return s(new Error("Not enough data to display or target element not found"));
        (t === null || a.globals.allSeriesCollapsed) && i.series.handleNoData(), i.grid = new et(i);
        var n, o, h = i.grid.drawGrid();
        if (i.annotations = new mt(i), i.annotations.drawImageAnnos(), i.annotations.drawTextAnnos(), a.config.grid.position === "back" && (h && a.globals.dom.elGraphical.add(h.el), h != null && (n = h.elGridBorders) !== null && n !== void 0 && n.node && a.globals.dom.elGraphical.add(h.elGridBorders)), Array.isArray(t.elGraph))
          for (var d = 0; d < t.elGraph.length; d++)
            a.globals.dom.elGraphical.add(t.elGraph[d]);
        else
          a.globals.dom.elGraphical.add(t.elGraph);
        a.config.grid.position === "front" && (h && a.globals.dom.elGraphical.add(h.el), h != null && (o = h.elGridBorders) !== null && o !== void 0 && o.node && a.globals.dom.elGraphical.add(h.elGridBorders)), a.config.xaxis.crosshairs.position === "front" && i.crosshairs.drawXCrosshairs(), a.config.yaxis[0].crosshairs.position === "front" && i.crosshairs.drawYCrosshairs(), a.config.chart.type !== "treemap" && i.axes.drawAxis(a.config.chart.type, h);
        var c = new we(e.ctx, h), g = new De(e.ctx, h);
        if (h !== null && (c.xAxisLabelCorrections(h.xAxisTickWidth), g.setYAxisTextAlignments(), a.config.yaxis.map(function(x, f) {
          a.globals.ignoreYAxisIndexes.indexOf(f) === -1 && g.yAxisTitleRotate(f, x.opposite);
        })), i.annotations.drawAxesAnnotations(), !a.globals.noData) {
          if (a.config.tooltip.enabled && !a.globals.noData && i.w.globals.tooltip.drawTooltip(t.xyRatios), a.globals.axisCharts && (a.globals.isXNumeric || a.config.xaxis.convertedCatToNumeric || a.globals.isRangeBar))
            (a.config.chart.zoom.enabled || a.config.chart.selection && a.config.chart.selection.enabled || a.config.chart.pan && a.config.chart.pan.enabled) && i.zoomPanSelection.init({ xyRatios: t.xyRatios });
          else {
            var p = a.config.chart.toolbar.tools;
            ["zoom", "zoomin", "zoomout", "selection", "pan", "reset"].forEach(function(x) {
              p[x] = !1;
            });
          }
          a.config.chart.toolbar.show && !a.globals.allSeriesCollapsed && i.toolbar.createToolbar();
        }
        a.globals.memory.methodsToExec.length > 0 && a.globals.memory.methodsToExec.forEach(function(x) {
          x.method(x.params, !1, x.context);
        }), a.globals.axisCharts || a.globals.noData || i.core.resizeNonAxisCharts(), r(i);
      });
    } }, { key: "destroy", value: function() {
      var e, t;
      window.removeEventListener("resize", this.windowResizeHandler), this.el.parentNode, e = this.parentResizeHandler, (t = We.get(e)) && (t.disconnect(), We.delete(e));
      var i = this.w.config.chart.id;
      i && Apex._chartInstances.forEach(function(a, r) {
        a.id === P.escapeString(i) && Apex._chartInstances.splice(r, 1);
      }), new ut(this.ctx).clear({ isUpdating: !1 });
    } }, { key: "updateOptions", value: function(e) {
      var t = this, i = arguments.length > 1 && arguments[1] !== void 0 && arguments[1], a = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2], r = !(arguments.length > 3 && arguments[3] !== void 0) || arguments[3], s = !(arguments.length > 4 && arguments[4] !== void 0) || arguments[4], n = this.w;
      return n.globals.selection = void 0, e.series && (this.series.resetSeries(!1, !0, !1), e.series.length && e.series[0].data && (e.series = e.series.map(function(o, h) {
        return t.updateHelpers._extendSeries(o, h);
      })), this.updateHelpers.revertDefaultAxisMinMax()), e.xaxis && (e = this.updateHelpers.forceXAxisUpdate(e)), e.yaxis && (e = this.updateHelpers.forceYAxisUpdate(e)), n.globals.collapsedSeriesIndices.length > 0 && this.series.clearPreviousPaths(), e.theme && (e = this.theme.updateThemeOptions(e)), this.updateHelpers._updateOptions(e, i, a, r, s);
    } }, { key: "updateSeries", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2];
      return this.series.resetSeries(!1), this.updateHelpers.revertDefaultAxisMinMax(), this.updateHelpers._updateSeries(e, t, i);
    } }, { key: "appendSeries", value: function(e) {
      var t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = !(arguments.length > 2 && arguments[2] !== void 0) || arguments[2], a = this.w.config.series.slice();
      return a.push(e), this.series.resetSeries(!1), this.updateHelpers.revertDefaultAxisMinMax(), this.updateHelpers._updateSeries(a, t, i);
    } }, { key: "appendData", value: function(e) {
      var t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = this;
      i.w.globals.dataChanged = !0, i.series.getPreviousPaths();
      for (var a = i.w.config.series.slice(), r = 0; r < a.length; r++)
        if (e[r] !== null && e[r] !== void 0)
          for (var s = 0; s < e[r].data.length; s++)
            a[r].data.push(e[r].data[s]);
      return i.w.config.series = a, t && (i.w.globals.initialSeries = P.clone(i.w.config.series)), this.update();
    } }, { key: "update", value: function(e) {
      var t = this;
      return new Promise(function(i, a) {
        new ut(t.ctx).clear({ isUpdating: !0 });
        var r = t.create(t.w.config.series, e);
        if (!r)
          return i(t);
        t.mount(r).then(function() {
          typeof t.w.config.chart.events.updated == "function" && t.w.config.chart.events.updated(t, t.w), t.events.fireEvent("updated", [t, t.w]), t.w.globals.isDirty = !0, i(t);
        }).catch(function(s) {
          a(s);
        });
      });
    } }, { key: "getSyncedCharts", value: function() {
      var e = this.getGroupedCharts(), t = [this];
      return e.length && (t = [], e.forEach(function(i) {
        t.push(i);
      })), t;
    } }, { key: "getGroupedCharts", value: function() {
      var e = this;
      return Apex._chartInstances.filter(function(t) {
        if (t.group)
          return !0;
      }).map(function(t) {
        return e.w.config.chart.group === t.group ? t.chart : e;
      });
    } }, { key: "toggleSeries", value: function(e) {
      return this.series.toggleSeries(e);
    } }, { key: "highlightSeriesOnLegendHover", value: function(e, t) {
      return this.series.toggleSeriesOnHover(e, t);
    } }, { key: "showSeries", value: function(e) {
      this.series.showSeries(e);
    } }, { key: "hideSeries", value: function(e) {
      this.series.hideSeries(e);
    } }, { key: "highlightSeries", value: function(e) {
      this.series.highlightSeries(e);
    } }, { key: "isSeriesHidden", value: function(e) {
      this.series.isSeriesHidden(e);
    } }, { key: "resetSeries", value: function() {
      var e = !(arguments.length > 0 && arguments[0] !== void 0) || arguments[0], t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1];
      this.series.resetSeries(e, t);
    } }, { key: "addEventListener", value: function(e, t) {
      this.events.addEventListener(e, t);
    } }, { key: "removeEventListener", value: function(e, t) {
      this.events.removeEventListener(e, t);
    } }, { key: "addXaxisAnnotation", value: function(e) {
      var t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : void 0, a = this;
      i && (a = i), a.annotations.addXaxisAnnotationExternal(e, t, a);
    } }, { key: "addYaxisAnnotation", value: function(e) {
      var t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : void 0, a = this;
      i && (a = i), a.annotations.addYaxisAnnotationExternal(e, t, a);
    } }, { key: "addPointAnnotation", value: function(e) {
      var t = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1], i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : void 0, a = this;
      i && (a = i), a.annotations.addPointAnnotationExternal(e, t, a);
    } }, { key: "clearAnnotations", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : void 0, t = this;
      e && (t = e), t.annotations.clearAnnotations(t);
    } }, { key: "removeAnnotation", value: function(e) {
      var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : void 0, i = this;
      t && (i = t), i.annotations.removeAnnotation(i, e);
    } }, { key: "getChartArea", value: function() {
      return this.w.globals.dom.baseEl.querySelector(".apexcharts-inner");
    } }, { key: "getSeriesTotalXRange", value: function(e, t) {
      return this.coreUtils.getSeriesTotalsXRange(e, t);
    } }, { key: "getHighestValueInSeries", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0;
      return new Fe(this.ctx).getMinYMaxY(e).highestY;
    } }, { key: "getLowestValueInSeries", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0;
      return new Fe(this.ctx).getMinYMaxY(e).lowestY;
    } }, { key: "getSeriesTotal", value: function() {
      return this.w.globals.seriesTotals;
    } }, { key: "toggleDataPointSelection", value: function(e, t) {
      return this.updateHelpers.toggleDataPointSelection(e, t);
    } }, { key: "zoomX", value: function(e, t) {
      this.ctx.toolbar.zoomUpdateOptions(e, t);
    } }, { key: "setLocale", value: function(e) {
      this.localization.setCurrentLocaleValues(e);
    } }, { key: "dataURI", value: function(e) {
      return new Pe(this.ctx).dataURI(e);
    } }, { key: "exportToCSV", value: function() {
      var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      return new Pe(this.ctx).exportToCSV(e);
    } }, { key: "paper", value: function() {
      return this.w.globals.dom.Paper;
    } }, { key: "_parentResizeCallback", value: function() {
      this.w.globals.animationEnded && this.w.config.chart.redrawOnParentResize && this._windowResize();
    } }, { key: "_windowResize", value: function() {
      var e = this;
      clearTimeout(this.w.globals.resizeTimer), this.w.globals.resizeTimer = window.setTimeout(function() {
        e.w.globals.resized = !0, e.w.globals.dataChanged = !1, e.ctx.update();
      }, 150);
    } }, { key: "_windowResizeHandler", value: function() {
      var e = this.w.config.chart.redrawOnWindowResize;
      typeof e == "function" && (e = e()), e && this._windowResize();
    } }], [{ key: "getChartByID", value: function(e) {
      var t = P.escapeString(e);
      if (Apex._chartInstances) {
        var i = Apex._chartInstances.filter(function(a) {
          return a.id === t;
        })[0];
        return i && i.chart;
      }
    } }, { key: "initOnLoad", value: function() {
      for (var e = document.querySelectorAll("[data-apexcharts]"), t = 0; t < e.length; t++)
        new y(e[t], JSON.parse(e[t].getAttribute("data-options"))).render();
    } }, { key: "exec", value: function(e, t) {
      var i = this.getChartByID(e);
      if (i) {
        i.w.globals.isExecCalled = !0;
        var a = null;
        if (i.publicMethods.indexOf(t) !== -1) {
          for (var r = arguments.length, s = new Array(r > 2 ? r - 2 : 0), n = 2; n < r; n++)
            s[n - 2] = arguments[n];
          a = i[t].apply(i, s);
        }
        return a;
      }
    } }, { key: "merge", value: function(e, t) {
      return P.extend(e, t);
    } }]), y;
  }();
  Ve.exports = Jt;
})(Ge, Ge.exports);
var ei = Ge.exports;
const ti = /* @__PURE__ */ Kt(ei), ai = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: ti
}, Symbol.toStringTag, { value: "Module" }));
export {
  ai as a
};
