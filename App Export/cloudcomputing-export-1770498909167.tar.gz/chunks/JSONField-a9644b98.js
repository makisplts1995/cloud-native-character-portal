import { S as B, i as E, s as G, ac as A, ai as V, c as C, m as N, aj as T, k as h, n as b, p as J, u as H, v as K, y as L, f as O, z as M, A as P, o as j, e as Q, aD as k } from "./index-e79f0bb2.js";
import { T as R } from "./TextArea-4567cc6e.js";
import { F as U } from "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function y(l) {
  let n, t, i;
  return t = new R({
    props: {
      value: (
        /*serialiseValue*/
        l[12](
          /*fieldState*/
          l[7].value
        )
      ),
      disabled: (
        /*fieldState*/
        l[7].disabled
      ),
      readonly: (
        /*fieldState*/
        l[7].readonly
      ),
      error: (
        /*fieldState*/
        l[7].error
      ),
      id: (
        /*fieldState*/
        l[7].fieldId
      ),
      placeholder: (
        /*placeholder*/
        l[2]
      )
    }
  }), t.$on(
    "change",
    /*handleChange*/
    l[13]
  ), {
    c() {
      n = Q("div"), C(t.$$.fragment), k(
        n,
        "--height",
        /*height*/
        l[9]
      );
    },
    m(e, o) {
      O(e, n, o), N(t, n, null), i = !0;
    },
    p(e, o) {
      const r = {};
      o & /*fieldState*/
      128 && (r.value = /*serialiseValue*/
      e[12](
        /*fieldState*/
        e[7].value
      )), o & /*fieldState*/
      128 && (r.disabled = /*fieldState*/
      e[7].disabled), o & /*fieldState*/
      128 && (r.readonly = /*fieldState*/
      e[7].readonly), o & /*fieldState*/
      128 && (r.error = /*fieldState*/
      e[7].error), o & /*fieldState*/
      128 && (r.id = /*fieldState*/
      e[7].fieldId), o & /*placeholder*/
      4 && (r.placeholder = /*placeholder*/
      e[2]), t.$set(r), (!i || o & /*height*/
      512) && k(
        n,
        "--height",
        /*height*/
        e[9]
      );
    },
    i(e) {
      i || (h(t.$$.fragment, e), i = !0);
    },
    o(e) {
      b(t.$$.fragment, e), i = !1;
    },
    d(e) {
      e && j(n), J(t);
    }
  };
}
function W(l) {
  let n, t, i = (
    /*fieldState*/
    l[7] && y(l)
  );
  return {
    c() {
      i && i.c(), n = L();
    },
    m(e, o) {
      i && i.m(e, o), O(e, n, o), t = !0;
    },
    p(e, o) {
      /*fieldState*/
      e[7] ? i ? (i.p(e, o), o & /*fieldState*/
      128 && h(i, 1)) : (i = y(e), i.c(), h(i, 1), i.m(n.parentNode, n)) : i && (M(), b(i, 1, 1, () => {
        i = null;
      }), P());
    },
    i(e) {
      t || (h(i), t = !0);
    },
    o(e) {
      b(i), t = !1;
    },
    d(e) {
      e && j(n), i && i.d(e);
    }
  };
}
function X(l) {
  let n, t, i, e;
  function o(f) {
    l[16](f);
  }
  function r(f) {
    l[17](f);
  }
  let u = {
    label: (
      /*label*/
      l[1]
    ),
    field: (
      /*field*/
      l[0]
    ),
    disabled: (
      /*disabled*/
      l[3]
    ),
    readonly: (
      /*readonly*/
      l[4]
    ),
    validation: (
      /*validation*/
      l[11]
    ),
    defaultValue: (
      /*defaultValue*/
      l[5]
    ),
    helpText: (
      /*helpText*/
      l[6]
    ),
    type: "json",
    $$slots: { default: [W] },
    $$scope: { ctx: l }
  };
  return (
    /*fieldState*/
    l[7] !== void 0 && (u.fieldState = /*fieldState*/
    l[7]), /*fieldApi*/
    l[8] !== void 0 && (u.fieldApi = /*fieldApi*/
    l[8]), n = new U({ props: u }), A.push(() => V(n, "fieldState", o)), A.push(() => V(n, "fieldApi", r)), {
      c() {
        C(n.$$.fragment);
      },
      m(f, d) {
        N(n, f, d), e = !0;
      },
      p(f, [d]) {
        const s = {};
        d & /*label*/
        2 && (s.label = /*label*/
        f[1]), d & /*field*/
        1 && (s.field = /*field*/
        f[0]), d & /*disabled*/
        8 && (s.disabled = /*disabled*/
        f[3]), d & /*readonly*/
        16 && (s.readonly = /*readonly*/
        f[4]), d & /*defaultValue*/
        32 && (s.defaultValue = /*defaultValue*/
        f[5]), d & /*helpText*/
        64 && (s.helpText = /*helpText*/
        f[6]), d & /*$$scope, height, fieldState, placeholder*/
        524932 && (s.$$scope = { dirty: d, ctx: f }), !t && d & /*fieldState*/
        128 && (t = !0, s.fieldState = /*fieldState*/
        f[7], T(() => t = !1)), !i && d & /*fieldApi*/
        256 && (i = !0, s.fieldApi = /*fieldApi*/
        f[8], T(() => i = !1)), n.$set(s);
      },
      i(f) {
        e || (h(n.$$.fragment, f), e = !0);
      },
      o(f) {
        b(n.$$.fragment, f), e = !1;
      },
      d(f) {
        J(n, f);
      }
    }
  );
}
function Y(l, n, t) {
  let i, e, { field: o } = n, { label: r } = n, { placeholder: u } = n, { disabled: f = !1 } = n, { readonly: d = !1 } = n, { defaultValue: s = "" } = n, { onChange: c } = n, { helpText: p = null } = n;
  const S = H("component");
  K(l, S, (a) => t(15, e = a));
  const v = [
    {
      constraint: "json",
      type: "json",
      error: "JSON syntax is invalid"
    }
  ];
  let g, m;
  const F = (a) => JSON.stringify(a || void 0, null, 4) || "", w = (a) => {
    try {
      return JSON.parse(a);
    } catch {
      return a;
    }
  }, I = (a) => {
    const _ = w(a.detail), D = m.setValue(_);
    c && D && c({ value: _ });
  };
  function q(a) {
    g = a, t(7, g);
  }
  function z(a) {
    m = a, t(8, m);
  }
  return l.$$set = (a) => {
    "field" in a && t(0, o = a.field), "label" in a && t(1, r = a.label), "placeholder" in a && t(2, u = a.placeholder), "disabled" in a && t(3, f = a.disabled), "readonly" in a && t(4, d = a.readonly), "defaultValue" in a && t(5, s = a.defaultValue), "onChange" in a && t(14, c = a.onChange), "helpText" in a && t(6, p = a.helpText);
  }, l.$$.update = () => {
    var a, _;
    l.$$.dirty & /*$component*/
    32768 && t(9, i = ((_ = (a = e.styles) == null ? void 0 : a.normal) == null ? void 0 : _.height) || "124px");
  }, [
    o,
    r,
    u,
    f,
    d,
    s,
    p,
    g,
    m,
    i,
    S,
    v,
    F,
    I,
    c,
    e,
    q,
    z
  ];
}
class ne extends B {
  constructor(n) {
    super(), E(this, n, Y, X, G, {
      field: 0,
      label: 1,
      placeholder: 2,
      disabled: 3,
      readonly: 4,
      defaultValue: 5,
      onChange: 14,
      helpText: 6
    });
  }
}
export {
  ne as default
};
