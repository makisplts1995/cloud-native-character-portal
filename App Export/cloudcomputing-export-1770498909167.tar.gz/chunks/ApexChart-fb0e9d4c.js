import { S as F, i as G, s as B, y as N, f as _, z as T, n as h, B as H, A as q, k as d, o as b, u as w, v as D, e as I, a as J, b as z, d as S, q as E, h as K, ac as Q, I as R, c as V, t as W, m as X, g as Y, p as Z } from "./index-e79f0bb2.js";
const $ = {
  Default: (e) => e,
  Thousands: (e) => `${Math.round(e / 1e3)}K`,
  Millions: (e) => `${Math.round(e / 1e6)}M`,
  Datetime: (e) => new Date(e).toLocaleString()
}, ee = (e) => {
  if (e === "Custom")
    return null;
  const [s, n] = e.split(" ");
  return `palette${n}`;
}, k = (e) => {
  const s = ["string", "boolean", "number", "function", "symbol"];
  if (e === null)
    return null;
  if (e !== void 0) {
    if (s.includes(typeof e))
      return e;
    if (Array.isArray(e))
      return e.map((n) => k(n));
    if (typeof e == "object" && e.constructor.name === "Object") {
      const n = {};
      return Object.entries(e).forEach(([r, o]) => {
        n[r] = k(o);
      }), n;
    }
    throw `Unsupported value: "${e}" of type: "${typeof e}"`;
  }
};
function j(e) {
  let s, n, r, o, u, a, c;
  return n = new R({
    props: {
      name: "warning",
      color: "var(--spectrum-global-color-static-red-600)"
    }
  }), {
    c() {
      s = I("div"), V(n.$$.fragment), r = W(`
      Add rows to your data source to start using your component`), z(s, "class", "component-placeholder svelte-sniduo");
    },
    m(t, l) {
      _(t, s, l), X(n, s, null), Y(s, r), u = !0, a || (c = E(o = /*styleable*/
      e[5].call(null, s, {
        .../*$component*/
        e[3].styles,
        normal: {},
        custom: null,
        empty: !0
      })), a = !0);
    },
    p(t, l) {
      o && K(o.update) && l & /*$component*/
      8 && o.update.call(null, {
        .../*$component*/
        t[3].styles,
        normal: {},
        custom: null,
        empty: !0
      });
    },
    i(t) {
      u || (d(n.$$.fragment, t), u = !0);
    },
    o(t) {
      h(n.$$.fragment, t), u = !1;
    },
    d(t) {
      t && b(s), Z(n), a = !1, c();
    }
  };
}
function M(e) {
  let s, n, r, o, u, a, c, t = (
    /*$builderStore*/
    e[4].inBuilder && /*noData*/
    e[2] && j(e)
  );
  return {
    c() {
      s = I("div"), r = J(), t && t.c(), o = N(), z(s, "class", "svelte-sniduo"), S(
        s,
        "hide",
        /*noData*/
        e[2]
      );
    },
    m(l, f) {
      _(l, s, f), e[9](s), _(l, r, f), t && t.m(l, f), _(l, o, f), u = !0, a || (c = E(n = /*styleable*/
      e[5].call(
        null,
        s,
        /*$component*/
        e[3].styles
      )), a = !0);
    },
    p(l, f) {
      n && K(n.update) && f & /*$component*/
      8 && n.update.call(
        null,
        /*$component*/
        l[3].styles
      ), (!u || f & /*noData*/
      4) && S(
        s,
        "hide",
        /*noData*/
        l[2]
      ), /*$builderStore*/
      l[4].inBuilder && /*noData*/
      l[2] ? t ? (t.p(l, f), f & /*$builderStore, noData*/
      20 && d(t, 1)) : (t = j(l), t.c(), d(t, 1), t.m(o.parentNode, o)) : t && (T(), h(t, 1, 1, () => {
        t = null;
      }), q());
    },
    i(l) {
      u || (d(t), u = !0);
    },
    o(l) {
      h(t), u = !1;
    },
    d(l) {
      l && (b(s), b(r), b(o)), e[9](null), t && t.d(l), a = !1, c();
    }
  };
}
function v(e) {
  var u;
  let s = (
    /*optionsCopy*/
    (u = e[1]) == null ? void 0 : u.customColor
  ), n, r, o = M(e);
  return {
    c() {
      o.c(), n = N();
    },
    m(a, c) {
      o.m(a, c), _(a, n, c), r = !0;
    },
    p(a, [c]) {
      var t;
      c & /*optionsCopy*/
      2 && B(s, s = /*optionsCopy*/
      (t = a[1]) == null ? void 0 : t.customColor) ? (T(), h(o, 1, 1, H), q(), o = M(a), o.c(), d(o, 1), o.m(n.parentNode, n)) : o.p(a, c);
    },
    i(a) {
      r || (d(o), r = !0);
    },
    o(a) {
      h(o), r = !1;
    },
    d(a) {
      a && b(n), o.d(a);
    }
  };
}
function O(e, s, n) {
  let r, o, u, a;
  const { styleable: c, builderStore: t } = w("sdk");
  D(e, t, (i) => n(4, a = i));
  const l = w("component");
  D(e, l, (i) => n(3, u = i));
  let { options: f } = s, m, p, A = null;
  const L = async (i) => {
    var y;
    (y = i == null ? void 0 : i.xaxis) != null && y.type && i.xaxis.type !== A ? await C(m) : await (p == null ? void 0 : p.updateOptions(i));
  }, C = async (i) => {
    var y;
    if (i)
      try {
        await (p == null ? void 0 : p.destroy());
        const { default: g } = await import("./apexcharts.common-a696121d.js").then((U) => U.a);
        p = new g(i, r), A = (y = r == null ? void 0 : r.xaxis) == null ? void 0 : y.type, await p.render();
      } catch (g) {
        if (g.message !== "Cannot read properties of undefined (reading 'parentNode')")
          throw g;
      }
  };
  function P(i) {
    Q[i ? "unshift" : "push"](() => {
      m = i, n(0, m);
    });
  }
  return e.$$set = (i) => {
    "options" in i && n(8, f = i.options);
  }, e.$$.update = () => {
    var i;
    e.$$.dirty & /*options*/
    256 && n(1, r = k(f)), e.$$.dirty & /*optionsCopy*/
    2 && n(2, o = r == null || ((i = r == null ? void 0 : r.series) == null ? void 0 : i.length) === 0), e.$$.dirty & /*chartElement, noData*/
    5 && C(m), e.$$.dirty & /*optionsCopy*/
    2 && L(r);
  }, [
    m,
    r,
    o,
    u,
    a,
    c,
    t,
    l,
    f,
    P
  ];
}
class te extends F {
  constructor(s) {
    super(), G(this, s, O, v, B, { options: 8 });
  }
}
export {
  te as A,
  $ as f,
  ee as p
};
