import { S as J, i as M, s as j, I as K, F as q, e as S, c as D, a as N, t as Q, b as r, aJ as P, aD as k, d as C, f as R, g as b, m as F, l as T, j as U, G, H as L, J as B, k as H, n as w, o as V, p as E } from "./index-e79f0bb2.js";
function W(i) {
  let e, l, n, t, a, _, g, f, h, A, c, p, u, O, o;
  a = new K({
    props: {
      name: (
        /*isOpen*/
        i[5] ? "caret-down" : "caret-right"
      ),
      size: "S"
    }
  });
  const z = (
    /*#slots*/
    i[10].default
  ), m = q(
    z,
    i,
    /*$$scope*/
    i[9],
    null
  );
  return {
    c() {
      e = S("div"), l = S("div"), n = S("h3"), t = S("button"), D(a.$$.fragment), _ = N(), g = Q(
        /*header*/
        i[1]
      ), A = N(), c = S("div"), m && m.c(), r(t, "class", f = P(`spectrum-Accordion-itemHeader ${I(
        /*headerSize*/
        i[2]
      )}`) + " svelte-1h85agu"), r(t, "type", "button"), k(
        t,
        "--font-weight",
        /*bold*/
        i[3] ? "bold" : "normal"
      ), r(n, "class", "spectrum-Accordion-itemHeading"), r(n, "style", h = /*noPadding*/
      i[4] ? "margin-bottom: -10px;" : ""), r(c, "class", "spectrum-Accordion-itemContent svelte-1h85agu"), r(
        c,
        "role",
        /*itemName*/
        i[0]
      ), r(c, "style", p = /*noPadding*/
      i[4] ? "padding-left: 0; padding-bottom: 0;" : "padding-left: 30px;"), r(l, "class", "spectrum-Accordion-item svelte-1h85agu"), C(
        l,
        "is-open",
        /*isOpen*/
        i[5]
      ), r(e, "class", "spectrum-Accordion"), r(
        e,
        "role",
        /*itemName*/
        i[0]
      );
    },
    m(s, d) {
      R(s, e, d), b(e, l), b(l, n), b(n, t), F(a, t, null), b(t, _), b(t, g), b(l, A), b(l, c), m && m.m(c, null), u = !0, O || (o = T(
        t,
        "click",
        /*click_handler*/
        i[11]
      ), O = !0);
    },
    p(s, [d]) {
      const v = {};
      d & /*isOpen*/
      32 && (v.name = /*isOpen*/
      s[5] ? "caret-down" : "caret-right"), a.$set(v), (!u || d & /*header*/
      2) && U(
        g,
        /*header*/
        s[1]
      ), (!u || d & /*headerSize*/
      4 && f !== (f = P(`spectrum-Accordion-itemHeader ${I(
        /*headerSize*/
        s[2]
      )}`) + " svelte-1h85agu")) && r(t, "class", f), (!u || d & /*bold*/
      8) && k(
        t,
        "--font-weight",
        /*bold*/
        s[3] ? "bold" : "normal"
      ), (!u || d & /*noPadding*/
      16 && h !== (h = /*noPadding*/
      s[4] ? "margin-bottom: -10px;" : "")) && r(n, "style", h), m && m.p && (!u || d & /*$$scope*/
      512) && G(
        m,
        z,
        s,
        /*$$scope*/
        s[9],
        u ? B(
          z,
          /*$$scope*/
          s[9],
          d,
          null
        ) : L(
          /*$$scope*/
          s[9]
        ),
        null
      ), (!u || d & /*itemName*/
      1) && r(
        c,
        "role",
        /*itemName*/
        s[0]
      ), (!u || d & /*noPadding*/
      16 && p !== (p = /*noPadding*/
      s[4] ? "padding-left: 0; padding-bottom: 0;" : "padding-left: 30px;")) && r(c, "style", p), (!u || d & /*isOpen*/
      32) && C(
        l,
        "is-open",
        /*isOpen*/
        s[5]
      ), (!u || d & /*itemName*/
      1) && r(
        e,
        "role",
        /*itemName*/
        s[0]
      );
    },
    i(s) {
      u || (H(a.$$.fragment, s), H(m, s), u = !0);
    },
    o(s) {
      w(a.$$.fragment, s), w(m, s), u = !1;
    },
    d(s) {
      s && V(e), E(a), m && m.d(s), O = !1, o();
    }
  };
}
function I(i) {
  return i === "S" ? "spectrum-Accordion-itemHeaderS" : i === "M" ? "spectrum-Accordion-itemHeaderM" : "spectrum-Accordion-itemHeaderL";
}
function X(i, e, l) {
  let { $$slots: n = {}, $$scope: t } = e, { itemName: a = void 0 } = e, { initialOpen: _ = !1 } = e, { header: g } = e, { headerSize: f = "S" } = e, { bold: h = !0 } = e, { noPadding: A = !1 } = e, c = _;
  function p() {
    l(5, c = !0);
  }
  function u() {
    l(5, c = !1);
  }
  const O = () => l(5, c = !c);
  return i.$$set = (o) => {
    "itemName" in o && l(0, a = o.itemName), "initialOpen" in o && l(6, _ = o.initialOpen), "header" in o && l(1, g = o.header), "headerSize" in o && l(2, f = o.headerSize), "bold" in o && l(3, h = o.bold), "noPadding" in o && l(4, A = o.noPadding), "$$scope" in o && l(9, t = o.$$scope);
  }, [
    a,
    g,
    f,
    h,
    A,
    c,
    _,
    p,
    u,
    t,
    n,
    O
  ];
}
class Y extends J {
  constructor(e) {
    super(), M(this, e, X, W, j, {
      itemName: 0,
      initialOpen: 6,
      header: 1,
      headerSize: 2,
      bold: 3,
      noPadding: 4,
      open: 7,
      close: 8
    });
  }
  get open() {
    return this.$$.ctx[7];
  }
  get close() {
    return this.$$.ctx[8];
  }
}
function Z(i) {
  let e;
  const l = (
    /*#slots*/
    i[3].default
  ), n = q(
    l,
    i,
    /*$$scope*/
    i[4],
    null
  );
  return {
    c() {
      n && n.c();
    },
    m(t, a) {
      n && n.m(t, a), e = !0;
    },
    p(t, a) {
      n && n.p && (!e || a & /*$$scope*/
      16) && G(
        n,
        l,
        t,
        /*$$scope*/
        t[4],
        e ? B(
          l,
          /*$$scope*/
          t[4],
          a,
          null
        ) : L(
          /*$$scope*/
          t[4]
        ),
        null
      );
    },
    i(t) {
      e || (H(n, t), e = !0);
    },
    o(t) {
      w(n, t), e = !1;
    },
    d(t) {
      n && n.d(t);
    }
  };
}
function y(i) {
  let e, l;
  return e = new Y({
    props: {
      header: (
        /*label*/
        i[2] || ""
      ),
      bold: (
        /*bold*/
        i[0]
      ),
      initialOpen: (
        /*initialOpen*/
        i[1]
      ),
      $$slots: { default: [Z] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      D(e.$$.fragment);
    },
    m(n, t) {
      F(e, n, t), l = !0;
    },
    p(n, [t]) {
      const a = {};
      t & /*label*/
      4 && (a.header = /*label*/
      n[2] || ""), t & /*bold*/
      1 && (a.bold = /*bold*/
      n[0]), t & /*initialOpen*/
      2 && (a.initialOpen = /*initialOpen*/
      n[1]), t & /*$$scope*/
      16 && (a.$$scope = { dirty: t, ctx: n }), e.$set(a);
    },
    i(n) {
      l || (H(e.$$.fragment, n), l = !0);
    },
    o(n) {
      w(e.$$.fragment, n), l = !1;
    },
    d(n) {
      E(e, n);
    }
  };
}
function x(i, e, l) {
  let { $$slots: n = {}, $$scope: t } = e, { bold: a } = e, { initialOpen: _ } = e, { label: g } = e;
  return i.$$set = (f) => {
    "bold" in f && l(0, a = f.bold), "initialOpen" in f && l(1, _ = f.initialOpen), "label" in f && l(2, g = f.label), "$$scope" in f && l(4, t = f.$$scope);
  }, [a, _, g, n, t];
}
class ee extends J {
  constructor(e) {
    super(), M(this, e, x, y, j, { bold: 0, initialOpen: 1, label: 2 });
  }
}
export {
  ee as default
};
