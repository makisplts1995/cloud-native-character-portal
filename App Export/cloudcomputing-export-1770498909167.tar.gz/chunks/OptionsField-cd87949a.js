import { S as oe, i as fe, s as ae, ac as v, ai as A, c as L, m as I, aj as P, k as c, n as b, p as w, ck as te, y as W, f as X, z as Y, A as Z, o as y, cm as ue } from "./index-e79f0bb2.js";
import { R as de } from "./RadioGroup-22e84d5a.js";
import { F as se } from "./Field-269dd13f.js";
import { g as re } from "./optionsParser-7fb88327.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function q(e) {
  let l, n, i, o;
  const a = [ce, _e], _ = [];
  function m(u, r) {
    return !/*optionsType*/
    u[5] || /*optionsType*/
    u[5] === "select" ? 0 : (
      /*optionsType*/
      u[5] === "radio" ? 1 : -1
    );
  }
  return ~(l = m(e)) && (n = _[l] = a[l](e)), {
    c() {
      n && n.c(), i = W();
    },
    m(u, r) {
      ~l && _[l].m(u, r), X(u, i, r), o = !0;
    },
    p(u, r) {
      let t = l;
      l = m(u), l === t ? ~l && _[l].p(u, r) : (n && (Y(), b(_[t], 1, 1, () => {
        _[t] = null;
      }), Z()), ~l ? (n = _[l], n ? n.p(u, r) : (n = _[l] = a[l](u), n.c()), c(n, 1), n.m(i.parentNode, i)) : n = null);
    },
    i(u) {
      o || (c(n), o = !0);
    },
    o(u) {
      b(n), o = !1;
    },
    d(u) {
      u && y(i), ~l && _[l].d(u);
    }
  };
}
function _e(e) {
  let l, n;
  return l = new de({
    props: {
      value: (
        /*fieldState*/
        e[14].value
      ),
      id: (
        /*fieldState*/
        e[14].fieldId
      ),
      disabled: (
        /*fieldState*/
        e[14].disabled
      ),
      readonly: (
        /*fieldState*/
        e[14].readonly
      ),
      error: (
        /*fieldState*/
        e[14].error
      ),
      options: (
        /*options*/
        e[16]
      ),
      direction: (
        /*direction*/
        e[9]
      ),
      getOptionLabel: (
        /*flatOptions*/
        e[17] ? H : J
      ),
      getOptionTitle: (
        /*flatOptions*/
        e[17] ? K : M
      ),
      getOptionValue: (
        /*flatOptions*/
        e[17] ? Q : U
      ),
      sort: (
        /*sort*/
        e[10]
      )
    }
  }), l.$on(
    "change",
    /*handleChange*/
    e[19]
  ), {
    c() {
      L(l.$$.fragment);
    },
    m(i, o) {
      I(l, i, o), n = !0;
    },
    p(i, o) {
      const a = {};
      o & /*fieldState*/
      16384 && (a.value = /*fieldState*/
      i[14].value), o & /*fieldState*/
      16384 && (a.id = /*fieldState*/
      i[14].fieldId), o & /*fieldState*/
      16384 && (a.disabled = /*fieldState*/
      i[14].disabled), o & /*fieldState*/
      16384 && (a.readonly = /*fieldState*/
      i[14].readonly), o & /*fieldState*/
      16384 && (a.error = /*fieldState*/
      i[14].error), o & /*options*/
      65536 && (a.options = /*options*/
      i[16]), o & /*direction*/
      512 && (a.direction = /*direction*/
      i[9]), o & /*flatOptions*/
      131072 && (a.getOptionLabel = /*flatOptions*/
      i[17] ? H : J), o & /*flatOptions*/
      131072 && (a.getOptionTitle = /*flatOptions*/
      i[17] ? K : M), o & /*flatOptions*/
      131072 && (a.getOptionValue = /*flatOptions*/
      i[17] ? Q : U), o & /*sort*/
      1024 && (a.sort = /*sort*/
      i[10]), l.$set(a);
    },
    i(i) {
      n || (c(l.$$.fragment, i), n = !0);
    },
    o(i) {
      b(l.$$.fragment, i), n = !1;
    },
    d(i) {
      w(l, i);
    }
  };
}
function ce(e) {
  let l, n;
  return l = new ue({
    props: {
      value: (
        /*fieldState*/
        e[14].value
      ),
      id: (
        /*fieldState*/
        e[14].fieldId
      ),
      disabled: (
        /*fieldState*/
        e[14].disabled
      ),
      readonly: (
        /*fieldState*/
        e[14].readonly
      ),
      error: (
        /*fieldState*/
        e[14].error
      ),
      options: (
        /*options*/
        e[16]
      ),
      placeholder: (
        /*placeholder*/
        e[2]
      ),
      getOptionLabel: (
        /*flatOptions*/
        e[17] ? z : B
      ),
      getOptionValue: (
        /*flatOptions*/
        e[17] ? D : E
      ),
      autocomplete: (
        /*autocomplete*/
        e[8]
      ),
      sort: (
        /*sort*/
        e[10]
      ),
      searchPlaceholder: (
        /*pickerLabels*/
        e[18].searchPlaceholder
      )
    }
  }), l.$on(
    "change",
    /*handleChange*/
    e[19]
  ), {
    c() {
      L(l.$$.fragment);
    },
    m(i, o) {
      I(l, i, o), n = !0;
    },
    p(i, o) {
      const a = {};
      o & /*fieldState*/
      16384 && (a.value = /*fieldState*/
      i[14].value), o & /*fieldState*/
      16384 && (a.id = /*fieldState*/
      i[14].fieldId), o & /*fieldState*/
      16384 && (a.disabled = /*fieldState*/
      i[14].disabled), o & /*fieldState*/
      16384 && (a.readonly = /*fieldState*/
      i[14].readonly), o & /*fieldState*/
      16384 && (a.error = /*fieldState*/
      i[14].error), o & /*options*/
      65536 && (a.options = /*options*/
      i[16]), o & /*placeholder*/
      4 && (a.placeholder = /*placeholder*/
      i[2]), o & /*flatOptions*/
      131072 && (a.getOptionLabel = /*flatOptions*/
      i[17] ? z : B), o & /*flatOptions*/
      131072 && (a.getOptionValue = /*flatOptions*/
      i[17] ? D : E), o & /*autocomplete*/
      256 && (a.autocomplete = /*autocomplete*/
      i[8]), o & /*sort*/
      1024 && (a.sort = /*sort*/
      i[10]), l.$set(a);
    },
    i(i) {
      n || (c(l.$$.fragment, i), n = !0);
    },
    o(i) {
      b(l.$$.fragment, i), n = !1;
    },
    d(i) {
      w(l, i);
    }
  };
}
function me(e) {
  let l, n, i = (
    /*fieldState*/
    e[14] && q(e)
  );
  return {
    c() {
      i && i.c(), l = W();
    },
    m(o, a) {
      i && i.m(o, a), X(o, l, a), n = !0;
    },
    p(o, a) {
      /*fieldState*/
      o[14] ? i ? (i.p(o, a), a & /*fieldState*/
      16384 && c(i, 1)) : (i = q(o), i.c(), c(i, 1), i.m(l.parentNode, l)) : i && (Y(), b(i, 1, 1, () => {
        i = null;
      }), Z());
    },
    i(o) {
      n || (c(i), n = !0);
    },
    o(o) {
      b(i), n = !1;
    },
    d(o) {
      o && y(l), i && i.d(o);
    }
  };
}
function be(e) {
  let l, n, i, o, a;
  function _(t) {
    e[26](t);
  }
  function m(t) {
    e[27](t);
  }
  function u(t) {
    e[28](t);
  }
  let r = {
    field: (
      /*field*/
      e[0]
    ),
    label: (
      /*label*/
      e[1]
    ),
    disabled: (
      /*disabled*/
      e[3]
    ),
    readonly: (
      /*readonly*/
      e[4]
    ),
    validation: (
      /*validation*/
      e[6]
    ),
    defaultValue: (
      /*defaultValue*/
      e[7]
    ),
    span: (
      /*span*/
      e[11]
    ),
    helpText: (
      /*helpText*/
      e[12]
    ),
    type: "options",
    $$slots: { default: [me] },
    $$scope: { ctx: e }
  };
  return (
    /*fieldState*/
    e[14] !== void 0 && (r.fieldState = /*fieldState*/
    e[14]), /*fieldApi*/
    e[15] !== void 0 && (r.fieldApi = /*fieldApi*/
    e[15]), /*fieldSchema*/
    e[13] !== void 0 && (r.fieldSchema = /*fieldSchema*/
    e[13]), l = new se({ props: r }), v.push(() => A(l, "fieldState", _)), v.push(() => A(l, "fieldApi", m)), v.push(() => A(l, "fieldSchema", u)), {
      c() {
        L(l.$$.fragment);
      },
      m(t, d) {
        I(l, t, d), a = !0;
      },
      p(t, [d]) {
        const s = {};
        d & /*field*/
        1 && (s.field = /*field*/
        t[0]), d & /*label*/
        2 && (s.label = /*label*/
        t[1]), d & /*disabled*/
        8 && (s.disabled = /*disabled*/
        t[3]), d & /*readonly*/
        16 && (s.readonly = /*readonly*/
        t[4]), d & /*validation*/
        64 && (s.validation = /*validation*/
        t[6]), d & /*defaultValue*/
        128 && (s.defaultValue = /*defaultValue*/
        t[7]), d & /*span*/
        2048 && (s.span = /*span*/
        t[11]), d & /*helpText*/
        4096 && (s.helpText = /*helpText*/
        t[12]), d & /*$$scope, fieldState, options, placeholder, flatOptions, autocomplete, sort, optionsType, direction*/
        537085732 && (s.$$scope = { dirty: d, ctx: t }), !n && d & /*fieldState*/
        16384 && (n = !0, s.fieldState = /*fieldState*/
        t[14], P(() => n = !1)), !i && d & /*fieldApi*/
        32768 && (i = !0, s.fieldApi = /*fieldApi*/
        t[15], P(() => i = !1)), !o && d & /*fieldSchema*/
        8192 && (o = !0, s.fieldSchema = /*fieldSchema*/
        t[13], P(() => o = !1)), l.$set(s);
      },
      i(t) {
        a || (c(l.$$.fragment, t), a = !0);
      },
      o(t) {
        b(l.$$.fragment, t), a = !1;
      },
      d(t) {
        w(l, t);
      }
    }
  );
}
const z = (e) => e, B = (e) => e.label, D = (e) => e, E = (e) => e.value, H = (e) => e, J = (e) => e.label, K = (e) => e, M = (e) => e.label, Q = (e) => e, U = (e) => e.value;
function ge(e, l, n) {
  let i, o, { field: a } = l, { label: _ } = l, { placeholder: m } = l, { disabled: u = !1 } = l, { readonly: r = !1 } = l, { optionsType: t = "select" } = l, { validation: d } = l, { defaultValue: s } = l, { optionsSource: g = "schema" } = l, { dataProvider: O } = l, { labelColumn: C } = l, { valueColumn: T } = l, { customOptions: V } = l, { autocomplete: F = !1 } = l, { direction: G = "vertical" } = l, { onChange: h } = l, { sort: N = !0 } = l, { span: R } = l, { helpText: j = null } = l, p, S, k;
  const x = te("picker"), $ = (f) => {
    const ne = S.setValue(f.detail);
    h && ne && h({ value: f.detail });
  };
  function ee(f) {
    p = f, n(14, p);
  }
  function le(f) {
    S = f, n(15, S);
  }
  function ie(f) {
    k = f, n(13, k);
  }
  return e.$$set = (f) => {
    "field" in f && n(0, a = f.field), "label" in f && n(1, _ = f.label), "placeholder" in f && n(2, m = f.placeholder), "disabled" in f && n(3, u = f.disabled), "readonly" in f && n(4, r = f.readonly), "optionsType" in f && n(5, t = f.optionsType), "validation" in f && n(6, d = f.validation), "defaultValue" in f && n(7, s = f.defaultValue), "optionsSource" in f && n(20, g = f.optionsSource), "dataProvider" in f && n(21, O = f.dataProvider), "labelColumn" in f && n(22, C = f.labelColumn), "valueColumn" in f && n(23, T = f.valueColumn), "customOptions" in f && n(24, V = f.customOptions), "autocomplete" in f && n(8, F = f.autocomplete), "direction" in f && n(9, G = f.direction), "onChange" in f && n(25, h = f.onChange), "sort" in f && n(10, N = f.sort), "span" in f && n(11, R = f.span), "helpText" in f && n(12, j = f.helpText);
  }, e.$$.update = () => {
    e.$$.dirty & /*optionsSource*/
    1048576 && n(17, i = g == null || g === "schema"), e.$$.dirty & /*optionsSource, fieldSchema, dataProvider, labelColumn, valueColumn, customOptions*/
    32514048 && n(16, o = re(g, k, O, C, T, V));
  }, [
    a,
    _,
    m,
    u,
    r,
    t,
    d,
    s,
    F,
    G,
    N,
    R,
    j,
    k,
    p,
    S,
    o,
    i,
    x,
    $,
    g,
    O,
    C,
    T,
    V,
    h,
    ee,
    le,
    ie
  ];
}
class Ve extends oe {
  constructor(l) {
    super(), fe(this, l, ge, be, ae, {
      field: 0,
      label: 1,
      placeholder: 2,
      disabled: 3,
      readonly: 4,
      optionsType: 5,
      validation: 6,
      defaultValue: 7,
      optionsSource: 20,
      dataProvider: 21,
      labelColumn: 22,
      valueColumn: 23,
      customOptions: 24,
      autocomplete: 8,
      direction: 9,
      onChange: 25,
      sort: 10,
      span: 11,
      helpText: 12
    });
  }
}
export {
  Ve as default
};
