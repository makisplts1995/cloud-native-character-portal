import { S as c, i as l, s as _, b2 as f, bL as i, c as u, m as d, c7 as g, c8 as h, k as A, n as M, p as $, cH as p, bM as b } from "./index-e79f0bb2.js";
import S from "./AttachmentField-d140a09b.js";
import "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function T(o) {
  let t, s;
  const a = [
    /*$$restProps*/
    o[1],
    { type: f.ATTACHMENT_SINGLE },
    { maximum: 1 },
    { defaultValue: null },
    {
      fieldApiMapper: (
        /*fieldApiMapper*/
        o[0]
      )
    }
  ];
  let r = {};
  for (let e = 0; e < a.length; e += 1)
    r = i(r, a[e]);
  return t = new S({ props: r }), {
    c() {
      u(t.$$.fragment);
    },
    m(e, n) {
      d(t, e, n), s = !0;
    },
    p(e, [n]) {
      const m = n & /*$$restProps, fieldApiMapper*/
      3 ? g(a, [
        n & /*$$restProps*/
        2 && h(
          /*$$restProps*/
          e[1]
        ),
        a[1],
        a[2],
        a[3],
        n & /*fieldApiMapper*/
        1 && {
          fieldApiMapper: (
            /*fieldApiMapper*/
            e[0]
          )
        }
      ]) : {};
      t.$set(m);
    },
    i(e) {
      s || (A(t.$$.fragment, e), s = !0);
    },
    o(e) {
      M(t.$$.fragment, e), s = !1;
    },
    d(e) {
      $(t, e);
    }
  };
}
function y(o, t, s) {
  const a = [];
  let r = p(t, a);
  const e = {
    get: (n) => (!Array.isArray(n) && n ? [n] : n) || [],
    set: (n) => n[0] || null
  };
  return o.$$set = (n) => {
    t = i(i({}, t), b(n)), s(1, r = p(t, a));
  }, [e, r];
}
class L extends c {
  constructor(t) {
    super(), l(this, t, y, T, _, {});
  }
}
export {
  L as default
};
