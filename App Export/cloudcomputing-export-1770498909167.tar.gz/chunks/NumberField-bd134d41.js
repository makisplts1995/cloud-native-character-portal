import { S as f, i as m, s as c, bL as u, c as d, m as _, c7 as g, c8 as p, k as b, n as V, p as N, bM as i } from "./index-e79f0bb2.js";
import h from "./StringField-b0123b03.js";
import "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function F(r) {
  let t, n;
  const a = [
    /*$$props*/
    r[2],
    { type: "number" },
    {
      defaultValue: (
        /*parseNumber*/
        r[1](
          /*defaultValue*/
          r[0]
        )
      )
    }
  ];
  let s = {};
  for (let e = 0; e < a.length; e += 1)
    s = u(s, a[e]);
  return t = new h({ props: s }), {
    c() {
      d(t.$$.fragment);
    },
    m(e, l) {
      _(t, e, l), n = !0;
    },
    p(e, [l]) {
      const o = l & /*$$props, parseNumber, defaultValue*/
      7 ? g(a, [
        l & /*$$props*/
        4 && p(
          /*$$props*/
          e[2]
        ),
        a[1],
        l & /*parseNumber, defaultValue*/
        3 && {
          defaultValue: (
            /*parseNumber*/
            e[1](
              /*defaultValue*/
              e[0]
            )
          )
        }
      ]) : {};
      t.$set(o);
    },
    i(e) {
      n || (b(t.$$.fragment, e), n = !0);
    },
    o(e) {
      V(t.$$.fragment, e), n = !1;
    },
    d(e) {
      N(t, e);
    }
  };
}
function S(r, t, n) {
  let { defaultValue: a } = t;
  const s = (e) => e == null || isNaN(e) ? null : parseFloat(e);
  return r.$$set = (e) => {
    n(2, t = u(u({}, t), i(e))), "defaultValue" in e && n(0, a = e.defaultValue);
  }, t = i(t), [a, s, t];
}
class M extends f {
  constructor(t) {
    super(), m(this, t, S, F, c, { defaultValue: 0 });
  }
}
export {
  M as default
};
