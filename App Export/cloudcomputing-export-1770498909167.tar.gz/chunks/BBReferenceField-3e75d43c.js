import { S as R, i as h, s as b, bL as o, c as y, m as V, c7 as D, c8 as B, k as E, n as F, p as I, b2 as U, bM as m, ab as A } from "./index-e79f0bb2.js";
import C from "./RelationshipField-c09d9c4a.js";
import { c as S, g as d } from "./users-b6137f6b.js";
import "./Multiselect-9dd507ef.js";
import "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function T(l) {
  let t, i;
  const u = [
    /*allProps*/
    l[3],
    { type: (
      /*type*/
      l[0]
    ) },
    { datasourceType: "user" },
    { primaryDisplay: "email" },
    {
      defaultValue: (
        /*updatedDefaultValue*/
        l[4]
      )
    },
    { defaultRows: (
      /*defaultRows*/
      l[2]
    ) },
    { multi: (
      /*multi*/
      l[1]
    ) }
  ];
  let s = {};
  for (let e = 0; e < u.length; e += 1)
    s = o(s, u[e]);
  return t = new C({ props: s }), t.$on(
    "rows",
    /*rows_handler*/
    l[6]
  ), {
    c() {
      y(t.$$.fragment);
    },
    m(e, n) {
      V(t, e, n), i = !0;
    },
    p(e, [n]) {
      const r = n & /*allProps, type, updatedDefaultValue, defaultRows, multi*/
      31 ? D(u, [
        n & /*allProps*/
        8 && B(
          /*allProps*/
          e[3]
        ),
        n & /*type*/
        1 && { type: (
          /*type*/
          e[0]
        ) },
        u[2],
        u[3],
        n & /*updatedDefaultValue*/
        16 && {
          defaultValue: (
            /*updatedDefaultValue*/
            e[4]
          )
        },
        n & /*defaultRows*/
        4 && { defaultRows: (
          /*defaultRows*/
          e[2]
        ) },
        n & /*multi*/
        2 && { multi: (
          /*multi*/
          e[1]
        ) }
      ]) : {};
      t.$set(r);
    },
    i(e) {
      i || (E(t.$$.fragment, e), i = !0);
    },
    o(e) {
      F(t.$$.fragment, e), i = !1;
    },
    d(e) {
      I(t, e);
    }
  };
}
function j(l, t, i) {
  let u, s, { defaultValue: e } = t, { type: n = U.BB_REFERENCE } = t, { multi: r = void 0 } = t, { defaultRows: f = [] } = t;
  function c(a) {
    return Array.isArray(a) ? a.map((g) => d(g)) : d(a);
  }
  function p(a) {
    return S(a) ? c(a) : a;
  }
  function _(a) {
    A.call(this, l, a);
  }
  return l.$$set = (a) => {
    i(9, t = o(o({}, t), m(a))), "defaultValue" in a && i(5, e = a.defaultValue), "type" in a && i(0, n = a.type), "multi" in a && i(1, r = a.multi), "defaultRows" in a && i(2, f = a.defaultRows);
  }, l.$$.update = () => {
    l.$$.dirty & /*defaultValue*/
    32 && i(4, u = p(e)), i(3, s = t);
  }, t = m(t), [
    n,
    r,
    f,
    s,
    u,
    e,
    _
  ];
}
class P extends R {
  constructor(t) {
    super(), h(this, t, j, T, b, {
      defaultValue: 5,
      type: 0,
      multi: 1,
      defaultRows: 2
    });
  }
}
export {
  P as default
};
