import { S as te, i as oe, s as ne, y as G, f as C, z as y, n as m, A as F, k as c, o as T, u as R, v as le, c as g, m as k, B as me, p, M as h, ac as be, ai as de, aj as _e, a as N, N as J, e as ge, b as ke, d as K, O as pe, cd as he, aT as Q } from "./index-e79f0bb2.js";
import { F as we, a as Ce } from "./FormBlockComponent-46c07230.js";
import Te from "./Placeholder-527c0fd1.js";
function X(s, e, o) {
  const t = s.slice();
  return t[17] = e[o], t[19] = o, t;
}
function Be(s) {
  let e, o;
  return e = new Te({
    props: {
      text: "Choose your table and add some fields to your form to get started"
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, i) {
      k(e, t, i), o = !0;
    },
    p: me,
    i(t) {
      o || (c(e.$$.fragment, t), o = !0);
    },
    o(t) {
      m(e.$$.fragment, t), o = !1;
    },
    d(t) {
      p(e, t);
    }
  };
}
function Se(s) {
  let e, o, t;
  function i(n) {
    s[16](n);
  }
  let l = {
    type: "form",
    props: {
      actionType: (
        /*actionType*/
        s[1] === "Create" ? "Create" : "Update"
      ),
      dataSource: (
        /*dataSource*/
        s[0]
      ),
      size: (
        /*size*/
        s[2]
      ),
      disabled: (
        /*disabled*/
        s[3]
      ),
      readonly: !/*disabled*/
      s[3] && /*actionType*/
      s[1] === "View"
    },
    styles: {
      normal: {
        width: "600px",
        "margin-left": "auto",
        "margin-right": "auto"
      }
    },
    context: "form",
    $$slots: { default: [Pe] },
    $$scope: { ctx: s }
  };
  return (
    /*formId*/
    s[12] !== void 0 && (l.id = /*formId*/
    s[12]), e = new h({ props: l }), be.push(() => de(e, "id", i)), {
      c() {
        g(e.$$.fragment);
      },
      m(n, r) {
        k(e, n, r), t = !0;
      },
      p(n, r) {
        const f = {};
        r & /*actionType, dataSource, size, disabled*/
        15 && (f.props = {
          actionType: (
            /*actionType*/
            n[1] === "Create" ? "Create" : "Update"
          ),
          dataSource: (
            /*dataSource*/
            n[0]
          ),
          size: (
            /*size*/
            n[2]
          ),
          disabled: (
            /*disabled*/
            n[3]
          ),
          readonly: !/*disabled*/
          n[3] && /*actionType*/
          n[1] === "View"
        }), r & /*$$scope, buttons, buttonsCollapsed, buttonsCollapsedText, buttonPosition, $context, fields, schema, description, title, renderHeader*/
        1077232 && (f.$$scope = { dirty: r, ctx: n }), !o && r & /*formId*/
        4096 && (o = !0, f.id = /*formId*/
        n[12], _e(() => o = !1)), e.$set(f);
      },
      i(n) {
        t || (c(e.$$.fragment, n), t = !0);
      },
      o(n) {
        m(e.$$.fragment, n), t = !1;
      },
      d(n) {
        p(e, n);
      }
    }
  );
}
function Y(s) {
  let e, o;
  return e = new h({
    props: {
      type: "container",
      props: { direction: "column", gap: "S" },
      order: 0,
      $$slots: { default: [ye] },
      $$scope: { ctx: s }
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, i) {
      k(e, t, i), o = !0;
    },
    p(t, i) {
      const l = {};
      i & /*$$scope, buttons, buttonsCollapsed, buttonsCollapsedText, buttonPosition, title*/
      1050528 && (l.$$scope = { dirty: i, ctx: t }), e.$set(l);
    },
    i(t) {
      o || (c(e.$$.fragment, t), o = !0);
    },
    o(t) {
      m(e.$$.fragment, t), o = !1;
    },
    d(t) {
      p(e, t);
    }
  };
}
function Z(s) {
  let e, o;
  return e = new h({
    props: {
      type: "buttongroup",
      props: {
        buttons: (
          /*buttons*/
          s[7]
        ),
        collapsed: (
          /*buttonsCollapsed*/
          s[9]
        ),
        collapsedText: (
          /*buttonsCollapsedText*/
          s[10]
        )
      },
      order: 0
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, i) {
      k(e, t, i), o = !0;
    },
    p(t, i) {
      const l = {};
      i & /*buttons, buttonsCollapsed, buttonsCollapsedText*/
      1664 && (l.props = {
        buttons: (
          /*buttons*/
          t[7]
        ),
        collapsed: (
          /*buttonsCollapsed*/
          t[9]
        ),
        collapsedText: (
          /*buttonsCollapsedText*/
          t[10]
        )
      }), e.$set(l);
    },
    i(t) {
      o || (c(e.$$.fragment, t), o = !0);
    },
    o(t) {
      m(e.$$.fragment, t), o = !1;
    },
    d(t) {
      p(e, t);
    }
  };
}
function ze(s) {
  let e, o, t, i;
  e = new h({
    props: {
      type: "textv2",
      props: {
        text: (
          /*title*/
          s[5] ? `## ${/*title*/
          s[5]}` : ""
        )
      },
      order: 0
    }
  });
  let l = (
    /*buttonPosition*/
    s[8] === "top" && Z(s)
  );
  return {
    c() {
      g(e.$$.fragment), o = N(), l && l.c(), t = G();
    },
    m(n, r) {
      k(e, n, r), C(n, o, r), l && l.m(n, r), C(n, t, r), i = !0;
    },
    p(n, r) {
      const f = {};
      r & /*title*/
      32 && (f.props = {
        text: (
          /*title*/
          n[5] ? `## ${/*title*/
          n[5]}` : ""
        )
      }), e.$set(f), /*buttonPosition*/
      n[8] === "top" ? l ? (l.p(n, r), r & /*buttonPosition*/
      256 && c(l, 1)) : (l = Z(n), l.c(), c(l, 1), l.m(t.parentNode, t)) : l && (y(), m(l, 1, 1, () => {
        l = null;
      }), F());
    },
    i(n) {
      i || (c(e.$$.fragment, n), c(l), i = !0);
    },
    o(n) {
      m(e.$$.fragment, n), m(l), i = !1;
    },
    d(n) {
      n && (T(o), T(t)), p(e, n), l && l.d(n);
    }
  };
}
function ye(s) {
  let e, o;
  return e = new h({
    props: {
      type: "container",
      props: {
        direction: "row",
        hAlign: "stretch",
        vAlign: "center",
        gap: "M",
        wrap: !0
      },
      order: 0,
      $$slots: { default: [ze] },
      $$scope: { ctx: s }
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, i) {
      k(e, t, i), o = !0;
    },
    p(t, i) {
      const l = {};
      i & /*$$scope, buttons, buttonsCollapsed, buttonsCollapsedText, buttonPosition, title*/
      1050528 && (l.$$scope = { dirty: i, ctx: t }), e.$set(l);
    },
    i(t) {
      o || (c(e.$$.fragment, t), o = !0);
    },
    o(t) {
      m(e.$$.fragment, t), o = !1;
    },
    d(t) {
      p(e, t);
    }
  };
}
function x(s) {
  let e, o;
  return e = new h({
    props: {
      type: "textv2",
      props: { text: (
        /*description*/
        s[6]
      ) },
      order: 1
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, i) {
      k(e, t, i), o = !0;
    },
    p(t, i) {
      const l = {};
      i & /*description*/
      64 && (l.props = { text: (
        /*description*/
        t[6]
      ) }), e.$set(l);
    },
    i(t) {
      o || (c(e.$$.fragment, t), o = !0);
    },
    o(t) {
      m(e.$$.fragment, t), o = !1;
    },
    d(t) {
      p(e, t);
    }
  };
}
function $(s) {
  let e, o;
  return e = new we({
    props: {
      field: (
        /*field*/
        s[17]
      ),
      schema: (
        /*schema*/
        s[11]
      ),
      order: (
        /*idx*/
        s[19]
      )
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, i) {
      k(e, t, i), o = !0;
    },
    p(t, i) {
      const l = {};
      i & /*fields*/
      16 && (l.field = /*field*/
      t[17]), i & /*schema*/
      2048 && (l.schema = /*schema*/
      t[11]), e.$set(l);
    },
    i(t) {
      o || (c(e.$$.fragment, t), o = !0);
    },
    o(t) {
      m(e.$$.fragment, t), o = !1;
    },
    d(t) {
      p(e, t);
    }
  };
}
function Fe(s) {
  let e, o, t = J(
    /*fields*/
    s[4]
  ), i = [];
  for (let n = 0; n < t.length; n += 1)
    i[n] = $(X(s, t, n));
  const l = (n) => m(i[n], 1, 1, () => {
    i[n] = null;
  });
  return {
    c() {
      e = ge("div");
      for (let n = 0; n < i.length; n += 1)
        i[n].c();
      ke(e, "class", "form-block fields svelte-1gdgv0g"), K(
        e,
        "mobile",
        /*$context*/
        s[14].device.mobile
      );
    },
    m(n, r) {
      C(n, e, r);
      for (let f = 0; f < i.length; f += 1)
        i[f] && i[f].m(e, null);
      o = !0;
    },
    p(n, r) {
      if (r & /*fields, schema*/
      2064) {
        t = J(
          /*fields*/
          n[4]
        );
        let f;
        for (f = 0; f < t.length; f += 1) {
          const b = X(n, t, f);
          i[f] ? (i[f].p(b, r), c(i[f], 1)) : (i[f] = $(b), i[f].c(), c(i[f], 1), i[f].m(e, null));
        }
        for (y(), f = t.length; f < i.length; f += 1)
          l(f);
        F();
      }
      (!o || r & /*$context*/
      16384) && K(
        e,
        "mobile",
        /*$context*/
        n[14].device.mobile
      );
    },
    i(n) {
      if (!o) {
        for (let r = 0; r < t.length; r += 1)
          c(i[r]);
        o = !0;
      }
    },
    o(n) {
      i = i.filter(Boolean);
      for (let r = 0; r < i.length; r += 1)
        m(i[r]);
      o = !1;
    },
    d(n) {
      n && T(e), pe(i, n);
    }
  };
}
function De(s) {
  let e, o, t, i, l = (
    /*renderHeader*/
    s[13] && Y(s)
  ), n = (
    /*description*/
    s[6] && x(s)
  );
  return t = new h({
    props: {
      type: "container",
      $$slots: { default: [Fe] },
      $$scope: { ctx: s }
    }
  }), {
    c() {
      l && l.c(), e = N(), n && n.c(), o = N(), g(t.$$.fragment);
    },
    m(r, f) {
      l && l.m(r, f), C(r, e, f), n && n.m(r, f), C(r, o, f), k(t, r, f), i = !0;
    },
    p(r, f) {
      /*renderHeader*/
      r[13] ? l ? (l.p(r, f), f & /*renderHeader*/
      8192 && c(l, 1)) : (l = Y(r), l.c(), c(l, 1), l.m(e.parentNode, e)) : l && (y(), m(l, 1, 1, () => {
        l = null;
      }), F()), /*description*/
      r[6] ? n ? (n.p(r, f), f & /*description*/
      64 && c(n, 1)) : (n = x(r), n.c(), c(n, 1), n.m(o.parentNode, o)) : n && (y(), m(n, 1, 1, () => {
        n = null;
      }), F());
      const b = {};
      f & /*$$scope, $context, fields, schema*/
      1067024 && (b.$$scope = { dirty: f, ctx: r }), t.$set(b);
    },
    i(r) {
      i || (c(l), c(n), c(t.$$.fragment, r), i = !0);
    },
    o(r) {
      m(l), m(n), m(t.$$.fragment, r), i = !1;
    },
    d(r) {
      r && (T(e), T(o)), l && l.d(r), n && n.d(r), p(t, r);
    }
  };
}
function ee(s) {
  let e, o;
  return e = new h({
    props: {
      type: "buttongroup",
      props: {
        buttons: (
          /*buttons*/
          s[7]
        ),
        collapsed: (
          /*buttonsCollapsed*/
          s[9]
        ),
        collapsedText: (
          /*buttonsCollapsedText*/
          s[10]
        )
      },
      styles: { normal: { "margin-top": "24" } },
      order: 1
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, i) {
      k(e, t, i), o = !0;
    },
    p(t, i) {
      const l = {};
      i & /*buttons, buttonsCollapsed, buttonsCollapsedText*/
      1664 && (l.props = {
        buttons: (
          /*buttons*/
          t[7]
        ),
        collapsed: (
          /*buttonsCollapsed*/
          t[9]
        ),
        collapsedText: (
          /*buttonsCollapsedText*/
          t[10]
        )
      }), e.$set(l);
    },
    i(t) {
      o || (c(e.$$.fragment, t), o = !0);
    },
    o(t) {
      m(e.$$.fragment, t), o = !1;
    },
    d(t) {
      p(e, t);
    }
  };
}
function Pe(s) {
  let e, o, t, i;
  e = new h({
    props: {
      type: "container",
      props: {
        direction: "column",
        hAlign: "stretch",
        vAlign: "top",
        gap: "M"
      },
      $$slots: { default: [De] },
      $$scope: { ctx: s }
    }
  });
  let l = (
    /*buttonPosition*/
    s[8] === "bottom" && ee(s)
  );
  return {
    c() {
      g(e.$$.fragment), o = N(), l && l.c(), t = G();
    },
    m(n, r) {
      k(e, n, r), C(n, o, r), l && l.m(n, r), C(n, t, r), i = !0;
    },
    p(n, r) {
      const f = {};
      r & /*$$scope, $context, fields, schema, description, buttons, buttonsCollapsed, buttonsCollapsedText, buttonPosition, title, renderHeader*/
      1077232 && (f.$$scope = { dirty: r, ctx: n }), e.$set(f), /*buttonPosition*/
      n[8] === "bottom" ? l ? (l.p(n, r), r & /*buttonPosition*/
      256 && c(l, 1)) : (l = ee(n), l.c(), c(l, 1), l.m(t.parentNode, t)) : l && (y(), m(l, 1, 1, () => {
        l = null;
      }), F());
    },
    i(n) {
      i || (c(e.$$.fragment, n), c(l), i = !0);
    },
    o(n) {
      m(e.$$.fragment, n), m(l), i = !1;
    },
    d(n) {
      n && (T(o), T(t)), p(e, n), l && l.d(n);
    }
  };
}
function Ie(s) {
  let e, o, t, i;
  const l = [Se, Be], n = [];
  function r(f, b) {
    var _;
    return (
      /*fields*/
      (_ = f[4]) != null && _.length ? 0 : 1
    );
  }
  return e = r(s), o = n[e] = l[e](s), {
    c() {
      o.c(), t = G();
    },
    m(f, b) {
      n[e].m(f, b), C(f, t, b), i = !0;
    },
    p(f, [b]) {
      let _ = e;
      e = r(f), e === _ ? n[e].p(f, b) : (y(), m(n[_], 1, 1, () => {
        n[_] = null;
      }), F(), o = n[e], o ? o.p(f, b) : (o = n[e] = l[e](f), o.c()), c(o, 1), o.m(t.parentNode, t));
    },
    i(f) {
      i || (c(o), i = !0);
    },
    o(f) {
      m(o), i = !1;
    },
    d(f) {
      f && T(t), n[e].d(f);
    }
  };
}
function Me(s, e, o) {
  let t, i, { dataSource: l } = e, { actionType: n } = e, { size: r } = e, { disabled: f } = e, { fields: b } = e, { title: _ } = e, { description: D } = e, { buttons: B } = e, { buttonPosition: z = "bottom" } = e, { buttonsCollapsed: P } = e, { buttonsCollapsedText: I } = e, { schema: M } = e;
  const O = R("context");
  le(s, O, (u) => o(14, i = u));
  let S;
  function A(u) {
    S = u, o(12, S);
  }
  return s.$$set = (u) => {
    "dataSource" in u && o(0, l = u.dataSource), "actionType" in u && o(1, n = u.actionType), "size" in u && o(2, r = u.size), "disabled" in u && o(3, f = u.disabled), "fields" in u && o(4, b = u.fields), "title" in u && o(5, _ = u.title), "description" in u && o(6, D = u.description), "buttons" in u && o(7, B = u.buttons), "buttonPosition" in u && o(8, z = u.buttonPosition), "buttonsCollapsed" in u && o(9, P = u.buttonsCollapsed), "buttonsCollapsedText" in u && o(10, I = u.buttonsCollapsedText), "schema" in u && o(11, M = u.schema);
  }, s.$$.update = () => {
    s.$$.dirty & /*buttons, title*/
    160 && o(13, t = B || _);
  }, [
    l,
    n,
    r,
    f,
    b,
    _,
    D,
    B,
    z,
    P,
    I,
    M,
    S,
    t,
    i,
    O,
    A
  ];
}
class Oe extends te {
  constructor(e) {
    super(), oe(this, e, Me, Ie, ne, {
      dataSource: 0,
      actionType: 1,
      size: 2,
      disabled: 3,
      fields: 4,
      title: 5,
      description: 6,
      buttons: 7,
      buttonPosition: 8,
      buttonsCollapsed: 9,
      buttonsCollapsedText: 10,
      schema: 11
    });
  }
}
function Ae(s) {
  let e, o;
  return e = new Oe({
    props: {
      dataSource: (
        /*dataSource*/
        s[1]
      ),
      actionType: (
        /*actionType*/
        s[0]
      ),
      size: (
        /*size*/
        s[2]
      ),
      disabled: (
        /*disabled*/
        s[3]
      ),
      fields: (
        /*fieldsOrDefault*/
        s[14]
      ),
      title: (
        /*title*/
        s[6]
      ),
      description: (
        /*description*/
        s[7]
      ),
      schema: (
        /*schema*/
        s[12]
      ),
      buttons: (
        /*buttonsOrDefault*/
        s[13]
      ),
      buttonPosition: (
        /*buttons*/
        s[4] ? (
          /*buttonPosition*/
          s[5]
        ) : "top"
      ),
      buttonsCollapsed: (
        /*buttonsCollapsed*/
        s[10]
      ),
      buttonsCollapsedText: (
        /*buttonsCollapsedText*/
        s[11]
      )
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, i) {
      k(e, t, i), o = !0;
    },
    p(t, i) {
      const l = {};
      i[0] & /*dataSource*/
      2 && (l.dataSource = /*dataSource*/
      t[1]), i[0] & /*actionType*/
      1 && (l.actionType = /*actionType*/
      t[0]), i[0] & /*size*/
      4 && (l.size = /*size*/
      t[2]), i[0] & /*disabled*/
      8 && (l.disabled = /*disabled*/
      t[3]), i[0] & /*fieldsOrDefault*/
      16384 && (l.fields = /*fieldsOrDefault*/
      t[14]), i[0] & /*title*/
      64 && (l.title = /*title*/
      t[6]), i[0] & /*description*/
      128 && (l.description = /*description*/
      t[7]), i[0] & /*schema*/
      4096 && (l.schema = /*schema*/
      t[12]), i[0] & /*buttonsOrDefault*/
      8192 && (l.buttons = /*buttonsOrDefault*/
      t[13]), i[0] & /*buttons, buttonPosition*/
      48 && (l.buttonPosition = /*buttons*/
      t[4] ? (
        /*buttonPosition*/
        t[5]
      ) : "top"), i[0] & /*buttonsCollapsed*/
      1024 && (l.buttonsCollapsed = /*buttonsCollapsed*/
      t[10]), i[0] & /*buttonsCollapsedText*/
      2048 && (l.buttonsCollapsedText = /*buttonsCollapsedText*/
      t[11]), e.$set(l);
    },
    i(t) {
      o || (c(e.$$.fragment, t), o = !0);
    },
    o(t) {
      m(e.$$.fragment, t), o = !1;
    },
    d(t) {
      p(e, t);
    }
  };
}
function Le(s) {
  let e, o;
  return e = new Ce({
    props: {
      actionType: (
        /*actionType*/
        s[0]
      ),
      dataSource: (
        /*dataSource*/
        s[1]
      ),
      rowId: (
        /*rowId*/
        s[8]
      ),
      noRowsMessage: (
        /*noRowsMessage*/
        s[9]
      ),
      $$slots: { default: [Ae] },
      $$scope: { ctx: s }
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, i) {
      k(e, t, i), o = !0;
    },
    p(t, i) {
      const l = {};
      i[0] & /*actionType*/
      1 && (l.actionType = /*actionType*/
      t[0]), i[0] & /*dataSource*/
      2 && (l.dataSource = /*dataSource*/
      t[1]), i[0] & /*rowId*/
      256 && (l.rowId = /*rowId*/
      t[8]), i[0] & /*noRowsMessage*/
      512 && (l.noRowsMessage = /*noRowsMessage*/
      t[9]), i[0] & /*dataSource, actionType, size, disabled, fieldsOrDefault, title, description, schema, buttonsOrDefault, buttons, buttonPosition, buttonsCollapsed, buttonsCollapsedText*/
      31999 | i[1] & /*$$scope*/
      4 && (l.$$scope = { dirty: i, ctx: t }), e.$set(l);
    },
    i(t) {
      o || (c(e.$$.fragment, t), o = !0);
    },
    o(t) {
      m(e.$$.fragment, t), o = !1;
    },
    d(t) {
      p(e, t);
    }
  };
}
function Re(s, e, o) {
  let t, i, l, n, r, { actionType: f } = e, { dataSource: b } = e, { size: _ } = e, { disabled: D } = e, { fields: B } = e, { buttons: z } = e, { buttonPosition: P } = e, { title: I } = e, { description: M } = e, { rowId: O } = e, { actionUrl: S } = e, { noRowsMessage: A } = e, { notificationOverride: u } = e, { buttonsCollapsed: H } = e, { buttonsCollapsedText: W } = e, { showDeleteButton: U } = e, { showSaveButton: j } = e, { saveButtonLabel: V } = e, { deleteButtonLabel: q } = e;
  const { fetchDatasourceSchema: ie, generateGoldenSample: se } = R("sdk"), v = R("component");
  le(s, v, (a) => o(26, r = a));
  const re = R("context");
  let E;
  const fe = () => {
    var w;
    const a = Q(v).id, d = ((w = Q(re)[`${a}-provider`]) == null ? void 0 : w.rows) || [], L = se(d);
    return { [`${a}-repeater`]: L };
  }, ae = (a) => a ? a.map((d) => typeof d == "string" ? { name: d, active: !0 } : {
    ...d,
    active: typeof (d == null ? void 0 : d.active) != "boolean" ? !0 : d == null ? void 0 : d.active
  }) : [], ue = (a, d) => {
    if (!d)
      return [];
    let L = [];
    return (!a || a.length === 0) && Object.values(d).filter((w) => !w.autocolumn).forEach((w) => {
      L.push({ name: w.name, active: !0 });
    }), [...a, ...L].filter((w) => w.active);
  }, ce = async (a) => {
    o(12, E = await ie(a) || {});
  };
  return s.$$set = (a) => {
    "actionType" in a && o(0, f = a.actionType), "dataSource" in a && o(1, b = a.dataSource), "size" in a && o(2, _ = a.size), "disabled" in a && o(3, D = a.disabled), "fields" in a && o(16, B = a.fields), "buttons" in a && o(4, z = a.buttons), "buttonPosition" in a && o(5, P = a.buttonPosition), "title" in a && o(6, I = a.title), "description" in a && o(7, M = a.description), "rowId" in a && o(8, O = a.rowId), "actionUrl" in a && o(17, S = a.actionUrl), "noRowsMessage" in a && o(9, A = a.noRowsMessage), "notificationOverride" in a && o(18, u = a.notificationOverride), "buttonsCollapsed" in a && o(10, H = a.buttonsCollapsed), "buttonsCollapsedText" in a && o(11, W = a.buttonsCollapsedText), "showDeleteButton" in a && o(19, U = a.showDeleteButton), "showSaveButton" in a && o(20, j = a.showSaveButton), "saveButtonLabel" in a && o(21, V = a.saveButtonLabel), "deleteButtonLabel" in a && o(22, q = a.deleteButtonLabel);
  }, s.$$.update = () => {
    s.$$.dirty[0] & /*dataSource*/
    2 && ce(b), s.$$.dirty[0] & /*$component*/
    67108864 && o(24, t = r.id), s.$$.dirty[0] & /*fields*/
    65536 && o(25, i = ae(B)), s.$$.dirty[0] & /*formattedFields, schema*/
    33558528 && o(14, l = ue(i, E)), s.$$.dirty[0] & /*buttons, id, showDeleteButton, showSaveButton, saveButtonLabel, deleteButtonLabel, notificationOverride, actionType, actionUrl, dataSource*/
    25034771 && o(13, n = z || he({
      _id: t,
      showDeleteButton: U,
      showSaveButton: j,
      saveButtonLabel: V,
      deleteButtonLabel: q,
      notificationOverride: u,
      actionType: f,
      actionUrl: S,
      dataSource: b
    }));
  }, [
    f,
    b,
    _,
    D,
    z,
    P,
    I,
    M,
    O,
    A,
    H,
    W,
    E,
    n,
    l,
    v,
    B,
    S,
    u,
    U,
    j,
    V,
    q,
    fe,
    t,
    i,
    r
  ];
}
class Ve extends te {
  constructor(e) {
    super(), oe(
      this,
      e,
      Re,
      Le,
      ne,
      {
        actionType: 0,
        dataSource: 1,
        size: 2,
        disabled: 3,
        fields: 16,
        buttons: 4,
        buttonPosition: 5,
        title: 6,
        description: 7,
        rowId: 8,
        actionUrl: 17,
        noRowsMessage: 9,
        notificationOverride: 18,
        buttonsCollapsed: 10,
        buttonsCollapsedText: 11,
        showDeleteButton: 19,
        showSaveButton: 20,
        saveButtonLabel: 21,
        deleteButtonLabel: 22,
        getAdditionalDataContext: 23
      },
      null,
      [-1, -1]
    );
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[23];
  }
}
export {
  Ve as default
};
