import { S as Z, i as x, s as $, e as p, b as N, d as T, aD as O, f as b, g as F, q as ee, h as te, B as D, o as y, u as A, v as le, x as se, cM as ie, N as m, a as ne, y as J, O as q, t as K, j as L, C as ce, D as oe } from "./index-e79f0bb2.js";
function B(o, n, t) {
  const s = o.slice();
  return s[19] = n[t], s;
}
function E(o, n, t) {
  const s = o.slice();
  return s[22] = n[t], s;
}
function I(o, n, t) {
  const s = o.slice();
  return s[22] = n[t], s;
}
function M(o) {
  let n, t, s = m(Object.keys(
    /*schema*/
    o[0]
  )), e = [];
  for (let i = 0; i < s.length; i += 1)
    e[i] = Q(I(o, s, i));
  let a = m(
    /*stringifiedRows*/
    o[2]
  ), l = [];
  for (let i = 0; i < a.length; i += 1)
    l[i] = H(B(o, a, i));
  return {
    c() {
      for (let i = 0; i < e.length; i += 1)
        e[i].c();
      n = ne();
      for (let i = 0; i < l.length; i += 1)
        l[i].c();
      t = J();
    },
    m(i, f) {
      for (let c = 0; c < e.length; c += 1)
        e[c] && e[c].m(i, f);
      b(i, n, f);
      for (let c = 0; c < l.length; c += 1)
        l[c] && l[c].m(i, f);
      b(i, t, f);
    },
    p(i, f) {
      if (f & /*schema, Object*/
      1) {
        s = m(Object.keys(
          /*schema*/
          i[0]
        ));
        let c;
        for (c = 0; c < s.length; c += 1) {
          const u = I(i, s, c);
          e[c] ? e[c].p(u, f) : (e[c] = Q(u), e[c].c(), e[c].m(n.parentNode, n));
        }
        for (; c < e.length; c += 1)
          e[c].d(1);
        e.length = s.length;
      }
      if (f & /*Object, schema, stringifiedRows*/
      5) {
        a = m(
          /*stringifiedRows*/
          i[2]
        );
        let c;
        for (c = 0; c < a.length; c += 1) {
          const u = B(i, a, c);
          l[c] ? l[c].p(u, f) : (l[c] = H(u), l[c].c(), l[c].m(t.parentNode, t));
        }
        for (; c < l.length; c += 1)
          l[c].d(1);
        l.length = a.length;
      }
    },
    d(i) {
      i && (y(n), y(t)), q(e, i), q(l, i);
    }
  };
}
function Q(o) {
  let n, t = (
    /*schema*/
    o[0][
      /*col*/
      o[22]
    ].displayName + ""
  ), s;
  return {
    c() {
      n = p("div"), s = K(t), N(n, "class", "cell header svelte-y4fs9");
    },
    m(e, a) {
      b(e, n, a), F(n, s);
    },
    p(e, a) {
      a & /*schema*/
      1 && t !== (t = /*schema*/
      e[0][
        /*col*/
        e[22]
      ].displayName + "") && L(s, t);
    },
    d(e) {
      e && y(n);
    }
  };
}
function G(o) {
  let n, t = (
    /*row*/
    o[19][
      /*col*/
      o[22]
    ] + ""
  ), s;
  return {
    c() {
      n = p("div"), s = K(t), N(n, "class", "cell svelte-y4fs9");
    },
    m(e, a) {
      b(e, n, a), F(n, s);
    },
    p(e, a) {
      a & /*stringifiedRows, schema*/
      5 && t !== (t = /*row*/
      e[19][
        /*col*/
        e[22]
      ] + "") && L(s, t);
    },
    d(e) {
      e && y(n);
    }
  };
}
function H(o) {
  let n, t = m(Object.keys(
    /*schema*/
    o[0]
  )), s = [];
  for (let e = 0; e < t.length; e += 1)
    s[e] = G(E(o, t, e));
  return {
    c() {
      for (let e = 0; e < s.length; e += 1)
        s[e].c();
      n = J();
    },
    m(e, a) {
      for (let l = 0; l < s.length; l += 1)
        s[l] && s[l].m(e, a);
      b(e, n, a);
    },
    p(e, a) {
      if (a & /*stringifiedRows, Object, schema*/
      5) {
        t = m(Object.keys(
          /*schema*/
          e[0]
        ));
        let l;
        for (l = 0; l < t.length; l += 1) {
          const i = E(e, t, l);
          s[l] ? s[l].p(i, a) : (s[l] = G(i), s[l].c(), s[l].m(n.parentNode, n));
        }
        for (; l < s.length; l += 1)
          s[l].d(1);
        s.length = t.length;
      }
    },
    d(e) {
      e && y(n), q(s, e);
    }
  };
}
function ae(o) {
  let n, t, s, e, a, l = (
    /*schema*/
    o[0] && M(o)
  );
  return {
    c() {
      n = p("div"), t = p("div"), l && l.c(), N(t, "class", "table svelte-y4fs9"), T(t, "valid", !!/*schema*/
      o[0]), N(n, "class", "vars svelte-y4fs9"), O(
        n,
        "--cols",
        /*columnCount*/
        o[4]
      ), O(
        n,
        "--rows",
        /*rowCount*/
        o[3]
      );
    },
    m(i, f) {
      b(i, n, f), F(n, t), l && l.m(t, null), e || (a = ee(s = /*styleable*/
      o[7].call(
        null,
        t,
        /*$component*/
        o[5].styles
      )), e = !0);
    },
    p(i, [f]) {
      /*schema*/
      i[0] ? l ? l.p(i, f) : (l = M(i), l.c(), l.m(t, null)) : l && (l.d(1), l = null), s && te(s.update) && f & /*$component*/
      32 && s.update.call(
        null,
        /*$component*/
        i[5].styles
      ), f & /*schema*/
      1 && T(t, "valid", !!/*schema*/
      i[0]), f & /*columnCount*/
      16 && O(
        n,
        "--cols",
        /*columnCount*/
        i[4]
      ), f & /*rowCount*/
      8 && O(
        n,
        "--rows",
        /*rowCount*/
        i[3]
      );
    },
    i: D,
    o: D,
    d(i) {
      i && y(n), l && l.d(), e = !1, a();
    }
  };
}
function re(o, n, t) {
  let s, e, a, l, i, f, c, u = D, U = () => (u(), u = ce(e, (r) => t(15, c = r)), e), P;
  o.$$.on_destroy.push(() => u());
  let { datasource: C } = n, { filter: j = void 0 } = n, { sortColumn: g = void 0 } = n, { sortOrder: v = void 0 } = n, { columns: w = void 0 } = n, { limit: k = 20 } = n;
  const z = A("component");
  le(o, z, (r) => t(5, P = r));
  const { styleable: V, API: W } = A("sdk"), X = (r) => oe({
    API: W,
    datasource: r,
    options: {
      query: s,
      sortColumn: g,
      sortOrder: v,
      limit: k,
      paginate: !1
    }
  }), Y = (r, h) => {
    if (!r)
      return {};
    let d = {};
    Object.entries(r).forEach(([_, S]) => {
      S.visible !== !1 && (d[_] = { ...S, displayName: _ });
    }), h != null && h.length || (h = Object.values(d).slice(0, 3));
    let R = {};
    for (let _ of h)
      d[_.name] && (R[_.name] = {
        ...d[_.name],
        displayName: _.displayName || d[_.name].displayName
      });
    return d = R, d;
  };
  return o.$$set = (r) => {
    "datasource" in r && t(8, C = r.datasource), "filter" in r && t(9, j = r.filter), "sortColumn" in r && t(10, g = r.sortColumn), "sortOrder" in r && t(11, v = r.sortOrder), "columns" in r && t(12, w = r.columns), "limit" in r && t(13, k = r.limit);
  }, o.$$.update = () => {
    var r;
    o.$$.dirty & /*filter*/
    512 && t(14, s = se(j)), o.$$.dirty & /*datasource*/
    256 && U(t(1, e = X(C))), o.$$.dirty & /*fetch, query, sortColumn, sortOrder, limit*/
    27650 && e.update({ query: s, sortColumn: g, sortOrder: v, limit: k }), o.$$.dirty & /*$fetch, columns*/
    36864 && t(0, a = Y(c.schema, w)), o.$$.dirty & /*schema*/
    1 && t(4, l = Object.keys(a).length), o.$$.dirty & /*$fetch*/
    32768 && t(3, i = ((r = c.rows) == null ? void 0 : r.length) || 0), o.$$.dirty & /*$fetch, schema*/
    32769 && t(2, f = ((c == null ? void 0 : c.rows) || []).map((h) => ie(h, a)));
  }, [
    a,
    e,
    f,
    i,
    l,
    P,
    z,
    V,
    C,
    j,
    g,
    v,
    w,
    k,
    s,
    c
  ];
}
class ue extends Z {
  constructor(n) {
    super(), x(this, n, re, ae, $, {
      datasource: 8,
      filter: 9,
      sortColumn: 10,
      sortOrder: 11,
      columns: 12,
      limit: 13
    });
  }
}
export {
  ue as default
};
