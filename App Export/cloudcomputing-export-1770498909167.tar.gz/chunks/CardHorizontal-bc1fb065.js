import { S as J, i as K, s as L, e as h, a as S, t as j, b as g, aD as c, f as F, g as s, q as A, j as w, h as M, B, o as G, r as O, u as D, v as P, aA as I } from "./index-e79f0bb2.js";
function E(t) {
  let e, i;
  return {
    c() {
      e = h("img"), c(
        e,
        "--imageWidth",
        /*imageWidth*/
        t[9]
      ), c(
        e,
        "--imageHeight",
        /*imageHeight*/
        t[10]
      ), g(e, "class", "image svelte-140q71n"), I(e.src, i = /*imageUrl*/
      t[0]) || g(e, "src", i), g(e, "alt", "");
    },
    m(n, o) {
      F(n, e, o);
    },
    p(n, o) {
      o & /*imageWidth*/
      512 && c(
        e,
        "--imageWidth",
        /*imageWidth*/
        n[9]
      ), o & /*imageHeight*/
      1024 && c(
        e,
        "--imageHeight",
        /*imageHeight*/
        n[10]
      ), o & /*imageUrl*/
      1 && !I(e.src, i = /*imageUrl*/
      n[0]) && g(e, "src", i);
    },
    d(n) {
      n && G(e);
    }
  };
}
function Q(t) {
  let e, i, n, o, H, U, T, b, d, N, u, k, v, z, f, W, _, C, q, l, m = (
    /*showImage*/
    t[11] && E(t)
  );
  return {
    c() {
      e = h("div"), m && m.c(), i = S(), n = h("div"), o = h("main"), H = h("h2"), U = j(
        /*heading*/
        t[1]
      ), T = S(), b = h("p"), d = j(
        /*description*/
        t[2]
      ), N = S(), u = h("footer"), k = h("p"), v = j(
        /*subtext*/
        t[3]
      ), z = S(), f = h("a"), W = j(
        /*linkText*/
        t[4]
      ), g(H, "class", "heading svelte-140q71n"), g(b, "class", "text svelte-140q71n"), g(k, "class", "subtext svelte-140q71n"), c(
        f,
        "--linkColor",
        /*linkColor*/
        t[6]
      ), c(
        f,
        "--linkHoverColor",
        /*linkHoverColor*/
        t[7]
      ), g(f, "href", _ = /*linkUrl*/
      t[5] || "/"), g(f, "class", "svelte-140q71n"), g(u, "class", "svelte-140q71n"), g(n, "class", "content svelte-140q71n"), g(e, "class", "container svelte-140q71n"), c(
        e,
        "--cardWidth",
        /*cardWidth*/
        t[8]
      );
    },
    m(a, r) {
      F(a, e, r), m && m.m(e, null), s(e, i), s(e, n), s(n, o), s(o, H), s(H, U), s(o, T), s(o, b), s(b, d), s(n, N), s(n, u), s(u, k), s(k, v), s(u, z), s(u, f), s(f, W), q || (l = [
        A(
          /*linkable*/
          t[14].call(null, f)
        ),
        A(C = /*styleable*/
        t[13].call(
          null,
          e,
          /*$component*/
          t[12].styles
        ))
      ], q = !0);
    },
    p(a, [r]) {
      /*showImage*/
      a[11] ? m ? m.p(a, r) : (m = E(a), m.c(), m.m(e, i)) : m && (m.d(1), m = null), r & /*heading*/
      2 && w(
        U,
        /*heading*/
        a[1]
      ), r & /*description*/
      4 && w(
        d,
        /*description*/
        a[2]
      ), r & /*subtext*/
      8 && w(
        v,
        /*subtext*/
        a[3]
      ), r & /*linkText*/
      16 && w(
        W,
        /*linkText*/
        a[4]
      ), r & /*linkColor*/
      64 && c(
        f,
        "--linkColor",
        /*linkColor*/
        a[6]
      ), r & /*linkHoverColor*/
      128 && c(
        f,
        "--linkHoverColor",
        /*linkHoverColor*/
        a[7]
      ), r & /*linkUrl*/
      32 && _ !== (_ = /*linkUrl*/
      a[5] || "/") && g(f, "href", _), r & /*cardWidth*/
      256 && c(
        e,
        "--cardWidth",
        /*cardWidth*/
        a[8]
      ), C && M(C.update) && r & /*$component*/
      4096 && C.update.call(
        null,
        /*$component*/
        a[12].styles
      );
    },
    i: B,
    o: B,
    d(a) {
      a && G(e), m && m.d(), q = !1, O(l);
    }
  };
}
function R(t, e, i) {
  let n, o;
  const { styleable: H, linkable: U } = D("sdk"), T = D("component");
  P(t, T, (l) => i(12, o = l));
  const b = "";
  let { imageUrl: d = "" } = e, { heading: N = "" } = e, { description: u = "" } = e, { subtext: k = "" } = e, { linkText: v = "" } = e, { linkUrl: z } = e, { linkColor: f } = e, { linkHoverColor: W } = e, { cardWidth: _ } = e, { imageWidth: C } = e, { imageHeight: q } = e;
  return t.$$set = (l) => {
    "imageUrl" in l && i(0, d = l.imageUrl), "heading" in l && i(1, N = l.heading), "description" in l && i(2, u = l.description), "subtext" in l && i(3, k = l.subtext), "linkText" in l && i(4, v = l.linkText), "linkUrl" in l && i(5, z = l.linkUrl), "linkColor" in l && i(6, f = l.linkColor), "linkHoverColor" in l && i(7, W = l.linkHoverColor), "cardWidth" in l && i(8, _ = l.cardWidth), "imageWidth" in l && i(9, C = l.imageWidth), "imageHeight" in l && i(10, q = l.imageHeight);
  }, t.$$.update = () => {
    t.$$.dirty & /*imageUrl*/
    1 && i(11, n = !!d);
  }, [
    d,
    N,
    u,
    k,
    v,
    z,
    f,
    W,
    _,
    C,
    q,
    n,
    o,
    H,
    U,
    T,
    b
  ];
}
class X extends J {
  constructor(e) {
    super(), K(this, e, R, Q, L, {
      className: 16,
      imageUrl: 0,
      heading: 1,
      description: 2,
      subtext: 3,
      linkText: 4,
      linkUrl: 5,
      linkColor: 6,
      linkHoverColor: 7,
      cardWidth: 8,
      imageWidth: 9,
      imageHeight: 10
    });
  }
  get className() {
    return this.$$.ctx[16];
  }
}
export {
  X as default
};
