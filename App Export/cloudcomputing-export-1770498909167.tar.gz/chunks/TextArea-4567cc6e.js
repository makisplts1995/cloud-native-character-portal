import { S as z, i as I, s as K, F as L, e as P, a as M, b as r, d as H, f as Q, g as E, l as C, G as R, H as U, J as W, k as X, n as Y, o as Z, r as p, ae as x, ab as F, ac as $ } from "./index-e79f0bb2.js";
function ee(t) {
  let i, e, o, d, c, m, h, a, g, _;
  const b = (
    /*#slots*/
    t[20].default
  ), u = L(
    b,
    t,
    /*$$scope*/
    t[19],
    null
  );
  return {
    c() {
      i = P("div"), e = P("textarea"), m = M(), u && u.c(), r(e, "placeholder", o = /*placeholder*/
      t[1] || ""), r(e, "class", "spectrum-Textfield-input svelte-1kmb9uq"), r(e, "style", d = /*align*/
      t[5] ? `text-align: ${/*align*/
      t[5]}` : ""), e.disabled = /*disabled*/
      t[2], e.readOnly = /*readonly*/
      t[3], r(
        e,
        "id",
        /*id*/
        t[4]
      ), e.value = c = /*value*/
      t[0] || "", r(i, "style", h = `${/*heightString*/
      t[9]}${/*minHeightString*/
      t[8]}`), r(i, "class", "spectrum-Textfield spectrum-Textfield--multiline svelte-1kmb9uq"), H(
        i,
        "is-disabled",
        /*disabled*/
        t[2]
      ), H(
        i,
        "is-focused",
        /*isFocused*/
        t[6]
      );
    },
    m(n, s) {
      Q(n, i, s), E(i, e), t[23](e), E(i, m), u && u.m(i, null), a = !0, g || (_ = [
        C(
          e,
          "input",
          /*onChange*/
          t[11]
        ),
        C(
          e,
          "focus",
          /*focus_handler*/
          t[24]
        ),
        C(
          e,
          "blur",
          /*onBlur*/
          t[10]
        ),
        C(
          e,
          "blur",
          /*blur_handler*/
          t[21]
        ),
        C(
          e,
          "keypress",
          /*keypress_handler*/
          t[22]
        )
      ], g = !0);
    },
    p(n, [s]) {
      (!a || s & /*placeholder*/
      2 && o !== (o = /*placeholder*/
      n[1] || "")) && r(e, "placeholder", o), (!a || s & /*align*/
      32 && d !== (d = /*align*/
      n[5] ? `text-align: ${/*align*/
      n[5]}` : "")) && r(e, "style", d), (!a || s & /*disabled*/
      4) && (e.disabled = /*disabled*/
      n[2]), (!a || s & /*readonly*/
      8) && (e.readOnly = /*readonly*/
      n[3]), (!a || s & /*id*/
      16) && r(
        e,
        "id",
        /*id*/
        n[4]
      ), (!a || s & /*value*/
      1 && c !== (c = /*value*/
      n[0] || "")) && (e.value = c), u && u.p && (!a || s & /*$$scope*/
      524288) && R(
        u,
        b,
        n,
        /*$$scope*/
        n[19],
        a ? W(
          b,
          /*$$scope*/
          n[19],
          s,
          null
        ) : U(
          /*$$scope*/
          n[19]
        ),
        null
      ), (!a || s & /*heightString, minHeightString*/
      768 && h !== (h = `${/*heightString*/
      n[9]}${/*minHeightString*/
      n[8]}`)) && r(i, "style", h), (!a || s & /*disabled*/
      4) && H(
        i,
        "is-disabled",
        /*disabled*/
        n[2]
      ), (!a || s & /*isFocused*/
      64) && H(
        i,
        "is-focused",
        /*isFocused*/
        n[6]
      );
    },
    i(n) {
      a || (X(u, n), a = !0);
    },
    o(n) {
      Y(u, n), a = !1;
    },
    d(n) {
      n && Z(i), t[23](null), u && u.d(n), g = !1, p(_);
    }
  };
}
function te(t, i, e) {
  let o, d, { $$slots: c = {}, $$scope: m } = i, { value: h = "" } = i, { placeholder: a = void 0 } = i, { disabled: g = !1 } = i, { readonly: _ = !1 } = i, { id: b = void 0 } = i, { height: u = void 0 } = i, { minHeight: n = void 0 } = i, { align: s = null } = i, { updateOnChange: S = !1 } = i;
  const N = () => ({
    start: f.selectionStart,
    end: f.selectionEnd
  }), T = x();
  let k = !1, f, O = !1;
  function A() {
    f.focus();
  }
  function B() {
    return f.value;
  }
  const D = () => {
    e(6, k = !1), v();
  }, G = () => {
    e(18, O = f.clientHeight < f.scrollHeight), S && v();
  }, v = () => {
    _ || g || T("change", f.value);
  }, q = (l, y) => y == null ? "" : typeof y != "number" || isNaN(y) ? `${l}:${y};` : `${l}:${y}px;`;
  function J(l) {
    F.call(this, t, l);
  }
  function V(l) {
    F.call(this, t, l);
  }
  function j(l) {
    $[l ? "unshift" : "push"](() => {
      f = l, e(7, f);
    });
  }
  const w = () => e(6, k = !0);
  return t.$$set = (l) => {
    "value" in l && e(0, h = l.value), "placeholder" in l && e(1, a = l.placeholder), "disabled" in l && e(2, g = l.disabled), "readonly" in l && e(3, _ = l.readonly), "id" in l && e(4, b = l.id), "height" in l && e(12, u = l.height), "minHeight" in l && e(13, n = l.minHeight), "align" in l && e(5, s = l.align), "updateOnChange" in l && e(14, S = l.updateOnChange), "$$scope" in l && e(19, m = l.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty & /*height*/
    4096 && e(9, o = q("height", u)), t.$$.dirty & /*minHeight*/
    8192 && e(8, d = q("min-height", n)), t.$$.dirty & /*scrollable*/
    262144 && T("scrollable", O);
  }, [
    h,
    a,
    g,
    _,
    b,
    s,
    k,
    f,
    d,
    o,
    D,
    G,
    u,
    n,
    S,
    N,
    A,
    B,
    O,
    m,
    c,
    J,
    V,
    j,
    w
  ];
}
class ne extends z {
  constructor(i) {
    super(), I(this, i, te, ee, K, {
      value: 0,
      placeholder: 1,
      disabled: 2,
      readonly: 3,
      id: 4,
      height: 12,
      minHeight: 13,
      align: 5,
      updateOnChange: 14,
      getCaretPosition: 15,
      focus: 16,
      contents: 17
    });
  }
  get getCaretPosition() {
    return this.$$.ctx[15];
  }
  get focus() {
    return this.$$.ctx[16];
  }
  get contents() {
    return this.$$.ctx[17];
  }
}
export {
  ne as T
};
