import { S as He, i as Ve, s as je, y as v, f as S, k as c, z as R, n as m, A as y, o as P, u as $, v as Ee, cb as Ke, cc as T, K as We, c as g, m as w, p as h, M as B, ac as M, ai as z, aj as F, aT as Ge, a as N, cd as j, N as ke, ce as Je, cf as Qe } from "./index-e79f0bb2.js";
import { e as Xe, a as Ye } from "./blocks-74fe5821.js";
function ge(o, e, n) {
  const t = o.slice();
  return t[60] = e[n], t[62] = n, t;
}
function we(o) {
  let e, n;
  return e = new We({
    props: {
      $$slots: { default: [ot] },
      $$scope: { ctx: o }
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, r) {
      w(e, t, r), n = !0;
    },
    p(t, r) {
      const l = {};
      r[0] & /*dataSource, size, formId, newRowSidePanelId, notificationOverride, sidePanelFields, normalFields, showTitleButton, titleButtonClickBehaviour, detailsSidePanelId, sidePanelSaveLabel, detailsFormBlockId, clickBehaviour, sortColumn, primaryDisplay, sortOrder, paginate, rowCount, autoRefresh, dataProviderId, tableColumns, quiet, compact, allowSelectRows, rowClickActions, noRowsMessage, buttonClickActions, titleButtonText, enrichedSearchColumns, title*/
      2013265919 | r[1] & /*id, deleteLabel, editTitle, enrichedFilter*/
      15 | r[2] & /*$$scope*/
      2 && (l.$$scope = { dirty: r, ctx: t }), e.$set(l);
    },
    i(t) {
      n || (c(e.$$.fragment, t), n = !0);
    },
    o(t) {
      m(e.$$.fragment, t), n = !1;
    },
    d(t) {
      h(e, t);
    }
  };
}
function he(o) {
  let e, n;
  return e = new B({
    props: {
      type: "container",
      props: {
        direction: "row",
        hAlign: "stretch",
        vAlign: "middle",
        gap: "M",
        wrap: !0
      },
      styles: { normal: { "margin-bottom": "20px" } },
      order: 0,
      $$slots: { default: [$e] },
      $$scope: { ctx: o }
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, r) {
      w(e, t, r), n = !0;
    },
    p(t, r) {
      const l = {};
      r[0] & /*buttonClickActions, titleButtonText, enrichedSearchColumns, showTitleButton, title*/
      302002177 | r[2] & /*$$scope*/
      2 && (l.$$scope = { dirty: r, ctx: t }), e.$set(l);
    },
    i(t) {
      n || (c(e.$$.fragment, t), n = !0);
    },
    o(t) {
      m(e.$$.fragment, t), n = !1;
    },
    d(t) {
      h(e, t);
    }
  };
}
function Ce(o) {
  let e = [], n = /* @__PURE__ */ new Map(), t, r, l = ke(
    /*enrichedSearchColumns*/
    o[25]
  );
  const i = (a) => (
    /*column*/
    a[60].name
  );
  for (let a = 0; a < l.length; a += 1) {
    let f = ge(o, l, a), p = i(f);
    n.set(p, e[a] = Be(p, f));
  }
  return {
    c() {
      for (let a = 0; a < e.length; a += 1)
        e[a].c();
      t = v();
    },
    m(a, f) {
      for (let p = 0; p < e.length; p += 1)
        e[p] && e[p].m(a, f);
      S(a, t, f), r = !0;
    },
    p(a, f) {
      f[0] & /*enrichedSearchColumns*/
      33554432 && (l = ke(
        /*enrichedSearchColumns*/
        a[25]
      ), R(), e = Je(e, f, i, 1, a, l, n, t.parentNode, Qe, Be, t, ge), y());
    },
    i(a) {
      if (!r) {
        for (let f = 0; f < l.length; f += 1)
          c(e[f]);
        r = !0;
      }
    },
    o(a) {
      for (let f = 0; f < e.length; f += 1)
        m(e[f]);
      r = !1;
    },
    d(a) {
      a && P(t);
      for (let f = 0; f < e.length; f += 1)
        e[f].d(a);
    }
  };
}
function Be(o, e) {
  let n, t, r;
  return t = new B({
    props: {
      type: (
        /*column*/
        e[60].componentType
      ),
      props: {
        field: (
          /*column*/
          e[60].name
        ),
        placeholder: (
          /*column*/
          e[60].name
        ),
        text: (
          /*column*/
          e[60].name
        ),
        autoWidth: !0
      },
      styles: { normal: { width: "192px" } },
      order: (
        /*idx*/
        e[62]
      )
    }
  }), {
    key: o,
    first: null,
    c() {
      n = v(), g(t.$$.fragment), this.first = n;
    },
    m(l, i) {
      S(l, n, i), w(t, l, i), r = !0;
    },
    p(l, i) {
      e = l;
      const a = {};
      i[0] & /*enrichedSearchColumns*/
      33554432 && (a.type = /*column*/
      e[60].componentType), i[0] & /*enrichedSearchColumns*/
      33554432 && (a.props = {
        field: (
          /*column*/
          e[60].name
        ),
        placeholder: (
          /*column*/
          e[60].name
        ),
        text: (
          /*column*/
          e[60].name
        ),
        autoWidth: !0
      }), i[0] & /*enrichedSearchColumns*/
      33554432 && (a.order = /*idx*/
      e[62]), t.$set(a);
    },
    i(l) {
      r || (c(t.$$.fragment, l), r = !0);
    },
    o(l) {
      m(t.$$.fragment, l), r = !1;
    },
    d(l) {
      l && P(n), h(t, l);
    }
  };
}
function Se(o) {
  var t;
  let e, n;
  return e = new B({
    props: {
      type: "button",
      props: {
        onClick: (
          /*buttonClickActions*/
          o[28]
        ),
        text: (
          /*titleButtonText*/
          o[13]
        ),
        type: "cta"
      },
      order: (
        /*enrichedSearchColumns*/
        ((t = o[25]) == null ? void 0 : t.length) ?? 0
      )
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(r, l) {
      w(e, r, l), n = !0;
    },
    p(r, l) {
      var a;
      const i = {};
      l[0] & /*buttonClickActions, titleButtonText*/
      268443648 && (i.props = {
        onClick: (
          /*buttonClickActions*/
          r[28]
        ),
        text: (
          /*titleButtonText*/
          r[13]
        ),
        type: "cta"
      }), l[0] & /*enrichedSearchColumns*/
      33554432 && (i.order = /*enrichedSearchColumns*/
      ((a = r[25]) == null ? void 0 : a.length) ?? 0), e.$set(i);
    },
    i(r) {
      n || (c(e.$$.fragment, r), n = !0);
    },
    o(r) {
      m(e.$$.fragment, r), n = !1;
    },
    d(r) {
      h(e, r);
    }
  };
}
function Ze(o) {
  var i;
  let e, n, t, r = (
    /*enrichedSearchColumns*/
    ((i = o[25]) == null ? void 0 : i.length) && Ce(o)
  ), l = (
    /*showTitleButton*/
    o[12] && Se(o)
  );
  return {
    c() {
      r && r.c(), e = N(), l && l.c(), n = v();
    },
    m(a, f) {
      r && r.m(a, f), S(a, e, f), l && l.m(a, f), S(a, n, f), t = !0;
    },
    p(a, f) {
      var p;
      /*enrichedSearchColumns*/
      (p = a[25]) != null && p.length ? r ? (r.p(a, f), f[0] & /*enrichedSearchColumns*/
      33554432 && c(r, 1)) : (r = Ce(a), r.c(), c(r, 1), r.m(e.parentNode, e)) : r && (R(), m(r, 1, 1, () => {
        r = null;
      }), y()), /*showTitleButton*/
      a[12] ? l ? (l.p(a, f), f[0] & /*showTitleButton*/
      4096 && c(l, 1)) : (l = Se(a), l.c(), c(l, 1), l.m(n.parentNode, n)) : l && (R(), m(l, 1, 1, () => {
        l = null;
      }), y());
    },
    i(a) {
      t || (c(r), c(l), t = !0);
    },
    o(a) {
      m(r), m(l), t = !1;
    },
    d(a) {
      a && (P(e), P(n)), r && r.d(a), l && l.d(a);
    }
  };
}
function $e(o) {
  let e, n, t, r;
  return e = new B({
    props: {
      type: "textv2",
      props: {
        text: (
          /*title*/
          o[0] ? `## ${/*title*/
          o[0]}` : ""
        )
      },
      order: 0
    }
  }), t = new B({
    props: {
      type: "container",
      props: {
        direction: "row",
        hAlign: "left",
        vAlign: "center",
        gap: "M",
        wrap: !0
      },
      order: 1,
      $$slots: { default: [Ze] },
      $$scope: { ctx: o }
    }
  }), {
    c() {
      g(e.$$.fragment), n = N(), g(t.$$.fragment);
    },
    m(l, i) {
      w(e, l, i), S(l, n, i), w(t, l, i), r = !0;
    },
    p(l, i) {
      const a = {};
      i[0] & /*title*/
      1 && (a.props = {
        text: (
          /*title*/
          l[0] ? `## ${/*title*/
          l[0]}` : ""
        )
      }), e.$set(a);
      const f = {};
      i[0] & /*buttonClickActions, titleButtonText, enrichedSearchColumns, showTitleButton*/
      302002176 | i[2] & /*$$scope*/
      2 && (f.$$scope = { dirty: i, ctx: l }), t.$set(f);
    },
    i(l) {
      r || (c(e.$$.fragment, l), c(t.$$.fragment, l), r = !0);
    },
    o(l) {
      m(e.$$.fragment, l), m(t.$$.fragment, l), r = !1;
    },
    d(l) {
      l && P(n), h(e, l), h(t, l);
    }
  };
}
function xe(o) {
  let e, n;
  return e = new B({
    props: {
      type: "table",
      context: "table",
      props: {
        dataProvider: `{{ literal ${T(
          /*dataProviderId*/
          o[26]
        )} }}`,
        columns: (
          /*tableColumns*/
          o[5]
        ),
        rowCount: (
          /*rowCount*/
          o[6]
        ),
        quiet: (
          /*quiet*/
          o[7]
        ),
        compact: (
          /*compact*/
          o[8]
        ),
        allowSelectRows: (
          /*allowSelectRows*/
          o[10]
        ),
        size: (
          /*size*/
          o[9]
        ),
        onClick: (
          /*rowClickActions*/
          o[29]
        ),
        noRowsMessage: (
          /*noRowsMessage*/
          o[15] || "No rows found"
        )
      }
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, r) {
      w(e, t, r), n = !0;
    },
    p(t, r) {
      const l = {};
      r[0] & /*dataProviderId, tableColumns, rowCount, quiet, compact, allowSelectRows, size, rowClickActions, noRowsMessage*/
      604014560 && (l.props = {
        dataProvider: `{{ literal ${T(
          /*dataProviderId*/
          t[26]
        )} }}`,
        columns: (
          /*tableColumns*/
          t[5]
        ),
        rowCount: (
          /*rowCount*/
          t[6]
        ),
        quiet: (
          /*quiet*/
          t[7]
        ),
        compact: (
          /*compact*/
          t[8]
        ),
        allowSelectRows: (
          /*allowSelectRows*/
          t[10]
        ),
        size: (
          /*size*/
          t[9]
        ),
        onClick: (
          /*rowClickActions*/
          t[29]
        ),
        noRowsMessage: (
          /*noRowsMessage*/
          t[15] || "No rows found"
        )
      }), e.$set(l);
    },
    i(t) {
      n || (c(e.$$.fragment, t), n = !0);
    },
    o(t) {
      m(e.$$.fragment, t), n = !1;
    },
    d(t) {
      h(e, t);
    }
  };
}
function Pe(o) {
  let e, n, t;
  function r(i) {
    o[49](i);
  }
  let l = {
    name: "Details side panel",
    type: "sidepanel",
    context: "details-side-panel",
    order: 2,
    $$slots: { default: [et] },
    $$scope: { ctx: o }
  };
  return (
    /*detailsSidePanelId*/
    o[22] !== void 0 && (l.id = /*detailsSidePanelId*/
    o[22]), e = new B({ props: l }), M.push(() => z(e, "id", r)), {
      c() {
        g(e.$$.fragment);
      },
      m(i, a) {
        w(e, i, a), t = !0;
      },
      p(i, a) {
        const f = {};
        a[0] & /*dataSource, sidePanelSaveLabel, notificationOverride, sidePanelFields, normalFields, detailsFormBlockId*/
        1076297730 | a[1] & /*id, deleteLabel, editTitle*/
        13 | a[2] & /*$$scope*/
        2 && (f.$$scope = { dirty: a, ctx: i }), !n && a[0] & /*detailsSidePanelId*/
        4194304 && (n = !0, f.id = /*detailsSidePanelId*/
        i[22], F(() => n = !1)), e.$set(f);
      },
      i(i) {
        t || (c(e.$$.fragment, i), t = !0);
      },
      o(i) {
        m(e.$$.fragment, i), t = !1;
      },
      d(i) {
        h(e, i);
      }
    }
  );
}
function et(o) {
  let e, n, t;
  function r(i) {
    o[48](i);
  }
  let l = {
    name: "Details form block",
    type: "formblock",
    context: "form-edit",
    props: {
      dataSource: (
        /*dataSource*/
        o[1]
      ),
      buttonPosition: "top",
      buttons: j({
        _id: (
          /*id*/
          o[33] + "-form-edit"
        ),
        showDeleteButton: (
          /*deleteLabel*/
          o[34] !== ""
        ),
        showSaveButton: !0,
        saveButtonLabel: (
          /*sidePanelSaveLabel*/
          o[17] || "Save"
        ),
        deleteButtonLabel: (
          /*deleteLabel*/
          o[34]
        ),
        notificationOverride: (
          /*notificationOverride*/
          o[18]
        ),
        actionType: "Update",
        dataSource: (
          /*dataSource*/
          o[1]
        )
      }),
      actionType: "Update",
      rowId: `{{ ${T("state")}.${T(
        /*stateKey*/
        o[36]
      )} }}`,
      fields: (
        /*sidePanelFields*/
        o[16] || /*normalFields*/
        o[30]
      ),
      title: (
        /*editTitle*/
        o[31]
      ),
      labelPosition: "left"
    }
  };
  return (
    /*detailsFormBlockId*/
    o[21] !== void 0 && (l.id = /*detailsFormBlockId*/
    o[21]), e = new B({ props: l }), M.push(() => z(e, "id", r)), {
      c() {
        g(e.$$.fragment);
      },
      m(i, a) {
        w(e, i, a), t = !0;
      },
      p(i, a) {
        const f = {};
        a[0] & /*dataSource, sidePanelSaveLabel, notificationOverride, sidePanelFields, normalFields*/
        1074200578 | a[1] & /*id, deleteLabel, editTitle*/
        13 && (f.props = {
          dataSource: (
            /*dataSource*/
            i[1]
          ),
          buttonPosition: "top",
          buttons: j({
            _id: (
              /*id*/
              i[33] + "-form-edit"
            ),
            showDeleteButton: (
              /*deleteLabel*/
              i[34] !== ""
            ),
            showSaveButton: !0,
            saveButtonLabel: (
              /*sidePanelSaveLabel*/
              i[17] || "Save"
            ),
            deleteButtonLabel: (
              /*deleteLabel*/
              i[34]
            ),
            notificationOverride: (
              /*notificationOverride*/
              i[18]
            ),
            actionType: "Update",
            dataSource: (
              /*dataSource*/
              i[1]
            )
          }),
          actionType: "Update",
          rowId: `{{ ${T("state")}.${T(
            /*stateKey*/
            i[36]
          )} }}`,
          fields: (
            /*sidePanelFields*/
            i[16] || /*normalFields*/
            i[30]
          ),
          title: (
            /*editTitle*/
            i[31]
          ),
          labelPosition: "left"
        }), !n && a[0] & /*detailsFormBlockId*/
        2097152 && (n = !0, f.id = /*detailsFormBlockId*/
        i[21], F(() => n = !1)), e.$set(f);
      },
      i(i) {
        t || (c(e.$$.fragment, i), t = !0);
      },
      o(i) {
        m(e.$$.fragment, i), t = !1;
      },
      d(i) {
        h(e, i);
      }
    }
  );
}
function Te(o) {
  let e, n, t;
  function r(i) {
    o[50](i);
  }
  let l = {
    name: "New row side panel",
    type: "sidepanel",
    context: "new-side-panel",
    order: 3,
    $$slots: { default: [tt] },
    $$scope: { ctx: o }
  };
  return (
    /*newRowSidePanelId*/
    o[23] !== void 0 && (l.id = /*newRowSidePanelId*/
    o[23]), e = new B({ props: l }), M.push(() => z(e, "id", r)), {
      c() {
        g(e.$$.fragment);
      },
      m(i, a) {
        w(e, i, a), t = !0;
      },
      p(i, a) {
        const f = {};
        a[0] & /*dataSource, notificationOverride, sidePanelFields, normalFields*/
        1074069506 | a[1] & /*id*/
        4 | a[2] & /*$$scope*/
        2 && (f.$$scope = { dirty: a, ctx: i }), !n && a[0] & /*newRowSidePanelId*/
        8388608 && (n = !0, f.id = /*newRowSidePanelId*/
        i[23], F(() => n = !1)), e.$set(f);
      },
      i(i) {
        t || (c(e.$$.fragment, i), t = !0);
      },
      o(i) {
        m(e.$$.fragment, i), t = !1;
      },
      d(i) {
        h(e, i);
      }
    }
  );
}
function tt(o) {
  let e, n;
  return e = new B({
    props: {
      name: "New row form block",
      type: "formblock",
      context: "form-new",
      props: {
        dataSource: (
          /*dataSource*/
          o[1]
        ),
        buttonPosition: "top",
        buttons: j({
          _id: (
            /*id*/
            o[33] + "-form-new"
          ),
          showDeleteButton: !1,
          showSaveButton: !0,
          saveButtonLabel: "Save",
          notificationOverride: (
            /*notificationOverride*/
            o[18]
          ),
          actionType: "Create",
          dataSource: (
            /*dataSource*/
            o[1]
          )
        }),
        actionType: "Create",
        fields: (
          /*sidePanelFields*/
          o[16] || /*normalFields*/
          o[30]
        ),
        title: "Create Row",
        labelPosition: "left"
      }
    }
  }), {
    c() {
      g(e.$$.fragment);
    },
    m(t, r) {
      w(e, t, r), n = !0;
    },
    p(t, r) {
      const l = {};
      r[0] & /*dataSource, notificationOverride, sidePanelFields, normalFields*/
      1074069506 | r[1] & /*id*/
      4 && (l.props = {
        dataSource: (
          /*dataSource*/
          t[1]
        ),
        buttonPosition: "top",
        buttons: j({
          _id: (
            /*id*/
            t[33] + "-form-new"
          ),
          showDeleteButton: !1,
          showSaveButton: !0,
          saveButtonLabel: "Save",
          notificationOverride: (
            /*notificationOverride*/
            t[18]
          ),
          actionType: "Create",
          dataSource: (
            /*dataSource*/
            t[1]
          )
        }),
        actionType: "Create",
        fields: (
          /*sidePanelFields*/
          t[16] || /*normalFields*/
          t[30]
        ),
        title: "Create Row",
        labelPosition: "left"
      }), e.$set(l);
    },
    i(t) {
      n || (c(e.$$.fragment, t), n = !0);
    },
    o(t) {
      m(e.$$.fragment, t), n = !1;
    },
    d(t) {
      h(e, t);
    }
  };
}
function nt(o) {
  var C;
  let e, n, t, r, l, i, a, f = (
    /*title*/
    (o[0] || /*enrichedSearchColumns*/
    ((C = o[25]) == null ? void 0 : C.length) || /*showTitleButton*/
    o[12]) && he(o)
  );
  function p(u) {
    o[47](u);
  }
  let L = {
    type: "dataprovider",
    props: {
      dataSource: (
        /*dataSource*/
        o[1]
      ),
      filter: (
        /*enrichedFilter*/
        o[32]
      ),
      sortColumn: (
        /*sortColumn*/
        o[2] || /*primaryDisplay*/
        o[24]
      ),
      sortOrder: (
        /*sortOrder*/
        o[3]
      ),
      paginate: (
        /*paginate*/
        o[4]
      ),
      limit: (
        /*rowCount*/
        o[6]
      ),
      autoRefresh: (
        /*autoRefresh*/
        o[19]
      )
    },
    context: "provider",
    order: 1,
    $$slots: { default: [xe] },
    $$scope: { ctx: o }
  };
  /*dataProviderId*/
  o[26] !== void 0 && (L.id = /*dataProviderId*/
  o[26]), n = new B({ props: L }), M.push(() => z(n, "id", p));
  let _ = (
    /*clickBehaviour*/
    o[11] === "details" && Pe(o)
  ), b = (
    /*showTitleButton*/
    o[12] && /*titleButtonClickBehaviour*/
    o[14] === "new" && Te(o)
  );
  return {
    c() {
      f && f.c(), e = N(), g(n.$$.fragment), r = N(), _ && _.c(), l = N(), b && b.c(), i = v();
    },
    m(u, d) {
      f && f.m(u, d), S(u, e, d), w(n, u, d), S(u, r, d), _ && _.m(u, d), S(u, l, d), b && b.m(u, d), S(u, i, d), a = !0;
    },
    p(u, d) {
      var O;
      /*title*/
      u[0] || /*enrichedSearchColumns*/
      (O = u[25]) != null && O.length || /*showTitleButton*/
      u[12] ? f ? (f.p(u, d), d[0] & /*title, enrichedSearchColumns, showTitleButton*/
      33558529 && c(f, 1)) : (f = he(u), f.c(), c(f, 1), f.m(e.parentNode, e)) : f && (R(), m(f, 1, 1, () => {
        f = null;
      }), y());
      const D = {};
      d[0] & /*dataSource, sortColumn, primaryDisplay, sortOrder, paginate, rowCount, autoRefresh*/
      17301598 | d[1] & /*enrichedFilter*/
      2 && (D.props = {
        dataSource: (
          /*dataSource*/
          u[1]
        ),
        filter: (
          /*enrichedFilter*/
          u[32]
        ),
        sortColumn: (
          /*sortColumn*/
          u[2] || /*primaryDisplay*/
          u[24]
        ),
        sortOrder: (
          /*sortOrder*/
          u[3]
        ),
        paginate: (
          /*paginate*/
          u[4]
        ),
        limit: (
          /*rowCount*/
          u[6]
        ),
        autoRefresh: (
          /*autoRefresh*/
          u[19]
        )
      }), d[0] & /*dataProviderId, tableColumns, rowCount, quiet, compact, allowSelectRows, size, rowClickActions, noRowsMessage*/
      604014560 | d[2] & /*$$scope*/
      2 && (D.$$scope = { dirty: d, ctx: u }), !t && d[0] & /*dataProviderId*/
      67108864 && (t = !0, D.id = /*dataProviderId*/
      u[26], F(() => t = !1)), n.$set(D), /*clickBehaviour*/
      u[11] === "details" ? _ ? (_.p(u, d), d[0] & /*clickBehaviour*/
      2048 && c(_, 1)) : (_ = Pe(u), _.c(), c(_, 1), _.m(l.parentNode, l)) : _ && (R(), m(_, 1, 1, () => {
        _ = null;
      }), y()), /*showTitleButton*/
      u[12] && /*titleButtonClickBehaviour*/
      u[14] === "new" ? b ? (b.p(u, d), d[0] & /*showTitleButton, titleButtonClickBehaviour*/
      20480 && c(b, 1)) : (b = Te(u), b.c(), c(b, 1), b.m(i.parentNode, i)) : b && (R(), m(b, 1, 1, () => {
        b = null;
      }), y());
    },
    i(u) {
      a || (c(f), c(n.$$.fragment, u), c(_), c(b), a = !0);
    },
    o(u) {
      m(f), m(n.$$.fragment, u), m(_), m(b), a = !1;
    },
    d(u) {
      u && (P(e), P(r), P(l), P(i)), f && f.d(u), h(n, u), _ && _.d(u), b && b.d(u);
    }
  };
}
function ot(o) {
  let e, n, t;
  function r(i) {
    o[51](i);
  }
  let l = {
    type: "form",
    props: {
      dataSource: (
        /*dataSource*/
        o[1]
      ),
      disableSchemaValidation: !0,
      editAutoColumns: !0,
      size: (
        /*size*/
        o[9]
      )
    },
    $$slots: { default: [nt] },
    $$scope: { ctx: o }
  };
  return (
    /*formId*/
    o[20] !== void 0 && (l.id = /*formId*/
    o[20]), e = new B({ props: l }), M.push(() => z(e, "id", r)), {
      c() {
        g(e.$$.fragment);
      },
      m(i, a) {
        w(e, i, a), t = !0;
      },
      p(i, a) {
        const f = {};
        a[0] & /*dataSource, size*/
        514 && (f.props = {
          dataSource: (
            /*dataSource*/
            i[1]
          ),
          disableSchemaValidation: !0,
          editAutoColumns: !0,
          size: (
            /*size*/
            i[9]
          )
        }), a[0] & /*newRowSidePanelId, dataSource, notificationOverride, sidePanelFields, normalFields, showTitleButton, titleButtonClickBehaviour, detailsSidePanelId, sidePanelSaveLabel, detailsFormBlockId, clickBehaviour, sortColumn, primaryDisplay, sortOrder, paginate, rowCount, autoRefresh, dataProviderId, tableColumns, quiet, compact, allowSelectRows, size, rowClickActions, noRowsMessage, buttonClickActions, titleButtonText, enrichedSearchColumns, title*/
        2012217343 | a[1] & /*id, deleteLabel, editTitle, enrichedFilter*/
        15 | a[2] & /*$$scope*/
        2 && (f.$$scope = { dirty: a, ctx: i }), !n && a[0] & /*formId*/
        1048576 && (n = !0, f.id = /*formId*/
        i[20], F(() => n = !1)), e.$set(f);
      },
      i(i) {
        t || (c(e.$$.fragment, i), t = !0);
      },
      o(i) {
        m(e.$$.fragment, i), t = !1;
      },
      d(i) {
        h(e, i);
      }
    }
  );
}
function lt(o) {
  let e, n, t = (
    /*schemaLoaded*/
    o[27] && we(o)
  );
  return {
    c() {
      t && t.c(), e = v();
    },
    m(r, l) {
      t && t.m(r, l), S(r, e, l), n = !0;
    },
    p(r, l) {
      /*schemaLoaded*/
      r[27] ? t ? (t.p(r, l), l[0] & /*schemaLoaded*/
      134217728 && c(t, 1)) : (t = we(r), t.c(), c(t, 1), t.m(e.parentNode, e)) : t && (R(), m(t, 1, 1, () => {
        t = null;
      }), y());
    },
    i(r) {
      n || (c(t), n = !0);
    },
    o(r) {
      m(t), n = !1;
    },
    d(r) {
      r && P(e), t && t.d(r);
    }
  };
}
function it(o, e, n) {
  let t, r, l, i, a, f, p, L, _, { title: b } = e, { dataSource: C } = e, { searchColumns: u } = e, { filter: d } = e, { sortColumn: D } = e, { sortOrder: O } = e, { paginate: x } = e, { tableColumns: ee } = e, { rowCount: te } = e, { quiet: ne } = e, { compact: oe } = e, { size: le } = e, { allowSelectRows: ie } = e, { clickBehaviour: E } = e, { onClick: K } = e, { showTitleButton: re } = e, { titleButtonText: ae } = e, { titleButtonClickBehaviour: W } = e, { onClickTitleButton: G } = e, { noRowsMessage: se } = e, { sidePanelFields: fe } = e, { sidePanelShowDelete: J } = e, { sidePanelSaveLabel: ue } = e, { sidePanelDeleteLabel: Q } = e, { notificationOverride: ce } = e, { autoRefresh: me } = e;
  const { fetchDatasourceSchema: De, API: Re, generateGoldenSample: ye } = $("sdk"), de = $("component");
  Ee(o, de, (s) => n(46, _ = s));
  const Le = $("context"), _e = `ID_${Ke.generate()}`;
  let I, q, U, H, V, A, X, Y, be = !1;
  const Oe = () => {
    var Z;
    const s = (Z = Ge(Le)[q]) == null ? void 0 : Z.rows;
    return { eventContext: { row: ye(s) } };
  }, Ae = (s) => {
    let k = J === !1 ? "" : s;
    return (k == null ? void 0 : k.trim()) === "" ? "" : k || "Delete";
  }, Ne = async (s) => {
    if ((s == null ? void 0 : s.type) === "table") {
      const k = await Re.fetchTableDefinition(s == null ? void 0 : s.tableId);
      n(44, A = k.schema), n(24, X = k.primaryDisplay);
    } else
      s && n(44, A = await De(s, { enrichRelationships: !0 }));
    n(27, be = !0);
  }, ve = (s) => s ? Object.entries(s).filter((k) => !k[1].autocolumn).map((k) => k[0]) : [], Me = (s, k) => {
    if (!k || !s)
      return "Edit";
    const pe = `${T(s + "-repeater")}.${T(k)}`;
    return `{{#if ${pe}}}{{${pe}}}{{else}}Details{{/if}}`;
  };
  function ze(s) {
    q = s, n(26, q);
  }
  function Fe(s) {
    U = s, n(21, U);
  }
  function Ie(s) {
    H = s, n(22, H);
  }
  function qe(s) {
    V = s, n(23, V);
  }
  function Ue(s) {
    I = s, n(20, I);
  }
  return o.$$set = (s) => {
    "title" in s && n(0, b = s.title), "dataSource" in s && n(1, C = s.dataSource), "searchColumns" in s && n(37, u = s.searchColumns), "filter" in s && n(38, d = s.filter), "sortColumn" in s && n(2, D = s.sortColumn), "sortOrder" in s && n(3, O = s.sortOrder), "paginate" in s && n(4, x = s.paginate), "tableColumns" in s && n(5, ee = s.tableColumns), "rowCount" in s && n(6, te = s.rowCount), "quiet" in s && n(7, ne = s.quiet), "compact" in s && n(8, oe = s.compact), "size" in s && n(9, le = s.size), "allowSelectRows" in s && n(10, ie = s.allowSelectRows), "clickBehaviour" in s && n(11, E = s.clickBehaviour), "onClick" in s && n(39, K = s.onClick), "showTitleButton" in s && n(12, re = s.showTitleButton), "titleButtonText" in s && n(13, ae = s.titleButtonText), "titleButtonClickBehaviour" in s && n(14, W = s.titleButtonClickBehaviour), "onClickTitleButton" in s && n(40, G = s.onClickTitleButton), "noRowsMessage" in s && n(15, se = s.noRowsMessage), "sidePanelFields" in s && n(16, fe = s.sidePanelFields), "sidePanelShowDelete" in s && n(41, J = s.sidePanelShowDelete), "sidePanelSaveLabel" in s && n(17, ue = s.sidePanelSaveLabel), "sidePanelDeleteLabel" in s && n(42, Q = s.sidePanelDeleteLabel), "notificationOverride" in s && n(18, ce = s.notificationOverride), "autoRefresh" in s && n(19, me = s.autoRefresh);
  }, o.$$.update = () => {
    o.$$.dirty[1] & /*sidePanelDeleteLabel, sidePanelShowDelete*/
    3072 && n(34, t = Ae(Q)), o.$$.dirty[1] & /*$component*/
    32768 && n(33, r = _.id), o.$$.dirty[0] & /*dataSource*/
    2 && n(45, l = (C == null ? void 0 : C.type) === "table" || (C == null ? void 0 : C.type) === "viewV2"), o.$$.dirty[0] & /*dataSource*/
    2 && Ne(C), o.$$.dirty[1] & /*searchColumns, schema*/
    8256 && Xe(u, A).then((s) => n(25, Y = s)), o.$$.dirty[0] & /*enrichedSearchColumns, formId*/
    34603008 | o.$$.dirty[1] & /*filter*/
    128 && n(32, i = Ye(d, Y, I)), o.$$.dirty[0] & /*detailsFormBlockId, primaryDisplay*/
    18874368 && n(31, a = Me(U, X)), o.$$.dirty[1] & /*schema*/
    8192 && n(30, f = ve(A)), o.$$.dirty[0] & /*clickBehaviour, detailsSidePanelId*/
    4196352 | o.$$.dirty[1] & /*isDSPlus, onClick*/
    16640 && n(29, p = E === "actions" || !l ? K : [
      {
        id: 0,
        "##eventHandlerType": "Update State",
        parameters: {
          key: _e,
          type: "set",
          persist: !1,
          value: `{{ ${T("eventContext")}.${T("row")}._id }}`
        }
      },
      {
        id: 1,
        "##eventHandlerType": "Open Side Panel",
        parameters: { id: H }
      }
    ]), o.$$.dirty[0] & /*titleButtonClickBehaviour, newRowSidePanelId*/
    8404992 | o.$$.dirty[1] & /*isDSPlus, onClickTitleButton*/
    16896 && n(28, L = W === "actions" || !l ? G : [
      {
        id: 0,
        "##eventHandlerType": "Open Side Panel",
        parameters: { id: V }
      }
    ]);
  }, [
    b,
    C,
    D,
    O,
    x,
    ee,
    te,
    ne,
    oe,
    le,
    ie,
    E,
    re,
    ae,
    W,
    se,
    fe,
    ue,
    ce,
    me,
    I,
    U,
    H,
    V,
    X,
    Y,
    q,
    be,
    L,
    p,
    f,
    a,
    i,
    r,
    t,
    de,
    _e,
    u,
    d,
    K,
    G,
    J,
    Q,
    Oe,
    A,
    l,
    _,
    ze,
    Fe,
    Ie,
    qe,
    Ue
  ];
}
class st extends He {
  constructor(e) {
    super(), Ve(
      this,
      e,
      it,
      lt,
      je,
      {
        title: 0,
        dataSource: 1,
        searchColumns: 37,
        filter: 38,
        sortColumn: 2,
        sortOrder: 3,
        paginate: 4,
        tableColumns: 5,
        rowCount: 6,
        quiet: 7,
        compact: 8,
        size: 9,
        allowSelectRows: 10,
        clickBehaviour: 11,
        onClick: 39,
        showTitleButton: 12,
        titleButtonText: 13,
        titleButtonClickBehaviour: 14,
        onClickTitleButton: 40,
        noRowsMessage: 15,
        sidePanelFields: 16,
        sidePanelShowDelete: 41,
        sidePanelSaveLabel: 17,
        sidePanelDeleteLabel: 42,
        notificationOverride: 18,
        autoRefresh: 19,
        getAdditionalDataContext: 43
      },
      null,
      [-1, -1, -1]
    );
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[43];
  }
}
export {
  st as default
};
