import { S as ae, i as te, s as ue, b2 as de, ac as P, ai as L, c as p, m as M, aj as F, k as _, n as b, p as G, ck as se, y as U, f as W, z as X, A as Z, o as y } from "./index-e79f0bb2.js";
import { C as ce } from "./CheckboxGroup-0b0feec9.js";
import { M as re } from "./Multiselect-9dd507ef.js";
import { F as _e } from "./Field-269dd13f.js";
import { g as me } from "./optionsParser-7fb88327.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function D(i) {
  let e, n, l, o;
  const a = [he, be], r = [];
  function m(u, c) {
    return !/*optionsType*/
    u[7] || /*optionsType*/
    u[7] === "select" ? 0 : (
      /*optionsType*/
      u[7] === "checkbox" ? 1 : -1
    );
  }
  return ~(e = m(i)) && (n = r[e] = a[e](i)), {
    c() {
      n && n.c(), l = U();
    },
    m(u, c) {
      ~e && r[e].m(u, c), W(u, l, c), o = !0;
    },
    p(u, c) {
      let t = e;
      e = m(u), e === t ? ~e && r[e].p(u, c) : (n && (X(), b(r[t], 1, 1, () => {
        r[t] = null;
      }), Z()), ~e ? (n = r[e], n ? n.p(u, c) : (n = r[e] = a[e](u), n.c()), _(n, 1), n.m(l.parentNode, l)) : n = null);
    },
    i(u) {
      o || (_(n), o = !0);
    },
    o(u) {
      b(n), o = !1;
    },
    d(u) {
      u && y(l), ~e && r[e].d(u);
    }
  };
}
function be(i) {
  let e, n;
  return e = new ce({
    props: {
      value: (
        /*fieldState*/
        i[14].value || []
      ),
      disabled: (
        /*fieldState*/
        i[14].disabled
      ),
      readonly: (
        /*fieldState*/
        i[14].readonly
      ),
      options: (
        /*options*/
        i[16]
      ),
      direction: (
        /*direction*/
        i[8]
      ),
      getOptionLabel: (
        /*flatOptions*/
        i[18] ? K : (
          /*func_5*/
          i[29]
        )
      ),
      getOptionValue: (
        /*flatOptions*/
        i[18] ? Q : (
          /*func_7*/
          i[30]
        )
      ),
      showSelectAll: (
        /*showSelectAll*/
        i[11]
      ),
      selectAllText: (
        /*selectAllText*/
        i[12]
      )
    }
  }), e.$on(
    "change",
    /*handleChange*/
    i[21]
  ), {
    c() {
      p(e.$$.fragment);
    },
    m(l, o) {
      M(e, l, o), n = !0;
    },
    p(l, o) {
      const a = {};
      o[0] & /*fieldState*/
      16384 && (a.value = /*fieldState*/
      l[14].value || []), o[0] & /*fieldState*/
      16384 && (a.disabled = /*fieldState*/
      l[14].disabled), o[0] & /*fieldState*/
      16384 && (a.readonly = /*fieldState*/
      l[14].readonly), o[0] & /*options*/
      65536 && (a.options = /*options*/
      l[16]), o[0] & /*direction*/
      256 && (a.direction = /*direction*/
      l[8]), o[0] & /*flatOptions*/
      262144 && (a.getOptionLabel = /*flatOptions*/
      l[18] ? K : (
        /*func_5*/
        l[29]
      )), o[0] & /*flatOptions*/
      262144 && (a.getOptionValue = /*flatOptions*/
      l[18] ? Q : (
        /*func_7*/
        l[30]
      )), o[0] & /*showSelectAll*/
      2048 && (a.showSelectAll = /*showSelectAll*/
      l[11]), o[0] & /*selectAllText*/
      4096 && (a.selectAllText = /*selectAllText*/
      l[12]), e.$set(a);
    },
    i(l) {
      n || (_(e.$$.fragment, l), n = !0);
    },
    o(l) {
      b(e.$$.fragment, l), n = !1;
    },
    d(l) {
      G(e, l);
    }
  };
}
function he(i) {
  let e, n;
  return e = new re({
    props: {
      value: (
        /*fieldState*/
        i[14].value || []
      ),
      getOptionLabel: (
        /*flatOptions*/
        i[18] ? Y : E
      ),
      getOptionValue: (
        /*flatOptions*/
        i[18] ? H : J
      ),
      id: (
        /*fieldState*/
        i[14].fieldId
      ),
      disabled: (
        /*fieldState*/
        i[14].disabled
      ),
      readonly: (
        /*fieldState*/
        i[14].readonly
      ),
      placeholder: (
        /*placeholder*/
        i[2]
      ),
      options: (
        /*options*/
        i[16]
      ),
      autocomplete: (
        /*autocomplete*/
        i[6]
      ),
      searchPlaceholder: (
        /*pickerLabels*/
        i[19].searchPlaceholder
      ),
      showSelectAll: (
        /*showSelectAll*/
        i[11]
      ),
      selectAllText: (
        /*selectAllText*/
        i[12]
      )
    }
  }), e.$on(
    "change",
    /*handleChange*/
    i[21]
  ), {
    c() {
      p(e.$$.fragment);
    },
    m(l, o) {
      M(e, l, o), n = !0;
    },
    p(l, o) {
      const a = {};
      o[0] & /*fieldState*/
      16384 && (a.value = /*fieldState*/
      l[14].value || []), o[0] & /*flatOptions*/
      262144 && (a.getOptionLabel = /*flatOptions*/
      l[18] ? Y : E), o[0] & /*flatOptions*/
      262144 && (a.getOptionValue = /*flatOptions*/
      l[18] ? H : J), o[0] & /*fieldState*/
      16384 && (a.id = /*fieldState*/
      l[14].fieldId), o[0] & /*fieldState*/
      16384 && (a.disabled = /*fieldState*/
      l[14].disabled), o[0] & /*fieldState*/
      16384 && (a.readonly = /*fieldState*/
      l[14].readonly), o[0] & /*placeholder*/
      4 && (a.placeholder = /*placeholder*/
      l[2]), o[0] & /*options*/
      65536 && (a.options = /*options*/
      l[16]), o[0] & /*autocomplete*/
      64 && (a.autocomplete = /*autocomplete*/
      l[6]), o[0] & /*showSelectAll*/
      2048 && (a.showSelectAll = /*showSelectAll*/
      l[11]), o[0] & /*selectAllText*/
      4096 && (a.selectAllText = /*selectAllText*/
      l[12]), e.$set(a);
    },
    i(l) {
      n || (_(e.$$.fragment, l), n = !0);
    },
    o(l) {
      b(e.$$.fragment, l), n = !1;
    },
    d(l) {
      G(e, l);
    }
  };
}
function ge(i) {
  let e, n, l = (
    /*fieldState*/
    i[14] && D(i)
  );
  return {
    c() {
      l && l.c(), e = U();
    },
    m(o, a) {
      l && l.m(o, a), W(o, e, a), n = !0;
    },
    p(o, a) {
      /*fieldState*/
      o[14] ? l ? (l.p(o, a), a[0] & /*fieldState*/
      16384 && _(l, 1)) : (l = D(o), l.c(), _(l, 1), l.m(e.parentNode, e)) : l && (X(), b(l, 1, 1, () => {
        l = null;
      }), Z());
    },
    i(o) {
      n || (_(l), n = !0);
    },
    o(o) {
      b(l), n = !1;
    },
    d(o) {
      o && y(e), l && l.d(o);
    }
  };
}
function Se(i) {
  let e, n, l, o, a;
  function r(t) {
    i[31](t);
  }
  function m(t) {
    i[32](t);
  }
  function u(t) {
    i[33](t);
  }
  let c = {
    field: (
      /*field*/
      i[0]
    ),
    label: (
      /*label*/
      i[1]
    ),
    disabled: (
      /*disabled*/
      i[3]
    ),
    readonly: (
      /*readonly*/
      i[4]
    ),
    validation: (
      /*validation*/
      i[5]
    ),
    span: (
      /*span*/
      i[9]
    ),
    helpText: (
      /*helpText*/
      i[10]
    ),
    defaultValue: (
      /*expandedDefaultValue*/
      i[17]
    ),
    type: de.ARRAY,
    $$slots: { default: [ge] },
    $$scope: { ctx: i }
  };
  return (
    /*fieldState*/
    i[14] !== void 0 && (c.fieldState = /*fieldState*/
    i[14]), /*fieldApi*/
    i[15] !== void 0 && (c.fieldApi = /*fieldApi*/
    i[15]), /*fieldSchema*/
    i[13] !== void 0 && (c.fieldSchema = /*fieldSchema*/
    i[13]), e = new _e({ props: c }), P.push(() => L(e, "fieldState", r)), P.push(() => L(e, "fieldApi", m)), P.push(() => L(e, "fieldSchema", u)), {
      c() {
        p(e.$$.fragment);
      },
      m(t, d) {
        M(e, t, d), a = !0;
      },
      p(t, d) {
        const s = {};
        d[0] & /*field*/
        1 && (s.field = /*field*/
        t[0]), d[0] & /*label*/
        2 && (s.label = /*label*/
        t[1]), d[0] & /*disabled*/
        8 && (s.disabled = /*disabled*/
        t[3]), d[0] & /*readonly*/
        16 && (s.readonly = /*readonly*/
        t[4]), d[0] & /*validation*/
        32 && (s.validation = /*validation*/
        t[5]), d[0] & /*span*/
        512 && (s.span = /*span*/
        t[9]), d[0] & /*helpText*/
        1024 && (s.helpText = /*helpText*/
        t[10]), d[0] & /*expandedDefaultValue*/
        131072 && (s.defaultValue = /*expandedDefaultValue*/
        t[17]), d[0] & /*fieldState, flatOptions, placeholder, options, autocomplete, showSelectAll, selectAllText, optionsType, direction*/
        350660 | d[1] & /*$$scope*/
        16 && (s.$$scope = { dirty: d, ctx: t }), !n && d[0] & /*fieldState*/
        16384 && (n = !0, s.fieldState = /*fieldState*/
        t[14], F(() => n = !1)), !l && d[0] & /*fieldApi*/
        32768 && (l = !0, s.fieldApi = /*fieldApi*/
        t[15], F(() => l = !1)), !o && d[0] & /*fieldSchema*/
        8192 && (o = !0, s.fieldSchema = /*fieldSchema*/
        t[13], F(() => o = !1)), e.$set(s);
      },
      i(t) {
        a || (_(e.$$.fragment, t), a = !0);
      },
      o(t) {
        b(e.$$.fragment, t), a = !1;
      },
      d(t) {
        G(e, t);
      }
    }
  );
}
const Y = (i) => i, E = (i) => i.label, H = (i) => i, J = (i) => i.value, K = (i) => i, Q = (i) => i;
function Ae(i, e, n) {
  let l, o, a, { field: r } = e, { label: m = void 0 } = e, { placeholder: u = void 0 } = e, { disabled: c = !1 } = e, { readonly: t = !1 } = e, { validation: d = void 0 } = e, { defaultValue: s = void 0 } = e, { optionsSource: g = "schema" } = e, { dataProvider: T = void 0 } = e, { labelColumn: C = void 0 } = e, { valueColumn: O = void 0 } = e, { customOptions: v } = e, { autocomplete: I = !1 } = e, { onChange: A = void 0 } = e, { optionsType: N = "select" } = e, { direction: R = "vertical" } = e, { span: j = void 0 } = e, { helpText: q = void 0 } = e, { showSelectAll: z = !1 } = e, { selectAllText: B = "Select all" } = e, V, h, k;
  const x = se("picker"), $ = (f) => f ? Array.isArray(f) ? f.slice() : f.split(",").map((S) => S.trim()) : [], w = (f, S) => S[f], ee = (f) => {
    const S = h == null ? void 0 : h.setValue(f.detail);
    A && S && A({ value: f.detail });
  }, le = (f) => w("label", f), ie = (f) => w("value", f);
  function ne(f) {
    V = f, n(14, V);
  }
  function fe(f) {
    h = f, n(15, h);
  }
  function oe(f) {
    k = f, n(13, k);
  }
  return i.$$set = (f) => {
    "field" in f && n(0, r = f.field), "label" in f && n(1, m = f.label), "placeholder" in f && n(2, u = f.placeholder), "disabled" in f && n(3, c = f.disabled), "readonly" in f && n(4, t = f.readonly), "validation" in f && n(5, d = f.validation), "defaultValue" in f && n(22, s = f.defaultValue), "optionsSource" in f && n(23, g = f.optionsSource), "dataProvider" in f && n(24, T = f.dataProvider), "labelColumn" in f && n(25, C = f.labelColumn), "valueColumn" in f && n(26, O = f.valueColumn), "customOptions" in f && n(27, v = f.customOptions), "autocomplete" in f && n(6, I = f.autocomplete), "onChange" in f && n(28, A = f.onChange), "optionsType" in f && n(7, N = f.optionsType), "direction" in f && n(8, R = f.direction), "span" in f && n(9, j = f.span), "helpText" in f && n(10, q = f.helpText), "showSelectAll" in f && n(11, z = f.showSelectAll), "selectAllText" in f && n(12, B = f.selectAllText);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*optionsSource*/
    8388608 && n(18, l = g == null || g === "schema"), i.$$.dirty[0] & /*defaultValue*/
    4194304 && n(17, o = $(s)), i.$$.dirty[0] & /*optionsSource, fieldSchema, dataProvider, labelColumn, valueColumn, customOptions*/
    260055040 && n(16, a = me(g, k, T, C, O, v));
  }, [
    r,
    m,
    u,
    c,
    t,
    d,
    I,
    N,
    R,
    j,
    q,
    z,
    B,
    k,
    V,
    h,
    a,
    o,
    l,
    x,
    w,
    ee,
    s,
    g,
    T,
    C,
    O,
    v,
    A,
    le,
    ie,
    ne,
    fe,
    oe
  ];
}
class Pe extends ae {
  constructor(e) {
    super(), te(
      this,
      e,
      Ae,
      Se,
      ue,
      {
        field: 0,
        label: 1,
        placeholder: 2,
        disabled: 3,
        readonly: 4,
        validation: 5,
        defaultValue: 22,
        optionsSource: 23,
        dataProvider: 24,
        labelColumn: 25,
        valueColumn: 26,
        customOptions: 27,
        autocomplete: 6,
        onChange: 28,
        optionsType: 7,
        direction: 8,
        span: 9,
        helpText: 10,
        showSelectAll: 11,
        selectAllText: 12
      },
      null,
      [-1, -1]
    );
  }
}
export {
  Pe as default
};
