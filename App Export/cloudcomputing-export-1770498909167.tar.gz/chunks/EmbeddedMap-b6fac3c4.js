import { Q as W, R as Bo, S as oa, i as sa, s as aa, e as Cn, a as Sr, b as Sn, f as Ei, g as gi, q as la, k as _i, z as ca, n as Mn, A as ha, h as da, o as Ai, u as Gu, v as fa, aO as pa, aa as ma, w as ga, t as Ur, j as _a, aM as $u, c as Xu, m as Yu, p as Ku, ac as ba } from "./index-e79f0bb2.js";
import { r as qe } from "./___vite-browser-external_commonjs-proxy-3c538421.js";
var Lr = { exports: {} };
/* @preserve
 * Leaflet 1.9.4, a JS library for interactive maps. https://leafletjs.com
 * (c) 2010-2023 Vladimir Agafonkin, (c) 2010-2011 CloudMade
 */
(function(o, i) {
  (function(n, r) {
    r(i);
  })(W, function(n) {
    function r(e) {
      for (var t, u, s = 1, l = arguments.length; s < l; s++)
        for (t in u = arguments[s])
          e[t] = u[t];
      return e;
    }
    var a = Object.create || function(e) {
      return c.prototype = e, new c();
    };
    function c() {
    }
    function p(e, t) {
      var u, s = Array.prototype.slice;
      return e.bind ? e.bind.apply(e, s.call(arguments, 1)) : (u = s.call(arguments, 2), function() {
        return e.apply(t, u.length ? u.concat(s.call(arguments)) : arguments);
      });
    }
    var g = 0;
    function d(e) {
      return "_leaflet_id" in e || (e._leaflet_id = ++g), e._leaflet_id;
    }
    function _(e, t, u) {
      var s, l, h = function() {
        s = !1, l && (y.apply(u, l), l = !1);
      }, y = function() {
        s ? l = arguments : (e.apply(u, arguments), setTimeout(h, t), s = !0);
      };
      return y;
    }
    function v(e, l, u) {
      var s = l[1], l = l[0], h = s - l;
      return e === s && u ? e : ((e - l) % h + h) % h + l;
    }
    function S() {
      return !1;
    }
    function f(e, t) {
      return t === !1 ? e : (t = Math.pow(10, t === void 0 ? 6 : t), Math.round(e * t) / t);
    }
    function m(e) {
      return e.trim ? e.trim() : e.replace(/^\s+|\s+$/g, "");
    }
    function N(e) {
      return m(e).split(/\s+/);
    }
    function I(e, t) {
      for (var u in Object.prototype.hasOwnProperty.call(e, "options") || (e.options = e.options ? a(e.options) : {}), t)
        e.options[u] = t[u];
      return e.options;
    }
    function E(e, t, u) {
      var s, l = [];
      for (s in e)
        l.push(encodeURIComponent(u ? s.toUpperCase() : s) + "=" + encodeURIComponent(e[s]));
      return (t && t.indexOf("?") !== -1 ? "&" : "?") + l.join("&");
    }
    var z = /\{ *([\w_ -]+) *\}/g;
    function H(e, t) {
      return e.replace(z, function(u, s) {
        if (s = t[s], s === void 0)
          throw new Error("No value provided for variable " + u);
        return s = typeof s == "function" ? s(t) : s;
      });
    }
    var U = Array.isArray || function(e) {
      return Object.prototype.toString.call(e) === "[object Array]";
    };
    function G(e, t) {
      for (var u = 0; u < e.length; u++)
        if (e[u] === t)
          return u;
      return -1;
    }
    var re = "data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=";
    function he(e) {
      return window["webkit" + e] || window["moz" + e] || window["ms" + e];
    }
    var Le = 0;
    function se(e) {
      var t = +/* @__PURE__ */ new Date(), u = Math.max(0, 16 - (t - Le));
      return Le = t + u, window.setTimeout(e, u);
    }
    var be = window.requestAnimationFrame || he("RequestAnimationFrame") || se, xe = window.cancelAnimationFrame || he("CancelAnimationFrame") || he("CancelRequestAnimationFrame") || function(e) {
      window.clearTimeout(e);
    };
    function T(e, t, u) {
      if (!u || be !== se)
        return be.call(window, p(e, t));
      e.call(t);
    }
    function A(e) {
      e && xe.call(window, e);
    }
    var D = { __proto__: null, extend: r, create: a, bind: p, get lastId() {
      return g;
    }, stamp: d, throttle: _, wrapNum: v, falseFn: S, formatNum: f, trim: m, splitWords: N, setOptions: I, getParamString: E, template: H, isArray: U, indexOf: G, emptyImageUrl: re, requestFn: be, cancelFn: xe, requestAnimFrame: T, cancelAnimFrame: A };
    function Z() {
    }
    Z.extend = function(e) {
      function t() {
        I(this), this.initialize && this.initialize.apply(this, arguments), this.callInitHooks();
      }
      var u, s = t.__super__ = this.prototype, l = a(s);
      for (u in (l.constructor = t).prototype = l, this)
        Object.prototype.hasOwnProperty.call(this, u) && u !== "prototype" && u !== "__super__" && (t[u] = this[u]);
      if (e.statics && r(t, e.statics), e.includes) {
        var h = e.includes;
        if (typeof L < "u" && L && L.Mixin) {
          h = U(h) ? h : [h];
          for (var y = 0; y < h.length; y++)
            h[y] === L.Mixin.Events && console.warn("Deprecated include of L.Mixin.Events: this property will be removed in future releases, please inherit from L.Evented instead.", new Error().stack);
        }
        r.apply(null, [l].concat(e.includes));
      }
      return r(l, e), delete l.statics, delete l.includes, l.options && (l.options = s.options ? a(s.options) : {}, r(l.options, e.options)), l._initHooks = [], l.callInitHooks = function() {
        if (!this._initHooksCalled) {
          s.callInitHooks && s.callInitHooks.call(this), this._initHooksCalled = !0;
          for (var b = 0, P = l._initHooks.length; b < P; b++)
            l._initHooks[b].call(this);
        }
      }, t;
    }, Z.include = function(e) {
      var t = this.prototype.options;
      return r(this.prototype, e), e.options && (this.prototype.options = t, this.mergeOptions(e.options)), this;
    }, Z.mergeOptions = function(e) {
      return r(this.prototype.options, e), this;
    }, Z.addInitHook = function(e) {
      var t = Array.prototype.slice.call(arguments, 1), u = typeof e == "function" ? e : function() {
        this[e].apply(this, t);
      };
      return this.prototype._initHooks = this.prototype._initHooks || [], this.prototype._initHooks.push(u), this;
    };
    var x = { on: function(e, t, u) {
      if (typeof e == "object")
        for (var s in e)
          this._on(s, e[s], t);
      else
        for (var l = 0, h = (e = N(e)).length; l < h; l++)
          this._on(e[l], t, u);
      return this;
    }, off: function(e, t, u) {
      if (arguments.length)
        if (typeof e == "object")
          for (var s in e)
            this._off(s, e[s], t);
        else {
          e = N(e);
          for (var l = arguments.length === 1, h = 0, y = e.length; h < y; h++)
            l ? this._off(e[h]) : this._off(e[h], t, u);
        }
      else
        delete this._events;
      return this;
    }, _on: function(e, t, u, s) {
      typeof t != "function" ? console.warn("wrong listener type: " + typeof t) : this._listens(e, t, u) === !1 && (t = { fn: t, ctx: u = u === this ? void 0 : u }, s && (t.once = !0), this._events = this._events || {}, this._events[e] = this._events[e] || [], this._events[e].push(t));
    }, _off: function(e, t, u) {
      var s, l, h;
      if (this._events && (s = this._events[e]))
        if (arguments.length === 1) {
          if (this._firingCount)
            for (l = 0, h = s.length; l < h; l++)
              s[l].fn = S;
          delete this._events[e];
        } else
          typeof t != "function" ? console.warn("wrong listener type: " + typeof t) : (t = this._listens(e, t, u)) !== !1 && (u = s[t], this._firingCount && (u.fn = S, this._events[e] = s = s.slice()), s.splice(t, 1));
    }, fire: function(e, t, u) {
      if (this.listens(e, u)) {
        var s = r({}, t, { type: e, target: this, sourceTarget: t && t.sourceTarget || this });
        if (this._events) {
          var l = this._events[e];
          if (l) {
            this._firingCount = this._firingCount + 1 || 1;
            for (var h = 0, y = l.length; h < y; h++) {
              var b = l[h], P = b.fn;
              b.once && this.off(e, P, b.ctx), P.call(b.ctx || this, s);
            }
            this._firingCount--;
          }
        }
        u && this._propagateEvent(s);
      }
      return this;
    }, listens: function(e, t, u, s) {
      typeof e != "string" && console.warn('"string" type argument expected');
      var l = t, h = (typeof t != "function" && (s = !!t, u = l = void 0), this._events && this._events[e]);
      if (h && h.length && this._listens(e, l, u) !== !1)
        return !0;
      if (s) {
        for (var y in this._eventParents)
          if (this._eventParents[y].listens(e, t, u, s))
            return !0;
      }
      return !1;
    }, _listens: function(e, t, u) {
      if (this._events) {
        var s = this._events[e] || [];
        if (!t)
          return !!s.length;
        u === this && (u = void 0);
        for (var l = 0, h = s.length; l < h; l++)
          if (s[l].fn === t && s[l].ctx === u)
            return l;
      }
      return !1;
    }, once: function(e, t, u) {
      if (typeof e == "object")
        for (var s in e)
          this._on(s, e[s], t, !0);
      else
        for (var l = 0, h = (e = N(e)).length; l < h; l++)
          this._on(e[l], t, u, !0);
      return this;
    }, addEventParent: function(e) {
      return this._eventParents = this._eventParents || {}, this._eventParents[d(e)] = e, this;
    }, removeEventParent: function(e) {
      return this._eventParents && delete this._eventParents[d(e)], this;
    }, _propagateEvent: function(e) {
      for (var t in this._eventParents)
        this._eventParents[t].fire(e.type, r({ layer: e.target, propagatedFrom: e.target }, e), !0);
    } }, C = (x.addEventListener = x.on, x.removeEventListener = x.clearAllEventListeners = x.off, x.addOneTimeEventListener = x.once, x.fireEvent = x.fire, x.hasEventListeners = x.listens, Z.extend(x));
    function w(e, t, u) {
      this.x = u ? Math.round(e) : e, this.y = u ? Math.round(t) : t;
    }
    var R = Math.trunc || function(e) {
      return 0 < e ? Math.floor(e) : Math.ceil(e);
    };
    function M(e, t, u) {
      return e instanceof w ? e : U(e) ? new w(e[0], e[1]) : e == null ? e : typeof e == "object" && "x" in e && "y" in e ? new w(e.x, e.y) : new w(e, t, u);
    }
    function V(e, t) {
      if (e)
        for (var u = t ? [e, t] : e, s = 0, l = u.length; s < l; s++)
          this.extend(u[s]);
    }
    function pe(e, t) {
      return !e || e instanceof V ? e : new V(e, t);
    }
    function we(e, t) {
      if (e)
        for (var u = t ? [e, t] : e, s = 0, l = u.length; s < l; s++)
          this.extend(u[s]);
    }
    function F(e, t) {
      return e instanceof we ? e : new we(e, t);
    }
    function j(e, t, u) {
      if (isNaN(e) || isNaN(t))
        throw new Error("Invalid LatLng object: (" + e + ", " + t + ")");
      this.lat = +e, this.lng = +t, u !== void 0 && (this.alt = +u);
    }
    function K(e, t, u) {
      return e instanceof j ? e : U(e) && typeof e[0] != "object" ? e.length === 3 ? new j(e[0], e[1], e[2]) : e.length === 2 ? new j(e[0], e[1]) : null : e == null ? e : typeof e == "object" && "lat" in e ? new j(e.lat, "lng" in e ? e.lng : e.lon, e.alt) : t === void 0 ? null : new j(e, t, u);
    }
    w.prototype = { clone: function() {
      return new w(this.x, this.y);
    }, add: function(e) {
      return this.clone()._add(M(e));
    }, _add: function(e) {
      return this.x += e.x, this.y += e.y, this;
    }, subtract: function(e) {
      return this.clone()._subtract(M(e));
    }, _subtract: function(e) {
      return this.x -= e.x, this.y -= e.y, this;
    }, divideBy: function(e) {
      return this.clone()._divideBy(e);
    }, _divideBy: function(e) {
      return this.x /= e, this.y /= e, this;
    }, multiplyBy: function(e) {
      return this.clone()._multiplyBy(e);
    }, _multiplyBy: function(e) {
      return this.x *= e, this.y *= e, this;
    }, scaleBy: function(e) {
      return new w(this.x * e.x, this.y * e.y);
    }, unscaleBy: function(e) {
      return new w(this.x / e.x, this.y / e.y);
    }, round: function() {
      return this.clone()._round();
    }, _round: function() {
      return this.x = Math.round(this.x), this.y = Math.round(this.y), this;
    }, floor: function() {
      return this.clone()._floor();
    }, _floor: function() {
      return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this;
    }, ceil: function() {
      return this.clone()._ceil();
    }, _ceil: function() {
      return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this;
    }, trunc: function() {
      return this.clone()._trunc();
    }, _trunc: function() {
      return this.x = R(this.x), this.y = R(this.y), this;
    }, distanceTo: function(u) {
      var t = (u = M(u)).x - this.x, u = u.y - this.y;
      return Math.sqrt(t * t + u * u);
    }, equals: function(e) {
      return (e = M(e)).x === this.x && e.y === this.y;
    }, contains: function(e) {
      return e = M(e), Math.abs(e.x) <= Math.abs(this.x) && Math.abs(e.y) <= Math.abs(this.y);
    }, toString: function() {
      return "Point(" + f(this.x) + ", " + f(this.y) + ")";
    } }, V.prototype = { extend: function(e) {
      var t, u;
      if (e) {
        if (e instanceof w || typeof e[0] == "number" || "x" in e)
          t = u = M(e);
        else if (t = (e = pe(e)).min, u = e.max, !t || !u)
          return this;
        this.min || this.max ? (this.min.x = Math.min(t.x, this.min.x), this.max.x = Math.max(u.x, this.max.x), this.min.y = Math.min(t.y, this.min.y), this.max.y = Math.max(u.y, this.max.y)) : (this.min = t.clone(), this.max = u.clone());
      }
      return this;
    }, getCenter: function(e) {
      return M((this.min.x + this.max.x) / 2, (this.min.y + this.max.y) / 2, e);
    }, getBottomLeft: function() {
      return M(this.min.x, this.max.y);
    }, getTopRight: function() {
      return M(this.max.x, this.min.y);
    }, getTopLeft: function() {
      return this.min;
    }, getBottomRight: function() {
      return this.max;
    }, getSize: function() {
      return this.max.subtract(this.min);
    }, contains: function(e) {
      var t, u;
      return (e = (typeof e[0] == "number" || e instanceof w ? M : pe)(e)) instanceof V ? (t = e.min, u = e.max) : t = u = e, t.x >= this.min.x && u.x <= this.max.x && t.y >= this.min.y && u.y <= this.max.y;
    }, intersects: function(h) {
      h = pe(h);
      var t = this.min, u = this.max, s = h.min, h = h.max, l = h.x >= t.x && s.x <= u.x, h = h.y >= t.y && s.y <= u.y;
      return l && h;
    }, overlaps: function(h) {
      h = pe(h);
      var t = this.min, u = this.max, s = h.min, h = h.max, l = h.x > t.x && s.x < u.x, h = h.y > t.y && s.y < u.y;
      return l && h;
    }, isValid: function() {
      return !(!this.min || !this.max);
    }, pad: function(l) {
      var t = this.min, u = this.max, s = Math.abs(t.x - u.x) * l, l = Math.abs(t.y - u.y) * l;
      return pe(M(t.x - s, t.y - l), M(u.x + s, u.y + l));
    }, equals: function(e) {
      return !!e && (e = pe(e), this.min.equals(e.getTopLeft()) && this.max.equals(e.getBottomRight()));
    } }, we.prototype = { extend: function(e) {
      var t, u, s = this._southWest, l = this._northEast;
      if (e instanceof j)
        u = t = e;
      else {
        if (!(e instanceof we))
          return e ? this.extend(K(e) || F(e)) : this;
        if (t = e._southWest, u = e._northEast, !t || !u)
          return this;
      }
      return s || l ? (s.lat = Math.min(t.lat, s.lat), s.lng = Math.min(t.lng, s.lng), l.lat = Math.max(u.lat, l.lat), l.lng = Math.max(u.lng, l.lng)) : (this._southWest = new j(t.lat, t.lng), this._northEast = new j(u.lat, u.lng)), this;
    }, pad: function(l) {
      var t = this._southWest, u = this._northEast, s = Math.abs(t.lat - u.lat) * l, l = Math.abs(t.lng - u.lng) * l;
      return new we(new j(t.lat - s, t.lng - l), new j(u.lat + s, u.lng + l));
    }, getCenter: function() {
      return new j((this._southWest.lat + this._northEast.lat) / 2, (this._southWest.lng + this._northEast.lng) / 2);
    }, getSouthWest: function() {
      return this._southWest;
    }, getNorthEast: function() {
      return this._northEast;
    }, getNorthWest: function() {
      return new j(this.getNorth(), this.getWest());
    }, getSouthEast: function() {
      return new j(this.getSouth(), this.getEast());
    }, getWest: function() {
      return this._southWest.lng;
    }, getSouth: function() {
      return this._southWest.lat;
    }, getEast: function() {
      return this._northEast.lng;
    }, getNorth: function() {
      return this._northEast.lat;
    }, contains: function(e) {
      e = (typeof e[0] == "number" || e instanceof j || "lat" in e ? K : F)(e);
      var t, u, s = this._southWest, l = this._northEast;
      return e instanceof we ? (t = e.getSouthWest(), u = e.getNorthEast()) : t = u = e, t.lat >= s.lat && u.lat <= l.lat && t.lng >= s.lng && u.lng <= l.lng;
    }, intersects: function(h) {
      h = F(h);
      var t = this._southWest, u = this._northEast, s = h.getSouthWest(), h = h.getNorthEast(), l = h.lat >= t.lat && s.lat <= u.lat, h = h.lng >= t.lng && s.lng <= u.lng;
      return l && h;
    }, overlaps: function(h) {
      h = F(h);
      var t = this._southWest, u = this._northEast, s = h.getSouthWest(), h = h.getNorthEast(), l = h.lat > t.lat && s.lat < u.lat, h = h.lng > t.lng && s.lng < u.lng;
      return l && h;
    }, toBBoxString: function() {
      return [this.getWest(), this.getSouth(), this.getEast(), this.getNorth()].join(",");
    }, equals: function(e, t) {
      return !!e && (e = F(e), this._southWest.equals(e.getSouthWest(), t) && this._northEast.equals(e.getNorthEast(), t));
    }, isValid: function() {
      return !(!this._southWest || !this._northEast);
    } };
    var X = { latLngToPoint: function(e, t) {
      return e = this.projection.project(e), t = this.scale(t), this.transformation._transform(e, t);
    }, pointToLatLng: function(e, t) {
      return t = this.scale(t), e = this.transformation.untransform(e, t), this.projection.unproject(e);
    }, project: function(e) {
      return this.projection.project(e);
    }, unproject: function(e) {
      return this.projection.unproject(e);
    }, scale: function(e) {
      return 256 * Math.pow(2, e);
    }, zoom: function(e) {
      return Math.log(e / 256) / Math.LN2;
    }, getProjectedBounds: function(e) {
      var t;
      return this.infinite ? null : (t = this.projection.bounds, e = this.scale(e), new V(this.transformation.transform(t.min, e), this.transformation.transform(t.max, e)));
    }, infinite: !(j.prototype = { equals: function(e, t) {
      return !!e && (e = K(e), Math.max(Math.abs(this.lat - e.lat), Math.abs(this.lng - e.lng)) <= (t === void 0 ? 1e-9 : t));
    }, toString: function(e) {
      return "LatLng(" + f(this.lat, e) + ", " + f(this.lng, e) + ")";
    }, distanceTo: function(e) {
      return $.distance(this, K(e));
    }, wrap: function() {
      return $.wrapLatLng(this);
    }, toBounds: function(t) {
      var t = 180 * t / 40075017, u = t / Math.cos(Math.PI / 180 * this.lat);
      return F([this.lat - t, this.lng - u], [this.lat + t, this.lng + u]);
    }, clone: function() {
      return new j(this.lat, this.lng, this.alt);
    } }), wrapLatLng: function(e) {
      var t = this.wrapLng ? v(e.lng, this.wrapLng, !0) : e.lng;
      return new j(this.wrapLat ? v(e.lat, this.wrapLat, !0) : e.lat, t, e.alt);
    }, wrapLatLngBounds: function(e) {
      var s = e.getCenter(), t = this.wrapLatLng(s), u = s.lat - t.lat, s = s.lng - t.lng;
      return u == 0 && s == 0 ? e : (t = e.getSouthWest(), e = e.getNorthEast(), new we(new j(t.lat - u, t.lng - s), new j(e.lat - u, e.lng - s)));
    } }, $ = r({}, X, { wrapLng: [-180, 180], R: 6371e3, distance: function(y, h) {
      var b = Math.PI / 180, u = y.lat * b, s = h.lat * b, l = Math.sin((h.lat - y.lat) * b / 2), h = Math.sin((h.lng - y.lng) * b / 2), y = l * l + Math.cos(u) * Math.cos(s) * h * h, b = 2 * Math.atan2(Math.sqrt(y), Math.sqrt(1 - y));
      return this.R * b;
    } }), _e = 6378137, _e = { R: _e, MAX_LATITUDE: 85.0511287798, project: function(e) {
      var t = Math.PI / 180, u = this.MAX_LATITUDE, u = Math.max(Math.min(u, e.lat), -u), u = Math.sin(u * t);
      return new w(this.R * e.lng * t, this.R * Math.log((1 + u) / (1 - u)) / 2);
    }, unproject: function(e) {
      var t = 180 / Math.PI;
      return new j((2 * Math.atan(Math.exp(e.y / this.R)) - Math.PI / 2) * t, e.x * t / this.R);
    }, bounds: new V([-(_e = _e * Math.PI), -_e], [_e, _e]) };
    function Ee(e, t, u, s) {
      U(e) ? (this._a = e[0], this._b = e[1], this._c = e[2], this._d = e[3]) : (this._a = e, this._b = t, this._c = u, this._d = s);
    }
    function Te(e, t, u, s) {
      return new Ee(e, t, u, s);
    }
    Ee.prototype = { transform: function(e, t) {
      return this._transform(e.clone(), t);
    }, _transform: function(e, t) {
      return e.x = (t = t || 1) * (this._a * e.x + this._b), e.y = t * (this._c * e.y + this._d), e;
    }, untransform: function(e, t) {
      return new w((e.x / (t = t || 1) - this._b) / this._a, (e.y / t - this._d) / this._c);
    } };
    var We = r({}, $, { code: "EPSG:3857", projection: _e, transformation: Te(We = 0.5 / (Math.PI * _e.R), 0.5, -We, 0.5) }), At = r({}, We, { code: "EPSG:900913" });
    function Ct(e) {
      return document.createElementNS("http://www.w3.org/2000/svg", e);
    }
    function Mt(e, t) {
      for (var u, s, l, h, y = "", b = 0, P = e.length; b < P; b++) {
        for (u = 0, s = (l = e[b]).length; u < s; u++)
          y += (u ? "L" : "M") + (h = l[u]).x + " " + h.y;
        y += t ? B.svg ? "z" : "x" : "";
      }
      return y || "M0 0";
    }
    var Je = document.documentElement.style, st = "ActiveXObject" in window, hr = st && !document.addEventListener, Ie = "msLaunchUri" in navigator && !("documentMode" in document), ri = de("webkit"), Gi = de("android"), Xi = de("android 2") || de("android 3"), xt = parseInt(/WebKit\/([0-9]+)|$/.exec(navigator.userAgent)[1], 10), xt = Gi && de("Google") && xt < 537 && !("AudioNode" in window), wt = !!window.opera, Yi = !Ie && de("chrome"), Ot = de("gecko") && !ri && !wt && !st, mr = !Yi && de("safari"), Ki = de("phantom"), Ce = "OTransition" in Je, mt = navigator.platform.indexOf("Win") === 0, un = st && "transition" in Je, li = "WebKitCSSMatrix" in window && "m11" in new window.WebKitCSSMatrix() && !Xi, Je = "MozPerspective" in Je, cn = !window.L_DISABLE_3D && (un || li || Je) && !Ce && !Ki, ct = typeof orientation < "u" || de("mobile"), hn = ct && ri, dn = ct && li, hi = !window.PointerEvent && window.MSPointerEvent, di = !(!window.PointerEvent && !hi), Di = "ontouchstart" in window || !!window.TouchEvent, Gn = !window.L_NO_TOUCH && (Di || di), Bi = ct && wt, $n = ct && Ot, Xn = 1 < (window.devicePixelRatio || window.screen.deviceXDPI / window.screen.logicalXDPI), Kt = function() {
      var e = !1;
      try {
        var t = Object.defineProperty({}, "passive", { get: function() {
          e = !0;
        } });
        window.addEventListener("testPassiveEventSupport", S, t), window.removeEventListener("testPassiveEventSupport", S, t);
      } catch {
      }
      return e;
    }(), Yn = !!document.createElement("canvas").getContext, O = !(!document.createElementNS || !Ct("svg").createSVGRect), ie = !!O && ((ie = document.createElement("div")).innerHTML = "<svg/>", (ie.firstChild && ie.firstChild.namespaceURI) === "http://www.w3.org/2000/svg");
    function de(e) {
      return 0 <= navigator.userAgent.toLowerCase().indexOf(e);
    }
    var B = { ie: st, ielt9: hr, edge: Ie, webkit: ri, android: Gi, android23: Xi, androidStock: xt, opera: wt, chrome: Yi, gecko: Ot, safari: mr, phantom: Ki, opera12: Ce, win: mt, ie3d: un, webkit3d: li, gecko3d: Je, any3d: cn, mobile: ct, mobileWebkit: hn, mobileWebkit3d: dn, msPointer: hi, pointer: di, touch: Gn, touchNative: Di, mobileOpera: Bi, mobileGecko: $n, retina: Xn, passiveEvents: Kt, canvas: Yn, svg: O, vml: !O && function() {
      try {
        var e = document.createElement("div"), t = (e.innerHTML = '<v:shape adj="1"/>', e.firstChild);
        return t.style.behavior = "url(#default#VML)", t && typeof t.adj == "object";
      } catch {
        return !1;
      }
    }(), inlineSvg: ie, mac: navigator.platform.indexOf("Mac") === 0, linux: navigator.platform.indexOf("Linux") === 0 }, zi = B.msPointer ? "MSPointerDown" : "pointerdown", Jt = B.msPointer ? "MSPointerMove" : "pointermove", Ge = B.msPointer ? "MSPointerUp" : "pointerup", Ri = B.msPointer ? "MSPointerCancel" : "pointercancel", It = { touchstart: zi, touchmove: Jt, touchend: Ge, touchcancel: Ri }, ji = { touchstart: function(e, t) {
      t.MSPOINTER_TYPE_TOUCH && t.pointerType === t.MSPOINTER_TYPE_TOUCH && Pe(t), qi(e, t);
    }, touchmove: qi, touchend: qi, touchcancel: qi }, kt = {}, hu = !1;
    function Ks(e, t, u) {
      return t !== "touchstart" || hu || (document.addEventListener(zi, Js, !0), document.addEventListener(Jt, Qs, !0), document.addEventListener(Ge, du, !0), document.addEventListener(Ri, du, !0), hu = !0), ji[t] ? (u = ji[t].bind(this, u), e.addEventListener(It[t], u, !1), u) : (console.warn("wrong event specified:", t), S);
    }
    function Js(e) {
      kt[e.pointerId] = e;
    }
    function Qs(e) {
      kt[e.pointerId] && (kt[e.pointerId] = e);
    }
    function du(e) {
      delete kt[e.pointerId];
    }
    function qi(e, t) {
      if (t.pointerType !== (t.MSPOINTER_TYPE_MOUSE || "mouse")) {
        for (var u in t.touches = [], kt)
          t.touches.push(kt[u]);
        t.changedTouches = [t], e(t);
      }
    }
    var ea = 200;
    function ta(e, t) {
      e.addEventListener("dblclick", t);
      var u, s = 0;
      function l(h) {
        var y;
        h.detail !== 1 ? u = h.detail : h.pointerType === "mouse" || h.sourceCapabilities && !h.sourceCapabilities.firesTouchEvents || (y = _u(h)).some(function(b) {
          return b instanceof HTMLLabelElement && b.attributes.for;
        }) && !y.some(function(b) {
          return b instanceof HTMLInputElement || b instanceof HTMLSelectElement;
        }) || ((y = Date.now()) - s <= ea ? ++u === 2 && t(function(b) {
          var P, k, q = {};
          for (k in b)
            P = b[k], q[k] = P && P.bind ? P.bind(b) : P;
          return (b = q).type = "dblclick", q.detail = 2, q.isTrusted = !1, q._simulated = !0, q;
        }(h)) : u = 1, s = y);
      }
      return e.addEventListener("click", l), { dblclick: t, simDblclick: l };
    }
    var Kn, Nt, Qt, Zi, Fi, Jn, Qn = Vi(["transform", "webkitTransform", "OTransform", "MozTransform", "msTransform"]), ei = Vi(["webkitTransition", "transition", "OTransition", "MozTransition", "msTransition"]), fu = ei === "webkitTransition" || ei === "OTransition" ? ei + "End" : "transitionend";
    function pu(e) {
      return typeof e == "string" ? document.getElementById(e) : e;
    }
    function ti(e, t) {
      var u = e.style[t] || e.currentStyle && e.currentStyle[t];
      return (u = u && u !== "auto" || !document.defaultView ? u : (e = document.defaultView.getComputedStyle(e, null)) ? e[t] : null) === "auto" ? null : u;
    }
    function oe(e, t, u) {
      return e = document.createElement(e), e.className = t || "", u && u.appendChild(e), e;
    }
    function ge(e) {
      var t = e.parentNode;
      t && t.removeChild(e);
    }
    function Hi(e) {
      for (; e.firstChild; )
        e.removeChild(e.firstChild);
    }
    function Dt(e) {
      var t = e.parentNode;
      t && t.lastChild !== e && t.appendChild(e);
    }
    function Bt(e) {
      var t = e.parentNode;
      t && t.firstChild !== e && t.insertBefore(e, t.firstChild);
    }
    function er(e, t) {
      return e.classList !== void 0 ? e.classList.contains(t) : 0 < (e = Ui(e)).length && new RegExp("(^|\\s)" + t + "(\\s|$)").test(e);
    }
    function te(e, t) {
      var u;
      if (e.classList !== void 0)
        for (var s = N(t), l = 0, h = s.length; l < h; l++)
          e.classList.add(s[l]);
      else
        er(e, t) || tr(e, ((u = Ui(e)) ? u + " " : "") + t);
    }
    function ye(e, t) {
      e.classList !== void 0 ? e.classList.remove(t) : tr(e, m((" " + Ui(e) + " ").replace(" " + t + " ", " ")));
    }
    function tr(e, t) {
      e.className.baseVal === void 0 ? e.className = t : e.className.baseVal = t;
    }
    function Ui(e) {
      return (e = e.correspondingElement ? e.correspondingElement : e).className.baseVal === void 0 ? e.className : e.className.baseVal;
    }
    function Be(e, t) {
      if ("opacity" in e.style)
        e.style.opacity = t;
      else if ("filter" in e.style) {
        var u = !1, s = "DXImageTransform.Microsoft.Alpha";
        try {
          u = e.filters.item(s);
        } catch {
          if (t === 1)
            return;
        }
        t = Math.round(100 * t), u ? (u.Enabled = t !== 100, u.Opacity = t) : e.style.filter += " progid:" + s + "(opacity=" + t + ")";
      }
    }
    function Vi(e) {
      for (var t = document.documentElement.style, u = 0; u < e.length; u++)
        if (e[u] in t)
          return e[u];
      return !1;
    }
    function gt(e, t, u) {
      t = t || new w(0, 0), e.style[Qn] = (B.ie3d ? "translate(" + t.x + "px," + t.y + "px)" : "translate3d(" + t.x + "px," + t.y + "px,0)") + (u ? " scale(" + u + ")" : "");
    }
    function Se(e, t) {
      e._leaflet_pos = t, B.any3d ? gt(e, t) : (e.style.left = t.x + "px", e.style.top = t.y + "px");
    }
    function _t(e) {
      return e._leaflet_pos || new w(0, 0);
    }
    function ir() {
      Y(window, "dragstart", Pe);
    }
    function nr() {
      ce(window, "dragstart", Pe);
    }
    function rr(e) {
      for (; e.tabIndex === -1; )
        e = e.parentNode;
      e.style && (Wi(), Jn = (Fi = e).style.outlineStyle, e.style.outlineStyle = "none", Y(window, "keydown", Wi));
    }
    function Wi() {
      Fi && (Fi.style.outlineStyle = Jn, Jn = Fi = void 0, ce(window, "keydown", Wi));
    }
    function mu(e) {
      for (; !((e = e.parentNode).offsetWidth && e.offsetHeight || e === document.body); )
        ;
      return e;
    }
    function ur(e) {
      var t = e.getBoundingClientRect();
      return { x: t.width / e.offsetWidth || 1, y: t.height / e.offsetHeight || 1, boundingClientRect: t };
    }
    Zi = "onselectstart" in document ? (Qt = function() {
      Y(window, "selectstart", Pe);
    }, function() {
      ce(window, "selectstart", Pe);
    }) : (Nt = Vi(["userSelect", "WebkitUserSelect", "OUserSelect", "MozUserSelect", "msUserSelect"]), Qt = function() {
      var e;
      Nt && (e = document.documentElement.style, Kn = e[Nt], e[Nt] = "none");
    }, function() {
      Nt && (document.documentElement.style[Nt] = Kn, Kn = void 0);
    }), st = { __proto__: null, TRANSFORM: Qn, TRANSITION: ei, TRANSITION_END: fu, get: pu, getStyle: ti, create: oe, remove: ge, empty: Hi, toFront: Dt, toBack: Bt, hasClass: er, addClass: te, removeClass: ye, setClass: tr, getClass: Ui, setOpacity: Be, testProp: Vi, setTransform: gt, setPosition: Se, getPosition: _t, get disableTextSelection() {
      return Qt;
    }, get enableTextSelection() {
      return Zi;
    }, disableImageDrag: ir, enableImageDrag: nr, preventOutline: rr, restoreOutline: Wi, getSizedParentNode: mu, getScale: ur };
    function Y(e, t, u, s) {
      if (t && typeof t == "object")
        for (var l in t)
          sr(e, l, t[l], u);
      else
        for (var h = 0, y = (t = N(t)).length; h < y; h++)
          sr(e, t[h], u, s);
      return this;
    }
    var Ze = "_leaflet_events";
    function ce(e, t, u, s) {
      if (arguments.length === 1)
        gu(e), delete e[Ze];
      else if (t && typeof t == "object")
        for (var l in t)
          ar(e, l, t[l], u);
      else if (t = N(t), arguments.length === 2)
        gu(e, function(b) {
          return G(t, b) !== -1;
        });
      else
        for (var h = 0, y = t.length; h < y; h++)
          ar(e, t[h], u, s);
      return this;
    }
    function gu(e, t) {
      for (var u in e[Ze]) {
        var s = u.split(/\d/)[0];
        t && !t(s) || ar(e, s, null, null, u);
      }
    }
    var or = { mouseenter: "mouseover", mouseleave: "mouseout", wheel: !("onwheel" in window) && "mousewheel" };
    function sr(e, t, u, s) {
      var l, h, y = t + d(u) + (s ? "_" + d(s) : "");
      e[Ze] && e[Ze][y] || (h = l = function(b) {
        return u.call(s || e, b || window.event);
      }, !B.touchNative && B.pointer && t.indexOf("touch") === 0 ? l = Ks(e, t, l) : B.touch && t === "dblclick" ? l = ta(e, l) : "addEventListener" in e ? t === "touchstart" || t === "touchmove" || t === "wheel" || t === "mousewheel" ? e.addEventListener(or[t] || t, l, !!B.passiveEvents && { passive: !1 }) : t === "mouseenter" || t === "mouseleave" ? e.addEventListener(or[t], l = function(b) {
        b = b || window.event, cr(e, b) && h(b);
      }, !1) : e.addEventListener(t, h, !1) : e.attachEvent("on" + t, l), e[Ze] = e[Ze] || {}, e[Ze][y] = l);
    }
    function ar(e, t, b, s, l) {
      l = l || t + d(b) + (s ? "_" + d(s) : "");
      var h, y, b = e[Ze] && e[Ze][l];
      b && (!B.touchNative && B.pointer && t.indexOf("touch") === 0 ? (s = e, y = b, It[h = t] ? s.removeEventListener(It[h], y, !1) : console.warn("wrong event specified:", h)) : B.touch && t === "dblclick" ? (s = b, (y = e).removeEventListener("dblclick", s.dblclick), y.removeEventListener("click", s.simDblclick)) : "removeEventListener" in e ? e.removeEventListener(or[t] || t, b, !1) : e.detachEvent("on" + t, b), e[Ze][l] = null);
    }
    function bt(e) {
      return e.stopPropagation ? e.stopPropagation() : e.originalEvent ? e.originalEvent._stopped = !0 : e.cancelBubble = !0, this;
    }
    function lr(e) {
      return sr(e, "wheel", bt), this;
    }
    function ii(e) {
      return Y(e, "mousedown touchstart dblclick contextmenu", bt), e._leaflet_disable_click = !0, this;
    }
    function Pe(e) {
      return e.preventDefault ? e.preventDefault() : e.returnValue = !1, this;
    }
    function yt(e) {
      return Pe(e), bt(e), this;
    }
    function _u(e) {
      if (e.composedPath)
        return e.composedPath();
      for (var t = [], u = e.target; u; )
        t.push(u), u = u.parentNode;
      return t;
    }
    function bu(e, t) {
      var u, s;
      return t ? (s = (u = ur(t)).boundingClientRect, new w((e.clientX - s.left) / u.x - t.clientLeft, (e.clientY - s.top) / u.y - t.clientTop)) : new w(e.clientX, e.clientY);
    }
    var ia = B.linux && B.chrome ? window.devicePixelRatio : B.mac ? 3 * window.devicePixelRatio : 0 < window.devicePixelRatio ? 2 * window.devicePixelRatio : 1;
    function yu(e) {
      return B.edge ? e.wheelDeltaY / 2 : e.deltaY && e.deltaMode === 0 ? -e.deltaY / ia : e.deltaY && e.deltaMode === 1 ? 20 * -e.deltaY : e.deltaY && e.deltaMode === 2 ? 60 * -e.deltaY : e.deltaX || e.deltaZ ? 0 : e.wheelDelta ? (e.wheelDeltaY || e.wheelDelta) / 2 : e.detail && Math.abs(e.detail) < 32765 ? 20 * -e.detail : e.detail ? e.detail / -32765 * 60 : 0;
    }
    function cr(e, t) {
      var u = t.relatedTarget;
      if (!u)
        return !0;
      try {
        for (; u && u !== e; )
          u = u.parentNode;
      } catch {
        return !1;
      }
      return u !== e;
    }
    var hr = { __proto__: null, on: Y, off: ce, stopPropagation: bt, disableScrollPropagation: lr, disableClickPropagation: ii, preventDefault: Pe, stop: yt, getPropagationPath: _u, getMousePosition: bu, getWheelDelta: yu, isExternalTarget: cr, addListener: Y, removeListener: ce }, vu = C.extend({ run: function(e, t, u, s) {
      this.stop(), this._el = e, this._inProgress = !0, this._duration = u || 0.25, this._easeOutPower = 1 / Math.max(s || 0.5, 0.2), this._startPos = _t(e), this._offset = t.subtract(this._startPos), this._startTime = +/* @__PURE__ */ new Date(), this.fire("start"), this._animate();
    }, stop: function() {
      this._inProgress && (this._step(!0), this._complete());
    }, _animate: function() {
      this._animId = T(this._animate, this), this._step();
    }, _step: function(e) {
      var t = +/* @__PURE__ */ new Date() - this._startTime, u = 1e3 * this._duration;
      t < u ? this._runFrame(this._easeOut(t / u), e) : (this._runFrame(1), this._complete());
    }, _runFrame: function(e, t) {
      e = this._startPos.add(this._offset.multiplyBy(e)), t && e._round(), Se(this._el, e), this.fire("step");
    }, _complete: function() {
      A(this._animId), this._inProgress = !1, this.fire("end");
    }, _easeOut: function(e) {
      return 1 - Math.pow(1 - e, this._easeOutPower);
    } }), ue = C.extend({ options: { crs: We, center: void 0, zoom: void 0, minZoom: void 0, maxZoom: void 0, layers: [], maxBounds: void 0, renderer: void 0, zoomAnimation: !0, zoomAnimationThreshold: 4, fadeAnimation: !0, markerZoomAnimation: !0, transform3DLimit: 8388608, zoomSnap: 1, zoomDelta: 1, trackResize: !0 }, initialize: function(e, t) {
      t = I(this, t), this._handlers = [], this._layers = {}, this._zoomBoundLayers = {}, this._sizeChanged = !0, this._initContainer(e), this._initLayout(), this._onResize = p(this._onResize, this), this._initEvents(), t.maxBounds && this.setMaxBounds(t.maxBounds), t.zoom !== void 0 && (this._zoom = this._limitZoom(t.zoom)), t.center && t.zoom !== void 0 && this.setView(K(t.center), t.zoom, { reset: !0 }), this.callInitHooks(), this._zoomAnimated = ei && B.any3d && !B.mobileOpera && this.options.zoomAnimation, this._zoomAnimated && (this._createAnimProxy(), Y(this._proxy, fu, this._catchTransitionEnd, this)), this._addLayers(this.options.layers);
    }, setView: function(e, t, u) {
      return t = t === void 0 ? this._zoom : this._limitZoom(t), e = this._limitCenter(K(e), t, this.options.maxBounds), u = u || {}, this._stop(), this._loaded && !u.reset && u !== !0 && (u.animate !== void 0 && (u.zoom = r({ animate: u.animate }, u.zoom), u.pan = r({ animate: u.animate, duration: u.duration }, u.pan)), this._zoom !== t ? this._tryAnimatedZoom && this._tryAnimatedZoom(e, t, u.zoom) : this._tryAnimatedPan(e, u.pan)) ? (clearTimeout(this._sizeTimer), this) : (this._resetView(e, t, u.pan && u.pan.noMoveStart), this);
    }, setZoom: function(e, t) {
      return this._loaded ? this.setView(this.getCenter(), e, { zoom: t }) : (this._zoom = e, this);
    }, zoomIn: function(e, t) {
      return e = e || (B.any3d ? this.options.zoomDelta : 1), this.setZoom(this._zoom + e, t);
    }, zoomOut: function(e, t) {
      return e = e || (B.any3d ? this.options.zoomDelta : 1), this.setZoom(this._zoom - e, t);
    }, setZoomAround: function(l, t, u) {
      var h = this.getZoomScale(t), s = this.getSize().divideBy(2), l = (l instanceof w ? l : this.latLngToContainerPoint(l)).subtract(s).multiplyBy(1 - 1 / h), h = this.containerPointToLatLng(s.add(l));
      return this.setView(h, t, { zoom: u });
    }, _getBoundsCenterZoom: function(e, t) {
      t = t || {}, e = e.getBounds ? e.getBounds() : F(e);
      var u = M(t.paddingTopLeft || t.padding || [0, 0]), s = M(t.paddingBottomRight || t.padding || [0, 0]), l = this.getBoundsZoom(e, !1, u.add(s));
      return (l = typeof t.maxZoom == "number" ? Math.min(t.maxZoom, l) : l) === 1 / 0 ? { center: e.getCenter(), zoom: l } : (t = s.subtract(u).divideBy(2), s = this.project(e.getSouthWest(), l), u = this.project(e.getNorthEast(), l), { center: this.unproject(s.add(u).divideBy(2).add(t), l), zoom: l });
    }, fitBounds: function(e, t) {
      if ((e = F(e)).isValid())
        return e = this._getBoundsCenterZoom(e, t), this.setView(e.center, e.zoom, t);
      throw new Error("Bounds are not valid.");
    }, fitWorld: function(e) {
      return this.fitBounds([[-90, -180], [90, 180]], e);
    }, panTo: function(e, t) {
      return this.setView(e, this._zoom, { pan: t });
    }, panBy: function(e, t) {
      var u;
      return t = t || {}, (e = M(e).round()).x || e.y ? (t.animate === !0 || this.getSize().contains(e) ? (this._panAnim || (this._panAnim = new vu(), this._panAnim.on({ step: this._onPanTransitionStep, end: this._onPanTransitionEnd }, this)), t.noMoveStart || this.fire("movestart"), t.animate !== !1 ? (te(this._mapPane, "leaflet-pan-anim"), u = this._getMapPanePos().subtract(e).round(), this._panAnim.run(this._mapPane, u, t.duration || 0.25, t.easeLinearity)) : (this._rawPanBy(e), this.fire("move").fire("moveend"))) : this._resetView(this.unproject(this.project(this.getCenter()).add(e)), this.getZoom()), this) : this.fire("moveend");
    }, flyTo: function(e, t, u) {
      if ((u = u || {}).animate === !1 || !B.any3d)
        return this.setView(e, t, u);
      this._stop();
      var s = this.project(this.getCenter()), l = this.project(e), h = this.getSize(), y = this._zoom, b = (e = K(e), t = t === void 0 ? y : t, Math.max(h.x, h.y)), P = b * this.getZoomScale(y, t), k = l.distanceTo(s) || 1, q = 1.42, J = q * q;
      function Q(ve) {
        return ve = (P * P - b * b + (ve ? -1 : 1) * J * J * k * k) / (2 * (ve ? P : b) * J * k), ve = Math.sqrt(ve * ve + 1) - ve, ve < 1e-9 ? -18 : Math.log(ve);
      }
      function me(ve) {
        return (Math.exp(ve) - Math.exp(-ve)) / 2;
      }
      function ke(ve) {
        return (Math.exp(ve) + Math.exp(-ve)) / 2;
      }
      var Ae = Q(0);
      function Ne(ve) {
        return b * (ke(Ae) * (me(ve = Ae + q * ve) / ke(ve)) - me(Ae)) / J;
      }
      var ra = Date.now(), Vu = (Q(1) - Ae) / q, ua = u.duration ? 1e3 * u.duration : 1e3 * Vu * 0.8;
      return this._moveStart(!0, u.noMoveStart), (function ve() {
        var fn = (Date.now() - ra) / ua, Wu = (1 - Math.pow(1 - fn, 1.5)) * Vu;
        fn <= 1 ? (this._flyToFrame = T(ve, this), this._move(this.unproject(s.add(l.subtract(s).multiplyBy(Ne(Wu) / k)), y), this.getScaleZoom(b / (fn = Wu, b * (ke(Ae) / ke(Ae + q * fn))), y), { flyTo: !0 })) : this._move(e, t)._moveEnd(!0);
      }).call(this), this;
    }, flyToBounds: function(e, t) {
      return e = this._getBoundsCenterZoom(e, t), this.flyTo(e.center, e.zoom, t);
    }, setMaxBounds: function(e) {
      return e = F(e), this.listens("moveend", this._panInsideMaxBounds) && this.off("moveend", this._panInsideMaxBounds), e.isValid() ? (this.options.maxBounds = e, this._loaded && this._panInsideMaxBounds(), this.on("moveend", this._panInsideMaxBounds)) : (this.options.maxBounds = null, this);
    }, setMinZoom: function(e) {
      var t = this.options.minZoom;
      return this.options.minZoom = e, this._loaded && t !== e && (this.fire("zoomlevelschange"), this.getZoom() < this.options.minZoom) ? this.setZoom(e) : this;
    }, setMaxZoom: function(e) {
      var t = this.options.maxZoom;
      return this.options.maxZoom = e, this._loaded && t !== e && (this.fire("zoomlevelschange"), this.getZoom() > this.options.maxZoom) ? this.setZoom(e) : this;
    }, panInsideBounds: function(s, t) {
      this._enforcingBounds = !0;
      var u = this.getCenter(), s = this._limitCenter(u, this._zoom, F(s));
      return u.equals(s) || this.panTo(s, t), this._enforcingBounds = !1, this;
    }, panInside: function(l, t) {
      var h = M((t = t || {}).paddingTopLeft || t.padding || [0, 0]), u = M(t.paddingBottomRight || t.padding || [0, 0]), s = this.project(this.getCenter()), l = this.project(l), y = this.getPixelBounds(), h = pe([y.min.add(h), y.max.subtract(u)]), y = h.getSize();
      return h.contains(l) || (this._enforcingBounds = !0, u = l.subtract(h.getCenter()), h = h.extend(l).getSize().subtract(y), s.x += u.x < 0 ? -h.x : h.x, s.y += u.y < 0 ? -h.y : h.y, this.panTo(this.unproject(s), t), this._enforcingBounds = !1), this;
    }, invalidateSize: function(e) {
      if (!this._loaded)
        return this;
      e = r({ animate: !1, pan: !0 }, e === !0 ? { animate: !0 } : e);
      var t = this.getSize(), u = (this._sizeChanged = !0, this._lastCenter = null, this.getSize()), l = t.divideBy(2).round(), s = u.divideBy(2).round(), l = l.subtract(s);
      return l.x || l.y ? (e.animate && e.pan ? this.panBy(l) : (e.pan && this._rawPanBy(l), this.fire("move"), e.debounceMoveend ? (clearTimeout(this._sizeTimer), this._sizeTimer = setTimeout(p(this.fire, this, "moveend"), 200)) : this.fire("moveend")), this.fire("resize", { oldSize: t, newSize: u })) : this;
    }, stop: function() {
      return this.setZoom(this._limitZoom(this._zoom)), this.options.zoomSnap || this.fire("viewreset"), this._stop();
    }, locate: function(e) {
      var t, u;
      return e = this._locateOptions = r({ timeout: 1e4, watch: !1 }, e), "geolocation" in navigator ? (t = p(this._handleGeolocationResponse, this), u = p(this._handleGeolocationError, this), e.watch ? this._locationWatchId = navigator.geolocation.watchPosition(t, u, e) : navigator.geolocation.getCurrentPosition(t, u, e)) : this._handleGeolocationError({ code: 0, message: "Geolocation not supported." }), this;
    }, stopLocate: function() {
      return navigator.geolocation && navigator.geolocation.clearWatch && navigator.geolocation.clearWatch(this._locationWatchId), this._locateOptions && (this._locateOptions.setView = !1), this;
    }, _handleGeolocationError: function(e) {
      var t;
      this._container._leaflet_id && (t = e.code, e = e.message || (t === 1 ? "permission denied" : t === 2 ? "position unavailable" : "timeout"), this._locateOptions.setView && !this._loaded && this.fitWorld(), this.fire("locationerror", { code: t, message: "Geolocation error: " + e + "." }));
    }, _handleGeolocationResponse: function(e) {
      if (this._container._leaflet_id) {
        var t, u, s = new j(e.coords.latitude, e.coords.longitude), l = s.toBounds(2 * e.coords.accuracy), h = this._locateOptions, y = (h.setView && (t = this.getBoundsZoom(l), this.setView(s, h.maxZoom ? Math.min(t, h.maxZoom) : t)), { latlng: s, bounds: l, timestamp: e.timestamp });
        for (u in e.coords)
          typeof e.coords[u] == "number" && (y[u] = e.coords[u]);
        this.fire("locationfound", y);
      }
    }, addHandler: function(e, t) {
      return t && (t = this[e] = new t(this), this._handlers.push(t), this.options[e] && t.enable()), this;
    }, remove: function() {
      if (this._initEvents(!0), this.options.maxBounds && this.off("moveend", this._panInsideMaxBounds), this._containerId !== this._container._leaflet_id)
        throw new Error("Map container is being reused by another instance");
      try {
        delete this._container._leaflet_id, delete this._containerId;
      } catch {
        this._container._leaflet_id = void 0, this._containerId = void 0;
      }
      for (var e in this._locationWatchId !== void 0 && this.stopLocate(), this._stop(), ge(this._mapPane), this._clearControlPos && this._clearControlPos(), this._resizeRequest && (A(this._resizeRequest), this._resizeRequest = null), this._clearHandlers(), this._loaded && this.fire("unload"), this._layers)
        this._layers[e].remove();
      for (e in this._panes)
        ge(this._panes[e]);
      return this._layers = [], this._panes = [], delete this._mapPane, delete this._renderer, this;
    }, createPane: function(e, t) {
      return t = oe("div", "leaflet-pane" + (e ? " leaflet-" + e.replace("Pane", "") + "-pane" : ""), t || this._mapPane), e && (this._panes[e] = t), t;
    }, getCenter: function() {
      return this._checkIfLoaded(), this._lastCenter && !this._moved() ? this._lastCenter.clone() : this.layerPointToLatLng(this._getCenterLayerPoint());
    }, getZoom: function() {
      return this._zoom;
    }, getBounds: function() {
      var e = this.getPixelBounds();
      return new we(this.unproject(e.getBottomLeft()), this.unproject(e.getTopRight()));
    }, getMinZoom: function() {
      return this.options.minZoom === void 0 ? this._layersMinZoom || 0 : this.options.minZoom;
    }, getMaxZoom: function() {
      return this.options.maxZoom === void 0 ? this._layersMaxZoom === void 0 ? 1 / 0 : this._layersMaxZoom : this.options.maxZoom;
    }, getBoundsZoom: function(P, t, b) {
      P = F(P), b = M(b || [0, 0]);
      var k = this.getZoom() || 0, s = this.getMinZoom(), l = this.getMaxZoom(), h = P.getNorthWest(), P = P.getSouthEast(), b = this.getSize().subtract(b), P = pe(this.project(P, k), this.project(h, k)).getSize(), h = B.any3d ? this.options.zoomSnap : 1, y = b.x / P.x, b = b.y / P.y, P = t ? Math.max(y, b) : Math.min(y, b), k = this.getScaleZoom(P, k);
      return h && (k = Math.round(k / (h / 100)) * (h / 100), k = t ? Math.ceil(k / h) * h : Math.floor(k / h) * h), Math.max(s, Math.min(l, k));
    }, getSize: function() {
      return this._size && !this._sizeChanged || (this._size = new w(this._container.clientWidth || 0, this._container.clientHeight || 0), this._sizeChanged = !1), this._size.clone();
    }, getPixelBounds: function(e, t) {
      return e = this._getTopLeftPoint(e, t), new V(e, e.add(this.getSize()));
    }, getPixelOrigin: function() {
      return this._checkIfLoaded(), this._pixelOrigin;
    }, getPixelWorldBounds: function(e) {
      return this.options.crs.getProjectedBounds(e === void 0 ? this.getZoom() : e);
    }, getPane: function(e) {
      return typeof e == "string" ? this._panes[e] : e;
    }, getPanes: function() {
      return this._panes;
    }, getContainer: function() {
      return this._container;
    }, getZoomScale: function(e, t) {
      var u = this.options.crs;
      return t = t === void 0 ? this._zoom : t, u.scale(e) / u.scale(t);
    }, getScaleZoom: function(s, t) {
      var u = this.options.crs, s = (t = t === void 0 ? this._zoom : t, u.zoom(s * u.scale(t)));
      return isNaN(s) ? 1 / 0 : s;
    }, project: function(e, t) {
      return t = t === void 0 ? this._zoom : t, this.options.crs.latLngToPoint(K(e), t);
    }, unproject: function(e, t) {
      return t = t === void 0 ? this._zoom : t, this.options.crs.pointToLatLng(M(e), t);
    }, layerPointToLatLng: function(e) {
      return e = M(e).add(this.getPixelOrigin()), this.unproject(e);
    }, latLngToLayerPoint: function(e) {
      return this.project(K(e))._round()._subtract(this.getPixelOrigin());
    }, wrapLatLng: function(e) {
      return this.options.crs.wrapLatLng(K(e));
    }, wrapLatLngBounds: function(e) {
      return this.options.crs.wrapLatLngBounds(F(e));
    }, distance: function(e, t) {
      return this.options.crs.distance(K(e), K(t));
    }, containerPointToLayerPoint: function(e) {
      return M(e).subtract(this._getMapPanePos());
    }, layerPointToContainerPoint: function(e) {
      return M(e).add(this._getMapPanePos());
    }, containerPointToLatLng: function(e) {
      return e = this.containerPointToLayerPoint(M(e)), this.layerPointToLatLng(e);
    }, latLngToContainerPoint: function(e) {
      return this.layerPointToContainerPoint(this.latLngToLayerPoint(K(e)));
    }, mouseEventToContainerPoint: function(e) {
      return bu(e, this._container);
    }, mouseEventToLayerPoint: function(e) {
      return this.containerPointToLayerPoint(this.mouseEventToContainerPoint(e));
    }, mouseEventToLatLng: function(e) {
      return this.layerPointToLatLng(this.mouseEventToLayerPoint(e));
    }, _initContainer: function(e) {
      if (e = this._container = pu(e), !e)
        throw new Error("Map container not found.");
      if (e._leaflet_id)
        throw new Error("Map container is already initialized.");
      Y(e, "scroll", this._onScroll, this), this._containerId = d(e);
    }, _initLayout: function() {
      var e = this._container, t = (this._fadeAnimated = this.options.fadeAnimation && B.any3d, te(e, "leaflet-container" + (B.touch ? " leaflet-touch" : "") + (B.retina ? " leaflet-retina" : "") + (B.ielt9 ? " leaflet-oldie" : "") + (B.safari ? " leaflet-safari" : "") + (this._fadeAnimated ? " leaflet-fade-anim" : "")), ti(e, "position"));
      t !== "absolute" && t !== "relative" && t !== "fixed" && t !== "sticky" && (e.style.position = "relative"), this._initPanes(), this._initControlPos && this._initControlPos();
    }, _initPanes: function() {
      var e = this._panes = {};
      this._paneRenderers = {}, this._mapPane = this.createPane("mapPane", this._container), Se(this._mapPane, new w(0, 0)), this.createPane("tilePane"), this.createPane("overlayPane"), this.createPane("shadowPane"), this.createPane("markerPane"), this.createPane("tooltipPane"), this.createPane("popupPane"), this.options.markerZoomAnimation || (te(e.markerPane, "leaflet-zoom-hide"), te(e.shadowPane, "leaflet-zoom-hide"));
    }, _resetView: function(e, t, u) {
      Se(this._mapPane, new w(0, 0));
      var s = !this._loaded, l = (this._loaded = !0, t = this._limitZoom(t), this.fire("viewprereset"), this._zoom !== t);
      this._moveStart(l, u)._move(e, t)._moveEnd(l), this.fire("viewreset"), s && this.fire("load");
    }, _moveStart: function(e, t) {
      return e && this.fire("zoomstart"), t || this.fire("movestart"), this;
    }, _move: function(e, t, u, s) {
      t === void 0 && (t = this._zoom);
      var l = this._zoom !== t;
      return this._zoom = t, this._lastCenter = e, this._pixelOrigin = this._getNewPixelOrigin(e), s ? u && u.pinch && this.fire("zoom", u) : ((l || u && u.pinch) && this.fire("zoom", u), this.fire("move", u)), this;
    }, _moveEnd: function(e) {
      return e && this.fire("zoomend"), this.fire("moveend");
    }, _stop: function() {
      return A(this._flyToFrame), this._panAnim && this._panAnim.stop(), this;
    }, _rawPanBy: function(e) {
      Se(this._mapPane, this._getMapPanePos().subtract(e));
    }, _getZoomSpan: function() {
      return this.getMaxZoom() - this.getMinZoom();
    }, _panInsideMaxBounds: function() {
      this._enforcingBounds || this.panInsideBounds(this.options.maxBounds);
    }, _checkIfLoaded: function() {
      if (!this._loaded)
        throw new Error("Set map center and zoom first.");
    }, _initEvents: function(e) {
      this._targets = {};
      var t = e ? ce : Y;
      t((this._targets[d(this._container)] = this)._container, "click dblclick mousedown mouseup mouseover mouseout mousemove contextmenu keypress keydown keyup", this._handleDOMEvent, this), this.options.trackResize && t(window, "resize", this._onResize, this), B.any3d && this.options.transform3DLimit && (e ? this.off : this.on).call(this, "moveend", this._onMoveEnd);
    }, _onResize: function() {
      A(this._resizeRequest), this._resizeRequest = T(function() {
        this.invalidateSize({ debounceMoveend: !0 });
      }, this);
    }, _onScroll: function() {
      this._container.scrollTop = 0, this._container.scrollLeft = 0;
    }, _onMoveEnd: function() {
      var e = this._getMapPanePos();
      Math.max(Math.abs(e.x), Math.abs(e.y)) >= this.options.transform3DLimit && this._resetView(this.getCenter(), this.getZoom());
    }, _findEventTargets: function(e, t) {
      for (var u, s = [], l = t === "mouseout" || t === "mouseover", h = e.target || e.srcElement, y = !1; h; ) {
        if ((u = this._targets[d(h)]) && (t === "click" || t === "preclick") && this._draggableMoved(u)) {
          y = !0;
          break;
        }
        if (u && u.listens(t, !0) && (l && !cr(h, e) || (s.push(u), l)) || h === this._container)
          break;
        h = h.parentNode;
      }
      return s = s.length || y || l || !this.listens(t, !0) ? s : [this];
    }, _isClickDisabled: function(e) {
      for (; e && e !== this._container; ) {
        if (e._leaflet_disable_click)
          return !0;
        e = e.parentNode;
      }
    }, _handleDOMEvent: function(e) {
      var t, u = e.target || e.srcElement;
      !this._loaded || u._leaflet_disable_events || e.type === "click" && this._isClickDisabled(u) || ((t = e.type) === "mousedown" && rr(u), this._fireDOMEvent(e, t));
    }, _mouseEvents: ["click", "dblclick", "mouseover", "mouseout", "contextmenu"], _fireDOMEvent: function(e, t, u) {
      e.type === "click" && ((b = r({}, e)).type = "preclick", this._fireDOMEvent(b, b.type, u));
      var s = this._findEventTargets(e, t);
      if (u) {
        for (var l = [], h = 0; h < u.length; h++)
          u[h].listens(t, !0) && l.push(u[h]);
        s = l.concat(s);
      }
      if (s.length) {
        t === "contextmenu" && Pe(e);
        var y, b = s[0], P = { originalEvent: e };
        for (e.type !== "keypress" && e.type !== "keydown" && e.type !== "keyup" && (y = b.getLatLng && (!b._radius || b._radius <= 10), P.containerPoint = y ? this.latLngToContainerPoint(b.getLatLng()) : this.mouseEventToContainerPoint(e), P.layerPoint = this.containerPointToLayerPoint(P.containerPoint), P.latlng = y ? b.getLatLng() : this.layerPointToLatLng(P.layerPoint)), h = 0; h < s.length; h++)
          if (s[h].fire(t, P, !0), P.originalEvent._stopped || s[h].options.bubblingMouseEvents === !1 && G(this._mouseEvents, t) !== -1)
            return;
      }
    }, _draggableMoved: function(e) {
      return (e = e.dragging && e.dragging.enabled() ? e : this).dragging && e.dragging.moved() || this.boxZoom && this.boxZoom.moved();
    }, _clearHandlers: function() {
      for (var e = 0, t = this._handlers.length; e < t; e++)
        this._handlers[e].disable();
    }, whenReady: function(e, t) {
      return this._loaded ? e.call(t || this, { target: this }) : this.on("load", e, t), this;
    }, _getMapPanePos: function() {
      return _t(this._mapPane) || new w(0, 0);
    }, _moved: function() {
      var e = this._getMapPanePos();
      return e && !e.equals([0, 0]);
    }, _getTopLeftPoint: function(e, t) {
      return (e && t !== void 0 ? this._getNewPixelOrigin(e, t) : this.getPixelOrigin()).subtract(this._getMapPanePos());
    }, _getNewPixelOrigin: function(e, t) {
      var u = this.getSize()._divideBy(2);
      return this.project(e, t)._subtract(u)._add(this._getMapPanePos())._round();
    }, _latLngToNewLayerPoint: function(e, t, u) {
      return u = this._getNewPixelOrigin(u, t), this.project(e, t)._subtract(u);
    }, _latLngBoundsToNewLayerBounds: function(e, t, u) {
      return u = this._getNewPixelOrigin(u, t), pe([this.project(e.getSouthWest(), t)._subtract(u), this.project(e.getNorthWest(), t)._subtract(u), this.project(e.getSouthEast(), t)._subtract(u), this.project(e.getNorthEast(), t)._subtract(u)]);
    }, _getCenterLayerPoint: function() {
      return this.containerPointToLayerPoint(this.getSize()._divideBy(2));
    }, _getCenterOffset: function(e) {
      return this.latLngToLayerPoint(e).subtract(this._getCenterLayerPoint());
    }, _limitCenter: function(e, t, u) {
      var s, l;
      return !u || (s = this.project(e, t), l = this.getSize().divideBy(2), l = new V(s.subtract(l), s.add(l)), l = this._getBoundsOffset(l, u, t), Math.abs(l.x) <= 1 && Math.abs(l.y) <= 1) ? e : this.unproject(s.add(l), t);
    }, _limitOffset: function(e, t) {
      var u;
      return t ? (u = new V((u = this.getPixelBounds()).min.add(e), u.max.add(e)), e.add(this._getBoundsOffset(u, t))) : e;
    }, _getBoundsOffset: function(e, t, u) {
      return t = pe(this.project(t.getNorthEast(), u), this.project(t.getSouthWest(), u)), u = t.min.subtract(e.min), t = t.max.subtract(e.max), new w(this._rebound(u.x, -t.x), this._rebound(u.y, -t.y));
    }, _rebound: function(e, t) {
      return 0 < e + t ? Math.round(e - t) / 2 : Math.max(0, Math.ceil(e)) - Math.max(0, Math.floor(t));
    }, _limitZoom: function(e) {
      var t = this.getMinZoom(), u = this.getMaxZoom(), s = B.any3d ? this.options.zoomSnap : 1;
      return s && (e = Math.round(e / s) * s), Math.max(t, Math.min(u, e));
    }, _onPanTransitionStep: function() {
      this.fire("move");
    }, _onPanTransitionEnd: function() {
      ye(this._mapPane, "leaflet-pan-anim"), this.fire("moveend");
    }, _tryAnimatedPan: function(e, t) {
      return e = this._getCenterOffset(e)._trunc(), !((t && t.animate) !== !0 && !this.getSize().contains(e)) && (this.panBy(e, t), !0);
    }, _createAnimProxy: function() {
      var e = this._proxy = oe("div", "leaflet-proxy leaflet-zoom-animated");
      this._panes.mapPane.appendChild(e), this.on("zoomanim", function(t) {
        var u = Qn, s = this._proxy.style[u];
        gt(this._proxy, this.project(t.center, t.zoom), this.getZoomScale(t.zoom, 1)), s === this._proxy.style[u] && this._animatingZoom && this._onZoomTransitionEnd();
      }, this), this.on("load moveend", this._animMoveEnd, this), this._on("unload", this._destroyAnimProxy, this);
    }, _destroyAnimProxy: function() {
      ge(this._proxy), this.off("load moveend", this._animMoveEnd, this), delete this._proxy;
    }, _animMoveEnd: function() {
      var e = this.getCenter(), t = this.getZoom();
      gt(this._proxy, this.project(e, t), this.getZoomScale(t, 1));
    }, _catchTransitionEnd: function(e) {
      this._animatingZoom && 0 <= e.propertyName.indexOf("transform") && this._onZoomTransitionEnd();
    }, _nothingToAnimate: function() {
      return !this._container.getElementsByClassName("leaflet-zoom-animated").length;
    }, _tryAnimatedZoom: function(e, t, u) {
      if (!this._animatingZoom) {
        if (u = u || {}, !this._zoomAnimated || u.animate === !1 || this._nothingToAnimate() || Math.abs(t - this._zoom) > this.options.zoomAnimationThreshold)
          return !1;
        var s = this.getZoomScale(t), s = this._getCenterOffset(e)._divideBy(1 - 1 / s);
        if (u.animate !== !0 && !this.getSize().contains(s))
          return !1;
        T(function() {
          this._moveStart(!0, u.noMoveStart || !1)._animateZoom(e, t, !0);
        }, this);
      }
      return !0;
    }, _animateZoom: function(e, t, u, s) {
      this._mapPane && (u && (this._animatingZoom = !0, this._animateToCenter = e, this._animateToZoom = t, te(this._mapPane, "leaflet-zoom-anim")), this.fire("zoomanim", { center: e, zoom: t, noUpdate: s }), this._tempFireZoomEvent || (this._tempFireZoomEvent = this._zoom !== this._animateToZoom), this._move(this._animateToCenter, this._animateToZoom, void 0, !0), setTimeout(p(this._onZoomTransitionEnd, this), 250));
    }, _onZoomTransitionEnd: function() {
      this._animatingZoom && (this._mapPane && ye(this._mapPane, "leaflet-zoom-anim"), this._animatingZoom = !1, this._move(this._animateToCenter, this._animateToZoom, void 0, !0), this._tempFireZoomEvent && this.fire("zoom"), delete this._tempFireZoomEvent, this.fire("move"), this._moveEnd(!0));
    } });
    function ni(e) {
      return new Re(e);
    }
    var Re = Z.extend({ options: { position: "topright" }, initialize: function(e) {
      I(this, e);
    }, getPosition: function() {
      return this.options.position;
    }, setPosition: function(e) {
      var t = this._map;
      return t && t.removeControl(this), this.options.position = e, t && t.addControl(this), this;
    }, getContainer: function() {
      return this._container;
    }, addTo: function(s) {
      this.remove(), this._map = s;
      var t = this._container = this.onAdd(s), u = this.getPosition(), s = s._controlCorners[u];
      return te(t, "leaflet-control"), u.indexOf("bottom") !== -1 ? s.insertBefore(t, s.firstChild) : s.appendChild(t), this._map.on("unload", this.remove, this), this;
    }, remove: function() {
      return this._map && (ge(this._container), this.onRemove && this.onRemove(this._map), this._map.off("unload", this.remove, this), this._map = null), this;
    }, _refocusOnMap: function(e) {
      this._map && e && 0 < e.screenX && 0 < e.screenY && this._map.getContainer().focus();
    } }), xu = (ue.include({ addControl: function(e) {
      return e.addTo(this), this;
    }, removeControl: function(e) {
      return e.remove(), this;
    }, _initControlPos: function() {
      var e = this._controlCorners = {}, t = "leaflet-", u = this._controlContainer = oe("div", t + "control-container", this._container);
      function s(l, h) {
        e[l + h] = oe("div", t + l + " " + t + h, u);
      }
      s("top", "left"), s("top", "right"), s("bottom", "left"), s("bottom", "right");
    }, _clearControlPos: function() {
      for (var e in this._controlCorners)
        ge(this._controlCorners[e]);
      ge(this._controlContainer), delete this._controlCorners, delete this._controlContainer;
    } }), Re.extend({ options: { collapsed: !0, position: "topright", autoZIndex: !0, hideSingleBase: !1, sortLayers: !1, sortFunction: function(e, t, u, s) {
      return u < s ? -1 : s < u ? 1 : 0;
    } }, initialize: function(e, t, u) {
      for (var s in I(this, u), this._layerControlInputs = [], this._layers = [], this._lastZIndex = 0, this._handlingClick = !1, this._preventClick = !1, e)
        this._addLayer(e[s], s);
      for (s in t)
        this._addLayer(t[s], s, !0);
    }, onAdd: function(e) {
      this._initLayout(), this._update(), (this._map = e).on("zoomend", this._checkDisabledLayers, this);
      for (var t = 0; t < this._layers.length; t++)
        this._layers[t].layer.on("add remove", this._onLayerChange, this);
      return this._container;
    }, addTo: function(e) {
      return Re.prototype.addTo.call(this, e), this._expandIfNotCollapsed();
    }, onRemove: function() {
      this._map.off("zoomend", this._checkDisabledLayers, this);
      for (var e = 0; e < this._layers.length; e++)
        this._layers[e].layer.off("add remove", this._onLayerChange, this);
    }, addBaseLayer: function(e, t) {
      return this._addLayer(e, t), this._map ? this._update() : this;
    }, addOverlay: function(e, t) {
      return this._addLayer(e, t, !0), this._map ? this._update() : this;
    }, removeLayer: function(e) {
      return e.off("add remove", this._onLayerChange, this), e = this._getLayer(d(e)), e && this._layers.splice(this._layers.indexOf(e), 1), this._map ? this._update() : this;
    }, expand: function() {
      te(this._container, "leaflet-control-layers-expanded"), this._section.style.height = null;
      var e = this._map.getSize().y - (this._container.offsetTop + 50);
      return e < this._section.clientHeight ? (te(this._section, "leaflet-control-layers-scrollbar"), this._section.style.height = e + "px") : ye(this._section, "leaflet-control-layers-scrollbar"), this._checkDisabledLayers(), this;
    }, collapse: function() {
      return ye(this._container, "leaflet-control-layers-expanded"), this;
    }, _initLayout: function() {
      var e = "leaflet-control-layers", t = this._container = oe("div", e), u = this.options.collapsed, s = (t.setAttribute("aria-haspopup", !0), ii(t), lr(t), this._section = oe("section", e + "-list")), l = (u && (this._map.on("click", this.collapse, this), Y(t, { mouseenter: this._expandSafely, mouseleave: this.collapse }, this)), this._layersLink = oe("a", e + "-toggle", t));
      l.href = "#", l.title = "Layers", l.setAttribute("role", "button"), Y(l, { keydown: function(h) {
        h.keyCode === 13 && this._expandSafely();
      }, click: function(h) {
        Pe(h), this._expandSafely();
      } }, this), u || this.expand(), this._baseLayersList = oe("div", e + "-base", s), this._separator = oe("div", e + "-separator", s), this._overlaysList = oe("div", e + "-overlays", s), t.appendChild(s);
    }, _getLayer: function(e) {
      for (var t = 0; t < this._layers.length; t++)
        if (this._layers[t] && d(this._layers[t].layer) === e)
          return this._layers[t];
    }, _addLayer: function(e, t, u) {
      this._map && e.on("add remove", this._onLayerChange, this), this._layers.push({ layer: e, name: t, overlay: u }), this.options.sortLayers && this._layers.sort(p(function(s, l) {
        return this.options.sortFunction(s.layer, l.layer, s.name, l.name);
      }, this)), this.options.autoZIndex && e.setZIndex && (this._lastZIndex++, e.setZIndex(this._lastZIndex)), this._expandIfNotCollapsed();
    }, _update: function() {
      if (this._container) {
        Hi(this._baseLayersList), Hi(this._overlaysList), this._layerControlInputs = [];
        for (var e, t, u, s = 0, l = 0; l < this._layers.length; l++)
          u = this._layers[l], this._addItem(u), t = t || u.overlay, e = e || !u.overlay, s += u.overlay ? 0 : 1;
        this.options.hideSingleBase && (this._baseLayersList.style.display = (e = e && 1 < s) ? "" : "none"), this._separator.style.display = t && e ? "" : "none";
      }
      return this;
    }, _onLayerChange: function(u) {
      this._handlingClick || this._update();
      var t = this._getLayer(d(u.target)), u = t.overlay ? u.type === "add" ? "overlayadd" : "overlayremove" : u.type === "add" ? "baselayerchange" : null;
      u && this._map.fire(u, t);
    }, _createRadioElement: function(e, t) {
      return e = '<input type="radio" class="leaflet-control-layers-selector" name="' + e + '"' + (t ? ' checked="checked"' : "") + "/>", t = document.createElement("div"), t.innerHTML = e, t.firstChild;
    }, _addItem: function(e) {
      var t, u = document.createElement("label"), s = this._map.hasLayer(e.layer), s = (e.overlay ? ((t = document.createElement("input")).type = "checkbox", t.className = "leaflet-control-layers-selector", t.defaultChecked = s) : t = this._createRadioElement("leaflet-base-layers_" + d(this), s), this._layerControlInputs.push(t), t.layerId = d(e.layer), Y(t, "click", this._onInputClick, this), document.createElement("span")), l = (s.innerHTML = " " + e.name, document.createElement("span"));
      return u.appendChild(l), l.appendChild(t), l.appendChild(s), (e.overlay ? this._overlaysList : this._baseLayersList).appendChild(u), this._checkDisabledLayers(), u;
    }, _onInputClick: function() {
      if (!this._preventClick) {
        var e, t, u = this._layerControlInputs, s = [], l = [];
        this._handlingClick = !0;
        for (var h = u.length - 1; 0 <= h; h--)
          e = u[h], t = this._getLayer(e.layerId).layer, e.checked ? s.push(t) : e.checked || l.push(t);
        for (h = 0; h < l.length; h++)
          this._map.hasLayer(l[h]) && this._map.removeLayer(l[h]);
        for (h = 0; h < s.length; h++)
          this._map.hasLayer(s[h]) || this._map.addLayer(s[h]);
        this._handlingClick = !1, this._refocusOnMap();
      }
    }, _checkDisabledLayers: function() {
      for (var e, t, u = this._layerControlInputs, s = this._map.getZoom(), l = u.length - 1; 0 <= l; l--)
        e = u[l], t = this._getLayer(e.layerId).layer, e.disabled = t.options.minZoom !== void 0 && s < t.options.minZoom || t.options.maxZoom !== void 0 && s > t.options.maxZoom;
    }, _expandIfNotCollapsed: function() {
      return this._map && !this.options.collapsed && this.expand(), this;
    }, _expandSafely: function() {
      var e = this._section, t = (this._preventClick = !0, Y(e, "click", Pe), this.expand(), this);
      setTimeout(function() {
        ce(e, "click", Pe), t._preventClick = !1;
      });
    } })), dr = Re.extend({ options: { position: "topleft", zoomInText: '<span aria-hidden="true">+</span>', zoomInTitle: "Zoom in", zoomOutText: '<span aria-hidden="true">&#x2212;</span>', zoomOutTitle: "Zoom out" }, onAdd: function(e) {
      var t = "leaflet-control-zoom", u = oe("div", t + " leaflet-bar"), s = this.options;
      return this._zoomInButton = this._createButton(s.zoomInText, s.zoomInTitle, t + "-in", u, this._zoomIn), this._zoomOutButton = this._createButton(s.zoomOutText, s.zoomOutTitle, t + "-out", u, this._zoomOut), this._updateDisabled(), e.on("zoomend zoomlevelschange", this._updateDisabled, this), u;
    }, onRemove: function(e) {
      e.off("zoomend zoomlevelschange", this._updateDisabled, this);
    }, disable: function() {
      return this._disabled = !0, this._updateDisabled(), this;
    }, enable: function() {
      return this._disabled = !1, this._updateDisabled(), this;
    }, _zoomIn: function(e) {
      !this._disabled && this._map._zoom < this._map.getMaxZoom() && this._map.zoomIn(this._map.options.zoomDelta * (e.shiftKey ? 3 : 1));
    }, _zoomOut: function(e) {
      !this._disabled && this._map._zoom > this._map.getMinZoom() && this._map.zoomOut(this._map.options.zoomDelta * (e.shiftKey ? 3 : 1));
    }, _createButton: function(e, t, u, s, l) {
      return u = oe("a", u, s), u.innerHTML = e, u.href = "#", u.title = t, u.setAttribute("role", "button"), u.setAttribute("aria-label", t), ii(u), Y(u, "click", yt), Y(u, "click", l, this), Y(u, "click", this._refocusOnMap, this), u;
    }, _updateDisabled: function() {
      var e = this._map, t = "leaflet-disabled";
      ye(this._zoomInButton, t), ye(this._zoomOutButton, t), this._zoomInButton.setAttribute("aria-disabled", "false"), this._zoomOutButton.setAttribute("aria-disabled", "false"), !this._disabled && e._zoom !== e.getMinZoom() || (te(this._zoomOutButton, t), this._zoomOutButton.setAttribute("aria-disabled", "true")), !this._disabled && e._zoom !== e.getMaxZoom() || (te(this._zoomInButton, t), this._zoomInButton.setAttribute("aria-disabled", "true"));
    } }), wu = (ue.mergeOptions({ zoomControl: !0 }), ue.addInitHook(function() {
      this.options.zoomControl && (this.zoomControl = new dr(), this.addControl(this.zoomControl));
    }), Re.extend({ options: { position: "bottomleft", maxWidth: 100, metric: !0, imperial: !0 }, onAdd: function(e) {
      var t = "leaflet-control-scale", u = oe("div", t), s = this.options;
      return this._addScales(s, t + "-line", u), e.on(s.updateWhenIdle ? "moveend" : "move", this._update, this), e.whenReady(this._update, this), u;
    }, onRemove: function(e) {
      e.off(this.options.updateWhenIdle ? "moveend" : "move", this._update, this);
    }, _addScales: function(e, t, u) {
      e.metric && (this._mScale = oe("div", t, u)), e.imperial && (this._iScale = oe("div", t, u));
    }, _update: function() {
      var t = this._map, e = t.getSize().y / 2, t = t.distance(t.containerPointToLatLng([0, e]), t.containerPointToLatLng([this.options.maxWidth, e]));
      this._updateScales(t);
    }, _updateScales: function(e) {
      this.options.metric && e && this._updateMetric(e), this.options.imperial && e && this._updateImperial(e);
    }, _updateMetric: function(e) {
      var t = this._getRoundNum(e);
      this._updateScale(this._mScale, t < 1e3 ? t + " m" : t / 1e3 + " km", t / e);
    }, _updateImperial: function(s) {
      var t, u, s = 3.2808399 * s;
      5280 < s ? (u = this._getRoundNum(t = s / 5280), this._updateScale(this._iScale, u + " mi", u / t)) : (u = this._getRoundNum(s), this._updateScale(this._iScale, u + " ft", u / s));
    }, _updateScale: function(e, t, u) {
      e.style.width = Math.round(this.options.maxWidth * u) + "px", e.innerHTML = t;
    }, _getRoundNum: function(u) {
      var t = Math.pow(10, (Math.floor(u) + "").length - 1), u = u / t;
      return t * (u = 10 <= u ? 10 : 5 <= u ? 5 : 3 <= u ? 3 : 2 <= u ? 2 : 1);
    } })), fr = Re.extend({ options: { position: "bottomright", prefix: '<a href="https://leafletjs.com" title="A JavaScript library for interactive maps">' + (B.inlineSvg ? '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="12" height="8" viewBox="0 0 12 8" class="leaflet-attribution-flag"><path fill="#4C7BE1" d="M0 0h12v4H0z"/><path fill="#FFD500" d="M0 4h12v3H0z"/><path fill="#E0BC00" d="M0 7h12v1H0z"/></svg> ' : "") + "Leaflet</a>" }, initialize: function(e) {
      I(this, e), this._attributions = {};
    }, onAdd: function(e) {
      for (var t in (e.attributionControl = this)._container = oe("div", "leaflet-control-attribution"), ii(this._container), e._layers)
        e._layers[t].getAttribution && this.addAttribution(e._layers[t].getAttribution());
      return this._update(), e.on("layeradd", this._addAttribution, this), this._container;
    }, onRemove: function(e) {
      e.off("layeradd", this._addAttribution, this);
    }, _addAttribution: function(e) {
      e.layer.getAttribution && (this.addAttribution(e.layer.getAttribution()), e.layer.once("remove", function() {
        this.removeAttribution(e.layer.getAttribution());
      }, this));
    }, setPrefix: function(e) {
      return this.options.prefix = e, this._update(), this;
    }, addAttribution: function(e) {
      return e && (this._attributions[e] || (this._attributions[e] = 0), this._attributions[e]++, this._update()), this;
    }, removeAttribution: function(e) {
      return e && this._attributions[e] && (this._attributions[e]--, this._update()), this;
    }, _update: function() {
      if (this._map) {
        var e, t = [];
        for (e in this._attributions)
          this._attributions[e] && t.push(e);
        var u = [];
        this.options.prefix && u.push(this.options.prefix), t.length && u.push(t.join(", ")), this._container.innerHTML = u.join(' <span aria-hidden="true">|</span> ');
      }
    } }), Ie = (ue.mergeOptions({ attributionControl: !0 }), ue.addInitHook(function() {
      this.options.attributionControl && new fr().addTo(this);
    }), Re.Layers = xu, Re.Zoom = dr, Re.Scale = wu, Re.Attribution = fr, ni.layers = function(e, t, u) {
      return new xu(e, t, u);
    }, ni.zoom = function(e) {
      return new dr(e);
    }, ni.scale = function(e) {
      return new wu(e);
    }, ni.attribution = function(e) {
      return new fr(e);
    }, Z.extend({ initialize: function(e) {
      this._map = e;
    }, enable: function() {
      return this._enabled || (this._enabled = !0, this.addHooks()), this;
    }, disable: function() {
      return this._enabled && (this._enabled = !1, this.removeHooks()), this;
    }, enabled: function() {
      return !!this._enabled;
    } })), ri = (Ie.addTo = function(e, t) {
      return e.addHandler(t, this), this;
    }, { Events: x }), Tu = B.touch ? "touchstart mousedown" : "mousedown", at = C.extend({ options: { clickTolerance: 3 }, initialize: function(e, t, u, s) {
      I(this, s), this._element = e, this._dragStartTarget = t || e, this._preventOutline = u;
    }, enable: function() {
      this._enabled || (Y(this._dragStartTarget, Tu, this._onDown, this), this._enabled = !0);
    }, disable: function() {
      this._enabled && (at._dragging === this && this.finishDrag(!0), ce(this._dragStartTarget, Tu, this._onDown, this), this._enabled = !1, this._moved = !1);
    }, _onDown: function(e) {
      var t, u;
      this._enabled && (this._moved = !1, er(this._element, "leaflet-zoom-anim") || (e.touches && e.touches.length !== 1 ? at._dragging === this && this.finishDrag() : at._dragging || e.shiftKey || e.which !== 1 && e.button !== 1 && !e.touches || ((at._dragging = this)._preventOutline && rr(this._element), ir(), Qt(), this._moving || (this.fire("down"), u = e.touches ? e.touches[0] : e, t = mu(this._element), this._startPoint = new w(u.clientX, u.clientY), this._startPos = _t(this._element), this._parentScale = ur(t), u = e.type === "mousedown", Y(document, u ? "mousemove" : "touchmove", this._onMove, this), Y(document, u ? "mouseup" : "touchend touchcancel", this._onUp, this)))));
    }, _onMove: function(e) {
      var t;
      this._enabled && (e.touches && 1 < e.touches.length ? this._moved = !0 : !(t = new w((t = e.touches && e.touches.length === 1 ? e.touches[0] : e).clientX, t.clientY)._subtract(this._startPoint)).x && !t.y || Math.abs(t.x) + Math.abs(t.y) < this.options.clickTolerance || (t.x /= this._parentScale.x, t.y /= this._parentScale.y, Pe(e), this._moved || (this.fire("dragstart"), this._moved = !0, te(document.body, "leaflet-dragging"), this._lastTarget = e.target || e.srcElement, window.SVGElementInstance && this._lastTarget instanceof window.SVGElementInstance && (this._lastTarget = this._lastTarget.correspondingUseElement), te(this._lastTarget, "leaflet-drag-target")), this._newPos = this._startPos.add(t), this._moving = !0, this._lastEvent = e, this._updatePosition()));
    }, _updatePosition: function() {
      var e = { originalEvent: this._lastEvent };
      this.fire("predrag", e), Se(this._element, this._newPos), this.fire("drag", e);
    }, _onUp: function() {
      this._enabled && this.finishDrag();
    }, finishDrag: function(e) {
      ye(document.body, "leaflet-dragging"), this._lastTarget && (ye(this._lastTarget, "leaflet-drag-target"), this._lastTarget = null), ce(document, "mousemove touchmove", this._onMove, this), ce(document, "mouseup touchend touchcancel", this._onUp, this), nr(), Zi();
      var t = this._moved && this._moving;
      this._moving = !1, at._dragging = !1, t && this.fire("dragend", { noInertia: e, distance: this._newPos.distanceTo(this._startPos) });
    } });
    function Su(e, t, u) {
      for (var s, l, h, y, b, P, k, q = [1, 4, 2, 8], J = 0, Q = e.length; J < Q; J++)
        e[J]._code = vt(e[J], t);
      for (h = 0; h < 4; h++) {
        for (P = q[h], s = [], J = 0, l = (Q = e.length) - 1; J < Q; l = J++)
          y = e[J], b = e[l], y._code & P ? b._code & P || ((k = $i(b, y, P, t, u))._code = vt(k, t), s.push(k)) : (b._code & P && ((k = $i(b, y, P, t, u))._code = vt(k, t), s.push(k)), s.push(y));
        e = s;
      }
      return e;
    }
    function Lu(e, t) {
      var u, s, l, h, y, b, P;
      if (!e || e.length === 0)
        throw new Error("latlngs not passed");
      ze(e) || (console.warn("latlngs are not flat! Only the first ring will be used"), e = e[0]);
      for (var k = K([0, 0]), q = F(e), J = (q.getNorthWest().distanceTo(q.getSouthWest()) * q.getNorthEast().distanceTo(q.getNorthWest()) < 1700 && (k = pr(e)), e.length), Q = [], me = 0; me < J; me++) {
        var ke = K(e[me]);
        Q.push(t.project(K([ke.lat - k.lat, ke.lng - k.lng])));
      }
      for (me = y = b = P = 0, u = J - 1; me < J; u = me++)
        s = Q[me], l = Q[u], h = s.y * l.x - l.y * s.x, b += (s.x + l.x) * h, P += (s.y + l.y) * h, y += 3 * h;
      return q = y === 0 ? Q[0] : [b / y, P / y], q = t.unproject(M(q)), K([q.lat + k.lat, q.lng + k.lng]);
    }
    function pr(e) {
      for (var t = 0, u = 0, s = 0, l = 0; l < e.length; l++) {
        var h = K(e[l]);
        t += h.lat, u += h.lng, s++;
      }
      return K([t / s, u / s]);
    }
    var Pu, Gi = { __proto__: null, clipPolygon: Su, polygonCenter: Lu, centroid: pr };
    function Eu(e, t) {
      if (t && e.length) {
        var u = e = function(b, P) {
          for (var k = [b[0]], q = 1, J = 0, Q = b.length; q < Q; q++)
            (function(me, Ne) {
              var Ae = Ne.x - me.x, Ne = Ne.y - me.y;
              return Ae * Ae + Ne * Ne;
            })(b[q], b[J]) > P && (k.push(b[q]), J = q);
          return J < Q - 1 && k.push(b[Q - 1]), k;
        }(e, t = t * t), s = u.length, l = new (typeof Uint8Array != void 0 + "" ? Uint8Array : Array)(s);
        l[0] = l[s - 1] = 1, function b(P, k, q, J, Q) {
          var me, ke, Ae, Ne = 0;
          for (ke = J + 1; ke <= Q - 1; ke++)
            Ae = ui(P[ke], P[J], P[Q], !0), Ne < Ae && (me = ke, Ne = Ae);
          q < Ne && (k[me] = 1, b(P, k, q, J, me), b(P, k, q, me, Q));
        }(u, l, t, 0, s - 1);
        var h, y = [];
        for (h = 0; h < s; h++)
          l[h] && y.push(u[h]);
        return y;
      }
      return e.slice();
    }
    function Au(e, t, u) {
      return Math.sqrt(ui(e, t, u, !0));
    }
    function Cu(e, t, u, s, l) {
      var h, y, b, P = s ? Pu : vt(e, u), k = vt(t, u);
      for (Pu = k; ; ) {
        if (!(P | k))
          return [e, t];
        if (P & k)
          return !1;
        b = vt(y = $i(e, t, h = P || k, u, l), u), h === P ? (e = y, P = b) : (t = y, k = b);
      }
    }
    function $i(e, P, u, q, l) {
      var h, y, b = P.x - e.x, P = P.y - e.y, k = q.min, q = q.max;
      return 8 & u ? (h = e.x + b * (q.y - e.y) / P, y = q.y) : 4 & u ? (h = e.x + b * (k.y - e.y) / P, y = k.y) : 2 & u ? (h = q.x, y = e.y + P * (q.x - e.x) / b) : 1 & u && (h = k.x, y = e.y + P * (k.x - e.x) / b), new w(h, y, l);
    }
    function vt(e, t) {
      var u = 0;
      return e.x < t.min.x ? u |= 1 : e.x > t.max.x && (u |= 2), e.y < t.min.y ? u |= 4 : e.y > t.max.y && (u |= 8), u;
    }
    function ui(e, h, u, s) {
      var l = h.x, h = h.y, y = u.x - l, b = u.y - h, P = y * y + b * b;
      return 0 < P && (1 < (P = ((e.x - l) * y + (e.y - h) * b) / P) ? (l = u.x, h = u.y) : 0 < P && (l += y * P, h += b * P)), y = e.x - l, b = e.y - h, s ? y * y + b * b : new w(l, h);
    }
    function ze(e) {
      return !U(e[0]) || typeof e[0][0] != "object" && e[0][0] !== void 0;
    }
    function Mu(e) {
      return console.warn("Deprecated use of _flat, please use L.LineUtil.isFlat instead."), ze(e);
    }
    function Ou(e, t) {
      var u, s, l, h, y, b;
      if (!e || e.length === 0)
        throw new Error("latlngs not passed");
      ze(e) || (console.warn("latlngs are not flat! Only the first ring will be used"), e = e[0]);
      for (var P = K([0, 0]), k = F(e), q = (k.getNorthWest().distanceTo(k.getSouthWest()) * k.getNorthEast().distanceTo(k.getNorthWest()) < 1700 && (P = pr(e)), e.length), J = [], Q = 0; Q < q; Q++) {
        var me = K(e[Q]);
        J.push(t.project(K([me.lat - P.lat, me.lng - P.lng])));
      }
      for (u = Q = 0; Q < q - 1; Q++)
        u += J[Q].distanceTo(J[Q + 1]) / 2;
      if (u === 0)
        b = J[0];
      else
        for (s = Q = 0; Q < q - 1; Q++)
          if (l = J[Q], h = J[Q + 1], u < (s += y = l.distanceTo(h))) {
            b = [h.x - (y = (s - u) / y) * (h.x - l.x), h.y - y * (h.y - l.y)];
            break;
          }
      return k = t.unproject(M(b)), K([k.lat + P.lat, k.lng + P.lng]);
    }
    var Xi = { __proto__: null, simplify: Eu, pointToSegmentDistance: Au, closestPointOnSegment: function(e, t, u) {
      return ui(e, t, u);
    }, clipSegment: Cu, _getEdgeIntersection: $i, _getBitCode: vt, _sqClosestPointOnSegment: ui, isFlat: ze, _flat: Mu, polylineCenter: Ou }, xt = { project: function(e) {
      return new w(e.lng, e.lat);
    }, unproject: function(e) {
      return new j(e.y, e.x);
    }, bounds: new V([-180, -90], [180, 90]) }, wt = { R: 6378137, R_MINOR: 6356752314245179e-9, bounds: new V([-2003750834279e-5, -1549657073972e-5], [2003750834279e-5, 1876465623138e-5]), project: function(e) {
      var t = Math.PI / 180, u = this.R, h = e.lat * t, s = this.R_MINOR / u, s = Math.sqrt(1 - s * s), l = s * Math.sin(h), l = Math.tan(Math.PI / 4 - h / 2) / Math.pow((1 - l) / (1 + l), s / 2), h = -u * Math.log(Math.max(l, 1e-10));
      return new w(e.lng * t * u, h);
    }, unproject: function(e) {
      for (var t, u = 180 / Math.PI, s = this.R, l = this.R_MINOR / s, h = Math.sqrt(1 - l * l), y = Math.exp(-e.y / s), b = Math.PI / 2 - 2 * Math.atan(y), P = 0, k = 0.1; P < 15 && 1e-7 < Math.abs(k); P++)
        t = h * Math.sin(b), t = Math.pow((1 - t) / (1 + t), h / 2), b += k = Math.PI / 2 - 2 * Math.atan(y * t) - b;
      return new j(b * u, e.x * u / s);
    } }, Yi = { __proto__: null, LonLat: xt, Mercator: wt, SphericalMercator: _e }, mr = r({}, $, { code: "EPSG:3395", projection: wt, transformation: Te(Ot = 0.5 / (Math.PI * wt.R), 0.5, -Ot, 0.5) }), Iu = r({}, $, { code: "EPSG:4326", projection: xt, transformation: Te(1 / 180, 1, -1 / 180, 0.5) }), Ki = r({}, X, { projection: xt, transformation: Te(1, 0, -1, 0), scale: function(e) {
      return Math.pow(2, e);
    }, zoom: function(e) {
      return Math.log(e) / Math.LN2;
    }, distance: function(e, s) {
      var u = s.lng - e.lng, s = s.lat - e.lat;
      return Math.sqrt(u * u + s * s);
    }, infinite: !0 }), Ce = (X.Earth = $, X.EPSG3395 = mr, X.EPSG3857 = We, X.EPSG900913 = At, X.EPSG4326 = Iu, X.Simple = Ki, C.extend({ options: { pane: "overlayPane", attribution: null, bubblingMouseEvents: !0 }, addTo: function(e) {
      return e.addLayer(this), this;
    }, remove: function() {
      return this.removeFrom(this._map || this._mapToAdd);
    }, removeFrom: function(e) {
      return e && e.removeLayer(this), this;
    }, getPane: function(e) {
      return this._map.getPane(e ? this.options[e] || e : this.options.pane);
    }, addInteractiveTarget: function(e) {
      return this._map._targets[d(e)] = this;
    }, removeInteractiveTarget: function(e) {
      return delete this._map._targets[d(e)], this;
    }, getAttribution: function() {
      return this.options.attribution;
    }, _layerAdd: function(e) {
      var t, u = e.target;
      u.hasLayer(this) && (this._map = u, this._zoomAnimated = u._zoomAnimated, this.getEvents && (t = this.getEvents(), u.on(t, this), this.once("remove", function() {
        u.off(t, this);
      }, this)), this.onAdd(u), this.fire("add"), u.fire("layeradd", { layer: this }));
    } })), zt = (ue.include({ addLayer: function(e) {
      var t;
      if (e._layerAdd)
        return t = d(e), this._layers[t] || ((this._layers[t] = e)._mapToAdd = this, e.beforeAdd && e.beforeAdd(this), this.whenReady(e._layerAdd, e)), this;
      throw new Error("The provided object is not a Layer.");
    }, removeLayer: function(e) {
      var t = d(e);
      return this._layers[t] && (this._loaded && e.onRemove(this), delete this._layers[t], this._loaded && (this.fire("layerremove", { layer: e }), e.fire("remove")), e._map = e._mapToAdd = null), this;
    }, hasLayer: function(e) {
      return d(e) in this._layers;
    }, eachLayer: function(e, t) {
      for (var u in this._layers)
        e.call(t, this._layers[u]);
      return this;
    }, _addLayers: function(e) {
      for (var t = 0, u = (e = e ? U(e) ? e : [e] : []).length; t < u; t++)
        this.addLayer(e[t]);
    }, _addZoomLimit: function(e) {
      isNaN(e.options.maxZoom) && isNaN(e.options.minZoom) || (this._zoomBoundLayers[d(e)] = e, this._updateZoomLevels());
    }, _removeZoomLimit: function(e) {
      e = d(e), this._zoomBoundLayers[e] && (delete this._zoomBoundLayers[e], this._updateZoomLevels());
    }, _updateZoomLevels: function() {
      var e, t = 1 / 0, u = -1 / 0, s = this._getZoomSpan();
      for (e in this._zoomBoundLayers)
        var l = this._zoomBoundLayers[e].options, t = l.minZoom === void 0 ? t : Math.min(t, l.minZoom), u = l.maxZoom === void 0 ? u : Math.max(u, l.maxZoom);
      this._layersMaxZoom = u === -1 / 0 ? void 0 : u, this._layersMinZoom = t === 1 / 0 ? void 0 : t, s !== this._getZoomSpan() && this.fire("zoomlevelschange"), this.options.maxZoom === void 0 && this._layersMaxZoom && this.getZoom() > this._layersMaxZoom && this.setZoom(this._layersMaxZoom), this.options.minZoom === void 0 && this._layersMinZoom && this.getZoom() < this._layersMinZoom && this.setZoom(this._layersMinZoom);
    } }), Ce.extend({ initialize: function(e, t) {
      var u, s;
      if (I(this, t), this._layers = {}, e)
        for (u = 0, s = e.length; u < s; u++)
          this.addLayer(e[u]);
    }, addLayer: function(e) {
      var t = this.getLayerId(e);
      return this._layers[t] = e, this._map && this._map.addLayer(e), this;
    }, removeLayer: function(e) {
      return e = e in this._layers ? e : this.getLayerId(e), this._map && this._layers[e] && this._map.removeLayer(this._layers[e]), delete this._layers[e], this;
    }, hasLayer: function(e) {
      return (typeof e == "number" ? e : this.getLayerId(e)) in this._layers;
    }, clearLayers: function() {
      return this.eachLayer(this.removeLayer, this);
    }, invoke: function(e) {
      var t, u, s = Array.prototype.slice.call(arguments, 1);
      for (t in this._layers)
        (u = this._layers[t])[e] && u[e].apply(u, s);
      return this;
    }, onAdd: function(e) {
      this.eachLayer(e.addLayer, e);
    }, onRemove: function(e) {
      this.eachLayer(e.removeLayer, e);
    }, eachLayer: function(e, t) {
      for (var u in this._layers)
        e.call(t, this._layers[u]);
      return this;
    }, getLayer: function(e) {
      return this._layers[e];
    }, getLayers: function() {
      var e = [];
      return this.eachLayer(e.push, e), e;
    }, setZIndex: function(e) {
      return this.invoke("setZIndex", e);
    }, getLayerId: d })), $e = zt.extend({ addLayer: function(e) {
      return this.hasLayer(e) ? this : (e.addEventParent(this), zt.prototype.addLayer.call(this, e), this.fire("layeradd", { layer: e }));
    }, removeLayer: function(e) {
      return this.hasLayer(e) ? ((e = e in this._layers ? this._layers[e] : e).removeEventParent(this), zt.prototype.removeLayer.call(this, e), this.fire("layerremove", { layer: e })) : this;
    }, setStyle: function(e) {
      return this.invoke("setStyle", e);
    }, bringToFront: function() {
      return this.invoke("bringToFront");
    }, bringToBack: function() {
      return this.invoke("bringToBack");
    }, getBounds: function() {
      var e, t = new we();
      for (e in this._layers) {
        var u = this._layers[e];
        t.extend(u.getBounds ? u.getBounds() : u.getLatLng());
      }
      return t;
    } }), Rt = Z.extend({ options: { popupAnchor: [0, 0], tooltipAnchor: [0, 0], crossOrigin: !1 }, initialize: function(e) {
      I(this, e);
    }, createIcon: function(e) {
      return this._createIcon("icon", e);
    }, createShadow: function(e) {
      return this._createIcon("shadow", e);
    }, _createIcon: function(e, t) {
      var u = this._getIconUrl(e);
      if (u)
        return u = this._createImg(u, t && t.tagName === "IMG" ? t : null), this._setIconStyles(u, e), !this.options.crossOrigin && this.options.crossOrigin !== "" || (u.crossOrigin = this.options.crossOrigin === !0 ? "" : this.options.crossOrigin), u;
      if (e === "icon")
        throw new Error("iconUrl not set in Icon options (see the docs).");
      return null;
    }, _setIconStyles: function(e, t) {
      var u = this.options, s = u[t + "Size"], s = M(s = typeof s == "number" ? [s, s] : s), l = M(t === "shadow" && u.shadowAnchor || u.iconAnchor || s && s.divideBy(2, !0));
      e.className = "leaflet-marker-" + t + " " + (u.className || ""), l && (e.style.marginLeft = -l.x + "px", e.style.marginTop = -l.y + "px"), s && (e.style.width = s.x + "px", e.style.height = s.y + "px");
    }, _createImg: function(e, t) {
      return (t = t || document.createElement("img")).src = e, t;
    }, _getIconUrl: function(e) {
      return B.retina && this.options[e + "RetinaUrl"] || this.options[e + "Url"];
    } }), oi = Rt.extend({ options: { iconUrl: "marker-icon.png", iconRetinaUrl: "marker-icon-2x.png", shadowUrl: "marker-shadow.png", iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], tooltipAnchor: [16, -28], shadowSize: [41, 41] }, _getIconUrl: function(e) {
      return typeof oi.imagePath != "string" && (oi.imagePath = this._detectIconPath()), (this.options.imagePath || oi.imagePath) + Rt.prototype._getIconUrl.call(this, e);
    }, _stripUrl: function(e) {
      function t(u, s, l) {
        return (s = s.exec(u)) && s[l];
      }
      return (e = t(e, /^url\((['"])?(.+)\1\)$/, 2)) && t(e, /^(.*)marker-icon\.png$/, 1);
    }, _detectIconPath: function() {
      var e = oe("div", "leaflet-default-icon-path", document.body), t = ti(e, "background-image") || ti(e, "backgroundImage");
      return document.body.removeChild(e), (t = this._stripUrl(t)) ? t : (e = document.querySelector('link[href$="leaflet.css"]')) ? e.href.substring(0, e.href.length - 11 - 1) : "";
    } }), ku = Ie.extend({ initialize: function(e) {
      this._marker = e;
    }, addHooks: function() {
      var e = this._marker._icon;
      this._draggable || (this._draggable = new at(e, e, !0)), this._draggable.on({ dragstart: this._onDragStart, predrag: this._onPreDrag, drag: this._onDrag, dragend: this._onDragEnd }, this).enable(), te(e, "leaflet-marker-draggable");
    }, removeHooks: function() {
      this._draggable.off({ dragstart: this._onDragStart, predrag: this._onPreDrag, drag: this._onDrag, dragend: this._onDragEnd }, this).disable(), this._marker._icon && ye(this._marker._icon, "leaflet-marker-draggable");
    }, moved: function() {
      return this._draggable && this._draggable._moved;
    }, _adjustPan: function(e) {
      var t = this._marker, u = t._map, s = this._marker.options.autoPanSpeed, l = this._marker.options.autoPanPadding, h = _t(t._icon), y = u.getPixelBounds(), b = u.getPixelOrigin(), b = pe(y.min._subtract(b).add(l), y.max._subtract(b).subtract(l));
      b.contains(h) || (l = M((Math.max(b.max.x, h.x) - b.max.x) / (y.max.x - b.max.x) - (Math.min(b.min.x, h.x) - b.min.x) / (y.min.x - b.min.x), (Math.max(b.max.y, h.y) - b.max.y) / (y.max.y - b.max.y) - (Math.min(b.min.y, h.y) - b.min.y) / (y.min.y - b.min.y)).multiplyBy(s), u.panBy(l, { animate: !1 }), this._draggable._newPos._add(l), this._draggable._startPos._add(l), Se(t._icon, this._draggable._newPos), this._onDrag(e), this._panRequest = T(this._adjustPan.bind(this, e)));
    }, _onDragStart: function() {
      this._oldLatLng = this._marker.getLatLng(), this._marker.closePopup && this._marker.closePopup(), this._marker.fire("movestart").fire("dragstart");
    }, _onPreDrag: function(e) {
      this._marker.options.autoPan && (A(this._panRequest), this._panRequest = T(this._adjustPan.bind(this, e)));
    }, _onDrag: function(e) {
      var t = this._marker, u = t._shadow, s = _t(t._icon), l = t._map.layerPointToLatLng(s);
      u && Se(u, s), t._latlng = l, e.latlng = l, e.oldLatLng = this._oldLatLng, t.fire("move", e).fire("drag", e);
    }, _onDragEnd: function(e) {
      A(this._panRequest), delete this._oldLatLng, this._marker.fire("moveend").fire("dragend", e);
    } }), Ji = Ce.extend({ options: { icon: new oi(), interactive: !0, keyboard: !0, title: "", alt: "Marker", zIndexOffset: 0, opacity: 1, riseOnHover: !1, riseOffset: 250, pane: "markerPane", shadowPane: "shadowPane", bubblingMouseEvents: !1, autoPanOnFocus: !0, draggable: !1, autoPan: !1, autoPanPadding: [50, 50], autoPanSpeed: 10 }, initialize: function(e, t) {
      I(this, t), this._latlng = K(e);
    }, onAdd: function(e) {
      this._zoomAnimated = this._zoomAnimated && e.options.markerZoomAnimation, this._zoomAnimated && e.on("zoomanim", this._animateZoom, this), this._initIcon(), this.update();
    }, onRemove: function(e) {
      this.dragging && this.dragging.enabled() && (this.options.draggable = !0, this.dragging.removeHooks()), delete this.dragging, this._zoomAnimated && e.off("zoomanim", this._animateZoom, this), this._removeIcon(), this._removeShadow();
    }, getEvents: function() {
      return { zoom: this.update, viewreset: this.update };
    }, getLatLng: function() {
      return this._latlng;
    }, setLatLng: function(e) {
      var t = this._latlng;
      return this._latlng = K(e), this.update(), this.fire("move", { oldLatLng: t, latlng: this._latlng });
    }, setZIndexOffset: function(e) {
      return this.options.zIndexOffset = e, this.update();
    }, getIcon: function() {
      return this.options.icon;
    }, setIcon: function(e) {
      return this.options.icon = e, this._map && (this._initIcon(), this.update()), this._popup && this.bindPopup(this._popup, this._popup.options), this;
    }, getElement: function() {
      return this._icon;
    }, update: function() {
      var e;
      return this._icon && this._map && (e = this._map.latLngToLayerPoint(this._latlng).round(), this._setPos(e)), this;
    }, _initIcon: function() {
      var e = this.options, t = "leaflet-zoom-" + (this._zoomAnimated ? "animated" : "hide"), s = e.icon.createIcon(this._icon), u = !1, s = (s !== this._icon && (this._icon && this._removeIcon(), u = !0, e.title && (s.title = e.title), s.tagName === "IMG" && (s.alt = e.alt || "")), te(s, t), e.keyboard && (s.tabIndex = "0", s.setAttribute("role", "button")), this._icon = s, e.riseOnHover && this.on({ mouseover: this._bringToFront, mouseout: this._resetZIndex }), this.options.autoPanOnFocus && Y(s, "focus", this._panOnFocus, this), e.icon.createShadow(this._shadow)), l = !1;
      s !== this._shadow && (this._removeShadow(), l = !0), s && (te(s, t), s.alt = ""), this._shadow = s, e.opacity < 1 && this._updateOpacity(), u && this.getPane().appendChild(this._icon), this._initInteraction(), s && l && this.getPane(e.shadowPane).appendChild(this._shadow);
    }, _removeIcon: function() {
      this.options.riseOnHover && this.off({ mouseover: this._bringToFront, mouseout: this._resetZIndex }), this.options.autoPanOnFocus && ce(this._icon, "focus", this._panOnFocus, this), ge(this._icon), this.removeInteractiveTarget(this._icon), this._icon = null;
    }, _removeShadow: function() {
      this._shadow && ge(this._shadow), this._shadow = null;
    }, _setPos: function(e) {
      this._icon && Se(this._icon, e), this._shadow && Se(this._shadow, e), this._zIndex = e.y + this.options.zIndexOffset, this._resetZIndex();
    }, _updateZIndex: function(e) {
      this._icon && (this._icon.style.zIndex = this._zIndex + e);
    }, _animateZoom: function(e) {
      e = this._map._latLngToNewLayerPoint(this._latlng, e.zoom, e.center).round(), this._setPos(e);
    }, _initInteraction: function() {
      var e;
      this.options.interactive && (te(this._icon, "leaflet-interactive"), this.addInteractiveTarget(this._icon), ku && (e = this.options.draggable, this.dragging && (e = this.dragging.enabled(), this.dragging.disable()), this.dragging = new ku(this), e && this.dragging.enable()));
    }, setOpacity: function(e) {
      return this.options.opacity = e, this._map && this._updateOpacity(), this;
    }, _updateOpacity: function() {
      var e = this.options.opacity;
      this._icon && Be(this._icon, e), this._shadow && Be(this._shadow, e);
    }, _bringToFront: function() {
      this._updateZIndex(this.options.riseOffset);
    }, _resetZIndex: function() {
      this._updateZIndex(0);
    }, _panOnFocus: function() {
      var e, t, u = this._map;
      u && (e = (t = this.options.icon.options).iconSize ? M(t.iconSize) : M(0, 0), t = t.iconAnchor ? M(t.iconAnchor) : M(0, 0), u.panInside(this._latlng, { paddingTopLeft: t, paddingBottomRight: e.subtract(t) }));
    }, _getPopupAnchor: function() {
      return this.options.icon.options.popupAnchor;
    }, _getTooltipAnchor: function() {
      return this.options.icon.options.tooltipAnchor;
    } }), lt = Ce.extend({ options: { stroke: !0, color: "#3388ff", weight: 3, opacity: 1, lineCap: "round", lineJoin: "round", dashArray: null, dashOffset: null, fill: !1, fillColor: null, fillOpacity: 0.2, fillRule: "evenodd", interactive: !0, bubblingMouseEvents: !0 }, beforeAdd: function(e) {
      this._renderer = e.getRenderer(this);
    }, onAdd: function() {
      this._renderer._initPath(this), this._reset(), this._renderer._addPath(this);
    }, onRemove: function() {
      this._renderer._removePath(this);
    }, redraw: function() {
      return this._map && this._renderer._updatePath(this), this;
    }, setStyle: function(e) {
      return I(this, e), this._renderer && (this._renderer._updateStyle(this), this.options.stroke && e && Object.prototype.hasOwnProperty.call(e, "weight") && this._updateBounds()), this;
    }, bringToFront: function() {
      return this._renderer && this._renderer._bringToFront(this), this;
    }, bringToBack: function() {
      return this._renderer && this._renderer._bringToBack(this), this;
    }, getElement: function() {
      return this._path;
    }, _reset: function() {
      this._project(), this._update();
    }, _clickTolerance: function() {
      return (this.options.stroke ? this.options.weight / 2 : 0) + (this._renderer.options.tolerance || 0);
    } }), Qi = lt.extend({ options: { fill: !0, radius: 10 }, initialize: function(e, t) {
      I(this, t), this._latlng = K(e), this._radius = this.options.radius;
    }, setLatLng: function(e) {
      var t = this._latlng;
      return this._latlng = K(e), this.redraw(), this.fire("move", { oldLatLng: t, latlng: this._latlng });
    }, getLatLng: function() {
      return this._latlng;
    }, setRadius: function(e) {
      return this.options.radius = this._radius = e, this.redraw();
    }, getRadius: function() {
      return this._radius;
    }, setStyle: function(e) {
      var t = e && e.radius || this._radius;
      return lt.prototype.setStyle.call(this, e), this.setRadius(t), this;
    }, _project: function() {
      this._point = this._map.latLngToLayerPoint(this._latlng), this._updateBounds();
    }, _updateBounds: function() {
      var u = this._radius, e = this._radiusY || u, t = this._clickTolerance(), u = [u + t, e + t];
      this._pxBounds = new V(this._point.subtract(u), this._point.add(u));
    }, _update: function() {
      this._map && this._updatePath();
    }, _updatePath: function() {
      this._renderer._updateCircle(this);
    }, _empty: function() {
      return this._radius && !this._renderer._bounds.intersects(this._pxBounds);
    }, _containsPoint: function(e) {
      return e.distanceTo(this._point) <= this._radius + this._clickTolerance();
    } }), gr = Qi.extend({ initialize: function(e, t, u) {
      if (I(this, t = typeof t == "number" ? r({}, u, { radius: t }) : t), this._latlng = K(e), isNaN(this.options.radius))
        throw new Error("Circle radius cannot be NaN");
      this._mRadius = this.options.radius;
    }, setRadius: function(e) {
      return this._mRadius = e, this.redraw();
    }, getRadius: function() {
      return this._mRadius;
    }, getBounds: function() {
      var e = [this._radius, this._radiusY || this._radius];
      return new we(this._map.layerPointToLatLng(this._point.subtract(e)), this._map.layerPointToLatLng(this._point.add(e)));
    }, setStyle: lt.prototype.setStyle, _project: function() {
      var e, t, u, s, l, h = this._latlng.lng, y = this._latlng.lat, b = this._map, P = b.options.crs;
      P.distance === $.distance ? (s = Math.PI / 180, l = this._mRadius / $.R / s, e = b.project([y + l, h]), t = b.project([y - l, h]), t = e.add(t).divideBy(2), u = b.unproject(t).lat, s = Math.acos((Math.cos(l * s) - Math.sin(y * s) * Math.sin(u * s)) / (Math.cos(y * s) * Math.cos(u * s))) / s, !isNaN(s) && s !== 0 || (s = l / Math.cos(Math.PI / 180 * y)), this._point = t.subtract(b.getPixelOrigin()), this._radius = isNaN(s) ? 0 : t.x - b.project([u, h - s]).x, this._radiusY = t.y - e.y) : (l = P.unproject(P.project(this._latlng).subtract([this._mRadius, 0])), this._point = b.latLngToLayerPoint(this._latlng), this._radius = this._point.x - b.latLngToLayerPoint(l).x), this._updateBounds();
    } }), Xe = lt.extend({ options: { smoothFactor: 1, noClip: !1 }, initialize: function(e, t) {
      I(this, t), this._setLatLngs(e);
    }, getLatLngs: function() {
      return this._latlngs;
    }, setLatLngs: function(e) {
      return this._setLatLngs(e), this.redraw();
    }, isEmpty: function() {
      return !this._latlngs.length;
    }, closestLayerPoint: function(e) {
      for (var t = 1 / 0, u = null, s = ui, l = 0, h = this._parts.length; l < h; l++)
        for (var y = this._parts[l], b = 1, P = y.length; b < P; b++) {
          var k, q, J = s(e, k = y[b - 1], q = y[b], !0);
          J < t && (t = J, u = s(e, k, q));
        }
      return u && (u.distance = Math.sqrt(t)), u;
    }, getCenter: function() {
      if (this._map)
        return Ou(this._defaultShape(), this._map.options.crs);
      throw new Error("Must add layer to map before using getCenter()");
    }, getBounds: function() {
      return this._bounds;
    }, addLatLng: function(e, t) {
      return t = t || this._defaultShape(), e = K(e), t.push(e), this._bounds.extend(e), this.redraw();
    }, _setLatLngs: function(e) {
      this._bounds = new we(), this._latlngs = this._convertLatLngs(e);
    }, _defaultShape: function() {
      return ze(this._latlngs) ? this._latlngs : this._latlngs[0];
    }, _convertLatLngs: function(e) {
      for (var t = [], u = ze(e), s = 0, l = e.length; s < l; s++)
        u ? (t[s] = K(e[s]), this._bounds.extend(t[s])) : t[s] = this._convertLatLngs(e[s]);
      return t;
    }, _project: function() {
      var e = new V();
      this._rings = [], this._projectLatlngs(this._latlngs, this._rings, e), this._bounds.isValid() && e.isValid() && (this._rawPxBounds = e, this._updateBounds());
    }, _updateBounds: function() {
      var e = this._clickTolerance(), e = new w(e, e);
      this._rawPxBounds && (this._pxBounds = new V([this._rawPxBounds.min.subtract(e), this._rawPxBounds.max.add(e)]));
    }, _projectLatlngs: function(e, t, u) {
      var s, l, h = e[0] instanceof j, y = e.length;
      if (h) {
        for (l = [], s = 0; s < y; s++)
          l[s] = this._map.latLngToLayerPoint(e[s]), u.extend(l[s]);
        t.push(l);
      } else
        for (s = 0; s < y; s++)
          this._projectLatlngs(e[s], t, u);
    }, _clipPoints: function() {
      var e = this._renderer._bounds;
      if (this._parts = [], this._pxBounds && this._pxBounds.intersects(e))
        if (this.options.noClip)
          this._parts = this._rings;
        else
          for (var t, u, s, l, h = this._parts, y = 0, b = 0, P = this._rings.length; y < P; y++)
            for (t = 0, u = (l = this._rings[y]).length; t < u - 1; t++)
              (s = Cu(l[t], l[t + 1], e, t, !0)) && (h[b] = h[b] || [], h[b].push(s[0]), s[1] === l[t + 1] && t !== u - 2 || (h[b].push(s[1]), b++));
    }, _simplifyPoints: function() {
      for (var e = this._parts, t = this.options.smoothFactor, u = 0, s = e.length; u < s; u++)
        e[u] = Eu(e[u], t);
    }, _update: function() {
      this._map && (this._clipPoints(), this._simplifyPoints(), this._updatePath());
    }, _updatePath: function() {
      this._renderer._updatePoly(this);
    }, _containsPoint: function(e, t) {
      var u, s, l, h, y, b, P = this._clickTolerance();
      if (this._pxBounds && this._pxBounds.contains(e)) {
        for (u = 0, h = this._parts.length; u < h; u++)
          for (s = 0, l = (y = (b = this._parts[u]).length) - 1; s < y; l = s++)
            if ((t || s !== 0) && Au(e, b[l], b[s]) <= P)
              return !0;
      }
      return !1;
    } });
    Xe._flat = Mu;
    var jt = Xe.extend({ options: { fill: !0 }, isEmpty: function() {
      return !this._latlngs.length || !this._latlngs[0].length;
    }, getCenter: function() {
      if (this._map)
        return Lu(this._defaultShape(), this._map.options.crs);
      throw new Error("Must add layer to map before using getCenter()");
    }, _convertLatLngs: function(t) {
      var t = Xe.prototype._convertLatLngs.call(this, t), u = t.length;
      return 2 <= u && t[0] instanceof j && t[0].equals(t[u - 1]) && t.pop(), t;
    }, _setLatLngs: function(e) {
      Xe.prototype._setLatLngs.call(this, e), ze(this._latlngs) && (this._latlngs = [this._latlngs]);
    }, _defaultShape: function() {
      return (ze(this._latlngs[0]) ? this._latlngs : this._latlngs[0])[0];
    }, _clipPoints: function() {
      var t = this._renderer._bounds, e = this.options.weight, e = new w(e, e), t = new V(t.min.subtract(e), t.max.add(e));
      if (this._parts = [], this._pxBounds && this._pxBounds.intersects(t))
        if (this.options.noClip)
          this._parts = this._rings;
        else
          for (var u, s = 0, l = this._rings.length; s < l; s++)
            (u = Su(this._rings[s], t, !0)).length && this._parts.push(u);
    }, _updatePath: function() {
      this._renderer._updatePoly(this, !0);
    }, _containsPoint: function(e) {
      var t, u, s, l, h, y, b, P, k = !1;
      if (!this._pxBounds || !this._pxBounds.contains(e))
        return !1;
      for (l = 0, b = this._parts.length; l < b; l++)
        for (h = 0, y = (P = (t = this._parts[l]).length) - 1; h < P; y = h++)
          u = t[h], s = t[y], u.y > e.y != s.y > e.y && e.x < (s.x - u.x) * (e.y - u.y) / (s.y - u.y) + u.x && (k = !k);
      return k || Xe.prototype._containsPoint.call(this, e, !0);
    } }), Ye = $e.extend({ initialize: function(e, t) {
      I(this, t), this._layers = {}, e && this.addData(e);
    }, addData: function(e) {
      var t, u, s, l = U(e) ? e : e.features;
      if (l) {
        for (t = 0, u = l.length; t < u; t++)
          ((s = l[t]).geometries || s.geometry || s.features || s.coordinates) && this.addData(s);
        return this;
      }
      var h, y = this.options;
      return (!y.filter || y.filter(e)) && (h = en(e, y)) ? (h.feature = rn(e), h.defaultOptions = h.options, this.resetStyle(h), y.onEachFeature && y.onEachFeature(e, h), this.addLayer(h)) : this;
    }, resetStyle: function(e) {
      return e === void 0 ? this.eachLayer(this.resetStyle, this) : (e.options = r({}, e.defaultOptions), this._setLayerStyle(e, this.options.style), this);
    }, setStyle: function(e) {
      return this.eachLayer(function(t) {
        this._setLayerStyle(t, e);
      }, this);
    }, _setLayerStyle: function(e, t) {
      e.setStyle && (typeof t == "function" && (t = t(e.feature)), e.setStyle(t));
    } });
    function en(e, t) {
      var u, s, l, h, y = e.type === "Feature" ? e.geometry : e, b = y ? y.coordinates : null, P = [], k = t && t.pointToLayer, q = t && t.coordsToLatLng || _r;
      if (!b && !y)
        return null;
      switch (y.type) {
        case "Point":
          return Nu(k, e, u = q(b), t);
        case "MultiPoint":
          for (l = 0, h = b.length; l < h; l++)
            u = q(b[l]), P.push(Nu(k, e, u, t));
          return new $e(P);
        case "LineString":
        case "MultiLineString":
          return s = tn(b, y.type === "LineString" ? 0 : 1, q), new Xe(s, t);
        case "Polygon":
        case "MultiPolygon":
          return s = tn(b, y.type === "Polygon" ? 1 : 2, q), new jt(s, t);
        case "GeometryCollection":
          for (l = 0, h = y.geometries.length; l < h; l++) {
            var J = en({ geometry: y.geometries[l], type: "Feature", properties: e.properties }, t);
            J && P.push(J);
          }
          return new $e(P);
        case "FeatureCollection":
          for (l = 0, h = y.features.length; l < h; l++) {
            var Q = en(y.features[l], t);
            Q && P.push(Q);
          }
          return new $e(P);
        default:
          throw new Error("Invalid GeoJSON object.");
      }
    }
    function Nu(e, t, u, s) {
      return e ? e(t, u) : new Ji(u, s && s.markersInheritOptions && s);
    }
    function _r(e) {
      return new j(e[1], e[0], e[2]);
    }
    function tn(e, t, u) {
      for (var s, l = [], h = 0, y = e.length; h < y; h++)
        s = t ? tn(e[h], t - 1, u) : (u || _r)(e[h]), l.push(s);
      return l;
    }
    function br(e, t) {
      return (e = K(e)).alt !== void 0 ? [f(e.lng, t), f(e.lat, t), f(e.alt, t)] : [f(e.lng, t), f(e.lat, t)];
    }
    function nn(e, t, u, s) {
      for (var l = [], h = 0, y = e.length; h < y; h++)
        l.push(t ? nn(e[h], ze(e[h]) ? 0 : t - 1, u, s) : br(e[h], s));
      return !t && u && 0 < l.length && l.push(l[0].slice()), l;
    }
    function qt(e, t) {
      return e.feature ? r({}, e.feature, { geometry: t }) : rn(t);
    }
    function rn(e) {
      return e.type === "Feature" || e.type === "FeatureCollection" ? e : { type: "Feature", properties: {}, geometry: e };
    }
    mt = { toGeoJSON: function(e) {
      return qt(this, { type: "Point", coordinates: br(this.getLatLng(), e) });
    } };
    function Du(e, t) {
      return new Ye(e, t);
    }
    Ji.include(mt), gr.include(mt), Qi.include(mt), Xe.include({ toGeoJSON: function(e) {
      var t = !ze(this._latlngs);
      return qt(this, { type: (t ? "Multi" : "") + "LineString", coordinates: nn(this._latlngs, t ? 1 : 0, !1, e) });
    } }), jt.include({ toGeoJSON: function(s) {
      var t = !ze(this._latlngs), u = t && !ze(this._latlngs[0]), s = nn(this._latlngs, u ? 2 : t ? 1 : 0, !0, s);
      return qt(this, { type: (u ? "Multi" : "") + "Polygon", coordinates: s = t ? s : [s] });
    } }), zt.include({ toMultiPoint: function(e) {
      var t = [];
      return this.eachLayer(function(u) {
        t.push(u.toGeoJSON(e).geometry.coordinates);
      }), qt(this, { type: "MultiPoint", coordinates: t });
    }, toGeoJSON: function(e) {
      var t, u, s = this.feature && this.feature.geometry && this.feature.geometry.type;
      return s === "MultiPoint" ? this.toMultiPoint(e) : (t = s === "GeometryCollection", u = [], this.eachLayer(function(l) {
        l.toGeoJSON && (l = l.toGeoJSON(e), t ? u.push(l.geometry) : (l = rn(l)).type === "FeatureCollection" ? u.push.apply(u, l.features) : u.push(l));
      }), t ? qt(this, { geometries: u, type: "GeometryCollection" }) : { type: "FeatureCollection", features: u });
    } });
    var un = Du, on = Ce.extend({ options: { opacity: 1, alt: "", interactive: !1, crossOrigin: !1, errorOverlayUrl: "", zIndex: 1, className: "" }, initialize: function(e, t, u) {
      this._url = e, this._bounds = F(t), I(this, u);
    }, onAdd: function() {
      this._image || (this._initImage(), this.options.opacity < 1 && this._updateOpacity()), this.options.interactive && (te(this._image, "leaflet-interactive"), this.addInteractiveTarget(this._image)), this.getPane().appendChild(this._image), this._reset();
    }, onRemove: function() {
      ge(this._image), this.options.interactive && this.removeInteractiveTarget(this._image);
    }, setOpacity: function(e) {
      return this.options.opacity = e, this._image && this._updateOpacity(), this;
    }, setStyle: function(e) {
      return e.opacity && this.setOpacity(e.opacity), this;
    }, bringToFront: function() {
      return this._map && Dt(this._image), this;
    }, bringToBack: function() {
      return this._map && Bt(this._image), this;
    }, setUrl: function(e) {
      return this._url = e, this._image && (this._image.src = e), this;
    }, setBounds: function(e) {
      return this._bounds = F(e), this._map && this._reset(), this;
    }, getEvents: function() {
      var e = { zoom: this._reset, viewreset: this._reset };
      return this._zoomAnimated && (e.zoomanim = this._animateZoom), e;
    }, setZIndex: function(e) {
      return this.options.zIndex = e, this._updateZIndex(), this;
    }, getBounds: function() {
      return this._bounds;
    }, getElement: function() {
      return this._image;
    }, _initImage: function() {
      var e = this._url.tagName === "IMG", t = this._image = e ? this._url : oe("img");
      te(t, "leaflet-image-layer"), this._zoomAnimated && te(t, "leaflet-zoom-animated"), this.options.className && te(t, this.options.className), t.onselectstart = S, t.onmousemove = S, t.onload = p(this.fire, this, "load"), t.onerror = p(this._overlayOnError, this, "error"), !this.options.crossOrigin && this.options.crossOrigin !== "" || (t.crossOrigin = this.options.crossOrigin === !0 ? "" : this.options.crossOrigin), this.options.zIndex && this._updateZIndex(), e ? this._url = t.src : (t.src = this._url, t.alt = this.options.alt);
    }, _animateZoom: function(u) {
      var t = this._map.getZoomScale(u.zoom), u = this._map._latLngBoundsToNewLayerBounds(this._bounds, u.zoom, u.center).min;
      gt(this._image, u, t);
    }, _reset: function() {
      var e = this._image, t = new V(this._map.latLngToLayerPoint(this._bounds.getNorthWest()), this._map.latLngToLayerPoint(this._bounds.getSouthEast())), u = t.getSize();
      Se(e, t.min), e.style.width = u.x + "px", e.style.height = u.y + "px";
    }, _updateOpacity: function() {
      Be(this._image, this.options.opacity);
    }, _updateZIndex: function() {
      this._image && this.options.zIndex !== void 0 && this.options.zIndex !== null && (this._image.style.zIndex = this.options.zIndex);
    }, _overlayOnError: function() {
      this.fire("error");
      var e = this.options.errorOverlayUrl;
      e && this._url !== e && (this._url = e, this._image.src = e);
    }, getCenter: function() {
      return this._bounds.getCenter();
    } }), Bu = on.extend({ options: { autoplay: !0, loop: !0, keepAspectRatio: !0, muted: !1, playsInline: !0 }, _initImage: function() {
      var e = this._url.tagName === "VIDEO", t = this._image = e ? this._url : oe("video");
      if (te(t, "leaflet-image-layer"), this._zoomAnimated && te(t, "leaflet-zoom-animated"), this.options.className && te(t, this.options.className), t.onselectstart = S, t.onmousemove = S, t.onloadeddata = p(this.fire, this, "load"), e) {
        for (var u = t.getElementsByTagName("source"), s = [], l = 0; l < u.length; l++)
          s.push(u[l].src);
        this._url = 0 < u.length ? s : [t.src];
      } else {
        U(this._url) || (this._url = [this._url]), !this.options.keepAspectRatio && Object.prototype.hasOwnProperty.call(t.style, "objectFit") && (t.style.objectFit = "fill"), t.autoplay = !!this.options.autoplay, t.loop = !!this.options.loop, t.muted = !!this.options.muted, t.playsInline = !!this.options.playsInline;
        for (var h = 0; h < this._url.length; h++) {
          var y = oe("source");
          y.src = this._url[h], t.appendChild(y);
        }
      }
    } }), zu = on.extend({ _initImage: function() {
      var e = this._image = this._url;
      te(e, "leaflet-image-layer"), this._zoomAnimated && te(e, "leaflet-zoom-animated"), this.options.className && te(e, this.options.className), e.onselectstart = S, e.onmousemove = S;
    } }), Fe = Ce.extend({ options: { interactive: !1, offset: [0, 0], className: "", pane: void 0, content: "" }, initialize: function(e, t) {
      e && (e instanceof j || U(e)) ? (this._latlng = K(e), I(this, t)) : (I(this, e), this._source = t), this.options.content && (this._content = this.options.content);
    }, openOn: function(e) {
      return (e = arguments.length ? e : this._source._map).hasLayer(this) || e.addLayer(this), this;
    }, close: function() {
      return this._map && this._map.removeLayer(this), this;
    }, toggle: function(e) {
      return this._map ? this.close() : (arguments.length ? this._source = e : e = this._source, this._prepareOpen(), this.openOn(e._map)), this;
    }, onAdd: function(e) {
      this._zoomAnimated = e._zoomAnimated, this._container || this._initLayout(), e._fadeAnimated && Be(this._container, 0), clearTimeout(this._removeTimeout), this.getPane().appendChild(this._container), this.update(), e._fadeAnimated && Be(this._container, 1), this.bringToFront(), this.options.interactive && (te(this._container, "leaflet-interactive"), this.addInteractiveTarget(this._container));
    }, onRemove: function(e) {
      e._fadeAnimated ? (Be(this._container, 0), this._removeTimeout = setTimeout(p(ge, void 0, this._container), 200)) : ge(this._container), this.options.interactive && (ye(this._container, "leaflet-interactive"), this.removeInteractiveTarget(this._container));
    }, getLatLng: function() {
      return this._latlng;
    }, setLatLng: function(e) {
      return this._latlng = K(e), this._map && (this._updatePosition(), this._adjustPan()), this;
    }, getContent: function() {
      return this._content;
    }, setContent: function(e) {
      return this._content = e, this.update(), this;
    }, getElement: function() {
      return this._container;
    }, update: function() {
      this._map && (this._container.style.visibility = "hidden", this._updateContent(), this._updateLayout(), this._updatePosition(), this._container.style.visibility = "", this._adjustPan());
    }, getEvents: function() {
      var e = { zoom: this._updatePosition, viewreset: this._updatePosition };
      return this._zoomAnimated && (e.zoomanim = this._animateZoom), e;
    }, isOpen: function() {
      return !!this._map && this._map.hasLayer(this);
    }, bringToFront: function() {
      return this._map && Dt(this._container), this;
    }, bringToBack: function() {
      return this._map && Bt(this._container), this;
    }, _prepareOpen: function(e) {
      if (!(u = this._source)._map)
        return !1;
      if (u instanceof $e) {
        var t, u = null, s = this._source._layers;
        for (t in s)
          if (s[t]._map) {
            u = s[t];
            break;
          }
        if (!u)
          return !1;
        this._source = u;
      }
      if (!e)
        if (u.getCenter)
          e = u.getCenter();
        else if (u.getLatLng)
          e = u.getLatLng();
        else {
          if (!u.getBounds)
            throw new Error("Unable to get source layer LatLng.");
          e = u.getBounds().getCenter();
        }
      return this.setLatLng(e), this._map && this.update(), !0;
    }, _updateContent: function() {
      if (this._content) {
        var e = this._contentNode, t = typeof this._content == "function" ? this._content(this._source || this) : this._content;
        if (typeof t == "string")
          e.innerHTML = t;
        else {
          for (; e.hasChildNodes(); )
            e.removeChild(e.firstChild);
          e.appendChild(t);
        }
        this.fire("contentupdate");
      }
    }, _updatePosition: function() {
      var e, t, u;
      this._map && (t = this._map.latLngToLayerPoint(this._latlng), e = M(this.options.offset), u = this._getAnchor(), this._zoomAnimated ? Se(this._container, t.add(u)) : e = e.add(t).add(u), t = this._containerBottom = -e.y, u = this._containerLeft = -Math.round(this._containerWidth / 2) + e.x, this._container.style.bottom = t + "px", this._container.style.left = u + "px");
    }, _getAnchor: function() {
      return [0, 0];
    } }), sn = (ue.include({ _initOverlay: function(e, t, u, s) {
      var l = t;
      return l instanceof e || (l = new e(s).setContent(t)), u && l.setLatLng(u), l;
    } }), Ce.include({ _initOverlay: function(e, t, u, s) {
      var l = u;
      return l instanceof e ? (I(l, s), l._source = this) : (l = t && !s ? t : new e(s, this)).setContent(u), l;
    } }), Fe.extend({ options: { pane: "popupPane", offset: [0, 7], maxWidth: 300, minWidth: 50, maxHeight: null, autoPan: !0, autoPanPaddingTopLeft: null, autoPanPaddingBottomRight: null, autoPanPadding: [5, 5], keepInView: !1, closeButton: !0, autoClose: !0, closeOnEscapeKey: !0, className: "" }, openOn: function(e) {
      return !(e = arguments.length ? e : this._source._map).hasLayer(this) && e._popup && e._popup.options.autoClose && e.removeLayer(e._popup), e._popup = this, Fe.prototype.openOn.call(this, e);
    }, onAdd: function(e) {
      Fe.prototype.onAdd.call(this, e), e.fire("popupopen", { popup: this }), this._source && (this._source.fire("popupopen", { popup: this }, !0), this._source instanceof lt || this._source.on("preclick", bt));
    }, onRemove: function(e) {
      Fe.prototype.onRemove.call(this, e), e.fire("popupclose", { popup: this }), this._source && (this._source.fire("popupclose", { popup: this }, !0), this._source instanceof lt || this._source.off("preclick", bt));
    }, getEvents: function() {
      var e = Fe.prototype.getEvents.call(this);
      return (this.options.closeOnClick !== void 0 ? this.options.closeOnClick : this._map.options.closePopupOnClick) && (e.preclick = this.close), this.options.keepInView && (e.moveend = this._adjustPan), e;
    }, _initLayout: function() {
      var e = "leaflet-popup", t = this._container = oe("div", e + " " + (this.options.className || "") + " leaflet-zoom-animated"), u = this._wrapper = oe("div", e + "-content-wrapper", t);
      this._contentNode = oe("div", e + "-content", u), ii(t), lr(this._contentNode), Y(t, "contextmenu", bt), this._tipContainer = oe("div", e + "-tip-container", t), this._tip = oe("div", e + "-tip", this._tipContainer), this.options.closeButton && ((u = this._closeButton = oe("a", e + "-close-button", t)).setAttribute("role", "button"), u.setAttribute("aria-label", "Close popup"), u.href = "#close", u.innerHTML = '<span aria-hidden="true">&#215;</span>', Y(u, "click", function(s) {
        Pe(s), this.close();
      }, this));
    }, _updateLayout: function() {
      var e = this._contentNode, t = e.style, u = (t.width = "", t.whiteSpace = "nowrap", e.offsetWidth), u = Math.min(u, this.options.maxWidth), u = (u = Math.max(u, this.options.minWidth), t.width = u + 1 + "px", t.whiteSpace = "", t.height = "", e.offsetHeight), s = this.options.maxHeight, l = "leaflet-popup-scrolled";
      (s && s < u ? (t.height = s + "px", te) : ye)(e, l), this._containerWidth = this._container.offsetWidth;
    }, _animateZoom: function(t) {
      var t = this._map._latLngToNewLayerPoint(this._latlng, t.zoom, t.center), u = this._getAnchor();
      Se(this._container, t.add(u));
    }, _adjustPan: function() {
      var e, t, u, s, l, h, y, b;
      this.options.autoPan && (this._map._panAnim && this._map._panAnim.stop(), this._autopanning ? this._autopanning = !1 : (e = this._map, t = parseInt(ti(this._container, "marginBottom"), 10) || 0, t = this._container.offsetHeight + t, b = this._containerWidth, (u = new w(this._containerLeft, -t - this._containerBottom))._add(_t(this._container)), u = e.layerPointToContainerPoint(u), l = M(this.options.autoPanPadding), s = M(this.options.autoPanPaddingTopLeft || l), l = M(this.options.autoPanPaddingBottomRight || l), h = e.getSize(), y = 0, u.x + b + l.x > h.x && (y = u.x + b - h.x + l.x), u.x - y - s.x < (b = 0) && (y = u.x - s.x), u.y + t + l.y > h.y && (b = u.y + t - h.y + l.y), u.y - b - s.y < 0 && (b = u.y - s.y), (y || b) && (this.options.keepInView && (this._autopanning = !0), e.fire("autopanstart").panBy([y, b]))));
    }, _getAnchor: function() {
      return M(this._source && this._source._getPopupAnchor ? this._source._getPopupAnchor() : [0, 0]);
    } })), an = (ue.mergeOptions({ closePopupOnClick: !0 }), ue.include({ openPopup: function(e, t, u) {
      return this._initOverlay(sn, e, t, u).openOn(this), this;
    }, closePopup: function(e) {
      return (e = arguments.length ? e : this._popup) && e.close(), this;
    } }), Ce.include({ bindPopup: function(e, t) {
      return this._popup = this._initOverlay(sn, this._popup, e, t), this._popupHandlersAdded || (this.on({ click: this._openPopup, keypress: this._onKeyPress, remove: this.closePopup, move: this._movePopup }), this._popupHandlersAdded = !0), this;
    }, unbindPopup: function() {
      return this._popup && (this.off({ click: this._openPopup, keypress: this._onKeyPress, remove: this.closePopup, move: this._movePopup }), this._popupHandlersAdded = !1, this._popup = null), this;
    }, openPopup: function(e) {
      return this._popup && (this instanceof $e || (this._popup._source = this), this._popup._prepareOpen(e || this._latlng) && this._popup.openOn(this._map)), this;
    }, closePopup: function() {
      return this._popup && this._popup.close(), this;
    }, togglePopup: function() {
      return this._popup && this._popup.toggle(this), this;
    }, isPopupOpen: function() {
      return !!this._popup && this._popup.isOpen();
    }, setPopupContent: function(e) {
      return this._popup && this._popup.setContent(e), this;
    }, getPopup: function() {
      return this._popup;
    }, _openPopup: function(e) {
      var t;
      this._popup && this._map && (yt(e), t = e.layer || e.target, this._popup._source !== t || t instanceof lt ? (this._popup._source = t, this.openPopup(e.latlng)) : this._map.hasLayer(this._popup) ? this.closePopup() : this.openPopup(e.latlng));
    }, _movePopup: function(e) {
      this._popup.setLatLng(e.latlng);
    }, _onKeyPress: function(e) {
      e.originalEvent.keyCode === 13 && this._openPopup(e);
    } }), Fe.extend({ options: { pane: "tooltipPane", offset: [0, 0], direction: "auto", permanent: !1, sticky: !1, opacity: 0.9 }, onAdd: function(e) {
      Fe.prototype.onAdd.call(this, e), this.setOpacity(this.options.opacity), e.fire("tooltipopen", { tooltip: this }), this._source && (this.addEventParent(this._source), this._source.fire("tooltipopen", { tooltip: this }, !0));
    }, onRemove: function(e) {
      Fe.prototype.onRemove.call(this, e), e.fire("tooltipclose", { tooltip: this }), this._source && (this.removeEventParent(this._source), this._source.fire("tooltipclose", { tooltip: this }, !0));
    }, getEvents: function() {
      var e = Fe.prototype.getEvents.call(this);
      return this.options.permanent || (e.preclick = this.close), e;
    }, _initLayout: function() {
      var e = "leaflet-tooltip " + (this.options.className || "") + " leaflet-zoom-" + (this._zoomAnimated ? "animated" : "hide");
      this._contentNode = this._container = oe("div", e), this._container.setAttribute("role", "tooltip"), this._container.setAttribute("id", "leaflet-tooltip-" + d(this));
    }, _updateLayout: function() {
    }, _adjustPan: function() {
    }, _setPosition: function(e) {
      var t, k = this._map, u = this._container, s = k.latLngToContainerPoint(k.getCenter()), k = k.layerPointToContainerPoint(e), l = this.options.direction, h = u.offsetWidth, y = u.offsetHeight, b = M(this.options.offset), P = this._getAnchor(), k = l === "top" ? (t = h / 2, y) : l === "bottom" ? (t = h / 2, 0) : (t = l === "center" ? h / 2 : l === "right" ? 0 : l === "left" ? h : k.x < s.x ? (l = "right", 0) : (l = "left", h + 2 * (b.x + P.x)), y / 2);
      e = e.subtract(M(t, k, !0)).add(b).add(P), ye(u, "leaflet-tooltip-right"), ye(u, "leaflet-tooltip-left"), ye(u, "leaflet-tooltip-top"), ye(u, "leaflet-tooltip-bottom"), te(u, "leaflet-tooltip-" + l), Se(u, e);
    }, _updatePosition: function() {
      var e = this._map.latLngToLayerPoint(this._latlng);
      this._setPosition(e);
    }, setOpacity: function(e) {
      this.options.opacity = e, this._container && Be(this._container, e);
    }, _animateZoom: function(e) {
      e = this._map._latLngToNewLayerPoint(this._latlng, e.zoom, e.center), this._setPosition(e);
    }, _getAnchor: function() {
      return M(this._source && this._source._getTooltipAnchor && !this.options.sticky ? this._source._getTooltipAnchor() : [0, 0]);
    } })), Ru = (ue.include({ openTooltip: function(e, t, u) {
      return this._initOverlay(an, e, t, u).openOn(this), this;
    }, closeTooltip: function(e) {
      return e.close(), this;
    } }), Ce.include({ bindTooltip: function(e, t) {
      return this._tooltip && this.isTooltipOpen() && this.unbindTooltip(), this._tooltip = this._initOverlay(an, this._tooltip, e, t), this._initTooltipInteractions(), this._tooltip.options.permanent && this._map && this._map.hasLayer(this) && this.openTooltip(), this;
    }, unbindTooltip: function() {
      return this._tooltip && (this._initTooltipInteractions(!0), this.closeTooltip(), this._tooltip = null), this;
    }, _initTooltipInteractions: function(e) {
      var t, u;
      !e && this._tooltipHandlersAdded || (t = e ? "off" : "on", u = { remove: this.closeTooltip, move: this._moveTooltip }, this._tooltip.options.permanent ? u.add = this._openTooltip : (u.mouseover = this._openTooltip, u.mouseout = this.closeTooltip, u.click = this._openTooltip, this._map ? this._addFocusListeners() : u.add = this._addFocusListeners), this._tooltip.options.sticky && (u.mousemove = this._moveTooltip), this[t](u), this._tooltipHandlersAdded = !e);
    }, openTooltip: function(e) {
      return this._tooltip && (this instanceof $e || (this._tooltip._source = this), this._tooltip._prepareOpen(e) && (this._tooltip.openOn(this._map), this.getElement ? this._setAriaDescribedByOnLayer(this) : this.eachLayer && this.eachLayer(this._setAriaDescribedByOnLayer, this))), this;
    }, closeTooltip: function() {
      if (this._tooltip)
        return this._tooltip.close();
    }, toggleTooltip: function() {
      return this._tooltip && this._tooltip.toggle(this), this;
    }, isTooltipOpen: function() {
      return this._tooltip.isOpen();
    }, setTooltipContent: function(e) {
      return this._tooltip && this._tooltip.setContent(e), this;
    }, getTooltip: function() {
      return this._tooltip;
    }, _addFocusListeners: function() {
      this.getElement ? this._addFocusListenersOnLayer(this) : this.eachLayer && this.eachLayer(this._addFocusListenersOnLayer, this);
    }, _addFocusListenersOnLayer: function(e) {
      var t = typeof e.getElement == "function" && e.getElement();
      t && (Y(t, "focus", function() {
        this._tooltip._source = e, this.openTooltip();
      }, this), Y(t, "blur", this.closeTooltip, this));
    }, _setAriaDescribedByOnLayer: function(e) {
      e = typeof e.getElement == "function" && e.getElement(), e && e.setAttribute("aria-describedby", this._tooltip._container.id);
    }, _openTooltip: function(e) {
      var t;
      this._tooltip && this._map && (this._map.dragging && this._map.dragging.moving() && !this._openOnceFlag ? (this._openOnceFlag = !0, (t = this)._map.once("moveend", function() {
        t._openOnceFlag = !1, t._openTooltip(e);
      })) : (this._tooltip._source = e.layer || e.target, this.openTooltip(this._tooltip.options.sticky ? e.latlng : void 0)));
    }, _moveTooltip: function(e) {
      var t = e.latlng;
      this._tooltip.options.sticky && e.originalEvent && (e = this._map.mouseEventToContainerPoint(e.originalEvent), e = this._map.containerPointToLayerPoint(e), t = this._map.layerPointToLatLng(e)), this._tooltip.setLatLng(t);
    } }), Rt.extend({ options: { iconSize: [12, 12], html: !1, bgPos: null, className: "leaflet-div-icon" }, createIcon: function(t) {
      var t = t && t.tagName === "DIV" ? t : document.createElement("div"), u = this.options;
      return u.html instanceof Element ? (Hi(t), t.appendChild(u.html)) : t.innerHTML = u.html !== !1 ? u.html : "", u.bgPos && (u = M(u.bgPos), t.style.backgroundPosition = -u.x + "px " + -u.y + "px"), this._setIconStyles(t, "icon"), t;
    }, createShadow: function() {
      return null;
    } }));
    Rt.Default = oi;
    var si = Ce.extend({ options: { tileSize: 256, opacity: 1, updateWhenIdle: B.mobile, updateWhenZooming: !0, updateInterval: 200, zIndex: 1, bounds: null, minZoom: 0, maxZoom: void 0, maxNativeZoom: void 0, minNativeZoom: void 0, noWrap: !1, pane: "tilePane", className: "", keepBuffer: 2 }, initialize: function(e) {
      I(this, e);
    }, onAdd: function() {
      this._initContainer(), this._levels = {}, this._tiles = {}, this._resetView();
    }, beforeAdd: function(e) {
      e._addZoomLimit(this);
    }, onRemove: function(e) {
      this._removeAllTiles(), ge(this._container), e._removeZoomLimit(this), this._container = null, this._tileZoom = void 0;
    }, bringToFront: function() {
      return this._map && (Dt(this._container), this._setAutoZIndex(Math.max)), this;
    }, bringToBack: function() {
      return this._map && (Bt(this._container), this._setAutoZIndex(Math.min)), this;
    }, getContainer: function() {
      return this._container;
    }, setOpacity: function(e) {
      return this.options.opacity = e, this._updateOpacity(), this;
    }, setZIndex: function(e) {
      return this.options.zIndex = e, this._updateZIndex(), this;
    }, isLoading: function() {
      return this._loading;
    }, redraw: function() {
      var e;
      return this._map && (this._removeAllTiles(), (e = this._clampZoom(this._map.getZoom())) !== this._tileZoom && (this._tileZoom = e, this._updateLevels()), this._update()), this;
    }, getEvents: function() {
      var e = { viewprereset: this._invalidateAll, viewreset: this._resetView, zoom: this._resetView, moveend: this._onMoveEnd };
      return this.options.updateWhenIdle || (this._onMove || (this._onMove = _(this._onMoveEnd, this.options.updateInterval, this)), e.move = this._onMove), this._zoomAnimated && (e.zoomanim = this._animateZoom), e;
    }, createTile: function() {
      return document.createElement("div");
    }, getTileSize: function() {
      var e = this.options.tileSize;
      return e instanceof w ? e : new w(e, e);
    }, _updateZIndex: function() {
      this._container && this.options.zIndex !== void 0 && this.options.zIndex !== null && (this._container.style.zIndex = this.options.zIndex);
    }, _setAutoZIndex: function(e) {
      for (var t, u = this.getPane().children, s = -e(-1 / 0, 1 / 0), l = 0, h = u.length; l < h; l++)
        t = u[l].style.zIndex, u[l] !== this._container && t && (s = e(s, +t));
      isFinite(s) && (this.options.zIndex = s + e(-1, 1), this._updateZIndex());
    }, _updateOpacity: function() {
      if (this._map && !B.ielt9) {
        Be(this._container, this.options.opacity);
        var e, t = +/* @__PURE__ */ new Date(), u = !1, s = !1;
        for (e in this._tiles) {
          var l, h = this._tiles[e];
          h.current && h.loaded && (l = Math.min(1, (t - h.loaded) / 200), Be(h.el, l), l < 1 ? u = !0 : (h.active ? s = !0 : this._onOpaqueTile(h), h.active = !0));
        }
        s && !this._noPrune && this._pruneTiles(), u && (A(this._fadeFrame), this._fadeFrame = T(this._updateOpacity, this));
      }
    }, _onOpaqueTile: S, _initContainer: function() {
      this._container || (this._container = oe("div", "leaflet-layer " + (this.options.className || "")), this._updateZIndex(), this.options.opacity < 1 && this._updateOpacity(), this.getPane().appendChild(this._container));
    }, _updateLevels: function() {
      var e = this._tileZoom, t = this.options.maxZoom;
      if (e !== void 0) {
        for (var u in this._levels)
          u = Number(u), this._levels[u].el.children.length || u === e ? (this._levels[u].el.style.zIndex = t - Math.abs(e - u), this._onUpdateLevel(u)) : (ge(this._levels[u].el), this._removeTilesAtZoom(u), this._onRemoveLevel(u), delete this._levels[u]);
        var s = this._levels[e], l = this._map;
        return s || ((s = this._levels[e] = {}).el = oe("div", "leaflet-tile-container leaflet-zoom-animated", this._container), s.el.style.zIndex = t, s.origin = l.project(l.unproject(l.getPixelOrigin()), e).round(), s.zoom = e, this._setZoomTransform(s, l.getCenter(), l.getZoom()), S(s.el.offsetWidth), this._onCreateLevel(s)), this._level = s;
      }
    }, _onUpdateLevel: S, _onRemoveLevel: S, _onCreateLevel: S, _pruneTiles: function() {
      if (this._map) {
        var e, t, u, s = this._map.getZoom();
        if (s > this.options.maxZoom || s < this.options.minZoom)
          this._removeAllTiles();
        else {
          for (e in this._tiles)
            (u = this._tiles[e]).retain = u.current;
          for (e in this._tiles)
            (u = this._tiles[e]).current && !u.active && (t = u.coords, this._retainParent(t.x, t.y, t.z, t.z - 5) || this._retainChildren(t.x, t.y, t.z, t.z + 2));
          for (e in this._tiles)
            this._tiles[e].retain || this._removeTile(e);
        }
      }
    }, _removeTilesAtZoom: function(e) {
      for (var t in this._tiles)
        this._tiles[t].coords.z === e && this._removeTile(t);
    }, _removeAllTiles: function() {
      for (var e in this._tiles)
        this._removeTile(e);
    }, _invalidateAll: function() {
      for (var e in this._levels)
        ge(this._levels[e].el), this._onRemoveLevel(Number(e)), delete this._levels[e];
      this._removeAllTiles(), this._tileZoom = void 0;
    }, _retainParent: function(l, h, y, s) {
      var l = Math.floor(l / 2), h = Math.floor(h / 2), y = y - 1, b = new w(+l, +h), b = (b.z = y, this._tileCoordsToKey(b)), b = this._tiles[b];
      return b && b.active ? b.retain = !0 : (b && b.loaded && (b.retain = !0), s < y && this._retainParent(l, h, y, s));
    }, _retainChildren: function(e, t, u, s) {
      for (var l = 2 * e; l < 2 * e + 2; l++)
        for (var h = 2 * t; h < 2 * t + 2; h++) {
          var y = new w(l, h), y = (y.z = u + 1, this._tileCoordsToKey(y)), y = this._tiles[y];
          y && y.active ? y.retain = !0 : (y && y.loaded && (y.retain = !0), u + 1 < s && this._retainChildren(l, h, u + 1, s));
        }
    }, _resetView: function(e) {
      e = e && (e.pinch || e.flyTo), this._setView(this._map.getCenter(), this._map.getZoom(), e, e);
    }, _animateZoom: function(e) {
      this._setView(e.center, e.zoom, !0, e.noUpdate);
    }, _clampZoom: function(e) {
      var t = this.options;
      return t.minNativeZoom !== void 0 && e < t.minNativeZoom ? t.minNativeZoom : t.maxNativeZoom !== void 0 && t.maxNativeZoom < e ? t.maxNativeZoom : e;
    }, _setView: function(e, t, u, s) {
      var l = Math.round(t), l = this.options.maxZoom !== void 0 && l > this.options.maxZoom || this.options.minZoom !== void 0 && l < this.options.minZoom ? void 0 : this._clampZoom(l), h = this.options.updateWhenZooming && l !== this._tileZoom;
      s && !h || (this._tileZoom = l, this._abortLoading && this._abortLoading(), this._updateLevels(), this._resetGrid(), l !== void 0 && this._update(e), u || this._pruneTiles(), this._noPrune = !!u), this._setZoomTransforms(e, t);
    }, _setZoomTransforms: function(e, t) {
      for (var u in this._levels)
        this._setZoomTransform(this._levels[u], e, t);
    }, _setZoomTransform: function(e, l, u) {
      var s = this._map.getZoomScale(u, e.zoom), l = e.origin.multiplyBy(s).subtract(this._map._getNewPixelOrigin(l, u)).round();
      B.any3d ? gt(e.el, l, s) : Se(e.el, l);
    }, _resetGrid: function() {
      var e = this._map, t = e.options.crs, u = this._tileSize = this.getTileSize(), s = this._tileZoom, l = this._map.getPixelWorldBounds(this._tileZoom);
      l && (this._globalTileRange = this._pxBoundsToTileRange(l)), this._wrapX = t.wrapLng && !this.options.noWrap && [Math.floor(e.project([0, t.wrapLng[0]], s).x / u.x), Math.ceil(e.project([0, t.wrapLng[1]], s).x / u.y)], this._wrapY = t.wrapLat && !this.options.noWrap && [Math.floor(e.project([t.wrapLat[0], 0], s).y / u.x), Math.ceil(e.project([t.wrapLat[1], 0], s).y / u.y)];
    }, _onMoveEnd: function() {
      this._map && !this._map._animatingZoom && this._update();
    }, _getTiledPixelBounds: function(u) {
      var s = this._map, t = s._animatingZoom ? Math.max(s._animateToZoom, s.getZoom()) : s.getZoom(), t = s.getZoomScale(t, this._tileZoom), u = s.project(u, this._tileZoom).floor(), s = s.getSize().divideBy(2 * t);
      return new V(u.subtract(s), u.add(s));
    }, _update: function(e) {
      var t = this._map;
      if (t) {
        var u = this._clampZoom(t.getZoom());
        if (e === void 0 && (e = t.getCenter()), this._tileZoom !== void 0) {
          var s, t = this._getTiledPixelBounds(e), l = this._pxBoundsToTileRange(t), h = l.getCenter(), y = [], t = this.options.keepBuffer, b = new V(l.getBottomLeft().subtract([t, -t]), l.getTopRight().add([t, -t]));
          if (!(isFinite(l.min.x) && isFinite(l.min.y) && isFinite(l.max.x) && isFinite(l.max.y)))
            throw new Error("Attempted to load an infinite number of tiles");
          for (s in this._tiles) {
            var P = this._tiles[s].coords;
            P.z === this._tileZoom && b.contains(new w(P.x, P.y)) || (this._tiles[s].current = !1);
          }
          if (1 < Math.abs(u - this._tileZoom))
            this._setView(e, u);
          else {
            for (var k = l.min.y; k <= l.max.y; k++)
              for (var q = l.min.x; q <= l.max.x; q++) {
                var J, Q = new w(q, k);
                Q.z = this._tileZoom, this._isValidTile(Q) && ((J = this._tiles[this._tileCoordsToKey(Q)]) ? J.current = !0 : y.push(Q));
              }
            if (y.sort(function(Ae, Ne) {
              return Ae.distanceTo(h) - Ne.distanceTo(h);
            }), y.length !== 0) {
              this._loading || (this._loading = !0, this.fire("loading"));
              for (var me = document.createDocumentFragment(), q = 0; q < y.length; q++)
                this._addTile(y[q], me);
              this._level.el.appendChild(me);
            }
          }
        }
      }
    }, _isValidTile: function(e) {
      var t = this._map.options.crs;
      if (!t.infinite) {
        var u = this._globalTileRange;
        if (!t.wrapLng && (e.x < u.min.x || e.x > u.max.x) || !t.wrapLat && (e.y < u.min.y || e.y > u.max.y))
          return !1;
      }
      return !this.options.bounds || (t = this._tileCoordsToBounds(e), F(this.options.bounds).overlaps(t));
    }, _keyToBounds: function(e) {
      return this._tileCoordsToBounds(this._keyToTileCoords(e));
    }, _tileCoordsToNwSe: function(e) {
      var t = this._map, s = this.getTileSize(), u = e.scaleBy(s), s = u.add(s);
      return [t.unproject(u, e.z), t.unproject(s, e.z)];
    }, _tileCoordsToBounds: function(e) {
      return e = this._tileCoordsToNwSe(e), e = new we(e[0], e[1]), e = this.options.noWrap ? e : this._map.wrapLatLngBounds(e);
    }, _tileCoordsToKey: function(e) {
      return e.x + ":" + e.y + ":" + e.z;
    }, _keyToTileCoords: function(t) {
      var t = t.split(":"), u = new w(+t[0], +t[1]);
      return u.z = +t[2], u;
    }, _removeTile: function(e) {
      var t = this._tiles[e];
      t && (ge(t.el), delete this._tiles[e], this.fire("tileunload", { tile: t.el, coords: this._keyToTileCoords(e) }));
    }, _initTile: function(e) {
      te(e, "leaflet-tile");
      var t = this.getTileSize();
      e.style.width = t.x + "px", e.style.height = t.y + "px", e.onselectstart = S, e.onmousemove = S, B.ielt9 && this.options.opacity < 1 && Be(e, this.options.opacity);
    }, _addTile: function(e, t) {
      var u = this._getTilePos(e), s = this._tileCoordsToKey(e), l = this.createTile(this._wrapCoords(e), p(this._tileReady, this, e));
      this._initTile(l), this.createTile.length < 2 && T(p(this._tileReady, this, e, null, l)), Se(l, u), this._tiles[s] = { el: l, coords: e, current: !0 }, t.appendChild(l), this.fire("tileloadstart", { tile: l, coords: e });
    }, _tileReady: function(e, t, u) {
      t && this.fire("tileerror", { error: t, tile: u, coords: e });
      var s = this._tileCoordsToKey(e);
      (u = this._tiles[s]) && (u.loaded = +/* @__PURE__ */ new Date(), this._map._fadeAnimated ? (Be(u.el, 0), A(this._fadeFrame), this._fadeFrame = T(this._updateOpacity, this)) : (u.active = !0, this._pruneTiles()), t || (te(u.el, "leaflet-tile-loaded"), this.fire("tileload", { tile: u.el, coords: e })), this._noTilesToLoad() && (this._loading = !1, this.fire("load"), B.ielt9 || !this._map._fadeAnimated ? T(this._pruneTiles, this) : setTimeout(p(this._pruneTiles, this), 250)));
    }, _getTilePos: function(e) {
      return e.scaleBy(this.getTileSize()).subtract(this._level.origin);
    }, _wrapCoords: function(e) {
      var t = new w(this._wrapX ? v(e.x, this._wrapX) : e.x, this._wrapY ? v(e.y, this._wrapY) : e.y);
      return t.z = e.z, t;
    }, _pxBoundsToTileRange: function(e) {
      var t = this.getTileSize();
      return new V(e.min.unscaleBy(t).floor(), e.max.unscaleBy(t).ceil().subtract([1, 1]));
    }, _noTilesToLoad: function() {
      for (var e in this._tiles)
        if (!this._tiles[e].loaded)
          return !1;
      return !0;
    } }), Zt = si.extend({ options: { minZoom: 0, maxZoom: 18, subdomains: "abc", errorTileUrl: "", zoomOffset: 0, tms: !1, zoomReverse: !1, detectRetina: !1, crossOrigin: !1, referrerPolicy: !1 }, initialize: function(e, t) {
      this._url = e, (t = I(this, t)).detectRetina && B.retina && 0 < t.maxZoom ? (t.tileSize = Math.floor(t.tileSize / 2), t.zoomReverse ? (t.zoomOffset--, t.minZoom = Math.min(t.maxZoom, t.minZoom + 1)) : (t.zoomOffset++, t.maxZoom = Math.max(t.minZoom, t.maxZoom - 1)), t.minZoom = Math.max(0, t.minZoom)) : t.zoomReverse ? t.minZoom = Math.min(t.maxZoom, t.minZoom) : t.maxZoom = Math.max(t.minZoom, t.maxZoom), typeof t.subdomains == "string" && (t.subdomains = t.subdomains.split("")), this.on("tileunload", this._onTileRemove);
    }, setUrl: function(e, t) {
      return this._url === e && t === void 0 && (t = !0), this._url = e, t || this.redraw(), this;
    }, createTile: function(e, t) {
      var u = document.createElement("img");
      return Y(u, "load", p(this._tileOnLoad, this, t, u)), Y(u, "error", p(this._tileOnError, this, t, u)), !this.options.crossOrigin && this.options.crossOrigin !== "" || (u.crossOrigin = this.options.crossOrigin === !0 ? "" : this.options.crossOrigin), typeof this.options.referrerPolicy == "string" && (u.referrerPolicy = this.options.referrerPolicy), u.alt = "", u.src = this.getTileUrl(e), u;
    }, getTileUrl: function(e) {
      var t = { r: B.retina ? "@2x" : "", s: this._getSubdomain(e), x: e.x, y: e.y, z: this._getZoomForUrl() };
      return this._map && !this._map.options.crs.infinite && (e = this._globalTileRange.max.y - e.y, this.options.tms && (t.y = e), t["-y"] = e), H(this._url, r(t, this.options));
    }, _tileOnLoad: function(e, t) {
      B.ielt9 ? setTimeout(p(e, this, null, t), 0) : e(null, t);
    }, _tileOnError: function(e, t, u) {
      var s = this.options.errorTileUrl;
      s && t.getAttribute("src") !== s && (t.src = s), e(u, t);
    }, _onTileRemove: function(e) {
      e.tile.onload = null;
    }, _getZoomForUrl: function() {
      var e = this._tileZoom, t = this.options.maxZoom;
      return (e = this.options.zoomReverse ? t - e : e) + this.options.zoomOffset;
    }, _getSubdomain: function(e) {
      return e = Math.abs(e.x + e.y) % this.options.subdomains.length, this.options.subdomains[e];
    }, _abortLoading: function() {
      var e, t, u;
      for (e in this._tiles)
        this._tiles[e].coords.z !== this._tileZoom && ((u = this._tiles[e].el).onload = S, u.onerror = S, u.complete || (u.src = re, t = this._tiles[e].coords, ge(u), delete this._tiles[e], this.fire("tileabort", { tile: u, coords: t })));
    }, _removeTile: function(e) {
      var t = this._tiles[e];
      if (t)
        return t.el.setAttribute("src", re), si.prototype._removeTile.call(this, e);
    }, _tileReady: function(e, t, u) {
      if (this._map && (!u || u.getAttribute("src") !== re))
        return si.prototype._tileReady.call(this, e, t, u);
    } });
    function ju(e, t) {
      return new Zt(e, t);
    }
    var qu = Zt.extend({ defaultWmsParams: { service: "WMS", request: "GetMap", layers: "", styles: "", format: "image/jpeg", transparent: !1, version: "1.1.1" }, options: { crs: null, uppercase: !1 }, initialize: function(l, t) {
      this._url = l;
      var u, s = r({}, this.defaultWmsParams);
      for (u in t)
        u in this.options || (s[u] = t[u]);
      var l = (t = I(this, t)).detectRetina && B.retina ? 2 : 1, h = this.getTileSize();
      s.width = h.x * l, s.height = h.y * l, this.wmsParams = s;
    }, onAdd: function(e) {
      this._crs = this.options.crs || e.options.crs, this._wmsVersion = parseFloat(this.wmsParams.version);
      var t = 1.3 <= this._wmsVersion ? "crs" : "srs";
      this.wmsParams[t] = this._crs.code, Zt.prototype.onAdd.call(this, e);
    }, getTileUrl: function(e) {
      var t = this._tileCoordsToNwSe(e), u = this._crs, u = pe(u.project(t[0]), u.project(t[1])), t = u.min, u = u.max, t = (1.3 <= this._wmsVersion && this._crs === Iu ? [t.y, t.x, u.y, u.x] : [t.x, t.y, u.x, u.y]).join(","), u = Zt.prototype.getTileUrl.call(this, e);
      return u + E(this.wmsParams, u, this.options.uppercase) + (this.options.uppercase ? "&BBOX=" : "&bbox=") + t;
    }, setParams: function(e, t) {
      return r(this.wmsParams, e), t || this.redraw(), this;
    } });
    Zt.WMS = qu, ju.wms = function(e, t) {
      return new qu(e, t);
    };
    var Ke = Ce.extend({ options: { padding: 0.1 }, initialize: function(e) {
      I(this, e), d(this), this._layers = this._layers || {};
    }, onAdd: function() {
      this._container || (this._initContainer(), te(this._container, "leaflet-zoom-animated")), this.getPane().appendChild(this._container), this._update(), this.on("update", this._updatePaths, this);
    }, onRemove: function() {
      this.off("update", this._updatePaths, this), this._destroyContainer();
    }, getEvents: function() {
      var e = { viewreset: this._reset, zoom: this._onZoom, moveend: this._update, zoomend: this._onZoomEnd };
      return this._zoomAnimated && (e.zoomanim = this._onAnimZoom), e;
    }, _onAnimZoom: function(e) {
      this._updateTransform(e.center, e.zoom);
    }, _onZoom: function() {
      this._updateTransform(this._map.getCenter(), this._map.getZoom());
    }, _updateTransform: function(e, t) {
      var u = this._map.getZoomScale(t, this._zoom), l = this._map.getSize().multiplyBy(0.5 + this.options.padding), s = this._map.project(this._center, t), l = l.multiplyBy(-u).add(s).subtract(this._map._getNewPixelOrigin(e, t));
      B.any3d ? gt(this._container, l, u) : Se(this._container, l);
    }, _reset: function() {
      for (var e in this._update(), this._updateTransform(this._center, this._zoom), this._layers)
        this._layers[e]._reset();
    }, _onZoomEnd: function() {
      for (var e in this._layers)
        this._layers[e]._project();
    }, _updatePaths: function() {
      for (var e in this._layers)
        this._layers[e]._update();
    }, _update: function() {
      var e = this.options.padding, t = this._map.getSize(), u = this._map.containerPointToLayerPoint(t.multiplyBy(-e)).round();
      this._bounds = new V(u, u.add(t.multiplyBy(1 + 2 * e)).round()), this._center = this._map.getCenter(), this._zoom = this._map.getZoom();
    } }), Zu = Ke.extend({ options: { tolerance: 0 }, getEvents: function() {
      var e = Ke.prototype.getEvents.call(this);
      return e.viewprereset = this._onViewPreReset, e;
    }, _onViewPreReset: function() {
      this._postponeUpdatePaths = !0;
    }, onAdd: function() {
      Ke.prototype.onAdd.call(this), this._draw();
    }, _initContainer: function() {
      var e = this._container = document.createElement("canvas");
      Y(e, "mousemove", this._onMouseMove, this), Y(e, "click dblclick mousedown mouseup contextmenu", this._onClick, this), Y(e, "mouseout", this._handleMouseOut, this), e._leaflet_disable_events = !0, this._ctx = e.getContext("2d");
    }, _destroyContainer: function() {
      A(this._redrawRequest), delete this._ctx, ge(this._container), ce(this._container), delete this._container;
    }, _updatePaths: function() {
      if (!this._postponeUpdatePaths) {
        for (var e in this._redrawBounds = null, this._layers)
          this._layers[e]._update();
        this._redraw();
      }
    }, _update: function() {
      var e, t, u, s;
      this._map._animatingZoom && this._bounds || (Ke.prototype._update.call(this), e = this._bounds, t = this._container, u = e.getSize(), s = B.retina ? 2 : 1, Se(t, e.min), t.width = s * u.x, t.height = s * u.y, t.style.width = u.x + "px", t.style.height = u.y + "px", B.retina && this._ctx.scale(2, 2), this._ctx.translate(-e.min.x, -e.min.y), this.fire("update"));
    }, _reset: function() {
      Ke.prototype._reset.call(this), this._postponeUpdatePaths && (this._postponeUpdatePaths = !1, this._updatePaths());
    }, _initPath: function(e) {
      this._updateDashArray(e), e = (this._layers[d(e)] = e)._order = { layer: e, prev: this._drawLast, next: null }, this._drawLast && (this._drawLast.next = e), this._drawLast = e, this._drawFirst = this._drawFirst || this._drawLast;
    }, _addPath: function(e) {
      this._requestRedraw(e);
    }, _removePath: function(e) {
      var u = e._order, t = u.next, u = u.prev;
      t ? t.prev = u : this._drawLast = u, u ? u.next = t : this._drawFirst = t, delete e._order, delete this._layers[d(e)], this._requestRedraw(e);
    }, _updatePath: function(e) {
      this._extendRedrawBounds(e), e._project(), e._update(), this._requestRedraw(e);
    }, _updateStyle: function(e) {
      this._updateDashArray(e), this._requestRedraw(e);
    }, _updateDashArray: function(e) {
      if (typeof e.options.dashArray == "string") {
        for (var t, u = e.options.dashArray.split(/[, ]+/), s = [], l = 0; l < u.length; l++) {
          if (t = Number(u[l]), isNaN(t))
            return;
          s.push(t);
        }
        e.options._dashArray = s;
      } else
        e.options._dashArray = e.options.dashArray;
    }, _requestRedraw: function(e) {
      this._map && (this._extendRedrawBounds(e), this._redrawRequest = this._redrawRequest || T(this._redraw, this));
    }, _extendRedrawBounds: function(e) {
      var t;
      e._pxBounds && (t = (e.options.weight || 0) + 1, this._redrawBounds = this._redrawBounds || new V(), this._redrawBounds.extend(e._pxBounds.min.subtract([t, t])), this._redrawBounds.extend(e._pxBounds.max.add([t, t])));
    }, _redraw: function() {
      this._redrawRequest = null, this._redrawBounds && (this._redrawBounds.min._floor(), this._redrawBounds.max._ceil()), this._clear(), this._draw(), this._redrawBounds = null;
    }, _clear: function() {
      var e, t = this._redrawBounds;
      t ? (e = t.getSize(), this._ctx.clearRect(t.min.x, t.min.y, e.x, e.y)) : (this._ctx.save(), this._ctx.setTransform(1, 0, 0, 1, 0, 0), this._ctx.clearRect(0, 0, this._container.width, this._container.height), this._ctx.restore());
    }, _draw: function() {
      var e, t, u = this._redrawBounds;
      this._ctx.save(), u && (t = u.getSize(), this._ctx.beginPath(), this._ctx.rect(u.min.x, u.min.y, t.x, t.y), this._ctx.clip()), this._drawing = !0;
      for (var s = this._drawFirst; s; s = s.next)
        e = s.layer, (!u || e._pxBounds && e._pxBounds.intersects(u)) && e._updatePath();
      this._drawing = !1, this._ctx.restore();
    }, _updatePoly: function(e, t) {
      if (this._drawing) {
        var u, s, l, h, y = e._parts, b = y.length, P = this._ctx;
        if (b) {
          for (P.beginPath(), u = 0; u < b; u++) {
            for (s = 0, l = y[u].length; s < l; s++)
              h = y[u][s], P[s ? "lineTo" : "moveTo"](h.x, h.y);
            t && P.closePath();
          }
          this._fillStroke(P, e);
        }
      }
    }, _updateCircle: function(e) {
      var t, u, s, l;
      this._drawing && !e._empty() && (t = e._point, u = this._ctx, s = Math.max(Math.round(e._radius), 1), (l = (Math.max(Math.round(e._radiusY), 1) || s) / s) != 1 && (u.save(), u.scale(1, l)), u.beginPath(), u.arc(t.x, t.y / l, s, 0, 2 * Math.PI, !1), l != 1 && u.restore(), this._fillStroke(u, e));
    }, _fillStroke: function(e, t) {
      var u = t.options;
      u.fill && (e.globalAlpha = u.fillOpacity, e.fillStyle = u.fillColor || u.color, e.fill(u.fillRule || "evenodd")), u.stroke && u.weight !== 0 && (e.setLineDash && e.setLineDash(t.options && t.options._dashArray || []), e.globalAlpha = u.opacity, e.lineWidth = u.weight, e.strokeStyle = u.color, e.lineCap = u.lineCap, e.lineJoin = u.lineJoin, e.stroke());
    }, _onClick: function(e) {
      for (var t, u, s = this._map.mouseEventToLayerPoint(e), l = this._drawFirst; l; l = l.next)
        (t = l.layer).options.interactive && t._containsPoint(s) && ((e.type === "click" || e.type === "preclick") && this._map._draggableMoved(t) || (u = t));
      this._fireEvent(!!u && [u], e);
    }, _onMouseMove: function(e) {
      var t;
      !this._map || this._map.dragging.moving() || this._map._animatingZoom || (t = this._map.mouseEventToLayerPoint(e), this._handleMouseHover(e, t));
    }, _handleMouseOut: function(e) {
      var t = this._hoveredLayer;
      t && (ye(this._container, "leaflet-interactive"), this._fireEvent([t], e, "mouseout"), this._hoveredLayer = null, this._mouseHoverThrottled = !1);
    }, _handleMouseHover: function(e, t) {
      if (!this._mouseHoverThrottled) {
        for (var u, s, l = this._drawFirst; l; l = l.next)
          (u = l.layer).options.interactive && u._containsPoint(t) && (s = u);
        s !== this._hoveredLayer && (this._handleMouseOut(e), s && (te(this._container, "leaflet-interactive"), this._fireEvent([s], e, "mouseover"), this._hoveredLayer = s)), this._fireEvent(!!this._hoveredLayer && [this._hoveredLayer], e), this._mouseHoverThrottled = !0, setTimeout(p(function() {
          this._mouseHoverThrottled = !1;
        }, this), 32);
      }
    }, _fireEvent: function(e, t, u) {
      this._map._fireDOMEvent(t, u || t.type, e);
    }, _bringToFront: function(e) {
      var t, u, s = e._order;
      s && (t = s.next, u = s.prev, t && ((t.prev = u) ? u.next = t : t && (this._drawFirst = t), s.prev = this._drawLast, (this._drawLast.next = s).next = null, this._drawLast = s, this._requestRedraw(e)));
    }, _bringToBack: function(e) {
      var t, u, s = e._order;
      s && (t = s.next, (u = s.prev) && ((u.next = t) ? t.prev = u : u && (this._drawLast = u), s.prev = null, s.next = this._drawFirst, this._drawFirst.prev = s, this._drawFirst = s, this._requestRedraw(e)));
    } });
    function Fu(e) {
      return B.canvas ? new Zu(e) : null;
    }
    var ai = function() {
      try {
        return document.namespaces.add("lvml", "urn:schemas-microsoft-com:vml"), function(e) {
          return document.createElement("<lvml:" + e + ' class="lvml">');
        };
      } catch {
      }
      return function(e) {
        return document.createElement("<" + e + ' xmlns="urn:schemas-microsoft.com:vml" class="lvml">');
      };
    }(), li = { _initContainer: function() {
      this._container = oe("div", "leaflet-vml-container");
    }, _update: function() {
      this._map._animatingZoom || (Ke.prototype._update.call(this), this.fire("update"));
    }, _initPath: function(e) {
      var t = e._container = ai("shape");
      te(t, "leaflet-vml-shape " + (this.options.className || "")), t.coordsize = "1 1", e._path = ai("path"), t.appendChild(e._path), this._updateStyle(e), this._layers[d(e)] = e;
    }, _addPath: function(e) {
      var t = e._container;
      this._container.appendChild(t), e.options.interactive && e.addInteractiveTarget(t);
    }, _removePath: function(e) {
      var t = e._container;
      ge(t), e.removeInteractiveTarget(t), delete this._layers[d(e)];
    }, _updateStyle: function(e) {
      var t = e._stroke, u = e._fill, s = e.options, l = e._container;
      l.stroked = !!s.stroke, l.filled = !!s.fill, s.stroke ? (t = t || (e._stroke = ai("stroke")), l.appendChild(t), t.weight = s.weight + "px", t.color = s.color, t.opacity = s.opacity, s.dashArray ? t.dashStyle = U(s.dashArray) ? s.dashArray.join(" ") : s.dashArray.replace(/( *, *)/g, " ") : t.dashStyle = "", t.endcap = s.lineCap.replace("butt", "flat"), t.joinstyle = s.lineJoin) : t && (l.removeChild(t), e._stroke = null), s.fill ? (u = u || (e._fill = ai("fill")), l.appendChild(u), u.color = s.fillColor || s.color, u.opacity = s.fillOpacity) : u && (l.removeChild(u), e._fill = null);
    }, _updateCircle: function(e) {
      var t = e._point.round(), u = Math.round(e._radius), s = Math.round(e._radiusY || u);
      this._setPath(e, e._empty() ? "M0 0" : "AL " + t.x + "," + t.y + " " + u + "," + s + " 0,23592600");
    }, _setPath: function(e, t) {
      e._path.v = t;
    }, _bringToFront: function(e) {
      Dt(e._container);
    }, _bringToBack: function(e) {
      Bt(e._container);
    } }, ln = B.vml ? ai : Ct, ci = Ke.extend({ _initContainer: function() {
      this._container = ln("svg"), this._container.setAttribute("pointer-events", "none"), this._rootGroup = ln("g"), this._container.appendChild(this._rootGroup);
    }, _destroyContainer: function() {
      ge(this._container), ce(this._container), delete this._container, delete this._rootGroup, delete this._svgSize;
    }, _update: function() {
      var e, t, u;
      this._map._animatingZoom && this._bounds || (Ke.prototype._update.call(this), t = (e = this._bounds).getSize(), u = this._container, this._svgSize && this._svgSize.equals(t) || (this._svgSize = t, u.setAttribute("width", t.x), u.setAttribute("height", t.y)), Se(u, e.min), u.setAttribute("viewBox", [e.min.x, e.min.y, t.x, t.y].join(" ")), this.fire("update"));
    }, _initPath: function(e) {
      var t = e._path = ln("path");
      e.options.className && te(t, e.options.className), e.options.interactive && te(t, "leaflet-interactive"), this._updateStyle(e), this._layers[d(e)] = e;
    }, _addPath: function(e) {
      this._rootGroup || this._initContainer(), this._rootGroup.appendChild(e._path), e.addInteractiveTarget(e._path);
    }, _removePath: function(e) {
      ge(e._path), e.removeInteractiveTarget(e._path), delete this._layers[d(e)];
    }, _updatePath: function(e) {
      e._project(), e._update();
    }, _updateStyle: function(u) {
      var t = u._path, u = u.options;
      t && (u.stroke ? (t.setAttribute("stroke", u.color), t.setAttribute("stroke-opacity", u.opacity), t.setAttribute("stroke-width", u.weight), t.setAttribute("stroke-linecap", u.lineCap), t.setAttribute("stroke-linejoin", u.lineJoin), u.dashArray ? t.setAttribute("stroke-dasharray", u.dashArray) : t.removeAttribute("stroke-dasharray"), u.dashOffset ? t.setAttribute("stroke-dashoffset", u.dashOffset) : t.removeAttribute("stroke-dashoffset")) : t.setAttribute("stroke", "none"), u.fill ? (t.setAttribute("fill", u.fillColor || u.color), t.setAttribute("fill-opacity", u.fillOpacity), t.setAttribute("fill-rule", u.fillRule || "evenodd")) : t.setAttribute("fill", "none"));
    }, _updatePoly: function(e, t) {
      this._setPath(e, Mt(e._parts, t));
    }, _updateCircle: function(e) {
      var s = e._point, t = Math.max(Math.round(e._radius), 1), u = "a" + t + "," + (Math.max(Math.round(e._radiusY), 1) || t) + " 0 1,0 ", s = e._empty() ? "M0 0" : "M" + (s.x - t) + "," + s.y + u + 2 * t + ",0 " + u + 2 * -t + ",0 ";
      this._setPath(e, s);
    }, _setPath: function(e, t) {
      e._path.setAttribute("d", t);
    }, _bringToFront: function(e) {
      Dt(e._path);
    }, _bringToBack: function(e) {
      Bt(e._path);
    } });
    function Hu(e) {
      return B.svg || B.vml ? new ci(e) : null;
    }
    B.vml && ci.include(li), ue.include({ getRenderer: function(e) {
      return e = (e = e.options.renderer || this._getPaneRenderer(e.options.pane) || this.options.renderer || this._renderer) || (this._renderer = this._createRenderer()), this.hasLayer(e) || this.addLayer(e), e;
    }, _getPaneRenderer: function(e) {
      var t;
      return e !== "overlayPane" && e !== void 0 && ((t = this._paneRenderers[e]) === void 0 && (t = this._createRenderer({ pane: e }), this._paneRenderers[e] = t), t);
    }, _createRenderer: function(e) {
      return this.options.preferCanvas && Fu(e) || Hu(e);
    } });
    var Uu = jt.extend({ initialize: function(e, t) {
      jt.prototype.initialize.call(this, this._boundsToLatLngs(e), t);
    }, setBounds: function(e) {
      return this.setLatLngs(this._boundsToLatLngs(e));
    }, _boundsToLatLngs: function(e) {
      return [(e = F(e)).getSouthWest(), e.getNorthWest(), e.getNorthEast(), e.getSouthEast()];
    } });
    ci.create = ln, ci.pointsToPath = Mt, Ye.geometryToLayer = en, Ye.coordsToLatLng = _r, Ye.coordsToLatLngs = tn, Ye.latLngToCoords = br, Ye.latLngsToCoords = nn, Ye.getFeature = qt, Ye.asFeature = rn, ue.mergeOptions({ boxZoom: !0 });
    var Je = Ie.extend({ initialize: function(e) {
      this._map = e, this._container = e._container, this._pane = e._panes.overlayPane, this._resetStateTimeout = 0, e.on("unload", this._destroy, this);
    }, addHooks: function() {
      Y(this._container, "mousedown", this._onMouseDown, this);
    }, removeHooks: function() {
      ce(this._container, "mousedown", this._onMouseDown, this);
    }, moved: function() {
      return this._moved;
    }, _destroy: function() {
      ge(this._pane), delete this._pane;
    }, _resetState: function() {
      this._resetStateTimeout = 0, this._moved = !1;
    }, _clearDeferredResetState: function() {
      this._resetStateTimeout !== 0 && (clearTimeout(this._resetStateTimeout), this._resetStateTimeout = 0);
    }, _onMouseDown: function(e) {
      if (!e.shiftKey || e.which !== 1 && e.button !== 1)
        return !1;
      this._clearDeferredResetState(), this._resetState(), Qt(), ir(), this._startPoint = this._map.mouseEventToContainerPoint(e), Y(document, { contextmenu: yt, mousemove: this._onMouseMove, mouseup: this._onMouseUp, keydown: this._onKeyDown }, this);
    }, _onMouseMove: function(t) {
      this._moved || (this._moved = !0, this._box = oe("div", "leaflet-zoom-box", this._container), te(this._container, "leaflet-crosshair"), this._map.fire("boxzoomstart")), this._point = this._map.mouseEventToContainerPoint(t);
      var t = new V(this._point, this._startPoint), u = t.getSize();
      Se(this._box, t.min), this._box.style.width = u.x + "px", this._box.style.height = u.y + "px";
    }, _finish: function() {
      this._moved && (ge(this._box), ye(this._container, "leaflet-crosshair")), Zi(), nr(), ce(document, { contextmenu: yt, mousemove: this._onMouseMove, mouseup: this._onMouseUp, keydown: this._onKeyDown }, this);
    }, _onMouseUp: function(e) {
      e.which !== 1 && e.button !== 1 || (this._finish(), this._moved && (this._clearDeferredResetState(), this._resetStateTimeout = setTimeout(p(this._resetState, this), 0), e = new we(this._map.containerPointToLatLng(this._startPoint), this._map.containerPointToLatLng(this._point)), this._map.fitBounds(e).fire("boxzoomend", { boxZoomBounds: e })));
    }, _onKeyDown: function(e) {
      e.keyCode === 27 && (this._finish(), this._clearDeferredResetState(), this._resetState());
    } }), cn = (ue.addInitHook("addHandler", "boxZoom", Je), ue.mergeOptions({ doubleClickZoom: !0 }), Ie.extend({ addHooks: function() {
      this._map.on("dblclick", this._onDoubleClick, this);
    }, removeHooks: function() {
      this._map.off("dblclick", this._onDoubleClick, this);
    }, _onDoubleClick: function(e) {
      var t = this._map, s = t.getZoom(), u = t.options.zoomDelta, s = e.originalEvent.shiftKey ? s - u : s + u;
      t.options.doubleClickZoom === "center" ? t.setZoom(s) : t.setZoomAround(e.containerPoint, s);
    } })), ct = (ue.addInitHook("addHandler", "doubleClickZoom", cn), ue.mergeOptions({ dragging: !0, inertia: !0, inertiaDeceleration: 3400, inertiaMaxSpeed: 1 / 0, easeLinearity: 0.2, worldCopyJump: !1, maxBoundsViscosity: 0 }), Ie.extend({ addHooks: function() {
      var e;
      this._draggable || (e = this._map, this._draggable = new at(e._mapPane, e._container), this._draggable.on({ dragstart: this._onDragStart, drag: this._onDrag, dragend: this._onDragEnd }, this), this._draggable.on("predrag", this._onPreDragLimit, this), e.options.worldCopyJump && (this._draggable.on("predrag", this._onPreDragWrap, this), e.on("zoomend", this._onZoomEnd, this), e.whenReady(this._onZoomEnd, this))), te(this._map._container, "leaflet-grab leaflet-touch-drag"), this._draggable.enable(), this._positions = [], this._times = [];
    }, removeHooks: function() {
      ye(this._map._container, "leaflet-grab"), ye(this._map._container, "leaflet-touch-drag"), this._draggable.disable();
    }, moved: function() {
      return this._draggable && this._draggable._moved;
    }, moving: function() {
      return this._draggable && this._draggable._moving;
    }, _onDragStart: function() {
      var e, t = this._map;
      t._stop(), this._map.options.maxBounds && this._map.options.maxBoundsViscosity ? (e = F(this._map.options.maxBounds), this._offsetLimit = pe(this._map.latLngToContainerPoint(e.getNorthWest()).multiplyBy(-1), this._map.latLngToContainerPoint(e.getSouthEast()).multiplyBy(-1).add(this._map.getSize())), this._viscosity = Math.min(1, Math.max(0, this._map.options.maxBoundsViscosity))) : this._offsetLimit = null, t.fire("movestart").fire("dragstart"), t.options.inertia && (this._positions = [], this._times = []);
    }, _onDrag: function(e) {
      var t, u;
      this._map.options.inertia && (t = this._lastTime = +/* @__PURE__ */ new Date(), u = this._lastPos = this._draggable._absPos || this._draggable._newPos, this._positions.push(u), this._times.push(t), this._prunePositions(t)), this._map.fire("move", e).fire("drag", e);
    }, _prunePositions: function(e) {
      for (; 1 < this._positions.length && 50 < e - this._times[0]; )
        this._positions.shift(), this._times.shift();
    }, _onZoomEnd: function() {
      var e = this._map.getSize().divideBy(2), t = this._map.latLngToLayerPoint([0, 0]);
      this._initialWorldOffset = t.subtract(e).x, this._worldWidth = this._map.getPixelWorldBounds().getSize().x;
    }, _viscousLimit: function(e, t) {
      return e - (e - t) * this._viscosity;
    }, _onPreDragLimit: function() {
      var e, t;
      this._viscosity && this._offsetLimit && (e = this._draggable._newPos.subtract(this._draggable._startPos), t = this._offsetLimit, e.x < t.min.x && (e.x = this._viscousLimit(e.x, t.min.x)), e.y < t.min.y && (e.y = this._viscousLimit(e.y, t.min.y)), e.x > t.max.x && (e.x = this._viscousLimit(e.x, t.max.x)), e.y > t.max.y && (e.y = this._viscousLimit(e.y, t.max.y)), this._draggable._newPos = this._draggable._startPos.add(e));
    }, _onPreDragWrap: function() {
      var l = this._worldWidth, e = Math.round(l / 2), t = this._initialWorldOffset, s = this._draggable._newPos.x, u = (s - e + t) % l + e - t, s = (s + e + t) % l - e - t, l = Math.abs(u + t) < Math.abs(s + t) ? u : s;
      this._draggable._absPos = this._draggable._newPos.clone(), this._draggable._newPos.x = l;
    }, _onDragEnd: function(e) {
      var t, u, s, l, h = this._map, y = h.options, b = !y.inertia || e.noInertia || this._times.length < 2;
      h.fire("dragend", e), !b && (this._prunePositions(+/* @__PURE__ */ new Date()), e = this._lastPos.subtract(this._positions[0]), b = (this._lastTime - this._times[0]) / 1e3, t = y.easeLinearity, b = (e = e.multiplyBy(t / b)).distanceTo([0, 0]), u = Math.min(y.inertiaMaxSpeed, b), e = e.multiplyBy(u / b), s = u / (y.inertiaDeceleration * t), (l = e.multiplyBy(-s / 2).round()).x || l.y) ? (l = h._limitOffset(l, h.options.maxBounds), T(function() {
        h.panBy(l, { duration: s, easeLinearity: t, noMoveStart: !0, animate: !0 });
      })) : h.fire("moveend");
    } })), hn = (ue.addInitHook("addHandler", "dragging", ct), ue.mergeOptions({ keyboard: !0, keyboardPanDelta: 80 }), Ie.extend({ keyCodes: { left: [37], right: [39], down: [40], up: [38], zoomIn: [187, 107, 61, 171], zoomOut: [189, 109, 54, 173] }, initialize: function(e) {
      this._map = e, this._setPanDelta(e.options.keyboardPanDelta), this._setZoomDelta(e.options.zoomDelta);
    }, addHooks: function() {
      var e = this._map._container;
      e.tabIndex <= 0 && (e.tabIndex = "0"), Y(e, { focus: this._onFocus, blur: this._onBlur, mousedown: this._onMouseDown }, this), this._map.on({ focus: this._addHooks, blur: this._removeHooks }, this);
    }, removeHooks: function() {
      this._removeHooks(), ce(this._map._container, { focus: this._onFocus, blur: this._onBlur, mousedown: this._onMouseDown }, this), this._map.off({ focus: this._addHooks, blur: this._removeHooks }, this);
    }, _onMouseDown: function() {
      var e, t, u;
      this._focused || (u = document.body, e = document.documentElement, t = u.scrollTop || e.scrollTop, u = u.scrollLeft || e.scrollLeft, this._map._container.focus(), window.scrollTo(u, t));
    }, _onFocus: function() {
      this._focused = !0, this._map.fire("focus");
    }, _onBlur: function() {
      this._focused = !1, this._map.fire("blur");
    }, _setPanDelta: function(e) {
      for (var t = this._panKeys = {}, u = this.keyCodes, s = 0, l = u.left.length; s < l; s++)
        t[u.left[s]] = [-1 * e, 0];
      for (s = 0, l = u.right.length; s < l; s++)
        t[u.right[s]] = [e, 0];
      for (s = 0, l = u.down.length; s < l; s++)
        t[u.down[s]] = [0, e];
      for (s = 0, l = u.up.length; s < l; s++)
        t[u.up[s]] = [0, -1 * e];
    }, _setZoomDelta: function(e) {
      for (var t = this._zoomKeys = {}, u = this.keyCodes, s = 0, l = u.zoomIn.length; s < l; s++)
        t[u.zoomIn[s]] = e;
      for (s = 0, l = u.zoomOut.length; s < l; s++)
        t[u.zoomOut[s]] = -e;
    }, _addHooks: function() {
      Y(document, "keydown", this._onKeyDown, this);
    }, _removeHooks: function() {
      ce(document, "keydown", this._onKeyDown, this);
    }, _onKeyDown: function(e) {
      if (!(e.altKey || e.ctrlKey || e.metaKey)) {
        var t, u, s = e.keyCode, l = this._map;
        if (s in this._panKeys)
          l._panAnim && l._panAnim._inProgress || (u = this._panKeys[s], e.shiftKey && (u = M(u).multiplyBy(3)), l.options.maxBounds && (u = l._limitOffset(M(u), l.options.maxBounds)), l.options.worldCopyJump ? (t = l.wrapLatLng(l.unproject(l.project(l.getCenter()).add(u))), l.panTo(t)) : l.panBy(u));
        else if (s in this._zoomKeys)
          l.setZoom(l.getZoom() + (e.shiftKey ? 3 : 1) * this._zoomKeys[s]);
        else {
          if (s !== 27 || !l._popup || !l._popup.options.closeOnEscapeKey)
            return;
          l.closePopup();
        }
        yt(e);
      }
    } })), dn = (ue.addInitHook("addHandler", "keyboard", hn), ue.mergeOptions({ scrollWheelZoom: !0, wheelDebounceTime: 40, wheelPxPerZoomLevel: 60 }), Ie.extend({ addHooks: function() {
      Y(this._map._container, "wheel", this._onWheelScroll, this), this._delta = 0;
    }, removeHooks: function() {
      ce(this._map._container, "wheel", this._onWheelScroll, this);
    }, _onWheelScroll: function(e) {
      var u = yu(e), t = this._map.options.wheelDebounceTime, u = (this._delta += u, this._lastMousePos = this._map.mouseEventToContainerPoint(e), this._startTime || (this._startTime = +/* @__PURE__ */ new Date()), Math.max(t - (+/* @__PURE__ */ new Date() - this._startTime), 0));
      clearTimeout(this._timer), this._timer = setTimeout(p(this._performZoom, this), u), yt(e);
    }, _performZoom: function() {
      var e = this._map, t = e.getZoom(), u = this._map.options.zoomSnap || 0, s = (e._stop(), this._delta / (4 * this._map.options.wheelPxPerZoomLevel)), s = 4 * Math.log(2 / (1 + Math.exp(-Math.abs(s)))) / Math.LN2, u = u ? Math.ceil(s / u) * u : s, s = e._limitZoom(t + (0 < this._delta ? u : -u)) - t;
      this._delta = 0, this._startTime = null, s && (e.options.scrollWheelZoom === "center" ? e.setZoom(t + s) : e.setZoomAround(this._lastMousePos, t + s));
    } })), hi = (ue.addInitHook("addHandler", "scrollWheelZoom", dn), ue.mergeOptions({ tapHold: B.touchNative && B.safari && B.mobile, tapTolerance: 15 }), Ie.extend({ addHooks: function() {
      Y(this._map._container, "touchstart", this._onDown, this);
    }, removeHooks: function() {
      ce(this._map._container, "touchstart", this._onDown, this);
    }, _onDown: function(e) {
      var t;
      clearTimeout(this._holdTimeout), e.touches.length === 1 && (t = e.touches[0], this._startPos = this._newPos = new w(t.clientX, t.clientY), this._holdTimeout = setTimeout(p(function() {
        this._cancel(), this._isTapValid() && (Y(document, "touchend", Pe), Y(document, "touchend touchcancel", this._cancelClickPrevent), this._simulateEvent("contextmenu", t));
      }, this), 600), Y(document, "touchend touchcancel contextmenu", this._cancel, this), Y(document, "touchmove", this._onMove, this));
    }, _cancelClickPrevent: function e() {
      ce(document, "touchend", Pe), ce(document, "touchend touchcancel", e);
    }, _cancel: function() {
      clearTimeout(this._holdTimeout), ce(document, "touchend touchcancel contextmenu", this._cancel, this), ce(document, "touchmove", this._onMove, this);
    }, _onMove: function(e) {
      e = e.touches[0], this._newPos = new w(e.clientX, e.clientY);
    }, _isTapValid: function() {
      return this._newPos.distanceTo(this._startPos) <= this._map.options.tapTolerance;
    }, _simulateEvent: function(e, t) {
      e = new MouseEvent(e, { bubbles: !0, cancelable: !0, view: window, screenX: t.screenX, screenY: t.screenY, clientX: t.clientX, clientY: t.clientY }), e._simulated = !0, t.target.dispatchEvent(e);
    } })), di = (ue.addInitHook("addHandler", "tapHold", hi), ue.mergeOptions({ touchZoom: B.touch, bounceAtZoomLimits: !0 }), Ie.extend({ addHooks: function() {
      te(this._map._container, "leaflet-touch-zoom"), Y(this._map._container, "touchstart", this._onTouchStart, this);
    }, removeHooks: function() {
      ye(this._map._container, "leaflet-touch-zoom"), ce(this._map._container, "touchstart", this._onTouchStart, this);
    }, _onTouchStart: function(e) {
      var t, u, s = this._map;
      !e.touches || e.touches.length !== 2 || s._animatingZoom || this._zooming || (t = s.mouseEventToContainerPoint(e.touches[0]), u = s.mouseEventToContainerPoint(e.touches[1]), this._centerPoint = s.getSize()._divideBy(2), this._startLatLng = s.containerPointToLatLng(this._centerPoint), s.options.touchZoom !== "center" && (this._pinchStartLatLng = s.containerPointToLatLng(t.add(u)._divideBy(2))), this._startDist = t.distanceTo(u), this._startZoom = s.getZoom(), this._moved = !1, this._zooming = !0, s._stop(), Y(document, "touchmove", this._onTouchMove, this), Y(document, "touchend touchcancel", this._onTouchEnd, this), Pe(e));
    }, _onTouchMove: function(e) {
      if (e.touches && e.touches.length === 2 && this._zooming) {
        var t = this._map, u = t.mouseEventToContainerPoint(e.touches[0]), s = t.mouseEventToContainerPoint(e.touches[1]), l = u.distanceTo(s) / this._startDist;
        if (this._zoom = t.getScaleZoom(l, this._startZoom), !t.options.bounceAtZoomLimits && (this._zoom < t.getMinZoom() && l < 1 || this._zoom > t.getMaxZoom() && 1 < l) && (this._zoom = t._limitZoom(this._zoom)), t.options.touchZoom === "center") {
          if (this._center = this._startLatLng, l == 1)
            return;
        } else {
          if (u = u._add(s)._divideBy(2)._subtract(this._centerPoint), l == 1 && u.x === 0 && u.y === 0)
            return;
          this._center = t.unproject(t.project(this._pinchStartLatLng, this._zoom).subtract(u), this._zoom);
        }
        this._moved || (t._moveStart(!0, !1), this._moved = !0), A(this._animRequest), s = p(t._move, t, this._center, this._zoom, { pinch: !0, round: !1 }, void 0), this._animRequest = T(s, this, !0), Pe(e);
      }
    }, _onTouchEnd: function() {
      this._moved && this._zooming ? (this._zooming = !1, A(this._animRequest), ce(document, "touchmove", this._onTouchMove, this), ce(document, "touchend touchcancel", this._onTouchEnd, this), this._map.options.zoomAnimation ? this._map._animateZoom(this._center, this._map._limitZoom(this._zoom), !0, this._map.options.zoomSnap) : this._map._resetView(this._center, this._map._limitZoom(this._zoom))) : this._zooming = !1;
    } })), na = (ue.addInitHook("addHandler", "touchZoom", di), ue.BoxZoom = Je, ue.DoubleClickZoom = cn, ue.Drag = ct, ue.Keyboard = hn, ue.ScrollWheelZoom = dn, ue.TapHold = hi, ue.TouchZoom = di, n.Bounds = V, n.Browser = B, n.CRS = X, n.Canvas = Zu, n.Circle = gr, n.CircleMarker = Qi, n.Class = Z, n.Control = Re, n.DivIcon = Ru, n.DivOverlay = Fe, n.DomEvent = hr, n.DomUtil = st, n.Draggable = at, n.Evented = C, n.FeatureGroup = $e, n.GeoJSON = Ye, n.GridLayer = si, n.Handler = Ie, n.Icon = Rt, n.ImageOverlay = on, n.LatLng = j, n.LatLngBounds = we, n.Layer = Ce, n.LayerGroup = zt, n.LineUtil = Xi, n.Map = ue, n.Marker = Ji, n.Mixin = ri, n.Path = lt, n.Point = w, n.PolyUtil = Gi, n.Polygon = jt, n.Polyline = Xe, n.Popup = sn, n.PosAnimation = vu, n.Projection = Yi, n.Rectangle = Uu, n.Renderer = Ke, n.SVG = ci, n.SVGOverlay = zu, n.TileLayer = Zt, n.Tooltip = an, n.Transformation = Ee, n.Util = D, n.VideoOverlay = Bu, n.bind = p, n.bounds = pe, n.canvas = Fu, n.circle = function(e, t, u) {
      return new gr(e, t, u);
    }, n.circleMarker = function(e, t) {
      return new Qi(e, t);
    }, n.control = ni, n.divIcon = function(e) {
      return new Ru(e);
    }, n.extend = r, n.featureGroup = function(e, t) {
      return new $e(e, t);
    }, n.geoJSON = Du, n.geoJson = un, n.gridLayer = function(e) {
      return new si(e);
    }, n.icon = function(e) {
      return new Rt(e);
    }, n.imageOverlay = function(e, t, u) {
      return new on(e, t, u);
    }, n.latLng = K, n.latLngBounds = F, n.layerGroup = function(e, t) {
      return new zt(e, t);
    }, n.map = function(e, t) {
      return new ue(e, t);
    }, n.marker = function(e, t) {
      return new Ji(e, t);
    }, n.point = M, n.polygon = function(e, t) {
      return new jt(e, t);
    }, n.polyline = function(e, t) {
      return new Xe(e, t);
    }, n.popup = function(e, t) {
      return new sn(e, t);
    }, n.rectangle = function(e, t) {
      return new Uu(e, t);
    }, n.setOptions = I, n.stamp = d, n.svg = Hu, n.svgOverlay = function(e, t, u) {
      return new zu(e, t, u);
    }, n.tileLayer = ju, n.tooltip = function(e, t) {
      return new an(e, t);
    }, n.transformation = Te, n.version = "1.9.4", n.videoOverlay = function(e, t, u) {
      return new Bu(e, t, u);
    }, window.L);
    n.noConflict = function() {
      return window.L = na, this;
    }, window.L = n;
  });
})(Lr, Lr.exports);
var ya = Lr.exports;
const fe = /* @__PURE__ */ Bo(ya);
var zo = {}, yi = {}, Vr = {}, vi = {}, Wr = {};
Object.defineProperty(Wr, "__esModule", { value: !0 });
Wr.default = new Uint16Array(
  // prettier-ignore
  'ᵁ<Õıʊҝջאٵ۞ޢߖࠏ੊ઑඡ๭༉༦჊ረዡᐕᒝᓃᓟᔥ\0\0\0\0\0\0ᕫᛍᦍᰒᷝ὾⁠↰⊍⏀⏻⑂⠤⤒ⴈ⹈⿎〖㊺㘹㞬㣾㨨㩱㫠㬮ࠀEMabcfglmnoprstu\\bfms¦³¹ÈÏlig耻Æ䃆P耻&䀦cute耻Á䃁reve;䄂Āiyx}rc耻Â䃂;䐐r;쀀𝔄rave耻À䃀pha;䎑acr;䄀d;橓Āgp¡on;䄄f;쀀𝔸plyFunction;恡ing耻Å䃅Ācs¾Ãr;쀀𝒜ign;扔ilde耻Ã䃃ml耻Ä䃄ЀaceforsuåûþėĜĢħĪĀcrêòkslash;或Ŷöø;櫧ed;挆y;䐑ƀcrtąċĔause;戵noullis;愬a;䎒r;쀀𝔅pf;쀀𝔹eve;䋘còēmpeq;扎܀HOacdefhilorsuōőŖƀƞƢƵƷƺǜȕɳɸɾcy;䐧PY耻©䂩ƀcpyŝŢźute;䄆Ā;iŧŨ拒talDifferentialD;慅leys;愭ȀaeioƉƎƔƘron;䄌dil耻Ç䃇rc;䄈nint;戰ot;䄊ĀdnƧƭilla;䂸terDot;䂷òſi;䎧rcleȀDMPTǇǋǑǖot;抙inus;抖lus;投imes;抗oĀcsǢǸkwiseContourIntegral;戲eCurlyĀDQȃȏoubleQuote;思uote;怙ȀlnpuȞȨɇɕonĀ;eȥȦ户;橴ƀgitȯȶȺruent;扡nt;戯ourIntegral;戮ĀfrɌɎ;愂oduct;成nterClockwiseContourIntegral;戳oss;樯cr;쀀𝒞pĀ;Cʄʅ拓ap;才րDJSZacefiosʠʬʰʴʸˋ˗ˡ˦̳ҍĀ;oŹʥtrahd;椑cy;䐂cy;䐅cy;䐏ƀgrsʿ˄ˇger;怡r;憡hv;櫤Āayː˕ron;䄎;䐔lĀ;t˝˞戇a;䎔r;쀀𝔇Āaf˫̧Ācm˰̢riticalȀADGT̖̜̀̆cute;䂴oŴ̋̍;䋙bleAcute;䋝rave;䁠ilde;䋜ond;拄ferentialD;慆Ѱ̽\0\0\0͔͂\0Ѕf;쀀𝔻ƀ;DE͈͉͍䂨ot;惜qual;扐blèCDLRUVͣͲ΂ϏϢϸontourIntegraìȹoɴ͹\0\0ͻ»͉nArrow;懓Āeo·ΤftƀARTΐΖΡrrow;懐ightArrow;懔eåˊngĀLRΫτeftĀARγιrrow;柸ightArrow;柺ightArrow;柹ightĀATϘϞrrow;懒ee;抨pɁϩ\0\0ϯrrow;懑ownArrow;懕erticalBar;戥ǹABLRTaВЪаўѿͼrrowƀ;BUНОТ憓ar;椓pArrow;懵reve;䌑eft˒к\0ц\0ѐightVector;楐eeVector;楞ectorĀ;Bљњ憽ar;楖ightǔѧ\0ѱeeVector;楟ectorĀ;BѺѻ懁ar;楗eeĀ;A҆҇护rrow;憧ĀctҒҗr;쀀𝒟rok;䄐ࠀNTacdfglmopqstuxҽӀӄӋӞӢӧӮӵԡԯԶՒ՝ՠեG;䅊H耻Ð䃐cute耻É䃉ƀaiyӒӗӜron;䄚rc耻Ê䃊;䐭ot;䄖r;쀀𝔈rave耻È䃈ement;戈ĀapӺӾcr;䄒tyɓԆ\0\0ԒmallSquare;旻erySmallSquare;斫ĀgpԦԪon;䄘f;쀀𝔼silon;䎕uĀaiԼՉlĀ;TՂՃ橵ilde;扂librium;懌Āci՗՚r;愰m;橳a;䎗ml耻Ë䃋Āipժկsts;戃onentialE;慇ʀcfiosօֈ֍ֲ׌y;䐤r;쀀𝔉lledɓ֗\0\0֣mallSquare;旼erySmallSquare;斪Ͱֺ\0ֿ\0\0ׄf;쀀𝔽All;戀riertrf;愱cò׋؀JTabcdfgorstר׬ׯ׺؀ؒؖ؛؝أ٬ٲcy;䐃耻>䀾mmaĀ;d׷׸䎓;䏜reve;䄞ƀeiy؇،ؐdil;䄢rc;䄜;䐓ot;䄠r;쀀𝔊;拙pf;쀀𝔾eater̀EFGLSTصلَٖٛ٦qualĀ;Lؾؿ扥ess;招ullEqual;执reater;檢ess;扷lantEqual;橾ilde;扳cr;쀀𝒢;扫ЀAacfiosuڅڋږڛڞڪھۊRDcy;䐪Āctڐڔek;䋇;䁞irc;䄤r;愌lbertSpace;愋ǰگ\0ڲf;愍izontalLine;攀Āctۃۅòکrok;䄦mpńېۘownHumðįqual;扏܀EJOacdfgmnostuۺ۾܃܇܎ܚܞܡܨ݄ݸދޏޕcy;䐕lig;䄲cy;䐁cute耻Í䃍Āiyܓܘrc耻Î䃎;䐘ot;䄰r;愑rave耻Ì䃌ƀ;apܠܯܿĀcgܴܷr;䄪inaryI;慈lieóϝǴ݉\0ݢĀ;eݍݎ戬Āgrݓݘral;戫section;拂isibleĀCTݬݲomma;恣imes;恢ƀgptݿރވon;䄮f;쀀𝕀a;䎙cr;愐ilde;䄨ǫޚ\0ޞcy;䐆l耻Ï䃏ʀcfosuެ޷޼߂ߐĀiyޱ޵rc;䄴;䐙r;쀀𝔍pf;쀀𝕁ǣ߇\0ߌr;쀀𝒥rcy;䐈kcy;䐄΀HJacfosߤߨ߽߬߱ࠂࠈcy;䐥cy;䐌ppa;䎚Āey߶߻dil;䄶;䐚r;쀀𝔎pf;쀀𝕂cr;쀀𝒦րJTaceflmostࠥࠩࠬࡐࡣ঳সে্਷ੇcy;䐉耻<䀼ʀcmnpr࠷࠼ࡁࡄࡍute;䄹bda;䎛g;柪lacetrf;愒r;憞ƀaeyࡗ࡜ࡡron;䄽dil;䄻;䐛Āfsࡨ॰tԀACDFRTUVarࡾࢩࢱࣦ࣠ࣼयज़ΐ४Ānrࢃ࢏gleBracket;柨rowƀ;BR࢙࢚࢞憐ar;懤ightArrow;懆eiling;挈oǵࢷ\0ࣃbleBracket;柦nǔࣈ\0࣒eeVector;楡ectorĀ;Bࣛࣜ懃ar;楙loor;挊ightĀAV࣯ࣵrrow;憔ector;楎Āerँगeƀ;AVउऊऐ抣rrow;憤ector;楚iangleƀ;BEतथऩ抲ar;槏qual;抴pƀDTVषूौownVector;楑eeVector;楠ectorĀ;Bॖॗ憿ar;楘ectorĀ;B॥०憼ar;楒ightáΜs̀EFGLSTॾঋকঝঢভqualGreater;拚ullEqual;扦reater;扶ess;檡lantEqual;橽ilde;扲r;쀀𝔏Ā;eঽা拘ftarrow;懚idot;䄿ƀnpw৔ਖਛgȀLRlr৞৷ਂਐeftĀAR০৬rrow;柵ightArrow;柷ightArrow;柶eftĀarγਊightáοightáϊf;쀀𝕃erĀLRਢਬeftArrow;憙ightArrow;憘ƀchtਾੀੂòࡌ;憰rok;䅁;扪Ѐacefiosuਗ਼੝੠੷੼અઋ઎p;椅y;䐜Ādl੥੯iumSpace;恟lintrf;愳r;쀀𝔐nusPlus;戓pf;쀀𝕄cò੶;䎜ҀJacefostuણધભીଔଙඑ඗ඞcy;䐊cute;䅃ƀaey઴હાron;䅇dil;䅅;䐝ƀgswે૰଎ativeƀMTV૓૟૨ediumSpace;怋hiĀcn૦૘ë૙eryThiî૙tedĀGL૸ଆreaterGreateòٳessLesóੈLine;䀊r;쀀𝔑ȀBnptଢନଷ଺reak;恠BreakingSpace;䂠f;愕ڀ;CDEGHLNPRSTV୕ୖ୪୼஡௫ఄ౞಄ದ೘ൡඅ櫬Āou୛୤ngruent;扢pCap;扭oubleVerticalBar;戦ƀlqxஃஊ஛ement;戉ualĀ;Tஒஓ扠ilde;쀀≂̸ists;戄reater΀;EFGLSTஶஷ஽௉௓௘௥扯qual;扱ullEqual;쀀≧̸reater;쀀≫̸ess;批lantEqual;쀀⩾̸ilde;扵umpń௲௽ownHump;쀀≎̸qual;쀀≏̸eĀfsఊధtTriangleƀ;BEచఛడ拪ar;쀀⧏̸qual;括s̀;EGLSTవశ఼ౄోౘ扮qual;扰reater;扸ess;쀀≪̸lantEqual;쀀⩽̸ilde;扴estedĀGL౨౹reaterGreater;쀀⪢̸essLess;쀀⪡̸recedesƀ;ESಒಓಛ技qual;쀀⪯̸lantEqual;拠ĀeiಫಹverseElement;戌ghtTriangleƀ;BEೋೌ೒拫ar;쀀⧐̸qual;拭ĀquೝഌuareSuĀbp೨೹setĀ;E೰ೳ쀀⊏̸qual;拢ersetĀ;Eഃആ쀀⊐̸qual;拣ƀbcpഓതൎsetĀ;Eഛഞ쀀⊂⃒qual;抈ceedsȀ;ESTലള഻െ抁qual;쀀⪰̸lantEqual;拡ilde;쀀≿̸ersetĀ;E൘൛쀀⊃⃒qual;抉ildeȀ;EFT൮൯൵ൿ扁qual;扄ullEqual;扇ilde;扉erticalBar;戤cr;쀀𝒩ilde耻Ñ䃑;䎝܀Eacdfgmoprstuvලෂ෉෕ෛ෠෧෼ขภยา฿ไlig;䅒cute耻Ó䃓Āiy෎ීrc耻Ô䃔;䐞blac;䅐r;쀀𝔒rave耻Ò䃒ƀaei෮ෲ෶cr;䅌ga;䎩cron;䎟pf;쀀𝕆enCurlyĀDQฎบoubleQuote;怜uote;怘;橔Āclวฬr;쀀𝒪ash耻Ø䃘iŬื฼de耻Õ䃕es;樷ml耻Ö䃖erĀBP๋๠Āar๐๓r;怾acĀek๚๜;揞et;掴arenthesis;揜Ҁacfhilors๿ງຊຏຒດຝະ໼rtialD;戂y;䐟r;쀀𝔓i;䎦;䎠usMinus;䂱Āipຢອncareplanåڝf;愙Ȁ;eio຺ູ໠໤檻cedesȀ;EST່້໏໚扺qual;檯lantEqual;扼ilde;找me;怳Ādp໩໮uct;戏ortionĀ;aȥ໹l;戝Āci༁༆r;쀀𝒫;䎨ȀUfos༑༖༛༟OT耻"䀢r;쀀𝔔pf;愚cr;쀀𝒬؀BEacefhiorsu༾གྷཇའཱིྦྷྪྭ႖ႩႴႾarr;椐G耻®䂮ƀcnrཎནབute;䅔g;柫rĀ;tཛྷཝ憠l;椖ƀaeyཧཬཱron;䅘dil;䅖;䐠Ā;vླྀཹ愜erseĀEUྂྙĀlq྇ྎement;戋uilibrium;懋pEquilibrium;楯r»ཹo;䎡ghtЀACDFTUVa࿁࿫࿳ဢဨၛႇϘĀnr࿆࿒gleBracket;柩rowƀ;BL࿜࿝࿡憒ar;懥eftArrow;懄eiling;按oǵ࿹\0စbleBracket;柧nǔည\0နeeVector;楝ectorĀ;Bဝသ懂ar;楕loor;挋Āerိ၃eƀ;AVဵံြ抢rrow;憦ector;楛iangleƀ;BEၐၑၕ抳ar;槐qual;抵pƀDTVၣၮၸownVector;楏eeVector;楜ectorĀ;Bႂႃ憾ar;楔ectorĀ;B႑႒懀ar;楓Āpuႛ႞f;愝ndImplies;楰ightarrow;懛ĀchႹႼr;愛;憱leDelayed;槴ڀHOacfhimoqstuფჱჷჽᄙᄞᅑᅖᅡᅧᆵᆻᆿĀCcჩხHcy;䐩y;䐨FTcy;䐬cute;䅚ʀ;aeiyᄈᄉᄎᄓᄗ檼ron;䅠dil;䅞rc;䅜;䐡r;쀀𝔖ortȀDLRUᄪᄴᄾᅉownArrow»ОeftArrow»࢚ightArrow»࿝pArrow;憑gma;䎣allCircle;战pf;쀀𝕊ɲᅭ\0\0ᅰt;戚areȀ;ISUᅻᅼᆉᆯ斡ntersection;抓uĀbpᆏᆞsetĀ;Eᆗᆘ抏qual;抑ersetĀ;Eᆨᆩ抐qual;抒nion;抔cr;쀀𝒮ar;拆ȀbcmpᇈᇛሉላĀ;sᇍᇎ拐etĀ;Eᇍᇕqual;抆ĀchᇠህeedsȀ;ESTᇭᇮᇴᇿ扻qual;檰lantEqual;扽ilde;承Tháྌ;我ƀ;esሒሓሣ拑rsetĀ;Eሜም抃qual;抇et»ሓրHRSacfhiorsሾቄ቉ቕ቞ቱቶኟዂወዑORN耻Þ䃞ADE;愢ĀHc቎ቒcy;䐋y;䐦Ābuቚቜ;䀉;䎤ƀaeyብቪቯron;䅤dil;䅢;䐢r;쀀𝔗Āeiቻ኉ǲኀ\0ኇefore;戴a;䎘Ācn኎ኘkSpace;쀀  Space;怉ldeȀ;EFTካኬኲኼ戼qual;扃ullEqual;扅ilde;扈pf;쀀𝕋ipleDot;惛Āctዖዛr;쀀𝒯rok;䅦ૡዷጎጚጦ\0ጬጱ\0\0\0\0\0ጸጽ፷ᎅ\0᏿ᐄᐊᐐĀcrዻጁute耻Ú䃚rĀ;oጇገ憟cir;楉rǣጓ\0጖y;䐎ve;䅬Āiyጞጣrc耻Û䃛;䐣blac;䅰r;쀀𝔘rave耻Ù䃙acr;䅪Ādiፁ፩erĀBPፈ፝Āarፍፐr;䁟acĀekፗፙ;揟et;掵arenthesis;揝onĀ;P፰፱拃lus;抎Āgp፻፿on;䅲f;쀀𝕌ЀADETadps᎕ᎮᎸᏄϨᏒᏗᏳrrowƀ;BDᅐᎠᎤar;椒ownArrow;懅ownArrow;憕quilibrium;楮eeĀ;AᏋᏌ报rrow;憥ownáϳerĀLRᏞᏨeftArrow;憖ightArrow;憗iĀ;lᏹᏺ䏒on;䎥ing;䅮cr;쀀𝒰ilde;䅨ml耻Ü䃜ҀDbcdefosvᐧᐬᐰᐳᐾᒅᒊᒐᒖash;披ar;櫫y;䐒ashĀ;lᐻᐼ抩;櫦Āerᑃᑅ;拁ƀbtyᑌᑐᑺar;怖Ā;iᑏᑕcalȀBLSTᑡᑥᑪᑴar;戣ine;䁼eparator;杘ilde;所ThinSpace;怊r;쀀𝔙pf;쀀𝕍cr;쀀𝒱dash;抪ʀcefosᒧᒬᒱᒶᒼirc;䅴dge;拀r;쀀𝔚pf;쀀𝕎cr;쀀𝒲Ȁfiosᓋᓐᓒᓘr;쀀𝔛;䎞pf;쀀𝕏cr;쀀𝒳ҀAIUacfosuᓱᓵᓹᓽᔄᔏᔔᔚᔠcy;䐯cy;䐇cy;䐮cute耻Ý䃝Āiyᔉᔍrc;䅶;䐫r;쀀𝔜pf;쀀𝕐cr;쀀𝒴ml;䅸ЀHacdefosᔵᔹᔿᕋᕏᕝᕠᕤcy;䐖cute;䅹Āayᕄᕉron;䅽;䐗ot;䅻ǲᕔ\0ᕛoWidtè૙a;䎖r;愨pf;愤cr;쀀𝒵௡ᖃᖊᖐ\0ᖰᖶᖿ\0\0\0\0ᗆᗛᗫᙟ᙭\0ᚕ᚛ᚲᚹ\0ᚾcute耻á䃡reve;䄃̀;Ediuyᖜᖝᖡᖣᖨᖭ戾;쀀∾̳;房rc耻â䃢te肻´̆;䐰lig耻æ䃦Ā;r²ᖺ;쀀𝔞rave耻à䃠ĀepᗊᗖĀfpᗏᗔsym;愵èᗓha;䎱ĀapᗟcĀclᗤᗧr;䄁g;樿ɤᗰ\0\0ᘊʀ;adsvᗺᗻᗿᘁᘇ戧nd;橕;橜lope;橘;橚΀;elmrszᘘᘙᘛᘞᘿᙏᙙ戠;榤e»ᘙsdĀ;aᘥᘦ戡ѡᘰᘲᘴᘶᘸᘺᘼᘾ;榨;榩;榪;榫;榬;榭;榮;榯tĀ;vᙅᙆ戟bĀ;dᙌᙍ抾;榝Āptᙔᙗh;戢»¹arr;捼Āgpᙣᙧon;䄅f;쀀𝕒΀;Eaeiop዁ᙻᙽᚂᚄᚇᚊ;橰cir;橯;扊d;手s;䀧roxĀ;e዁ᚒñᚃing耻å䃥ƀctyᚡᚦᚨr;쀀𝒶;䀪mpĀ;e዁ᚯñʈilde耻ã䃣ml耻ä䃤Āciᛂᛈoninôɲnt;樑ࠀNabcdefiklnoprsu᛭ᛱᜰ᜼ᝃᝈ᝸᝽០៦ᠹᡐᜍ᤽᥈ᥰot;櫭Ācrᛶ᜞kȀcepsᜀᜅᜍᜓong;扌psilon;䏶rime;怵imĀ;e᜚᜛戽q;拍Ŷᜢᜦee;抽edĀ;gᜬᜭ挅e»ᜭrkĀ;t፜᜷brk;掶Āoyᜁᝁ;䐱quo;怞ʀcmprtᝓ᝛ᝡᝤᝨausĀ;eĊĉptyv;榰séᜌnoõēƀahwᝯ᝱ᝳ;䎲;愶een;扬r;쀀𝔟g΀costuvwឍឝឳេ៕៛៞ƀaiuបពរðݠrc;旯p»፱ƀdptឤឨឭot;樀lus;樁imes;樂ɱឹ\0\0ើcup;樆ar;昅riangleĀdu៍្own;施p;斳plus;樄eåᑄåᒭarow;植ƀako៭ᠦᠵĀcn៲ᠣkƀlst៺֫᠂ozenge;槫riangleȀ;dlr᠒᠓᠘᠝斴own;斾eft;旂ight;斸k;搣Ʊᠫ\0ᠳƲᠯ\0ᠱ;斒;斑4;斓ck;斈ĀeoᠾᡍĀ;qᡃᡆ쀀=⃥uiv;쀀≡⃥t;挐Ȁptwxᡙᡞᡧᡬf;쀀𝕓Ā;tᏋᡣom»Ꮜtie;拈؀DHUVbdhmptuvᢅᢖᢪᢻᣗᣛᣬ᣿ᤅᤊᤐᤡȀLRlrᢎᢐᢒᢔ;敗;敔;敖;敓ʀ;DUduᢡᢢᢤᢦᢨ敐;敦;敩;敤;敧ȀLRlrᢳᢵᢷᢹ;敝;敚;敜;教΀;HLRhlrᣊᣋᣍᣏᣑᣓᣕ救;敬;散;敠;敫;敢;敟ox;槉ȀLRlrᣤᣦᣨᣪ;敕;敒;攐;攌ʀ;DUduڽ᣷᣹᣻᣽;敥;敨;攬;攴inus;抟lus;択imes;抠ȀLRlrᤙᤛᤝ᤟;敛;敘;攘;攔΀;HLRhlrᤰᤱᤳᤵᤷ᤻᤹攂;敪;敡;敞;攼;攤;攜Āevģ᥂bar耻¦䂦Ȁceioᥑᥖᥚᥠr;쀀𝒷mi;恏mĀ;e᜚᜜lƀ;bhᥨᥩᥫ䁜;槅sub;柈Ŭᥴ᥾lĀ;e᥹᥺怢t»᥺pƀ;Eeįᦅᦇ;檮Ā;qۜۛೡᦧ\0᧨ᨑᨕᨲ\0ᨷᩐ\0\0᪴\0\0᫁\0\0ᬡᬮ᭍᭒\0᯽\0ᰌƀcpr᦭ᦲ᧝ute;䄇̀;abcdsᦿᧀᧄ᧊᧕᧙戩nd;橄rcup;橉Āau᧏᧒p;橋p;橇ot;橀;쀀∩︀Āeo᧢᧥t;恁îړȀaeiu᧰᧻ᨁᨅǰ᧵\0᧸s;橍on;䄍dil耻ç䃧rc;䄉psĀ;sᨌᨍ橌m;橐ot;䄋ƀdmnᨛᨠᨦil肻¸ƭptyv;榲t脀¢;eᨭᨮ䂢räƲr;쀀𝔠ƀceiᨽᩀᩍy;䑇ckĀ;mᩇᩈ朓ark»ᩈ;䏇r΀;Ecefms᩟᩠ᩢᩫ᪤᪪᪮旋;槃ƀ;elᩩᩪᩭ䋆q;扗eɡᩴ\0\0᪈rrowĀlr᩼᪁eft;憺ight;憻ʀRSacd᪒᪔᪖᪚᪟»ཇ;擈st;抛irc;抚ash;抝nint;樐id;櫯cir;槂ubsĀ;u᪻᪼晣it»᪼ˬ᫇᫔᫺\0ᬊonĀ;eᫍᫎ䀺Ā;qÇÆɭ᫙\0\0᫢aĀ;t᫞᫟䀬;䁀ƀ;fl᫨᫩᫫戁îᅠeĀmx᫱᫶ent»᫩eóɍǧ᫾\0ᬇĀ;dኻᬂot;橭nôɆƀfryᬐᬔᬗ;쀀𝕔oäɔ脀©;sŕᬝr;愗Āaoᬥᬩrr;憵ss;朗Ācuᬲᬷr;쀀𝒸Ābpᬼ᭄Ā;eᭁᭂ櫏;櫑Ā;eᭉᭊ櫐;櫒dot;拯΀delprvw᭠᭬᭷ᮂᮬᯔ᯹arrĀlr᭨᭪;椸;椵ɰ᭲\0\0᭵r;拞c;拟arrĀ;p᭿ᮀ憶;椽̀;bcdosᮏᮐᮖᮡᮥᮨ截rcap;橈Āauᮛᮞp;橆p;橊ot;抍r;橅;쀀∪︀Ȁalrv᮵ᮿᯞᯣrrĀ;mᮼᮽ憷;椼yƀevwᯇᯔᯘqɰᯎ\0\0ᯒreã᭳uã᭵ee;拎edge;拏en耻¤䂤earrowĀlrᯮ᯳eft»ᮀight»ᮽeäᯝĀciᰁᰇoninôǷnt;戱lcty;挭ঀAHabcdefhijlorstuwz᰸᰻᰿ᱝᱩᱵᲊᲞᲬᲷ᳻᳿ᴍᵻᶑᶫᶻ᷆᷍rò΁ar;楥Ȁglrs᱈ᱍ᱒᱔ger;怠eth;愸òᄳhĀ;vᱚᱛ怐»ऊūᱡᱧarow;椏aã̕Āayᱮᱳron;䄏;䐴ƀ;ao̲ᱼᲄĀgrʿᲁr;懊tseq;橷ƀglmᲑᲔᲘ耻°䂰ta;䎴ptyv;榱ĀirᲣᲨsht;楿;쀀𝔡arĀlrᲳᲵ»ࣜ»သʀaegsv᳂͸᳖᳜᳠mƀ;oș᳊᳔ndĀ;ș᳑uit;晦amma;䏝in;拲ƀ;io᳧᳨᳸䃷de脀÷;o᳧ᳰntimes;拇nø᳷cy;䑒cɯᴆ\0\0ᴊrn;挞op;挍ʀlptuwᴘᴝᴢᵉᵕlar;䀤f;쀀𝕕ʀ;emps̋ᴭᴷᴽᵂqĀ;d͒ᴳot;扑inus;戸lus;戔quare;抡blebarwedgåúnƀadhᄮᵝᵧownarrowóᲃarpoonĀlrᵲᵶefôᲴighôᲶŢᵿᶅkaro÷གɯᶊ\0\0ᶎrn;挟op;挌ƀcotᶘᶣᶦĀryᶝᶡ;쀀𝒹;䑕l;槶rok;䄑Ādrᶰᶴot;拱iĀ;fᶺ᠖斿Āah᷀᷃ròЩaòྦangle;榦Āci᷒ᷕy;䑟grarr;柿ऀDacdefglmnopqrstuxḁḉḙḸոḼṉṡṾấắẽỡἪἷὄ὎὚ĀDoḆᴴoôᲉĀcsḎḔute耻é䃩ter;橮ȀaioyḢḧḱḶron;䄛rĀ;cḭḮ扖耻ê䃪lon;払;䑍ot;䄗ĀDrṁṅot;扒;쀀𝔢ƀ;rsṐṑṗ檚ave耻è䃨Ā;dṜṝ檖ot;檘Ȁ;ilsṪṫṲṴ檙nters;揧;愓Ā;dṹṺ檕ot;檗ƀapsẅẉẗcr;䄓tyƀ;svẒẓẕ戅et»ẓpĀ1;ẝẤĳạả;怄;怅怃ĀgsẪẬ;䅋p;怂ĀgpẴẸon;䄙f;쀀𝕖ƀalsỄỎỒrĀ;sỊị拕l;槣us;橱iƀ;lvỚớở䎵on»ớ;䏵ȀcsuvỪỳἋἣĀioữḱrc»Ḯɩỹ\0\0ỻíՈantĀglἂἆtr»ṝess»Ṻƀaeiἒ἖Ἒls;䀽st;扟vĀ;DȵἠD;橸parsl;槥ĀDaἯἳot;打rr;楱ƀcdiἾὁỸr;愯oô͒ĀahὉὋ;䎷耻ð䃰Āmrὓὗl耻ë䃫o;悬ƀcipὡὤὧl;䀡sôծĀeoὬὴctatioîՙnentialåչৡᾒ\0ᾞ\0ᾡᾧ\0\0ῆῌ\0ΐ\0ῦῪ \0 ⁚llingdotseñṄy;䑄male;晀ƀilrᾭᾳ῁lig;耀ﬃɩᾹ\0\0᾽g;耀ﬀig;耀ﬄ;쀀𝔣lig;耀ﬁlig;쀀fjƀaltῙ῜ῡt;晭ig;耀ﬂns;斱of;䆒ǰ΅\0ῳf;쀀𝕗ĀakֿῷĀ;vῼ´拔;櫙artint;樍Āao‌⁕Ācs‑⁒α‚‰‸⁅⁈\0⁐β•‥‧‪‬\0‮耻½䂽;慓耻¼䂼;慕;慙;慛Ƴ‴\0‶;慔;慖ʴ‾⁁\0\0⁃耻¾䂾;慗;慜5;慘ƶ⁌\0⁎;慚;慝8;慞l;恄wn;挢cr;쀀𝒻ࢀEabcdefgijlnorstv₂₉₟₥₰₴⃰⃵⃺⃿℃ℒℸ̗ℾ⅒↞Ā;lٍ₇;檌ƀcmpₐₕ₝ute;䇵maĀ;dₜ᳚䎳;檆reve;䄟Āiy₪₮rc;䄝;䐳ot;䄡Ȁ;lqsؾق₽⃉ƀ;qsؾٌ⃄lanô٥Ȁ;cdl٥⃒⃥⃕c;檩otĀ;o⃜⃝檀Ā;l⃢⃣檂;檄Ā;e⃪⃭쀀⋛︀s;檔r;쀀𝔤Ā;gٳ؛mel;愷cy;䑓Ȁ;Eajٚℌℎℐ;檒;檥;檤ȀEaesℛℝ℩ℴ;扩pĀ;p℣ℤ檊rox»ℤĀ;q℮ℯ檈Ā;q℮ℛim;拧pf;쀀𝕘Āci⅃ⅆr;愊mƀ;el٫ⅎ⅐;檎;檐茀>;cdlqr׮ⅠⅪⅮⅳⅹĀciⅥⅧ;檧r;橺ot;拗Par;榕uest;橼ʀadelsↄⅪ←ٖ↛ǰ↉\0↎proø₞r;楸qĀlqؿ↖lesó₈ií٫Āen↣↭rtneqq;쀀≩︀Å↪ԀAabcefkosy⇄⇇⇱⇵⇺∘∝∯≨≽ròΠȀilmr⇐⇔⇗⇛rsðᒄf»․ilôکĀdr⇠⇤cy;䑊ƀ;cwࣴ⇫⇯ir;楈;憭ar;意irc;䄥ƀalr∁∎∓rtsĀ;u∉∊晥it»∊lip;怦con;抹r;쀀𝔥sĀew∣∩arow;椥arow;椦ʀamopr∺∾≃≞≣rr;懿tht;戻kĀlr≉≓eftarrow;憩ightarrow;憪f;쀀𝕙bar;怕ƀclt≯≴≸r;쀀𝒽asè⇴rok;䄧Ābp⊂⊇ull;恃hen»ᱛૡ⊣\0⊪\0⊸⋅⋎\0⋕⋳\0\0⋸⌢⍧⍢⍿\0⎆⎪⎴cute耻í䃭ƀ;iyݱ⊰⊵rc耻î䃮;䐸Ācx⊼⊿y;䐵cl耻¡䂡ĀfrΟ⋉;쀀𝔦rave耻ì䃬Ȁ;inoܾ⋝⋩⋮Āin⋢⋦nt;樌t;戭fin;槜ta;愩lig;䄳ƀaop⋾⌚⌝ƀcgt⌅⌈⌗r;䄫ƀelpܟ⌏⌓inåގarôܠh;䄱f;抷ed;䆵ʀ;cfotӴ⌬⌱⌽⍁are;愅inĀ;t⌸⌹戞ie;槝doô⌙ʀ;celpݗ⍌⍐⍛⍡al;抺Āgr⍕⍙eróᕣã⍍arhk;樗rod;樼Ȁcgpt⍯⍲⍶⍻y;䑑on;䄯f;쀀𝕚a;䎹uest耻¿䂿Āci⎊⎏r;쀀𝒾nʀ;EdsvӴ⎛⎝⎡ӳ;拹ot;拵Ā;v⎦⎧拴;拳Ā;iݷ⎮lde;䄩ǫ⎸\0⎼cy;䑖l耻ï䃯̀cfmosu⏌⏗⏜⏡⏧⏵Āiy⏑⏕rc;䄵;䐹r;쀀𝔧ath;䈷pf;쀀𝕛ǣ⏬\0⏱r;쀀𝒿rcy;䑘kcy;䑔Ѐacfghjos␋␖␢␧␭␱␵␻ppaĀ;v␓␔䎺;䏰Āey␛␠dil;䄷;䐺r;쀀𝔨reen;䄸cy;䑅cy;䑜pf;쀀𝕜cr;쀀𝓀஀ABEHabcdefghjlmnoprstuv⑰⒁⒆⒍⒑┎┽╚▀♎♞♥♹♽⚚⚲⛘❝❨➋⟀⠁⠒ƀart⑷⑺⑼rò৆òΕail;椛arr;椎Ā;gঔ⒋;檋ar;楢ॣ⒥\0⒪\0⒱\0\0\0\0\0⒵Ⓔ\0ⓆⓈⓍ\0⓹ute;䄺mptyv;榴raîࡌbda;䎻gƀ;dlࢎⓁⓃ;榑åࢎ;檅uo耻«䂫rЀ;bfhlpst࢙ⓞⓦⓩ⓫⓮⓱⓵Ā;f࢝ⓣs;椟s;椝ë≒p;憫l;椹im;楳l;憢ƀ;ae⓿─┄檫il;椙Ā;s┉┊檭;쀀⪭︀ƀabr┕┙┝rr;椌rk;杲Āak┢┬cĀek┨┪;䁻;䁛Āes┱┳;榋lĀdu┹┻;榏;榍Ȁaeuy╆╋╖╘ron;䄾Ādi═╔il;䄼ìࢰâ┩;䐻Ȁcqrs╣╦╭╽a;椶uoĀ;rนᝆĀdu╲╷har;楧shar;楋h;憲ʀ;fgqs▋▌উ◳◿扤tʀahlrt▘▤▷◂◨rrowĀ;t࢙□aé⓶arpoonĀdu▯▴own»њp»०eftarrows;懇ightƀahs◍◖◞rrowĀ;sࣴࢧarpoonó྘quigarro÷⇰hreetimes;拋ƀ;qs▋ও◺lanôবʀ;cdgsব☊☍☝☨c;檨otĀ;o☔☕橿Ā;r☚☛檁;檃Ā;e☢☥쀀⋚︀s;檓ʀadegs☳☹☽♉♋pproøⓆot;拖qĀgq♃♅ôউgtò⒌ôছiíলƀilr♕࣡♚sht;楼;쀀𝔩Ā;Eজ♣;檑š♩♶rĀdu▲♮Ā;l॥♳;楪lk;斄cy;䑙ʀ;achtੈ⚈⚋⚑⚖rò◁orneòᴈard;楫ri;旺Āio⚟⚤dot;䅀ustĀ;a⚬⚭掰che»⚭ȀEaes⚻⚽⛉⛔;扨pĀ;p⛃⛄檉rox»⛄Ā;q⛎⛏檇Ā;q⛎⚻im;拦Ѐabnoptwz⛩⛴⛷✚✯❁❇❐Ānr⛮⛱g;柬r;懽rëࣁgƀlmr⛿✍✔eftĀar০✇ightá৲apsto;柼ightá৽parrowĀlr✥✩efô⓭ight;憬ƀafl✶✹✽r;榅;쀀𝕝us;樭imes;樴š❋❏st;戗áፎƀ;ef❗❘᠀旊nge»❘arĀ;l❤❥䀨t;榓ʀachmt❳❶❼➅➇ròࢨorneòᶌarĀ;d྘➃;業;怎ri;抿̀achiqt➘➝ੀ➢➮➻quo;怹r;쀀𝓁mƀ;egল➪➬;檍;檏Ābu┪➳oĀ;rฟ➹;怚rok;䅂萀<;cdhilqrࠫ⟒☹⟜⟠⟥⟪⟰Āci⟗⟙;檦r;橹reå◲mes;拉arr;楶uest;橻ĀPi⟵⟹ar;榖ƀ;ef⠀भ᠛旃rĀdu⠇⠍shar;楊har;楦Āen⠗⠡rtneqq;쀀≨︀Å⠞܀Dacdefhilnopsu⡀⡅⢂⢎⢓⢠⢥⢨⣚⣢⣤ઃ⣳⤂Dot;戺Ȁclpr⡎⡒⡣⡽r耻¯䂯Āet⡗⡙;時Ā;e⡞⡟朠se»⡟Ā;sျ⡨toȀ;dluျ⡳⡷⡻owîҌefôएðᏑker;斮Āoy⢇⢌mma;権;䐼ash;怔asuredangle»ᘦr;쀀𝔪o;愧ƀcdn⢯⢴⣉ro耻µ䂵Ȁ;acdᑤ⢽⣀⣄sôᚧir;櫰ot肻·Ƶusƀ;bd⣒ᤃ⣓戒Ā;uᴼ⣘;横ţ⣞⣡p;櫛ò−ðઁĀdp⣩⣮els;抧f;쀀𝕞Āct⣸⣽r;쀀𝓂pos»ᖝƀ;lm⤉⤊⤍䎼timap;抸ఀGLRVabcdefghijlmoprstuvw⥂⥓⥾⦉⦘⧚⧩⨕⨚⩘⩝⪃⪕⪤⪨⬄⬇⭄⭿⮮ⰴⱧⱼ⳩Āgt⥇⥋;쀀⋙̸Ā;v⥐௏쀀≫⃒ƀelt⥚⥲⥶ftĀar⥡⥧rrow;懍ightarrow;懎;쀀⋘̸Ā;v⥻ే쀀≪⃒ightarrow;懏ĀDd⦎⦓ash;抯ash;抮ʀbcnpt⦣⦧⦬⦱⧌la»˞ute;䅄g;쀀∠⃒ʀ;Eiop඄⦼⧀⧅⧈;쀀⩰̸d;쀀≋̸s;䅉roø඄urĀ;a⧓⧔普lĀ;s⧓ସǳ⧟\0⧣p肻 ଷmpĀ;e௹ఀʀaeouy⧴⧾⨃⨐⨓ǰ⧹\0⧻;橃on;䅈dil;䅆ngĀ;dൾ⨊ot;쀀⩭̸p;橂;䐽ash;怓΀;Aadqsxஒ⨩⨭⨻⩁⩅⩐rr;懗rĀhr⨳⨶k;椤Ā;oᏲᏰot;쀀≐̸uiöୣĀei⩊⩎ar;椨í஘istĀ;s஠டr;쀀𝔫ȀEest௅⩦⩹⩼ƀ;qs஼⩭௡ƀ;qs஼௅⩴lanô௢ií௪Ā;rஶ⪁»ஷƀAap⪊⪍⪑rò⥱rr;憮ar;櫲ƀ;svྍ⪜ྌĀ;d⪡⪢拼;拺cy;䑚΀AEadest⪷⪺⪾⫂⫅⫶⫹rò⥦;쀀≦̸rr;憚r;急Ȁ;fqs఻⫎⫣⫯tĀar⫔⫙rro÷⫁ightarro÷⪐ƀ;qs఻⪺⫪lanôౕĀ;sౕ⫴»శiíౝĀ;rవ⫾iĀ;eచథiäඐĀpt⬌⬑f;쀀𝕟膀¬;in⬙⬚⬶䂬nȀ;Edvஉ⬤⬨⬮;쀀⋹̸ot;쀀⋵̸ǡஉ⬳⬵;拷;拶iĀ;vಸ⬼ǡಸ⭁⭃;拾;拽ƀaor⭋⭣⭩rȀ;ast୻⭕⭚⭟lleì୻l;쀀⫽⃥;쀀∂̸lint;樔ƀ;ceಒ⭰⭳uåಥĀ;cಘ⭸Ā;eಒ⭽ñಘȀAait⮈⮋⮝⮧rò⦈rrƀ;cw⮔⮕⮙憛;쀀⤳̸;쀀↝̸ghtarrow»⮕riĀ;eೋೖ΀chimpqu⮽⯍⯙⬄୸⯤⯯Ȁ;cerല⯆ഷ⯉uå൅;쀀𝓃ortɭ⬅\0\0⯖ará⭖mĀ;e൮⯟Ā;q൴൳suĀbp⯫⯭å೸åഋƀbcp⯶ⰑⰙȀ;Ees⯿ⰀഢⰄ抄;쀀⫅̸etĀ;eഛⰋqĀ;qണⰀcĀ;eലⰗñസȀ;EesⰢⰣൟⰧ抅;쀀⫆̸etĀ;e൘ⰮqĀ;qൠⰣȀgilrⰽⰿⱅⱇìௗlde耻ñ䃱çృiangleĀlrⱒⱜeftĀ;eచⱚñదightĀ;eೋⱥñ೗Ā;mⱬⱭ䎽ƀ;esⱴⱵⱹ䀣ro;愖p;怇ҀDHadgilrsⲏⲔⲙⲞⲣⲰⲶⳓⳣash;抭arr;椄p;쀀≍⃒ash;抬ĀetⲨⲬ;쀀≥⃒;쀀>⃒nfin;槞ƀAetⲽⳁⳅrr;椂;쀀≤⃒Ā;rⳊⳍ쀀<⃒ie;쀀⊴⃒ĀAtⳘⳜrr;椃rie;쀀⊵⃒im;쀀∼⃒ƀAan⳰⳴ⴂrr;懖rĀhr⳺⳽k;椣Ā;oᏧᏥear;椧ቓ᪕\0\0\0\0\0\0\0\0\0\0\0\0\0ⴭ\0ⴸⵈⵠⵥ⵲ⶄᬇ\0\0ⶍⶫ\0ⷈⷎ\0ⷜ⸙⸫⸾⹃Ācsⴱ᪗ute耻ó䃳ĀiyⴼⵅrĀ;c᪞ⵂ耻ô䃴;䐾ʀabios᪠ⵒⵗǈⵚlac;䅑v;樸old;榼lig;䅓Ācr⵩⵭ir;榿;쀀𝔬ͯ⵹\0\0⵼\0ⶂn;䋛ave耻ò䃲;槁Ābmⶈ෴ar;榵Ȁacitⶕ⶘ⶥⶨrò᪀Āir⶝ⶠr;榾oss;榻nå๒;槀ƀaeiⶱⶵⶹcr;䅍ga;䏉ƀcdnⷀⷅǍron;䎿;榶pf;쀀𝕠ƀaelⷔ⷗ǒr;榷rp;榹΀;adiosvⷪⷫⷮ⸈⸍⸐⸖戨rò᪆Ȁ;efmⷷⷸ⸂⸅橝rĀ;oⷾⷿ愴f»ⷿ耻ª䂪耻º䂺gof;抶r;橖lope;橗;橛ƀclo⸟⸡⸧ò⸁ash耻ø䃸l;折iŬⸯ⸴de耻õ䃵esĀ;aǛ⸺s;樶ml耻ö䃶bar;挽ૡ⹞\0⹽\0⺀⺝\0⺢⺹\0\0⻋ຜ\0⼓\0\0⼫⾼\0⿈rȀ;astЃ⹧⹲຅脀¶;l⹭⹮䂶leìЃɩ⹸\0\0⹻m;櫳;櫽y;䐿rʀcimpt⺋⺏⺓ᡥ⺗nt;䀥od;䀮il;怰enk;怱r;쀀𝔭ƀimo⺨⺰⺴Ā;v⺭⺮䏆;䏕maô੶ne;明ƀ;tv⺿⻀⻈䏀chfork»´;䏖Āau⻏⻟nĀck⻕⻝kĀ;h⇴⻛;愎ö⇴sҀ;abcdemst⻳⻴ᤈ⻹⻽⼄⼆⼊⼎䀫cir;樣ir;樢Āouᵀ⼂;樥;橲n肻±ຝim;樦wo;樧ƀipu⼙⼠⼥ntint;樕f;쀀𝕡nd耻£䂣Ԁ;Eaceinosu່⼿⽁⽄⽇⾁⾉⾒⽾⾶;檳p;檷uå໙Ā;c໎⽌̀;acens່⽙⽟⽦⽨⽾pproø⽃urlyeñ໙ñ໎ƀaes⽯⽶⽺pprox;檹qq;檵im;拨iíໟmeĀ;s⾈ຮ怲ƀEas⽸⾐⽺ð⽵ƀdfp໬⾙⾯ƀals⾠⾥⾪lar;挮ine;挒urf;挓Ā;t໻⾴ï໻rel;抰Āci⿀⿅r;쀀𝓅;䏈ncsp;怈̀fiopsu⿚⋢⿟⿥⿫⿱r;쀀𝔮pf;쀀𝕢rime;恗cr;쀀𝓆ƀaeo⿸〉〓tĀei⿾々rnionóڰnt;樖stĀ;e【】䀿ñἙô༔઀ABHabcdefhilmnoprstux぀けさすムㄎㄫㅇㅢㅲㆎ㈆㈕㈤㈩㉘㉮㉲㊐㊰㊷ƀartぇおがròႳòϝail;検aròᱥar;楤΀cdenqrtとふへみわゔヌĀeuねぱ;쀀∽̱te;䅕iãᅮmptyv;榳gȀ;del࿑らるろ;榒;榥å࿑uo耻»䂻rր;abcfhlpstw࿜ガクシスゼゾダッデナp;極Ā;f࿠ゴs;椠;椳s;椞ë≝ð✮l;楅im;楴l;憣;憝Āaiパフil;椚oĀ;nホボ戶aló༞ƀabrョリヮrò៥rk;杳ĀakンヽcĀekヹ・;䁽;䁝Āes㄂㄄;榌lĀduㄊㄌ;榎;榐Ȁaeuyㄗㄜㄧㄩron;䅙Ādiㄡㄥil;䅗ì࿲âヺ;䑀Ȁclqsㄴㄷㄽㅄa;椷dhar;楩uoĀ;rȎȍh;憳ƀacgㅎㅟངlȀ;ipsླྀㅘㅛႜnåႻarôྩt;断ƀilrㅩဣㅮsht;楽;쀀𝔯ĀaoㅷㆆrĀduㅽㅿ»ѻĀ;l႑ㆄ;楬Ā;vㆋㆌ䏁;䏱ƀgns㆕ㇹㇼht̀ahlrstㆤㆰ㇂㇘㇤㇮rrowĀ;t࿜ㆭaéトarpoonĀduㆻㆿowîㅾp»႒eftĀah㇊㇐rrowó࿪arpoonóՑightarrows;應quigarro÷ニhreetimes;拌g;䋚ingdotseñἲƀahm㈍㈐㈓rò࿪aòՑ;怏oustĀ;a㈞㈟掱che»㈟mid;櫮Ȁabpt㈲㈽㉀㉒Ānr㈷㈺g;柭r;懾rëဃƀafl㉇㉊㉎r;榆;쀀𝕣us;樮imes;樵Āap㉝㉧rĀ;g㉣㉤䀩t;榔olint;樒arò㇣Ȁachq㉻㊀Ⴜ㊅quo;怺r;쀀𝓇Ābu・㊊oĀ;rȔȓƀhir㊗㊛㊠reåㇸmes;拊iȀ;efl㊪ၙᠡ㊫方tri;槎luhar;楨;愞ൡ㋕㋛㋟㌬㌸㍱\0㍺㎤\0\0㏬㏰\0㐨㑈㑚㒭㒱㓊㓱\0㘖\0\0㘳cute;䅛quï➺Ԁ;Eaceinpsyᇭ㋳㋵㋿㌂㌋㌏㌟㌦㌩;檴ǰ㋺\0㋼;檸on;䅡uåᇾĀ;dᇳ㌇il;䅟rc;䅝ƀEas㌖㌘㌛;檶p;檺im;择olint;樓iíሄ;䑁otƀ;be㌴ᵇ㌵担;橦΀Aacmstx㍆㍊㍗㍛㍞㍣㍭rr;懘rĀhr㍐㍒ë∨Ā;oਸ਼਴t耻§䂧i;䀻war;椩mĀin㍩ðnuóñt;朶rĀ;o㍶⁕쀀𝔰Ȁacoy㎂㎆㎑㎠rp;景Āhy㎋㎏cy;䑉;䑈rtɭ㎙\0\0㎜iäᑤaraì⹯耻­䂭Āgm㎨㎴maƀ;fv㎱㎲㎲䏃;䏂Ѐ;deglnprካ㏅㏉㏎㏖㏞㏡㏦ot;橪Ā;q኱ኰĀ;E㏓㏔檞;檠Ā;E㏛㏜檝;檟e;扆lus;樤arr;楲aròᄽȀaeit㏸㐈㐏㐗Āls㏽㐄lsetmé㍪hp;樳parsl;槤Ādlᑣ㐔e;挣Ā;e㐜㐝檪Ā;s㐢㐣檬;쀀⪬︀ƀflp㐮㐳㑂tcy;䑌Ā;b㐸㐹䀯Ā;a㐾㐿槄r;挿f;쀀𝕤aĀdr㑍ЂesĀ;u㑔㑕晠it»㑕ƀcsu㑠㑹㒟Āau㑥㑯pĀ;sᆈ㑫;쀀⊓︀pĀ;sᆴ㑵;쀀⊔︀uĀbp㑿㒏ƀ;esᆗᆜ㒆etĀ;eᆗ㒍ñᆝƀ;esᆨᆭ㒖etĀ;eᆨ㒝ñᆮƀ;afᅻ㒦ְrť㒫ֱ»ᅼaròᅈȀcemt㒹㒾㓂㓅r;쀀𝓈tmîñiì㐕aræᆾĀar㓎㓕rĀ;f㓔ឿ昆Āan㓚㓭ightĀep㓣㓪psiloîỠhé⺯s»⡒ʀbcmnp㓻㕞ሉ㖋㖎Ҁ;Edemnprs㔎㔏㔑㔕㔞㔣㔬㔱㔶抂;櫅ot;檽Ā;dᇚ㔚ot;櫃ult;櫁ĀEe㔨㔪;櫋;把lus;檿arr;楹ƀeiu㔽㕒㕕tƀ;en㔎㕅㕋qĀ;qᇚ㔏eqĀ;q㔫㔨m;櫇Ābp㕚㕜;櫕;櫓c̀;acensᇭ㕬㕲㕹㕻㌦pproø㋺urlyeñᇾñᇳƀaes㖂㖈㌛pproø㌚qñ㌗g;晪ڀ123;Edehlmnps㖩㖬㖯ሜ㖲㖴㗀㗉㗕㗚㗟㗨㗭耻¹䂹耻²䂲耻³䂳;櫆Āos㖹㖼t;檾ub;櫘Ā;dሢ㗅ot;櫄sĀou㗏㗒l;柉b;櫗arr;楻ult;櫂ĀEe㗤㗦;櫌;抋lus;櫀ƀeiu㗴㘉㘌tƀ;enሜ㗼㘂qĀ;qሢ㖲eqĀ;q㗧㗤m;櫈Ābp㘑㘓;櫔;櫖ƀAan㘜㘠㘭rr;懙rĀhr㘦㘨ë∮Ā;oਫ਩war;椪lig耻ß䃟௡㙑㙝㙠ዎ㙳㙹\0㙾㛂\0\0\0\0\0㛛㜃\0㜉㝬\0\0\0㞇ɲ㙖\0\0㙛get;挖;䏄rë๟ƀaey㙦㙫㙰ron;䅥dil;䅣;䑂lrec;挕r;쀀𝔱Ȁeiko㚆㚝㚵㚼ǲ㚋\0㚑eĀ4fኄኁaƀ;sv㚘㚙㚛䎸ym;䏑Ācn㚢㚲kĀas㚨㚮pproø዁im»ኬsðኞĀas㚺㚮ð዁rn耻þ䃾Ǭ̟㛆⋧es膀×;bd㛏㛐㛘䃗Ā;aᤏ㛕r;樱;樰ƀeps㛡㛣㜀á⩍Ȁ;bcf҆㛬㛰㛴ot;挶ir;櫱Ā;o㛹㛼쀀𝕥rk;櫚á㍢rime;怴ƀaip㜏㜒㝤dåቈ΀adempst㜡㝍㝀㝑㝗㝜㝟ngleʀ;dlqr㜰㜱㜶㝀㝂斵own»ᶻeftĀ;e⠀㜾ñम;扜ightĀ;e㊪㝋ñၚot;旬inus;樺lus;樹b;槍ime;樻ezium;揢ƀcht㝲㝽㞁Āry㝷㝻;쀀𝓉;䑆cy;䑛rok;䅧Āio㞋㞎xô᝷headĀlr㞗㞠eftarro÷ࡏightarrow»ཝऀAHabcdfghlmoprstuw㟐㟓㟗㟤㟰㟼㠎㠜㠣㠴㡑㡝㡫㢩㣌㣒㣪㣶ròϭar;楣Ācr㟜㟢ute耻ú䃺òᅐrǣ㟪\0㟭y;䑞ve;䅭Āiy㟵㟺rc耻û䃻;䑃ƀabh㠃㠆㠋ròᎭlac;䅱aòᏃĀir㠓㠘sht;楾;쀀𝔲rave耻ù䃹š㠧㠱rĀlr㠬㠮»ॗ»ႃlk;斀Āct㠹㡍ɯ㠿\0\0㡊rnĀ;e㡅㡆挜r»㡆op;挏ri;旸Āal㡖㡚cr;䅫肻¨͉Āgp㡢㡦on;䅳f;쀀𝕦̀adhlsuᅋ㡸㡽፲㢑㢠ownáᎳarpoonĀlr㢈㢌efô㠭ighô㠯iƀ;hl㢙㢚㢜䏅»ᏺon»㢚parrows;懈ƀcit㢰㣄㣈ɯ㢶\0\0㣁rnĀ;e㢼㢽挝r»㢽op;挎ng;䅯ri;旹cr;쀀𝓊ƀdir㣙㣝㣢ot;拰lde;䅩iĀ;f㜰㣨»᠓Āam㣯㣲rò㢨l耻ü䃼angle;榧ހABDacdeflnoprsz㤜㤟㤩㤭㦵㦸㦽㧟㧤㧨㧳㧹㧽㨁㨠ròϷarĀ;v㤦㤧櫨;櫩asèϡĀnr㤲㤷grt;榜΀eknprst㓣㥆㥋㥒㥝㥤㦖appá␕othinçẖƀhir㓫⻈㥙opô⾵Ā;hᎷ㥢ïㆍĀiu㥩㥭gmá㎳Ābp㥲㦄setneqĀ;q㥽㦀쀀⊊︀;쀀⫋︀setneqĀ;q㦏㦒쀀⊋︀;쀀⫌︀Āhr㦛㦟etá㚜iangleĀlr㦪㦯eft»थight»ၑy;䐲ash»ံƀelr㧄㧒㧗ƀ;beⷪ㧋㧏ar;抻q;扚lip;拮Ābt㧜ᑨaòᑩr;쀀𝔳tré㦮suĀbp㧯㧱»ജ»൙pf;쀀𝕧roð໻tré㦴Ācu㨆㨋r;쀀𝓋Ābp㨐㨘nĀEe㦀㨖»㥾nĀEe㦒㨞»㦐igzag;榚΀cefoprs㨶㨻㩖㩛㩔㩡㩪irc;䅵Ādi㩀㩑Ābg㩅㩉ar;機eĀ;qᗺ㩏;扙erp;愘r;쀀𝔴pf;쀀𝕨Ā;eᑹ㩦atèᑹcr;쀀𝓌ૣណ㪇\0㪋\0㪐㪛\0\0㪝㪨㪫㪯\0\0㫃㫎\0㫘ៜ៟tré៑r;쀀𝔵ĀAa㪔㪗ròσrò৶;䎾ĀAa㪡㪤ròθrò৫að✓is;拻ƀdptឤ㪵㪾Āfl㪺ឩ;쀀𝕩imåឲĀAa㫇㫊ròώròਁĀcq㫒ីr;쀀𝓍Āpt៖㫜ré។Ѐacefiosu㫰㫽㬈㬌㬑㬕㬛㬡cĀuy㫶㫻te耻ý䃽;䑏Āiy㬂㬆rc;䅷;䑋n耻¥䂥r;쀀𝔶cy;䑗pf;쀀𝕪cr;쀀𝓎Ācm㬦㬩y;䑎l耻ÿ䃿Ԁacdefhiosw㭂㭈㭔㭘㭤㭩㭭㭴㭺㮀cute;䅺Āay㭍㭒ron;䅾;䐷ot;䅼Āet㭝㭡træᕟa;䎶r;쀀𝔷cy;䐶grarr;懝pf;쀀𝕫cr;쀀𝓏Ājn㮅㮇;怍j;怌'.split("").map(function(o) {
    return o.charCodeAt(0);
  })
);
var Gr = {};
Object.defineProperty(Gr, "__esModule", { value: !0 });
Gr.default = new Uint16Array(
  // prettier-ignore
  "Ȁaglq	\x1Bɭ\0\0p;䀦os;䀧t;䀾t;䀼uot;䀢".split("").map(function(o) {
    return o.charCodeAt(0);
  })
);
var Pr = {};
(function(o) {
  var i;
  Object.defineProperty(o, "__esModule", { value: !0 }), o.replaceCodePoint = o.fromCodePoint = void 0;
  var n = /* @__PURE__ */ new Map([
    [0, 65533],
    // C1 Unicode control character reference replacements
    [128, 8364],
    [130, 8218],
    [131, 402],
    [132, 8222],
    [133, 8230],
    [134, 8224],
    [135, 8225],
    [136, 710],
    [137, 8240],
    [138, 352],
    [139, 8249],
    [140, 338],
    [142, 381],
    [145, 8216],
    [146, 8217],
    [147, 8220],
    [148, 8221],
    [149, 8226],
    [150, 8211],
    [151, 8212],
    [152, 732],
    [153, 8482],
    [154, 353],
    [155, 8250],
    [156, 339],
    [158, 382],
    [159, 376]
  ]);
  o.fromCodePoint = // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition, node/no-unsupported-features/es-builtins
  (i = String.fromCodePoint) !== null && i !== void 0 ? i : function(c) {
    var p = "";
    return c > 65535 && (c -= 65536, p += String.fromCharCode(c >>> 10 & 1023 | 55296), c = 56320 | c & 1023), p += String.fromCharCode(c), p;
  };
  function r(c) {
    var p;
    return c >= 55296 && c <= 57343 || c > 1114111 ? 65533 : (p = n.get(c)) !== null && p !== void 0 ? p : c;
  }
  o.replaceCodePoint = r;
  function a(c) {
    return (0, o.fromCodePoint)(r(c));
  }
  o.default = a;
})(Pr);
(function(o) {
  var i = W && W.__createBinding || (Object.create ? function(T, A, D, Z) {
    Z === void 0 && (Z = D);
    var x = Object.getOwnPropertyDescriptor(A, D);
    (!x || ("get" in x ? !A.__esModule : x.writable || x.configurable)) && (x = { enumerable: !0, get: function() {
      return A[D];
    } }), Object.defineProperty(T, Z, x);
  } : function(T, A, D, Z) {
    Z === void 0 && (Z = D), T[Z] = A[D];
  }), n = W && W.__setModuleDefault || (Object.create ? function(T, A) {
    Object.defineProperty(T, "default", { enumerable: !0, value: A });
  } : function(T, A) {
    T.default = A;
  }), r = W && W.__importStar || function(T) {
    if (T && T.__esModule)
      return T;
    var A = {};
    if (T != null)
      for (var D in T)
        D !== "default" && Object.prototype.hasOwnProperty.call(T, D) && i(A, T, D);
    return n(A, T), A;
  }, a = W && W.__importDefault || function(T) {
    return T && T.__esModule ? T : { default: T };
  };
  Object.defineProperty(o, "__esModule", { value: !0 }), o.decodeXML = o.decodeHTMLStrict = o.decodeHTMLAttribute = o.decodeHTML = o.determineBranch = o.EntityDecoder = o.DecodingMode = o.BinTrieFlags = o.fromCodePoint = o.replaceCodePoint = o.decodeCodePoint = o.xmlDecodeTree = o.htmlDecodeTree = void 0;
  var c = a(Wr);
  o.htmlDecodeTree = c.default;
  var p = a(Gr);
  o.xmlDecodeTree = p.default;
  var g = r(Pr);
  o.decodeCodePoint = g.default;
  var d = Pr;
  Object.defineProperty(o, "replaceCodePoint", { enumerable: !0, get: function() {
    return d.replaceCodePoint;
  } }), Object.defineProperty(o, "fromCodePoint", { enumerable: !0, get: function() {
    return d.fromCodePoint;
  } });
  var _;
  (function(T) {
    T[T.NUM = 35] = "NUM", T[T.SEMI = 59] = "SEMI", T[T.EQUALS = 61] = "EQUALS", T[T.ZERO = 48] = "ZERO", T[T.NINE = 57] = "NINE", T[T.LOWER_A = 97] = "LOWER_A", T[T.LOWER_F = 102] = "LOWER_F", T[T.LOWER_X = 120] = "LOWER_X", T[T.LOWER_Z = 122] = "LOWER_Z", T[T.UPPER_A = 65] = "UPPER_A", T[T.UPPER_F = 70] = "UPPER_F", T[T.UPPER_Z = 90] = "UPPER_Z";
  })(_ || (_ = {}));
  var v = 32, S;
  (function(T) {
    T[T.VALUE_LENGTH = 49152] = "VALUE_LENGTH", T[T.BRANCH_LENGTH = 16256] = "BRANCH_LENGTH", T[T.JUMP_TABLE = 127] = "JUMP_TABLE";
  })(S = o.BinTrieFlags || (o.BinTrieFlags = {}));
  function f(T) {
    return T >= _.ZERO && T <= _.NINE;
  }
  function m(T) {
    return T >= _.UPPER_A && T <= _.UPPER_F || T >= _.LOWER_A && T <= _.LOWER_F;
  }
  function N(T) {
    return T >= _.UPPER_A && T <= _.UPPER_Z || T >= _.LOWER_A && T <= _.LOWER_Z || f(T);
  }
  function I(T) {
    return T === _.EQUALS || N(T);
  }
  var E;
  (function(T) {
    T[T.EntityStart = 0] = "EntityStart", T[T.NumericStart = 1] = "NumericStart", T[T.NumericDecimal = 2] = "NumericDecimal", T[T.NumericHex = 3] = "NumericHex", T[T.NamedEntity = 4] = "NamedEntity";
  })(E || (E = {}));
  var z;
  (function(T) {
    T[T.Legacy = 0] = "Legacy", T[T.Strict = 1] = "Strict", T[T.Attribute = 2] = "Attribute";
  })(z = o.DecodingMode || (o.DecodingMode = {}));
  var H = (
    /** @class */
    function() {
      function T(A, D, Z) {
        this.decodeTree = A, this.emitCodePoint = D, this.errors = Z, this.state = E.EntityStart, this.consumed = 1, this.result = 0, this.treeIndex = 0, this.excess = 1, this.decodeMode = z.Strict;
      }
      return T.prototype.startEntity = function(A) {
        this.decodeMode = A, this.state = E.EntityStart, this.result = 0, this.treeIndex = 0, this.excess = 1, this.consumed = 1;
      }, T.prototype.write = function(A, D) {
        switch (this.state) {
          case E.EntityStart:
            return A.charCodeAt(D) === _.NUM ? (this.state = E.NumericStart, this.consumed += 1, this.stateNumericStart(A, D + 1)) : (this.state = E.NamedEntity, this.stateNamedEntity(A, D));
          case E.NumericStart:
            return this.stateNumericStart(A, D);
          case E.NumericDecimal:
            return this.stateNumericDecimal(A, D);
          case E.NumericHex:
            return this.stateNumericHex(A, D);
          case E.NamedEntity:
            return this.stateNamedEntity(A, D);
        }
      }, T.prototype.stateNumericStart = function(A, D) {
        return D >= A.length ? -1 : (A.charCodeAt(D) | v) === _.LOWER_X ? (this.state = E.NumericHex, this.consumed += 1, this.stateNumericHex(A, D + 1)) : (this.state = E.NumericDecimal, this.stateNumericDecimal(A, D));
      }, T.prototype.addToNumericResult = function(A, D, Z, x) {
        if (D !== Z) {
          var C = Z - D;
          this.result = this.result * Math.pow(x, C) + parseInt(A.substr(D, C), x), this.consumed += C;
        }
      }, T.prototype.stateNumericHex = function(A, D) {
        for (var Z = D; D < A.length; ) {
          var x = A.charCodeAt(D);
          if (f(x) || m(x))
            D += 1;
          else
            return this.addToNumericResult(A, Z, D, 16), this.emitNumericEntity(x, 3);
        }
        return this.addToNumericResult(A, Z, D, 16), -1;
      }, T.prototype.stateNumericDecimal = function(A, D) {
        for (var Z = D; D < A.length; ) {
          var x = A.charCodeAt(D);
          if (f(x))
            D += 1;
          else
            return this.addToNumericResult(A, Z, D, 10), this.emitNumericEntity(x, 2);
        }
        return this.addToNumericResult(A, Z, D, 10), -1;
      }, T.prototype.emitNumericEntity = function(A, D) {
        var Z;
        if (this.consumed <= D)
          return (Z = this.errors) === null || Z === void 0 || Z.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
        if (A === _.SEMI)
          this.consumed += 1;
        else if (this.decodeMode === z.Strict)
          return 0;
        return this.emitCodePoint((0, g.replaceCodePoint)(this.result), this.consumed), this.errors && (A !== _.SEMI && this.errors.missingSemicolonAfterCharacterReference(), this.errors.validateNumericCharacterReference(this.result)), this.consumed;
      }, T.prototype.stateNamedEntity = function(A, D) {
        for (var Z = this.decodeTree, x = Z[this.treeIndex], C = (x & S.VALUE_LENGTH) >> 14; D < A.length; D++, this.excess++) {
          var w = A.charCodeAt(D);
          if (this.treeIndex = G(Z, x, this.treeIndex + Math.max(1, C), w), this.treeIndex < 0)
            return this.result === 0 || // If we are parsing an attribute
            this.decodeMode === z.Attribute && // We shouldn't have consumed any characters after the entity,
            (C === 0 || // And there should be no invalid characters.
            I(w)) ? 0 : this.emitNotTerminatedNamedEntity();
          if (x = Z[this.treeIndex], C = (x & S.VALUE_LENGTH) >> 14, C !== 0) {
            if (w === _.SEMI)
              return this.emitNamedEntityData(this.treeIndex, C, this.consumed + this.excess);
            this.decodeMode !== z.Strict && (this.result = this.treeIndex, this.consumed += this.excess, this.excess = 0);
          }
        }
        return -1;
      }, T.prototype.emitNotTerminatedNamedEntity = function() {
        var A, D = this, Z = D.result, x = D.decodeTree, C = (x[Z] & S.VALUE_LENGTH) >> 14;
        return this.emitNamedEntityData(Z, C, this.consumed), (A = this.errors) === null || A === void 0 || A.missingSemicolonAfterCharacterReference(), this.consumed;
      }, T.prototype.emitNamedEntityData = function(A, D, Z) {
        var x = this.decodeTree;
        return this.emitCodePoint(D === 1 ? x[A] & ~S.VALUE_LENGTH : x[A + 1], Z), D === 3 && this.emitCodePoint(x[A + 2], Z), Z;
      }, T.prototype.end = function() {
        var A;
        switch (this.state) {
          case E.NamedEntity:
            return this.result !== 0 && (this.decodeMode !== z.Attribute || this.result === this.treeIndex) ? this.emitNotTerminatedNamedEntity() : 0;
          case E.NumericDecimal:
            return this.emitNumericEntity(0, 2);
          case E.NumericHex:
            return this.emitNumericEntity(0, 3);
          case E.NumericStart:
            return (A = this.errors) === null || A === void 0 || A.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
          case E.EntityStart:
            return 0;
        }
      }, T;
    }()
  );
  o.EntityDecoder = H;
  function U(T) {
    var A = "", D = new H(T, function(Z) {
      return A += (0, g.fromCodePoint)(Z);
    });
    return function(x, C) {
      for (var w = 0, R = 0; (R = x.indexOf("&", R)) >= 0; ) {
        A += x.slice(w, R), D.startEntity(C);
        var M = D.write(
          x,
          // Skip the "&"
          R + 1
        );
        if (M < 0) {
          w = R + D.end();
          break;
        }
        w = R + M, R = M === 0 ? w + 1 : w;
      }
      var V = A + x.slice(w);
      return A = "", V;
    };
  }
  function G(T, A, D, Z) {
    var x = (A & S.BRANCH_LENGTH) >> 7, C = A & S.JUMP_TABLE;
    if (x === 0)
      return C !== 0 && Z === C ? D : -1;
    if (C) {
      var w = Z - C;
      return w < 0 || w >= x ? -1 : T[D + w] - 1;
    }
    for (var R = D, M = R + x - 1; R <= M; ) {
      var V = R + M >>> 1, pe = T[V];
      if (pe < Z)
        R = V + 1;
      else if (pe > Z)
        M = V - 1;
      else
        return T[V + x];
    }
    return -1;
  }
  o.determineBranch = G;
  var re = U(c.default), he = U(p.default);
  function Le(T, A) {
    return A === void 0 && (A = z.Legacy), re(T, A);
  }
  o.decodeHTML = Le;
  function se(T) {
    return re(T, z.Attribute);
  }
  o.decodeHTMLAttribute = se;
  function be(T) {
    return re(T, z.Strict);
  }
  o.decodeHTMLStrict = be;
  function xe(T) {
    return he(T, z.Strict);
  }
  o.decodeXML = xe;
})(vi);
(function(o) {
  Object.defineProperty(o, "__esModule", { value: !0 }), o.QuoteType = void 0;
  var i = vi, n;
  (function(f) {
    f[f.Tab = 9] = "Tab", f[f.NewLine = 10] = "NewLine", f[f.FormFeed = 12] = "FormFeed", f[f.CarriageReturn = 13] = "CarriageReturn", f[f.Space = 32] = "Space", f[f.ExclamationMark = 33] = "ExclamationMark", f[f.Number = 35] = "Number", f[f.Amp = 38] = "Amp", f[f.SingleQuote = 39] = "SingleQuote", f[f.DoubleQuote = 34] = "DoubleQuote", f[f.Dash = 45] = "Dash", f[f.Slash = 47] = "Slash", f[f.Zero = 48] = "Zero", f[f.Nine = 57] = "Nine", f[f.Semi = 59] = "Semi", f[f.Lt = 60] = "Lt", f[f.Eq = 61] = "Eq", f[f.Gt = 62] = "Gt", f[f.Questionmark = 63] = "Questionmark", f[f.UpperA = 65] = "UpperA", f[f.LowerA = 97] = "LowerA", f[f.UpperF = 70] = "UpperF", f[f.LowerF = 102] = "LowerF", f[f.UpperZ = 90] = "UpperZ", f[f.LowerZ = 122] = "LowerZ", f[f.LowerX = 120] = "LowerX", f[f.OpeningSquareBracket = 91] = "OpeningSquareBracket";
  })(n || (n = {}));
  var r;
  (function(f) {
    f[f.Text = 1] = "Text", f[f.BeforeTagName = 2] = "BeforeTagName", f[f.InTagName = 3] = "InTagName", f[f.InSelfClosingTag = 4] = "InSelfClosingTag", f[f.BeforeClosingTagName = 5] = "BeforeClosingTagName", f[f.InClosingTagName = 6] = "InClosingTagName", f[f.AfterClosingTagName = 7] = "AfterClosingTagName", f[f.BeforeAttributeName = 8] = "BeforeAttributeName", f[f.InAttributeName = 9] = "InAttributeName", f[f.AfterAttributeName = 10] = "AfterAttributeName", f[f.BeforeAttributeValue = 11] = "BeforeAttributeValue", f[f.InAttributeValueDq = 12] = "InAttributeValueDq", f[f.InAttributeValueSq = 13] = "InAttributeValueSq", f[f.InAttributeValueNq = 14] = "InAttributeValueNq", f[f.BeforeDeclaration = 15] = "BeforeDeclaration", f[f.InDeclaration = 16] = "InDeclaration", f[f.InProcessingInstruction = 17] = "InProcessingInstruction", f[f.BeforeComment = 18] = "BeforeComment", f[f.CDATASequence = 19] = "CDATASequence", f[f.InSpecialComment = 20] = "InSpecialComment", f[f.InCommentLike = 21] = "InCommentLike", f[f.BeforeSpecialS = 22] = "BeforeSpecialS", f[f.SpecialStartSequence = 23] = "SpecialStartSequence", f[f.InSpecialTag = 24] = "InSpecialTag", f[f.BeforeEntity = 25] = "BeforeEntity", f[f.BeforeNumericEntity = 26] = "BeforeNumericEntity", f[f.InNamedEntity = 27] = "InNamedEntity", f[f.InNumericEntity = 28] = "InNumericEntity", f[f.InHexEntity = 29] = "InHexEntity";
  })(r || (r = {}));
  function a(f) {
    return f === n.Space || f === n.NewLine || f === n.Tab || f === n.FormFeed || f === n.CarriageReturn;
  }
  function c(f) {
    return f === n.Slash || f === n.Gt || a(f);
  }
  function p(f) {
    return f >= n.Zero && f <= n.Nine;
  }
  function g(f) {
    return f >= n.LowerA && f <= n.LowerZ || f >= n.UpperA && f <= n.UpperZ;
  }
  function d(f) {
    return f >= n.UpperA && f <= n.UpperF || f >= n.LowerA && f <= n.LowerF;
  }
  var _;
  (function(f) {
    f[f.NoValue = 0] = "NoValue", f[f.Unquoted = 1] = "Unquoted", f[f.Single = 2] = "Single", f[f.Double = 3] = "Double";
  })(_ = o.QuoteType || (o.QuoteType = {}));
  var v = {
    Cdata: new Uint8Array([67, 68, 65, 84, 65, 91]),
    CdataEnd: new Uint8Array([93, 93, 62]),
    CommentEnd: new Uint8Array([45, 45, 62]),
    ScriptEnd: new Uint8Array([60, 47, 115, 99, 114, 105, 112, 116]),
    StyleEnd: new Uint8Array([60, 47, 115, 116, 121, 108, 101]),
    TitleEnd: new Uint8Array([60, 47, 116, 105, 116, 108, 101])
    // `</title`
  }, S = (
    /** @class */
    function() {
      function f(m, N) {
        var I = m.xmlMode, E = I === void 0 ? !1 : I, z = m.decodeEntities, H = z === void 0 ? !0 : z;
        this.cbs = N, this.state = r.Text, this.buffer = "", this.sectionStart = 0, this.index = 0, this.baseState = r.Text, this.isSpecial = !1, this.running = !0, this.offset = 0, this.currentSequence = void 0, this.sequenceIndex = 0, this.trieIndex = 0, this.trieCurrent = 0, this.entityResult = 0, this.entityExcess = 0, this.xmlMode = E, this.decodeEntities = H, this.entityTrie = E ? i.xmlDecodeTree : i.htmlDecodeTree;
      }
      return f.prototype.reset = function() {
        this.state = r.Text, this.buffer = "", this.sectionStart = 0, this.index = 0, this.baseState = r.Text, this.currentSequence = void 0, this.running = !0, this.offset = 0;
      }, f.prototype.write = function(m) {
        this.offset += this.buffer.length, this.buffer = m, this.parse();
      }, f.prototype.end = function() {
        this.running && this.finish();
      }, f.prototype.pause = function() {
        this.running = !1;
      }, f.prototype.resume = function() {
        this.running = !0, this.index < this.buffer.length + this.offset && this.parse();
      }, f.prototype.getIndex = function() {
        return this.index;
      }, f.prototype.getSectionStart = function() {
        return this.sectionStart;
      }, f.prototype.stateText = function(m) {
        m === n.Lt || !this.decodeEntities && this.fastForwardTo(n.Lt) ? (this.index > this.sectionStart && this.cbs.ontext(this.sectionStart, this.index), this.state = r.BeforeTagName, this.sectionStart = this.index) : this.decodeEntities && m === n.Amp && (this.state = r.BeforeEntity);
      }, f.prototype.stateSpecialStartSequence = function(m) {
        var N = this.sequenceIndex === this.currentSequence.length, I = N ? (
          // If we are at the end of the sequence, make sure the tag name has ended
          c(m)
        ) : (
          // Otherwise, do a case-insensitive comparison
          (m | 32) === this.currentSequence[this.sequenceIndex]
        );
        if (!I)
          this.isSpecial = !1;
        else if (!N) {
          this.sequenceIndex++;
          return;
        }
        this.sequenceIndex = 0, this.state = r.InTagName, this.stateInTagName(m);
      }, f.prototype.stateInSpecialTag = function(m) {
        if (this.sequenceIndex === this.currentSequence.length) {
          if (m === n.Gt || a(m)) {
            var N = this.index - this.currentSequence.length;
            if (this.sectionStart < N) {
              var I = this.index;
              this.index = N, this.cbs.ontext(this.sectionStart, N), this.index = I;
            }
            this.isSpecial = !1, this.sectionStart = N + 2, this.stateInClosingTagName(m);
            return;
          }
          this.sequenceIndex = 0;
        }
        (m | 32) === this.currentSequence[this.sequenceIndex] ? this.sequenceIndex += 1 : this.sequenceIndex === 0 ? this.currentSequence === v.TitleEnd ? this.decodeEntities && m === n.Amp && (this.state = r.BeforeEntity) : this.fastForwardTo(n.Lt) && (this.sequenceIndex = 1) : this.sequenceIndex = +(m === n.Lt);
      }, f.prototype.stateCDATASequence = function(m) {
        m === v.Cdata[this.sequenceIndex] ? ++this.sequenceIndex === v.Cdata.length && (this.state = r.InCommentLike, this.currentSequence = v.CdataEnd, this.sequenceIndex = 0, this.sectionStart = this.index + 1) : (this.sequenceIndex = 0, this.state = r.InDeclaration, this.stateInDeclaration(m));
      }, f.prototype.fastForwardTo = function(m) {
        for (; ++this.index < this.buffer.length + this.offset; )
          if (this.buffer.charCodeAt(this.index - this.offset) === m)
            return !0;
        return this.index = this.buffer.length + this.offset - 1, !1;
      }, f.prototype.stateInCommentLike = function(m) {
        m === this.currentSequence[this.sequenceIndex] ? ++this.sequenceIndex === this.currentSequence.length && (this.currentSequence === v.CdataEnd ? this.cbs.oncdata(this.sectionStart, this.index, 2) : this.cbs.oncomment(this.sectionStart, this.index, 2), this.sequenceIndex = 0, this.sectionStart = this.index + 1, this.state = r.Text) : this.sequenceIndex === 0 ? this.fastForwardTo(this.currentSequence[0]) && (this.sequenceIndex = 1) : m !== this.currentSequence[this.sequenceIndex - 1] && (this.sequenceIndex = 0);
      }, f.prototype.isTagStartChar = function(m) {
        return this.xmlMode ? !c(m) : g(m);
      }, f.prototype.startSpecial = function(m, N) {
        this.isSpecial = !0, this.currentSequence = m, this.sequenceIndex = N, this.state = r.SpecialStartSequence;
      }, f.prototype.stateBeforeTagName = function(m) {
        if (m === n.ExclamationMark)
          this.state = r.BeforeDeclaration, this.sectionStart = this.index + 1;
        else if (m === n.Questionmark)
          this.state = r.InProcessingInstruction, this.sectionStart = this.index + 1;
        else if (this.isTagStartChar(m)) {
          var N = m | 32;
          this.sectionStart = this.index, !this.xmlMode && N === v.TitleEnd[2] ? this.startSpecial(v.TitleEnd, 3) : this.state = !this.xmlMode && N === v.ScriptEnd[2] ? r.BeforeSpecialS : r.InTagName;
        } else
          m === n.Slash ? this.state = r.BeforeClosingTagName : (this.state = r.Text, this.stateText(m));
      }, f.prototype.stateInTagName = function(m) {
        c(m) && (this.cbs.onopentagname(this.sectionStart, this.index), this.sectionStart = -1, this.state = r.BeforeAttributeName, this.stateBeforeAttributeName(m));
      }, f.prototype.stateBeforeClosingTagName = function(m) {
        a(m) || (m === n.Gt ? this.state = r.Text : (this.state = this.isTagStartChar(m) ? r.InClosingTagName : r.InSpecialComment, this.sectionStart = this.index));
      }, f.prototype.stateInClosingTagName = function(m) {
        (m === n.Gt || a(m)) && (this.cbs.onclosetag(this.sectionStart, this.index), this.sectionStart = -1, this.state = r.AfterClosingTagName, this.stateAfterClosingTagName(m));
      }, f.prototype.stateAfterClosingTagName = function(m) {
        (m === n.Gt || this.fastForwardTo(n.Gt)) && (this.state = r.Text, this.baseState = r.Text, this.sectionStart = this.index + 1);
      }, f.prototype.stateBeforeAttributeName = function(m) {
        m === n.Gt ? (this.cbs.onopentagend(this.index), this.isSpecial ? (this.state = r.InSpecialTag, this.sequenceIndex = 0) : this.state = r.Text, this.baseState = this.state, this.sectionStart = this.index + 1) : m === n.Slash ? this.state = r.InSelfClosingTag : a(m) || (this.state = r.InAttributeName, this.sectionStart = this.index);
      }, f.prototype.stateInSelfClosingTag = function(m) {
        m === n.Gt ? (this.cbs.onselfclosingtag(this.index), this.state = r.Text, this.baseState = r.Text, this.sectionStart = this.index + 1, this.isSpecial = !1) : a(m) || (this.state = r.BeforeAttributeName, this.stateBeforeAttributeName(m));
      }, f.prototype.stateInAttributeName = function(m) {
        (m === n.Eq || c(m)) && (this.cbs.onattribname(this.sectionStart, this.index), this.sectionStart = -1, this.state = r.AfterAttributeName, this.stateAfterAttributeName(m));
      }, f.prototype.stateAfterAttributeName = function(m) {
        m === n.Eq ? this.state = r.BeforeAttributeValue : m === n.Slash || m === n.Gt ? (this.cbs.onattribend(_.NoValue, this.index), this.state = r.BeforeAttributeName, this.stateBeforeAttributeName(m)) : a(m) || (this.cbs.onattribend(_.NoValue, this.index), this.state = r.InAttributeName, this.sectionStart = this.index);
      }, f.prototype.stateBeforeAttributeValue = function(m) {
        m === n.DoubleQuote ? (this.state = r.InAttributeValueDq, this.sectionStart = this.index + 1) : m === n.SingleQuote ? (this.state = r.InAttributeValueSq, this.sectionStart = this.index + 1) : a(m) || (this.sectionStart = this.index, this.state = r.InAttributeValueNq, this.stateInAttributeValueNoQuotes(m));
      }, f.prototype.handleInAttributeValue = function(m, N) {
        m === N || !this.decodeEntities && this.fastForwardTo(N) ? (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = -1, this.cbs.onattribend(N === n.DoubleQuote ? _.Double : _.Single, this.index), this.state = r.BeforeAttributeName) : this.decodeEntities && m === n.Amp && (this.baseState = this.state, this.state = r.BeforeEntity);
      }, f.prototype.stateInAttributeValueDoubleQuotes = function(m) {
        this.handleInAttributeValue(m, n.DoubleQuote);
      }, f.prototype.stateInAttributeValueSingleQuotes = function(m) {
        this.handleInAttributeValue(m, n.SingleQuote);
      }, f.prototype.stateInAttributeValueNoQuotes = function(m) {
        a(m) || m === n.Gt ? (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = -1, this.cbs.onattribend(_.Unquoted, this.index), this.state = r.BeforeAttributeName, this.stateBeforeAttributeName(m)) : this.decodeEntities && m === n.Amp && (this.baseState = this.state, this.state = r.BeforeEntity);
      }, f.prototype.stateBeforeDeclaration = function(m) {
        m === n.OpeningSquareBracket ? (this.state = r.CDATASequence, this.sequenceIndex = 0) : this.state = m === n.Dash ? r.BeforeComment : r.InDeclaration;
      }, f.prototype.stateInDeclaration = function(m) {
        (m === n.Gt || this.fastForwardTo(n.Gt)) && (this.cbs.ondeclaration(this.sectionStart, this.index), this.state = r.Text, this.sectionStart = this.index + 1);
      }, f.prototype.stateInProcessingInstruction = function(m) {
        (m === n.Gt || this.fastForwardTo(n.Gt)) && (this.cbs.onprocessinginstruction(this.sectionStart, this.index), this.state = r.Text, this.sectionStart = this.index + 1);
      }, f.prototype.stateBeforeComment = function(m) {
        m === n.Dash ? (this.state = r.InCommentLike, this.currentSequence = v.CommentEnd, this.sequenceIndex = 2, this.sectionStart = this.index + 1) : this.state = r.InDeclaration;
      }, f.prototype.stateInSpecialComment = function(m) {
        (m === n.Gt || this.fastForwardTo(n.Gt)) && (this.cbs.oncomment(this.sectionStart, this.index, 0), this.state = r.Text, this.sectionStart = this.index + 1);
      }, f.prototype.stateBeforeSpecialS = function(m) {
        var N = m | 32;
        N === v.ScriptEnd[3] ? this.startSpecial(v.ScriptEnd, 4) : N === v.StyleEnd[3] ? this.startSpecial(v.StyleEnd, 4) : (this.state = r.InTagName, this.stateInTagName(m));
      }, f.prototype.stateBeforeEntity = function(m) {
        this.entityExcess = 1, this.entityResult = 0, m === n.Number ? this.state = r.BeforeNumericEntity : m === n.Amp || (this.trieIndex = 0, this.trieCurrent = this.entityTrie[0], this.state = r.InNamedEntity, this.stateInNamedEntity(m));
      }, f.prototype.stateInNamedEntity = function(m) {
        if (this.entityExcess += 1, this.trieIndex = (0, i.determineBranch)(this.entityTrie, this.trieCurrent, this.trieIndex + 1, m), this.trieIndex < 0) {
          this.emitNamedEntity(), this.index--;
          return;
        }
        this.trieCurrent = this.entityTrie[this.trieIndex];
        var N = this.trieCurrent & i.BinTrieFlags.VALUE_LENGTH;
        if (N) {
          var I = (N >> 14) - 1;
          if (!this.allowLegacyEntity() && m !== n.Semi)
            this.trieIndex += I;
          else {
            var E = this.index - this.entityExcess + 1;
            E > this.sectionStart && this.emitPartial(this.sectionStart, E), this.entityResult = this.trieIndex, this.trieIndex += I, this.entityExcess = 0, this.sectionStart = this.index + 1, I === 0 && this.emitNamedEntity();
          }
        }
      }, f.prototype.emitNamedEntity = function() {
        if (this.state = this.baseState, this.entityResult !== 0) {
          var m = (this.entityTrie[this.entityResult] & i.BinTrieFlags.VALUE_LENGTH) >> 14;
          switch (m) {
            case 1: {
              this.emitCodePoint(this.entityTrie[this.entityResult] & ~i.BinTrieFlags.VALUE_LENGTH);
              break;
            }
            case 2: {
              this.emitCodePoint(this.entityTrie[this.entityResult + 1]);
              break;
            }
            case 3:
              this.emitCodePoint(this.entityTrie[this.entityResult + 1]), this.emitCodePoint(this.entityTrie[this.entityResult + 2]);
          }
        }
      }, f.prototype.stateBeforeNumericEntity = function(m) {
        (m | 32) === n.LowerX ? (this.entityExcess++, this.state = r.InHexEntity) : (this.state = r.InNumericEntity, this.stateInNumericEntity(m));
      }, f.prototype.emitNumericEntity = function(m) {
        var N = this.index - this.entityExcess - 1, I = N + 2 + +(this.state === r.InHexEntity);
        I !== this.index && (N > this.sectionStart && this.emitPartial(this.sectionStart, N), this.sectionStart = this.index + Number(m), this.emitCodePoint((0, i.replaceCodePoint)(this.entityResult))), this.state = this.baseState;
      }, f.prototype.stateInNumericEntity = function(m) {
        m === n.Semi ? this.emitNumericEntity(!0) : p(m) ? (this.entityResult = this.entityResult * 10 + (m - n.Zero), this.entityExcess++) : (this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state = this.baseState, this.index--);
      }, f.prototype.stateInHexEntity = function(m) {
        m === n.Semi ? this.emitNumericEntity(!0) : p(m) ? (this.entityResult = this.entityResult * 16 + (m - n.Zero), this.entityExcess++) : d(m) ? (this.entityResult = this.entityResult * 16 + ((m | 32) - n.LowerA + 10), this.entityExcess++) : (this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state = this.baseState, this.index--);
      }, f.prototype.allowLegacyEntity = function() {
        return !this.xmlMode && (this.baseState === r.Text || this.baseState === r.InSpecialTag);
      }, f.prototype.cleanup = function() {
        this.running && this.sectionStart !== this.index && (this.state === r.Text || this.state === r.InSpecialTag && this.sequenceIndex === 0 ? (this.cbs.ontext(this.sectionStart, this.index), this.sectionStart = this.index) : (this.state === r.InAttributeValueDq || this.state === r.InAttributeValueSq || this.state === r.InAttributeValueNq) && (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = this.index));
      }, f.prototype.shouldContinue = function() {
        return this.index < this.buffer.length + this.offset && this.running;
      }, f.prototype.parse = function() {
        for (; this.shouldContinue(); ) {
          var m = this.buffer.charCodeAt(this.index - this.offset);
          switch (this.state) {
            case r.Text: {
              this.stateText(m);
              break;
            }
            case r.SpecialStartSequence: {
              this.stateSpecialStartSequence(m);
              break;
            }
            case r.InSpecialTag: {
              this.stateInSpecialTag(m);
              break;
            }
            case r.CDATASequence: {
              this.stateCDATASequence(m);
              break;
            }
            case r.InAttributeValueDq: {
              this.stateInAttributeValueDoubleQuotes(m);
              break;
            }
            case r.InAttributeName: {
              this.stateInAttributeName(m);
              break;
            }
            case r.InCommentLike: {
              this.stateInCommentLike(m);
              break;
            }
            case r.InSpecialComment: {
              this.stateInSpecialComment(m);
              break;
            }
            case r.BeforeAttributeName: {
              this.stateBeforeAttributeName(m);
              break;
            }
            case r.InTagName: {
              this.stateInTagName(m);
              break;
            }
            case r.InClosingTagName: {
              this.stateInClosingTagName(m);
              break;
            }
            case r.BeforeTagName: {
              this.stateBeforeTagName(m);
              break;
            }
            case r.AfterAttributeName: {
              this.stateAfterAttributeName(m);
              break;
            }
            case r.InAttributeValueSq: {
              this.stateInAttributeValueSingleQuotes(m);
              break;
            }
            case r.BeforeAttributeValue: {
              this.stateBeforeAttributeValue(m);
              break;
            }
            case r.BeforeClosingTagName: {
              this.stateBeforeClosingTagName(m);
              break;
            }
            case r.AfterClosingTagName: {
              this.stateAfterClosingTagName(m);
              break;
            }
            case r.BeforeSpecialS: {
              this.stateBeforeSpecialS(m);
              break;
            }
            case r.InAttributeValueNq: {
              this.stateInAttributeValueNoQuotes(m);
              break;
            }
            case r.InSelfClosingTag: {
              this.stateInSelfClosingTag(m);
              break;
            }
            case r.InDeclaration: {
              this.stateInDeclaration(m);
              break;
            }
            case r.BeforeDeclaration: {
              this.stateBeforeDeclaration(m);
              break;
            }
            case r.BeforeComment: {
              this.stateBeforeComment(m);
              break;
            }
            case r.InProcessingInstruction: {
              this.stateInProcessingInstruction(m);
              break;
            }
            case r.InNamedEntity: {
              this.stateInNamedEntity(m);
              break;
            }
            case r.BeforeEntity: {
              this.stateBeforeEntity(m);
              break;
            }
            case r.InHexEntity: {
              this.stateInHexEntity(m);
              break;
            }
            case r.InNumericEntity: {
              this.stateInNumericEntity(m);
              break;
            }
            default:
              this.stateBeforeNumericEntity(m);
          }
          this.index++;
        }
        this.cleanup();
      }, f.prototype.finish = function() {
        this.state === r.InNamedEntity && this.emitNamedEntity(), this.sectionStart < this.index && this.handleTrailingData(), this.cbs.onend();
      }, f.prototype.handleTrailingData = function() {
        var m = this.buffer.length + this.offset;
        this.state === r.InCommentLike ? this.currentSequence === v.CdataEnd ? this.cbs.oncdata(this.sectionStart, m, 0) : this.cbs.oncomment(this.sectionStart, m, 0) : this.state === r.InNumericEntity && this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state === r.InHexEntity && this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state === r.InTagName || this.state === r.BeforeAttributeName || this.state === r.BeforeAttributeValue || this.state === r.AfterAttributeName || this.state === r.InAttributeName || this.state === r.InAttributeValueSq || this.state === r.InAttributeValueDq || this.state === r.InAttributeValueNq || this.state === r.InClosingTagName || this.cbs.ontext(this.sectionStart, m);
      }, f.prototype.emitPartial = function(m, N) {
        this.baseState !== r.Text && this.baseState !== r.InSpecialTag ? this.cbs.onattribdata(m, N) : this.cbs.ontext(m, N);
      }, f.prototype.emitCodePoint = function(m) {
        this.baseState !== r.Text && this.baseState !== r.InSpecialTag ? this.cbs.onattribentity(m) : this.cbs.ontextentity(m);
      }, f;
    }()
  );
  o.default = S;
})(Vr);
var va = W && W.__createBinding || (Object.create ? function(o, i, n, r) {
  r === void 0 && (r = n);
  var a = Object.getOwnPropertyDescriptor(i, n);
  (!a || ("get" in a ? !i.__esModule : a.writable || a.configurable)) && (a = { enumerable: !0, get: function() {
    return i[n];
  } }), Object.defineProperty(o, r, a);
} : function(o, i, n, r) {
  r === void 0 && (r = n), o[r] = i[n];
}), xa = W && W.__setModuleDefault || (Object.create ? function(o, i) {
  Object.defineProperty(o, "default", { enumerable: !0, value: i });
} : function(o, i) {
  o.default = i;
}), wa = W && W.__importStar || function(o) {
  if (o && o.__esModule)
    return o;
  var i = {};
  if (o != null)
    for (var n in o)
      n !== "default" && Object.prototype.hasOwnProperty.call(o, n) && va(i, o, n);
  return xa(i, o), i;
};
Object.defineProperty(yi, "__esModule", { value: !0 });
yi.Parser = void 0;
var pn = wa(Vr), Ju = vi, Ft = /* @__PURE__ */ new Set([
  "input",
  "option",
  "optgroup",
  "select",
  "button",
  "datalist",
  "textarea"
]), le = /* @__PURE__ */ new Set(["p"]), Qu = /* @__PURE__ */ new Set(["thead", "tbody"]), eo = /* @__PURE__ */ new Set(["dd", "dt"]), to = /* @__PURE__ */ new Set(["rt", "rp"]), Ta = /* @__PURE__ */ new Map([
  ["tr", /* @__PURE__ */ new Set(["tr", "th", "td"])],
  ["th", /* @__PURE__ */ new Set(["th"])],
  ["td", /* @__PURE__ */ new Set(["thead", "th", "td"])],
  ["body", /* @__PURE__ */ new Set(["head", "link", "script"])],
  ["li", /* @__PURE__ */ new Set(["li"])],
  ["p", le],
  ["h1", le],
  ["h2", le],
  ["h3", le],
  ["h4", le],
  ["h5", le],
  ["h6", le],
  ["select", Ft],
  ["input", Ft],
  ["output", Ft],
  ["button", Ft],
  ["datalist", Ft],
  ["textarea", Ft],
  ["option", /* @__PURE__ */ new Set(["option"])],
  ["optgroup", /* @__PURE__ */ new Set(["optgroup", "option"])],
  ["dd", eo],
  ["dt", eo],
  ["address", le],
  ["article", le],
  ["aside", le],
  ["blockquote", le],
  ["details", le],
  ["div", le],
  ["dl", le],
  ["fieldset", le],
  ["figcaption", le],
  ["figure", le],
  ["footer", le],
  ["form", le],
  ["header", le],
  ["hr", le],
  ["main", le],
  ["nav", le],
  ["ol", le],
  ["pre", le],
  ["section", le],
  ["table", le],
  ["ul", le],
  ["rt", to],
  ["rp", to],
  ["tbody", Qu],
  ["tfoot", Qu]
]), Sa = /* @__PURE__ */ new Set([
  "area",
  "base",
  "basefont",
  "br",
  "col",
  "command",
  "embed",
  "frame",
  "hr",
  "img",
  "input",
  "isindex",
  "keygen",
  "link",
  "meta",
  "param",
  "source",
  "track",
  "wbr"
]), io = /* @__PURE__ */ new Set(["math", "svg"]), no = /* @__PURE__ */ new Set([
  "mi",
  "mo",
  "mn",
  "ms",
  "mtext",
  "annotation-xml",
  "foreignobject",
  "desc",
  "title"
]), La = /\s|\//, Pa = (
  /** @class */
  function() {
    function o(i, n) {
      n === void 0 && (n = {});
      var r, a, c, p, g;
      this.options = n, this.startIndex = 0, this.endIndex = 0, this.openTagStart = 0, this.tagname = "", this.attribname = "", this.attribvalue = "", this.attribs = null, this.stack = [], this.foreignContext = [], this.buffers = [], this.bufferOffset = 0, this.writeIndex = 0, this.ended = !1, this.cbs = i ?? {}, this.lowerCaseTagNames = (r = n.lowerCaseTags) !== null && r !== void 0 ? r : !n.xmlMode, this.lowerCaseAttributeNames = (a = n.lowerCaseAttributeNames) !== null && a !== void 0 ? a : !n.xmlMode, this.tokenizer = new ((c = n.Tokenizer) !== null && c !== void 0 ? c : pn.default)(this.options, this), (g = (p = this.cbs).onparserinit) === null || g === void 0 || g.call(p, this);
    }
    return o.prototype.ontext = function(i, n) {
      var r, a, c = this.getSlice(i, n);
      this.endIndex = n - 1, (a = (r = this.cbs).ontext) === null || a === void 0 || a.call(r, c), this.startIndex = n;
    }, o.prototype.ontextentity = function(i) {
      var n, r, a = this.tokenizer.getSectionStart();
      this.endIndex = a - 1, (r = (n = this.cbs).ontext) === null || r === void 0 || r.call(n, (0, Ju.fromCodePoint)(i)), this.startIndex = a;
    }, o.prototype.isVoidElement = function(i) {
      return !this.options.xmlMode && Sa.has(i);
    }, o.prototype.onopentagname = function(i, n) {
      this.endIndex = n;
      var r = this.getSlice(i, n);
      this.lowerCaseTagNames && (r = r.toLowerCase()), this.emitOpenTag(r);
    }, o.prototype.emitOpenTag = function(i) {
      var n, r, a, c;
      this.openTagStart = this.startIndex, this.tagname = i;
      var p = !this.options.xmlMode && Ta.get(i);
      if (p)
        for (; this.stack.length > 0 && p.has(this.stack[this.stack.length - 1]); ) {
          var g = this.stack.pop();
          (r = (n = this.cbs).onclosetag) === null || r === void 0 || r.call(n, g, !0);
        }
      this.isVoidElement(i) || (this.stack.push(i), io.has(i) ? this.foreignContext.push(!0) : no.has(i) && this.foreignContext.push(!1)), (c = (a = this.cbs).onopentagname) === null || c === void 0 || c.call(a, i), this.cbs.onopentag && (this.attribs = {});
    }, o.prototype.endOpenTag = function(i) {
      var n, r;
      this.startIndex = this.openTagStart, this.attribs && ((r = (n = this.cbs).onopentag) === null || r === void 0 || r.call(n, this.tagname, this.attribs, i), this.attribs = null), this.cbs.onclosetag && this.isVoidElement(this.tagname) && this.cbs.onclosetag(this.tagname, !0), this.tagname = "";
    }, o.prototype.onopentagend = function(i) {
      this.endIndex = i, this.endOpenTag(!1), this.startIndex = i + 1;
    }, o.prototype.onclosetag = function(i, n) {
      var r, a, c, p, g, d;
      this.endIndex = n;
      var _ = this.getSlice(i, n);
      if (this.lowerCaseTagNames && (_ = _.toLowerCase()), (io.has(_) || no.has(_)) && this.foreignContext.pop(), this.isVoidElement(_))
        !this.options.xmlMode && _ === "br" && ((a = (r = this.cbs).onopentagname) === null || a === void 0 || a.call(r, "br"), (p = (c = this.cbs).onopentag) === null || p === void 0 || p.call(c, "br", {}, !0), (d = (g = this.cbs).onclosetag) === null || d === void 0 || d.call(g, "br", !1));
      else {
        var v = this.stack.lastIndexOf(_);
        if (v !== -1)
          if (this.cbs.onclosetag)
            for (var S = this.stack.length - v; S--; )
              this.cbs.onclosetag(this.stack.pop(), S !== 0);
          else
            this.stack.length = v;
        else
          !this.options.xmlMode && _ === "p" && (this.emitOpenTag("p"), this.closeCurrentTag(!0));
      }
      this.startIndex = n + 1;
    }, o.prototype.onselfclosingtag = function(i) {
      this.endIndex = i, this.options.xmlMode || this.options.recognizeSelfClosing || this.foreignContext[this.foreignContext.length - 1] ? (this.closeCurrentTag(!1), this.startIndex = i + 1) : this.onopentagend(i);
    }, o.prototype.closeCurrentTag = function(i) {
      var n, r, a = this.tagname;
      this.endOpenTag(i), this.stack[this.stack.length - 1] === a && ((r = (n = this.cbs).onclosetag) === null || r === void 0 || r.call(n, a, !i), this.stack.pop());
    }, o.prototype.onattribname = function(i, n) {
      this.startIndex = i;
      var r = this.getSlice(i, n);
      this.attribname = this.lowerCaseAttributeNames ? r.toLowerCase() : r;
    }, o.prototype.onattribdata = function(i, n) {
      this.attribvalue += this.getSlice(i, n);
    }, o.prototype.onattribentity = function(i) {
      this.attribvalue += (0, Ju.fromCodePoint)(i);
    }, o.prototype.onattribend = function(i, n) {
      var r, a;
      this.endIndex = n, (a = (r = this.cbs).onattribute) === null || a === void 0 || a.call(r, this.attribname, this.attribvalue, i === pn.QuoteType.Double ? '"' : i === pn.QuoteType.Single ? "'" : i === pn.QuoteType.NoValue ? void 0 : null), this.attribs && !Object.prototype.hasOwnProperty.call(this.attribs, this.attribname) && (this.attribs[this.attribname] = this.attribvalue), this.attribvalue = "";
    }, o.prototype.getInstructionName = function(i) {
      var n = i.search(La), r = n < 0 ? i : i.substr(0, n);
      return this.lowerCaseTagNames && (r = r.toLowerCase()), r;
    }, o.prototype.ondeclaration = function(i, n) {
      this.endIndex = n;
      var r = this.getSlice(i, n);
      if (this.cbs.onprocessinginstruction) {
        var a = this.getInstructionName(r);
        this.cbs.onprocessinginstruction("!".concat(a), "!".concat(r));
      }
      this.startIndex = n + 1;
    }, o.prototype.onprocessinginstruction = function(i, n) {
      this.endIndex = n;
      var r = this.getSlice(i, n);
      if (this.cbs.onprocessinginstruction) {
        var a = this.getInstructionName(r);
        this.cbs.onprocessinginstruction("?".concat(a), "?".concat(r));
      }
      this.startIndex = n + 1;
    }, o.prototype.oncomment = function(i, n, r) {
      var a, c, p, g;
      this.endIndex = n, (c = (a = this.cbs).oncomment) === null || c === void 0 || c.call(a, this.getSlice(i, n - r)), (g = (p = this.cbs).oncommentend) === null || g === void 0 || g.call(p), this.startIndex = n + 1;
    }, o.prototype.oncdata = function(i, n, r) {
      var a, c, p, g, d, _, v, S, f, m;
      this.endIndex = n;
      var N = this.getSlice(i, n - r);
      this.options.xmlMode || this.options.recognizeCDATA ? ((c = (a = this.cbs).oncdatastart) === null || c === void 0 || c.call(a), (g = (p = this.cbs).ontext) === null || g === void 0 || g.call(p, N), (_ = (d = this.cbs).oncdataend) === null || _ === void 0 || _.call(d)) : ((S = (v = this.cbs).oncomment) === null || S === void 0 || S.call(v, "[CDATA[".concat(N, "]]")), (m = (f = this.cbs).oncommentend) === null || m === void 0 || m.call(f)), this.startIndex = n + 1;
    }, o.prototype.onend = function() {
      var i, n;
      if (this.cbs.onclosetag) {
        this.endIndex = this.startIndex;
        for (var r = this.stack.length; r > 0; this.cbs.onclosetag(this.stack[--r], !0))
          ;
      }
      (n = (i = this.cbs).onend) === null || n === void 0 || n.call(i);
    }, o.prototype.reset = function() {
      var i, n, r, a;
      (n = (i = this.cbs).onreset) === null || n === void 0 || n.call(i), this.tokenizer.reset(), this.tagname = "", this.attribname = "", this.attribs = null, this.stack.length = 0, this.startIndex = 0, this.endIndex = 0, (a = (r = this.cbs).onparserinit) === null || a === void 0 || a.call(r, this), this.buffers.length = 0, this.bufferOffset = 0, this.writeIndex = 0, this.ended = !1;
    }, o.prototype.parseComplete = function(i) {
      this.reset(), this.end(i);
    }, o.prototype.getSlice = function(i, n) {
      for (; i - this.bufferOffset >= this.buffers[0].length; )
        this.shiftBuffer();
      for (var r = this.buffers[0].slice(i - this.bufferOffset, n - this.bufferOffset); n - this.bufferOffset > this.buffers[0].length; )
        this.shiftBuffer(), r += this.buffers[0].slice(0, n - this.bufferOffset);
      return r;
    }, o.prototype.shiftBuffer = function() {
      this.bufferOffset += this.buffers[0].length, this.writeIndex--, this.buffers.shift();
    }, o.prototype.write = function(i) {
      var n, r;
      if (this.ended) {
        (r = (n = this.cbs).onerror) === null || r === void 0 || r.call(n, new Error(".write() after done!"));
        return;
      }
      this.buffers.push(i), this.tokenizer.running && (this.tokenizer.write(i), this.writeIndex++);
    }, o.prototype.end = function(i) {
      var n, r;
      if (this.ended) {
        (r = (n = this.cbs).onerror) === null || r === void 0 || r.call(n, new Error(".end() after done!"));
        return;
      }
      i && this.write(i), this.ended = !0, this.tokenizer.end();
    }, o.prototype.pause = function() {
      this.tokenizer.pause();
    }, o.prototype.resume = function() {
      for (this.tokenizer.resume(); this.tokenizer.running && this.writeIndex < this.buffers.length; )
        this.tokenizer.write(this.buffers[this.writeIndex++]);
      this.ended && this.tokenizer.end();
    }, o.prototype.parseChunk = function(i) {
      this.write(i);
    }, o.prototype.done = function(i) {
      this.end(i);
    }, o;
  }()
);
yi.Parser = Pa;
var nt = {}, Yt = {};
(function(o) {
  Object.defineProperty(o, "__esModule", { value: !0 }), o.Doctype = o.CDATA = o.Tag = o.Style = o.Script = o.Comment = o.Directive = o.Text = o.Root = o.isTag = o.ElementType = void 0;
  var i;
  (function(r) {
    r.Root = "root", r.Text = "text", r.Directive = "directive", r.Comment = "comment", r.Script = "script", r.Style = "style", r.Tag = "tag", r.CDATA = "cdata", r.Doctype = "doctype";
  })(i = o.ElementType || (o.ElementType = {}));
  function n(r) {
    return r.type === i.Tag || r.type === i.Script || r.type === i.Style;
  }
  o.isTag = n, o.Root = i.Root, o.Text = i.Text, o.Directive = i.Directive, o.Comment = i.Comment, o.Script = i.Script, o.Style = i.Style, o.Tag = i.Tag, o.CDATA = i.CDATA, o.Doctype = i.Doctype;
})(Yt);
var ne = {}, dt = W && W.__extends || function() {
  var o = function(i, n) {
    return o = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(r, a) {
      r.__proto__ = a;
    } || function(r, a) {
      for (var c in a)
        Object.prototype.hasOwnProperty.call(a, c) && (r[c] = a[c]);
    }, o(i, n);
  };
  return function(i, n) {
    if (typeof n != "function" && n !== null)
      throw new TypeError("Class extends value " + String(n) + " is not a constructor or null");
    o(i, n);
    function r() {
      this.constructor = i;
    }
    i.prototype = n === null ? Object.create(n) : (r.prototype = n.prototype, new r());
  };
}(), bi = W && W.__assign || function() {
  return bi = Object.assign || function(o) {
    for (var i, n = 1, r = arguments.length; n < r; n++) {
      i = arguments[n];
      for (var a in i)
        Object.prototype.hasOwnProperty.call(i, a) && (o[a] = i[a]);
    }
    return o;
  }, bi.apply(this, arguments);
};
Object.defineProperty(ne, "__esModule", { value: !0 });
ne.cloneNode = ne.hasChildren = ne.isDocument = ne.isDirective = ne.isComment = ne.isText = ne.isCDATA = ne.isTag = ne.Element = ne.Document = ne.CDATA = ne.NodeWithChildren = ne.ProcessingInstruction = ne.Comment = ne.Text = ne.DataNode = ne.Node = void 0;
var Oe = Yt, $r = (
  /** @class */
  function() {
    function o() {
      this.parent = null, this.prev = null, this.next = null, this.startIndex = null, this.endIndex = null;
    }
    return Object.defineProperty(o.prototype, "parentNode", {
      // Read-write aliases for properties
      /**
       * Same as {@link parent}.
       * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
       */
      get: function() {
        return this.parent;
      },
      set: function(i) {
        this.parent = i;
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(o.prototype, "previousSibling", {
      /**
       * Same as {@link prev}.
       * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
       */
      get: function() {
        return this.prev;
      },
      set: function(i) {
        this.prev = i;
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(o.prototype, "nextSibling", {
      /**
       * Same as {@link next}.
       * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
       */
      get: function() {
        return this.next;
      },
      set: function(i) {
        this.next = i;
      },
      enumerable: !1,
      configurable: !0
    }), o.prototype.cloneNode = function(i) {
      return i === void 0 && (i = !1), Xr(this, i);
    }, o;
  }()
);
ne.Node = $r;
var jn = (
  /** @class */
  function(o) {
    dt(i, o);
    function i(n) {
      var r = o.call(this) || this;
      return r.data = n, r;
    }
    return Object.defineProperty(i.prototype, "nodeValue", {
      /**
       * Same as {@link data}.
       * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
       */
      get: function() {
        return this.data;
      },
      set: function(n) {
        this.data = n;
      },
      enumerable: !1,
      configurable: !0
    }), i;
  }($r)
);
ne.DataNode = jn;
var Ro = (
  /** @class */
  function(o) {
    dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.type = Oe.ElementType.Text, n;
    }
    return Object.defineProperty(i.prototype, "nodeType", {
      get: function() {
        return 3;
      },
      enumerable: !1,
      configurable: !0
    }), i;
  }(jn)
);
ne.Text = Ro;
var jo = (
  /** @class */
  function(o) {
    dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.type = Oe.ElementType.Comment, n;
    }
    return Object.defineProperty(i.prototype, "nodeType", {
      get: function() {
        return 8;
      },
      enumerable: !1,
      configurable: !0
    }), i;
  }(jn)
);
ne.Comment = jo;
var qo = (
  /** @class */
  function(o) {
    dt(i, o);
    function i(n, r) {
      var a = o.call(this, r) || this;
      return a.name = n, a.type = Oe.ElementType.Directive, a;
    }
    return Object.defineProperty(i.prototype, "nodeType", {
      get: function() {
        return 1;
      },
      enumerable: !1,
      configurable: !0
    }), i;
  }(jn)
);
ne.ProcessingInstruction = qo;
var qn = (
  /** @class */
  function(o) {
    dt(i, o);
    function i(n) {
      var r = o.call(this) || this;
      return r.children = n, r;
    }
    return Object.defineProperty(i.prototype, "firstChild", {
      // Aliases
      /** First child of the node. */
      get: function() {
        var n;
        return (n = this.children[0]) !== null && n !== void 0 ? n : null;
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(i.prototype, "lastChild", {
      /** Last child of the node. */
      get: function() {
        return this.children.length > 0 ? this.children[this.children.length - 1] : null;
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(i.prototype, "childNodes", {
      /**
       * Same as {@link children}.
       * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
       */
      get: function() {
        return this.children;
      },
      set: function(n) {
        this.children = n;
      },
      enumerable: !1,
      configurable: !0
    }), i;
  }($r)
);
ne.NodeWithChildren = qn;
var Zo = (
  /** @class */
  function(o) {
    dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.type = Oe.ElementType.CDATA, n;
    }
    return Object.defineProperty(i.prototype, "nodeType", {
      get: function() {
        return 4;
      },
      enumerable: !1,
      configurable: !0
    }), i;
  }(qn)
);
ne.CDATA = Zo;
var Fo = (
  /** @class */
  function(o) {
    dt(i, o);
    function i() {
      var n = o !== null && o.apply(this, arguments) || this;
      return n.type = Oe.ElementType.Root, n;
    }
    return Object.defineProperty(i.prototype, "nodeType", {
      get: function() {
        return 9;
      },
      enumerable: !1,
      configurable: !0
    }), i;
  }(qn)
);
ne.Document = Fo;
var Ho = (
  /** @class */
  function(o) {
    dt(i, o);
    function i(n, r, a, c) {
      a === void 0 && (a = []), c === void 0 && (c = n === "script" ? Oe.ElementType.Script : n === "style" ? Oe.ElementType.Style : Oe.ElementType.Tag);
      var p = o.call(this, a) || this;
      return p.name = n, p.attribs = r, p.type = c, p;
    }
    return Object.defineProperty(i.prototype, "nodeType", {
      get: function() {
        return 1;
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(i.prototype, "tagName", {
      // DOM Level 1 aliases
      /**
       * Same as {@link name}.
       * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
       */
      get: function() {
        return this.name;
      },
      set: function(n) {
        this.name = n;
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(i.prototype, "attributes", {
      get: function() {
        var n = this;
        return Object.keys(this.attribs).map(function(r) {
          var a, c;
          return {
            name: r,
            value: n.attribs[r],
            namespace: (a = n["x-attribsNamespace"]) === null || a === void 0 ? void 0 : a[r],
            prefix: (c = n["x-attribsPrefix"]) === null || c === void 0 ? void 0 : c[r]
          };
        });
      },
      enumerable: !1,
      configurable: !0
    }), i;
  }(qn)
);
ne.Element = Ho;
function Uo(o) {
  return (0, Oe.isTag)(o);
}
ne.isTag = Uo;
function Vo(o) {
  return o.type === Oe.ElementType.CDATA;
}
ne.isCDATA = Vo;
function Wo(o) {
  return o.type === Oe.ElementType.Text;
}
ne.isText = Wo;
function Go(o) {
  return o.type === Oe.ElementType.Comment;
}
ne.isComment = Go;
function $o(o) {
  return o.type === Oe.ElementType.Directive;
}
ne.isDirective = $o;
function Xo(o) {
  return o.type === Oe.ElementType.Root;
}
ne.isDocument = Xo;
function Ea(o) {
  return Object.prototype.hasOwnProperty.call(o, "children");
}
ne.hasChildren = Ea;
function Xr(o, i) {
  i === void 0 && (i = !1);
  var n;
  if (Wo(o))
    n = new Ro(o.data);
  else if (Go(o))
    n = new jo(o.data);
  else if (Uo(o)) {
    var r = i ? yr(o.children) : [], a = new Ho(o.name, bi({}, o.attribs), r);
    r.forEach(function(d) {
      return d.parent = a;
    }), o.namespace != null && (a.namespace = o.namespace), o["x-attribsNamespace"] && (a["x-attribsNamespace"] = bi({}, o["x-attribsNamespace"])), o["x-attribsPrefix"] && (a["x-attribsPrefix"] = bi({}, o["x-attribsPrefix"])), n = a;
  } else if (Vo(o)) {
    var r = i ? yr(o.children) : [], c = new Zo(r);
    r.forEach(function(_) {
      return _.parent = c;
    }), n = c;
  } else if (Xo(o)) {
    var r = i ? yr(o.children) : [], p = new Fo(r);
    r.forEach(function(_) {
      return _.parent = p;
    }), o["x-mode"] && (p["x-mode"] = o["x-mode"]), n = p;
  } else if ($o(o)) {
    var g = new qo(o.name, o.data);
    o["x-name"] != null && (g["x-name"] = o["x-name"], g["x-publicId"] = o["x-publicId"], g["x-systemId"] = o["x-systemId"]), n = g;
  } else
    throw new Error("Not implemented yet: ".concat(o.type));
  return n.startIndex = o.startIndex, n.endIndex = o.endIndex, o.sourceCodeLocation != null && (n.sourceCodeLocation = o.sourceCodeLocation), n;
}
ne.cloneNode = Xr;
function yr(o) {
  for (var i = o.map(function(r) {
    return Xr(r, !0);
  }), n = 1; n < i.length; n++)
    i[n].prev = i[n - 1], i[n - 1].next = i[n];
  return i;
}
(function(o) {
  var i = W && W.__createBinding || (Object.create ? function(g, d, _, v) {
    v === void 0 && (v = _);
    var S = Object.getOwnPropertyDescriptor(d, _);
    (!S || ("get" in S ? !d.__esModule : S.writable || S.configurable)) && (S = { enumerable: !0, get: function() {
      return d[_];
    } }), Object.defineProperty(g, v, S);
  } : function(g, d, _, v) {
    v === void 0 && (v = _), g[v] = d[_];
  }), n = W && W.__exportStar || function(g, d) {
    for (var _ in g)
      _ !== "default" && !Object.prototype.hasOwnProperty.call(d, _) && i(d, g, _);
  };
  Object.defineProperty(o, "__esModule", { value: !0 }), o.DomHandler = void 0;
  var r = Yt, a = ne;
  n(ne, o);
  var c = {
    withStartIndices: !1,
    withEndIndices: !1,
    xmlMode: !1
  }, p = (
    /** @class */
    function() {
      function g(d, _, v) {
        this.dom = [], this.root = new a.Document(this.dom), this.done = !1, this.tagStack = [this.root], this.lastNode = null, this.parser = null, typeof _ == "function" && (v = _, _ = c), typeof d == "object" && (_ = d, d = void 0), this.callback = d ?? null, this.options = _ ?? c, this.elementCB = v ?? null;
      }
      return g.prototype.onparserinit = function(d) {
        this.parser = d;
      }, g.prototype.onreset = function() {
        this.dom = [], this.root = new a.Document(this.dom), this.done = !1, this.tagStack = [this.root], this.lastNode = null, this.parser = null;
      }, g.prototype.onend = function() {
        this.done || (this.done = !0, this.parser = null, this.handleCallback(null));
      }, g.prototype.onerror = function(d) {
        this.handleCallback(d);
      }, g.prototype.onclosetag = function() {
        this.lastNode = null;
        var d = this.tagStack.pop();
        this.options.withEndIndices && (d.endIndex = this.parser.endIndex), this.elementCB && this.elementCB(d);
      }, g.prototype.onopentag = function(d, _) {
        var v = this.options.xmlMode ? r.ElementType.Tag : void 0, S = new a.Element(d, _, void 0, v);
        this.addNode(S), this.tagStack.push(S);
      }, g.prototype.ontext = function(d) {
        var _ = this.lastNode;
        if (_ && _.type === r.ElementType.Text)
          _.data += d, this.options.withEndIndices && (_.endIndex = this.parser.endIndex);
        else {
          var v = new a.Text(d);
          this.addNode(v), this.lastNode = v;
        }
      }, g.prototype.oncomment = function(d) {
        if (this.lastNode && this.lastNode.type === r.ElementType.Comment) {
          this.lastNode.data += d;
          return;
        }
        var _ = new a.Comment(d);
        this.addNode(_), this.lastNode = _;
      }, g.prototype.oncommentend = function() {
        this.lastNode = null;
      }, g.prototype.oncdatastart = function() {
        var d = new a.Text(""), _ = new a.CDATA([d]);
        this.addNode(_), d.parent = _, this.lastNode = d;
      }, g.prototype.oncdataend = function() {
        this.lastNode = null;
      }, g.prototype.onprocessinginstruction = function(d, _) {
        var v = new a.ProcessingInstruction(d, _);
        this.addNode(v);
      }, g.prototype.handleCallback = function(d) {
        if (typeof this.callback == "function")
          this.callback(d, this.dom);
        else if (d)
          throw d;
      }, g.prototype.addNode = function(d) {
        var _ = this.tagStack[this.tagStack.length - 1], v = _.children[_.children.length - 1];
        this.options.withStartIndices && (d.startIndex = this.parser.startIndex), this.options.withEndIndices && (d.endIndex = this.parser.endIndex), _.children.push(d), v && (d.prev = v, v.next = d), d.parent = _, this.lastNode = null;
      }, g;
    }()
  );
  o.DomHandler = p, o.default = p;
})(nt);
var Ln = {}, ft = {}, Ci = {}, Yo = {}, St = {}, Yr = {};
Object.defineProperty(Yr, "__esModule", { value: !0 });
function mn(o) {
  for (var i = 1; i < o.length; i++)
    o[i][0] += o[i - 1][0] + 1;
  return o;
}
Yr.default = new Map(/* @__PURE__ */ mn([[9, "&Tab;"], [0, "&NewLine;"], [22, "&excl;"], [0, "&quot;"], [0, "&num;"], [0, "&dollar;"], [0, "&percnt;"], [0, "&amp;"], [0, "&apos;"], [0, "&lpar;"], [0, "&rpar;"], [0, "&ast;"], [0, "&plus;"], [0, "&comma;"], [1, "&period;"], [0, "&sol;"], [10, "&colon;"], [0, "&semi;"], [0, { v: "&lt;", n: 8402, o: "&nvlt;" }], [0, { v: "&equals;", n: 8421, o: "&bne;" }], [0, { v: "&gt;", n: 8402, o: "&nvgt;" }], [0, "&quest;"], [0, "&commat;"], [26, "&lbrack;"], [0, "&bsol;"], [0, "&rbrack;"], [0, "&Hat;"], [0, "&lowbar;"], [0, "&DiacriticalGrave;"], [5, { n: 106, o: "&fjlig;" }], [20, "&lbrace;"], [0, "&verbar;"], [0, "&rbrace;"], [34, "&nbsp;"], [0, "&iexcl;"], [0, "&cent;"], [0, "&pound;"], [0, "&curren;"], [0, "&yen;"], [0, "&brvbar;"], [0, "&sect;"], [0, "&die;"], [0, "&copy;"], [0, "&ordf;"], [0, "&laquo;"], [0, "&not;"], [0, "&shy;"], [0, "&circledR;"], [0, "&macr;"], [0, "&deg;"], [0, "&PlusMinus;"], [0, "&sup2;"], [0, "&sup3;"], [0, "&acute;"], [0, "&micro;"], [0, "&para;"], [0, "&centerdot;"], [0, "&cedil;"], [0, "&sup1;"], [0, "&ordm;"], [0, "&raquo;"], [0, "&frac14;"], [0, "&frac12;"], [0, "&frac34;"], [0, "&iquest;"], [0, "&Agrave;"], [0, "&Aacute;"], [0, "&Acirc;"], [0, "&Atilde;"], [0, "&Auml;"], [0, "&angst;"], [0, "&AElig;"], [0, "&Ccedil;"], [0, "&Egrave;"], [0, "&Eacute;"], [0, "&Ecirc;"], [0, "&Euml;"], [0, "&Igrave;"], [0, "&Iacute;"], [0, "&Icirc;"], [0, "&Iuml;"], [0, "&ETH;"], [0, "&Ntilde;"], [0, "&Ograve;"], [0, "&Oacute;"], [0, "&Ocirc;"], [0, "&Otilde;"], [0, "&Ouml;"], [0, "&times;"], [0, "&Oslash;"], [0, "&Ugrave;"], [0, "&Uacute;"], [0, "&Ucirc;"], [0, "&Uuml;"], [0, "&Yacute;"], [0, "&THORN;"], [0, "&szlig;"], [0, "&agrave;"], [0, "&aacute;"], [0, "&acirc;"], [0, "&atilde;"], [0, "&auml;"], [0, "&aring;"], [0, "&aelig;"], [0, "&ccedil;"], [0, "&egrave;"], [0, "&eacute;"], [0, "&ecirc;"], [0, "&euml;"], [0, "&igrave;"], [0, "&iacute;"], [0, "&icirc;"], [0, "&iuml;"], [0, "&eth;"], [0, "&ntilde;"], [0, "&ograve;"], [0, "&oacute;"], [0, "&ocirc;"], [0, "&otilde;"], [0, "&ouml;"], [0, "&div;"], [0, "&oslash;"], [0, "&ugrave;"], [0, "&uacute;"], [0, "&ucirc;"], [0, "&uuml;"], [0, "&yacute;"], [0, "&thorn;"], [0, "&yuml;"], [0, "&Amacr;"], [0, "&amacr;"], [0, "&Abreve;"], [0, "&abreve;"], [0, "&Aogon;"], [0, "&aogon;"], [0, "&Cacute;"], [0, "&cacute;"], [0, "&Ccirc;"], [0, "&ccirc;"], [0, "&Cdot;"], [0, "&cdot;"], [0, "&Ccaron;"], [0, "&ccaron;"], [0, "&Dcaron;"], [0, "&dcaron;"], [0, "&Dstrok;"], [0, "&dstrok;"], [0, "&Emacr;"], [0, "&emacr;"], [2, "&Edot;"], [0, "&edot;"], [0, "&Eogon;"], [0, "&eogon;"], [0, "&Ecaron;"], [0, "&ecaron;"], [0, "&Gcirc;"], [0, "&gcirc;"], [0, "&Gbreve;"], [0, "&gbreve;"], [0, "&Gdot;"], [0, "&gdot;"], [0, "&Gcedil;"], [1, "&Hcirc;"], [0, "&hcirc;"], [0, "&Hstrok;"], [0, "&hstrok;"], [0, "&Itilde;"], [0, "&itilde;"], [0, "&Imacr;"], [0, "&imacr;"], [2, "&Iogon;"], [0, "&iogon;"], [0, "&Idot;"], [0, "&imath;"], [0, "&IJlig;"], [0, "&ijlig;"], [0, "&Jcirc;"], [0, "&jcirc;"], [0, "&Kcedil;"], [0, "&kcedil;"], [0, "&kgreen;"], [0, "&Lacute;"], [0, "&lacute;"], [0, "&Lcedil;"], [0, "&lcedil;"], [0, "&Lcaron;"], [0, "&lcaron;"], [0, "&Lmidot;"], [0, "&lmidot;"], [0, "&Lstrok;"], [0, "&lstrok;"], [0, "&Nacute;"], [0, "&nacute;"], [0, "&Ncedil;"], [0, "&ncedil;"], [0, "&Ncaron;"], [0, "&ncaron;"], [0, "&napos;"], [0, "&ENG;"], [0, "&eng;"], [0, "&Omacr;"], [0, "&omacr;"], [2, "&Odblac;"], [0, "&odblac;"], [0, "&OElig;"], [0, "&oelig;"], [0, "&Racute;"], [0, "&racute;"], [0, "&Rcedil;"], [0, "&rcedil;"], [0, "&Rcaron;"], [0, "&rcaron;"], [0, "&Sacute;"], [0, "&sacute;"], [0, "&Scirc;"], [0, "&scirc;"], [0, "&Scedil;"], [0, "&scedil;"], [0, "&Scaron;"], [0, "&scaron;"], [0, "&Tcedil;"], [0, "&tcedil;"], [0, "&Tcaron;"], [0, "&tcaron;"], [0, "&Tstrok;"], [0, "&tstrok;"], [0, "&Utilde;"], [0, "&utilde;"], [0, "&Umacr;"], [0, "&umacr;"], [0, "&Ubreve;"], [0, "&ubreve;"], [0, "&Uring;"], [0, "&uring;"], [0, "&Udblac;"], [0, "&udblac;"], [0, "&Uogon;"], [0, "&uogon;"], [0, "&Wcirc;"], [0, "&wcirc;"], [0, "&Ycirc;"], [0, "&ycirc;"], [0, "&Yuml;"], [0, "&Zacute;"], [0, "&zacute;"], [0, "&Zdot;"], [0, "&zdot;"], [0, "&Zcaron;"], [0, "&zcaron;"], [19, "&fnof;"], [34, "&imped;"], [63, "&gacute;"], [65, "&jmath;"], [142, "&circ;"], [0, "&caron;"], [16, "&breve;"], [0, "&DiacriticalDot;"], [0, "&ring;"], [0, "&ogon;"], [0, "&DiacriticalTilde;"], [0, "&dblac;"], [51, "&DownBreve;"], [127, "&Alpha;"], [0, "&Beta;"], [0, "&Gamma;"], [0, "&Delta;"], [0, "&Epsilon;"], [0, "&Zeta;"], [0, "&Eta;"], [0, "&Theta;"], [0, "&Iota;"], [0, "&Kappa;"], [0, "&Lambda;"], [0, "&Mu;"], [0, "&Nu;"], [0, "&Xi;"], [0, "&Omicron;"], [0, "&Pi;"], [0, "&Rho;"], [1, "&Sigma;"], [0, "&Tau;"], [0, "&Upsilon;"], [0, "&Phi;"], [0, "&Chi;"], [0, "&Psi;"], [0, "&ohm;"], [7, "&alpha;"], [0, "&beta;"], [0, "&gamma;"], [0, "&delta;"], [0, "&epsi;"], [0, "&zeta;"], [0, "&eta;"], [0, "&theta;"], [0, "&iota;"], [0, "&kappa;"], [0, "&lambda;"], [0, "&mu;"], [0, "&nu;"], [0, "&xi;"], [0, "&omicron;"], [0, "&pi;"], [0, "&rho;"], [0, "&sigmaf;"], [0, "&sigma;"], [0, "&tau;"], [0, "&upsi;"], [0, "&phi;"], [0, "&chi;"], [0, "&psi;"], [0, "&omega;"], [7, "&thetasym;"], [0, "&Upsi;"], [2, "&phiv;"], [0, "&piv;"], [5, "&Gammad;"], [0, "&digamma;"], [18, "&kappav;"], [0, "&rhov;"], [3, "&epsiv;"], [0, "&backepsilon;"], [10, "&IOcy;"], [0, "&DJcy;"], [0, "&GJcy;"], [0, "&Jukcy;"], [0, "&DScy;"], [0, "&Iukcy;"], [0, "&YIcy;"], [0, "&Jsercy;"], [0, "&LJcy;"], [0, "&NJcy;"], [0, "&TSHcy;"], [0, "&KJcy;"], [1, "&Ubrcy;"], [0, "&DZcy;"], [0, "&Acy;"], [0, "&Bcy;"], [0, "&Vcy;"], [0, "&Gcy;"], [0, "&Dcy;"], [0, "&IEcy;"], [0, "&ZHcy;"], [0, "&Zcy;"], [0, "&Icy;"], [0, "&Jcy;"], [0, "&Kcy;"], [0, "&Lcy;"], [0, "&Mcy;"], [0, "&Ncy;"], [0, "&Ocy;"], [0, "&Pcy;"], [0, "&Rcy;"], [0, "&Scy;"], [0, "&Tcy;"], [0, "&Ucy;"], [0, "&Fcy;"], [0, "&KHcy;"], [0, "&TScy;"], [0, "&CHcy;"], [0, "&SHcy;"], [0, "&SHCHcy;"], [0, "&HARDcy;"], [0, "&Ycy;"], [0, "&SOFTcy;"], [0, "&Ecy;"], [0, "&YUcy;"], [0, "&YAcy;"], [0, "&acy;"], [0, "&bcy;"], [0, "&vcy;"], [0, "&gcy;"], [0, "&dcy;"], [0, "&iecy;"], [0, "&zhcy;"], [0, "&zcy;"], [0, "&icy;"], [0, "&jcy;"], [0, "&kcy;"], [0, "&lcy;"], [0, "&mcy;"], [0, "&ncy;"], [0, "&ocy;"], [0, "&pcy;"], [0, "&rcy;"], [0, "&scy;"], [0, "&tcy;"], [0, "&ucy;"], [0, "&fcy;"], [0, "&khcy;"], [0, "&tscy;"], [0, "&chcy;"], [0, "&shcy;"], [0, "&shchcy;"], [0, "&hardcy;"], [0, "&ycy;"], [0, "&softcy;"], [0, "&ecy;"], [0, "&yucy;"], [0, "&yacy;"], [1, "&iocy;"], [0, "&djcy;"], [0, "&gjcy;"], [0, "&jukcy;"], [0, "&dscy;"], [0, "&iukcy;"], [0, "&yicy;"], [0, "&jsercy;"], [0, "&ljcy;"], [0, "&njcy;"], [0, "&tshcy;"], [0, "&kjcy;"], [1, "&ubrcy;"], [0, "&dzcy;"], [7074, "&ensp;"], [0, "&emsp;"], [0, "&emsp13;"], [0, "&emsp14;"], [1, "&numsp;"], [0, "&puncsp;"], [0, "&ThinSpace;"], [0, "&hairsp;"], [0, "&NegativeMediumSpace;"], [0, "&zwnj;"], [0, "&zwj;"], [0, "&lrm;"], [0, "&rlm;"], [0, "&dash;"], [2, "&ndash;"], [0, "&mdash;"], [0, "&horbar;"], [0, "&Verbar;"], [1, "&lsquo;"], [0, "&CloseCurlyQuote;"], [0, "&lsquor;"], [1, "&ldquo;"], [0, "&CloseCurlyDoubleQuote;"], [0, "&bdquo;"], [1, "&dagger;"], [0, "&Dagger;"], [0, "&bull;"], [2, "&nldr;"], [0, "&hellip;"], [9, "&permil;"], [0, "&pertenk;"], [0, "&prime;"], [0, "&Prime;"], [0, "&tprime;"], [0, "&backprime;"], [3, "&lsaquo;"], [0, "&rsaquo;"], [3, "&oline;"], [2, "&caret;"], [1, "&hybull;"], [0, "&frasl;"], [10, "&bsemi;"], [7, "&qprime;"], [7, { v: "&MediumSpace;", n: 8202, o: "&ThickSpace;" }], [0, "&NoBreak;"], [0, "&af;"], [0, "&InvisibleTimes;"], [0, "&ic;"], [72, "&euro;"], [46, "&tdot;"], [0, "&DotDot;"], [37, "&complexes;"], [2, "&incare;"], [4, "&gscr;"], [0, "&hamilt;"], [0, "&Hfr;"], [0, "&Hopf;"], [0, "&planckh;"], [0, "&hbar;"], [0, "&imagline;"], [0, "&Ifr;"], [0, "&lagran;"], [0, "&ell;"], [1, "&naturals;"], [0, "&numero;"], [0, "&copysr;"], [0, "&weierp;"], [0, "&Popf;"], [0, "&Qopf;"], [0, "&realine;"], [0, "&real;"], [0, "&reals;"], [0, "&rx;"], [3, "&trade;"], [1, "&integers;"], [2, "&mho;"], [0, "&zeetrf;"], [0, "&iiota;"], [2, "&bernou;"], [0, "&Cayleys;"], [1, "&escr;"], [0, "&Escr;"], [0, "&Fouriertrf;"], [1, "&Mellintrf;"], [0, "&order;"], [0, "&alefsym;"], [0, "&beth;"], [0, "&gimel;"], [0, "&daleth;"], [12, "&CapitalDifferentialD;"], [0, "&dd;"], [0, "&ee;"], [0, "&ii;"], [10, "&frac13;"], [0, "&frac23;"], [0, "&frac15;"], [0, "&frac25;"], [0, "&frac35;"], [0, "&frac45;"], [0, "&frac16;"], [0, "&frac56;"], [0, "&frac18;"], [0, "&frac38;"], [0, "&frac58;"], [0, "&frac78;"], [49, "&larr;"], [0, "&ShortUpArrow;"], [0, "&rarr;"], [0, "&darr;"], [0, "&harr;"], [0, "&updownarrow;"], [0, "&nwarr;"], [0, "&nearr;"], [0, "&LowerRightArrow;"], [0, "&LowerLeftArrow;"], [0, "&nlarr;"], [0, "&nrarr;"], [1, { v: "&rarrw;", n: 824, o: "&nrarrw;" }], [0, "&Larr;"], [0, "&Uarr;"], [0, "&Rarr;"], [0, "&Darr;"], [0, "&larrtl;"], [0, "&rarrtl;"], [0, "&LeftTeeArrow;"], [0, "&mapstoup;"], [0, "&map;"], [0, "&DownTeeArrow;"], [1, "&hookleftarrow;"], [0, "&hookrightarrow;"], [0, "&larrlp;"], [0, "&looparrowright;"], [0, "&harrw;"], [0, "&nharr;"], [1, "&lsh;"], [0, "&rsh;"], [0, "&ldsh;"], [0, "&rdsh;"], [1, "&crarr;"], [0, "&cularr;"], [0, "&curarr;"], [2, "&circlearrowleft;"], [0, "&circlearrowright;"], [0, "&leftharpoonup;"], [0, "&DownLeftVector;"], [0, "&RightUpVector;"], [0, "&LeftUpVector;"], [0, "&rharu;"], [0, "&DownRightVector;"], [0, "&dharr;"], [0, "&dharl;"], [0, "&RightArrowLeftArrow;"], [0, "&udarr;"], [0, "&LeftArrowRightArrow;"], [0, "&leftleftarrows;"], [0, "&upuparrows;"], [0, "&rightrightarrows;"], [0, "&ddarr;"], [0, "&leftrightharpoons;"], [0, "&Equilibrium;"], [0, "&nlArr;"], [0, "&nhArr;"], [0, "&nrArr;"], [0, "&DoubleLeftArrow;"], [0, "&DoubleUpArrow;"], [0, "&DoubleRightArrow;"], [0, "&dArr;"], [0, "&DoubleLeftRightArrow;"], [0, "&DoubleUpDownArrow;"], [0, "&nwArr;"], [0, "&neArr;"], [0, "&seArr;"], [0, "&swArr;"], [0, "&lAarr;"], [0, "&rAarr;"], [1, "&zigrarr;"], [6, "&larrb;"], [0, "&rarrb;"], [15, "&DownArrowUpArrow;"], [7, "&loarr;"], [0, "&roarr;"], [0, "&hoarr;"], [0, "&forall;"], [0, "&comp;"], [0, { v: "&part;", n: 824, o: "&npart;" }], [0, "&exist;"], [0, "&nexist;"], [0, "&empty;"], [1, "&Del;"], [0, "&Element;"], [0, "&NotElement;"], [1, "&ni;"], [0, "&notni;"], [2, "&prod;"], [0, "&coprod;"], [0, "&sum;"], [0, "&minus;"], [0, "&MinusPlus;"], [0, "&dotplus;"], [1, "&Backslash;"], [0, "&lowast;"], [0, "&compfn;"], [1, "&radic;"], [2, "&prop;"], [0, "&infin;"], [0, "&angrt;"], [0, { v: "&ang;", n: 8402, o: "&nang;" }], [0, "&angmsd;"], [0, "&angsph;"], [0, "&mid;"], [0, "&nmid;"], [0, "&DoubleVerticalBar;"], [0, "&NotDoubleVerticalBar;"], [0, "&and;"], [0, "&or;"], [0, { v: "&cap;", n: 65024, o: "&caps;" }], [0, { v: "&cup;", n: 65024, o: "&cups;" }], [0, "&int;"], [0, "&Int;"], [0, "&iiint;"], [0, "&conint;"], [0, "&Conint;"], [0, "&Cconint;"], [0, "&cwint;"], [0, "&ClockwiseContourIntegral;"], [0, "&awconint;"], [0, "&there4;"], [0, "&becaus;"], [0, "&ratio;"], [0, "&Colon;"], [0, "&dotminus;"], [1, "&mDDot;"], [0, "&homtht;"], [0, { v: "&sim;", n: 8402, o: "&nvsim;" }], [0, { v: "&backsim;", n: 817, o: "&race;" }], [0, { v: "&ac;", n: 819, o: "&acE;" }], [0, "&acd;"], [0, "&VerticalTilde;"], [0, "&NotTilde;"], [0, { v: "&eqsim;", n: 824, o: "&nesim;" }], [0, "&sime;"], [0, "&NotTildeEqual;"], [0, "&cong;"], [0, "&simne;"], [0, "&ncong;"], [0, "&ap;"], [0, "&nap;"], [0, "&ape;"], [0, { v: "&apid;", n: 824, o: "&napid;" }], [0, "&backcong;"], [0, { v: "&asympeq;", n: 8402, o: "&nvap;" }], [0, { v: "&bump;", n: 824, o: "&nbump;" }], [0, { v: "&bumpe;", n: 824, o: "&nbumpe;" }], [0, { v: "&doteq;", n: 824, o: "&nedot;" }], [0, "&doteqdot;"], [0, "&efDot;"], [0, "&erDot;"], [0, "&Assign;"], [0, "&ecolon;"], [0, "&ecir;"], [0, "&circeq;"], [1, "&wedgeq;"], [0, "&veeeq;"], [1, "&triangleq;"], [2, "&equest;"], [0, "&ne;"], [0, { v: "&Congruent;", n: 8421, o: "&bnequiv;" }], [0, "&nequiv;"], [1, { v: "&le;", n: 8402, o: "&nvle;" }], [0, { v: "&ge;", n: 8402, o: "&nvge;" }], [0, { v: "&lE;", n: 824, o: "&nlE;" }], [0, { v: "&gE;", n: 824, o: "&ngE;" }], [0, { v: "&lnE;", n: 65024, o: "&lvertneqq;" }], [0, { v: "&gnE;", n: 65024, o: "&gvertneqq;" }], [0, { v: "&ll;", n: new Map(/* @__PURE__ */ mn([[824, "&nLtv;"], [7577, "&nLt;"]])) }], [0, { v: "&gg;", n: new Map(/* @__PURE__ */ mn([[824, "&nGtv;"], [7577, "&nGt;"]])) }], [0, "&between;"], [0, "&NotCupCap;"], [0, "&nless;"], [0, "&ngt;"], [0, "&nle;"], [0, "&nge;"], [0, "&lesssim;"], [0, "&GreaterTilde;"], [0, "&nlsim;"], [0, "&ngsim;"], [0, "&LessGreater;"], [0, "&gl;"], [0, "&NotLessGreater;"], [0, "&NotGreaterLess;"], [0, "&pr;"], [0, "&sc;"], [0, "&prcue;"], [0, "&sccue;"], [0, "&PrecedesTilde;"], [0, { v: "&scsim;", n: 824, o: "&NotSucceedsTilde;" }], [0, "&NotPrecedes;"], [0, "&NotSucceeds;"], [0, { v: "&sub;", n: 8402, o: "&NotSubset;" }], [0, { v: "&sup;", n: 8402, o: "&NotSuperset;" }], [0, "&nsub;"], [0, "&nsup;"], [0, "&sube;"], [0, "&supe;"], [0, "&NotSubsetEqual;"], [0, "&NotSupersetEqual;"], [0, { v: "&subne;", n: 65024, o: "&varsubsetneq;" }], [0, { v: "&supne;", n: 65024, o: "&varsupsetneq;" }], [1, "&cupdot;"], [0, "&UnionPlus;"], [0, { v: "&sqsub;", n: 824, o: "&NotSquareSubset;" }], [0, { v: "&sqsup;", n: 824, o: "&NotSquareSuperset;" }], [0, "&sqsube;"], [0, "&sqsupe;"], [0, { v: "&sqcap;", n: 65024, o: "&sqcaps;" }], [0, { v: "&sqcup;", n: 65024, o: "&sqcups;" }], [0, "&CirclePlus;"], [0, "&CircleMinus;"], [0, "&CircleTimes;"], [0, "&osol;"], [0, "&CircleDot;"], [0, "&circledcirc;"], [0, "&circledast;"], [1, "&circleddash;"], [0, "&boxplus;"], [0, "&boxminus;"], [0, "&boxtimes;"], [0, "&dotsquare;"], [0, "&RightTee;"], [0, "&dashv;"], [0, "&DownTee;"], [0, "&bot;"], [1, "&models;"], [0, "&DoubleRightTee;"], [0, "&Vdash;"], [0, "&Vvdash;"], [0, "&VDash;"], [0, "&nvdash;"], [0, "&nvDash;"], [0, "&nVdash;"], [0, "&nVDash;"], [0, "&prurel;"], [1, "&LeftTriangle;"], [0, "&RightTriangle;"], [0, { v: "&LeftTriangleEqual;", n: 8402, o: "&nvltrie;" }], [0, { v: "&RightTriangleEqual;", n: 8402, o: "&nvrtrie;" }], [0, "&origof;"], [0, "&imof;"], [0, "&multimap;"], [0, "&hercon;"], [0, "&intcal;"], [0, "&veebar;"], [1, "&barvee;"], [0, "&angrtvb;"], [0, "&lrtri;"], [0, "&bigwedge;"], [0, "&bigvee;"], [0, "&bigcap;"], [0, "&bigcup;"], [0, "&diam;"], [0, "&sdot;"], [0, "&sstarf;"], [0, "&divideontimes;"], [0, "&bowtie;"], [0, "&ltimes;"], [0, "&rtimes;"], [0, "&leftthreetimes;"], [0, "&rightthreetimes;"], [0, "&backsimeq;"], [0, "&curlyvee;"], [0, "&curlywedge;"], [0, "&Sub;"], [0, "&Sup;"], [0, "&Cap;"], [0, "&Cup;"], [0, "&fork;"], [0, "&epar;"], [0, "&lessdot;"], [0, "&gtdot;"], [0, { v: "&Ll;", n: 824, o: "&nLl;" }], [0, { v: "&Gg;", n: 824, o: "&nGg;" }], [0, { v: "&leg;", n: 65024, o: "&lesg;" }], [0, { v: "&gel;", n: 65024, o: "&gesl;" }], [2, "&cuepr;"], [0, "&cuesc;"], [0, "&NotPrecedesSlantEqual;"], [0, "&NotSucceedsSlantEqual;"], [0, "&NotSquareSubsetEqual;"], [0, "&NotSquareSupersetEqual;"], [2, "&lnsim;"], [0, "&gnsim;"], [0, "&precnsim;"], [0, "&scnsim;"], [0, "&nltri;"], [0, "&NotRightTriangle;"], [0, "&nltrie;"], [0, "&NotRightTriangleEqual;"], [0, "&vellip;"], [0, "&ctdot;"], [0, "&utdot;"], [0, "&dtdot;"], [0, "&disin;"], [0, "&isinsv;"], [0, "&isins;"], [0, { v: "&isindot;", n: 824, o: "&notindot;" }], [0, "&notinvc;"], [0, "&notinvb;"], [1, { v: "&isinE;", n: 824, o: "&notinE;" }], [0, "&nisd;"], [0, "&xnis;"], [0, "&nis;"], [0, "&notnivc;"], [0, "&notnivb;"], [6, "&barwed;"], [0, "&Barwed;"], [1, "&lceil;"], [0, "&rceil;"], [0, "&LeftFloor;"], [0, "&rfloor;"], [0, "&drcrop;"], [0, "&dlcrop;"], [0, "&urcrop;"], [0, "&ulcrop;"], [0, "&bnot;"], [1, "&profline;"], [0, "&profsurf;"], [1, "&telrec;"], [0, "&target;"], [5, "&ulcorn;"], [0, "&urcorn;"], [0, "&dlcorn;"], [0, "&drcorn;"], [2, "&frown;"], [0, "&smile;"], [9, "&cylcty;"], [0, "&profalar;"], [7, "&topbot;"], [6, "&ovbar;"], [1, "&solbar;"], [60, "&angzarr;"], [51, "&lmoustache;"], [0, "&rmoustache;"], [2, "&OverBracket;"], [0, "&bbrk;"], [0, "&bbrktbrk;"], [37, "&OverParenthesis;"], [0, "&UnderParenthesis;"], [0, "&OverBrace;"], [0, "&UnderBrace;"], [2, "&trpezium;"], [4, "&elinters;"], [59, "&blank;"], [164, "&circledS;"], [55, "&boxh;"], [1, "&boxv;"], [9, "&boxdr;"], [3, "&boxdl;"], [3, "&boxur;"], [3, "&boxul;"], [3, "&boxvr;"], [7, "&boxvl;"], [7, "&boxhd;"], [7, "&boxhu;"], [7, "&boxvh;"], [19, "&boxH;"], [0, "&boxV;"], [0, "&boxdR;"], [0, "&boxDr;"], [0, "&boxDR;"], [0, "&boxdL;"], [0, "&boxDl;"], [0, "&boxDL;"], [0, "&boxuR;"], [0, "&boxUr;"], [0, "&boxUR;"], [0, "&boxuL;"], [0, "&boxUl;"], [0, "&boxUL;"], [0, "&boxvR;"], [0, "&boxVr;"], [0, "&boxVR;"], [0, "&boxvL;"], [0, "&boxVl;"], [0, "&boxVL;"], [0, "&boxHd;"], [0, "&boxhD;"], [0, "&boxHD;"], [0, "&boxHu;"], [0, "&boxhU;"], [0, "&boxHU;"], [0, "&boxvH;"], [0, "&boxVh;"], [0, "&boxVH;"], [19, "&uhblk;"], [3, "&lhblk;"], [3, "&block;"], [8, "&blk14;"], [0, "&blk12;"], [0, "&blk34;"], [13, "&square;"], [8, "&blacksquare;"], [0, "&EmptyVerySmallSquare;"], [1, "&rect;"], [0, "&marker;"], [2, "&fltns;"], [1, "&bigtriangleup;"], [0, "&blacktriangle;"], [0, "&triangle;"], [2, "&blacktriangleright;"], [0, "&rtri;"], [3, "&bigtriangledown;"], [0, "&blacktriangledown;"], [0, "&dtri;"], [2, "&blacktriangleleft;"], [0, "&ltri;"], [6, "&loz;"], [0, "&cir;"], [32, "&tridot;"], [2, "&bigcirc;"], [8, "&ultri;"], [0, "&urtri;"], [0, "&lltri;"], [0, "&EmptySmallSquare;"], [0, "&FilledSmallSquare;"], [8, "&bigstar;"], [0, "&star;"], [7, "&phone;"], [49, "&female;"], [1, "&male;"], [29, "&spades;"], [2, "&clubs;"], [1, "&hearts;"], [0, "&diamondsuit;"], [3, "&sung;"], [2, "&flat;"], [0, "&natural;"], [0, "&sharp;"], [163, "&check;"], [3, "&cross;"], [8, "&malt;"], [21, "&sext;"], [33, "&VerticalSeparator;"], [25, "&lbbrk;"], [0, "&rbbrk;"], [84, "&bsolhsub;"], [0, "&suphsol;"], [28, "&LeftDoubleBracket;"], [0, "&RightDoubleBracket;"], [0, "&lang;"], [0, "&rang;"], [0, "&Lang;"], [0, "&Rang;"], [0, "&loang;"], [0, "&roang;"], [7, "&longleftarrow;"], [0, "&longrightarrow;"], [0, "&longleftrightarrow;"], [0, "&DoubleLongLeftArrow;"], [0, "&DoubleLongRightArrow;"], [0, "&DoubleLongLeftRightArrow;"], [1, "&longmapsto;"], [2, "&dzigrarr;"], [258, "&nvlArr;"], [0, "&nvrArr;"], [0, "&nvHarr;"], [0, "&Map;"], [6, "&lbarr;"], [0, "&bkarow;"], [0, "&lBarr;"], [0, "&dbkarow;"], [0, "&drbkarow;"], [0, "&DDotrahd;"], [0, "&UpArrowBar;"], [0, "&DownArrowBar;"], [2, "&Rarrtl;"], [2, "&latail;"], [0, "&ratail;"], [0, "&lAtail;"], [0, "&rAtail;"], [0, "&larrfs;"], [0, "&rarrfs;"], [0, "&larrbfs;"], [0, "&rarrbfs;"], [2, "&nwarhk;"], [0, "&nearhk;"], [0, "&hksearow;"], [0, "&hkswarow;"], [0, "&nwnear;"], [0, "&nesear;"], [0, "&seswar;"], [0, "&swnwar;"], [8, { v: "&rarrc;", n: 824, o: "&nrarrc;" }], [1, "&cudarrr;"], [0, "&ldca;"], [0, "&rdca;"], [0, "&cudarrl;"], [0, "&larrpl;"], [2, "&curarrm;"], [0, "&cularrp;"], [7, "&rarrpl;"], [2, "&harrcir;"], [0, "&Uarrocir;"], [0, "&lurdshar;"], [0, "&ldrushar;"], [2, "&LeftRightVector;"], [0, "&RightUpDownVector;"], [0, "&DownLeftRightVector;"], [0, "&LeftUpDownVector;"], [0, "&LeftVectorBar;"], [0, "&RightVectorBar;"], [0, "&RightUpVectorBar;"], [0, "&RightDownVectorBar;"], [0, "&DownLeftVectorBar;"], [0, "&DownRightVectorBar;"], [0, "&LeftUpVectorBar;"], [0, "&LeftDownVectorBar;"], [0, "&LeftTeeVector;"], [0, "&RightTeeVector;"], [0, "&RightUpTeeVector;"], [0, "&RightDownTeeVector;"], [0, "&DownLeftTeeVector;"], [0, "&DownRightTeeVector;"], [0, "&LeftUpTeeVector;"], [0, "&LeftDownTeeVector;"], [0, "&lHar;"], [0, "&uHar;"], [0, "&rHar;"], [0, "&dHar;"], [0, "&luruhar;"], [0, "&ldrdhar;"], [0, "&ruluhar;"], [0, "&rdldhar;"], [0, "&lharul;"], [0, "&llhard;"], [0, "&rharul;"], [0, "&lrhard;"], [0, "&udhar;"], [0, "&duhar;"], [0, "&RoundImplies;"], [0, "&erarr;"], [0, "&simrarr;"], [0, "&larrsim;"], [0, "&rarrsim;"], [0, "&rarrap;"], [0, "&ltlarr;"], [1, "&gtrarr;"], [0, "&subrarr;"], [1, "&suplarr;"], [0, "&lfisht;"], [0, "&rfisht;"], [0, "&ufisht;"], [0, "&dfisht;"], [5, "&lopar;"], [0, "&ropar;"], [4, "&lbrke;"], [0, "&rbrke;"], [0, "&lbrkslu;"], [0, "&rbrksld;"], [0, "&lbrksld;"], [0, "&rbrkslu;"], [0, "&langd;"], [0, "&rangd;"], [0, "&lparlt;"], [0, "&rpargt;"], [0, "&gtlPar;"], [0, "&ltrPar;"], [3, "&vzigzag;"], [1, "&vangrt;"], [0, "&angrtvbd;"], [6, "&ange;"], [0, "&range;"], [0, "&dwangle;"], [0, "&uwangle;"], [0, "&angmsdaa;"], [0, "&angmsdab;"], [0, "&angmsdac;"], [0, "&angmsdad;"], [0, "&angmsdae;"], [0, "&angmsdaf;"], [0, "&angmsdag;"], [0, "&angmsdah;"], [0, "&bemptyv;"], [0, "&demptyv;"], [0, "&cemptyv;"], [0, "&raemptyv;"], [0, "&laemptyv;"], [0, "&ohbar;"], [0, "&omid;"], [0, "&opar;"], [1, "&operp;"], [1, "&olcross;"], [0, "&odsold;"], [1, "&olcir;"], [0, "&ofcir;"], [0, "&olt;"], [0, "&ogt;"], [0, "&cirscir;"], [0, "&cirE;"], [0, "&solb;"], [0, "&bsolb;"], [3, "&boxbox;"], [3, "&trisb;"], [0, "&rtriltri;"], [0, { v: "&LeftTriangleBar;", n: 824, o: "&NotLeftTriangleBar;" }], [0, { v: "&RightTriangleBar;", n: 824, o: "&NotRightTriangleBar;" }], [11, "&iinfin;"], [0, "&infintie;"], [0, "&nvinfin;"], [4, "&eparsl;"], [0, "&smeparsl;"], [0, "&eqvparsl;"], [5, "&blacklozenge;"], [8, "&RuleDelayed;"], [1, "&dsol;"], [9, "&bigodot;"], [0, "&bigoplus;"], [0, "&bigotimes;"], [1, "&biguplus;"], [1, "&bigsqcup;"], [5, "&iiiint;"], [0, "&fpartint;"], [2, "&cirfnint;"], [0, "&awint;"], [0, "&rppolint;"], [0, "&scpolint;"], [0, "&npolint;"], [0, "&pointint;"], [0, "&quatint;"], [0, "&intlarhk;"], [10, "&pluscir;"], [0, "&plusacir;"], [0, "&simplus;"], [0, "&plusdu;"], [0, "&plussim;"], [0, "&plustwo;"], [1, "&mcomma;"], [0, "&minusdu;"], [2, "&loplus;"], [0, "&roplus;"], [0, "&Cross;"], [0, "&timesd;"], [0, "&timesbar;"], [1, "&smashp;"], [0, "&lotimes;"], [0, "&rotimes;"], [0, "&otimesas;"], [0, "&Otimes;"], [0, "&odiv;"], [0, "&triplus;"], [0, "&triminus;"], [0, "&tritime;"], [0, "&intprod;"], [2, "&amalg;"], [0, "&capdot;"], [1, "&ncup;"], [0, "&ncap;"], [0, "&capand;"], [0, "&cupor;"], [0, "&cupcap;"], [0, "&capcup;"], [0, "&cupbrcap;"], [0, "&capbrcup;"], [0, "&cupcup;"], [0, "&capcap;"], [0, "&ccups;"], [0, "&ccaps;"], [2, "&ccupssm;"], [2, "&And;"], [0, "&Or;"], [0, "&andand;"], [0, "&oror;"], [0, "&orslope;"], [0, "&andslope;"], [1, "&andv;"], [0, "&orv;"], [0, "&andd;"], [0, "&ord;"], [1, "&wedbar;"], [6, "&sdote;"], [3, "&simdot;"], [2, { v: "&congdot;", n: 824, o: "&ncongdot;" }], [0, "&easter;"], [0, "&apacir;"], [0, { v: "&apE;", n: 824, o: "&napE;" }], [0, "&eplus;"], [0, "&pluse;"], [0, "&Esim;"], [0, "&Colone;"], [0, "&Equal;"], [1, "&ddotseq;"], [0, "&equivDD;"], [0, "&ltcir;"], [0, "&gtcir;"], [0, "&ltquest;"], [0, "&gtquest;"], [0, { v: "&leqslant;", n: 824, o: "&nleqslant;" }], [0, { v: "&geqslant;", n: 824, o: "&ngeqslant;" }], [0, "&lesdot;"], [0, "&gesdot;"], [0, "&lesdoto;"], [0, "&gesdoto;"], [0, "&lesdotor;"], [0, "&gesdotol;"], [0, "&lap;"], [0, "&gap;"], [0, "&lne;"], [0, "&gne;"], [0, "&lnap;"], [0, "&gnap;"], [0, "&lEg;"], [0, "&gEl;"], [0, "&lsime;"], [0, "&gsime;"], [0, "&lsimg;"], [0, "&gsiml;"], [0, "&lgE;"], [0, "&glE;"], [0, "&lesges;"], [0, "&gesles;"], [0, "&els;"], [0, "&egs;"], [0, "&elsdot;"], [0, "&egsdot;"], [0, "&el;"], [0, "&eg;"], [2, "&siml;"], [0, "&simg;"], [0, "&simlE;"], [0, "&simgE;"], [0, { v: "&LessLess;", n: 824, o: "&NotNestedLessLess;" }], [0, { v: "&GreaterGreater;", n: 824, o: "&NotNestedGreaterGreater;" }], [1, "&glj;"], [0, "&gla;"], [0, "&ltcc;"], [0, "&gtcc;"], [0, "&lescc;"], [0, "&gescc;"], [0, "&smt;"], [0, "&lat;"], [0, { v: "&smte;", n: 65024, o: "&smtes;" }], [0, { v: "&late;", n: 65024, o: "&lates;" }], [0, "&bumpE;"], [0, { v: "&PrecedesEqual;", n: 824, o: "&NotPrecedesEqual;" }], [0, { v: "&sce;", n: 824, o: "&NotSucceedsEqual;" }], [2, "&prE;"], [0, "&scE;"], [0, "&precneqq;"], [0, "&scnE;"], [0, "&prap;"], [0, "&scap;"], [0, "&precnapprox;"], [0, "&scnap;"], [0, "&Pr;"], [0, "&Sc;"], [0, "&subdot;"], [0, "&supdot;"], [0, "&subplus;"], [0, "&supplus;"], [0, "&submult;"], [0, "&supmult;"], [0, "&subedot;"], [0, "&supedot;"], [0, { v: "&subE;", n: 824, o: "&nsubE;" }], [0, { v: "&supE;", n: 824, o: "&nsupE;" }], [0, "&subsim;"], [0, "&supsim;"], [2, { v: "&subnE;", n: 65024, o: "&varsubsetneqq;" }], [0, { v: "&supnE;", n: 65024, o: "&varsupsetneqq;" }], [2, "&csub;"], [0, "&csup;"], [0, "&csube;"], [0, "&csupe;"], [0, "&subsup;"], [0, "&supsub;"], [0, "&subsub;"], [0, "&supsup;"], [0, "&suphsub;"], [0, "&supdsub;"], [0, "&forkv;"], [0, "&topfork;"], [0, "&mlcp;"], [8, "&Dashv;"], [1, "&Vdashl;"], [0, "&Barv;"], [0, "&vBar;"], [0, "&vBarv;"], [1, "&Vbar;"], [0, "&Not;"], [0, "&bNot;"], [0, "&rnmid;"], [0, "&cirmid;"], [0, "&midcir;"], [0, "&topcir;"], [0, "&nhpar;"], [0, "&parsim;"], [9, { v: "&parsl;", n: 8421, o: "&nparsl;" }], [44343, { n: new Map(/* @__PURE__ */ mn([[56476, "&Ascr;"], [1, "&Cscr;"], [0, "&Dscr;"], [2, "&Gscr;"], [2, "&Jscr;"], [0, "&Kscr;"], [2, "&Nscr;"], [0, "&Oscr;"], [0, "&Pscr;"], [0, "&Qscr;"], [1, "&Sscr;"], [0, "&Tscr;"], [0, "&Uscr;"], [0, "&Vscr;"], [0, "&Wscr;"], [0, "&Xscr;"], [0, "&Yscr;"], [0, "&Zscr;"], [0, "&ascr;"], [0, "&bscr;"], [0, "&cscr;"], [0, "&dscr;"], [1, "&fscr;"], [1, "&hscr;"], [0, "&iscr;"], [0, "&jscr;"], [0, "&kscr;"], [0, "&lscr;"], [0, "&mscr;"], [0, "&nscr;"], [1, "&pscr;"], [0, "&qscr;"], [0, "&rscr;"], [0, "&sscr;"], [0, "&tscr;"], [0, "&uscr;"], [0, "&vscr;"], [0, "&wscr;"], [0, "&xscr;"], [0, "&yscr;"], [0, "&zscr;"], [52, "&Afr;"], [0, "&Bfr;"], [1, "&Dfr;"], [0, "&Efr;"], [0, "&Ffr;"], [0, "&Gfr;"], [2, "&Jfr;"], [0, "&Kfr;"], [0, "&Lfr;"], [0, "&Mfr;"], [0, "&Nfr;"], [0, "&Ofr;"], [0, "&Pfr;"], [0, "&Qfr;"], [1, "&Sfr;"], [0, "&Tfr;"], [0, "&Ufr;"], [0, "&Vfr;"], [0, "&Wfr;"], [0, "&Xfr;"], [0, "&Yfr;"], [1, "&afr;"], [0, "&bfr;"], [0, "&cfr;"], [0, "&dfr;"], [0, "&efr;"], [0, "&ffr;"], [0, "&gfr;"], [0, "&hfr;"], [0, "&ifr;"], [0, "&jfr;"], [0, "&kfr;"], [0, "&lfr;"], [0, "&mfr;"], [0, "&nfr;"], [0, "&ofr;"], [0, "&pfr;"], [0, "&qfr;"], [0, "&rfr;"], [0, "&sfr;"], [0, "&tfr;"], [0, "&ufr;"], [0, "&vfr;"], [0, "&wfr;"], [0, "&xfr;"], [0, "&yfr;"], [0, "&zfr;"], [0, "&Aopf;"], [0, "&Bopf;"], [1, "&Dopf;"], [0, "&Eopf;"], [0, "&Fopf;"], [0, "&Gopf;"], [1, "&Iopf;"], [0, "&Jopf;"], [0, "&Kopf;"], [0, "&Lopf;"], [0, "&Mopf;"], [1, "&Oopf;"], [3, "&Sopf;"], [0, "&Topf;"], [0, "&Uopf;"], [0, "&Vopf;"], [0, "&Wopf;"], [0, "&Xopf;"], [0, "&Yopf;"], [1, "&aopf;"], [0, "&bopf;"], [0, "&copf;"], [0, "&dopf;"], [0, "&eopf;"], [0, "&fopf;"], [0, "&gopf;"], [0, "&hopf;"], [0, "&iopf;"], [0, "&jopf;"], [0, "&kopf;"], [0, "&lopf;"], [0, "&mopf;"], [0, "&nopf;"], [0, "&oopf;"], [0, "&popf;"], [0, "&qopf;"], [0, "&ropf;"], [0, "&sopf;"], [0, "&topf;"], [0, "&uopf;"], [0, "&vopf;"], [0, "&wopf;"], [0, "&xopf;"], [0, "&yopf;"], [0, "&zopf;"]])) }], [8906, "&fflig;"], [0, "&filig;"], [0, "&fllig;"], [0, "&ffilig;"], [0, "&ffllig;"]]));
var On = {};
(function(o) {
  Object.defineProperty(o, "__esModule", { value: !0 }), o.escapeText = o.escapeAttribute = o.escapeUTF8 = o.escape = o.encodeXML = o.getCodePoint = o.xmlReplacer = void 0, o.xmlReplacer = /["&'<>$\x80-\uFFFF]/g;
  var i = /* @__PURE__ */ new Map([
    [34, "&quot;"],
    [38, "&amp;"],
    [39, "&apos;"],
    [60, "&lt;"],
    [62, "&gt;"]
  ]);
  o.getCodePoint = // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
  String.prototype.codePointAt != null ? function(a, c) {
    return a.codePointAt(c);
  } : (
    // http://mathiasbynens.be/notes/javascript-encoding#surrogate-formulae
    function(a, c) {
      return (a.charCodeAt(c) & 64512) === 55296 ? (a.charCodeAt(c) - 55296) * 1024 + a.charCodeAt(c + 1) - 56320 + 65536 : a.charCodeAt(c);
    }
  );
  function n(a) {
    for (var c = "", p = 0, g; (g = o.xmlReplacer.exec(a)) !== null; ) {
      var d = g.index, _ = a.charCodeAt(d), v = i.get(_);
      v !== void 0 ? (c += a.substring(p, d) + v, p = d + 1) : (c += "".concat(a.substring(p, d), "&#x").concat((0, o.getCodePoint)(a, d).toString(16), ";"), p = o.xmlReplacer.lastIndex += +((_ & 64512) === 55296));
    }
    return c + a.substr(p);
  }
  o.encodeXML = n, o.escape = n;
  function r(a, c) {
    return function(g) {
      for (var d, _ = 0, v = ""; d = a.exec(g); )
        _ !== d.index && (v += g.substring(_, d.index)), v += c.get(d[0].charCodeAt(0)), _ = d.index + 1;
      return v + g.substring(_);
    };
  }
  o.escapeUTF8 = r(/[&<>'"]/g, i), o.escapeAttribute = r(/["&\u00A0]/g, /* @__PURE__ */ new Map([
    [34, "&quot;"],
    [38, "&amp;"],
    [160, "&nbsp;"]
  ])), o.escapeText = r(/[&<>\u00A0]/g, /* @__PURE__ */ new Map([
    [38, "&amp;"],
    [60, "&lt;"],
    [62, "&gt;"],
    [160, "&nbsp;"]
  ]));
})(On);
var Aa = W && W.__importDefault || function(o) {
  return o && o.__esModule ? o : { default: o };
};
Object.defineProperty(St, "__esModule", { value: !0 });
St.encodeNonAsciiHTML = St.encodeHTML = void 0;
var Ca = Aa(Yr), Ko = On, Ma = /[\t\n!-,./:-@[-`\f{-}$\x80-\uFFFF]/g;
function Oa(o) {
  return Jo(Ma, o);
}
St.encodeHTML = Oa;
function Ia(o) {
  return Jo(Ko.xmlReplacer, o);
}
St.encodeNonAsciiHTML = Ia;
function Jo(o, i) {
  for (var n = "", r = 0, a; (a = o.exec(i)) !== null; ) {
    var c = a.index;
    n += i.substring(r, c);
    var p = i.charCodeAt(c), g = Ca.default.get(p);
    if (typeof g == "object") {
      if (c + 1 < i.length) {
        var d = i.charCodeAt(c + 1), _ = typeof g.n == "number" ? g.n === d ? g.o : void 0 : g.n.get(d);
        if (_ !== void 0) {
          n += _, r = o.lastIndex += 1;
          continue;
        }
      }
      g = g.v;
    }
    if (g !== void 0)
      n += g, r = c + 1;
    else {
      var v = (0, Ko.getCodePoint)(i, c);
      n += "&#x".concat(v.toString(16), ";"), r = o.lastIndex += +(v !== p);
    }
  }
  return n + i.substr(r);
}
(function(o) {
  Object.defineProperty(o, "__esModule", { value: !0 }), o.decodeXMLStrict = o.decodeHTML5Strict = o.decodeHTML4Strict = o.decodeHTML5 = o.decodeHTML4 = o.decodeHTMLAttribute = o.decodeHTMLStrict = o.decodeHTML = o.decodeXML = o.DecodingMode = o.EntityDecoder = o.encodeHTML5 = o.encodeHTML4 = o.encodeNonAsciiHTML = o.encodeHTML = o.escapeText = o.escapeAttribute = o.escapeUTF8 = o.escape = o.encodeXML = o.encode = o.decodeStrict = o.decode = o.EncodingMode = o.EntityLevel = void 0;
  var i = vi, n = St, r = On, a;
  (function(f) {
    f[f.XML = 0] = "XML", f[f.HTML = 1] = "HTML";
  })(a = o.EntityLevel || (o.EntityLevel = {}));
  var c;
  (function(f) {
    f[f.UTF8 = 0] = "UTF8", f[f.ASCII = 1] = "ASCII", f[f.Extensive = 2] = "Extensive", f[f.Attribute = 3] = "Attribute", f[f.Text = 4] = "Text";
  })(c = o.EncodingMode || (o.EncodingMode = {}));
  function p(f, m) {
    m === void 0 && (m = a.XML);
    var N = typeof m == "number" ? m : m.level;
    if (N === a.HTML) {
      var I = typeof m == "object" ? m.mode : void 0;
      return (0, i.decodeHTML)(f, I);
    }
    return (0, i.decodeXML)(f);
  }
  o.decode = p;
  function g(f, m) {
    var N;
    m === void 0 && (m = a.XML);
    var I = typeof m == "number" ? { level: m } : m;
    return (N = I.mode) !== null && N !== void 0 || (I.mode = i.DecodingMode.Strict), p(f, I);
  }
  o.decodeStrict = g;
  function d(f, m) {
    m === void 0 && (m = a.XML);
    var N = typeof m == "number" ? { level: m } : m;
    return N.mode === c.UTF8 ? (0, r.escapeUTF8)(f) : N.mode === c.Attribute ? (0, r.escapeAttribute)(f) : N.mode === c.Text ? (0, r.escapeText)(f) : N.level === a.HTML ? N.mode === c.ASCII ? (0, n.encodeNonAsciiHTML)(f) : (0, n.encodeHTML)(f) : (0, r.encodeXML)(f);
  }
  o.encode = d;
  var _ = On;
  Object.defineProperty(o, "encodeXML", { enumerable: !0, get: function() {
    return _.encodeXML;
  } }), Object.defineProperty(o, "escape", { enumerable: !0, get: function() {
    return _.escape;
  } }), Object.defineProperty(o, "escapeUTF8", { enumerable: !0, get: function() {
    return _.escapeUTF8;
  } }), Object.defineProperty(o, "escapeAttribute", { enumerable: !0, get: function() {
    return _.escapeAttribute;
  } }), Object.defineProperty(o, "escapeText", { enumerable: !0, get: function() {
    return _.escapeText;
  } });
  var v = St;
  Object.defineProperty(o, "encodeHTML", { enumerable: !0, get: function() {
    return v.encodeHTML;
  } }), Object.defineProperty(o, "encodeNonAsciiHTML", { enumerable: !0, get: function() {
    return v.encodeNonAsciiHTML;
  } }), Object.defineProperty(o, "encodeHTML4", { enumerable: !0, get: function() {
    return v.encodeHTML;
  } }), Object.defineProperty(o, "encodeHTML5", { enumerable: !0, get: function() {
    return v.encodeHTML;
  } });
  var S = vi;
  Object.defineProperty(o, "EntityDecoder", { enumerable: !0, get: function() {
    return S.EntityDecoder;
  } }), Object.defineProperty(o, "DecodingMode", { enumerable: !0, get: function() {
    return S.DecodingMode;
  } }), Object.defineProperty(o, "decodeXML", { enumerable: !0, get: function() {
    return S.decodeXML;
  } }), Object.defineProperty(o, "decodeHTML", { enumerable: !0, get: function() {
    return S.decodeHTML;
  } }), Object.defineProperty(o, "decodeHTMLStrict", { enumerable: !0, get: function() {
    return S.decodeHTMLStrict;
  } }), Object.defineProperty(o, "decodeHTMLAttribute", { enumerable: !0, get: function() {
    return S.decodeHTMLAttribute;
  } }), Object.defineProperty(o, "decodeHTML4", { enumerable: !0, get: function() {
    return S.decodeHTML;
  } }), Object.defineProperty(o, "decodeHTML5", { enumerable: !0, get: function() {
    return S.decodeHTML;
  } }), Object.defineProperty(o, "decodeHTML4Strict", { enumerable: !0, get: function() {
    return S.decodeHTMLStrict;
  } }), Object.defineProperty(o, "decodeHTML5Strict", { enumerable: !0, get: function() {
    return S.decodeHTMLStrict;
  } }), Object.defineProperty(o, "decodeXMLStrict", { enumerable: !0, get: function() {
    return S.decodeXML;
  } });
})(Yo);
var Vt = {};
Object.defineProperty(Vt, "__esModule", { value: !0 });
Vt.attributeNames = Vt.elementNames = void 0;
Vt.elementNames = new Map([
  "altGlyph",
  "altGlyphDef",
  "altGlyphItem",
  "animateColor",
  "animateMotion",
  "animateTransform",
  "clipPath",
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feDropShadow",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence",
  "foreignObject",
  "glyphRef",
  "linearGradient",
  "radialGradient",
  "textPath"
].map(function(o) {
  return [o.toLowerCase(), o];
}));
Vt.attributeNames = new Map([
  "definitionURL",
  "attributeName",
  "attributeType",
  "baseFrequency",
  "baseProfile",
  "calcMode",
  "clipPathUnits",
  "diffuseConstant",
  "edgeMode",
  "filterUnits",
  "glyphRef",
  "gradientTransform",
  "gradientUnits",
  "kernelMatrix",
  "kernelUnitLength",
  "keyPoints",
  "keySplines",
  "keyTimes",
  "lengthAdjust",
  "limitingConeAngle",
  "markerHeight",
  "markerUnits",
  "markerWidth",
  "maskContentUnits",
  "maskUnits",
  "numOctaves",
  "pathLength",
  "patternContentUnits",
  "patternTransform",
  "patternUnits",
  "pointsAtX",
  "pointsAtY",
  "pointsAtZ",
  "preserveAlpha",
  "preserveAspectRatio",
  "primitiveUnits",
  "refX",
  "refY",
  "repeatCount",
  "repeatDur",
  "requiredExtensions",
  "requiredFeatures",
  "specularConstant",
  "specularExponent",
  "spreadMethod",
  "startOffset",
  "stdDeviation",
  "stitchTiles",
  "surfaceScale",
  "systemLanguage",
  "tableValues",
  "targetX",
  "targetY",
  "textLength",
  "viewBox",
  "viewTarget",
  "xChannelSelector",
  "yChannelSelector",
  "zoomAndPan"
].map(function(o) {
  return [o.toLowerCase(), o];
}));
var Ut = W && W.__assign || function() {
  return Ut = Object.assign || function(o) {
    for (var i, n = 1, r = arguments.length; n < r; n++) {
      i = arguments[n];
      for (var a in i)
        Object.prototype.hasOwnProperty.call(i, a) && (o[a] = i[a]);
    }
    return o;
  }, Ut.apply(this, arguments);
}, ka = W && W.__createBinding || (Object.create ? function(o, i, n, r) {
  r === void 0 && (r = n);
  var a = Object.getOwnPropertyDescriptor(i, n);
  (!a || ("get" in a ? !i.__esModule : a.writable || a.configurable)) && (a = { enumerable: !0, get: function() {
    return i[n];
  } }), Object.defineProperty(o, r, a);
} : function(o, i, n, r) {
  r === void 0 && (r = n), o[r] = i[n];
}), Na = W && W.__setModuleDefault || (Object.create ? function(o, i) {
  Object.defineProperty(o, "default", { enumerable: !0, value: i });
} : function(o, i) {
  o.default = i;
}), Da = W && W.__importStar || function(o) {
  if (o && o.__esModule)
    return o;
  var i = {};
  if (o != null)
    for (var n in o)
      n !== "default" && Object.prototype.hasOwnProperty.call(o, n) && ka(i, o, n);
  return Na(i, o), i;
};
Object.defineProperty(Ci, "__esModule", { value: !0 });
Ci.render = void 0;
var Qe = Da(Yt), In = Yo, Qo = Vt, Ba = /* @__PURE__ */ new Set([
  "style",
  "script",
  "xmp",
  "iframe",
  "noembed",
  "noframes",
  "plaintext",
  "noscript"
]);
function za(o) {
  return o.replace(/"/g, "&quot;");
}
function Ra(o, i) {
  var n;
  if (o) {
    var r = ((n = i.encodeEntities) !== null && n !== void 0 ? n : i.decodeEntities) === !1 ? za : i.xmlMode || i.encodeEntities !== "utf8" ? In.encodeXML : In.escapeAttribute;
    return Object.keys(o).map(function(a) {
      var c, p, g = (c = o[a]) !== null && c !== void 0 ? c : "";
      return i.xmlMode === "foreign" && (a = (p = Qo.attributeNames.get(a)) !== null && p !== void 0 ? p : a), !i.emptyAttrs && !i.xmlMode && g === "" ? a : "".concat(a, '="').concat(r(g), '"');
    }).join(" ");
  }
}
var ro = /* @__PURE__ */ new Set([
  "area",
  "base",
  "basefont",
  "br",
  "col",
  "command",
  "embed",
  "frame",
  "hr",
  "img",
  "input",
  "isindex",
  "keygen",
  "link",
  "meta",
  "param",
  "source",
  "track",
  "wbr"
]);
function Zn(o, i) {
  i === void 0 && (i = {});
  for (var n = ("length" in o) ? o : [o], r = "", a = 0; a < n.length; a++)
    r += ja(n[a], i);
  return r;
}
Ci.render = Zn;
Ci.default = Zn;
function ja(o, i) {
  switch (o.type) {
    case Qe.Root:
      return Zn(o.children, i);
    case Qe.Doctype:
    case Qe.Directive:
      return Ha(o);
    case Qe.Comment:
      return Wa(o);
    case Qe.CDATA:
      return Va(o);
    case Qe.Script:
    case Qe.Style:
    case Qe.Tag:
      return Fa(o, i);
    case Qe.Text:
      return Ua(o, i);
  }
}
var qa = /* @__PURE__ */ new Set([
  "mi",
  "mo",
  "mn",
  "ms",
  "mtext",
  "annotation-xml",
  "foreignObject",
  "desc",
  "title"
]), Za = /* @__PURE__ */ new Set(["svg", "math"]);
function Fa(o, i) {
  var n;
  i.xmlMode === "foreign" && (o.name = (n = Qo.elementNames.get(o.name)) !== null && n !== void 0 ? n : o.name, o.parent && qa.has(o.parent.name) && (i = Ut(Ut({}, i), { xmlMode: !1 }))), !i.xmlMode && Za.has(o.name) && (i = Ut(Ut({}, i), { xmlMode: "foreign" }));
  var r = "<".concat(o.name), a = Ra(o.attribs, i);
  return a && (r += " ".concat(a)), o.children.length === 0 && (i.xmlMode ? (
    // In XML mode or foreign mode, and user hasn't explicitly turned off self-closing tags
    i.selfClosingTags !== !1
  ) : (
    // User explicitly asked for self-closing tags, even in HTML mode
    i.selfClosingTags && ro.has(o.name)
  )) ? (i.xmlMode || (r += " "), r += "/>") : (r += ">", o.children.length > 0 && (r += Zn(o.children, i)), (i.xmlMode || !ro.has(o.name)) && (r += "</".concat(o.name, ">"))), r;
}
function Ha(o) {
  return "<".concat(o.data, ">");
}
function Ua(o, i) {
  var n, r = o.data || "";
  return ((n = i.encodeEntities) !== null && n !== void 0 ? n : i.decodeEntities) !== !1 && !(!i.xmlMode && o.parent && Ba.has(o.parent.name)) && (r = i.xmlMode || i.encodeEntities !== "utf8" ? (0, In.encodeXML)(r) : (0, In.escapeText)(r)), r;
}
function Va(o) {
  return "<![CDATA[".concat(o.children[0].data, "]]>");
}
function Wa(o) {
  return "<!--".concat(o.data, "-->");
}
var Ga = W && W.__importDefault || function(o) {
  return o && o.__esModule ? o : { default: o };
};
Object.defineProperty(ft, "__esModule", { value: !0 });
ft.getOuterHTML = es;
ft.getInnerHTML = Ya;
ft.getText = Pn;
ft.textContent = Er;
ft.innerText = Ar;
var Ue = nt, $a = Ga(Ci), Xa = Yt;
function es(o, i) {
  return (0, $a.default)(o, i);
}
function Ya(o, i) {
  return (0, Ue.hasChildren)(o) ? o.children.map(function(n) {
    return es(n, i);
  }).join("") : "";
}
function Pn(o) {
  return Array.isArray(o) ? o.map(Pn).join("") : (0, Ue.isTag)(o) ? o.name === "br" ? `
` : Pn(o.children) : (0, Ue.isCDATA)(o) ? Pn(o.children) : (0, Ue.isText)(o) ? o.data : "";
}
function Er(o) {
  return Array.isArray(o) ? o.map(Er).join("") : (0, Ue.hasChildren)(o) && !(0, Ue.isComment)(o) ? Er(o.children) : (0, Ue.isText)(o) ? o.data : "";
}
function Ar(o) {
  return Array.isArray(o) ? o.map(Ar).join("") : (0, Ue.hasChildren)(o) && (o.type === Xa.ElementType.Tag || (0, Ue.isCDATA)(o)) ? Ar(o.children) : (0, Ue.isText)(o) ? o.data : "";
}
var Ve = {};
Object.defineProperty(Ve, "__esModule", { value: !0 });
Ve.getChildren = ts;
Ve.getParent = is;
Ve.getSiblings = Ka;
Ve.getAttributeValue = Ja;
Ve.hasAttrib = Qa;
Ve.getName = el;
Ve.nextElementSibling = tl;
Ve.prevElementSibling = il;
var Kr = nt;
function ts(o) {
  return (0, Kr.hasChildren)(o) ? o.children : [];
}
function is(o) {
  return o.parent || null;
}
function Ka(o) {
  var i, n, r = is(o);
  if (r != null)
    return ts(r);
  for (var a = [o], c = o.prev, p = o.next; c != null; )
    a.unshift(c), i = c, c = i.prev;
  for (; p != null; )
    a.push(p), n = p, p = n.next;
  return a;
}
function Ja(o, i) {
  var n;
  return (n = o.attribs) === null || n === void 0 ? void 0 : n[i];
}
function Qa(o, i) {
  return o.attribs != null && Object.prototype.hasOwnProperty.call(o.attribs, i) && o.attribs[i] != null;
}
function el(o) {
  return o.name;
}
function tl(o) {
  for (var i, n = o.next; n !== null && !(0, Kr.isTag)(n); )
    i = n, n = i.next;
  return n;
}
function il(o) {
  for (var i, n = o.prev; n !== null && !(0, Kr.isTag)(n); )
    i = n, n = i.prev;
  return n;
}
var pt = {};
Object.defineProperty(pt, "__esModule", { value: !0 });
pt.removeElement = Mi;
pt.replaceElement = nl;
pt.appendChild = rl;
pt.append = ul;
pt.prependChild = ol;
pt.prepend = sl;
function Mi(o) {
  if (o.prev && (o.prev.next = o.next), o.next && (o.next.prev = o.prev), o.parent) {
    var i = o.parent.children, n = i.lastIndexOf(o);
    n >= 0 && i.splice(n, 1);
  }
  o.next = null, o.prev = null, o.parent = null;
}
function nl(o, i) {
  var n = i.prev = o.prev;
  n && (n.next = i);
  var r = i.next = o.next;
  r && (r.prev = i);
  var a = i.parent = o.parent;
  if (a) {
    var c = a.children;
    c[c.lastIndexOf(o)] = i, o.parent = null;
  }
}
function rl(o, i) {
  if (Mi(i), i.next = null, i.parent = o, o.children.push(i) > 1) {
    var n = o.children[o.children.length - 2];
    n.next = i, i.prev = n;
  } else
    i.prev = null;
}
function ul(o, i) {
  Mi(i);
  var n = o.parent, r = o.next;
  if (i.next = r, i.prev = o, o.next = i, i.parent = n, r) {
    if (r.prev = i, n) {
      var a = n.children;
      a.splice(a.lastIndexOf(r), 0, i);
    }
  } else
    n && n.children.push(i);
}
function ol(o, i) {
  if (Mi(i), i.parent = o, i.prev = null, o.children.unshift(i) !== 1) {
    var n = o.children[1];
    n.prev = i, i.next = n;
  } else
    i.next = null;
}
function sl(o, i) {
  Mi(i);
  var n = o.parent;
  if (n) {
    var r = n.children;
    r.splice(r.indexOf(o), 0, i);
  }
  o.prev && (o.prev.next = i), i.parent = n, i.prev = o.prev, i.next = o, o.prev = i;
}
var ut = {};
Object.defineProperty(ut, "__esModule", { value: !0 });
ut.filter = al;
ut.find = ns;
ut.findOneChild = ll;
ut.findOne = rs;
ut.existsOne = us;
ut.findAll = cl;
var Lt = nt;
function al(o, i, n, r) {
  return n === void 0 && (n = !0), r === void 0 && (r = 1 / 0), ns(o, Array.isArray(i) ? i : [i], n, r);
}
function ns(o, i, n, r) {
  for (var a = [], c = [Array.isArray(i) ? i : [i]], p = [0]; ; ) {
    if (p[0] >= c[0].length) {
      if (p.length === 1)
        return a;
      c.shift(), p.shift();
      continue;
    }
    var g = c[0][p[0]++];
    if (o(g) && (a.push(g), --r <= 0))
      return a;
    n && (0, Lt.hasChildren)(g) && g.children.length > 0 && (p.unshift(0), c.unshift(g.children));
  }
}
function ll(o, i) {
  return i.find(o);
}
function rs(o, i, n) {
  n === void 0 && (n = !0);
  for (var r = Array.isArray(i) ? i : [i], a = 0; a < r.length; a++) {
    var c = r[a];
    if ((0, Lt.isTag)(c) && o(c))
      return c;
    if (n && (0, Lt.hasChildren)(c) && c.children.length > 0) {
      var p = rs(o, c.children, !0);
      if (p)
        return p;
    }
  }
  return null;
}
function us(o, i) {
  return (Array.isArray(i) ? i : [i]).some(function(n) {
    return (0, Lt.isTag)(n) && o(n) || (0, Lt.hasChildren)(n) && us(o, n.children);
  });
}
function cl(o, i) {
  for (var n = [], r = [Array.isArray(i) ? i : [i]], a = [0]; ; ) {
    if (a[0] >= r[0].length) {
      if (r.length === 1)
        return n;
      r.shift(), a.shift();
      continue;
    }
    var c = r[0][a[0]++];
    (0, Lt.isTag)(c) && o(c) && n.push(c), (0, Lt.hasChildren)(c) && c.children.length > 0 && (a.unshift(0), r.unshift(c.children));
  }
}
var ot = {};
Object.defineProperty(ot, "__esModule", { value: !0 });
ot.testElement = dl;
ot.getElements = fl;
ot.getElementById = pl;
ot.getElementsByTagName = ml;
ot.getElementsByClassName = gl;
ot.getElementsByTagType = _l;
var Tt = nt, Oi = ut, kn = {
  tag_name: function(o) {
    return typeof o == "function" ? function(i) {
      return (0, Tt.isTag)(i) && o(i.name);
    } : o === "*" ? Tt.isTag : function(i) {
      return (0, Tt.isTag)(i) && i.name === o;
    };
  },
  tag_type: function(o) {
    return typeof o == "function" ? function(i) {
      return o(i.type);
    } : function(i) {
      return i.type === o;
    };
  },
  tag_contains: function(o) {
    return typeof o == "function" ? function(i) {
      return (0, Tt.isText)(i) && o(i.data);
    } : function(i) {
      return (0, Tt.isText)(i) && i.data === o;
    };
  }
};
function Jr(o, i) {
  return typeof i == "function" ? function(n) {
    return (0, Tt.isTag)(n) && i(n.attribs[o]);
  } : function(n) {
    return (0, Tt.isTag)(n) && n.attribs[o] === i;
  };
}
function hl(o, i) {
  return function(n) {
    return o(n) || i(n);
  };
}
function os(o) {
  var i = Object.keys(o).map(function(n) {
    var r = o[n];
    return Object.prototype.hasOwnProperty.call(kn, n) ? kn[n](r) : Jr(n, r);
  });
  return i.length === 0 ? null : i.reduce(hl);
}
function dl(o, i) {
  var n = os(o);
  return n ? n(i) : !0;
}
function fl(o, i, n, r) {
  r === void 0 && (r = 1 / 0);
  var a = os(o);
  return a ? (0, Oi.filter)(a, i, n, r) : [];
}
function pl(o, i, n) {
  return n === void 0 && (n = !0), Array.isArray(i) || (i = [i]), (0, Oi.findOne)(Jr("id", o), i, n);
}
function ml(o, i, n, r) {
  return n === void 0 && (n = !0), r === void 0 && (r = 1 / 0), (0, Oi.filter)(kn.tag_name(o), i, n, r);
}
function gl(o, i, n, r) {
  return n === void 0 && (n = !0), r === void 0 && (r = 1 / 0), (0, Oi.filter)(Jr("class", o), i, n, r);
}
function _l(o, i, n, r) {
  return n === void 0 && (n = !0), r === void 0 && (r = 1 / 0), (0, Oi.filter)(kn.tag_type(o), i, n, r);
}
var Pt = {};
Object.defineProperty(Pt, "__esModule", { value: !0 });
Pt.DocumentPosition = void 0;
Pt.removeSubsets = bl;
Pt.compareDocumentPosition = ss;
Pt.uniqueSort = yl;
var uo = nt;
function bl(o) {
  for (var i = o.length; --i >= 0; ) {
    var n = o[i];
    if (i > 0 && o.lastIndexOf(n, i - 1) >= 0) {
      o.splice(i, 1);
      continue;
    }
    for (var r = n.parent; r; r = r.parent)
      if (o.includes(r)) {
        o.splice(i, 1);
        break;
      }
  }
  return o;
}
var je;
(function(o) {
  o[o.DISCONNECTED = 1] = "DISCONNECTED", o[o.PRECEDING = 2] = "PRECEDING", o[o.FOLLOWING = 4] = "FOLLOWING", o[o.CONTAINS = 8] = "CONTAINS", o[o.CONTAINED_BY = 16] = "CONTAINED_BY";
})(je || (Pt.DocumentPosition = je = {}));
function ss(o, i) {
  var n = [], r = [];
  if (o === i)
    return 0;
  for (var a = (0, uo.hasChildren)(o) ? o : o.parent; a; )
    n.unshift(a), a = a.parent;
  for (a = (0, uo.hasChildren)(i) ? i : i.parent; a; )
    r.unshift(a), a = a.parent;
  for (var c = Math.min(n.length, r.length), p = 0; p < c && n[p] === r[p]; )
    p++;
  if (p === 0)
    return je.DISCONNECTED;
  var g = n[p - 1], d = g.children, _ = n[p], v = r[p];
  return d.indexOf(_) > d.indexOf(v) ? g === i ? je.FOLLOWING | je.CONTAINED_BY : je.FOLLOWING : g === o ? je.PRECEDING | je.CONTAINS : je.PRECEDING;
}
function yl(o) {
  return o = o.filter(function(i, n, r) {
    return !r.includes(i, n + 1);
  }), o.sort(function(i, n) {
    var r = ss(i, n);
    return r & je.PRECEDING ? -1 : r & je.FOLLOWING ? 1 : 0;
  }), o;
}
var Qr = {};
Object.defineProperty(Qr, "__esModule", { value: !0 });
Qr.getFeed = xl;
var vl = ft, Ii = ot;
function xl(o) {
  var i = Nn(Pl, o);
  return i ? i.name === "feed" ? wl(i) : Tl(i) : null;
}
function wl(o) {
  var i, n = o.children, r = {
    type: "atom",
    items: (0, Ii.getElementsByTagName)("entry", n).map(function(p) {
      var g, d = p.children, _ = { media: as(d) };
      Me(_, "id", "id", d), Me(_, "title", "title", d);
      var v = (g = Nn("link", d)) === null || g === void 0 ? void 0 : g.attribs.href;
      v && (_.link = v);
      var S = ht("summary", d) || ht("content", d);
      S && (_.description = S);
      var f = ht("updated", d);
      return f && (_.pubDate = new Date(f)), _;
    })
  };
  Me(r, "id", "id", n), Me(r, "title", "title", n);
  var a = (i = Nn("link", n)) === null || i === void 0 ? void 0 : i.attribs.href;
  a && (r.link = a), Me(r, "description", "subtitle", n);
  var c = ht("updated", n);
  return c && (r.updated = new Date(c)), Me(r, "author", "email", n, !0), r;
}
function Tl(o) {
  var i, n, r = (n = (i = Nn("channel", o.children)) === null || i === void 0 ? void 0 : i.children) !== null && n !== void 0 ? n : [], a = {
    type: o.name.substr(0, 3),
    id: "",
    items: (0, Ii.getElementsByTagName)("item", o.children).map(function(p) {
      var g = p.children, d = { media: as(g) };
      Me(d, "id", "guid", g), Me(d, "title", "title", g), Me(d, "link", "link", g), Me(d, "description", "description", g);
      var _ = ht("pubDate", g) || ht("dc:date", g);
      return _ && (d.pubDate = new Date(_)), d;
    })
  };
  Me(a, "title", "title", r), Me(a, "link", "link", r), Me(a, "description", "description", r);
  var c = ht("lastBuildDate", r);
  return c && (a.updated = new Date(c)), Me(a, "author", "managingEditor", r, !0), a;
}
var Sl = ["url", "type", "lang"], Ll = [
  "fileSize",
  "bitrate",
  "framerate",
  "samplingrate",
  "channels",
  "duration",
  "height",
  "width"
];
function as(o) {
  return (0, Ii.getElementsByTagName)("media:content", o).map(function(i) {
    for (var n = i.attribs, r = {
      medium: n.medium,
      isDefault: !!n.isDefault
    }, a = 0, c = Sl; a < c.length; a++) {
      var p = c[a];
      n[p] && (r[p] = n[p]);
    }
    for (var g = 0, d = Ll; g < d.length; g++) {
      var p = d[g];
      n[p] && (r[p] = parseInt(n[p], 10));
    }
    return n.expression && (r.expression = n.expression), r;
  });
}
function Nn(o, i) {
  return (0, Ii.getElementsByTagName)(o, i, !0, 1)[0];
}
function ht(o, i, n) {
  return n === void 0 && (n = !1), (0, vl.textContent)((0, Ii.getElementsByTagName)(o, i, n, 1)).trim();
}
function Me(o, i, n, r, a) {
  a === void 0 && (a = !1);
  var c = ht(n, r, a);
  c && (o[i] = c);
}
function Pl(o) {
  return o === "rss" || o === "feed" || o === "rdf:RDF";
}
(function(o) {
  var i = W && W.__createBinding || (Object.create ? function(a, c, p, g) {
    g === void 0 && (g = p);
    var d = Object.getOwnPropertyDescriptor(c, p);
    (!d || ("get" in d ? !c.__esModule : d.writable || d.configurable)) && (d = { enumerable: !0, get: function() {
      return c[p];
    } }), Object.defineProperty(a, g, d);
  } : function(a, c, p, g) {
    g === void 0 && (g = p), a[g] = c[p];
  }), n = W && W.__exportStar || function(a, c) {
    for (var p in a)
      p !== "default" && !Object.prototype.hasOwnProperty.call(c, p) && i(c, a, p);
  };
  Object.defineProperty(o, "__esModule", { value: !0 }), o.hasChildren = o.isDocument = o.isComment = o.isText = o.isCDATA = o.isTag = void 0, n(ft, o), n(Ve, o), n(pt, o), n(ut, o), n(ot, o), n(Pt, o), n(Qr, o);
  var r = nt;
  Object.defineProperty(o, "isTag", { enumerable: !0, get: function() {
    return r.isTag;
  } }), Object.defineProperty(o, "isCDATA", { enumerable: !0, get: function() {
    return r.isCDATA;
  } }), Object.defineProperty(o, "isText", { enumerable: !0, get: function() {
    return r.isText;
  } }), Object.defineProperty(o, "isComment", { enumerable: !0, get: function() {
    return r.isComment;
  } }), Object.defineProperty(o, "isDocument", { enumerable: !0, get: function() {
    return r.isDocument;
  } }), Object.defineProperty(o, "hasChildren", { enumerable: !0, get: function() {
    return r.hasChildren;
  } });
})(Ln);
(function(o) {
  var i = W && W.__createBinding || (Object.create ? function(z, H, U, G) {
    G === void 0 && (G = U);
    var re = Object.getOwnPropertyDescriptor(H, U);
    (!re || ("get" in re ? !H.__esModule : re.writable || re.configurable)) && (re = { enumerable: !0, get: function() {
      return H[U];
    } }), Object.defineProperty(z, G, re);
  } : function(z, H, U, G) {
    G === void 0 && (G = U), z[G] = H[U];
  }), n = W && W.__setModuleDefault || (Object.create ? function(z, H) {
    Object.defineProperty(z, "default", { enumerable: !0, value: H });
  } : function(z, H) {
    z.default = H;
  }), r = W && W.__importStar || function(z) {
    if (z && z.__esModule)
      return z;
    var H = {};
    if (z != null)
      for (var U in z)
        U !== "default" && Object.prototype.hasOwnProperty.call(z, U) && i(H, z, U);
    return n(H, z), H;
  }, a = W && W.__importDefault || function(z) {
    return z && z.__esModule ? z : { default: z };
  };
  Object.defineProperty(o, "__esModule", { value: !0 }), o.DomUtils = o.parseFeed = o.getFeed = o.ElementType = o.Tokenizer = o.createDomStream = o.parseDOM = o.parseDocument = o.DefaultHandler = o.DomHandler = o.Parser = void 0;
  var c = yi, p = yi;
  Object.defineProperty(o, "Parser", { enumerable: !0, get: function() {
    return p.Parser;
  } });
  var g = nt, d = nt;
  Object.defineProperty(o, "DomHandler", { enumerable: !0, get: function() {
    return d.DomHandler;
  } }), Object.defineProperty(o, "DefaultHandler", { enumerable: !0, get: function() {
    return d.DomHandler;
  } });
  function _(z, H) {
    var U = new g.DomHandler(void 0, H);
    return new c.Parser(U, H).end(z), U.root;
  }
  o.parseDocument = _;
  function v(z, H) {
    return _(z, H).children;
  }
  o.parseDOM = v;
  function S(z, H, U) {
    var G = new g.DomHandler(z, H, U);
    return new c.Parser(G, H);
  }
  o.createDomStream = S;
  var f = Vr;
  Object.defineProperty(o, "Tokenizer", { enumerable: !0, get: function() {
    return a(f).default;
  } }), o.ElementType = r(Yt);
  var m = Ln, N = Ln;
  Object.defineProperty(o, "getFeed", { enumerable: !0, get: function() {
    return N.getFeed;
  } });
  var I = { xmlMode: !0 };
  function E(z, H) {
    return H === void 0 && (H = I), (0, m.getFeed)(v(z, H));
  }
  o.parseFeed = E, o.DomUtils = r(Ln);
})(zo);
var El = (o) => {
  if (typeof o != "string")
    throw new TypeError("Expected a string");
  return o.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}, eu = {};
Object.defineProperty(eu, "__esModule", { value: !0 });
/*!
 * is-plain-object <https://github.com/jonschlinkert/is-plain-object>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */
function oo(o) {
  return Object.prototype.toString.call(o) === "[object Object]";
}
function Al(o) {
  var i, n;
  return oo(o) === !1 ? !1 : (i = o.constructor, i === void 0 ? !0 : (n = i.prototype, !(oo(n) === !1 || n.hasOwnProperty("isPrototypeOf") === !1)));
}
eu.isPlainObject = Al;
var Cl = function(i) {
  return Ml(i) && !Ol(i);
};
function Ml(o) {
  return !!o && typeof o == "object";
}
function Ol(o) {
  var i = Object.prototype.toString.call(o);
  return i === "[object RegExp]" || i === "[object Date]" || Nl(o);
}
var Il = typeof Symbol == "function" && Symbol.for, kl = Il ? Symbol.for("react.element") : 60103;
function Nl(o) {
  return o.$$typeof === kl;
}
function Dl(o) {
  return Array.isArray(o) ? [] : {};
}
function xi(o, i) {
  return i.clone !== !1 && i.isMergeableObject(o) ? Wt(Dl(o), o, i) : o;
}
function Bl(o, i, n) {
  return o.concat(i).map(function(r) {
    return xi(r, n);
  });
}
function zl(o, i) {
  if (!i.customMerge)
    return Wt;
  var n = i.customMerge(o);
  return typeof n == "function" ? n : Wt;
}
function Rl(o) {
  return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(o).filter(function(i) {
    return Object.propertyIsEnumerable.call(o, i);
  }) : [];
}
function so(o) {
  return Object.keys(o).concat(Rl(o));
}
function ls(o, i) {
  try {
    return i in o;
  } catch {
    return !1;
  }
}
function jl(o, i) {
  return ls(o, i) && !(Object.hasOwnProperty.call(o, i) && Object.propertyIsEnumerable.call(o, i));
}
function ql(o, i, n) {
  var r = {};
  return n.isMergeableObject(o) && so(o).forEach(function(a) {
    r[a] = xi(o[a], n);
  }), so(i).forEach(function(a) {
    jl(o, a) || (ls(o, a) && n.isMergeableObject(i[a]) ? r[a] = zl(a, n)(o[a], i[a], n) : r[a] = xi(i[a], n));
  }), r;
}
function Wt(o, i, n) {
  n = n || {}, n.arrayMerge = n.arrayMerge || Bl, n.isMergeableObject = n.isMergeableObject || Cl, n.cloneUnlessOtherwiseSpecified = xi;
  var r = Array.isArray(i), a = Array.isArray(o), c = r === a;
  return c ? r ? n.arrayMerge(o, i, n) : ql(o, i, n) : xi(i, n);
}
Wt.all = function(i, n) {
  if (!Array.isArray(i))
    throw new Error("first argument should be an array");
  return i.reduce(function(r, a) {
    return Wt(r, a, n);
  }, {});
};
var Zl = Wt, Fl = Zl, cs = { exports: {} };
(function(o) {
  (function(i, n) {
    o.exports ? o.exports = n() : i.parseSrcset = n();
  })(W, function() {
    return function(i) {
      function n(G) {
        return G === " " || // space
        G === "	" || // horizontal tab
        G === `
` || // new line
        G === "\f" || // form feed
        G === "\r";
      }
      function r(G) {
        var re, he = G.exec(i.substring(E));
        if (he)
          return re = he[0], E += re.length, re;
      }
      for (var a = i.length, c = /^[ \t\n\r\u000c]+/, p = /^[, \t\n\r\u000c]+/, g = /^[^ \t\n\r\u000c]+/, d = /[,]+$/, _ = /^\d+$/, v = /^-?(?:[0-9]+|[0-9]*\.[0-9]+)(?:[eE][+-]?[0-9]+)?$/, S, f, m, N, I, E = 0, z = []; ; ) {
        if (r(p), E >= a)
          return z;
        S = r(g), f = [], S.slice(-1) === "," ? (S = S.replace(d, ""), U()) : H();
      }
      function H() {
        for (r(c), m = "", N = "in descriptor"; ; ) {
          if (I = i.charAt(E), N === "in descriptor")
            if (n(I))
              m && (f.push(m), m = "", N = "after descriptor");
            else if (I === ",") {
              E += 1, m && f.push(m), U();
              return;
            } else if (I === "(")
              m = m + I, N = "in parens";
            else if (I === "") {
              m && f.push(m), U();
              return;
            } else
              m = m + I;
          else if (N === "in parens")
            if (I === ")")
              m = m + I, N = "in descriptor";
            else if (I === "") {
              f.push(m), U();
              return;
            } else
              m = m + I;
          else if (N === "after descriptor" && !n(I))
            if (I === "") {
              U();
              return;
            } else
              N = "in descriptor", E -= 1;
          E += 1;
        }
      }
      function U() {
        var G = !1, re, he, Le, se, be = {}, xe, T, A, D, Z;
        for (se = 0; se < f.length; se++)
          xe = f[se], T = xe[xe.length - 1], A = xe.substring(0, xe.length - 1), D = parseInt(A, 10), Z = parseFloat(A), _.test(A) && T === "w" ? ((re || he) && (G = !0), D === 0 ? G = !0 : re = D) : v.test(A) && T === "x" ? ((re || he || Le) && (G = !0), Z < 0 ? G = !0 : he = Z) : _.test(A) && T === "h" ? ((Le || he) && (G = !0), D === 0 ? G = !0 : Le = D) : G = !0;
        G ? console && console.log && console.log("Invalid srcset descriptor found in '" + i + "' at '" + xe + "'.") : (be.url = S, re && (be.w = re), he && (be.d = he), Le && (be.h = Le), z.push(be));
      }
    };
  });
})(cs);
var Hl = cs.exports, tu = { exports: {} }, ee = String, hs = function() {
  return { isColorSupported: !1, reset: ee, bold: ee, dim: ee, italic: ee, underline: ee, inverse: ee, hidden: ee, strikethrough: ee, black: ee, red: ee, green: ee, yellow: ee, blue: ee, magenta: ee, cyan: ee, white: ee, gray: ee, bgBlack: ee, bgRed: ee, bgGreen: ee, bgYellow: ee, bgBlue: ee, bgMagenta: ee, bgCyan: ee, bgWhite: ee, blackBright: ee, redBright: ee, greenBright: ee, yellowBright: ee, blueBright: ee, magentaBright: ee, cyanBright: ee, whiteBright: ee, bgBlackBright: ee, bgRedBright: ee, bgGreenBright: ee, bgYellowBright: ee, bgBlueBright: ee, bgMagentaBright: ee, bgCyanBright: ee, bgWhiteBright: ee };
};
tu.exports = hs();
tu.exports.createColors = hs;
var Ul = tu.exports;
let ao = Ul, lo = qe, Cr = class ds extends Error {
  constructor(i, n, r, a, c, p) {
    super(i), this.name = "CssSyntaxError", this.reason = i, c && (this.file = c), a && (this.source = a), p && (this.plugin = p), typeof n < "u" && typeof r < "u" && (typeof n == "number" ? (this.line = n, this.column = r) : (this.line = n.line, this.column = n.column, this.endLine = r.line, this.endColumn = r.column)), this.setMessage(), Error.captureStackTrace && Error.captureStackTrace(this, ds);
  }
  setMessage() {
    this.message = this.plugin ? this.plugin + ": " : "", this.message += this.file ? this.file : "<css input>", typeof this.line < "u" && (this.message += ":" + this.line + ":" + this.column), this.message += ": " + this.reason;
  }
  showSourceCode(i) {
    if (!this.source)
      return "";
    let n = this.source;
    i == null && (i = ao.isColorSupported);
    let r = (v) => v, a = (v) => v, c = (v) => v;
    if (i) {
      let { bold: v, gray: S, red: f } = ao.createColors(!0);
      a = (m) => v(f(m)), r = (m) => S(m), lo && (c = (m) => lo(m));
    }
    let p = n.split(/\r?\n/), g = Math.max(this.line - 3, 0), d = Math.min(this.line + 2, p.length), _ = String(d).length;
    return p.slice(g, d).map((v, S) => {
      let f = g + 1 + S, m = " " + (" " + f).slice(-_) + " | ";
      if (f === this.line) {
        if (v.length > 160) {
          let I = 20, E = Math.max(0, this.column - I), z = Math.max(
            this.column + I,
            this.endColumn + I
          ), H = v.slice(E, z), U = r(m.replace(/\d/g, " ")) + v.slice(0, Math.min(this.column - 1, I - 1)).replace(/[^\t]/g, " ");
          return a(">") + r(m) + c(H) + `
 ` + U + a("^");
        }
        let N = r(m.replace(/\d/g, " ")) + v.slice(0, this.column - 1).replace(/[^\t]/g, " ");
        return a(">") + r(m) + c(v) + `
 ` + N + a("^");
      }
      return " " + r(m) + c(v);
    }).join(`
`);
  }
  toString() {
    let i = this.showSourceCode();
    return i && (i = `

` + i + `
`), this.name + ": " + this.message + i;
  }
};
var iu = Cr;
Cr.default = Cr;
const co = {
  after: `
`,
  beforeClose: `
`,
  beforeComment: `
`,
  beforeDecl: `
`,
  beforeOpen: " ",
  beforeRule: `
`,
  colon: ": ",
  commentLeft: " ",
  commentRight: " ",
  emptyBody: "",
  indent: "    ",
  semicolon: !1
};
function Vl(o) {
  return o[0].toUpperCase() + o.slice(1);
}
let Mr = class {
  constructor(i) {
    this.builder = i;
  }
  atrule(i, n) {
    let r = "@" + i.name, a = i.params ? this.rawValue(i, "params") : "";
    if (typeof i.raws.afterName < "u" ? r += i.raws.afterName : a && (r += " "), i.nodes)
      this.block(i, r + a);
    else {
      let c = (i.raws.between || "") + (n ? ";" : "");
      this.builder(r + a + c, i);
    }
  }
  beforeAfter(i, n) {
    let r;
    i.type === "decl" ? r = this.raw(i, null, "beforeDecl") : i.type === "comment" ? r = this.raw(i, null, "beforeComment") : n === "before" ? r = this.raw(i, null, "beforeRule") : r = this.raw(i, null, "beforeClose");
    let a = i.parent, c = 0;
    for (; a && a.type !== "root"; )
      c += 1, a = a.parent;
    if (r.includes(`
`)) {
      let p = this.raw(i, null, "indent");
      if (p.length)
        for (let g = 0; g < c; g++)
          r += p;
    }
    return r;
  }
  block(i, n) {
    let r = this.raw(i, "between", "beforeOpen");
    this.builder(n + r + "{", i, "start");
    let a;
    i.nodes && i.nodes.length ? (this.body(i), a = this.raw(i, "after")) : a = this.raw(i, "after", "emptyBody"), a && this.builder(a), this.builder("}", i, "end");
  }
  body(i) {
    let n = i.nodes.length - 1;
    for (; n > 0 && i.nodes[n].type === "comment"; )
      n -= 1;
    let r = this.raw(i, "semicolon");
    for (let a = 0; a < i.nodes.length; a++) {
      let c = i.nodes[a], p = this.raw(c, "before");
      p && this.builder(p), this.stringify(c, n !== a || r);
    }
  }
  comment(i) {
    let n = this.raw(i, "left", "commentLeft"), r = this.raw(i, "right", "commentRight");
    this.builder("/*" + n + i.text + r + "*/", i);
  }
  decl(i, n) {
    let r = this.raw(i, "between", "colon"), a = i.prop + r + this.rawValue(i, "value");
    i.important && (a += i.raws.important || " !important"), n && (a += ";"), this.builder(a, i);
  }
  document(i) {
    this.body(i);
  }
  raw(i, n, r) {
    let a;
    if (r || (r = n), n && (a = i.raws[n], typeof a < "u"))
      return a;
    let c = i.parent;
    if (r === "before" && (!c || c.type === "root" && c.first === i || c && c.type === "document"))
      return "";
    if (!c)
      return co[r];
    let p = i.root();
    if (p.rawCache || (p.rawCache = {}), typeof p.rawCache[r] < "u")
      return p.rawCache[r];
    if (r === "before" || r === "after")
      return this.beforeAfter(i, r);
    {
      let g = "raw" + Vl(r);
      this[g] ? a = this[g](p, i) : p.walk((d) => {
        if (a = d.raws[n], typeof a < "u")
          return !1;
      });
    }
    return typeof a > "u" && (a = co[r]), p.rawCache[r] = a, a;
  }
  rawBeforeClose(i) {
    let n;
    return i.walk((r) => {
      if (r.nodes && r.nodes.length > 0 && typeof r.raws.after < "u")
        return n = r.raws.after, n.includes(`
`) && (n = n.replace(/[^\n]+$/, "")), !1;
    }), n && (n = n.replace(/\S/g, "")), n;
  }
  rawBeforeComment(i, n) {
    let r;
    return i.walkComments((a) => {
      if (typeof a.raws.before < "u")
        return r = a.raws.before, r.includes(`
`) && (r = r.replace(/[^\n]+$/, "")), !1;
    }), typeof r > "u" ? r = this.raw(n, null, "beforeDecl") : r && (r = r.replace(/\S/g, "")), r;
  }
  rawBeforeDecl(i, n) {
    let r;
    return i.walkDecls((a) => {
      if (typeof a.raws.before < "u")
        return r = a.raws.before, r.includes(`
`) && (r = r.replace(/[^\n]+$/, "")), !1;
    }), typeof r > "u" ? r = this.raw(n, null, "beforeRule") : r && (r = r.replace(/\S/g, "")), r;
  }
  rawBeforeOpen(i) {
    let n;
    return i.walk((r) => {
      if (r.type !== "decl" && (n = r.raws.between, typeof n < "u"))
        return !1;
    }), n;
  }
  rawBeforeRule(i) {
    let n;
    return i.walk((r) => {
      if (r.nodes && (r.parent !== i || i.first !== r) && typeof r.raws.before < "u")
        return n = r.raws.before, n.includes(`
`) && (n = n.replace(/[^\n]+$/, "")), !1;
    }), n && (n = n.replace(/\S/g, "")), n;
  }
  rawColon(i) {
    let n;
    return i.walkDecls((r) => {
      if (typeof r.raws.between < "u")
        return n = r.raws.between.replace(/[^\s:]/g, ""), !1;
    }), n;
  }
  rawEmptyBody(i) {
    let n;
    return i.walk((r) => {
      if (r.nodes && r.nodes.length === 0 && (n = r.raws.after, typeof n < "u"))
        return !1;
    }), n;
  }
  rawIndent(i) {
    if (i.raws.indent)
      return i.raws.indent;
    let n;
    return i.walk((r) => {
      let a = r.parent;
      if (a && a !== i && a.parent && a.parent === i && typeof r.raws.before < "u") {
        let c = r.raws.before.split(`
`);
        return n = c[c.length - 1], n = n.replace(/\S/g, ""), !1;
      }
    }), n;
  }
  rawSemicolon(i) {
    let n;
    return i.walk((r) => {
      if (r.nodes && r.nodes.length && r.last.type === "decl" && (n = r.raws.semicolon, typeof n < "u"))
        return !1;
    }), n;
  }
  rawValue(i, n) {
    let r = i[n], a = i.raws[n];
    return a && a.value === r ? a.raw : r;
  }
  root(i) {
    this.body(i), i.raws.after && this.builder(i.raws.after);
  }
  rule(i) {
    this.block(i, this.rawValue(i, "selector")), i.raws.ownSemicolon && this.builder(i.raws.ownSemicolon, i, "end");
  }
  stringify(i, n) {
    if (!this[i.type])
      throw new Error(
        "Unknown AST node type " + i.type + ". Maybe you need to change PostCSS stringifier."
      );
    this[i.type](i, n);
  }
};
var fs = Mr;
Mr.default = Mr;
let Wl = fs;
function Or(o, i) {
  new Wl(i).stringify(o);
}
var Fn = Or;
Or.default = Or;
var ki = {};
ki.isClean = Symbol("isClean");
ki.my = Symbol("my");
let Gl = iu, $l = fs, Xl = Fn, { isClean: fi, my: Yl } = ki;
function Ir(o, i) {
  let n = new o.constructor();
  for (let r in o) {
    if (!Object.prototype.hasOwnProperty.call(o, r) || r === "proxyCache")
      continue;
    let a = o[r], c = typeof a;
    r === "parent" && c === "object" ? i && (n[r] = i) : r === "source" ? n[r] = a : Array.isArray(a) ? n[r] = a.map((p) => Ir(p, n)) : (c === "object" && a !== null && (a = Ir(a)), n[r] = a);
  }
  return n;
}
function et(o, i) {
  if (i && typeof i.offset < "u")
    return i.offset;
  let n = 1, r = 1, a = 0;
  for (let c = 0; c < o.length; c++) {
    if (r === i.line && n === i.column) {
      a = c;
      break;
    }
    o[c] === `
` ? (n = 1, r += 1) : n += 1;
  }
  return a;
}
let kr = class {
  get proxyOf() {
    return this;
  }
  constructor(i = {}) {
    this.raws = {}, this[fi] = !1, this[Yl] = !0;
    for (let n in i)
      if (n === "nodes") {
        this.nodes = [];
        for (let r of i[n])
          typeof r.clone == "function" ? this.append(r.clone()) : this.append(r);
      } else
        this[n] = i[n];
  }
  addToError(i) {
    if (i.postcssNode = this, i.stack && this.source && /\n\s{4}at /.test(i.stack)) {
      let n = this.source;
      i.stack = i.stack.replace(
        /\n\s{4}at /,
        `$&${n.input.from}:${n.start.line}:${n.start.column}$&`
      );
    }
    return i;
  }
  after(i) {
    return this.parent.insertAfter(this, i), this;
  }
  assign(i = {}) {
    for (let n in i)
      this[n] = i[n];
    return this;
  }
  before(i) {
    return this.parent.insertBefore(this, i), this;
  }
  cleanRaws(i) {
    delete this.raws.before, delete this.raws.after, i || delete this.raws.between;
  }
  clone(i = {}) {
    let n = Ir(this);
    for (let r in i)
      n[r] = i[r];
    return n;
  }
  cloneAfter(i = {}) {
    let n = this.clone(i);
    return this.parent.insertAfter(this, n), n;
  }
  cloneBefore(i = {}) {
    let n = this.clone(i);
    return this.parent.insertBefore(this, n), n;
  }
  error(i, n = {}) {
    if (this.source) {
      let { end: r, start: a } = this.rangeBy(n);
      return this.source.input.error(
        i,
        { column: a.column, line: a.line },
        { column: r.column, line: r.line },
        n
      );
    }
    return new Gl(i);
  }
  getProxyProcessor() {
    return {
      get(i, n) {
        return n === "proxyOf" ? i : n === "root" ? () => i.root().toProxy() : i[n];
      },
      set(i, n, r) {
        return i[n] === r || (i[n] = r, (n === "prop" || n === "value" || n === "name" || n === "params" || n === "important" || /* c8 ignore next */
        n === "text") && i.markDirty()), !0;
      }
    };
  }
  /* c8 ignore next 3 */
  markClean() {
    this[fi] = !0;
  }
  markDirty() {
    if (this[fi]) {
      this[fi] = !1;
      let i = this;
      for (; i = i.parent; )
        i[fi] = !1;
    }
  }
  next() {
    if (!this.parent)
      return;
    let i = this.parent.index(this);
    return this.parent.nodes[i + 1];
  }
  positionBy(i = {}) {
    let n = this.source.start;
    if (i.index)
      n = this.positionInside(i.index);
    else if (i.word) {
      let r = "document" in this.source.input ? this.source.input.document : this.source.input.css, c = r.slice(
        et(r, this.source.start),
        et(r, this.source.end)
      ).indexOf(i.word);
      c !== -1 && (n = this.positionInside(c));
    }
    return n;
  }
  positionInside(i) {
    let n = this.source.start.column, r = this.source.start.line, a = "document" in this.source.input ? this.source.input.document : this.source.input.css, c = et(a, this.source.start), p = c + i;
    for (let g = c; g < p; g++)
      a[g] === `
` ? (n = 1, r += 1) : n += 1;
    return { column: n, line: r, offset: p };
  }
  prev() {
    if (!this.parent)
      return;
    let i = this.parent.index(this);
    return this.parent.nodes[i - 1];
  }
  rangeBy(i = {}) {
    let n = "document" in this.source.input ? this.source.input.document : this.source.input.css, r = {
      column: this.source.start.column,
      line: this.source.start.line,
      offset: et(n, this.source.start)
    }, a = this.source.end ? {
      column: this.source.end.column + 1,
      line: this.source.end.line,
      offset: typeof this.source.end.offset == "number" ? (
        // `source.end.offset` is exclusive, so we don't need to add 1
        this.source.end.offset
      ) : (
        // Since line/column in this.source.end is inclusive,
        // the `sourceOffset(... , this.source.end)` returns an inclusive offset.
        // So, we add 1 to convert it to exclusive.
        et(n, this.source.end) + 1
      )
    } : {
      column: r.column + 1,
      line: r.line,
      offset: r.offset + 1
    };
    if (i.word) {
      let p = n.slice(
        et(n, this.source.start),
        et(n, this.source.end)
      ).indexOf(i.word);
      p !== -1 && (r = this.positionInside(p), a = this.positionInside(p + i.word.length));
    } else
      i.start ? r = {
        column: i.start.column,
        line: i.start.line,
        offset: et(n, i.start)
      } : i.index && (r = this.positionInside(i.index)), i.end ? a = {
        column: i.end.column,
        line: i.end.line,
        offset: et(n, i.end)
      } : typeof i.endIndex == "number" ? a = this.positionInside(i.endIndex) : i.index && (a = this.positionInside(i.index + 1));
    return (a.line < r.line || a.line === r.line && a.column <= r.column) && (a = {
      column: r.column + 1,
      line: r.line,
      offset: r.offset + 1
    }), { end: a, start: r };
  }
  raw(i, n) {
    return new $l().raw(this, i, n);
  }
  remove() {
    return this.parent && this.parent.removeChild(this), this.parent = void 0, this;
  }
  replaceWith(...i) {
    if (this.parent) {
      let n = this, r = !1;
      for (let a of i)
        a === this ? r = !0 : r ? (this.parent.insertAfter(n, a), n = a) : this.parent.insertBefore(n, a);
      r || this.remove();
    }
    return this;
  }
  root() {
    let i = this;
    for (; i.parent && i.parent.type !== "document"; )
      i = i.parent;
    return i;
  }
  toJSON(i, n) {
    let r = {}, a = n == null;
    n = n || /* @__PURE__ */ new Map();
    let c = 0;
    for (let p in this) {
      if (!Object.prototype.hasOwnProperty.call(this, p) || p === "parent" || p === "proxyCache")
        continue;
      let g = this[p];
      if (Array.isArray(g))
        r[p] = g.map((d) => typeof d == "object" && d.toJSON ? d.toJSON(null, n) : d);
      else if (typeof g == "object" && g.toJSON)
        r[p] = g.toJSON(null, n);
      else if (p === "source") {
        if (g == null)
          continue;
        let d = n.get(g.input);
        d == null && (d = c, n.set(g.input, c), c++), r[p] = {
          end: g.end,
          inputId: d,
          start: g.start
        };
      } else
        r[p] = g;
    }
    return a && (r.inputs = [...n.keys()].map((p) => p.toJSON())), r;
  }
  toProxy() {
    return this.proxyCache || (this.proxyCache = new Proxy(this, this.getProxyProcessor())), this.proxyCache;
  }
  toString(i = Xl) {
    i.stringify && (i = i.stringify);
    let n = "";
    return i(this, (r) => {
      n += r;
    }), n;
  }
  warn(i, n, r = {}) {
    let a = { node: this };
    for (let c in r)
      a[c] = r[c];
    return i.warn(n, a);
  }
};
var Hn = kr;
kr.default = kr;
let Kl = Hn, Nr = class extends Kl {
  constructor(i) {
    super(i), this.type = "comment";
  }
};
var Un = Nr;
Nr.default = Nr;
let Jl = Hn, Dr = class extends Jl {
  get variable() {
    return this.prop.startsWith("--") || this.prop[0] === "$";
  }
  constructor(i) {
    i && typeof i.value < "u" && typeof i.value != "string" && (i = { ...i, value: String(i.value) }), super(i), this.type = "decl";
  }
};
var Vn = Dr;
Dr.default = Dr;
let ps = Un, ms = Vn, Ql = Hn, { isClean: gs, my: _s } = ki, nu, bs, ys, ru;
function vs(o) {
  return o.map((i) => (i.nodes && (i.nodes = vs(i.nodes)), delete i.source, i));
}
function xs(o) {
  if (o[gs] = !1, o.proxyOf.nodes)
    for (let i of o.proxyOf.nodes)
      xs(i);
}
let rt = class ws extends Ql {
  get first() {
    if (this.proxyOf.nodes)
      return this.proxyOf.nodes[0];
  }
  get last() {
    if (this.proxyOf.nodes)
      return this.proxyOf.nodes[this.proxyOf.nodes.length - 1];
  }
  append(...i) {
    for (let n of i) {
      let r = this.normalize(n, this.last);
      for (let a of r)
        this.proxyOf.nodes.push(a);
    }
    return this.markDirty(), this;
  }
  cleanRaws(i) {
    if (super.cleanRaws(i), this.nodes)
      for (let n of this.nodes)
        n.cleanRaws(i);
  }
  each(i) {
    if (!this.proxyOf.nodes)
      return;
    let n = this.getIterator(), r, a;
    for (; this.indexes[n] < this.proxyOf.nodes.length && (r = this.indexes[n], a = i(this.proxyOf.nodes[r], r), a !== !1); )
      this.indexes[n] += 1;
    return delete this.indexes[n], a;
  }
  every(i) {
    return this.nodes.every(i);
  }
  getIterator() {
    this.lastEach || (this.lastEach = 0), this.indexes || (this.indexes = {}), this.lastEach += 1;
    let i = this.lastEach;
    return this.indexes[i] = 0, i;
  }
  getProxyProcessor() {
    return {
      get(i, n) {
        return n === "proxyOf" ? i : i[n] ? n === "each" || typeof n == "string" && n.startsWith("walk") ? (...r) => i[n](
          ...r.map((a) => typeof a == "function" ? (c, p) => a(c.toProxy(), p) : a)
        ) : n === "every" || n === "some" ? (r) => i[n](
          (a, ...c) => r(a.toProxy(), ...c)
        ) : n === "root" ? () => i.root().toProxy() : n === "nodes" ? i.nodes.map((r) => r.toProxy()) : n === "first" || n === "last" ? i[n].toProxy() : i[n] : i[n];
      },
      set(i, n, r) {
        return i[n] === r || (i[n] = r, (n === "name" || n === "params" || n === "selector") && i.markDirty()), !0;
      }
    };
  }
  index(i) {
    return typeof i == "number" ? i : (i.proxyOf && (i = i.proxyOf), this.proxyOf.nodes.indexOf(i));
  }
  insertAfter(i, n) {
    let r = this.index(i), a = this.normalize(n, this.proxyOf.nodes[r]).reverse();
    r = this.index(i);
    for (let p of a)
      this.proxyOf.nodes.splice(r + 1, 0, p);
    let c;
    for (let p in this.indexes)
      c = this.indexes[p], r < c && (this.indexes[p] = c + a.length);
    return this.markDirty(), this;
  }
  insertBefore(i, n) {
    let r = this.index(i), a = r === 0 ? "prepend" : !1, c = this.normalize(
      n,
      this.proxyOf.nodes[r],
      a
    ).reverse();
    r = this.index(i);
    for (let g of c)
      this.proxyOf.nodes.splice(r, 0, g);
    let p;
    for (let g in this.indexes)
      p = this.indexes[g], r <= p && (this.indexes[g] = p + c.length);
    return this.markDirty(), this;
  }
  normalize(i, n) {
    if (typeof i == "string")
      i = vs(bs(i).nodes);
    else if (typeof i > "u")
      i = [];
    else if (Array.isArray(i)) {
      i = i.slice(0);
      for (let a of i)
        a.parent && a.parent.removeChild(a, "ignore");
    } else if (i.type === "root" && this.type !== "document") {
      i = i.nodes.slice(0);
      for (let a of i)
        a.parent && a.parent.removeChild(a, "ignore");
    } else if (i.type)
      i = [i];
    else if (i.prop) {
      if (typeof i.value > "u")
        throw new Error("Value field is missed in node creation");
      typeof i.value != "string" && (i.value = String(i.value)), i = [new ms(i)];
    } else if (i.selector || i.selectors)
      i = [new ru(i)];
    else if (i.name)
      i = [new nu(i)];
    else if (i.text)
      i = [new ps(i)];
    else
      throw new Error("Unknown node type in node creation");
    return i.map((a) => (a[_s] || ws.rebuild(a), a = a.proxyOf, a.parent && a.parent.removeChild(a), a[gs] && xs(a), a.raws || (a.raws = {}), typeof a.raws.before > "u" && n && typeof n.raws.before < "u" && (a.raws.before = n.raws.before.replace(/\S/g, "")), a.parent = this.proxyOf, a));
  }
  prepend(...i) {
    i = i.reverse();
    for (let n of i) {
      let r = this.normalize(n, this.first, "prepend").reverse();
      for (let a of r)
        this.proxyOf.nodes.unshift(a);
      for (let a in this.indexes)
        this.indexes[a] = this.indexes[a] + r.length;
    }
    return this.markDirty(), this;
  }
  push(i) {
    return i.parent = this, this.proxyOf.nodes.push(i), this;
  }
  removeAll() {
    for (let i of this.proxyOf.nodes)
      i.parent = void 0;
    return this.proxyOf.nodes = [], this.markDirty(), this;
  }
  removeChild(i) {
    i = this.index(i), this.proxyOf.nodes[i].parent = void 0, this.proxyOf.nodes.splice(i, 1);
    let n;
    for (let r in this.indexes)
      n = this.indexes[r], n >= i && (this.indexes[r] = n - 1);
    return this.markDirty(), this;
  }
  replaceValues(i, n, r) {
    return r || (r = n, n = {}), this.walkDecls((a) => {
      n.props && !n.props.includes(a.prop) || n.fast && !a.value.includes(n.fast) || (a.value = a.value.replace(i, r));
    }), this.markDirty(), this;
  }
  some(i) {
    return this.nodes.some(i);
  }
  walk(i) {
    return this.each((n, r) => {
      let a;
      try {
        a = i(n, r);
      } catch (c) {
        throw n.addToError(c);
      }
      return a !== !1 && n.walk && (a = n.walk(i)), a;
    });
  }
  walkAtRules(i, n) {
    return n ? i instanceof RegExp ? this.walk((r, a) => {
      if (r.type === "atrule" && i.test(r.name))
        return n(r, a);
    }) : this.walk((r, a) => {
      if (r.type === "atrule" && r.name === i)
        return n(r, a);
    }) : (n = i, this.walk((r, a) => {
      if (r.type === "atrule")
        return n(r, a);
    }));
  }
  walkComments(i) {
    return this.walk((n, r) => {
      if (n.type === "comment")
        return i(n, r);
    });
  }
  walkDecls(i, n) {
    return n ? i instanceof RegExp ? this.walk((r, a) => {
      if (r.type === "decl" && i.test(r.prop))
        return n(r, a);
    }) : this.walk((r, a) => {
      if (r.type === "decl" && r.prop === i)
        return n(r, a);
    }) : (n = i, this.walk((r, a) => {
      if (r.type === "decl")
        return n(r, a);
    }));
  }
  walkRules(i, n) {
    return n ? i instanceof RegExp ? this.walk((r, a) => {
      if (r.type === "rule" && i.test(r.selector))
        return n(r, a);
    }) : this.walk((r, a) => {
      if (r.type === "rule" && r.selector === i)
        return n(r, a);
    }) : (n = i, this.walk((r, a) => {
      if (r.type === "rule")
        return n(r, a);
    }));
  }
};
rt.registerParse = (o) => {
  bs = o;
};
rt.registerRule = (o) => {
  ru = o;
};
rt.registerAtRule = (o) => {
  nu = o;
};
rt.registerRoot = (o) => {
  ys = o;
};
var Et = rt;
rt.default = rt;
rt.rebuild = (o) => {
  o.type === "atrule" ? Object.setPrototypeOf(o, nu.prototype) : o.type === "rule" ? Object.setPrototypeOf(o, ru.prototype) : o.type === "decl" ? Object.setPrototypeOf(o, ms.prototype) : o.type === "comment" ? Object.setPrototypeOf(o, ps.prototype) : o.type === "root" && Object.setPrototypeOf(o, ys.prototype), o[_s] = !0, o.nodes && o.nodes.forEach((i) => {
    rt.rebuild(i);
  });
};
let Ts = Et, Dn = class extends Ts {
  constructor(i) {
    super(i), this.type = "atrule";
  }
  append(...i) {
    return this.proxyOf.nodes || (this.nodes = []), super.append(...i);
  }
  prepend(...i) {
    return this.proxyOf.nodes || (this.nodes = []), super.prepend(...i);
  }
};
var uu = Dn;
Dn.default = Dn;
Ts.registerAtRule(Dn);
let ec = Et, Ss, Ls, wi = class extends ec {
  constructor(i) {
    super({ type: "document", ...i }), this.nodes || (this.nodes = []);
  }
  toResult(i = {}) {
    return new Ss(new Ls(), this, i).stringify();
  }
};
wi.registerLazyResult = (o) => {
  Ss = o;
};
wi.registerProcessor = (o) => {
  Ls = o;
};
var ou = wi;
wi.default = wi;
let tc = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict", ic = (o, i = 21) => (n = i) => {
  let r = "", a = n | 0;
  for (; a--; )
    r += o[Math.random() * o.length | 0];
  return r;
}, nc = (o = 21) => {
  let i = "", n = o | 0;
  for (; n--; )
    i += tc[Math.random() * 64 | 0];
  return i;
};
var rc = { nanoid: nc, customAlphabet: ic };
let { existsSync: uc, readFileSync: oc } = qe, { dirname: vr, join: sc } = qe, { SourceMapConsumer: ho, SourceMapGenerator: fo } = qe;
function ac(o) {
  return Buffer ? Buffer.from(o, "base64").toString() : window.atob(o);
}
let Br = class {
  constructor(i, n) {
    if (n.map === !1)
      return;
    this.loadAnnotation(i), this.inline = this.startWith(this.annotation, "data:");
    let r = n.map ? n.map.prev : void 0, a = this.loadMap(n.from, r);
    !this.mapFile && n.from && (this.mapFile = n.from), this.mapFile && (this.root = vr(this.mapFile)), a && (this.text = a);
  }
  consumer() {
    return this.consumerCache || (this.consumerCache = new ho(this.text)), this.consumerCache;
  }
  decodeInline(i) {
    let n = /^data:application\/json;charset=utf-?8;base64,/, r = /^data:application\/json;base64,/, a = /^data:application\/json;charset=utf-?8,/, c = /^data:application\/json,/, p = i.match(a) || i.match(c);
    if (p)
      return decodeURIComponent(i.substr(p[0].length));
    let g = i.match(n) || i.match(r);
    if (g)
      return ac(i.substr(g[0].length));
    let d = i.match(/data:application\/json;([^,]+),/)[1];
    throw new Error("Unsupported source map encoding " + d);
  }
  getAnnotationURL(i) {
    return i.replace(/^\/\*\s*# sourceMappingURL=/, "").trim();
  }
  isMap(i) {
    return typeof i != "object" ? !1 : typeof i.mappings == "string" || typeof i._mappings == "string" || Array.isArray(i.sections);
  }
  loadAnnotation(i) {
    let n = i.match(/\/\*\s*# sourceMappingURL=/g);
    if (!n)
      return;
    let r = i.lastIndexOf(n.pop()), a = i.indexOf("*/", r);
    r > -1 && a > -1 && (this.annotation = this.getAnnotationURL(i.substring(r, a)));
  }
  loadFile(i) {
    if (this.root = vr(i), uc(i))
      return this.mapFile = i, oc(i, "utf-8").toString().trim();
  }
  loadMap(i, n) {
    if (n === !1)
      return !1;
    if (n) {
      if (typeof n == "string")
        return n;
      if (typeof n == "function") {
        let r = n(i);
        if (r) {
          let a = this.loadFile(r);
          if (!a)
            throw new Error(
              "Unable to load previous source map: " + r.toString()
            );
          return a;
        }
      } else {
        if (n instanceof ho)
          return fo.fromSourceMap(n).toString();
        if (n instanceof fo)
          return n.toString();
        if (this.isMap(n))
          return JSON.stringify(n);
        throw new Error(
          "Unsupported previous source map format: " + n.toString()
        );
      }
    } else {
      if (this.inline)
        return this.decodeInline(this.annotation);
      if (this.annotation) {
        let r = this.annotation;
        return i && (r = sc(vr(i), r)), this.loadFile(r);
      }
    }
  }
  startWith(i, n) {
    return i ? i.substr(0, n.length) === n : !1;
  }
  withContent() {
    return !!(this.consumer().sourcesContent && this.consumer().sourcesContent.length > 0);
  }
};
var Ps = Br;
Br.default = Br;
let { nanoid: lc } = rc, { isAbsolute: zr, resolve: Rr } = qe, { SourceMapConsumer: cc, SourceMapGenerator: hc } = qe, { fileURLToPath: po, pathToFileURL: gn } = qe, mo = iu, dc = Ps, xr = qe, wr = Symbol("lineToIndexCache"), fc = !!(cc && hc), go = !!(Rr && zr);
function _o(o) {
  if (o[wr])
    return o[wr];
  let i = o.css.split(`
`), n = new Array(i.length), r = 0;
  for (let a = 0, c = i.length; a < c; a++)
    n[a] = r, r += i[a].length + 1;
  return o[wr] = n, n;
}
let Bn = class {
  get from() {
    return this.file || this.id;
  }
  constructor(i, n = {}) {
    if (i === null || typeof i > "u" || typeof i == "object" && !i.toString)
      throw new Error(`PostCSS received ${i} instead of CSS string`);
    if (this.css = i.toString(), this.css[0] === "\uFEFF" || this.css[0] === "￾" ? (this.hasBOM = !0, this.css = this.css.slice(1)) : this.hasBOM = !1, this.document = this.css, n.document && (this.document = n.document.toString()), n.from && (!go || /^\w+:\/\//.test(n.from) || zr(n.from) ? this.file = n.from : this.file = Rr(n.from)), go && fc) {
      let r = new dc(this.css, n);
      if (r.text) {
        this.map = r;
        let a = r.consumer().file;
        !this.file && a && (this.file = this.mapResolve(a));
      }
    }
    this.file || (this.id = "<input css " + lc(6) + ">"), this.map && (this.map.file = this.from);
  }
  error(i, n, r, a = {}) {
    let c, p, g, d, _;
    if (n && typeof n == "object") {
      let S = n, f = r;
      if (typeof S.offset == "number") {
        d = S.offset;
        let m = this.fromOffset(d);
        n = m.line, r = m.col;
      } else
        n = S.line, r = S.column, d = this.fromLineAndColumn(n, r);
      if (typeof f.offset == "number") {
        g = f.offset;
        let m = this.fromOffset(g);
        p = m.line, c = m.col;
      } else
        p = f.line, c = f.column, g = this.fromLineAndColumn(f.line, f.column);
    } else if (r)
      d = this.fromLineAndColumn(n, r);
    else {
      d = n;
      let S = this.fromOffset(d);
      n = S.line, r = S.col;
    }
    let v = this.origin(n, r, p, c);
    return v ? _ = new mo(
      i,
      v.endLine === void 0 ? v.line : { column: v.column, line: v.line },
      v.endLine === void 0 ? v.column : { column: v.endColumn, line: v.endLine },
      v.source,
      v.file,
      a.plugin
    ) : _ = new mo(
      i,
      p === void 0 ? n : { column: r, line: n },
      p === void 0 ? r : { column: c, line: p },
      this.css,
      this.file,
      a.plugin
    ), _.input = { column: r, endColumn: c, endLine: p, endOffset: g, line: n, offset: d, source: this.css }, this.file && (gn && (_.input.url = gn(this.file).toString()), _.input.file = this.file), _;
  }
  fromLineAndColumn(i, n) {
    return _o(this)[i - 1] + n - 1;
  }
  fromOffset(i) {
    let n = _o(this), r = n[n.length - 1], a = 0;
    if (i >= r)
      a = n.length - 1;
    else {
      let c = n.length - 2, p;
      for (; a < c; )
        if (p = a + (c - a >> 1), i < n[p])
          c = p - 1;
        else if (i >= n[p + 1])
          a = p + 1;
        else {
          a = p;
          break;
        }
    }
    return {
      col: i - n[a] + 1,
      line: a + 1
    };
  }
  mapResolve(i) {
    return /^\w+:\/\//.test(i) ? i : Rr(this.map.consumer().sourceRoot || this.map.root || ".", i);
  }
  origin(i, n, r, a) {
    if (!this.map)
      return !1;
    let c = this.map.consumer(), p = c.originalPositionFor({ column: n, line: i });
    if (!p.source)
      return !1;
    let g;
    typeof r == "number" && (g = c.originalPositionFor({ column: a, line: r }));
    let d;
    zr(p.source) ? d = gn(p.source) : d = new URL(
      p.source,
      this.map.consumer().sourceRoot || gn(this.map.mapFile)
    );
    let _ = {
      column: p.column,
      endColumn: g && g.column,
      endLine: g && g.line,
      line: p.line,
      url: d.toString()
    };
    if (d.protocol === "file:")
      if (po)
        _.file = po(d);
      else
        throw new Error("file: protocol is not available in this PostCSS build");
    let v = c.sourceContentFor(p.source);
    return v && (_.source = v), _;
  }
  toJSON() {
    let i = {};
    for (let n of ["hasBOM", "css", "file", "id"])
      this[n] != null && (i[n] = this[n]);
    return this.map && (i.map = { ...this.map }, i.map.consumerCache && (i.map.consumerCache = void 0)), i;
  }
};
var Wn = Bn;
Bn.default = Bn;
xr && xr.registerInput && xr.registerInput(Bn);
let Es = Et, As, Cs, Gt = class extends Es {
  constructor(i) {
    super(i), this.type = "root", this.nodes || (this.nodes = []);
  }
  normalize(i, n, r) {
    let a = super.normalize(i);
    if (n) {
      if (r === "prepend")
        this.nodes.length > 1 ? n.raws.before = this.nodes[1].raws.before : delete n.raws.before;
      else if (this.first !== n)
        for (let c of a)
          c.raws.before = n.raws.before;
    }
    return a;
  }
  removeChild(i, n) {
    let r = this.index(i);
    return !n && r === 0 && this.nodes.length > 1 && (this.nodes[1].raws.before = this.nodes[r].raws.before), super.removeChild(i);
  }
  toResult(i = {}) {
    return new As(new Cs(), this, i).stringify();
  }
};
Gt.registerLazyResult = (o) => {
  As = o;
};
Gt.registerProcessor = (o) => {
  Cs = o;
};
var Ni = Gt;
Gt.default = Gt;
Es.registerRoot(Gt);
let Ti = {
  comma(o) {
    return Ti.split(o, [","], !0);
  },
  space(o) {
    let i = [" ", `
`, "	"];
    return Ti.split(o, i);
  },
  split(o, i, n) {
    let r = [], a = "", c = !1, p = 0, g = !1, d = "", _ = !1;
    for (let v of o)
      _ ? _ = !1 : v === "\\" ? _ = !0 : g ? v === d && (g = !1) : v === '"' || v === "'" ? (g = !0, d = v) : v === "(" ? p += 1 : v === ")" ? p > 0 && (p -= 1) : p === 0 && i.includes(v) && (c = !0), c ? (a !== "" && r.push(a.trim()), a = "", c = !1) : a += v;
    return (n || a !== "") && r.push(a.trim()), r;
  }
};
var Ms = Ti;
Ti.default = Ti;
let Os = Et, pc = Ms, zn = class extends Os {
  get selectors() {
    return pc.comma(this.selector);
  }
  set selectors(i) {
    let n = this.selector ? this.selector.match(/,\s*/) : null, r = n ? n[0] : "," + this.raw("between", "beforeOpen");
    this.selector = i.join(r);
  }
  constructor(i) {
    super(i), this.type = "rule", this.nodes || (this.nodes = []);
  }
};
var su = zn;
zn.default = zn;
Os.registerRule(zn);
let mc = uu, gc = Un, _c = Vn, bc = Wn, yc = Ps, vc = Ni, xc = su;
function Si(o, i) {
  if (Array.isArray(o))
    return o.map((a) => Si(a));
  let { inputs: n, ...r } = o;
  if (n) {
    i = [];
    for (let a of n) {
      let c = { ...a, __proto__: bc.prototype };
      c.map && (c.map = {
        ...c.map,
        __proto__: yc.prototype
      }), i.push(c);
    }
  }
  if (r.nodes && (r.nodes = o.nodes.map((a) => Si(a, i))), r.source) {
    let { inputId: a, ...c } = r.source;
    r.source = c, a != null && (r.source.input = i[a]);
  }
  if (r.type === "root")
    return new vc(r);
  if (r.type === "decl")
    return new _c(r);
  if (r.type === "rule")
    return new xc(r);
  if (r.type === "comment")
    return new gc(r);
  if (r.type === "atrule")
    return new mc(r);
  throw new Error("Unknown node type: " + o.type);
}
var wc = Si;
Si.default = Si;
let { dirname: En, relative: Is, resolve: ks, sep: Ns } = qe, { SourceMapConsumer: Ds, SourceMapGenerator: An } = qe, { pathToFileURL: bo } = qe, Tc = Wn, Sc = !!(Ds && An), Lc = !!(En && ks && Is && Ns), Pc = class {
  constructor(i, n, r, a) {
    this.stringify = i, this.mapOpts = r.map || {}, this.root = n, this.opts = r, this.css = a, this.originalCSS = a, this.usesFileUrls = !this.mapOpts.from && this.mapOpts.absolute, this.memoizedFileURLs = /* @__PURE__ */ new Map(), this.memoizedPaths = /* @__PURE__ */ new Map(), this.memoizedURLs = /* @__PURE__ */ new Map();
  }
  addAnnotation() {
    let i;
    this.isInline() ? i = "data:application/json;base64," + this.toBase64(this.map.toString()) : typeof this.mapOpts.annotation == "string" ? i = this.mapOpts.annotation : typeof this.mapOpts.annotation == "function" ? i = this.mapOpts.annotation(this.opts.to, this.root) : i = this.outputFile() + ".map";
    let n = `
`;
    this.css.includes(`\r
`) && (n = `\r
`), this.css += n + "/*# sourceMappingURL=" + i + " */";
  }
  applyPrevMaps() {
    for (let i of this.previous()) {
      let n = this.toUrl(this.path(i.file)), r = i.root || En(i.file), a;
      this.mapOpts.sourcesContent === !1 ? (a = new Ds(i.text), a.sourcesContent && (a.sourcesContent = null)) : a = i.consumer(), this.map.applySourceMap(a, n, this.toUrl(this.path(r)));
    }
  }
  clearAnnotation() {
    if (this.mapOpts.annotation !== !1)
      if (this.root) {
        let i;
        for (let n = this.root.nodes.length - 1; n >= 0; n--)
          i = this.root.nodes[n], i.type === "comment" && i.text.startsWith("# sourceMappingURL=") && this.root.removeChild(n);
      } else
        this.css && (this.css = this.css.replace(/\n*\/\*#[\S\s]*?\*\/$/gm, ""));
  }
  generate() {
    if (this.clearAnnotation(), Lc && Sc && this.isMap())
      return this.generateMap();
    {
      let i = "";
      return this.stringify(this.root, (n) => {
        i += n;
      }), [i];
    }
  }
  generateMap() {
    if (this.root)
      this.generateString();
    else if (this.previous().length === 1) {
      let i = this.previous()[0].consumer();
      i.file = this.outputFile(), this.map = An.fromSourceMap(i, {
        ignoreInvalidMapping: !0
      });
    } else
      this.map = new An({
        file: this.outputFile(),
        ignoreInvalidMapping: !0
      }), this.map.addMapping({
        generated: { column: 0, line: 1 },
        original: { column: 0, line: 1 },
        source: this.opts.from ? this.toUrl(this.path(this.opts.from)) : "<no source>"
      });
    return this.isSourcesContent() && this.setSourcesContent(), this.root && this.previous().length > 0 && this.applyPrevMaps(), this.isAnnotation() && this.addAnnotation(), this.isInline() ? [this.css] : [this.css, this.map];
  }
  generateString() {
    this.css = "", this.map = new An({
      file: this.outputFile(),
      ignoreInvalidMapping: !0
    });
    let i = 1, n = 1, r = "<no source>", a = {
      generated: { column: 0, line: 0 },
      original: { column: 0, line: 0 },
      source: ""
    }, c, p;
    this.stringify(this.root, (g, d, _) => {
      if (this.css += g, d && _ !== "end" && (a.generated.line = i, a.generated.column = n - 1, d.source && d.source.start ? (a.source = this.sourcePath(d), a.original.line = d.source.start.line, a.original.column = d.source.start.column - 1, this.map.addMapping(a)) : (a.source = r, a.original.line = 1, a.original.column = 0, this.map.addMapping(a))), p = g.match(/\n/g), p ? (i += p.length, c = g.lastIndexOf(`
`), n = g.length - c) : n += g.length, d && _ !== "start") {
        let v = d.parent || { raws: {} };
        (!(d.type === "decl" || d.type === "atrule" && !d.nodes) || d !== v.last || v.raws.semicolon) && (d.source && d.source.end ? (a.source = this.sourcePath(d), a.original.line = d.source.end.line, a.original.column = d.source.end.column - 1, a.generated.line = i, a.generated.column = n - 2, this.map.addMapping(a)) : (a.source = r, a.original.line = 1, a.original.column = 0, a.generated.line = i, a.generated.column = n - 1, this.map.addMapping(a)));
      }
    });
  }
  isAnnotation() {
    return this.isInline() ? !0 : typeof this.mapOpts.annotation < "u" ? this.mapOpts.annotation : this.previous().length ? this.previous().some((i) => i.annotation) : !0;
  }
  isInline() {
    if (typeof this.mapOpts.inline < "u")
      return this.mapOpts.inline;
    let i = this.mapOpts.annotation;
    return typeof i < "u" && i !== !0 ? !1 : this.previous().length ? this.previous().some((n) => n.inline) : !0;
  }
  isMap() {
    return typeof this.opts.map < "u" ? !!this.opts.map : this.previous().length > 0;
  }
  isSourcesContent() {
    return typeof this.mapOpts.sourcesContent < "u" ? this.mapOpts.sourcesContent : this.previous().length ? this.previous().some((i) => i.withContent()) : !0;
  }
  outputFile() {
    return this.opts.to ? this.path(this.opts.to) : this.opts.from ? this.path(this.opts.from) : "to.css";
  }
  path(i) {
    if (this.mapOpts.absolute || i.charCodeAt(0) === 60 || /^\w+:\/\//.test(i))
      return i;
    let n = this.memoizedPaths.get(i);
    if (n)
      return n;
    let r = this.opts.to ? En(this.opts.to) : ".";
    typeof this.mapOpts.annotation == "string" && (r = En(ks(r, this.mapOpts.annotation)));
    let a = Is(r, i);
    return this.memoizedPaths.set(i, a), a;
  }
  previous() {
    if (!this.previousMaps)
      if (this.previousMaps = [], this.root)
        this.root.walk((i) => {
          if (i.source && i.source.input.map) {
            let n = i.source.input.map;
            this.previousMaps.includes(n) || this.previousMaps.push(n);
          }
        });
      else {
        let i = new Tc(this.originalCSS, this.opts);
        i.map && this.previousMaps.push(i.map);
      }
    return this.previousMaps;
  }
  setSourcesContent() {
    let i = {};
    if (this.root)
      this.root.walk((n) => {
        if (n.source) {
          let r = n.source.input.from;
          if (r && !i[r]) {
            i[r] = !0;
            let a = this.usesFileUrls ? this.toFileUrl(r) : this.toUrl(this.path(r));
            this.map.setSourceContent(a, n.source.input.css);
          }
        }
      });
    else if (this.css) {
      let n = this.opts.from ? this.toUrl(this.path(this.opts.from)) : "<no source>";
      this.map.setSourceContent(n, this.css);
    }
  }
  sourcePath(i) {
    return this.mapOpts.from ? this.toUrl(this.mapOpts.from) : this.usesFileUrls ? this.toFileUrl(i.source.input.from) : this.toUrl(this.path(i.source.input.from));
  }
  toBase64(i) {
    return Buffer ? Buffer.from(i).toString("base64") : window.btoa(unescape(encodeURIComponent(i)));
  }
  toFileUrl(i) {
    let n = this.memoizedFileURLs.get(i);
    if (n)
      return n;
    if (bo) {
      let r = bo(i).toString();
      return this.memoizedFileURLs.set(i, r), r;
    } else
      throw new Error(
        "`map.absolute` option is not available in this PostCSS build"
      );
  }
  toUrl(i) {
    let n = this.memoizedURLs.get(i);
    if (n)
      return n;
    Ns === "\\" && (i = i.replace(/\\/g, "/"));
    let r = encodeURI(i).replace(/[#?]/g, encodeURIComponent);
    return this.memoizedURLs.set(i, r), r;
  }
};
var Bs = Pc;
const Tr = "'".charCodeAt(0), yo = '"'.charCodeAt(0), _n = "\\".charCodeAt(0), vo = "/".charCodeAt(0), bn = `
`.charCodeAt(0), pi = " ".charCodeAt(0), yn = "\f".charCodeAt(0), vn = "	".charCodeAt(0), xn = "\r".charCodeAt(0), Ec = "[".charCodeAt(0), Ac = "]".charCodeAt(0), Cc = "(".charCodeAt(0), Mc = ")".charCodeAt(0), Oc = "{".charCodeAt(0), Ic = "}".charCodeAt(0), kc = ";".charCodeAt(0), Nc = "*".charCodeAt(0), Dc = ":".charCodeAt(0), Bc = "@".charCodeAt(0), wn = /[\t\n\f\r "#'()/;[\\\]{}]/g, Tn = /[\t\n\f\r !"#'():;@[\\\]{}]|\/(?=\*)/g, zc = /.[\r\n"'(/\\]/, xo = /[\da-f]/i;
var Rc = function(i, n = {}) {
  let r = i.css.valueOf(), a = n.ignoreErrors, c, p, g, d, _, v, S, f, m, N, I = r.length, E = 0, z = [], H = [];
  function U() {
    return E;
  }
  function G(se) {
    throw i.error("Unclosed " + se, E);
  }
  function re() {
    return H.length === 0 && E >= I;
  }
  function he(se) {
    if (H.length)
      return H.pop();
    if (E >= I)
      return;
    let be = se ? se.ignoreUnclosed : !1;
    switch (c = r.charCodeAt(E), c) {
      case bn:
      case pi:
      case vn:
      case xn:
      case yn: {
        d = E;
        do
          d += 1, c = r.charCodeAt(d);
        while (c === pi || c === bn || c === vn || c === xn || c === yn);
        v = ["space", r.slice(E, d)], E = d - 1;
        break;
      }
      case Ec:
      case Ac:
      case Oc:
      case Ic:
      case Dc:
      case kc:
      case Mc: {
        let xe = String.fromCharCode(c);
        v = [xe, xe, E];
        break;
      }
      case Cc: {
        if (N = z.length ? z.pop()[1] : "", m = r.charCodeAt(E + 1), N === "url" && m !== Tr && m !== yo && m !== pi && m !== bn && m !== vn && m !== yn && m !== xn) {
          d = E;
          do {
            if (S = !1, d = r.indexOf(")", d + 1), d === -1)
              if (a || be) {
                d = E;
                break;
              } else
                G("bracket");
            for (f = d; r.charCodeAt(f - 1) === _n; )
              f -= 1, S = !S;
          } while (S);
          v = ["brackets", r.slice(E, d + 1), E, d], E = d;
        } else
          d = r.indexOf(")", E + 1), p = r.slice(E, d + 1), d === -1 || zc.test(p) ? v = ["(", "(", E] : (v = ["brackets", p, E, d], E = d);
        break;
      }
      case Tr:
      case yo: {
        _ = c === Tr ? "'" : '"', d = E;
        do {
          if (S = !1, d = r.indexOf(_, d + 1), d === -1)
            if (a || be) {
              d = E + 1;
              break;
            } else
              G("string");
          for (f = d; r.charCodeAt(f - 1) === _n; )
            f -= 1, S = !S;
        } while (S);
        v = ["string", r.slice(E, d + 1), E, d], E = d;
        break;
      }
      case Bc: {
        wn.lastIndex = E + 1, wn.test(r), wn.lastIndex === 0 ? d = r.length - 1 : d = wn.lastIndex - 2, v = ["at-word", r.slice(E, d + 1), E, d], E = d;
        break;
      }
      case _n: {
        for (d = E, g = !0; r.charCodeAt(d + 1) === _n; )
          d += 1, g = !g;
        if (c = r.charCodeAt(d + 1), g && c !== vo && c !== pi && c !== bn && c !== vn && c !== xn && c !== yn && (d += 1, xo.test(r.charAt(d)))) {
          for (; xo.test(r.charAt(d + 1)); )
            d += 1;
          r.charCodeAt(d + 1) === pi && (d += 1);
        }
        v = ["word", r.slice(E, d + 1), E, d], E = d;
        break;
      }
      default: {
        c === vo && r.charCodeAt(E + 1) === Nc ? (d = r.indexOf("*/", E + 2) + 1, d === 0 && (a || be ? d = r.length : G("comment")), v = ["comment", r.slice(E, d + 1), E, d], E = d) : (Tn.lastIndex = E + 1, Tn.test(r), Tn.lastIndex === 0 ? d = r.length - 1 : d = Tn.lastIndex - 2, v = ["word", r.slice(E, d + 1), E, d], z.push(v), E = d);
        break;
      }
    }
    return E++, v;
  }
  function Le(se) {
    H.push(se);
  }
  return {
    back: Le,
    endOfFile: re,
    nextToken: he,
    position: U
  };
};
let jc = uu, qc = Un, Zc = Vn, Fc = Ni, wo = su, Hc = Rc;
const To = {
  empty: !0,
  space: !0
};
function Uc(o) {
  for (let i = o.length - 1; i >= 0; i--) {
    let n = o[i], r = n[3] || n[2];
    if (r)
      return r;
  }
}
let Vc = class {
  constructor(i) {
    this.input = i, this.root = new Fc(), this.current = this.root, this.spaces = "", this.semicolon = !1, this.createTokenizer(), this.root.source = { input: i, start: { column: 1, line: 1, offset: 0 } };
  }
  atrule(i) {
    let n = new jc();
    n.name = i[1].slice(1), n.name === "" && this.unnamedAtrule(n, i), this.init(n, i[2]);
    let r, a, c, p = !1, g = !1, d = [], _ = [];
    for (; !this.tokenizer.endOfFile(); ) {
      if (i = this.tokenizer.nextToken(), r = i[0], r === "(" || r === "[" ? _.push(r === "(" ? ")" : "]") : r === "{" && _.length > 0 ? _.push("}") : r === _[_.length - 1] && _.pop(), _.length === 0)
        if (r === ";") {
          n.source.end = this.getPosition(i[2]), n.source.end.offset++, this.semicolon = !0;
          break;
        } else if (r === "{") {
          g = !0;
          break;
        } else if (r === "}") {
          if (d.length > 0) {
            for (c = d.length - 1, a = d[c]; a && a[0] === "space"; )
              a = d[--c];
            a && (n.source.end = this.getPosition(a[3] || a[2]), n.source.end.offset++);
          }
          this.end(i);
          break;
        } else
          d.push(i);
      else
        d.push(i);
      if (this.tokenizer.endOfFile()) {
        p = !0;
        break;
      }
    }
    n.raws.between = this.spacesAndCommentsFromEnd(d), d.length ? (n.raws.afterName = this.spacesAndCommentsFromStart(d), this.raw(n, "params", d), p && (i = d[d.length - 1], n.source.end = this.getPosition(i[3] || i[2]), n.source.end.offset++, this.spaces = n.raws.between, n.raws.between = "")) : (n.raws.afterName = "", n.params = ""), g && (n.nodes = [], this.current = n);
  }
  checkMissedSemicolon(i) {
    let n = this.colon(i);
    if (n === !1)
      return;
    let r = 0, a;
    for (let c = n - 1; c >= 0 && (a = i[c], !(a[0] !== "space" && (r += 1, r === 2))); c--)
      ;
    throw this.input.error(
      "Missed semicolon",
      a[0] === "word" ? a[3] + 1 : a[2]
    );
  }
  colon(i) {
    let n = 0, r, a, c;
    for (let [p, g] of i.entries()) {
      if (a = g, c = a[0], c === "(" && (n += 1), c === ")" && (n -= 1), n === 0 && c === ":")
        if (!r)
          this.doubleColon(a);
        else {
          if (r[0] === "word" && r[1] === "progid")
            continue;
          return p;
        }
      r = a;
    }
    return !1;
  }
  comment(i) {
    let n = new qc();
    this.init(n, i[2]), n.source.end = this.getPosition(i[3] || i[2]), n.source.end.offset++;
    let r = i[1].slice(2, -2);
    if (/^\s*$/.test(r))
      n.text = "", n.raws.left = r, n.raws.right = "";
    else {
      let a = r.match(/^(\s*)([^]*\S)(\s*)$/);
      n.text = a[2], n.raws.left = a[1], n.raws.right = a[3];
    }
  }
  createTokenizer() {
    this.tokenizer = Hc(this.input);
  }
  decl(i, n) {
    let r = new Zc();
    this.init(r, i[0][2]);
    let a = i[i.length - 1];
    for (a[0] === ";" && (this.semicolon = !0, i.pop()), r.source.end = this.getPosition(
      a[3] || a[2] || Uc(i)
    ), r.source.end.offset++; i[0][0] !== "word"; )
      i.length === 1 && this.unknownWord(i), r.raws.before += i.shift()[1];
    for (r.source.start = this.getPosition(i[0][2]), r.prop = ""; i.length; ) {
      let _ = i[0][0];
      if (_ === ":" || _ === "space" || _ === "comment")
        break;
      r.prop += i.shift()[1];
    }
    r.raws.between = "";
    let c;
    for (; i.length; )
      if (c = i.shift(), c[0] === ":") {
        r.raws.between += c[1];
        break;
      } else
        c[0] === "word" && /\w/.test(c[1]) && this.unknownWord([c]), r.raws.between += c[1];
    (r.prop[0] === "_" || r.prop[0] === "*") && (r.raws.before += r.prop[0], r.prop = r.prop.slice(1));
    let p = [], g;
    for (; i.length && (g = i[0][0], !(g !== "space" && g !== "comment")); )
      p.push(i.shift());
    this.precheckMissedSemicolon(i);
    for (let _ = i.length - 1; _ >= 0; _--) {
      if (c = i[_], c[1].toLowerCase() === "!important") {
        r.important = !0;
        let v = this.stringFrom(i, _);
        v = this.spacesFromEnd(i) + v, v !== " !important" && (r.raws.important = v);
        break;
      } else if (c[1].toLowerCase() === "important") {
        let v = i.slice(0), S = "";
        for (let f = _; f > 0; f--) {
          let m = v[f][0];
          if (S.trim().startsWith("!") && m !== "space")
            break;
          S = v.pop()[1] + S;
        }
        S.trim().startsWith("!") && (r.important = !0, r.raws.important = S, i = v);
      }
      if (c[0] !== "space" && c[0] !== "comment")
        break;
    }
    i.some((_) => _[0] !== "space" && _[0] !== "comment") && (r.raws.between += p.map((_) => _[1]).join(""), p = []), this.raw(r, "value", p.concat(i), n), r.value.includes(":") && !n && this.checkMissedSemicolon(i);
  }
  doubleColon(i) {
    throw this.input.error(
      "Double colon",
      { offset: i[2] },
      { offset: i[2] + i[1].length }
    );
  }
  emptyRule(i) {
    let n = new wo();
    this.init(n, i[2]), n.selector = "", n.raws.between = "", this.current = n;
  }
  end(i) {
    this.current.nodes && this.current.nodes.length && (this.current.raws.semicolon = this.semicolon), this.semicolon = !1, this.current.raws.after = (this.current.raws.after || "") + this.spaces, this.spaces = "", this.current.parent ? (this.current.source.end = this.getPosition(i[2]), this.current.source.end.offset++, this.current = this.current.parent) : this.unexpectedClose(i);
  }
  endFile() {
    this.current.parent && this.unclosedBlock(), this.current.nodes && this.current.nodes.length && (this.current.raws.semicolon = this.semicolon), this.current.raws.after = (this.current.raws.after || "") + this.spaces, this.root.source.end = this.getPosition(this.tokenizer.position());
  }
  freeSemicolon(i) {
    if (this.spaces += i[1], this.current.nodes) {
      let n = this.current.nodes[this.current.nodes.length - 1];
      n && n.type === "rule" && !n.raws.ownSemicolon && (n.raws.ownSemicolon = this.spaces, this.spaces = "", n.source.end = this.getPosition(i[2]), n.source.end.offset += n.raws.ownSemicolon.length);
    }
  }
  // Helpers
  getPosition(i) {
    let n = this.input.fromOffset(i);
    return {
      column: n.col,
      line: n.line,
      offset: i
    };
  }
  init(i, n) {
    this.current.push(i), i.source = {
      input: this.input,
      start: this.getPosition(n)
    }, i.raws.before = this.spaces, this.spaces = "", i.type !== "comment" && (this.semicolon = !1);
  }
  other(i) {
    let n = !1, r = null, a = !1, c = null, p = [], g = i[1].startsWith("--"), d = [], _ = i;
    for (; _; ) {
      if (r = _[0], d.push(_), r === "(" || r === "[")
        c || (c = _), p.push(r === "(" ? ")" : "]");
      else if (g && a && r === "{")
        c || (c = _), p.push("}");
      else if (p.length === 0)
        if (r === ";")
          if (a) {
            this.decl(d, g);
            return;
          } else
            break;
        else if (r === "{") {
          this.rule(d);
          return;
        } else if (r === "}") {
          this.tokenizer.back(d.pop()), n = !0;
          break;
        } else
          r === ":" && (a = !0);
      else
        r === p[p.length - 1] && (p.pop(), p.length === 0 && (c = null));
      _ = this.tokenizer.nextToken();
    }
    if (this.tokenizer.endOfFile() && (n = !0), p.length > 0 && this.unclosedBracket(c), n && a) {
      if (!g)
        for (; d.length && (_ = d[d.length - 1][0], !(_ !== "space" && _ !== "comment")); )
          this.tokenizer.back(d.pop());
      this.decl(d, g);
    } else
      this.unknownWord(d);
  }
  parse() {
    let i;
    for (; !this.tokenizer.endOfFile(); )
      switch (i = this.tokenizer.nextToken(), i[0]) {
        case "space":
          this.spaces += i[1];
          break;
        case ";":
          this.freeSemicolon(i);
          break;
        case "}":
          this.end(i);
          break;
        case "comment":
          this.comment(i);
          break;
        case "at-word":
          this.atrule(i);
          break;
        case "{":
          this.emptyRule(i);
          break;
        default:
          this.other(i);
          break;
      }
    this.endFile();
  }
  precheckMissedSemicolon() {
  }
  raw(i, n, r, a) {
    let c, p, g = r.length, d = "", _ = !0, v, S;
    for (let f = 0; f < g; f += 1)
      c = r[f], p = c[0], p === "space" && f === g - 1 && !a ? _ = !1 : p === "comment" ? (S = r[f - 1] ? r[f - 1][0] : "empty", v = r[f + 1] ? r[f + 1][0] : "empty", !To[S] && !To[v] ? d.slice(-1) === "," ? _ = !1 : d += c[1] : _ = !1) : d += c[1];
    if (!_) {
      let f = r.reduce((m, N) => m + N[1], "");
      i.raws[n] = { raw: f, value: d };
    }
    i[n] = d;
  }
  rule(i) {
    i.pop();
    let n = new wo();
    this.init(n, i[0][2]), n.raws.between = this.spacesAndCommentsFromEnd(i), this.raw(n, "selector", i), this.current = n;
  }
  spacesAndCommentsFromEnd(i) {
    let n, r = "";
    for (; i.length && (n = i[i.length - 1][0], !(n !== "space" && n !== "comment")); )
      r = i.pop()[1] + r;
    return r;
  }
  // Errors
  spacesAndCommentsFromStart(i) {
    let n, r = "";
    for (; i.length && (n = i[0][0], !(n !== "space" && n !== "comment")); )
      r += i.shift()[1];
    return r;
  }
  spacesFromEnd(i) {
    let n, r = "";
    for (; i.length && (n = i[i.length - 1][0], n === "space"); )
      r = i.pop()[1] + r;
    return r;
  }
  stringFrom(i, n) {
    let r = "";
    for (let a = n; a < i.length; a++)
      r += i[a][1];
    return i.splice(n, i.length - n), r;
  }
  unclosedBlock() {
    let i = this.current.source.start;
    throw this.input.error("Unclosed block", i.line, i.column);
  }
  unclosedBracket(i) {
    throw this.input.error(
      "Unclosed bracket",
      { offset: i[2] },
      { offset: i[2] + 1 }
    );
  }
  unexpectedClose(i) {
    throw this.input.error(
      "Unexpected }",
      { offset: i[2] },
      { offset: i[2] + 1 }
    );
  }
  unknownWord(i) {
    throw this.input.error(
      "Unknown word " + i[0][1],
      { offset: i[0][2] },
      { offset: i[0][2] + i[0][1].length }
    );
  }
  unnamedAtrule(i, n) {
    throw this.input.error(
      "At-rule without name",
      { offset: n[2] },
      { offset: n[2] + n[1].length }
    );
  }
};
var Wc = Vc;
let Gc = Et, $c = Wn, Xc = Wc;
function Rn(o, i) {
  let n = new $c(o, i), r = new Xc(n);
  try {
    r.parse();
  } catch (a) {
    throw process.env.NODE_ENV !== "production" && a.name === "CssSyntaxError" && i && i.from && (/\.scss$/i.test(i.from) ? a.message += `
You tried to parse SCSS with the standard CSS parser; try again with the postcss-scss parser` : /\.sass/i.test(i.from) ? a.message += `
You tried to parse Sass with the standard CSS parser; try again with the postcss-sass parser` : /\.less$/i.test(i.from) && (a.message += `
You tried to parse Less with the standard CSS parser; try again with the postcss-less parser`)), a;
  }
  return r.root;
}
var au = Rn;
Rn.default = Rn;
Gc.registerParse(Rn);
let jr = class {
  constructor(i, n = {}) {
    if (this.type = "warning", this.text = i, n.node && n.node.source) {
      let r = n.node.rangeBy(n);
      this.line = r.start.line, this.column = r.start.column, this.endLine = r.end.line, this.endColumn = r.end.column;
    }
    for (let r in n)
      this[r] = n[r];
  }
  toString() {
    return this.node ? this.node.error(this.text, {
      index: this.index,
      plugin: this.plugin,
      word: this.word
    }).message : this.plugin ? this.plugin + ": " + this.text : this.text;
  }
};
var zs = jr;
jr.default = jr;
let Yc = zs, qr = class {
  get content() {
    return this.css;
  }
  constructor(i, n, r) {
    this.processor = i, this.messages = [], this.root = n, this.opts = r, this.css = "", this.map = void 0;
  }
  toString() {
    return this.css;
  }
  warn(i, n = {}) {
    n.plugin || this.lastPlugin && this.lastPlugin.postcssPlugin && (n.plugin = this.lastPlugin.postcssPlugin);
    let r = new Yc(i, n);
    return this.messages.push(r), r;
  }
  warnings() {
    return this.messages.filter((i) => i.type === "warning");
  }
};
var lu = qr;
qr.default = qr;
let So = {};
var Rs = function(i) {
  So[i] || (So[i] = !0, typeof console < "u" && console.warn && console.warn(i));
};
let Kc = Et, Jc = ou, Qc = Bs, e0 = au, Lo = lu, t0 = Ni, i0 = Fn, { isClean: He, my: n0 } = ki, r0 = Rs;
const u0 = {
  atrule: "AtRule",
  comment: "Comment",
  decl: "Declaration",
  document: "Document",
  root: "Root",
  rule: "Rule"
}, o0 = {
  AtRule: !0,
  AtRuleExit: !0,
  Comment: !0,
  CommentExit: !0,
  Declaration: !0,
  DeclarationExit: !0,
  Document: !0,
  DocumentExit: !0,
  Once: !0,
  OnceExit: !0,
  postcssPlugin: !0,
  prepare: !0,
  Root: !0,
  RootExit: !0,
  Rule: !0,
  RuleExit: !0
}, s0 = {
  Once: !0,
  postcssPlugin: !0,
  prepare: !0
}, $t = 0;
function mi(o) {
  return typeof o == "object" && typeof o.then == "function";
}
function js(o) {
  let i = !1, n = u0[o.type];
  return o.type === "decl" ? i = o.prop.toLowerCase() : o.type === "atrule" && (i = o.name.toLowerCase()), i && o.append ? [
    n,
    n + "-" + i,
    $t,
    n + "Exit",
    n + "Exit-" + i
  ] : i ? [n, n + "-" + i, n + "Exit", n + "Exit-" + i] : o.append ? [n, $t, n + "Exit"] : [n, n + "Exit"];
}
function Po(o) {
  let i;
  return o.type === "document" ? i = ["Document", $t, "DocumentExit"] : o.type === "root" ? i = ["Root", $t, "RootExit"] : i = js(o), {
    eventIndex: 0,
    events: i,
    iterator: 0,
    node: o,
    visitorIndex: 0,
    visitors: []
  };
}
function Zr(o) {
  return o[He] = !1, o.nodes && o.nodes.forEach((i) => Zr(i)), o;
}
let Fr = {}, Xt = class qs {
  get content() {
    return this.stringify().content;
  }
  get css() {
    return this.stringify().css;
  }
  get map() {
    return this.stringify().map;
  }
  get messages() {
    return this.sync().messages;
  }
  get opts() {
    return this.result.opts;
  }
  get processor() {
    return this.result.processor;
  }
  get root() {
    return this.sync().root;
  }
  get [Symbol.toStringTag]() {
    return "LazyResult";
  }
  constructor(i, n, r) {
    this.stringified = !1, this.processed = !1;
    let a;
    if (typeof n == "object" && n !== null && (n.type === "root" || n.type === "document"))
      a = Zr(n);
    else if (n instanceof qs || n instanceof Lo)
      a = Zr(n.root), n.map && (typeof r.map > "u" && (r.map = {}), r.map.inline || (r.map.inline = !1), r.map.prev = n.map);
    else {
      let c = e0;
      r.syntax && (c = r.syntax.parse), r.parser && (c = r.parser), c.parse && (c = c.parse);
      try {
        a = c(n, r);
      } catch (p) {
        this.processed = !0, this.error = p;
      }
      a && !a[n0] && Kc.rebuild(a);
    }
    this.result = new Lo(i, a, r), this.helpers = { ...Fr, postcss: Fr, result: this.result }, this.plugins = this.processor.plugins.map((c) => typeof c == "object" && c.prepare ? { ...c, ...c.prepare(this.result) } : c);
  }
  async() {
    return this.error ? Promise.reject(this.error) : this.processed ? Promise.resolve(this.result) : (this.processing || (this.processing = this.runAsync()), this.processing);
  }
  catch(i) {
    return this.async().catch(i);
  }
  finally(i) {
    return this.async().then(i, i);
  }
  getAsyncError() {
    throw new Error("Use process(css).then(cb) to work with async plugins");
  }
  handleError(i, n) {
    let r = this.result.lastPlugin;
    try {
      if (n && n.addToError(i), this.error = i, i.name === "CssSyntaxError" && !i.plugin)
        i.plugin = r.postcssPlugin, i.setMessage();
      else if (r.postcssVersion && process.env.NODE_ENV !== "production") {
        let a = r.postcssPlugin, c = r.postcssVersion, p = this.result.processor.version, g = c.split("."), d = p.split(".");
        (g[0] !== d[0] || parseInt(g[1]) > parseInt(d[1])) && console.error(
          "Unknown error from PostCSS plugin. Your current PostCSS version is " + p + ", but " + a + " uses " + c + ". Perhaps this is the source of the error below."
        );
      }
    } catch (a) {
      console && console.error && console.error(a);
    }
    return i;
  }
  prepareVisitors() {
    this.listeners = {};
    let i = (n, r, a) => {
      this.listeners[r] || (this.listeners[r] = []), this.listeners[r].push([n, a]);
    };
    for (let n of this.plugins)
      if (typeof n == "object")
        for (let r in n) {
          if (!o0[r] && /^[A-Z]/.test(r))
            throw new Error(
              `Unknown event ${r} in ${n.postcssPlugin}. Try to update PostCSS (${this.processor.version} now).`
            );
          if (!s0[r])
            if (typeof n[r] == "object")
              for (let a in n[r])
                a === "*" ? i(n, r, n[r][a]) : i(
                  n,
                  r + "-" + a.toLowerCase(),
                  n[r][a]
                );
            else
              typeof n[r] == "function" && i(n, r, n[r]);
        }
    this.hasListener = Object.keys(this.listeners).length > 0;
  }
  async runAsync() {
    this.plugin = 0;
    for (let i = 0; i < this.plugins.length; i++) {
      let n = this.plugins[i], r = this.runOnRoot(n);
      if (mi(r))
        try {
          await r;
        } catch (a) {
          throw this.handleError(a);
        }
    }
    if (this.prepareVisitors(), this.hasListener) {
      let i = this.result.root;
      for (; !i[He]; ) {
        i[He] = !0;
        let n = [Po(i)];
        for (; n.length > 0; ) {
          let r = this.visitTick(n);
          if (mi(r))
            try {
              await r;
            } catch (a) {
              let c = n[n.length - 1].node;
              throw this.handleError(a, c);
            }
        }
      }
      if (this.listeners.OnceExit)
        for (let [n, r] of this.listeners.OnceExit) {
          this.result.lastPlugin = n;
          try {
            if (i.type === "document") {
              let a = i.nodes.map(
                (c) => r(c, this.helpers)
              );
              await Promise.all(a);
            } else
              await r(i, this.helpers);
          } catch (a) {
            throw this.handleError(a);
          }
        }
    }
    return this.processed = !0, this.stringify();
  }
  runOnRoot(i) {
    this.result.lastPlugin = i;
    try {
      if (typeof i == "object" && i.Once) {
        if (this.result.root.type === "document") {
          let n = this.result.root.nodes.map(
            (r) => i.Once(r, this.helpers)
          );
          return mi(n[0]) ? Promise.all(n) : n;
        }
        return i.Once(this.result.root, this.helpers);
      } else if (typeof i == "function")
        return i(this.result.root, this.result);
    } catch (n) {
      throw this.handleError(n);
    }
  }
  stringify() {
    if (this.error)
      throw this.error;
    if (this.stringified)
      return this.result;
    this.stringified = !0, this.sync();
    let i = this.result.opts, n = i0;
    i.syntax && (n = i.syntax.stringify), i.stringifier && (n = i.stringifier), n.stringify && (n = n.stringify);
    let a = new Qc(n, this.result.root, this.result.opts).generate();
    return this.result.css = a[0], this.result.map = a[1], this.result;
  }
  sync() {
    if (this.error)
      throw this.error;
    if (this.processed)
      return this.result;
    if (this.processed = !0, this.processing)
      throw this.getAsyncError();
    for (let i of this.plugins) {
      let n = this.runOnRoot(i);
      if (mi(n))
        throw this.getAsyncError();
    }
    if (this.prepareVisitors(), this.hasListener) {
      let i = this.result.root;
      for (; !i[He]; )
        i[He] = !0, this.walkSync(i);
      if (this.listeners.OnceExit)
        if (i.type === "document")
          for (let n of i.nodes)
            this.visitSync(this.listeners.OnceExit, n);
        else
          this.visitSync(this.listeners.OnceExit, i);
    }
    return this.result;
  }
  then(i, n) {
    return process.env.NODE_ENV !== "production" && ("from" in this.opts || r0(
      "Without `from` option PostCSS could generate wrong source map and will not find Browserslist config. Set it to CSS file path or to `undefined` to prevent this warning."
    )), this.async().then(i, n);
  }
  toString() {
    return this.css;
  }
  visitSync(i, n) {
    for (let [r, a] of i) {
      this.result.lastPlugin = r;
      let c;
      try {
        c = a(n, this.helpers);
      } catch (p) {
        throw this.handleError(p, n.proxyOf);
      }
      if (n.type !== "root" && n.type !== "document" && !n.parent)
        return !0;
      if (mi(c))
        throw this.getAsyncError();
    }
  }
  visitTick(i) {
    let n = i[i.length - 1], { node: r, visitors: a } = n;
    if (r.type !== "root" && r.type !== "document" && !r.parent) {
      i.pop();
      return;
    }
    if (a.length > 0 && n.visitorIndex < a.length) {
      let [p, g] = a[n.visitorIndex];
      n.visitorIndex += 1, n.visitorIndex === a.length && (n.visitors = [], n.visitorIndex = 0), this.result.lastPlugin = p;
      try {
        return g(r.toProxy(), this.helpers);
      } catch (d) {
        throw this.handleError(d, r);
      }
    }
    if (n.iterator !== 0) {
      let p = n.iterator, g;
      for (; g = r.nodes[r.indexes[p]]; )
        if (r.indexes[p] += 1, !g[He]) {
          g[He] = !0, i.push(Po(g));
          return;
        }
      n.iterator = 0, delete r.indexes[p];
    }
    let c = n.events;
    for (; n.eventIndex < c.length; ) {
      let p = c[n.eventIndex];
      if (n.eventIndex += 1, p === $t) {
        r.nodes && r.nodes.length && (r[He] = !0, n.iterator = r.getIterator());
        return;
      } else if (this.listeners[p]) {
        n.visitors = this.listeners[p];
        return;
      }
    }
    i.pop();
  }
  walkSync(i) {
    i[He] = !0;
    let n = js(i);
    for (let r of n)
      if (r === $t)
        i.nodes && i.each((a) => {
          a[He] || this.walkSync(a);
        });
      else {
        let a = this.listeners[r];
        if (a && this.visitSync(a, i.toProxy()))
          return;
      }
  }
  warnings() {
    return this.sync().warnings();
  }
};
Xt.registerPostcss = (o) => {
  Fr = o;
};
var Zs = Xt;
Xt.default = Xt;
t0.registerLazyResult(Xt);
Jc.registerLazyResult(Xt);
let a0 = Bs, l0 = au;
const c0 = lu;
let h0 = Fn, d0 = Rs, Hr = class {
  get content() {
    return this.result.css;
  }
  get css() {
    return this.result.css;
  }
  get map() {
    return this.result.map;
  }
  get messages() {
    return [];
  }
  get opts() {
    return this.result.opts;
  }
  get processor() {
    return this.result.processor;
  }
  get root() {
    if (this._root)
      return this._root;
    let i, n = l0;
    try {
      i = n(this._css, this._opts);
    } catch (r) {
      this.error = r;
    }
    if (this.error)
      throw this.error;
    return this._root = i, i;
  }
  get [Symbol.toStringTag]() {
    return "NoWorkResult";
  }
  constructor(i, n, r) {
    n = n.toString(), this.stringified = !1, this._processor = i, this._css = n, this._opts = r, this._map = void 0;
    let a, c = h0;
    this.result = new c0(this._processor, a, this._opts), this.result.css = n;
    let p = this;
    Object.defineProperty(this.result, "root", {
      get() {
        return p.root;
      }
    });
    let g = new a0(c, a, this._opts, n);
    if (g.isMap()) {
      let [d, _] = g.generate();
      d && (this.result.css = d), _ && (this.result.map = _);
    } else
      g.clearAnnotation(), this.result.css = g.css;
  }
  async() {
    return this.error ? Promise.reject(this.error) : Promise.resolve(this.result);
  }
  catch(i) {
    return this.async().catch(i);
  }
  finally(i) {
    return this.async().then(i, i);
  }
  sync() {
    if (this.error)
      throw this.error;
    return this.result;
  }
  then(i, n) {
    return process.env.NODE_ENV !== "production" && ("from" in this._opts || d0(
      "Without `from` option PostCSS could generate wrong source map and will not find Browserslist config. Set it to CSS file path or to `undefined` to prevent this warning."
    )), this.async().then(i, n);
  }
  toString() {
    return this._css;
  }
  warnings() {
    return [];
  }
};
var f0 = Hr;
Hr.default = Hr;
let p0 = ou, m0 = Zs, g0 = f0, _0 = Ni, Li = class {
  constructor(i = []) {
    this.version = "8.5.6", this.plugins = this.normalize(i);
  }
  normalize(i) {
    let n = [];
    for (let r of i)
      if (r.postcss === !0 ? r = r() : r.postcss && (r = r.postcss), typeof r == "object" && Array.isArray(r.plugins))
        n = n.concat(r.plugins);
      else if (typeof r == "object" && r.postcssPlugin)
        n.push(r);
      else if (typeof r == "function")
        n.push(r);
      else if (typeof r == "object" && (r.parse || r.stringify)) {
        if (process.env.NODE_ENV !== "production")
          throw new Error(
            "PostCSS syntaxes cannot be used as plugins. Instead, please use one of the syntax/parser/stringifier options as outlined in your PostCSS runner documentation."
          );
      } else
        throw new Error(r + " is not a PostCSS plugin");
    return n;
  }
  process(i, n = {}) {
    return !this.plugins.length && !n.parser && !n.stringifier && !n.syntax ? new g0(this, i, n) : new m0(this, i, n);
  }
  use(i) {
    return this.plugins = this.plugins.concat(this.normalize([i])), this;
  }
};
var b0 = Li;
Li.default = Li;
_0.registerProcessor(Li);
p0.registerProcessor(Li);
let Fs = uu, Hs = Un, y0 = Et, v0 = iu, Us = Vn, Vs = ou, x0 = wc, w0 = Wn, T0 = Zs, S0 = Ms, L0 = Hn, P0 = au, cu = b0, E0 = lu, Ws = Ni, Gs = su, A0 = Fn, C0 = zs;
function ae(...o) {
  return o.length === 1 && Array.isArray(o[0]) && (o = o[0]), new cu(o);
}
ae.plugin = function(i, n) {
  let r = !1;
  function a(...p) {
    console && console.warn && !r && (r = !0, console.warn(
      i + `: postcss.plugin was deprecated. Migration guide:
https://evilmartians.com/chronicles/postcss-8-plugin-migration`
    ), process.env.LANG && process.env.LANG.startsWith("cn") && console.warn(
      i + `: 里面 postcss.plugin 被弃用. 迁移指南:
https://www.w3ctech.com/topic/2226`
    ));
    let g = n(...p);
    return g.postcssPlugin = i, g.postcssVersion = new cu().version, g;
  }
  let c;
  return Object.defineProperty(a, "postcss", {
    get() {
      return c || (c = a()), c;
    }
  }), a.process = function(p, g, d) {
    return ae([a(d)]).process(p, g);
  }, a;
};
ae.stringify = A0;
ae.parse = P0;
ae.fromJSON = x0;
ae.list = S0;
ae.comment = (o) => new Hs(o);
ae.atRule = (o) => new Fs(o);
ae.decl = (o) => new Us(o);
ae.rule = (o) => new Gs(o);
ae.root = (o) => new Ws(o);
ae.document = (o) => new Vs(o);
ae.CssSyntaxError = v0;
ae.Declaration = Us;
ae.Container = y0;
ae.Processor = cu;
ae.Document = Vs;
ae.Comment = Hs;
ae.Warning = C0;
ae.AtRule = Fs;
ae.Result = E0;
ae.Input = w0;
ae.Rule = Gs;
ae.Root = Ws;
ae.Node = L0;
T0.registerPostcss(ae);
var M0 = ae;
ae.default = ae;
const O0 = zo, Eo = El, { isPlainObject: I0 } = eu, Ao = Fl, k0 = Hl, { parse: N0 } = M0, D0 = [
  "img",
  "audio",
  "video",
  "picture",
  "svg",
  "object",
  "map",
  "iframe",
  "embed"
], B0 = ["script", "style"];
function Ht(o, i) {
  o && Object.keys(o).forEach(function(n) {
    i(o[n], n);
  });
}
function tt(o, i) {
  return {}.hasOwnProperty.call(o, i);
}
function Co(o, i) {
  const n = [];
  return Ht(o, function(r) {
    i(r) && n.push(r);
  }), n;
}
function z0(o) {
  for (const i in o)
    if (tt(o, i))
      return !1;
  return !0;
}
function R0(o) {
  return o.map(function(i) {
    if (!i.url)
      throw new Error("URL missing");
    return i.url + (i.w ? ` ${i.w}w` : "") + (i.h ? ` ${i.h}h` : "") + (i.d ? ` ${i.d}x` : "");
  }).join(", ");
}
var j0 = Pi;
const q0 = /^[^\0\t\n\f\r /<=>]+$/;
function Pi(o, i, n) {
  if (o == null)
    return "";
  typeof o == "number" && (o = o.toString());
  let r = "", a = "";
  function c(x, C) {
    const w = this;
    this.tag = x, this.attribs = C || {}, this.tagPosition = r.length, this.text = "", this.openingTagLength = 0, this.mediaChildren = [], this.updateParentNodeText = function() {
      if (E.length) {
        const R = E[E.length - 1];
        R.text += w.text;
      }
    }, this.updateParentNodeMediaChildren = function() {
      E.length && D0.includes(this.tag) && E[E.length - 1].mediaChildren.push(this.tag);
    };
  }
  i = Object.assign({}, Pi.defaults, i), i.parser = Object.assign({}, Z0, i.parser);
  const p = function(x) {
    return i.allowedTags === !1 || (i.allowedTags || []).indexOf(x) > -1;
  };
  B0.forEach(function(x) {
    p(x) && !i.allowVulnerableTags && console.warn(`

⚠️ Your \`allowedTags\` option includes, \`${x}\`, which is inherently
vulnerable to XSS attacks. Please remove it from \`allowedTags\`.
Or, to disable this warning, add the \`allowVulnerableTags\` option
and ensure you are accounting for this risk.

`);
  });
  const g = i.nonTextTags || [
    "script",
    "style",
    "textarea",
    "option"
  ];
  let d, _;
  i.allowedAttributes && (d = {}, _ = {}, Ht(i.allowedAttributes, function(x, C) {
    d[C] = [];
    const w = [];
    x.forEach(function(R) {
      typeof R == "string" && R.indexOf("*") >= 0 ? w.push(Eo(R).replace(/\\\*/g, ".*")) : d[C].push(R);
    }), w.length && (_[C] = new RegExp("^(" + w.join("|") + ")$"));
  }));
  const v = {}, S = {}, f = {};
  Ht(i.allowedClasses, function(x, C) {
    if (d && (tt(d, C) || (d[C] = []), d[C].push("class")), v[C] = x, Array.isArray(x)) {
      const w = [];
      v[C] = [], f[C] = [], x.forEach(function(R) {
        typeof R == "string" && R.indexOf("*") >= 0 ? w.push(Eo(R).replace(/\\\*/g, ".*")) : R instanceof RegExp ? f[C].push(R) : v[C].push(R);
      }), w.length && (S[C] = new RegExp("^(" + w.join("|") + ")$"));
    }
  });
  const m = {};
  let N;
  Ht(i.transformTags, function(x, C) {
    let w;
    typeof x == "function" ? w = x : typeof x == "string" && (w = Pi.simpleTransform(x)), C === "*" ? N = w : m[C] = w;
  });
  let I, E, z, H, U, G, re = !1;
  Le();
  const he = new O0.Parser({
    onopentag: function(x, C) {
      if (i.onOpenTag && i.onOpenTag(x, C), i.enforceHtmlBoundary && x === "html" && Le(), U) {
        G++;
        return;
      }
      const w = new c(x, C);
      E.push(w);
      let R = !1;
      const M = !!w.text;
      let V;
      if (tt(m, x) && (V = m[x](x, C), w.attribs = C = V.attribs, V.text !== void 0 && (w.innerText = V.text), x !== V.tagName && (w.name = x = V.tagName, H[I] = V.tagName)), N && (V = N(x, C), w.attribs = C = V.attribs, x !== V.tagName && (w.name = x = V.tagName, H[I] = V.tagName)), (!p(x) || i.disallowedTagsMode === "recursiveEscape" && !z0(z) || i.nestingLimit != null && I >= i.nestingLimit) && (R = !0, z[I] = !0, (i.disallowedTagsMode === "discard" || i.disallowedTagsMode === "completelyDiscard") && g.indexOf(x) !== -1 && (U = !0, G = 1)), I++, R) {
        if (i.disallowedTagsMode === "discard" || i.disallowedTagsMode === "completelyDiscard") {
          if (w.innerText && !M) {
            const F = se(w.innerText);
            i.textFilter ? r += i.textFilter(F, x) : r += F, re = !0;
          }
          return;
        }
        a = r, r = "";
      }
      r += "<" + x, x === "script" && (i.allowedScriptHostnames || i.allowedScriptDomains) && (w.innerText = ""), R && (i.disallowedTagsMode === "escape" || i.disallowedTagsMode === "recursiveEscape") && i.preserveEscapedAttributes ? Ht(C, function(F, j) {
        r += " " + j + '="' + se(F || "", !0) + '"';
      }) : (!d || tt(d, x) || d["*"]) && Ht(C, function(F, j) {
        if (!q0.test(j)) {
          delete w.attribs[j];
          return;
        }
        if (F === "" && !i.allowedEmptyAttributes.includes(j) && (i.nonBooleanAttributes.includes(j) || i.nonBooleanAttributes.includes("*"))) {
          delete w.attribs[j];
          return;
        }
        let K = !1;
        if (!d || tt(d, x) && d[x].indexOf(j) !== -1 || d["*"] && d["*"].indexOf(j) !== -1 || tt(_, x) && _[x].test(j) || _["*"] && _["*"].test(j))
          K = !0;
        else if (d && d[x]) {
          for (const X of d[x])
            if (I0(X) && X.name && X.name === j) {
              K = !0;
              let $ = "";
              if (X.multiple === !0) {
                const _e = F.split(" ");
                for (const Ee of _e)
                  X.values.indexOf(Ee) !== -1 && ($ === "" ? $ = Ee : $ += " " + Ee);
              } else
                X.values.indexOf(F) >= 0 && ($ = F);
              F = $;
            }
        }
        if (K) {
          if (i.allowedSchemesAppliedToAttributes.indexOf(j) !== -1 && be(x, F)) {
            delete w.attribs[j];
            return;
          }
          if (x === "script" && j === "src") {
            let X = !0;
            try {
              const $ = xe(F);
              if (i.allowedScriptHostnames || i.allowedScriptDomains) {
                const _e = (i.allowedScriptHostnames || []).find(function(Te) {
                  return Te === $.url.hostname;
                }), Ee = (i.allowedScriptDomains || []).find(function(Te) {
                  return $.url.hostname === Te || $.url.hostname.endsWith(`.${Te}`);
                });
                X = _e || Ee;
              }
            } catch {
              X = !1;
            }
            if (!X) {
              delete w.attribs[j];
              return;
            }
          }
          if (x === "iframe" && j === "src") {
            let X = !0;
            try {
              const $ = xe(F);
              if ($.isRelativeUrl)
                X = tt(i, "allowIframeRelativeUrls") ? i.allowIframeRelativeUrls : !i.allowedIframeHostnames && !i.allowedIframeDomains;
              else if (i.allowedIframeHostnames || i.allowedIframeDomains) {
                const _e = (i.allowedIframeHostnames || []).find(function(Te) {
                  return Te === $.url.hostname;
                }), Ee = (i.allowedIframeDomains || []).find(function(Te) {
                  return $.url.hostname === Te || $.url.hostname.endsWith(`.${Te}`);
                });
                X = _e || Ee;
              }
            } catch {
              X = !1;
            }
            if (!X) {
              delete w.attribs[j];
              return;
            }
          }
          if (j === "srcset")
            try {
              let X = k0(F);
              if (X.forEach(function($) {
                be("srcset", $.url) && ($.evil = !0);
              }), X = Co(X, function($) {
                return !$.evil;
              }), X.length)
                F = R0(Co(X, function($) {
                  return !$.evil;
                })), w.attribs[j] = F;
              else {
                delete w.attribs[j];
                return;
              }
            } catch {
              delete w.attribs[j];
              return;
            }
          if (j === "class") {
            const X = v[x], $ = v["*"], _e = S[x], Ee = f[x], Te = f["*"], We = S["*"], At = [
              _e,
              We
            ].concat(Ee, Te).filter(function(Ct) {
              return Ct;
            });
            if (X && $ ? F = Z(F, Ao(X, $), At) : F = Z(F, X || $, At), !F.length) {
              delete w.attribs[j];
              return;
            }
          }
          if (j === "style") {
            if (i.parseStyleAttributes)
              try {
                const X = N0(x + " {" + F + "}", { map: !1 }), $ = T(X, i.allowedStyles);
                if (F = A($), F.length === 0) {
                  delete w.attribs[j];
                  return;
                }
              } catch {
                typeof window < "u" && console.warn('Failed to parse "' + x + " {" + F + `}", If you're running this in a browser, we recommend to disable style parsing: options.parseStyleAttributes: false, since this only works in a node environment due to a postcss dependency, More info: https://github.com/apostrophecms/sanitize-html/issues/547`), delete w.attribs[j];
                return;
              }
            else if (i.allowedStyles)
              throw new Error("allowedStyles option cannot be used together with parseStyleAttributes: false.");
          }
          r += " " + j, F && F.length ? r += '="' + se(F, !0) + '"' : i.allowedEmptyAttributes.includes(j) && (r += '=""');
        } else
          delete w.attribs[j];
      }), i.selfClosing.indexOf(x) !== -1 ? r += " />" : (r += ">", w.innerText && !M && !i.textFilter && (r += se(w.innerText), re = !0)), R && (r = a + se(r), a = ""), w.openingTagLength = r.length - w.tagPosition;
    },
    ontext: function(x) {
      if (U)
        return;
      const C = E[E.length - 1];
      let w;
      if (C && (w = C.tag, x = C.innerText !== void 0 ? C.innerText : x), i.disallowedTagsMode === "completelyDiscard" && !p(w))
        x = "";
      else if ((i.disallowedTagsMode === "discard" || i.disallowedTagsMode === "completelyDiscard") && (w === "script" || w === "style"))
        r += x;
      else if (!re) {
        const R = se(x, !1);
        i.textFilter ? r += i.textFilter(R, w) : r += R;
      }
      if (E.length) {
        const R = E[E.length - 1];
        R.text += x;
      }
    },
    onclosetag: function(x, C) {
      if (i.onCloseTag && i.onCloseTag(x, C), U)
        if (G--, !G)
          U = !1;
        else
          return;
      const w = E.pop();
      if (!w)
        return;
      if (w.tag !== x) {
        E.push(w);
        return;
      }
      U = i.enforceHtmlBoundary ? x === "html" : !1, I--;
      const R = z[I];
      if (R) {
        if (delete z[I], i.disallowedTagsMode === "discard" || i.disallowedTagsMode === "completelyDiscard") {
          w.updateParentNodeText();
          return;
        }
        a = r, r = "";
      }
      if (H[I] && (x = H[I], delete H[I]), i.exclusiveFilter) {
        const M = i.exclusiveFilter(w);
        if (M === "excludeTag") {
          R && (r = a, a = ""), r = r.substring(0, w.tagPosition) + r.substring(w.tagPosition + w.openingTagLength);
          return;
        } else if (M) {
          r = r.substring(0, w.tagPosition);
          return;
        }
      }
      if (w.updateParentNodeMediaChildren(), w.updateParentNodeText(), // Already output />
      i.selfClosing.indexOf(x) !== -1 || // Escaped tag, closing tag is implied
      C && !p(x) && ["escape", "recursiveEscape"].indexOf(i.disallowedTagsMode) >= 0) {
        R && (r = a, a = "");
        return;
      }
      r += "</" + x + ">", R && (r = a + se(r), a = ""), re = !1;
    }
  }, i.parser);
  return he.write(o), he.end(), r;
  function Le() {
    r = "", I = 0, E = [], z = {}, H = {}, U = !1, G = 0;
  }
  function se(x, C) {
    return typeof x != "string" && (x = x + ""), i.parser.decodeEntities && (x = x.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"), C && (x = x.replace(/"/g, "&quot;"))), x = x.replace(/&(?![a-zA-Z0-9#]{1,20};)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"), C && (x = x.replace(/"/g, "&quot;")), x;
  }
  function be(x, C) {
    for (C = C.replace(/[\x00-\x20]+/g, ""); ; ) {
      const M = C.indexOf("<!--");
      if (M === -1)
        break;
      const V = C.indexOf("-->", M + 4);
      if (V === -1)
        break;
      C = C.substring(0, M) + C.substring(V + 3);
    }
    const w = C.match(/^([a-zA-Z][a-zA-Z0-9.\-+]*):/);
    if (!w)
      return C.match(/^[/\\]{2}/) ? !i.allowProtocolRelative : !1;
    const R = w[1].toLowerCase();
    return tt(i.allowedSchemesByTag, x) ? i.allowedSchemesByTag[x].indexOf(R) === -1 : !i.allowedSchemes || i.allowedSchemes.indexOf(R) === -1;
  }
  function xe(x) {
    if (x = x.replace(/^(\w+:)?\s*[\\/]\s*[\\/]/, "$1//"), x.startsWith("relative:"))
      throw new Error("relative: exploit attempt");
    let C = "relative://relative-site";
    for (let M = 0; M < 100; M++)
      C += `/${M}`;
    const w = new URL(x, C);
    return {
      isRelativeUrl: w && w.hostname === "relative-site" && w.protocol === "relative:",
      url: w
    };
  }
  function T(x, C) {
    if (!C)
      return x;
    const w = x.nodes[0];
    let R;
    return C[w.selector] && C["*"] ? R = Ao(
      C[w.selector],
      C["*"]
    ) : R = C[w.selector] || C["*"], R && (x.nodes[0].nodes = w.nodes.reduce(D(R), [])), x;
  }
  function A(x) {
    return x.nodes[0].nodes.reduce(function(C, w) {
      return C.push(
        `${w.prop}:${w.value}${w.important ? " !important" : ""}`
      ), C;
    }, []).join(";");
  }
  function D(x) {
    return function(C, w) {
      return tt(x, w.prop) && x[w.prop].some(function(M) {
        return M.test(w.value);
      }) && C.push(w), C;
    };
  }
  function Z(x, C, w) {
    return C ? (x = x.split(/\s+/), x.filter(function(R) {
      return C.indexOf(R) !== -1 || w.some(function(M) {
        return M.test(R);
      });
    }).join(" ")) : x;
  }
}
const Z0 = {
  decodeEntities: !0
};
Pi.defaults = {
  allowedTags: [
    // Sections derived from MDN element categories and limited to the more
    // benign categories.
    // https://developer.mozilla.org/en-US/docs/Web/HTML/Element
    // Content sectioning
    "address",
    "article",
    "aside",
    "footer",
    "header",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "hgroup",
    "main",
    "nav",
    "section",
    // Text content
    "blockquote",
    "dd",
    "div",
    "dl",
    "dt",
    "figcaption",
    "figure",
    "hr",
    "li",
    "menu",
    "ol",
    "p",
    "pre",
    "ul",
    // Inline text semantics
    "a",
    "abbr",
    "b",
    "bdi",
    "bdo",
    "br",
    "cite",
    "code",
    "data",
    "dfn",
    "em",
    "i",
    "kbd",
    "mark",
    "q",
    "rb",
    "rp",
    "rt",
    "rtc",
    "ruby",
    "s",
    "samp",
    "small",
    "span",
    "strong",
    "sub",
    "sup",
    "time",
    "u",
    "var",
    "wbr",
    // Table content
    "caption",
    "col",
    "colgroup",
    "table",
    "tbody",
    "td",
    "tfoot",
    "th",
    "thead",
    "tr"
  ],
  // Tags that cannot be boolean
  nonBooleanAttributes: [
    "abbr",
    "accept",
    "accept-charset",
    "accesskey",
    "action",
    "allow",
    "alt",
    "as",
    "autocapitalize",
    "autocomplete",
    "blocking",
    "charset",
    "cite",
    "class",
    "color",
    "cols",
    "colspan",
    "content",
    "contenteditable",
    "coords",
    "crossorigin",
    "data",
    "datetime",
    "decoding",
    "dir",
    "dirname",
    "download",
    "draggable",
    "enctype",
    "enterkeyhint",
    "fetchpriority",
    "for",
    "form",
    "formaction",
    "formenctype",
    "formmethod",
    "formtarget",
    "headers",
    "height",
    "hidden",
    "high",
    "href",
    "hreflang",
    "http-equiv",
    "id",
    "imagesizes",
    "imagesrcset",
    "inputmode",
    "integrity",
    "is",
    "itemid",
    "itemprop",
    "itemref",
    "itemtype",
    "kind",
    "label",
    "lang",
    "list",
    "loading",
    "low",
    "max",
    "maxlength",
    "media",
    "method",
    "min",
    "minlength",
    "name",
    "nonce",
    "optimum",
    "pattern",
    "ping",
    "placeholder",
    "popover",
    "popovertarget",
    "popovertargetaction",
    "poster",
    "preload",
    "referrerpolicy",
    "rel",
    "rows",
    "rowspan",
    "sandbox",
    "scope",
    "shape",
    "size",
    "sizes",
    "slot",
    "span",
    "spellcheck",
    "src",
    "srcdoc",
    "srclang",
    "srcset",
    "start",
    "step",
    "style",
    "tabindex",
    "target",
    "title",
    "translate",
    "type",
    "usemap",
    "value",
    "width",
    "wrap",
    // Event handlers
    "onauxclick",
    "onafterprint",
    "onbeforematch",
    "onbeforeprint",
    "onbeforeunload",
    "onbeforetoggle",
    "onblur",
    "oncancel",
    "oncanplay",
    "oncanplaythrough",
    "onchange",
    "onclick",
    "onclose",
    "oncontextlost",
    "oncontextmenu",
    "oncontextrestored",
    "oncopy",
    "oncuechange",
    "oncut",
    "ondblclick",
    "ondrag",
    "ondragend",
    "ondragenter",
    "ondragleave",
    "ondragover",
    "ondragstart",
    "ondrop",
    "ondurationchange",
    "onemptied",
    "onended",
    "onerror",
    "onfocus",
    "onformdata",
    "onhashchange",
    "oninput",
    "oninvalid",
    "onkeydown",
    "onkeypress",
    "onkeyup",
    "onlanguagechange",
    "onload",
    "onloadeddata",
    "onloadedmetadata",
    "onloadstart",
    "onmessage",
    "onmessageerror",
    "onmousedown",
    "onmouseenter",
    "onmouseleave",
    "onmousemove",
    "onmouseout",
    "onmouseover",
    "onmouseup",
    "onoffline",
    "ononline",
    "onpagehide",
    "onpageshow",
    "onpaste",
    "onpause",
    "onplay",
    "onplaying",
    "onpopstate",
    "onprogress",
    "onratechange",
    "onreset",
    "onresize",
    "onrejectionhandled",
    "onscroll",
    "onscrollend",
    "onsecuritypolicyviolation",
    "onseeked",
    "onseeking",
    "onselect",
    "onslotchange",
    "onstalled",
    "onstorage",
    "onsubmit",
    "onsuspend",
    "ontimeupdate",
    "ontoggle",
    "onunhandledrejection",
    "onunload",
    "onvolumechange",
    "onwaiting",
    "onwheel"
  ],
  disallowedTagsMode: "discard",
  allowedAttributes: {
    a: ["href", "name", "target"],
    // We don't currently allow img itself by default, but
    // these attributes would make sense if we did.
    img: ["src", "srcset", "alt", "title", "width", "height", "loading"]
  },
  allowedEmptyAttributes: [
    "alt"
  ],
  // Lots of these won't come up by default because we don't allow them
  selfClosing: ["img", "br", "hr", "area", "base", "basefont", "input", "link", "meta"],
  // URL schemes we permit
  allowedSchemes: ["http", "https", "ftp", "mailto", "tel"],
  allowedSchemesByTag: {},
  allowedSchemesAppliedToAttributes: ["href", "src", "cite"],
  allowProtocolRelative: !0,
  enforceHtmlBoundary: !1,
  parseStyleAttributes: !0,
  preserveEscapedAttributes: !1
};
Pi.simpleTransform = function(o, i, n) {
  return n = n === void 0 ? !0 : n, i = i || {}, function(r, a) {
    let c;
    if (n)
      for (c in i)
        a[c] = i[c];
    else
      a = i;
    return {
      tagName: o,
      attribs: a
    };
  };
};
const F0 = /* @__PURE__ */ Bo(j0);
const Mo = [
  [
    "requestFullscreen",
    "exitFullscreen",
    "fullscreenElement",
    "fullscreenEnabled",
    "fullscreenchange",
    "fullscreenerror"
  ],
  // New WebKit
  [
    "webkitRequestFullscreen",
    "webkitExitFullscreen",
    "webkitFullscreenElement",
    "webkitFullscreenEnabled",
    "webkitfullscreenchange",
    "webkitfullscreenerror"
  ],
  // Old WebKit
  [
    "webkitRequestFullScreen",
    "webkitCancelFullScreen",
    "webkitCurrentFullScreenElement",
    "webkitCancelFullScreen",
    "webkitfullscreenchange",
    "webkitfullscreenerror"
  ],
  [
    "mozRequestFullScreen",
    "mozCancelFullScreen",
    "mozFullScreenElement",
    "mozFullScreenEnabled",
    "mozfullscreenchange",
    "mozfullscreenerror"
  ],
  [
    "msRequestFullscreen",
    "msExitFullscreen",
    "msFullscreenElement",
    "msFullscreenEnabled",
    "MSFullscreenChange",
    "MSFullscreenError"
  ]
], it = (() => {
  if (typeof document > "u")
    return !1;
  const o = Mo[0], i = {};
  for (const n of Mo)
    if ((n == null ? void 0 : n[1]) in document) {
      for (const [a, c] of n.entries())
        i[o[a]] = c;
      return i;
    }
  return !1;
})(), Oo = {
  change: it.fullscreenchange,
  error: it.fullscreenerror
};
let De = {
  // eslint-disable-next-line default-param-last
  request(o = document.documentElement, i) {
    return new Promise((n, r) => {
      const a = () => {
        De.off("change", a), n();
      };
      De.on("change", a);
      const c = o[it.requestFullscreen](i);
      c instanceof Promise && c.then(a).catch(r);
    });
  },
  exit() {
    return new Promise((o, i) => {
      if (!De.isFullscreen) {
        o();
        return;
      }
      const n = () => {
        De.off("change", n), o();
      };
      De.on("change", n);
      const r = document[it.exitFullscreen]();
      r instanceof Promise && r.then(n).catch(i);
    });
  },
  toggle(o, i) {
    return De.isFullscreen ? De.exit() : De.request(o, i);
  },
  onchange(o) {
    De.on("change", o);
  },
  onerror(o) {
    De.on("error", o);
  },
  on(o, i) {
    const n = Oo[o];
    n && document.addEventListener(n, i, !1);
  },
  off(o, i) {
    const n = Oo[o];
    n && document.removeEventListener(n, i, !1);
  },
  raw: it
};
Object.defineProperties(De, {
  isFullscreen: {
    get: () => !!document[it.fullscreenElement]
  },
  element: {
    enumerable: !0,
    get: () => document[it.fullscreenElement] ?? void 0
  },
  isEnabled: {
    enumerable: !0,
    // Coerce to boolean in case of old WebKit.
    get: () => !!document[it.fullscreenEnabled]
  }
});
it || (De = { isEnabled: !1 });
const Io = De, $s = function(o, i, n, r, a) {
  let c = fe.DomUtil.create("a", n, r);
  return c.innerHTML = o, c.href = "#", c.title = i, c.setAttribute("role", "button"), c.setAttribute("aria-label", i), fe.DomEvent.disableClickPropagation(c), fe.DomEvent.on(c, "click", fe.DomEvent.stop), fe.DomEvent.on(c, "click", a, this), fe.DomEvent.on(c, "click", this._refocusOnMap, this), c;
}, Xs = fe.Control.extend({
  options: {
    position: "topright",
    fullScreenContent: '<span class="embedded-map-control embedded-map-location-icon"><i class="ph ph-arrows-out" style="font-size: 16px;" aria-hidden="true"></i><span>',
    fullScreenTitle: "Enter Fullscreen"
  },
  onAdd: function() {
    let o = "leaflet-control-fullscreen", i = fe.DomUtil.create("div", o + " leaflet-bar"), n = this.options;
    return this._fullScreenButton = this._createButton(
      n.fullScreenContent,
      n.fullScreenTitle,
      "map-fullscreen map-svg-button",
      i,
      this._fullScreen
    ), i;
  },
  _fullScreen: function() {
    let o = this._map;
    Io.isEnabled && Io.toggle(o.getContainer());
  },
  _createButton: $s
}), H0 = () => {
  fe.Map.mergeOptions({
    fullScreen: !1
  }), fe.Map.addInitHook(function() {
    this.options.fullScreen ? (this.fullScreenControl = new Xs(), this.addControl(this.fullScreenControl)) : this.fullScreenControl = null;
  });
}, Ys = fe.Control.extend({
  options: {
    position: "topright",
    locationContent: '<span class="embedded-map-control embedded-map-location-icon"><i class="ph ph-crosshair" style="font-size: 16px;" aria-hidden="true"></i><span>',
    locationTitle: "Show Your Location"
  },
  onAdd: function() {
    let o = "leaflet-control-location", i = fe.DomUtil.create("div", o + " leaflet-bar"), n = this.options;
    return this._locationButton = this._createButton(
      n.locationContent,
      n.locationTitle,
      "map-location map-svg-button",
      i,
      this._location
    ), this._updateDisabled(), i;
  },
  disable: function() {
    return this._disabled = !0, this._updateDisabled(), this;
  },
  enable: function() {
    return this._disabled = !1, this._updateDisabled(), this;
  },
  _location: function() {
    if (this._disabled == !0)
      return;
    this.disable();
    const o = (n) => {
      this._map.closePopup(), typeof this.options.onLocationSuccess == "function" && this.options.onLocationSuccess({
        lat: n.coords.latitude,
        lng: n.coords.longitude
      });
    }, i = (n) => {
      typeof this.options.onLocationFail == "function" && this.options.onLocationFail(n);
    };
    this._getPosition().then(o).catch(i).finally(() => {
      this.enable();
    });
  },
  _getPosition: function() {
    let o = {
      enableHighAccuracy: !1,
      timeout: 5e3,
      maximumAge: 3e4
    };
    return new Promise((i, n) => {
      navigator.geolocation.getCurrentPosition(i, n, o);
    });
  },
  _createButton: $s,
  _updateDisabled: function() {
    let o = "leaflet-disabled";
    fe.DomUtil.removeClass(this._locationButton, o), this._locationButton.setAttribute("aria-disabled", "false"), this._disabled && (fe.DomUtil.addClass(this._locationButton, o), this._locationButton.setAttribute("aria-disabled", "true"));
  }
}), U0 = () => {
  fe.Map.mergeOptions({
    location: !1,
    onLocationFail: null,
    onLocationSuccess: null
  }), fe.Map.addInitHook(function() {
    this.options.location ? (this.localControl = new Ys(), this.addControl(this.LocationControl)) : this.localControl = null;
  });
}, V0 = () => {
  H0(), U0();
};
function ko(o) {
  let i, n;
  return {
    c() {
      i = Cn("div"), n = Ur(
        /*error*/
        o[0]
      );
    },
    m(r, a) {
      Ei(r, i, a), gi(i, n);
    },
    p(r, a) {
      a[0] & /*error*/
      1 && _a(
        n,
        /*error*/
        r[0]
      );
    },
    d(r) {
      r && Ai(i);
    }
  };
}
function No(o) {
  let i, n, r, a, c;
  return n = new $u({
    props: {
      secondary: !0,
      quiet: !0,
      $$slots: { default: [W0] },
      $$scope: { ctx: o }
    }
  }), n.$on(
    "click",
    /*clearCandidateMarker*/
    o[8]
  ), a = new $u({
    props: {
      cta: !0,
      $$slots: { default: [G0] },
      $$scope: { ctx: o }
    }
  }), a.$on(
    "click",
    /*createMarker*/
    o[7]
  ), {
    c() {
      i = Cn("div"), Xu(n.$$.fragment), r = Sr(), Xu(a.$$.fragment), Sn(i, "class", "button-container svelte-1kf8258");
    },
    m(p, g) {
      Ei(p, i, g), Yu(n, i, null), gi(i, r), Yu(a, i, null), c = !0;
    },
    p(p, g) {
      const d = {};
      g[1] & /*$$scope*/
      134217728 && (d.$$scope = { dirty: g, ctx: p }), n.$set(d);
      const _ = {};
      g[1] & /*$$scope*/
      134217728 && (_.$$scope = { dirty: g, ctx: p }), a.$set(_);
    },
    i(p) {
      c || (_i(n.$$.fragment, p), _i(a.$$.fragment, p), c = !0);
    },
    o(p) {
      Mn(n.$$.fragment, p), Mn(a.$$.fragment, p), c = !1;
    },
    d(p) {
      p && Ai(i), Ku(n), Ku(a);
    }
  };
}
function W0(o) {
  let i;
  return {
    c() {
      i = Ur("Cancel");
    },
    m(n, r) {
      Ei(n, i, r);
    },
    d(n) {
      n && Ai(i);
    }
  };
}
function G0(o) {
  let i;
  return {
    c() {
      i = Ur("Create marker");
    },
    m(n, r) {
      Ei(n, i, r);
    },
    d(n) {
      n && Ai(i);
    }
  };
}
function $0(o) {
  let i, n, r, a, c, p, g, d, _ = (
    /*error*/
    o[0] && ko(o)
  ), v = (
    /*candidateMarkerPosition*/
    o[2] && No(o)
  );
  return {
    c() {
      i = Cn("div"), _ && _.c(), n = Sr(), r = Cn("div"), a = Sr(), v && v.c(), Sn(
        r,
        "id",
        /*embeddedMapId*/
        o[6]
      ), Sn(r, "class", "embedded embedded-map svelte-1kf8258"), Sn(i, "class", "embedded-map-wrapper map-default svelte-1kf8258");
    },
    m(S, f) {
      Ei(S, i, f), _ && _.m(i, null), gi(i, n), gi(i, r), o[26](r), gi(i, a), v && v.m(i, null), p = !0, g || (d = la(c = /*styleable*/
      o[4].call(
        null,
        i,
        /*$component*/
        o[3].styles
      )), g = !0);
    },
    p(S, f) {
      /*error*/
      S[0] ? _ ? _.p(S, f) : (_ = ko(S), _.c(), _.m(i, n)) : _ && (_.d(1), _ = null), /*candidateMarkerPosition*/
      S[2] ? v ? (v.p(S, f), f[0] & /*candidateMarkerPosition*/
      4 && _i(v, 1)) : (v = No(S), v.c(), _i(v, 1), v.m(i, null)) : v && (ca(), Mn(v, 1, 1, () => {
        v = null;
      }), ha()), c && da(c.update) && f[0] & /*$component*/
      8 && c.update.call(
        null,
        /*$component*/
        S[3].styles
      );
    },
    i(S) {
      p || (_i(v), p = !0);
    },
    o(S) {
      Mn(v), p = !1;
    },
    d(S) {
      S && Ai(i), _ && _.d(), o[26](null), v && v.d(), g = !1, d();
    }
  };
}
const X0 = 0, Do = 18;
function Y0(o, i, n) {
  let r, a, c, p, g;
  V0();
  let { dataProvider: d } = i, { error: _ } = i, { zoomLevel: v } = i, { zoomEnabled: S = !0 } = i, { latitudeKey: f = null } = i, { longitudeKey: m = null } = i, { titleKey: N = null } = i, { fullScreenEnabled: I = !0 } = i, { locationEnabled: E = !0 } = i, { defaultLocation: z } = i, { tileURL: H = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" } = i, { mapAttribution: U } = i, { creationEnabled: G = !1 } = i, { onClickMarker: re } = i, { onCreateMarker: he } = i;
  const { styleable: Le, notificationStore: se } = Gu("sdk"), be = Gu("component");
  fa(o, be, (O) => n(3, g = O));
  const xe = `${pa()}-wrapper`, T = new Ys({
    position: "bottomright",
    onLocationFail: (O) => {
      O.code === GeolocationPositionError.PERMISSION_DENIED ? se.actions.error("Location requests not permitted. Ensure location is enabled") : O.code === GeolocationPositionError.POSITION_UNAVAILABLE ? se.actions.warning("Location could not be retrieved. Try again") : O.code === GeolocationPositionError.TIMEOUT ? se.actions.warning("Location request timed out. Try again") : se.actions.error("Unknown location error");
    },
    onLocationSuccess: (O) => {
      X = O, typeof M == "object" && M.setView(X, 15);
    }
  }), A = new Xs({ position: "topright" }), D = fe.control.zoom({ position: "bottomright" }), Z = {
    html: '<div><i class="ph ph-map-pin ph-fill" style="font-size: 26px; color: #b12b27;" aria-hidden="true"></i></div>',
    className: "embedded-map-marker",
    iconSize: [26, 26],
    iconAnchor: [13, 26],
    popupAnchor: [0, -13]
  }, x = {
    icon: fe.divIcon(Z),
    draggable: !1,
    alt: "Location Marker"
  }, C = {
    icon: fe.divIcon({
      ...Z,
      className: "embedded-map-marker--candidate"
    }),
    draggable: !1,
    alt: "Location Marker"
  }, w = {
    fullScreen: !1,
    zoomControl: !1,
    scrollWheelZoom: S,
    minZoom: X0,
    maxZoom: Do
  }, R = [51.5072, -0.1276];
  let M, V, pe = new fe.FeatureGroup(), we = new fe.FeatureGroup(), F, j = !1, K = !1, X, $, _e;
  const Ee = (O) => !isNaN(O) && O > -90 && O < 90, Te = (O) => !isNaN(O) && O > -180 && O < 180, We = (O, ie, de) => !(O != null && O.length) || !ie || !de ? [] : O.filter((B) => Ee(B[ie]) && Te(B[de])), At = (O) => {
    let ie = O;
    return ie == null || isNaN(ie) ? ie = 50 : (ie = parseFloat(ie), ie = Math.max(0, Math.min(100, ie))), Math.round(ie * Do / 100);
  }, Ct = (O) => {
    if (typeof O != "string")
      return R;
    let ie = O.split(",");
    if (ie.length !== 2)
      return R;
    let de = parseFloat(ie[0].trim()), B = parseFloat(ie[1].trim());
    return Ee(de) === !0 && Te(B) === !0 ? [de, B] : R;
  }, Mt = () => {
    if (M)
      if (pe.getLayers().length) {
        const O = pe.getBounds();
        if (c) {
          const ie = O.getCenter();
          M.setView(ie, a);
        } else
          M.fitBounds(O, { paddingTopLeft: [0, 24] });
      } else
        M.setView(p, a);
  }, st = (O, ie) => {
    typeof O == "object" && (ie ? T.addTo(O) : O.removeControl(T));
  }, Ot = (O, ie) => {
    typeof O == "object" && (ie ? A.addTo(O) : O.removeControl(A));
  }, mt = (O, ie) => {
    typeof O == "object" && (ie ? (D.addTo(O), O.scrollWheelZoom.enable()) : (O.removeControl(D), O.scrollWheelZoom.disable()));
  }, Di = (O, ie, de, B, zi, Jt) => {
    O && (pe.clearLayers(), ie != null && ie.length && (ie.forEach((Ge) => {
      let Ri = [Ge[de], Ge[B]], It = fe.marker(Ri, x).addTo(O), ji = Gn(Ge[de], Ge[B], Ge[zi]);
      It.bindTooltip(ji, { direction: "top", offset: [0, -25] }).addTo(pe), Jt && It.on("click", () => {
        Jt({ marker: Ge });
      });
    }), K || (Mt(), K = !0)));
  }, Gn = (O, ie, de) => de || O + "," + ie, Bi = (O, ie) => {
    if (j) {
      M && M.remove();
      try {
        n(23, M = fe.map(xe, w)), pe.addTo(M), we.addTo(M);
        const de = F0(ie || "", {
          allowedTags: ["a"],
          allowedAttributes: { a: ["href", "target"] }
        });
        fe.tileLayer(O, {
          attribution: "&copy; " + de
        }).addTo(M), M.on("click", $n), Mt(), M.whenReady(() => {
          M.invalidateSize();
        });
      } catch (de) {
        console.error("There was a problem with the map", de);
      }
    }
  }, $n = (O) => {
    if (!G)
      return;
    we.clearLayers(), n(2, F = [O.latlng.lat, O.latlng.lng]), fe.marker(F, C).bindTooltip("New marker", {
      permanent: !0,
      direction: "top",
      offset: [0, -25]
    }).addTo(we).on("click", Kt);
  }, Xn = async () => {
    if (!he)
      return;
    await he({
      lat: F[0],
      lng: F[1]
    }) !== !1 && Kt();
  }, Kt = () => {
    we.clearLayers(), n(2, F = null);
  };
  ma(() => {
    j = !0, Bi(H, U), typeof ResizeObserver < "u" && V && ($ = new ResizeObserver(() => {
      clearTimeout(_e), _e = setTimeout(
        () => {
          M == null || M.invalidateSize();
        },
        150
      );
    }), $.observe(V));
  }), ga(() => {
    $ == null || $.disconnect(), clearTimeout(_e);
  });
  function Yn(O) {
    ba[O ? "unshift" : "push"](() => {
      V = O, n(1, V);
    });
  }
  return o.$$set = (O) => {
    "dataProvider" in O && n(9, d = O.dataProvider), "error" in O && n(0, _ = O.error), "zoomLevel" in O && n(10, v = O.zoomLevel), "zoomEnabled" in O && n(11, S = O.zoomEnabled), "latitudeKey" in O && n(12, f = O.latitudeKey), "longitudeKey" in O && n(13, m = O.longitudeKey), "titleKey" in O && n(14, N = O.titleKey), "fullScreenEnabled" in O && n(15, I = O.fullScreenEnabled), "locationEnabled" in O && n(16, E = O.locationEnabled), "defaultLocation" in O && n(17, z = O.defaultLocation), "tileURL" in O && n(18, H = O.tileURL), "mapAttribution" in O && n(19, U = O.mapAttribution), "creationEnabled" in O && n(20, G = O.creationEnabled), "onClickMarker" in O && n(21, re = O.onClickMarker), "onCreateMarker" in O && n(22, he = O.onCreateMarker);
  }, o.$$.update = () => {
    o.$$.dirty[0] & /*dataProvider, latitudeKey, longitudeKey*/
    12800 && n(25, r = We(d == null ? void 0 : d.rows, f, m)), o.$$.dirty[0] & /*zoomLevel*/
    1024 && (a = At(v)), o.$$.dirty[0] & /*zoomLevel*/
    1024 && (c = v != null && v !== ""), o.$$.dirty[0] & /*defaultLocation*/
    131072 && n(24, p = Ct(z)), o.$$.dirty[0] & /*tileURL, mapAttribution*/
    786432 && Bi(H, U), o.$$.dirty[0] & /*mapInstance, zoomEnabled*/
    8390656 && mt(M, S), o.$$.dirty[0] & /*mapInstance, locationEnabled*/
    8454144 && st(M, E), o.$$.dirty[0] & /*mapInstance, fullScreenEnabled*/
    8421376 && Ot(M, I), o.$$.dirty[0] & /*defaultCoordinates*/
    16777216 && Mt(), o.$$.dirty[0] & /*mapInstance, validRows, latitudeKey, longitudeKey, titleKey, onClickMarker*/
    44068864 && Di(M, r, f, m, N, re);
  }, [
    _,
    V,
    F,
    g,
    Le,
    be,
    xe,
    Xn,
    Kt,
    d,
    v,
    S,
    f,
    m,
    N,
    I,
    E,
    z,
    H,
    U,
    G,
    re,
    he,
    M,
    p,
    r,
    Yn
  ];
}
class mh extends oa {
  constructor(i) {
    super(), sa(
      this,
      i,
      Y0,
      $0,
      aa,
      {
        dataProvider: 9,
        error: 0,
        zoomLevel: 10,
        zoomEnabled: 11,
        latitudeKey: 12,
        longitudeKey: 13,
        titleKey: 14,
        fullScreenEnabled: 15,
        locationEnabled: 16,
        defaultLocation: 17,
        tileURL: 18,
        mapAttribution: 19,
        creationEnabled: 20,
        onClickMarker: 21,
        onCreateMarker: 22
      },
      null,
      [-1, -1]
    );
  }
}
export {
  mh as default
};
