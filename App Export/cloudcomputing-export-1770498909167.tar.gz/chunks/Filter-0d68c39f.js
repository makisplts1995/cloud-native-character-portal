import { S as ve, i as Ee, s as me, I as _t, e as Y, c as L, a as ie, b as W, f as j, m as P, g as Q, k as v, n as k, o as G, p as C, bR as Tt, ae as Le, v as be, al as dt, aL as ce, bS as He, bT as yt, bh as ze, F as Ot, ah as vt, ac as ye, ai as Et, l as mt, G as kt, H as At, J as wt, aj as Dt, bU as Ft, u as Be, b2 as w, z as _e, A as de, bV as Ie, bW as Ke, bX as Nt, bg as Rt, bY as Xe, ab as Ze, aK as gt, aM as pt, t as he, j as ke, aq as bt, B as Pe, y as Ce, br as xe, bZ as Je, d as pe, b1 as zt, b_ as Qe, b$ as Fe, bd as Bt, ad as It, bf as Ne, E as $e, aa as Lt, w as Pt, x as Ct, c0 as Vt, c1 as Re, c2 as et, N as tt, O as St, C as Mt, c3 as jt, D as Gt, c4 as Ut } from "./index-e79f0bb2.js";
import Wt from "./Container-5c26767f.js";
import { D as qt } from "./DatePicker-bd3b4fc9.js";
import { D as nt } from "./DatePicker-c2e8a5bb.js";
import { C as Qt } from "./CheckboxGroup-0b0feec9.js";
import { R as ht } from "./RadioGroup-22e84d5a.js";
import Yt from "./BBReferenceField-3e75d43c.js";
import { u as Ht } from "./utc-7f9d85e9.js";
import { F as Ye } from "./datasources-2b52ffcb.js";
import "./RelationshipField-c09d9c4a.js";
import "./Multiselect-9dd507ef.js";
import "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
import "./users-b6137f6b.js";
function Zt(r) {
  let e, n, t, l, o, i, f, m;
  return n = new nt({
    props: {
      value: (
        /*parsedFrom*/
        r[4]
      ),
      enableTime: (
        /*enableTime*/
        r[0]
      ),
      timeOnly: (
        /*timeOnly*/
        r[1]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        r[2]
      ),
      startDayOfWeek: (
        /*resolvedStartDayOfWeek*/
        r[5]
      )
    }
  }), n.$on(
    "change",
    /*change_handler*/
    r[14]
  ), o = new _t({ props: { name: "caret-right" } }), f = new nt({
    props: {
      value: (
        /*parsedTo*/
        r[3]
      ),
      enableTime: (
        /*enableTime*/
        r[0]
      ),
      timeOnly: (
        /*timeOnly*/
        r[1]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        r[2]
      ),
      startDayOfWeek: (
        /*resolvedStartDayOfWeek*/
        r[5]
      )
    }
  }), f.$on(
    "change",
    /*change_handler_1*/
    r[15]
  ), {
    c() {
      e = Y("div"), L(n.$$.fragment), t = ie(), l = Y("div"), L(o.$$.fragment), i = ie(), L(f.$$.fragment), W(l, "class", "arrow svelte-1i3abvq"), W(e, "class", "date-range svelte-1i3abvq");
    },
    m(s, b) {
      j(s, e, b), P(n, e, null), Q(e, t), Q(e, l), P(o, l, null), Q(e, i), P(f, e, null), m = !0;
    },
    p(s, [b]) {
      const h = {};
      b & /*parsedFrom*/
      16 && (h.value = /*parsedFrom*/
      s[4]), b & /*enableTime*/
      1 && (h.enableTime = /*enableTime*/
      s[0]), b & /*timeOnly*/
      2 && (h.timeOnly = /*timeOnly*/
      s[1]), b & /*ignoreTimezones*/
      4 && (h.ignoreTimezones = /*ignoreTimezones*/
      s[2]), b & /*resolvedStartDayOfWeek*/
      32 && (h.startDayOfWeek = /*resolvedStartDayOfWeek*/
      s[5]), n.$set(h);
      const p = {};
      b & /*parsedTo*/
      8 && (p.value = /*parsedTo*/
      s[3]), b & /*enableTime*/
      1 && (p.enableTime = /*enableTime*/
      s[0]), b & /*timeOnly*/
      2 && (p.timeOnly = /*timeOnly*/
      s[1]), b & /*ignoreTimezones*/
      4 && (p.ignoreTimezones = /*ignoreTimezones*/
      s[2]), b & /*resolvedStartDayOfWeek*/
      32 && (p.startDayOfWeek = /*resolvedStartDayOfWeek*/
      s[5]), f.$set(p);
    },
    i(s) {
      m || (v(n.$$.fragment, s), v(o.$$.fragment, s), v(f.$$.fragment, s), m = !0);
    },
    o(s) {
      k(n.$$.fragment, s), k(o.$$.fragment, s), k(f.$$.fragment, s), m = !1;
    },
    d(s) {
      s && G(e), C(n), C(o), C(f);
    }
  };
}
function Jt(r, e, n) {
  let t, l, o, i, { enableTime: f = !1 } = e, { timeOnly: m = !1 } = e, { ignoreTimezones: s = !1 } = e;
  const b = Tt();
  let { startDayOfWeek: h = void 0 } = e, { value: p = [] } = e;
  const y = Le(), O = dt();
  be(r, O, (g) => n(13, i = g));
  let u, a;
  const R = (g) => {
    !Array.isArray(g) || !g[0] || !g[1] ? (n(11, u = null), n(12, a = null)) : (n(11, u = ce(g[0])), n(12, a = ce(g[1])));
  }, T = (g) => {
    const E = g ? f ? ce(g) : ce(g).startOf("day") : null;
    E && (!a || E.isAfter(a)) ? n(12, a = f ? E : E.endOf("day")) : E || n(12, a = null), y("change", [E, a]);
  }, A = (g) => {
    const E = g ? f ? ce(g) : ce(g).startOf("day") : null;
    E && (!u || E.isBefore(u)) ? n(11, u = f ? E : E.startOf("day")) : E || n(11, u = null), y("change", [u, E]);
  }, U = (g) => T(g.detail), B = (g) => A(g.detail);
  return r.$$set = (g) => {
    "enableTime" in g && n(0, f = g.enableTime), "timeOnly" in g && n(1, m = g.timeOnly), "ignoreTimezones" in g && n(2, s = g.ignoreTimezones), "startDayOfWeek" in g && n(9, h = g.startDayOfWeek), "value" in g && n(10, p = g.value);
  }, r.$$.update = () => {
    r.$$.dirty & /*value*/
    1024 && O.set(p || []), r.$$.dirty & /*$valueStore*/
    8192 && R(i), r.$$.dirty & /*startDayOfWeek*/
    512 && n(5, t = h ?? b), r.$$.dirty & /*fromDate, enableTime*/
    2049 && n(4, l = u ? He(u, { enableTime: f }) : void 0), r.$$.dirty & /*toDate, enableTime*/
    4097 && n(3, o = a ? He(a, { enableTime: f }) : void 0);
  }, [
    f,
    m,
    s,
    o,
    l,
    t,
    O,
    T,
    A,
    h,
    p,
    u,
    a,
    i,
    U,
    B
  ];
}
class Kt extends ve {
  constructor(e) {
    super(), Ee(this, e, Jt, Zt, me, {
      enableTime: 0,
      timeOnly: 1,
      ignoreTimezones: 2,
      startDayOfWeek: 9,
      value: 10
    });
  }
}
function Xt(r) {
  let e, n;
  return e = new Kt({
    props: {
      error: (
        /*error*/
        r[5]
      ),
      disabled: (
        /*disabled*/
        r[3]
      ),
      readonly: (
        /*readonly*/
        r[4]
      ),
      value: (
        /*value*/
        r[0]
      ),
      appendTo: (
        /*appendTo*/
        r[7]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        r[8]
      ),
      enableTime: (
        /*enableTime*/
        r[9]
      ),
      timeOnly: (
        /*timeOnly*/
        r[10]
      )
    }
  }), e.$on(
    "change",
    /*onChange*/
    r[11]
  ), {
    c() {
      L(e.$$.fragment);
    },
    m(t, l) {
      P(e, t, l), n = !0;
    },
    p(t, l) {
      const o = {};
      l & /*error*/
      32 && (o.error = /*error*/
      t[5]), l & /*disabled*/
      8 && (o.disabled = /*disabled*/
      t[3]), l & /*readonly*/
      16 && (o.readonly = /*readonly*/
      t[4]), l & /*value*/
      1 && (o.value = /*value*/
      t[0]), l & /*appendTo*/
      128 && (o.appendTo = /*appendTo*/
      t[7]), l & /*ignoreTimezones*/
      256 && (o.ignoreTimezones = /*ignoreTimezones*/
      t[8]), l & /*enableTime*/
      512 && (o.enableTime = /*enableTime*/
      t[9]), l & /*timeOnly*/
      1024 && (o.timeOnly = /*timeOnly*/
      t[10]), e.$set(o);
    },
    i(t) {
      n || (v(e.$$.fragment, t), n = !0);
    },
    o(t) {
      k(e.$$.fragment, t), n = !1;
    },
    d(t) {
      C(e, t);
    }
  };
}
function xt(r) {
  let e, n;
  return e = new yt({
    props: {
      helpText: (
        /*helpText*/
        r[6]
      ),
      label: (
        /*label*/
        r[1]
      ),
      labelPosition: (
        /*labelPosition*/
        r[2]
      ),
      error: (
        /*error*/
        r[5]
      ),
      $$slots: { default: [Xt] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      L(e.$$.fragment);
    },
    m(t, l) {
      P(e, t, l), n = !0;
    },
    p(t, [l]) {
      const o = {};
      l & /*helpText*/
      64 && (o.helpText = /*helpText*/
      t[6]), l & /*label*/
      2 && (o.label = /*label*/
      t[1]), l & /*labelPosition*/
      4 && (o.labelPosition = /*labelPosition*/
      t[2]), l & /*error*/
      32 && (o.error = /*error*/
      t[5]), l & /*$$scope, error, disabled, readonly, value, appendTo, ignoreTimezones, enableTime, timeOnly*/
      10169 && (o.$$scope = { dirty: l, ctx: t }), e.$set(o);
    },
    i(t) {
      n || (v(e.$$.fragment, t), n = !0);
    },
    o(t) {
      k(e.$$.fragment, t), n = !1;
    },
    d(t) {
      C(e, t);
    }
  };
}
function $t(r, e, n) {
  let { value: t = void 0 } = e, { label: l = null } = e, { labelPosition: o = "above" } = e, { disabled: i = !1 } = e, { readonly: f = !1 } = e, { error: m = null } = e, { helpText: s = null } = e, { appendTo: b = void 0 } = e, { ignoreTimezones: h = !1 } = e, { enableTime: p = !1 } = e, { timeOnly: y = !1 } = e;
  const O = Le(), u = (a) => {
    n(0, t = a.detail), O("change", a.detail);
  };
  return r.$$set = (a) => {
    "value" in a && n(0, t = a.value), "label" in a && n(1, l = a.label), "labelPosition" in a && n(2, o = a.labelPosition), "disabled" in a && n(3, i = a.disabled), "readonly" in a && n(4, f = a.readonly), "error" in a && n(5, m = a.error), "helpText" in a && n(6, s = a.helpText), "appendTo" in a && n(7, b = a.appendTo), "ignoreTimezones" in a && n(8, h = a.ignoreTimezones), "enableTime" in a && n(9, p = a.enableTime), "timeOnly" in a && n(10, y = a.timeOnly);
  }, [
    t,
    l,
    o,
    i,
    f,
    m,
    s,
    b,
    h,
    p,
    y,
    u
  ];
}
class en extends ve {
  constructor(e) {
    super(), Ee(this, e, $t, xt, me, {
      value: 0,
      label: 1,
      labelPosition: 2,
      disabled: 3,
      readonly: 4,
      error: 5,
      helpText: 6,
      appendTo: 7,
      ignoreTimezones: 8,
      enableTime: 9,
      timeOnly: 10
    });
  }
}
function Oe(r) {
  return r === ze.CONTAINS_ANY || r === ze.ONE_OF;
}
function tn(r) {
  const e = r.slice(), n = Oe(
    /*editableFilter*/
    e[13].operator
  );
  return e[45] = n, e;
}
function nn(r) {
  const e = r.slice(), n = Oe(
    /*editableFilter*/
    e[13].operator
  );
  e[43] = n;
  const t = (
    /*isMulti*/
    e[43] ? Qt : ht
  );
  return e[44] = t, e;
}
const rn = (r) => ({}), rt = (r) => ({});
function lt(r) {
  let e, n, t, l, o, i, f, m, s, b;
  n = new gt({
    props: {
      quiet: !0,
      value: (
        /*editableFilter*/
        r[13].operator
      ),
      disabled: !/*editableFilter*/
      r[13].field,
      options: (
        /*operators*/
        r[5]
      ),
      autoWidth: !0
    }
  }), n.$on(
    "change",
    /*change_handler*/
    r[28]
  );
  const h = [
    _n,
    cn,
    fn,
    un,
    an,
    sn,
    on,
    ln
  ], p = [];
  function y(u, a) {
    var R, T, A;
    return a[0] & /*editableFilter*/
    8192 && (l = null), a[0] & /*editableFilter*/
    8192 && (o = null), l == null && (l = !!/*editableFilter*/
    ((R = u[13]) != null && R.type && [
      w.STRING,
      w.LONGFORM,
      w.NUMBER,
      w.BIGINT,
      w.FORMULA,
      w.AI
    ].includes(
      /*editableFilter*/
      u[13].type
    ))), l ? 0 : (
      /*editableFilter*/
      (T = u[13]) != null && T.type && /*editableFilter*/
      ((A = u[13]) == null ? void 0 : A.type) === w.ARRAY || /*editableFilter*/
      u[13].type === w.OPTIONS && /*editableFilter*/
      u[13].operator === ze.ONE_OF ? 1 : (
        /*editableFilter*/
        u[13].type === w.OPTIONS ? 2 : (
          /*editableFilter*/
          u[13].type === w.DATETIME && /*editableFilter*/
          u[13].operator === "range" ? 3 : (
            /*editableFilter*/
            u[13].type === w.DATETIME ? 4 : (
              /*editableFilter*/
              u[13].type === w.BOOLEAN ? 5 : (o == null && (o = !!/*editableFilter*/
              (u[13].type && [w.BB_REFERENCE, w.BB_REFERENCE_SINGLE].includes(
                /*editableFilter*/
                u[13].type
              ))), o ? 6 : 7)
            )
          )
        )
      )
    );
  }
  function O(u, a) {
    return a === 1 ? nn(u) : a === 6 ? tn(u) : u;
  }
  return i = y(r, [-1, -1]), f = p[i] = h[i](O(r, i)), s = new pt({
    props: {
      cta: !0,
      $$slots: { default: [dn] },
      $$scope: { ctx: r }
    }
  }), s.$on(
    "click",
    /*click_handler*/
    r[35]
  ), {
    c() {
      e = Y("div"), L(n.$$.fragment), t = ie(), f.c(), m = ie(), L(s.$$.fragment), W(e, "class", "operator svelte-y8gc31");
    },
    m(u, a) {
      j(u, e, a), P(n, e, null), j(u, t, a), p[i].m(u, a), j(u, m, a), P(s, u, a), b = !0;
    },
    p(u, a) {
      const R = {};
      a[0] & /*editableFilter*/
      8192 && (R.value = /*editableFilter*/
      u[13].operator), a[0] & /*editableFilter*/
      8192 && (R.disabled = !/*editableFilter*/
      u[13].field), a[0] & /*operators*/
      32 && (R.options = /*operators*/
      u[5]), n.$set(R);
      let T = i;
      i = y(u, a), i === T ? p[i].p(O(u, i), a) : (_e(), k(p[T], 1, 1, () => {
        p[T] = null;
      }), de(), f = p[i], f ? f.p(O(u, i), a) : (f = p[i] = h[i](O(u, i)), f.c()), v(f, 1), f.m(m.parentNode, m));
      const A = {};
      a[0] & /*buttonText*/
      16 | a[1] & /*$$scope*/
      512 && (A.$$scope = { dirty: a, ctx: u }), s.$set(A);
    },
    i(u) {
      b || (v(n.$$.fragment, u), v(f), v(s.$$.fragment, u), b = !0);
    },
    o(u) {
      k(n.$$.fragment, u), k(f), k(s.$$.fragment, u), b = !1;
    },
    d(u) {
      u && (G(e), G(t), G(m)), C(n), p[i].d(u), C(s, u);
    }
  };
}
function ln(r) {
  let e, n;
  return e = new bt({ props: { disabled: !0 } }), {
    c() {
      L(e.$$.fragment);
    },
    m(t, l) {
      P(e, t, l), n = !0;
    },
    p: Pe,
    i(t) {
      n || (v(e.$$.fragment, t), n = !0);
    },
    o(t) {
      k(e.$$.fragment, t), n = !1;
    },
    d(t) {
      C(e, t);
    }
  };
}
function on(r) {
  let e = (
    /*multi*/
    r[45]
  ), n, t, l = ot(r);
  return {
    c() {
      l.c(), n = Ce();
    },
    m(o, i) {
      l.m(o, i), j(o, n, i), t = !0;
    },
    p(o, i) {
      i[0] & /*editableFilter*/
      8192 && me(e, e = /*multi*/
      o[45]) ? (_e(), k(l, 1, 1, Pe), de(), l = ot(o), l.c(), v(l, 1), l.m(n.parentNode, n)) : l.p(o, i);
    },
    i(o) {
      t || (v(l), t = !0);
    },
    o(o) {
      k(l), t = !1;
    },
    d(o) {
      o && G(n), l.d(o);
    }
  };
}
function sn(r) {
  let e, n;
  return e = new gt({
    props: {
      value: (
        /*editableFilter*/
        r[13].value
      ),
      disabled: (
        /*editableFilter*/
        r[13].noValue
      ),
      options: [{ label: "True", value: "true" }, { label: "False", value: "false" }]
    }
  }), e.$on(
    "change",
    /*change_handler_6*/
    r[34]
  ), {
    c() {
      L(e.$$.fragment);
    },
    m(t, l) {
      P(e, t, l), n = !0;
    },
    p(t, l) {
      const o = {};
      l[0] & /*editableFilter*/
      8192 && (o.value = /*editableFilter*/
      t[13].value), l[0] & /*editableFilter*/
      8192 && (o.disabled = /*editableFilter*/
      t[13].noValue), e.$set(o);
    },
    i(t) {
      n || (v(e.$$.fragment, t), n = !0);
    },
    o(t) {
      k(e.$$.fragment, t), n = !1;
    },
    d(t) {
      C(e, t);
    }
  };
}
function an(r) {
  let e, n;
  return e = new qt({
    props: {
      enableTime: (
        /*enableTime*/
        r[10]
      ),
      timeOnly: (
        /*timeOnly*/
        r[11]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        r[12]
      ),
      disabled: (
        /*editableFilter*/
        r[13].noValue
      ),
      value: (
        /*editableFilter*/
        r[13].value
      )
    }
  }), e.$on(
    "change",
    /*change_handler_5*/
    r[33]
  ), {
    c() {
      L(e.$$.fragment);
    },
    m(t, l) {
      P(e, t, l), n = !0;
    },
    p(t, l) {
      const o = {};
      l[0] & /*enableTime*/
      1024 && (o.enableTime = /*enableTime*/
      t[10]), l[0] & /*timeOnly*/
      2048 && (o.timeOnly = /*timeOnly*/
      t[11]), l[0] & /*ignoreTimezones*/
      4096 && (o.ignoreTimezones = /*ignoreTimezones*/
      t[12]), l[0] & /*editableFilter*/
      8192 && (o.disabled = /*editableFilter*/
      t[13].noValue), l[0] & /*editableFilter*/
      8192 && (o.value = /*editableFilter*/
      t[13].value), e.$set(o);
    },
    i(t) {
      n || (v(e.$$.fragment, t), n = !0);
    },
    o(t) {
      k(e.$$.fragment, t), n = !1;
    },
    d(t) {
      C(e, t);
    }
  };
}
function un(r) {
  let e, n;
  return e = new en({
    props: {
      enableTime: (
        /*enableTime*/
        r[10]
      ),
      timeOnly: (
        /*timeOnly*/
        r[11]
      ),
      ignoreTimezones: (
        /*ignoreTimezones*/
        r[12]
      ),
      value: (
        /*parseDateRange*/
        r[18](
          /*editableFilter*/
          r[13].value
        )
      )
    }
  }), e.$on(
    "change",
    /*change_handler_4*/
    r[32]
  ), {
    c() {
      L(e.$$.fragment);
    },
    m(t, l) {
      P(e, t, l), n = !0;
    },
    p(t, l) {
      const o = {};
      l[0] & /*enableTime*/
      1024 && (o.enableTime = /*enableTime*/
      t[10]), l[0] & /*timeOnly*/
      2048 && (o.timeOnly = /*timeOnly*/
      t[11]), l[0] & /*ignoreTimezones*/
      4096 && (o.ignoreTimezones = /*ignoreTimezones*/
      t[12]), l[0] & /*editableFilter*/
      8192 && (o.value = /*parseDateRange*/
      t[18](
        /*editableFilter*/
        t[13].value
      )), e.$set(o);
    },
    i(t) {
      n || (v(e.$$.fragment, t), n = !0);
    },
    o(t) {
      k(e.$$.fragment, t), n = !1;
    },
    d(t) {
      C(e, t);
    }
  };
}
function fn(r) {
  let e, n;
  return e = new ht({
    props: {
      value: (
        /*editableFilter*/
        r[13].value
      ),
      disabled: (
        /*editableFilter*/
        r[13].noValue
      ),
      options: (
        /*options*/
        r[14]
      ),
      direction: "vertical"
    }
  }), e.$on(
    "change",
    /*change_handler_3*/
    r[31]
  ), {
    c() {
      L(e.$$.fragment);
    },
    m(t, l) {
      P(e, t, l), n = !0;
    },
    p(t, l) {
      const o = {};
      l[0] & /*editableFilter*/
      8192 && (o.value = /*editableFilter*/
      t[13].value), l[0] & /*editableFilter*/
      8192 && (o.disabled = /*editableFilter*/
      t[13].noValue), l[0] & /*options*/
      16384 && (o.options = /*options*/
      t[14]), e.$set(o);
    },
    i(t) {
      n || (v(e.$$.fragment, t), n = !0);
    },
    o(t) {
      k(e.$$.fragment, t), n = !1;
    },
    d(t) {
      C(e, t);
    }
  };
}
function cn(r) {
  let e = (
    /*type*/
    r[44]
  ), n, t, l = it(r);
  return {
    c() {
      l.c(), n = Ce();
    },
    m(o, i) {
      l.m(o, i), j(o, n, i), t = !0;
    },
    p(o, i) {
      i[0] & /*editableFilter*/
      8192 && me(e, e = /*type*/
      o[44]) ? (_e(), k(l, 1, 1, Pe), de(), l = it(o), l.c(), v(l, 1), l.m(n.parentNode, n)) : l.p(o, i);
    },
    i(o) {
      t || (v(l), t = !0);
    },
    o(o) {
      k(l), t = !1;
    },
    d(o) {
      o && G(n), l.d(o);
    }
  };
}
function _n(r) {
  let e, n;
  return e = new bt({
    props: {
      disabled: (
        /*editableFilter*/
        r[13].noValue
      ),
      value: (
        /*editableFilter*/
        r[13].value
      )
    }
  }), e.$on(
    "change",
    /*change_handler_1*/
    r[29]
  ), {
    c() {
      L(e.$$.fragment);
    },
    m(t, l) {
      P(e, t, l), n = !0;
    },
    p(t, l) {
      const o = {};
      l[0] & /*editableFilter*/
      8192 && (o.disabled = /*editableFilter*/
      t[13].noValue), l[0] & /*editableFilter*/
      8192 && (o.value = /*editableFilter*/
      t[13].value), e.$set(o);
    },
    i(t) {
      n || (v(e.$$.fragment, t), n = !0);
    },
    o(t) {
      k(e.$$.fragment, t), n = !1;
    },
    d(t) {
      C(e, t);
    }
  };
}
function ot(r) {
  let e, n;
  return e = new Yt({
    props: {
      disabled: (
        /*editableFilter*/
        r[13].noValue
      ),
      defaultValue: (
        /*editableFilter*/
        r[13].value
      ),
      multi: (
        /*multi*/
        r[45]
      ),
      onChange: (
        /*changeUser*/
        r[20]
      ),
      defaultRows: Object.values(
        /*$rowCache*/
        r[15]
      )
    }
  }), e.$on(
    "rows",
    /*cacheUserRows*/
    r[21]
  ), {
    c() {
      L(e.$$.fragment);
    },
    m(t, l) {
      P(e, t, l), n = !0;
    },
    p(t, l) {
      const o = {};
      l[0] & /*editableFilter*/
      8192 && (o.disabled = /*editableFilter*/
      t[13].noValue), l[0] & /*editableFilter*/
      8192 && (o.defaultValue = /*editableFilter*/
      t[13].value), l[0] & /*editableFilter*/
      8192 && (o.multi = /*multi*/
      t[45]), l[0] & /*$rowCache*/
      32768 && (o.defaultRows = Object.values(
        /*$rowCache*/
        t[15]
      )), e.$set(o);
    },
    i(t) {
      n || (v(e.$$.fragment, t), n = !0);
    },
    o(t) {
      k(e.$$.fragment, t), n = !1;
    },
    d(t) {
      C(e, t);
    }
  };
}
function it(r) {
  let e, n, t;
  var l = (
    /*type*/
    r[44]
  );
  function o(i, f) {
    return {
      props: {
        value: (
          /*editableFilter*/
          i[13].value || []
        ),
        disabled: (
          /*editableFilter*/
          i[13].noValue
        ),
        options: (
          /*options*/
          i[14]
        ),
        direction: "vertical"
      }
    };
  }
  return l && (e = xe(l, o(r)), e.$on(
    "change",
    /*change_handler_2*/
    r[30]
  )), {
    c() {
      e && L(e.$$.fragment), n = Ce();
    },
    m(i, f) {
      e && P(e, i, f), j(i, n, f), t = !0;
    },
    p(i, f) {
      if (f[0] & /*editableFilter*/
      8192 && l !== (l = /*type*/
      i[44])) {
        if (e) {
          _e();
          const m = e;
          k(m.$$.fragment, 1, 0, () => {
            C(m, 1);
          }), de();
        }
        l ? (e = xe(l, o(i)), e.$on(
          "change",
          /*change_handler_2*/
          i[30]
        ), L(e.$$.fragment), v(e.$$.fragment, 1), P(e, n.parentNode, n)) : e = null;
      } else if (l) {
        const m = {};
        f[0] & /*editableFilter*/
        8192 && (m.value = /*editableFilter*/
        i[13].value || []), f[0] & /*editableFilter*/
        8192 && (m.disabled = /*editableFilter*/
        i[13].noValue), f[0] & /*options*/
        16384 && (m.options = /*options*/
        i[14]), e.$set(m);
      }
    },
    i(i) {
      t || (e && v(e.$$.fragment, i), t = !0);
    },
    o(i) {
      e && k(e.$$.fragment, i), t = !1;
    },
    d(i) {
      i && G(n), e && C(e, i);
    }
  };
}
function dn(r) {
  let e = (
    /*buttonText*/
    (r[4] || "Apply") + ""
  ), n;
  return {
    c() {
      n = he(e);
    },
    m(t, l) {
      j(t, n, l);
    },
    p(t, l) {
      l[0] & /*buttonText*/
      16 && e !== (e = /*buttonText*/
      (t[4] || "Apply") + "") && ke(n, e);
    },
    d(t) {
      t && G(n);
    }
  };
}
function mn(r) {
  let e, n, t, l = (
    /*editableFilter*/
    r[13] && /*fieldSchema*/
    r[6] && lt(r)
  );
  return {
    c() {
      e = Y("div"), n = Y("div"), l && l.c(), W(n, "class", "filter-popover-body svelte-y8gc31"), W(e, "class", "filter-popover svelte-y8gc31");
    },
    m(o, i) {
      j(o, e, i), Q(e, n), l && l.m(n, null), t = !0;
    },
    p(o, i) {
      /*editableFilter*/
      o[13] && /*fieldSchema*/
      o[6] ? l ? (l.p(o, i), i[0] & /*editableFilter, fieldSchema*/
      8256 && v(l, 1)) : (l = lt(o), l.c(), v(l, 1), l.m(n, null)) : l && (_e(), k(l, 1, 1, () => {
        l = null;
      }), de());
    },
    i(o) {
      t || (v(l), t = !0);
    },
    o(o) {
      k(l), t = !1;
    },
    d(o) {
      o && G(e), l && l.d();
    }
  };
}
function gn(r) {
  let e, n, t, l, o, i, f;
  const m = (
    /*#slots*/
    r[26].anchor
  ), s = Ot(
    m,
    r,
    /*$$scope*/
    r[40],
    rt
  );
  function b(p) {
    r[37](p);
  }
  let h = {
    minWidth: 300,
    maxWidth: 300,
    anchor: (
      /*anchor*/
      r[8]
    ),
    align: (
      /*align*/
      r[2]
    ),
    showPopover: (
      /*showPopover*/
      r[3]
    ),
    customZIndex: 5,
    $$slots: { default: [mn] },
    $$scope: { ctx: r }
  };
  return (
    /*open*/
    r[9] !== void 0 && (h.open = /*open*/
    r[9]), t = new vt({ props: h }), r[36](t), ye.push(() => Et(t, "open", b)), t.$on(
      "open",
      /*open_handler*/
      r[38]
    ), t.$on(
      "close",
      /*close_handler*/
      r[39]
    ), {
      c() {
        e = Y("div"), s && s.c(), n = ie(), L(t.$$.fragment), W(e, "class", "anchor");
      },
      m(p, y) {
        j(p, e, y), s && s.m(e, null), r[27](e), j(p, n, y), P(t, p, y), o = !0, i || (f = mt(
          e,
          "click",
          /*show*/
          r[0]
        ), i = !0);
      },
      p(p, y) {
        s && s.p && (!o || y[1] & /*$$scope*/
        512) && kt(
          s,
          m,
          p,
          /*$$scope*/
          p[40],
          o ? wt(
            m,
            /*$$scope*/
            p[40],
            y,
            rn
          ) : At(
            /*$$scope*/
            p[40]
          ),
          rt
        );
        const O = {};
        y[0] & /*anchor*/
        256 && (O.anchor = /*anchor*/
        p[8]), y[0] & /*align*/
        4 && (O.align = /*align*/
        p[2]), y[0] & /*showPopover*/
        8 && (O.showPopover = /*showPopover*/
        p[3]), y[0] & /*editableFilter, buttonText, options, enableTime, timeOnly, ignoreTimezones, $rowCache, operators, fieldSchema*/
        64624 | y[1] & /*$$scope*/
        512 && (O.$$scope = { dirty: y, ctx: p }), !l && y[0] & /*open*/
        512 && (l = !0, O.open = /*open*/
        p[9], Dt(() => l = !1)), t.$set(O);
      },
      i(p) {
        o || (v(s, p), v(t.$$.fragment, p), o = !0);
      },
      o(p) {
        k(s, p), k(t.$$.fragment, p), o = !1;
      },
      d(p) {
        p && (G(e), G(n)), s && s.d(p), r[27](null), r[36](null), C(t, p), i = !1, f();
      }
    }
  );
}
function pn(r, e, n) {
  let t, l, o, i, { $$slots: f = {}, $$scope: m } = e;
  ce.extend(Ht);
  const s = () => B == null ? void 0 : B.show(), b = () => B == null ? void 0 : B.hide();
  let { align: h = Ft.Left } = e, { showPopover: p = !0 } = e, { filter: y = void 0 } = e, { schema: O = null } = e, { buttonText: u = void 0 } = e, { config: a = void 0 } = e, { defaultOperator: R = void 0 } = e, { operators: T = void 0 } = e;
  const A = Le(), U = Be("rows");
  be(r, U, (c) => n(15, i = c));
  let B, g, E = !1, S, X, H;
  const z = (c) => {
    if (!c)
      return;
    const D = [c.low, c.high];
    if (D.filter((N) => N).length === 2)
      return D;
  }, Z = (c) => {
    var oe;
    if (!c)
      return;
    const D = Ie(c), N = Oe(c.operator);
    N && typeof c.value == "string" && ![w.STRING, w.NUMBER].includes(c.type) ? D.value = [c.value] : N && !((oe = c == null ? void 0 : c.value) != null && oe.length) ? delete D.value : !N && Array.isArray(c.value) && (D.value = c.value[0]);
    const q = [Ke.Empty.value, Ke.NotEmpty.value];
    return D.noValue = q.includes(D.operator), D != null && D.operator || delete D.value, D;
  }, ge = (c) => {
    if (!c)
      return [];
    const D = l == null ? void 0 : l.constraints;
    return (D == null ? void 0 : D.inclusion) ?? [];
  }, d = (c, D, N) => {
    var Te;
    if (c)
      return Ie(c);
    if (!D || !N)
      return;
    const q = D[N.field], oe = (q == null ? void 0 : q.type) === w.BOOLEAN ? "true" : void 0, Ge = {
      valueType: Nt.VALUE,
      field: N.field,
      type: q == null ? void 0 : q.type,
      operator: Rt.EMPTY,
      value: oe
    }, Ae = (we) => {
      var De;
      return we && ((De = T == null ? void 0 : T.find((_) => _.value === we)) == null ? void 0 : De.value);
    }, Ue = (Te = T == null ? void 0 : T[0]) == null ? void 0 : Te.value, We = Ae(N == null ? void 0 : N.defaultOperator), qe = Ae(R);
    return {
      ...Ge,
      operator: We ?? qe ?? Ue
    };
  }, V = (c) => {
    !c || !t || n(13, t = Z({ ...t, value: c.value }));
  }, K = (c) => {
    const D = c.detail.reduce(
      (N, q) => (N[q._id] = q, N),
      {}
    );
    U.update((N) => ({ ...N, ...D }));
  };
  function ne(c) {
    ye[c ? "unshift" : "push"](() => {
      g = c, n(8, g);
    });
  }
  const x = (c) => {
    if (!t)
      return;
    const D = Z({ ...t, operator: c.detail });
    n(13, t = { ...D || t });
  }, se = (c) => {
    t && n(13, t = Z({ ...t, value: c.detail }));
  }, re = (c) => {
    t && n(13, t = Z({ ...t, value: c.detail }));
  }, Ve = (c) => {
    t && n(13, t = Z({ ...t, value: c.detail }));
  }, ae = (c) => {
    const [D, N] = c.detail, q = S ? D.utc().format() : Xe(D, { enableTime: S, timeOnly: X, ignoreTimezones: H }), oe = S ? N.utc().format() : Xe(N, { enableTime: S, timeOnly: X, ignoreTimezones: H });
    t && n(13, t = Z({
      ...t,
      value: { low: q, high: oe }
    }));
  }, ue = (c) => {
    t && n(13, t = Z({ ...t, value: c.detail }));
  }, J = (c) => {
    t && n(13, t = Z({ ...t, value: c.detail }));
  }, le = () => {
    const c = Z(t), { noValue: D, value: N, operator: q } = c || {};
    A("change", !D && !N || !q ? void 0 : c), b();
  };
  function $(c) {
    ye[c ? "unshift" : "push"](() => {
      B = c, n(7, B);
    });
  }
  function Se(c) {
    E = c, n(9, E);
  }
  function Me(c) {
    Ze.call(this, r, c);
  }
  function je(c) {
    Ze.call(this, r, c);
  }
  return r.$$set = (c) => {
    "align" in c && n(2, h = c.align), "showPopover" in c && n(3, p = c.showPopover), "filter" in c && n(22, y = c.filter), "schema" in c && n(23, O = c.schema), "buttonText" in c && n(4, u = c.buttonText), "config" in c && n(24, a = c.config), "defaultOperator" in c && n(25, R = c.defaultOperator), "operators" in c && n(5, T = c.operators), "$$scope" in c && n(40, m = c.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty[0] & /*filter, schema, config*/
    29360128 && n(13, t = d(y, O, a)), r.$$.dirty[0] & /*config, schema*/
    25165824 && n(6, l = a ? O == null ? void 0 : O[a == null ? void 0 : a.field] : void 0), r.$$.dirty[0] & /*fieldSchema*/
    64 && n(14, o = ge(l)), r.$$.dirty[0] & /*fieldSchema*/
    64 && (l == null ? void 0 : l.type) === w.DATETIME && (n(10, S = !(l != null && l.dateOnly)), n(11, X = !!(l != null && l.timeOnly)), n(12, H = !!(l != null && l.ignoreTimezones)));
  }, [
    s,
    b,
    h,
    p,
    u,
    T,
    l,
    B,
    g,
    E,
    S,
    X,
    H,
    t,
    o,
    i,
    A,
    U,
    z,
    Z,
    V,
    K,
    y,
    O,
    a,
    R,
    f,
    ne,
    x,
    se,
    re,
    Ve,
    ae,
    ue,
    J,
    le,
    $,
    Se,
    Me,
    je,
    m
  ];
}
class bn extends ve {
  constructor(e) {
    super(), Ee(
      this,
      e,
      pn,
      gn,
      me,
      {
        show: 0,
        hide: 1,
        align: 2,
        showPopover: 3,
        filter: 22,
        schema: 23,
        buttonText: 4,
        config: 24,
        defaultOperator: 25,
        operators: 5
      },
      null,
      [-1, -1]
    );
  }
  get show() {
    return this.$$.ctx[0];
  }
  get hide() {
    return this.$$.ctx[1];
  }
}
function hn(r) {
  let e;
  return {
    c() {
      e = he(
        /*buttonText*/
        r[2]
      );
    },
    m(n, t) {
      j(n, e, t);
    },
    p(n, t) {
      t & /*buttonText*/
      4 && ke(
        e,
        /*buttonText*/
        n[2]
      );
    },
    d(n) {
      n && G(e);
    }
  };
}
function st(r) {
  let e, n;
  return {
    c() {
      e = Y("span"), n = he(
        /*filterDisplay*/
        r[12]
      ), W(e, "class", "display svelte-1ohvvxo");
    },
    m(t, l) {
      j(t, e, l), Q(e, n);
    },
    p(t, l) {
      l & /*filterDisplay*/
      4096 && ke(
        n,
        /*filterDisplay*/
        t[12]
      );
    },
    d(t) {
      t && G(e);
    }
  };
}
function at(r) {
  let e, n;
  return {
    c() {
      e = Y("span"), n = he(
        /*filterMeta*/
        r[10]
      ), W(e, "class", "filterMeta");
    },
    m(t, l) {
      j(t, e, l), Q(e, n);
    },
    p(t, l) {
      l & /*filterMeta*/
      1024 && ke(
        n,
        /*filterMeta*/
        t[10]
      );
    },
    d(t) {
      t && G(e);
    }
  };
}
function Tn(r) {
  var U, B;
  let e, n, t, l, o, i, f, m, s = (
    /*config*/
    (((U = r[5]) == null ? void 0 : U.label) || /*config*/
    ((B = r[5]) == null ? void 0 : B.field)) + ""
  ), b, h, p, y, O, u, a, R;
  o = new _t({
    props: {
      name: (
        /*iconName*/
        r[14]
      ),
      size: (
        /*size*/
        r[1]
      )
    }
  });
  let T = (
    /*filter*/
    r[4] && st(r)
  ), A = (
    /*filterMeta*/
    r[10] && at(r)
  );
  return {
    c() {
      e = Y("div"), n = Y("div"), t = Y("div"), l = Y("div"), L(o.$$.fragment), i = ie(), f = Y("span"), m = Y("span"), b = he(s), h = ie(), T && T.c(), p = ie(), A && A.c(), W(l, "class", "toggle-wrap svelte-1ohvvxo"), W(m, "class", "field"), W(f, "class", "spectrum-Button-label svelte-1ohvvxo"), pe(
        f,
        "truncate",
        /*truncate*/
        r[13]
      ), W(t, "class", y = "new-styles spectrum-Button spectrum-Button--secondary spectrum-Button--size" + /*size*/
      r[1].toUpperCase() + " svelte-1ohvvxo"), W(t, "title", O = /*filterTitle*/
      r[11] || /*filterDisplay*/
      r[12]), pe(
        t,
        "is-disabled",
        /*disabled*/
        r[0]
      ), W(n, "class", "filter-button-wrap svelte-1ohvvxo"), pe(n, "inactive", !/*filter*/
      r[4]), W(e, "slot", "anchor");
    },
    m(g, E) {
      j(g, e, E), Q(e, n), Q(n, t), Q(t, l), P(o, l, null), Q(t, i), Q(t, f), Q(f, m), Q(m, b), Q(f, h), T && T.m(f, null), Q(t, p), A && A.m(t, null), r[20](t), u = !0, a || (R = mt(
        l,
        "click",
        /*click_handler*/
        r[19]
      ), a = !0);
    },
    p(g, E) {
      var X, H;
      const S = {};
      E & /*iconName*/
      16384 && (S.name = /*iconName*/
      g[14]), E & /*size*/
      2 && (S.size = /*size*/
      g[1]), o.$set(S), (!u || E & /*config*/
      32) && s !== (s = /*config*/
      (((X = g[5]) == null ? void 0 : X.label) || /*config*/
      ((H = g[5]) == null ? void 0 : H.field)) + "") && ke(b, s), /*filter*/
      g[4] ? T ? T.p(g, E) : (T = st(g), T.c(), T.m(f, null)) : T && (T.d(1), T = null), (!u || E & /*truncate*/
      8192) && pe(
        f,
        "truncate",
        /*truncate*/
        g[13]
      ), /*filterMeta*/
      g[10] ? A ? A.p(g, E) : (A = at(g), A.c(), A.m(t, null)) : A && (A.d(1), A = null), (!u || E & /*size*/
      2 && y !== (y = "new-styles spectrum-Button spectrum-Button--secondary spectrum-Button--size" + /*size*/
      g[1].toUpperCase() + " svelte-1ohvvxo")) && W(t, "class", y), (!u || E & /*filterTitle, filterDisplay*/
      6144 && O !== (O = /*filterTitle*/
      g[11] || /*filterDisplay*/
      g[12])) && W(t, "title", O), (!u || E & /*size, disabled*/
      3) && pe(
        t,
        "is-disabled",
        /*disabled*/
        g[0]
      ), (!u || E & /*filter*/
      16) && pe(n, "inactive", !/*filter*/
      g[4]);
    },
    i(g) {
      u || (v(o.$$.fragment, g), u = !0);
    },
    o(g) {
      k(o.$$.fragment, g), u = !1;
    },
    d(g) {
      g && G(e), C(o), T && T.d(), A && A.d(), r[20](null), a = !1, R();
    }
  };
}
function yn(r) {
  let e, n, t = {
    filter: (
      /*filter*/
      r[4]
    ),
    operators: (
      /*operators*/
      r[7]
    ),
    schema: (
      /*schema*/
      r[6]
    ),
    config: (
      /*config*/
      r[5]
    ),
    buttonText: (
      /*buttonText*/
      r[2]
    ),
    defaultOperator: (
      /*defaultOperator*/
      r[3]
    ),
    $$slots: {
      anchor: [Tn],
      default: [hn]
    },
    $$scope: { ctx: r }
  };
  return e = new bn({ props: t }), r[21](e), e.$on(
    "change",
    /*change_handler*/
    r[22]
  ), {
    c() {
      L(e.$$.fragment);
    },
    m(l, o) {
      P(e, l, o), n = !0;
    },
    p(l, [o]) {
      const i = {};
      o & /*filter*/
      16 && (i.filter = /*filter*/
      l[4]), o & /*operators*/
      128 && (i.operators = /*operators*/
      l[7]), o & /*schema*/
      64 && (i.schema = /*schema*/
      l[6]), o & /*config*/
      32 && (i.config = /*config*/
      l[5]), o & /*buttonText*/
      4 && (i.buttonText = /*buttonText*/
      l[2]), o & /*defaultOperator*/
      8 && (i.defaultOperator = /*defaultOperator*/
      l[3]), o & /*$$scope, filter, size, filterTitle, filterDisplay, button, disabled, filterMeta, truncate, config, iconName, buttonText*/
      134250039 && (i.$$scope = { dirty: o, ctx: l }), e.$set(i);
    },
    i(l) {
      n || (v(e.$$.fragment, l), n = !0);
    },
    o(l) {
      k(e.$$.fragment, l), n = !1;
    },
    d(l) {
      r[21](null), C(e, l);
    }
  };
}
function On(r, e, n) {
  let t, l, o, i, f, m, { disabled: s = !1 } = e, { size: b = "S" } = e, { buttonText: h = "Apply" } = e, { defaultOperator: p = void 0 } = e, { filter: y = void 0 } = e, { config: O = void 0 } = e, { schema: u = null } = e, { operators: a = void 0 } = e;
  const R = Le(), T = Be("rows");
  be(r, T, (d) => n(23, m = d));
  let A, U, B, g;
  const E = (d, V) => {
    if (!d || !V || V.type !== w.DATETIME)
      return "";
    if (d.operator === Je.RANGE) {
      const x = !V.dateOnly, { high: se, low: re } = d.value;
      return `${Qe(re, { enableTime: x })}
        - ${Qe(se, { enableTime: x })}`;
    }
    const K = He(d.value, { enableTime: !V.dateOnly });
    return `${Qe(K, { enableTime: !V.dateOnly })}`;
  }, S = (d) => {
    const V = Array.isArray(d) && (d == null ? void 0 : d.length) > 1 ? `+${(d == null ? void 0 : d.length) - 1} more` : void 0;
    return n(10, B = V), n(11, g = `${d == null ? void 0 : d.join(", ")}`), `${d == null ? void 0 : d[0]}`;
  }, X = (d, V) => {
    if (n(10, B = void 0), n(11, g = void 0), !d || !V)
      return;
    let K = d.value;
    if (V.type === w.BOOLEAN)
      K = zt(d.value);
    else if (V.type === w.DATETIME)
      K = E(d, V);
    else if (V.type === w.ARRAY)
      if (!Oe(d.operator))
        K = d.value;
      else {
        const ne = Array.isArray(d.value) ? d.value : [d.value];
        K = S(ne);
      }
    else if (V.type === w.BB_REFERENCE || V.type === w.BB_REFERENCE_SINGLE) {
      let ne = "";
      if (Oe(d.operator)) {
        const x = Array.isArray(d.value) ? d.value : [d.value];
        ne = S(x.map((se) => {
          var re;
          return ((re = m == null ? void 0 : m[se]) == null ? void 0 : re.email) ?? se;
        }));
      } else {
        const x = m == null ? void 0 : m[d.value];
        ne = (x == null ? void 0 : x.email) ?? d.value;
      }
      K = ne;
    }
    return `${o == null ? void 0 : o.label.toLowerCase()} ${d.noValue ? "" : K}`;
  }, H = (d) => {
    y && d.stopPropagation(), s || R("toggle");
  };
  function z(d) {
    ye[d ? "unshift" : "push"](() => {
      U = d, n(9, U);
    });
  }
  function Z(d) {
    ye[d ? "unshift" : "push"](() => {
      A = d, n(8, A);
    });
  }
  function ge(d) {
    Ze.call(this, r, d);
  }
  return r.$$set = (d) => {
    "disabled" in d && n(0, s = d.disabled), "size" in d && n(1, b = d.size), "buttonText" in d && n(2, h = d.buttonText), "defaultOperator" in d && n(3, p = d.defaultOperator), "filter" in d && n(4, y = d.filter), "config" in d && n(5, O = d.config), "schema" in d && n(6, u = d.schema), "operators" in d && n(7, a = d.operators);
  }, r.$$.update = () => {
    r.$$.dirty & /*filter*/
    16 && n(14, t = y ? "x-circle" : "sliders-horizontal"), r.$$.dirty & /*config, schema*/
    96 && n(18, l = O ? u == null ? void 0 : u[O == null ? void 0 : O.field] : void 0), r.$$.dirty & /*filter, operators*/
    144 && n(17, o = y ? a == null ? void 0 : a.find((d) => d.value === y.operator) : void 0), r.$$.dirty & /*filterOp*/
    131072 && n(13, i = (o == null ? void 0 : o.value) !== Je.RANGE), r.$$.dirty & /*filter, fieldSchema*/
    262160 && n(12, f = X(y, l));
  }, [
    s,
    b,
    h,
    p,
    y,
    O,
    u,
    a,
    A,
    U,
    B,
    g,
    f,
    i,
    t,
    R,
    T,
    o,
    l,
    H,
    z,
    Z,
    ge
  ];
}
class vn extends ve {
  constructor(e) {
    super(), Ee(this, e, On, yn, me, {
      disabled: 0,
      size: 1,
      buttonText: 2,
      defaultOperator: 3,
      filter: 4,
      config: 5,
      schema: 6,
      operators: 7
    });
  }
}
function ut(r, e, n) {
  const t = r.slice();
  t[54] = e[n];
  const l = (
    /*$memoFilters*/
    t[7][
      /*config*/
      t[54].field
    ]
  );
  return t[55] = l, t;
}
function ft(r) {
  let e, n;
  function t(...o) {
    return (
      /*change_handler*/
      r[30](
        /*config*/
        r[54],
        ...o
      )
    );
  }
  function l() {
    return (
      /*toggle_handler*/
      r[31](
        /*config*/
        r[54]
      )
    );
  }
  return e = new vn({
    props: {
      size: (
        /*size*/
        r[1]
      ),
      config: (
        /*config*/
        r[54]
      ),
      filter: (
        /*filter*/
        r[55]
      ),
      schema: (
        /*schema*/
        r[6]
      ),
      buttonText: (
        /*buttonText*/
        r[2]
      ),
      defaultOperator: (
        /*defaultOperator*/
        r[3]
      ),
      operators: (
        /*getOperators*/
        r[11](
          /*config*/
          r[54],
          /*schema*/
          r[6]
        )
      )
    }
  }), e.$on("change", t), e.$on("toggle", l), {
    c() {
      L(e.$$.fragment);
    },
    m(o, i) {
      P(e, o, i), n = !0;
    },
    p(o, i) {
      r = o;
      const f = {};
      i[0] & /*size*/
      2 && (f.size = /*size*/
      r[1]), i[0] & /*visibleFilters*/
      256 && (f.config = /*config*/
      r[54]), i[0] & /*$memoFilters, visibleFilters*/
      384 && (f.filter = /*filter*/
      r[55]), i[0] & /*schema*/
      64 && (f.schema = /*schema*/
      r[6]), i[0] & /*buttonText*/
      4 && (f.buttonText = /*buttonText*/
      r[2]), i[0] & /*defaultOperator*/
      8 && (f.defaultOperator = /*defaultOperator*/
      r[3]), i[0] & /*visibleFilters, schema*/
      320 && (f.operators = /*getOperators*/
      r[11](
        /*config*/
        r[54],
        /*schema*/
        r[6]
      )), e.$set(f);
    },
    i(o) {
      n || (v(e.$$.fragment, o), n = !0);
    },
    o(o) {
      k(e.$$.fragment, o), n = !1;
    },
    d(o) {
      C(e, o);
    }
  };
}
function ct(r) {
  let e, n;
  return e = new pt({
    props: {
      size: (
        /*size*/
        r[1]
      ),
      secondary: !0,
      $$slots: { default: [En] },
      $$scope: { ctx: r }
    }
  }), e.$on(
    "click",
    /*clearAll*/
    r[12]
  ), {
    c() {
      L(e.$$.fragment);
    },
    m(t, l) {
      P(e, t, l), n = !0;
    },
    p(t, l) {
      const o = {};
      l[0] & /*size*/
      2 && (o.size = /*size*/
      t[1]), l[1] & /*$$scope*/
      134217728 && (o.$$scope = { dirty: l, ctx: t }), e.$set(o);
    },
    i(t) {
      n || (v(e.$$.fragment, t), n = !0);
    },
    o(t) {
      k(e.$$.fragment, t), n = !1;
    },
    d(t) {
      C(e, t);
    }
  };
}
function En(r) {
  let e;
  return {
    c() {
      e = he("Clear all");
    },
    m(n, t) {
      j(n, e, t);
    },
    d(n) {
      n && G(e);
    }
  };
}
function kn(r) {
  let e, n = (
    /*showClear*/
    r[0] && Object.keys(
      /*filters*/
      r[5]
    ).length
  ), t, l, o = tt(
    /*visibleFilters*/
    r[8] || []
  ), i = [];
  for (let s = 0; s < o.length; s += 1)
    i[s] = ft(ut(r, o, s));
  const f = (s) => k(i[s], 1, 1, () => {
    i[s] = null;
  });
  let m = n && ct(r);
  return {
    c() {
      for (let s = 0; s < i.length; s += 1)
        i[s].c();
      e = ie(), m && m.c(), t = Ce();
    },
    m(s, b) {
      for (let h = 0; h < i.length; h += 1)
        i[h] && i[h].m(s, b);
      j(s, e, b), m && m.m(s, b), j(s, t, b), l = !0;
    },
    p(s, b) {
      if (b[0] & /*size, visibleFilters, $memoFilters, schema, buttonText, defaultOperator, getOperators, filters*/
      2542) {
        o = tt(
          /*visibleFilters*/
          s[8] || []
        );
        let h;
        for (h = 0; h < o.length; h += 1) {
          const p = ut(s, o, h);
          i[h] ? (i[h].p(p, b), v(i[h], 1)) : (i[h] = ft(p), i[h].c(), v(i[h], 1), i[h].m(e.parentNode, e));
        }
        for (_e(), h = o.length; h < i.length; h += 1)
          f(h);
        de();
      }
      b[0] & /*showClear, filters*/
      33 && (n = /*showClear*/
      s[0] && Object.keys(
        /*filters*/
        s[5]
      ).length), n ? m ? (m.p(s, b), b[0] & /*showClear, filters*/
      33 && v(m, 1)) : (m = ct(s), m.c(), v(m, 1), m.m(t.parentNode, t)) : m && (_e(), k(m, 1, 1, () => {
        m = null;
      }), de());
    },
    i(s) {
      if (!l) {
        for (let b = 0; b < o.length; b += 1)
          v(i[b]);
        v(m), l = !0;
      }
    },
    o(s) {
      i = i.filter(Boolean);
      for (let b = 0; b < i.length; b += 1)
        k(i[b]);
      k(m), l = !1;
    },
    d(s) {
      s && (G(e), G(t)), St(i, s), m && m.d(s);
    }
  };
}
function An(r) {
  let e, n, t, l;
  return t = new Wt({
    props: {
      wrap: !0,
      direction: "row",
      hAlign: "left",
      vAlign: "top",
      gap: "S",
      $$slots: { default: [kn] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      e = Y("div"), n = Y("div"), L(t.$$.fragment), W(n, "class", "filters svelte-u18njk");
    },
    m(o, i) {
      j(o, e, i), Q(e, n), P(t, n, null), l = !0;
    },
    p(o, i) {
      const f = {};
      i[0] & /*size, showClear, filters, visibleFilters, $memoFilters, schema, buttonText, defaultOperator*/
      495 | i[1] & /*$$scope*/
      134217728 && (f.$$scope = { dirty: i, ctx: o }), t.$set(f);
    },
    i(o) {
      l || (v(t.$$.fragment, o), l = !0);
    },
    o(o) {
      k(t.$$.fragment, o), l = !1;
    },
    d(o) {
      o && G(e), C(t);
    }
  };
}
function wn(r, e, n) {
  let t, l, o, i, f, m, s, b, h, p, y, O, u, a, R, T, A, U, B = Pe, g = () => (B(), B = Mt(ae, (_) => n(29, U = _)), ae), E;
  be(r, Fe, (_) => n(36, A = _)), r.$$.on_destroy.push(() => B());
  let { persistFilters: S = !1 } = e, { showClear: X = !1 } = e, { filterConfig: H = [] } = e, { targetComponent: z } = e, { size: Z = "M" } = e, { buttonText: ge = "Apply" } = e, { defaultOperator: d = void 0 } = e;
  const V = Bt({});
  be(r, V, (_) => n(7, E = _));
  const K = Be("component");
  be(r, K, (_) => n(35, T = _));
  const { API: ne, fetchDatasourceSchema: x, getRelationshipSchemaAdditions: se } = Be("sdk"), re = dt({});
  It("rows", re);
  const Ve = {
    logicalOperator: Ne.ALL,
    onEmptyFilter: $e.RETURN_NONE,
    groups: [
      {
        logicalOperator: Ne.ALL,
        // could be configurable
        filters: []
      }
    ]
  };
  let ae, ue = !1, J = {}, le, $ = null;
  const Se = (_) => {
    !$ && _ ? (n(17, $ = _), ue || Te()) : $ && !_ && (n(16, ue = !1), n(17, $ = null), n(5, J = {}), n(6, le = null));
  }, Me = (_, F) => {
    if (!(_ != null && _.field) || !_.columnType || !F)
      return [];
    const M = _.columnType || F[_.field].type;
    let I = Ut({ type: M }, _.field, o);
    const te = M === w.DATETIME, ee = {
      rangeHigh: te ? "Before" : void 0,
      rangeLow: te ? "After" : void 0,
      [Ye.EQUAL]: "Is",
      [Ye.NOT_EQUAL]: "Is not"
    };
    return I = [
      ...I,
      ...M === w.DATETIME ? [
        {
          value: Je.RANGE,
          label: "Between"
        }
      ] : []
    ], I.filter((fe) => !(te && fe.value === Ye.ONE_OF)).map((fe) => ({
      ...fe,
      label: ee[fe.value] || fe.label
    }));
  }, je = (_) => {
    const F = Ie(Ve);
    if (delete F.onEmptyFilter, F.groups) {
      const M = F.groups;
      M[0].filters = Object.values(_);
    }
    return F;
  }, c = (_) => {
    if (!(!(T != null && T.id) || !i)) {
      if (Object.keys(J).length == 0) {
        O == null || O(T.id), D();
        return;
      }
      S && D(), y == null || y(T.id, s ? _ : l);
    }
  }, D = () => {
    Fe.update((_) => ({
      ..._,
      [T.id]: {
        sourceId: o.resourceId,
        filters: J
      }
    }));
  }, N = () => {
    Fe.update((_) => (delete _[T.id], _));
  }, q = [w.ATTACHMENT_SINGLE, w.ATTACHMENTS, w.AI];
  async function oe(_) {
    if (_) {
      const F = await x(_, {
        enrichRelationships: !0,
        formSchema: !1
      }), M = Object.entries(F || {}).filter(([ee, fe]) => !q.includes(fe.type)), I = Object.fromEntries(M), te = await se(I);
      n(6, le = { ...I, ...te });
    } else
      n(6, le = null);
  }
  const Ge = (_, F) => Me(_, F), Ae = () => {
    n(5, J = {}), Fe.update((_) => (delete _[T.id], _));
  }, Ue = (_) => {
    let F = {
      logicalOperator: Ne.ALL,
      filters: [
        {
          field: "_id",
          operator: ze.ONE_OF,
          value: Array.isArray(_) ? _ : [_]
        }
      ]
    }, M = _ ? {
      logicalOperator: Ne.ALL,
      groups: [F],
      onEmptyFilter: $e.RETURN_NONE
    } : void 0;
    const I = {
      type: "user",
      tableId: jt.USER_METADATA
    };
    return Gt({
      API: ne,
      datasource: I,
      options: { filter: M, limit: 100 }
    });
  }, We = (_) => {
    const F = Object.entries(_ || {}).filter(([M, I]) => I.type === w.BB_REFERENCE_SINGLE || I.type === w.BB_REFERENCE);
    return Object.fromEntries(F);
  }, qe = (_) => {
    const F = Object.entries(_ || {}).reduce(
      (I, [te, ee]) => ((ee.type === w.BB_REFERENCE_SINGLE || ee.type === w.BB_REFERENCE) && ee.value && (I = [
        ...I,
        ...Array.isArray(ee.value) ? ee.value : [ee.value]
      ]), I),
      []
    ), M = new Set(F);
    return Array.from(M);
  }, Te = () => {
    var _;
    if (S) {
      const F = (_ = A[T.id]) == null ? void 0 : _.filters;
      n(5, J = Ie(F || {}));
    }
    n(16, ue = !0);
  };
  Lt(() => {
    S ? Te() : N();
  }), Pt(() => {
    O == null || O(T.id);
  });
  const we = (_, F) => {
    if (F.detail)
      n(5, J = { ...J, [_.field]: F.detail });
    else {
      const { [_.field]: M, ...I } = J;
      n(5, J = { ...I });
    }
  }, De = (_) => {
    const { [_.field]: F, ...M } = J;
    n(5, J = { ...M });
  };
  return r.$$set = (_) => {
    "persistFilters" in _ && n(13, S = _.persistFilters), "showClear" in _ && n(0, X = _.showClear), "filterConfig" in _ && n(14, H = _.filterConfig), "targetComponent" in _ && n(15, z = _.targetComponent), "size" in _ && n(1, Z = _.size), "buttonText" in _ && n(2, ge = _.buttonText), "defaultOperator" in _ && n(3, d = _.defaultOperator);
  }, r.$$.update = () => {
    var _, F, M;
    if (r.$$.dirty[0] & /*filters*/
    32 && V.set(J), r.$$.dirty[0] & /*$memoFilters*/
    128 && n(24, t = je(E)), r.$$.dirty[0] & /*filterExtension*/
    16777216 && (l = t ? Ct(t) : null), r.$$.dirty[0] & /*targetComponent*/
    32768 && n(21, o = ((_ = z == null ? void 0 : z.embeddedData) == null ? void 0 : _.dataSource) ?? (z == null ? void 0 : z.datasource)), r.$$.dirty[0] & /*targetComponent*/
    32768 && n(23, i = ((F = z == null ? void 0 : z.embeddedData) == null ? void 0 : F.componentId) ?? (z == null ? void 0 : z.id)), r.$$.dirty[0] & /*componentId*/
    8388608 && n(28, f = Vt.actions.getComponentById(i)), r.$$.dirty[0] & /*targetComponent*/
    32768 && n(25, m = (((M = z == null ? void 0 : z.embeddedData) == null ? void 0 : M.loaded) ?? (z == null ? void 0 : z.loaded)) || !1), r.$$.dirty[0] & /*loaded, target*/
    301989888 && m && Se(f), r.$$.dirty[0] & /*dataComponent, filterDatasource*/
    2228224 && $ && oe(o), r.$$.dirty[0] & /*dataComponent*/
    131072 && n(22, s = ($ == null ? void 0 : $._component) === "@budibase/standard-components/gridblock"), r.$$.dirty[0] & /*filterConfig, schema*/
    16448 && n(8, b = H == null ? void 0 : H.filter((I) => I.active && (le == null ? void 0 : le[I.field]))), r.$$.dirty[0] & /*isGridblock*/
    4194304 && n(27, h = s ? Re.AddDataProviderFilterExtension : Re.AddDataProviderQueryExtension), r.$$.dirty[0] & /*isGridblock*/
    4194304 && n(26, p = s ? Re.RemoveDataProviderFilterExtension : Re.RemoveDataProviderQueryExtension), r.$$.dirty[0] & /*componentId, loaded, addAction*/
    176160768 && (y = i && m ? et(i, h) : null), r.$$.dirty[0] & /*componentId, loaded, removeAction*/
    109051904 && (O = i && m ? et(i, p) : null), r.$$.dirty[0] & /*hydrated, dataComponent, loaded, filterExtension*/
    50528256 && ue && $ && m && c(t), r.$$.dirty[0] & /*$memoFilters*/
    128 && n(20, u = We(E)), r.$$.dirty[0] & /*rels*/
    1048576 && n(19, a = qe(u)), r.$$.dirty[0] & /*userFetch, relIds*/
    524304 && !ae && a.length && g(n(4, ae = Ue(a))), r.$$.dirty[0] & /*userFetch, $userFetch*/
    536870928 && n(18, R = ae ? U == null ? void 0 : U.rows : []), r.$$.dirty[0] & /*fetchedRows*/
    262144 && R.length) {
      const I = R.reduce(
        (te, ee) => (te[ee._id] = ee, te),
        {}
      );
      re.update((te) => ({ ...te, ...I }));
    }
  }, [
    X,
    Z,
    ge,
    d,
    ae,
    J,
    le,
    E,
    b,
    V,
    K,
    Ge,
    Ae,
    S,
    H,
    z,
    ue,
    $,
    R,
    a,
    u,
    o,
    s,
    i,
    t,
    m,
    p,
    h,
    f,
    U,
    we,
    De
  ];
}
class Un extends ve {
  constructor(e) {
    super(), Ee(
      this,
      e,
      wn,
      An,
      me,
      {
        persistFilters: 13,
        showClear: 0,
        filterConfig: 14,
        targetComponent: 15,
        size: 1,
        buttonText: 2,
        defaultOperator: 3
      },
      null,
      [-1, -1]
    );
  }
}
export {
  Un as default
};
