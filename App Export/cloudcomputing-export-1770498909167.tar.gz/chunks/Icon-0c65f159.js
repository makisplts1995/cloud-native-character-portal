import { S as q, i as B, s as W, y as A, f as b, z as L, n as d, A as j, k as p, o as h, u as z, v as I, e as N, c as D, m as E, q as P, h as y, p as F, b as v, d as S, l as G, B as w, r as H } from "./index-e79f0bb2.js";
import J from "./Placeholder-527c0fd1.js";
import { l as K } from "./phosphorIconLoader-ff92b5d5.js";
function M(l) {
  let e, t, r, s, a, i;
  return t = new J({}), {
    c() {
      e = N("div"), D(t.$$.fragment);
    },
    m(o, n) {
      b(o, e, n), E(t, e, null), s = !0, a || (i = P(r = /*styleable*/
      l[6].call(
        null,
        e,
        /*styles*/
        l[3]
      )), a = !0);
    },
    p(o, n) {
      r && y(r.update) && n & /*styles*/
      8 && r.update.call(
        null,
        /*styles*/
        o[3]
      );
    },
    i(o) {
      s || (p(t.$$.fragment, o), s = !0);
    },
    o(o) {
      d(t.$$.fragment, o), s = !1;
    },
    d(o) {
      o && h(e), F(t), a = !1, i();
    }
  };
}
function O(l) {
  let e, t, r, s, a;
  return {
    c() {
      e = N("i"), v(e, "class", t = /*iconClass*/
      l[4] + " " + /*size*/
      l[1] + " svelte-1ghy1wa"), S(
        e,
        "hoverable",
        /*onClick*/
        l[2] != null
      );
    },
    m(i, o) {
      b(i, e, o), s || (a = [
        P(r = /*styleable*/
        l[6].call(
          null,
          e,
          /*styles*/
          l[3]
        )),
        G(e, "click", function() {
          y(
            /*onClick*/
            l[2]
          ) && l[2].apply(this, arguments);
        })
      ], s = !0);
    },
    p(i, o) {
      l = i, o & /*iconClass, size*/
      18 && t !== (t = /*iconClass*/
      l[4] + " " + /*size*/
      l[1] + " svelte-1ghy1wa") && v(e, "class", t), r && y(r.update) && o & /*styles*/
      8 && r.update.call(
        null,
        /*styles*/
        l[3]
      ), o & /*iconClass, size, onClick*/
      22 && S(
        e,
        "hoverable",
        /*onClick*/
        l[2] != null
      );
    },
    i: w,
    o: w,
    d(i) {
      i && h(e), s = !1, H(a);
    }
  };
}
function Q(l) {
  let e, t, r, s;
  const a = [O, M], i = [];
  function o(n, u) {
    return (
      /*icon*/
      n[0] ? 0 : (
        /*$builderStore*/
        n[5].inBuilder ? 1 : -1
      )
    );
  }
  return ~(e = o(l)) && (t = i[e] = a[e](l)), {
    c() {
      t && t.c(), r = A();
    },
    m(n, u) {
      ~e && i[e].m(n, u), b(n, r, u), s = !0;
    },
    p(n, [u]) {
      let _ = e;
      e = o(n), e === _ ? ~e && i[e].p(n, u) : (t && (L(), d(i[_], 1, 1, () => {
        i[_] = null;
      }), j()), ~e ? (t = i[e], t ? t.p(n, u) : (t = i[e] = a[e](n), t.c()), p(t, 1), t.m(r.parentNode, r)) : t = null);
    },
    i(n) {
      s || (p(t), s = !0);
    },
    o(n) {
      d(t), s = !1;
    },
    d(n) {
      n && h(r), ~e && i[e].d(n);
    }
  };
}
function R(l, e, t) {
  let r, s, a, i, o, n;
  const { styleable: u, builderStore: _ } = z("sdk");
  I(l, _, (c) => t(5, n = c));
  const k = z("component");
  I(l, k, (c) => t(12, o = c));
  let { icon: f } = e, { size: g } = e, { color: m } = e, { onClick: C } = e;
  return l.$$set = (c) => {
    "icon" in c && t(0, f = c.icon), "size" in c && t(1, g = c.size), "color" in c && t(9, m = c.color), "onClick" in c && t(2, C = c.onClick);
  }, l.$$.update = () => {
    l.$$.dirty & /*icon*/
    1 && t(11, r = f && (f.startsWith("ri-") || f.includes("remix"))), l.$$.dirty & /*icon, isLegacyIcon*/
    2049 && t(10, s = f && !r), l.$$.dirty & /*isPhosphorIcon*/
    1024 && s && K("regular"), l.$$.dirty & /*isPhosphorIcon, icon*/
    1025 && t(4, a = s ? (() => `ph ph-${f.replace(/^ph-/, "")}`)() : f), l.$$.dirty & /*$component, color*/
    4608 && t(3, i = {
      ...o.styles,
      normal: {
        ...o.styles.normal,
        color: m || "var(--spectrum-global-color-gray-900)"
      }
    });
  }, [
    f,
    g,
    C,
    i,
    a,
    n,
    u,
    _,
    k,
    m,
    s,
    r,
    o
  ];
}
class X extends q {
  constructor(e) {
    super(), B(this, e, R, Q, W, { icon: 0, size: 1, color: 9, onClick: 2 });
  }
}
export {
  X as default
};
