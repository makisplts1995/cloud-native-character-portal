import { S as I, i as p, s as z, e as u, a as k, t as U, b as n, f as A, g as o, q as y, j as S, h as D, B as q, o as B, r as E, u as C, v as F, aA as L } from "./index-e79f0bb2.js";
function j(t) {
  let s, e, l;
  return {
    c() {
      s = u("div"), e = u("img"), n(e, "class", "image svelte-scr5w"), L(e.src, l = /*imageUrl*/
      t[0]) || n(e, "src", l), n(e, "alt", ""), n(s, "class", "image-block svelte-scr5w");
    },
    m(c, d) {
      A(c, s, d), o(s, e);
    },
    p(c, d) {
      d & /*imageUrl*/
      1 && !L(e.src, l = /*imageUrl*/
      c[0]) && n(e, "src", l);
    },
    d(c) {
      c && B(s);
    }
  };
}
function G(t) {
  let s, e, l, c, d, _, v, h, f, b, g, a, w, i = (
    /*showImage*/
    t[4] && j(t)
  );
  return {
    c() {
      s = u("div"), e = u("a"), l = u("div"), i && i.c(), c = k(), d = u("div"), _ = u("div"), v = U(
        /*heading*/
        t[1]
      ), h = k(), f = u("div"), b = U(
        /*subheading*/
        t[2]
      ), n(_, "class", "heading svelte-scr5w"), n(f, "class", "subheading svelte-scr5w"), n(d, "class", "content svelte-scr5w"), n(l, "class", "stackedlist svelte-scr5w"), n(
        e,
        "href",
        /*destinationUrl*/
        t[3]
      ), n(e, "class", "svelte-scr5w"), n(s, "class", "container svelte-scr5w");
    },
    m(r, m) {
      A(r, s, m), o(s, e), o(e, l), i && i.m(l, null), o(l, c), o(l, d), o(d, _), o(_, v), o(d, h), o(d, f), o(f, b), a || (w = [
        y(
          /*linkable*/
          t[7].call(null, e)
        ),
        y(g = /*styleable*/
        t[6].call(
          null,
          s,
          /*$component*/
          t[5].styles
        ))
      ], a = !0);
    },
    p(r, [m]) {
      /*showImage*/
      r[4] ? i ? i.p(r, m) : (i = j(r), i.c(), i.m(l, c)) : i && (i.d(1), i = null), m & /*heading*/
      2 && S(
        v,
        /*heading*/
        r[1]
      ), m & /*subheading*/
      4 && S(
        b,
        /*subheading*/
        r[2]
      ), m & /*destinationUrl*/
      8 && n(
        e,
        "href",
        /*destinationUrl*/
        r[3]
      ), g && D(g.update) && m & /*$component*/
      32 && g.update.call(
        null,
        /*$component*/
        r[5].styles
      );
    },
    i: q,
    o: q,
    d(r) {
      r && B(s), i && i.d(), a = !1, E(w);
    }
  };
}
function H(t, s, e) {
  let l, c;
  const { styleable: d, linkable: _ } = C("sdk"), v = C("component");
  F(t, v, (a) => e(5, c = a));
  let { imageUrl: h = "" } = s, { heading: f = "" } = s, { subheading: b = "" } = s, { destinationUrl: g = "/" } = s;
  return t.$$set = (a) => {
    "imageUrl" in a && e(0, h = a.imageUrl), "heading" in a && e(1, f = a.heading), "subheading" in a && e(2, b = a.subheading), "destinationUrl" in a && e(3, g = a.destinationUrl);
  }, t.$$.update = () => {
    t.$$.dirty & /*imageUrl*/
    1 && e(4, l = !!h);
  }, [
    h,
    f,
    b,
    g,
    l,
    c,
    d,
    _,
    v
  ];
}
class K extends I {
  constructor(s) {
    super(), p(this, s, H, G, z, {
      imageUrl: 0,
      heading: 1,
      subheading: 2,
      destinationUrl: 3
    });
  }
}
export {
  K as default
};
