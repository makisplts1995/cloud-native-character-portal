import { S as M, i as O, s as P, c as Q, m as R, k as V, n as W, p as X } from "./index-e79f0bb2.js";
import { A as Y, p as v, f as j } from "./ApexChart-fb0e9d4c.js";
function p(l) {
  let n, t;
  return n = new Y({ props: { options: (
    /*options*/
    l[0]
  ) } }), {
    c() {
      Q(n.$$.fragment);
    },
    m(i, m) {
      R(n, i, m), t = !0;
    },
    p(i, [m]) {
      const f = {};
      m & /*options*/
      1 && (f.options = /*options*/
      i[0]), n.$set(f);
    },
    i(i) {
      t || (V(n.$$.fragment, i), t = !0);
    },
    o(i) {
      W(n.$$.fragment, i), t = !1;
    },
    d(i) {
      X(n, i);
    }
  };
}
function $(l, n, t) {
  let i, m, f, L, w, B, { title: d } = n, { dataProvider: c } = n, { labelColumn: g } = n, { valueColumns: _ } = n, { xAxisLabel: k } = n, { yAxisLabel: S } = n, { height: r } = n, { width: x } = n, { animate: F } = n, { dataLabels: U } = n, { curve: D } = n, { legend: z } = n, { yAxisUnits: y } = n, { palette: C } = n, { c1: I, c2: q, c3: N, c4: T, c5: Z } = n, { onClick: h } = n;
  function H(e) {
    h == null || h({ marker: e });
  }
  const J = (e, u = []) => {
    const o = e.rows ?? [];
    return u.map((a) => ({
      name: a,
      data: o.map((s) => {
        var A, G;
        const b = s == null ? void 0 : s[a];
        return ((G = (A = e == null ? void 0 : e.schema) == null ? void 0 : A[a]) == null ? void 0 : G.type) === "datetime" && b ? Date.parse(b) : b;
      })
    }));
  }, K = (e, u) => (e.rows ?? []).map((a) => {
    const s = a == null ? void 0 : a[u];
    return ["string", "number", "boolean"].includes(typeof s) ? s : "";
  }), E = (e, u, o) => {
    const a = o === "x";
    return e === "datetime" && a ? j.Datetime : a ? j.Default : j[u];
  };
  return l.$$set = (e) => {
    "title" in e && t(1, d = e.title), "dataProvider" in e && t(2, c = e.dataProvider), "labelColumn" in e && t(3, g = e.labelColumn), "valueColumns" in e && t(4, _ = e.valueColumns), "xAxisLabel" in e && t(5, k = e.xAxisLabel), "yAxisLabel" in e && t(6, S = e.yAxisLabel), "height" in e && t(7, r = e.height), "width" in e && t(8, x = e.width), "animate" in e && t(9, F = e.animate), "dataLabels" in e && t(10, U = e.dataLabels), "curve" in e && t(11, D = e.curve), "legend" in e && t(12, z = e.legend), "yAxisUnits" in e && t(13, y = e.yAxisUnits), "palette" in e && t(14, C = e.palette), "c1" in e && t(15, I = e.c1), "c2" in e && t(16, q = e.c2), "c3" in e && t(17, N = e.c3), "c4" in e && t(18, T = e.c4), "c5" in e && t(19, Z = e.c5), "onClick" in e && t(20, h = e.onClick);
  }, l.$$.update = () => {
    var e, u;
    l.$$.dirty & /*dataProvider, valueColumns*/
    20 && t(24, i = J(c, _)), l.$$.dirty & /*dataProvider, labelColumn*/
    12 && t(23, m = K(c, g)), l.$$.dirty & /*dataProvider, labelColumn*/
    12 && t(25, f = ((u = (e = c == null ? void 0 : c.schema) == null ? void 0 : e[g]) == null ? void 0 : u.type) === "datetime" ? "datetime" : "category"), l.$$.dirty & /*labelType, yAxisUnits*/
    33562624 && t(22, L = E(f, y, "x")), l.$$.dirty & /*labelType, yAxisUnits*/
    33562624 && t(21, w = E(f, y, "y")), l.$$.dirty & /*series, curve, palette, c1, c2, c3, c4, c5, legend, title, dataLabels, height, width, animate, dataProvider, categories, xAxisFormatter, xAxisLabel, yAxisFormatter, yAxisLabel*/
    32497638 && t(0, B = {
      series: i,
      stroke: { curve: D.toLowerCase() },
      colors: C === "Custom" ? [I, q, N, T, Z] : [],
      theme: { palette: v(C) },
      legend: {
        show: z,
        position: "top",
        horizontalAlign: "right",
        showForSingleSeries: !0,
        showForNullSeries: !0,
        showForZeroSeries: !0
      },
      title: { text: d },
      dataLabels: { enabled: U },
      chart: {
        height: r == null || r === "" ? "auto" : r,
        width: x == null || x === "" ? "100%" : x,
        type: "line",
        animations: { enabled: F },
        toolbar: { show: !1 },
        zoom: { enabled: !1 },
        events: {
          // Clicking on a line
          markerClick(o, a, s) {
            const b = s.dataPointIndex, A = c.rows[b];
            H(A);
          }
        }
      },
      xaxis: {
        categories: m,
        labels: { formatter: L },
        title: { text: k }
      },
      yaxis: {
        labels: { formatter: w },
        title: { text: S }
      }
    });
  }, [
    B,
    d,
    c,
    g,
    _,
    k,
    S,
    r,
    x,
    F,
    U,
    D,
    z,
    y,
    C,
    I,
    q,
    N,
    T,
    Z,
    h,
    w,
    L,
    m,
    i,
    f
  ];
}
class ne extends M {
  constructor(n) {
    super(), O(this, n, $, p, P, {
      title: 1,
      dataProvider: 2,
      labelColumn: 3,
      valueColumns: 4,
      xAxisLabel: 5,
      yAxisLabel: 6,
      height: 7,
      width: 8,
      animate: 9,
      dataLabels: 10,
      curve: 11,
      legend: 12,
      yAxisUnits: 13,
      palette: 14,
      c1: 15,
      c2: 16,
      c3: 17,
      c4: 18,
      c5: 19,
      onClick: 20
    });
  }
}
export {
  ne as default
};
