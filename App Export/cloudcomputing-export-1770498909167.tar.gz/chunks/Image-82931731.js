import { S as q, i as A, s as B, y as C, f as p, z as I, n as _, A as w, k as m, o as d, u as b, v as y, e as v, c as z, b as c, m as N, q as h, h as S, p as P, aA as k, B as g } from "./index-e79f0bb2.js";
import j from "./Placeholder-527c0fd1.js";
function D(a) {
  let e, t, s, o, u, r;
  return t = new j({}), {
    c() {
      e = v("div"), z(t.$$.fragment), c(e, "class", "placeholder svelte-1d46lef");
    },
    m(n, l) {
      p(n, e, l), N(t, e, null), o = !0, u || (r = h(s = /*styleable*/
      a[3].call(null, e, {
        .../*$component*/
        a[1].styles,
        empty: !0
      })), u = !0);
    },
    p(n, l) {
      s && S(s.update) && l & /*$component*/
      2 && s.update.call(null, {
        .../*$component*/
        n[1].styles,
        empty: !0
      });
    },
    i(n) {
      o || (m(t.$$.fragment, n), o = !0);
    },
    o(n) {
      _(t.$$.fragment, n), o = !1;
    },
    d(n) {
      n && d(e), P(t), u = !1, r();
    }
  };
}
function E(a) {
  let e, t, s, o, u, r;
  return {
    c() {
      e = v("img"), k(e.src, t = /*url*/
      a[0]) || c(e, "src", t), c(e, "alt", s = /*$component*/
      a[1].name);
    },
    m(n, l) {
      p(n, e, l), u || (r = h(o = /*styleable*/
      a[3].call(
        null,
        e,
        /*$component*/
        a[1].styles
      )), u = !0);
    },
    p(n, l) {
      l & /*url*/
      1 && !k(e.src, t = /*url*/
      n[0]) && c(e, "src", t), l & /*$component*/
      2 && s !== (s = /*$component*/
      n[1].name) && c(e, "alt", s), o && S(o.update) && l & /*$component*/
      2 && o.update.call(
        null,
        /*$component*/
        n[1].styles
      );
    },
    i: g,
    o: g,
    d(n) {
      n && d(e), u = !1, r();
    }
  };
}
function F(a) {
  let e, t, s, o;
  const u = [E, D], r = [];
  function n(l, i) {
    return (
      /*url*/
      l[0] ? 0 : (
        /*$builderStore*/
        l[2].inBuilder ? 1 : -1
      )
    );
  }
  return ~(e = n(a)) && (t = r[e] = u[e](a)), {
    c() {
      t && t.c(), s = C();
    },
    m(l, i) {
      ~e && r[e].m(l, i), p(l, s, i), o = !0;
    },
    p(l, [i]) {
      let f = e;
      e = n(l), e === f ? ~e && r[e].p(l, i) : (t && (I(), _(r[f], 1, 1, () => {
        r[f] = null;
      }), w()), ~e ? (t = r[e], t ? t.p(l, i) : (t = r[e] = u[e](l), t.c()), m(t, 1), t.m(s.parentNode, s)) : t = null);
    },
    i(l) {
      o || (m(t), o = !0);
    },
    o(l) {
      _(t), o = !1;
    },
    d(l) {
      l && d(s), ~e && r[e].d(l);
    }
  };
}
function G(a, e, t) {
  let s, o;
  const { styleable: u, builderStore: r } = b("sdk");
  y(a, r, (i) => t(2, o = i));
  const n = b("component");
  y(a, n, (i) => t(1, s = i));
  let { url: l } = e;
  return a.$$set = (i) => {
    "url" in i && t(0, l = i.url);
  }, [l, s, o, u, r, n];
}
class K extends q {
  constructor(e) {
    super(), A(this, e, G, F, B, { url: 0 });
  }
}
export {
  K as default
};
