import { S as L, i as O, s as A, y as Q, f as D, B as q, o as E, u as P, v as M, e as R, t as U, b as m, d, g as V, q as W, l as N, h as j, cg as X, r as Y, ac as Z } from "./index-e79f0bb2.js";
function w(e) {
  let t, l, o, i, a, r, f;
  return {
    c() {
      t = R("p"), l = U(
        /*componentText*/
        e[9]
      ), m(t, "contenteditable", o = /*$component*/
      e[4].editing), m(t, "class", i = "spectrum-Body " + /*sizeClass*/
      e[8] + " " + /*alignClass*/
      e[7] + " svelte-1bo4sd3"), d(
        t,
        "placeholder",
        /*placeholder*/
        e[10]
      ), d(
        t,
        "bold",
        /*bold*/
        e[0]
      ), d(
        t,
        "italic",
        /*italic*/
        e[1]
      ), d(
        t,
        "underline",
        /*underline*/
        e[2]
      );
    },
    m(s, u) {
      D(s, t, u), V(t, l), e[20](t), r || (f = [
        W(a = /*styleable*/
        e[11].call(
          null,
          t,
          /*styles*/
          e[6]
        )),
        N(t, "blur", function() {
          j(
            /*$component*/
            e[4].editing ? (
              /*updateText*/
              e[14]
            ) : null
          ) && /*$component*/
          (e[4].editing ? (
            /*updateText*/
            e[14]
          ) : null).apply(this, arguments);
        }),
        N(
          t,
          "input",
          /*input_handler*/
          e[21]
        )
      ], r = !0);
    },
    p(s, u) {
      e = s, u & /*componentText*/
      512 && X(
        l,
        /*componentText*/
        e[9],
        /*$component*/
        e[4].editing
      ), u & /*$component*/
      16 && o !== (o = /*$component*/
      e[4].editing) && m(t, "contenteditable", o), u & /*sizeClass, alignClass*/
      384 && i !== (i = "spectrum-Body " + /*sizeClass*/
      e[8] + " " + /*alignClass*/
      e[7] + " svelte-1bo4sd3") && m(t, "class", i), a && j(a.update) && u & /*styles*/
      64 && a.update.call(
        null,
        /*styles*/
        e[6]
      ), u & /*sizeClass, alignClass, placeholder*/
      1408 && d(
        t,
        "placeholder",
        /*placeholder*/
        e[10]
      ), u & /*sizeClass, alignClass, bold*/
      385 && d(
        t,
        "bold",
        /*bold*/
        e[0]
      ), u & /*sizeClass, alignClass, italic*/
      386 && d(
        t,
        "italic",
        /*italic*/
        e[1]
      ), u & /*sizeClass, alignClass, underline*/
      388 && d(
        t,
        "underline",
        /*underline*/
        e[2]
      );
    },
    d(s) {
      s && E(t), e[20](null), r = !1, Y(f);
    }
  };
}
function v(e) {
  let t = (
    /*$component*/
    e[4].editing
  ), l, o = w(e);
  return {
    c() {
      o.c(), l = Q();
    },
    m(i, a) {
      o.m(i, a), D(i, l, a);
    },
    p(i, [a]) {
      a & /*$component*/
      16 && A(t, t = /*$component*/
      i[4].editing) ? (o.d(1), o = w(i), o.c(), o.m(l.parentNode, l)) : o.p(i, a);
    },
    i: q,
    o: q,
    d(i) {
      i && E(l), o.d(i);
    }
  };
}
function x(e, t, l) {
  let o, i, a, r, f, s, u;
  const { styleable: F, builderStore: h } = P("sdk");
  M(e, h, (n) => l(19, u = n));
  const B = P("component");
  M(e, B, (n) => l(4, s = n));
  let { text: _ } = t, { color: y } = t, { align: k } = t, { bold: C } = t, { italic: T } = t, { underline: p } = t, { size: z } = t, c, b = !1;
  const G = (n, g, S) => !g.inBuilder || S.editing ? n || "" : n || S.name || "Placeholder text", H = (n, g) => g ? {
    ...n,
    normal: { ...n == null ? void 0 : n.normal, color: g }
  } : n, I = (n) => {
    b && h.actions.updateProp("text", n.target.textContent), l(5, b = !1);
  };
  function J(n) {
    Z[n ? "unshift" : "push"](() => {
      c = n, l(3, c);
    });
  }
  const K = () => l(5, b = !0);
  return e.$$set = (n) => {
    "text" in n && l(15, _ = n.text), "color" in n && l(16, y = n.color), "align" in n && l(17, k = n.align), "bold" in n && l(0, C = n.bold), "italic" in n && l(1, T = n.italic), "underline" in n && l(2, p = n.underline), "size" in n && l(18, z = n.size);
  }, e.$$.update = () => {
    e.$$.dirty & /*$component, node*/
    24 && s.editing && (c == null || c.focus()), e.$$.dirty & /*$builderStore, text, $component*/
    557072 && l(10, o = u.inBuilder && !_ && !s.editing), e.$$.dirty & /*text, $builderStore, $component*/
    557072 && l(9, i = G(_, u, s)), e.$$.dirty & /*size*/
    262144 && l(8, a = `spectrum-Body--size${z || "M"}`), e.$$.dirty & /*align*/
    131072 && l(7, r = `align--${k || "left"}`), e.$$.dirty & /*$component, color*/
    65552 && l(6, f = H(s.styles, y));
  }, [
    C,
    T,
    p,
    c,
    s,
    b,
    f,
    r,
    a,
    i,
    o,
    F,
    h,
    B,
    I,
    _,
    y,
    k,
    z,
    u,
    J,
    K
  ];
}
class ee extends L {
  constructor(t) {
    super(), O(this, t, x, v, A, {
      text: 15,
      color: 16,
      align: 17,
      bold: 0,
      italic: 1,
      underline: 2,
      size: 18
    });
  }
}
export {
  ee as default
};
