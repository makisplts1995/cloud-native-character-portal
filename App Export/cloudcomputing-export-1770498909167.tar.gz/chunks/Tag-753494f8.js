import { S as B, i as A, s as M, e as j, t as N, a as P, b as C, f as V, g as k, q as D, j as E, k as d, z as F, n as h, A as G, h as x, o as H, u as S, v as p, aN as I, c as J, m as K, p as L } from "./index-e79f0bb2.js";
function w(o) {
  let e, l;
  return e = new I({}), e.$on("click", function() {
    x(
      /*onClick*/
      o[0]
    ) && o[0].apply(this, arguments);
  }), {
    c() {
      J(e.$$.fragment);
    },
    m(a, u) {
      K(e, a, u), l = !0;
    },
    p(a, u) {
      o = a;
    },
    i(a) {
      l || (d(e.$$.fragment, a), l = !0);
    },
    o(a) {
      h(e.$$.fragment, a), l = !1;
    },
    d(a) {
      L(e, a);
    }
  };
}
function O(o) {
  let e, l, a, u, c, f, i, m, _, n = (
    /*closable*/
    o[1] && w(o)
  );
  return {
    c() {
      e = j("div"), l = j("span"), a = N(
        /*componentText*/
        o[3]
      ), u = P(), n && n.c(), C(l, "class", "spectrum-Tag-label svelte-jml011"), C(e, "class", c = "spectrum-Tag spectrum-Tag--size" + /*size*/
      o[2] + " svelte-jml011");
    },
    m(s, r) {
      V(s, e, r), k(e, l), k(l, a), k(e, u), n && n.m(e, null), i = !0, m || (_ = D(f = /*styleable*/
      o[6].call(
        null,
        e,
        /*styles*/
        o[4]
      )), m = !0);
    },
    p(s, [r]) {
      (!i || r & /*componentText*/
      8) && E(
        a,
        /*componentText*/
        s[3]
      ), /*closable*/
      s[1] ? n ? (n.p(s, r), r & /*closable*/
      2 && d(n, 1)) : (n = w(s), n.c(), d(n, 1), n.m(e, null)) : n && (F(), h(n, 1, 1, () => {
        n = null;
      }), G()), (!i || r & /*size*/
      4 && c !== (c = "spectrum-Tag spectrum-Tag--size" + /*size*/
      s[2] + " svelte-jml011")) && C(e, "class", c), f && x(f.update) && r & /*styles*/
      16 && f.update.call(
        null,
        /*styles*/
        s[4]
      );
    },
    i(s) {
      i || (d(n), i = !0);
    },
    o(s) {
      h(n), i = !1;
    },
    d(s) {
      s && H(e), n && n.d(), m = !1, _();
    }
  };
}
function Q(o, e, l) {
  let a, u, c, f, { onClick: i } = e, { text: m = "" } = e, { color: _ } = e, { textColor: n } = e, { closable: s = !1 } = e, { size: r = "M" } = e;
  const T = S("component");
  p(o, T, (t) => l(11, c = t));
  const { styleable: y, builderStore: z } = S("sdk");
  p(o, z, (t) => l(12, f = t));
  const q = (t, g, b) => !g.inBuilder || b.editing ? t || " " : t || b.name || "Placeholder text", v = (t, g, b) => g ? {
    ...t,
    normal: {
      ...t == null ? void 0 : t.normal,
      "background-color": g,
      "border-color": g,
      color: b || "white",
      "--spectrum-clearbutton-medium-icon-color": "white"
    }
  } : t;
  return o.$$set = (t) => {
    "onClick" in t && l(0, i = t.onClick), "text" in t && l(8, m = t.text), "color" in t && l(9, _ = t.color), "textColor" in t && l(10, n = t.textColor), "closable" in t && l(1, s = t.closable), "size" in t && l(2, r = t.size);
  }, o.$$.update = () => {
    o.$$.dirty & /*$component, color, textColor*/
    3584 && l(4, a = v(c.styles, _, n)), o.$$.dirty & /*text, $builderStore, $component*/
    6400 && l(3, u = q(m, f, c));
  }, [
    i,
    s,
    r,
    u,
    a,
    T,
    y,
    z,
    m,
    _,
    n,
    c,
    f
  ];
}
class U extends B {
  constructor(e) {
    super(), A(this, e, Q, O, M, {
      onClick: 0,
      text: 8,
      color: 9,
      textColor: 10,
      closable: 1,
      size: 2
    });
  }
}
export {
  U as default
};
