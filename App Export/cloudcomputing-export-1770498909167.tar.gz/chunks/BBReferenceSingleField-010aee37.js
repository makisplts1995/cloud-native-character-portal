import { S as m, i as _, s as f, b2 as l, bL as i, c as u, m as d, c7 as b, c8 as g, k as B, n as E, p as $, cH as c, bM as F } from "./index-e79f0bb2.js";
import R from "./BBReferenceField-3e75d43c.js";
import "./RelationshipField-c09d9c4a.js";
import "./Multiselect-9dd507ef.js";
import "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
import "./users-b6137f6b.js";
function S(o) {
  let t, n;
  const r = [
    /*$$restProps*/
    o[0],
    { type: l.BB_REFERENCE_SINGLE }
  ];
  let s = {};
  for (let e = 0; e < r.length; e += 1)
    s = i(s, r[e]);
  return t = new R({ props: s }), {
    c() {
      u(t.$$.fragment);
    },
    m(e, a) {
      d(t, e, a), n = !0;
    },
    p(e, [a]) {
      const p = a & /*$$restProps*/
      1 ? b(r, [
        g(
          /*$$restProps*/
          e[0]
        ),
        r[1]
      ]) : {};
      t.$set(p);
    },
    i(e) {
      n || (B(t.$$.fragment, e), n = !0);
    },
    o(e) {
      E(t.$$.fragment, e), n = !1;
    },
    d(e) {
      $(t, e);
    }
  };
}
function h(o, t, n) {
  const r = [];
  let s = c(t, r);
  return o.$$set = (e) => {
    t = i(i({}, t), F(e)), n(0, s = c(t, r));
  }, [s];
}
class q extends m {
  constructor(t) {
    super(), _(this, t, h, S, f, {});
  }
}
export {
  q as default
};
