import { S as ie, i as fe, s as ue, ay as Ce, e as F, a as V, c as v, b as q, f as p, g as T, m as y, k as b, z as R, n as g, A as z, o as C, p as S, ae as ve, t as I, j as D, aq as ye, ac as L, ai as J, aj as K, cI as P, cv as re, am as Se, I as qe, y as oe, aM as se, B as Fe } from "./index-e79f0bb2.js";
import { F as Te } from "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function x(a) {
  let e, t, n, l, i, r, o;
  const u = [Be, Me], s = [];
  function f(c, k) {
    var h;
    return k[0] & /*validator, value*/
    17 && (t = null), t == null && (t = !!/*validator*/
    ((h = c[4]) != null && h.call(
      c,
      /*value*/
      c[0]
    ))), t ? 0 : 1;
  }
  return n = f(a, [-1, -1]), l = s[n] = u[n](a), {
    c() {
      e = F("div"), l.c(), i = V(), r = I(
        /*value*/
        a[0]
      ), q(e, "class", "scanner-value field-display svelte-1jyd4la");
    },
    m(c, k) {
      p(c, e, k), s[n].m(e, null), T(e, i), T(e, r), o = !0;
    },
    p(c, k) {
      let h = n;
      n = f(c, k), n !== h && (R(), g(s[h], 1, 1, () => {
        s[h] = null;
      }), z(), l = s[n], l || (l = s[n] = u[n](c), l.c()), b(l, 1), l.m(e, i)), (!o || k[0] & /*value*/
      1) && D(
        r,
        /*value*/
        c[0]
      );
    },
    i(c) {
      o || (b(l), o = !0);
    },
    o(c) {
      g(l), o = !1;
    },
    d(c) {
      c && C(e), s[n].d();
    }
  };
}
function Me(a) {
  let e, t;
  return e = new P({ props: { positive: !0 } }), {
    c() {
      v(e.$$.fragment);
    },
    m(n, l) {
      y(e, n, l), t = !0;
    },
    i(n) {
      t || (b(e.$$.fragment, n), t = !0);
    },
    o(n) {
      g(e.$$.fragment, n), t = !1;
    },
    d(n) {
      S(e, n);
    }
  };
}
function Be(a) {
  let e, t;
  return e = new P({ props: { negative: !0 } }), {
    c() {
      v(e.$$.fragment);
    },
    m(n, l) {
      y(e, n, l), t = !0;
    },
    i(n) {
      t || (b(e.$$.fragment, n), t = !0);
    },
    o(n) {
      g(e.$$.fragment, n), t = !1;
    },
    d(n) {
      S(e, n);
    }
  };
}
function ee(a) {
  let e, t, n, l;
  function i(o) {
    a[19](o);
  }
  let r = { updateOnChange: !1 };
  return (
    /*value*/
    a[0] !== void 0 && (r.value = /*value*/
    a[0]), t = new ye({ props: r }), L.push(() => J(t, "value", i)), t.$on(
      "change",
      /*change_handler*/
      a[20]
    ), {
      c() {
        e = F("div"), v(t.$$.fragment), q(e, "class", "manual-input svelte-1jyd4la");
      },
      m(o, u) {
        p(o, e, u), y(t, e, null), l = !0;
      },
      p(o, u) {
        const s = {};
        !n && u[0] & /*value*/
        1 && (n = !0, s.value = /*value*/
        o[0], K(() => n = !1)), t.$set(s);
      },
      i(o) {
        l || (b(t.$$.fragment, o), l = !0);
      },
      o(o) {
        g(t.$$.fragment, o), l = !1;
      },
      d(o) {
        o && C(e), S(t);
      }
    }
  );
}
function Ee(a) {
  let e, t;
  return e = new re({
    props: {
      icon: "camera",
      disabled: (
        /*disabled*/
        a[1]
      ),
      $$slots: { default: [Ae] },
      $$scope: { ctx: a }
    }
  }), e.$on(
    "click",
    /*click_handler_1*/
    a[22]
  ), {
    c() {
      v(e.$$.fragment);
    },
    m(n, l) {
      y(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l[0] & /*disabled*/
      2 && (i.disabled = /*disabled*/
      n[1]), l[0] & /*scanButtonText*/
      8 | l[1] & /*$$scope*/
      32 && (i.$$scope = { dirty: l, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (b(e.$$.fragment, n), t = !0);
    },
    o(n) {
      g(e.$$.fragment, n), t = !1;
    },
    d(n) {
      S(e, n);
    }
  };
}
function Oe(a) {
  let e, t;
  return e = new re({
    props: {
      disabled: (
        /*disabled*/
        a[1]
      ),
      $$slots: { default: [je] },
      $$scope: { ctx: a }
    }
  }), e.$on(
    "click",
    /*click_handler*/
    a[21]
  ), {
    c() {
      v(e.$$.fragment);
    },
    m(n, l) {
      y(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l[0] & /*disabled*/
      2 && (i.disabled = /*disabled*/
      n[1]), l[1] & /*$$scope*/
      32 && (i.$$scope = { dirty: l, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (b(e.$$.fragment, n), t = !0);
    },
    o(n) {
      g(e.$$.fragment, n), t = !1;
    },
    d(n) {
      S(e, n);
    }
  };
}
function Ae(a) {
  let e;
  return {
    c() {
      e = I(
        /*scanButtonText*/
        a[3]
      );
    },
    m(t, n) {
      p(t, e, n);
    },
    p(t, n) {
      n[0] & /*scanButtonText*/
      8 && D(
        e,
        /*scanButtonText*/
        t[3]
      );
    },
    d(t) {
      t && C(e);
    }
  };
}
function je(a) {
  let e;
  return {
    c() {
      e = I("Clear");
    },
    m(t, n) {
      p(t, e, n);
    },
    d(t) {
      t && C(e);
    }
  };
}
function ne(a) {
  let e;
  return {
    c() {
      e = F("div"), e.textContent = "Your camera is disabled.";
    },
    m(t, n) {
      p(t, e, n);
    },
    d(t) {
      t && C(e);
    }
  };
}
function te(a) {
  let e, t, n, l, i, r;
  const o = [Re, Ve, Ze], u = [];
  function s(f, c) {
    var k, h;
    return c[0] & /*value, validator*/
    17 && (t = null), c[0] & /*value, validator*/
    17 && (n = null), t == null && (t = !!/*value*/
    (f[0] && !/*validator*/
    ((k = f[4]) != null && k.call(
      f,
      /*value*/
      f[0]
    )))), t ? 0 : (n == null && (n = !!/*value*/
    (f[0] && /*validator*/
    ((h = f[4]) != null && h.call(
      f,
      /*value*/
      f[0]
    )))), n ? 1 : 2);
  }
  return l = s(a, [-1, -1]), i = u[l] = o[l](a), {
    c() {
      e = F("div"), i.c(), q(e, "class", "code-wrap");
    },
    m(f, c) {
      p(f, e, c), u[l].m(e, null), r = !0;
    },
    p(f, c) {
      let k = l;
      l = s(f, c), l === k ? u[l].p(f, c) : (R(), g(u[k], 1, 1, () => {
        u[k] = null;
      }), z(), i = u[l], i ? i.p(f, c) : (i = u[l] = o[l](f), i.c()), b(i, 1), i.m(e, null));
    },
    i(f) {
      r || (b(i), r = !0);
    },
    o(f) {
      g(i), r = !1;
    },
    d(f) {
      f && C(e), u[l].d();
    }
  };
}
function Ze(a) {
  let e, t, n, l;
  return t = new P({ props: { neutral: !0 } }), {
    c() {
      e = F("div"), v(t.$$.fragment), n = I(`
              Searching for code...`), q(e, "class", "scanner-value svelte-1jyd4la");
    },
    m(i, r) {
      p(i, e, r), y(t, e, null), T(e, n), l = !0;
    },
    p: Fe,
    i(i) {
      l || (b(t.$$.fragment, i), l = !0);
    },
    o(i) {
      g(t.$$.fragment, i), l = !1;
    },
    d(i) {
      i && C(e), S(t);
    }
  };
}
function Ve(a) {
  let e, t, n, l, i;
  return t = new P({ props: { negative: !0 } }), {
    c() {
      e = F("div"), v(t.$$.fragment), n = V(), l = I(
        /*value*/
        a[0]
      ), q(e, "class", "scanner-value svelte-1jyd4la");
    },
    m(r, o) {
      p(r, e, o), y(t, e, null), T(e, n), T(e, l), i = !0;
    },
    p(r, o) {
      (!i || o[0] & /*value*/
      1) && D(
        l,
        /*value*/
        r[0]
      );
    },
    i(r) {
      i || (b(t.$$.fragment, r), i = !0);
    },
    o(r) {
      g(t.$$.fragment, r), i = !1;
    },
    d(r) {
      r && C(e), S(t);
    }
  };
}
function Re(a) {
  let e, t, n, l, i;
  return t = new P({ props: { positive: !0 } }), {
    c() {
      e = F("div"), v(t.$$.fragment), n = V(), l = I(
        /*value*/
        a[0]
      ), q(e, "class", "scanner-value svelte-1jyd4la");
    },
    m(r, o) {
      p(r, e, o), y(t, e, null), T(e, n), T(e, l), i = !0;
    },
    p(r, o) {
      (!i || o[0] & /*value*/
      1) && D(
        l,
        /*value*/
        r[0]
      );
    },
    i(r) {
      i || (b(t.$$.fragment, r), i = !0);
    },
    o(r) {
      g(t.$$.fragment, r), i = !1;
    },
    d(r) {
      r && C(e), S(t);
    }
  };
}
function ze(a) {
  let e, t, n, l, i, r, o;
  n = new qe({ props: { size: "XXL", name: "camera" } });
  let u = (
    /*cameraEnabled*/
    a[6] === !1 && ne()
  ), s = (
    /*cameraEnabled*/
    a[6] === !0 && te(a)
  );
  return {
    c() {
      e = F("div"), t = F("div"), v(n.$$.fragment), l = V(), u && u.c(), i = V(), s && s.c(), r = oe(), q(t, "class", "camera-placeholder svelte-1jyd4la"), q(e, "id", "reader"), q(e, "class", "container svelte-1jyd4la");
    },
    m(f, c) {
      p(f, e, c), T(e, t), y(n, t, null), T(t, l), u && u.m(t, null), a[25](e), p(f, i, c), s && s.m(f, c), p(f, r, c), o = !0;
    },
    p(f, c) {
      /*cameraEnabled*/
      f[6] === !1 ? u || (u = ne(), u.c(), u.m(t, null)) : u && (u.d(1), u = null), /*cameraEnabled*/
      f[6] === !0 ? s ? (s.p(f, c), c[0] & /*cameraEnabled*/
      64 && b(s, 1)) : (s = te(f), s.c(), b(s, 1), s.m(r.parentNode, r)) : s && (R(), g(s, 1, 1, () => {
        s = null;
      }), z());
    },
    i(f) {
      o || (b(n.$$.fragment, f), b(s), o = !0);
    },
    o(f) {
      g(n.$$.fragment, f), g(s), o = !1;
    },
    d(f) {
      f && (C(e), C(i), C(r)), S(n), u && u.d(), a[25](null), s && s.d(f);
    }
  };
}
function le(a) {
  let e, t;
  return e = new se({
    props: {
      group: !0,
      secondary: !0,
      newStyles: !0,
      $$slots: { default: [Ie] },
      $$scope: { ctx: a }
    }
  }), e.$on(
    "click",
    /*click_handler_2*/
    a[23]
  ), {
    c() {
      v(e.$$.fragment);
    },
    m(n, l) {
      y(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l[1] & /*$$scope*/
      32 && (i.$$scope = { dirty: l, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (b(e.$$.fragment, n), t = !0);
    },
    o(n) {
      g(e.$$.fragment, n), t = !1;
    },
    d(n) {
      S(e, n);
    }
  };
}
function Ie(a) {
  let e;
  return {
    c() {
      e = I("Enter manually");
    },
    m(t, n) {
      p(t, e, n);
    },
    d(t) {
      t && C(e);
    }
  };
}
function Ne(a) {
  let e;
  return {
    c() {
      e = I("Confirm");
    },
    m(t, n) {
      p(t, e, n);
    },
    d(t) {
      t && C(e);
    }
  };
}
function Qe(a) {
  let e, t, n, l, i, r = (
    /*allowManualEntry*/
    a[2] && !/*manualMode*/
    a[8] && le(a)
  );
  return l = new se({
    props: {
      group: !0,
      cta: !0,
      $$slots: { default: [Ne] },
      $$scope: { ctx: a }
    }
  }), l.$on(
    "click",
    /*click_handler_3*/
    a[24]
  ), {
    c() {
      e = F("div"), t = F("div"), r && r.c(), n = V(), v(l.$$.fragment), q(t, "class", "footer-buttons svelte-1jyd4la"), q(e, "slot", "footer");
    },
    m(o, u) {
      p(o, e, u), T(e, t), r && r.m(t, null), T(t, n), y(l, t, null), i = !0;
    },
    p(o, u) {
      /*allowManualEntry*/
      o[2] && !/*manualMode*/
      o[8] ? r ? (r.p(o, u), u[0] & /*allowManualEntry, manualMode*/
      260 && b(r, 1)) : (r = le(o), r.c(), b(r, 1), r.m(t, n)) : r && (R(), g(r, 1, 1, () => {
        r = null;
      }), z());
      const s = {};
      u[1] & /*$$scope*/
      32 && (s.$$scope = { dirty: u, ctx: o }), l.$set(s);
    },
    i(o) {
      i || (b(r), b(l.$$.fragment, o), i = !0);
    },
    o(o) {
      g(r), g(l.$$.fragment, o), i = !1;
    },
    d(o) {
      o && C(e), r && r.d(), S(l);
    }
  };
}
function He(a) {
  let e, t;
  return e = new Se({
    props: {
      title: (
        /*scanButtonText*/
        a[3]
      ),
      showConfirmButton: !1,
      showCancelButton: !1,
      $$slots: {
        footer: [Qe],
        default: [ze]
      },
      $$scope: { ctx: a }
    }
  }), {
    c() {
      v(e.$$.fragment);
    },
    m(n, l) {
      y(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l[0] & /*scanButtonText*/
      8 && (i.title = /*scanButtonText*/
      n[3]), l[0] & /*camModal, manualMode, allowManualEntry, value, validator, cameraEnabled, videoEle*/
      501 | l[1] & /*$$scope*/
      32 && (i.$$scope = { dirty: l, ctx: n }), e.$set(i);
    },
    i(n) {
      t || (b(e.$$.fragment, n), t = !0);
    },
    o(n) {
      g(e.$$.fragment, n), t = !1;
    },
    d(n) {
      S(e, n);
    }
  };
}
function Le(a) {
  let e, t, n, l, i, r, o, u, s, f = (
    /*value*/
    a[0] && !/*manualMode*/
    a[8] && x(a)
  ), c = (
    /*allowManualEntry*/
    a[2] && /*manualMode*/
    a[8] && ee(a)
  );
  const k = [Oe, Ee], h = [];
  function M(_, w) {
    return (
      /*value*/
      _[0] ? 0 : 1
    );
  }
  l = M(a), i = h[l] = k[l](a);
  let j = {
    $$slots: { default: [He] },
    $$scope: { ctx: a }
  };
  return u = new Ce({ props: j }), a[26](u), u.$on(
    "hide",
    /*hideReaderModal*/
    a[11]
  ), {
    c() {
      e = F("div"), f && f.c(), t = V(), c && c.c(), n = V(), i.c(), r = V(), o = F("div"), v(u.$$.fragment), q(e, "class", "scanner-video-wrapper"), q(o, "class", "modal-wrap");
    },
    m(_, w) {
      p(_, e, w), f && f.m(e, null), T(e, t), c && c.m(e, null), T(e, n), h[l].m(e, null), p(_, r, w), p(_, o, w), y(u, o, null), s = !0;
    },
    p(_, w) {
      /*value*/
      _[0] && !/*manualMode*/
      _[8] ? f ? (f.p(_, w), w[0] & /*value, manualMode*/
      257 && b(f, 1)) : (f = x(_), f.c(), b(f, 1), f.m(e, t)) : f && (R(), g(f, 1, 1, () => {
        f = null;
      }), z()), /*allowManualEntry*/
      _[2] && /*manualMode*/
      _[8] ? c ? (c.p(_, w), w[0] & /*allowManualEntry, manualMode*/
      260 && b(c, 1)) : (c = ee(_), c.c(), b(c, 1), c.m(e, n)) : c && (R(), g(c, 1, 1, () => {
        c = null;
      }), z());
      let B = l;
      l = M(_), l === B ? h[l].p(_, w) : (R(), g(h[B], 1, 1, () => {
        h[B] = null;
      }), z(), i = h[l], i ? i.p(_, w) : (i = h[l] = k[l](_), i.c()), b(i, 1), i.m(e, null));
      const O = {};
      w[0] & /*scanButtonText, camModal, manualMode, allowManualEntry, value, validator, cameraEnabled, videoEle*/
      509 | w[1] & /*$$scope*/
      32 && (O.$$scope = { dirty: w, ctx: _ }), u.$set(O);
    },
    i(_) {
      s || (b(f), b(c), b(i), b(u.$$.fragment, _), s = !0);
    },
    o(_) {
      g(f), g(c), g(i), g(u.$$.fragment, _), s = !1;
    },
    d(_) {
      _ && (C(e), C(r), C(o)), f && f.d(), c && c.d(), h[l].d(), a[26](null), S(u);
    }
  };
}
function Pe(a, e, t) {
  let { value: n } = e, { disabled: l = !1 } = e, { allowManualEntry: i = !1 } = e, { autoConfirm: r = !1 } = e, { scanButtonText: o = "Scan code" } = e, { beepOnScan: u = !1 } = e, { beepFrequency: s = 2637 } = e, { customFrequency: f = 1046 } = e, { preferredCamera: c = "environment" } = e, { defaultZoom: k = 1 } = e, { validator: h } = e;
  const M = ve();
  let j, _, w = !1, B, O = !1, E, H = { facingMode: c }, Q = {
    fps: 25,
    qrbox: { width: 250, height: 250 }
  };
  const N = new (window.AudioContext || window.webkitAudioContext)(), G = (d) => {
    n != d && (u && de(), M("change", d), r && !(h != null && h(d)) && (_ == null || _.hide()));
  }, U = async () => {
    E && E.stop();
    const { Html5Qrcode: d } = await import("./index-e5b4f47f.js");
    return E = new d("reader"), new Promise((A) => {
      E.start(H, Q, G).then(() => {
        if (k > 1) {
          const X = E.getRunningTrackCameraCapabilities().zoomFeature();
          X.isSupported() && X.apply(k);
        }
        A({ initialised: !0 });
      }).catch((Z) => {
        console.error("There was a problem scanning the image", Z), A({ initialised: !1 });
      });
    });
  }, m = async () => {
    const { Html5Qrcode: d } = await import("./index-e5b4f47f.js");
    return new Promise((A) => {
      d.getCameras().then((Z) => {
        Z && Z.length && A({ enabled: !0 });
      }).catch((Z) => {
        console.error(Z), A({ enabled: !1 });
      });
    });
  }, Y = async () => {
    const d = await U();
    t(18, O = d.initialised);
  }, W = async () => {
    _.show();
    const d = await m();
    t(6, B = d.enabled);
  }, ce = async () => {
    t(6, B = void 0), t(18, O = !1), E && (await E.stop(), E = void 0), _.hide();
  }, de = () => {
    const d = N.createOscillator(), A = N.createGain();
    d.connect(A), A.connect(N.destination);
    const Z = s === "custom" ? f : s;
    d.frequency.value = Z, d.type = "square";
    const X = 420, $ = N.currentTime + X / 1e3;
    A.gain.setValueAtTime(1, N.currentTime), A.gain.exponentialRampToValueAtTime(1e-3, $), d.start(), d.stop($);
  };
  function me(d) {
    n = d, t(0, n);
  }
  const _e = () => {
    M("change", n);
  }, be = () => {
    M("change", "");
  }, ge = () => {
    W();
  }, he = () => {
    t(8, w = !0), _.hide();
  }, ke = () => {
    _.hide();
  };
  function we(d) {
    L[d ? "unshift" : "push"](() => {
      j = d, t(5, j);
    });
  }
  function pe(d) {
    L[d ? "unshift" : "push"](() => {
      _ = d, t(7, _);
    });
  }
  return a.$$set = (d) => {
    "value" in d && t(0, n = d.value), "disabled" in d && t(1, l = d.disabled), "allowManualEntry" in d && t(2, i = d.allowManualEntry), "autoConfirm" in d && t(12, r = d.autoConfirm), "scanButtonText" in d && t(3, o = d.scanButtonText), "beepOnScan" in d && t(13, u = d.beepOnScan), "beepFrequency" in d && t(14, s = d.beepFrequency), "customFrequency" in d && t(15, f = d.customFrequency), "preferredCamera" in d && t(16, c = d.preferredCamera), "defaultZoom" in d && t(17, k = d.defaultZoom), "validator" in d && t(4, h = d.validator);
  }, a.$$.update = () => {
    a.$$.dirty[0] & /*cameraEnabled, videoEle, cameraStarted*/
    262240 && B && j && !O && Y();
  }, [
    n,
    l,
    i,
    o,
    h,
    j,
    B,
    _,
    w,
    M,
    W,
    ce,
    r,
    u,
    s,
    f,
    c,
    k,
    O,
    me,
    _e,
    be,
    ge,
    he,
    ke,
    we,
    pe
  ];
}
class Xe extends ie {
  constructor(e) {
    super(), fe(
      this,
      e,
      Pe,
      Le,
      ue,
      {
        value: 0,
        disabled: 1,
        allowManualEntry: 2,
        autoConfirm: 12,
        scanButtonText: 3,
        beepOnScan: 13,
        beepFrequency: 14,
        customFrequency: 15,
        preferredCamera: 16,
        defaultZoom: 17,
        validator: 4
      },
      null,
      [-1, -1]
    );
  }
}
function ae(a) {
  let e, t;
  return e = new Xe({
    props: {
      value: (
        /*fieldState*/
        a[15].value
      ),
      disabled: (
        /*fieldState*/
        a[15].disabled || /*fieldState*/
        a[15].readonly
      ),
      allowManualEntry: (
        /*allowManualEntry*/
        a[7]
      ),
      autoConfirm: (
        /*autoConfirm*/
        a[8]
      ),
      scanButtonText: (
        /*scanText*/
        a[17]
      ),
      beepOnScan: (
        /*beepOnScan*/
        a[9]
      ),
      beepFrequency: (
        /*beepFrequency*/
        a[10]
      ),
      customFrequency: (
        /*customFrequency*/
        a[11]
      ),
      preferredCamera: (
        /*preferredCamera*/
        a[12]
      ),
      defaultZoom: (
        /*defaultZoom*/
        a[13]
      ),
      validator: (
        /*fieldState*/
        a[15].validator
      )
    }
  }), e.$on(
    "change",
    /*handleUpdate*/
    a[18]
  ), {
    c() {
      v(e.$$.fragment);
    },
    m(n, l) {
      y(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l & /*fieldState*/
      32768 && (i.value = /*fieldState*/
      n[15].value), l & /*fieldState*/
      32768 && (i.disabled = /*fieldState*/
      n[15].disabled || /*fieldState*/
      n[15].readonly), l & /*allowManualEntry*/
      128 && (i.allowManualEntry = /*allowManualEntry*/
      n[7]), l & /*autoConfirm*/
      256 && (i.autoConfirm = /*autoConfirm*/
      n[8]), l & /*scanText*/
      131072 && (i.scanButtonText = /*scanText*/
      n[17]), l & /*beepOnScan*/
      512 && (i.beepOnScan = /*beepOnScan*/
      n[9]), l & /*beepFrequency*/
      1024 && (i.beepFrequency = /*beepFrequency*/
      n[10]), l & /*customFrequency*/
      2048 && (i.customFrequency = /*customFrequency*/
      n[11]), l & /*preferredCamera*/
      4096 && (i.preferredCamera = /*preferredCamera*/
      n[12]), l & /*defaultZoom*/
      8192 && (i.defaultZoom = /*defaultZoom*/
      n[13]), l & /*fieldState*/
      32768 && (i.validator = /*fieldState*/
      n[15].validator), e.$set(i);
    },
    i(n) {
      t || (b(e.$$.fragment, n), t = !0);
    },
    o(n) {
      g(e.$$.fragment, n), t = !1;
    },
    d(n) {
      S(e, n);
    }
  };
}
function De(a) {
  let e, t, n = (
    /*fieldState*/
    a[15] && ae(a)
  );
  return {
    c() {
      n && n.c(), e = oe();
    },
    m(l, i) {
      n && n.m(l, i), p(l, e, i), t = !0;
    },
    p(l, i) {
      /*fieldState*/
      l[15] ? n ? (n.p(l, i), i & /*fieldState*/
      32768 && b(n, 1)) : (n = ae(l), n.c(), b(n, 1), n.m(e.parentNode, e)) : n && (R(), g(n, 1, 1, () => {
        n = null;
      }), z());
    },
    i(l) {
      t || (b(n), t = !0);
    },
    o(l) {
      g(n), t = !1;
    },
    d(l) {
      l && C(e), n && n.d(l);
    }
  };
}
function Ge(a) {
  let e, t, n, l;
  function i(u) {
    a[21](u);
  }
  function r(u) {
    a[22](u);
  }
  let o = {
    label: (
      /*label*/
      a[1]
    ),
    field: (
      /*field*/
      a[0]
    ),
    disabled: (
      /*disabled*/
      a[3]
    ),
    readonly: (
      /*readonly*/
      a[4]
    ),
    validation: (
      /*validation*/
      a[5]
    ),
    defaultValue: (
      /*defaultValue*/
      a[6]
    ),
    type: (
      /*type*/
      a[2]
    ),
    helpText: (
      /*helpText*/
      a[14]
    ),
    $$slots: { default: [De] },
    $$scope: { ctx: a }
  };
  return (
    /*fieldState*/
    a[15] !== void 0 && (o.fieldState = /*fieldState*/
    a[15]), /*fieldApi*/
    a[16] !== void 0 && (o.fieldApi = /*fieldApi*/
    a[16]), e = new Te({ props: o }), L.push(() => J(e, "fieldState", i)), L.push(() => J(e, "fieldApi", r)), {
      c() {
        v(e.$$.fragment);
      },
      m(u, s) {
        y(e, u, s), l = !0;
      },
      p(u, [s]) {
        const f = {};
        s & /*label*/
        2 && (f.label = /*label*/
        u[1]), s & /*field*/
        1 && (f.field = /*field*/
        u[0]), s & /*disabled*/
        8 && (f.disabled = /*disabled*/
        u[3]), s & /*readonly*/
        16 && (f.readonly = /*readonly*/
        u[4]), s & /*validation*/
        32 && (f.validation = /*validation*/
        u[5]), s & /*defaultValue*/
        64 && (f.defaultValue = /*defaultValue*/
        u[6]), s & /*type*/
        4 && (f.type = /*type*/
        u[2]), s & /*helpText*/
        16384 && (f.helpText = /*helpText*/
        u[14]), s & /*$$scope, fieldState, allowManualEntry, autoConfirm, scanText, beepOnScan, beepFrequency, customFrequency, preferredCamera, defaultZoom*/
        8568704 && (f.$$scope = { dirty: s, ctx: u }), !t && s & /*fieldState*/
        32768 && (t = !0, f.fieldState = /*fieldState*/
        u[15], K(() => t = !1)), !n && s & /*fieldApi*/
        65536 && (n = !0, f.fieldApi = /*fieldApi*/
        u[16], K(() => n = !1)), e.$set(f);
      },
      i(u) {
        l || (b(e.$$.fragment, u), l = !0);
      },
      o(u) {
        g(e.$$.fragment, u), l = !1;
      },
      d(u) {
        S(e, u);
      }
    }
  );
}
function Ue(a, e, t) {
  let n, { field: l } = e, { label: i } = e, { type: r = "barcodeqr" } = e, { disabled: o = !1 } = e, { readonly: u = !1 } = e, { validation: s } = e, { defaultValue: f = "" } = e, { onChange: c } = e, { allowManualEntry: k } = e, { autoConfirm: h } = e, { scanButtonText: M } = e, { beepOnScan: j } = e, { beepFrequency: _ } = e, { customFrequency: w } = e, { preferredCamera: B } = e, { defaultZoom: O } = e, { helpText: E = null } = e, H, Q;
  const N = (m) => {
    const Y = Q.setValue(m.detail);
    c && Y && c({ value: m.detail });
  };
  function G(m) {
    H = m, t(15, H);
  }
  function U(m) {
    Q = m, t(16, Q);
  }
  return a.$$set = (m) => {
    "field" in m && t(0, l = m.field), "label" in m && t(1, i = m.label), "type" in m && t(2, r = m.type), "disabled" in m && t(3, o = m.disabled), "readonly" in m && t(4, u = m.readonly), "validation" in m && t(5, s = m.validation), "defaultValue" in m && t(6, f = m.defaultValue), "onChange" in m && t(19, c = m.onChange), "allowManualEntry" in m && t(7, k = m.allowManualEntry), "autoConfirm" in m && t(8, h = m.autoConfirm), "scanButtonText" in m && t(20, M = m.scanButtonText), "beepOnScan" in m && t(9, j = m.beepOnScan), "beepFrequency" in m && t(10, _ = m.beepFrequency), "customFrequency" in m && t(11, w = m.customFrequency), "preferredCamera" in m && t(12, B = m.preferredCamera), "defaultZoom" in m && t(13, O = m.defaultZoom), "helpText" in m && t(14, E = m.helpText);
  }, a.$$.update = () => {
    a.$$.dirty & /*scanButtonText*/
    1048576 && t(17, n = M || "Scan code");
  }, [
    l,
    i,
    r,
    o,
    u,
    s,
    f,
    k,
    h,
    j,
    _,
    w,
    B,
    O,
    E,
    H,
    Q,
    n,
    N,
    c,
    M,
    G,
    U
  ];
}
class $e extends ie {
  constructor(e) {
    super(), fe(this, e, Ue, Ge, ue, {
      field: 0,
      label: 1,
      type: 2,
      disabled: 3,
      readonly: 4,
      validation: 5,
      defaultValue: 6,
      onChange: 19,
      allowManualEntry: 7,
      autoConfirm: 8,
      scanButtonText: 20,
      beepOnScan: 9,
      beepFrequency: 10,
      customFrequency: 11,
      preferredCamera: 12,
      defaultZoom: 13,
      helpText: 14
    });
  }
}
export {
  $e as default
};
