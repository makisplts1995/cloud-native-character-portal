import { S as y, i as Q, s as R, F as D, e as p, b as k, f as C, G as L, H as j, J as q, k as g, n as h, o as w, a as W, d as I, g as M, l as E, h as ee, z as S, A as z, r as le, aP as te, ae as ne, u as ie, I as T, c as U, aD as F, m as V, p as Y, N as G, O as se, ab as oe, t as ae, j as fe, B as J } from "./index-e79f0bb2.js";
function ce(l) {
  let e, s;
  const t = (
    /*#slots*/
    l[1].default
  ), n = D(
    t,
    l,
    /*$$scope*/
    l[0],
    null
  );
  return {
    c() {
      e = p("ul"), n && n.c(), k(e, "class", "spectrum-Menu"), k(e, "role", "menu");
    },
    m(i, r) {
      C(i, e, r), n && n.m(e, null), s = !0;
    },
    p(i, [r]) {
      n && n.p && (!s || r & /*$$scope*/
      1) && L(
        n,
        t,
        i,
        /*$$scope*/
        i[0],
        s ? q(
          t,
          /*$$scope*/
          i[0],
          r,
          null
        ) : j(
          /*$$scope*/
          i[0]
        ),
        null
      );
    },
    i(i) {
      s || (g(n, i), s = !0);
    },
    o(i) {
      h(n, i), s = !1;
    },
    d(i) {
      i && w(e), n && n.d(i);
    }
  };
}
function ue(l, e, s) {
  let { $$slots: t = {}, $$scope: n } = e;
  return l.$$set = (i) => {
    "$$scope" in i && s(0, n = i.$$scope);
  }, [n, t];
}
class be extends y {
  constructor(e) {
    super(), Q(this, e, ue, ce, R, {});
  }
}
function K(l, e, s) {
  const t = l.slice();
  return t[17] = e[s], t;
}
const re = (l) => ({}), N = (l) => ({});
function O(l) {
  let e, s, t;
  return s = new T({
    props: {
      name: (
        /*icon*/
        l[0]
      ),
      weight: (
        /*iconWeight*/
        l[1]
      ),
      size: "S",
      color: (
        /*iconColour*/
        l[2] || "var(--spectrum-global-color-gray-700)"
      )
    }
  }), {
    c() {
      e = p("div"), U(s.$$.fragment), k(e, "class", "icon svelte-b9x87s"), F(
        e,
        "align-self",
        /*iconAlign*/
        l[4]
      ), I(
        e,
        "iconHidden",
        /*iconHidden*/
        l[3]
      );
    },
    m(n, i) {
      C(n, e, i), V(s, e, null), t = !0;
    },
    p(n, i) {
      const r = {};
      i & /*icon*/
      1 && (r.name = /*icon*/
      n[0]), i & /*iconWeight*/
      2 && (r.weight = /*iconWeight*/
      n[1]), i & /*iconColour*/
      4 && (r.color = /*iconColour*/
      n[2] || "var(--spectrum-global-color-gray-700)"), s.$set(r), (!t || i & /*iconAlign*/
      16) && F(
        e,
        "align-self",
        /*iconAlign*/
        n[4]
      ), (!t || i & /*iconHidden*/
      8) && I(
        e,
        "iconHidden",
        /*iconHidden*/
        n[3]
      );
    },
    i(n) {
      t || (g(s.$$.fragment, n), t = !0);
    },
    o(n) {
      h(s.$$.fragment, n), t = !1;
    },
    d(n) {
      n && w(e), Y(s);
    }
  };
}
function P(l) {
  let e, s, t;
  const n = (
    /*#slots*/
    l[12].right
  ), i = D(
    n,
    l,
    /*$$scope*/
    l[11],
    N
  );
  let r = G(
    /*keys*/
    l[6]
  ), u = [];
  for (let f = 0; f < r.length; f += 1)
    u[f] = X(K(l, r, f));
  const c = (f) => h(u[f], 1, 1, () => {
    u[f] = null;
  });
  return {
    c() {
      e = p("div"), i && i.c(), s = W();
      for (let f = 0; f < u.length; f += 1)
        u[f].c();
      k(e, "class", "keys svelte-b9x87s");
    },
    m(f, a) {
      C(f, e, a), i && i.m(e, null), M(e, s);
      for (let o = 0; o < u.length; o += 1)
        u[o] && u[o].m(e, null);
      t = !0;
    },
    p(f, a) {
      if (i && i.p && (!t || a & /*$$scope*/
      2048) && L(
        i,
        n,
        f,
        /*$$scope*/
        f[11],
        t ? q(
          n,
          /*$$scope*/
          f[11],
          a,
          re
        ) : j(
          /*$$scope*/
          f[11]
        ),
        N
      ), a & /*iconWeight, keys*/
      66) {
        r = G(
          /*keys*/
          f[6]
        );
        let o;
        for (o = 0; o < r.length; o += 1) {
          const d = K(f, r, o);
          u[o] ? (u[o].p(d, a), g(u[o], 1)) : (u[o] = X(d), u[o].c(), g(u[o], 1), u[o].m(e, null));
        }
        for (S(), o = r.length; o < u.length; o += 1)
          c(o);
        z();
      }
    },
    i(f) {
      if (!t) {
        g(i, f);
        for (let a = 0; a < r.length; a += 1)
          g(u[a]);
        t = !0;
      }
    },
    o(f) {
      h(i, f), u = u.filter(Boolean);
      for (let a = 0; a < u.length; a += 1)
        h(u[a]);
      t = !1;
    },
    d(f) {
      f && w(e), i && i.d(f), se(u, f);
    }
  };
}
function _e(l) {
  let e = (
    /*key*/
    l[17] + ""
  ), s;
  return {
    c() {
      s = ae(e);
    },
    m(t, n) {
      C(t, s, n);
    },
    p(t, n) {
      n & /*keys*/
      64 && e !== (e = /*key*/
      t[17] + "") && fe(s, e);
    },
    i: J,
    o: J,
    d(t) {
      t && w(s);
    }
  };
}
function ge(l) {
  let e, s;
  return e = new T({
    props: {
      size: "XS",
      weight: (
        /*iconWeight*/
        l[1]
      ),
      name: (
        /*key*/
        l[17].split("!")[1]
      )
    }
  }), {
    c() {
      U(e.$$.fragment);
    },
    m(t, n) {
      V(e, t, n), s = !0;
    },
    p(t, n) {
      const i = {};
      n & /*iconWeight*/
      2 && (i.weight = /*iconWeight*/
      t[1]), n & /*keys*/
      64 && (i.name = /*key*/
      t[17].split("!")[1]), e.$set(i);
    },
    i(t) {
      s || (g(e.$$.fragment, t), s = !0);
    },
    o(t) {
      h(e.$$.fragment, t), s = !1;
    },
    d(t) {
      Y(e, t);
    }
  };
}
function X(l) {
  let e, s, t, n, i, r;
  const u = [ge, _e], c = [];
  function f(a, o) {
    return o & /*keys*/
    64 && (s = null), s == null && (s = !!/*key*/
    a[17].startsWith("!")), s ? 0 : 1;
  }
  return t = f(l, -1), n = c[t] = u[t](l), {
    c() {
      e = p("div"), n.c(), i = W(), k(e, "class", "key svelte-b9x87s");
    },
    m(a, o) {
      C(a, e, o), c[t].m(e, null), M(e, i), r = !0;
    },
    p(a, o) {
      let d = t;
      t = f(a, o), t === d ? c[t].p(a, o) : (S(), h(c[d], 1, 1, () => {
        c[d] = null;
      }), z(), n = c[t], n ? n.p(a, o) : (n = c[t] = u[t](a), n.c()), g(n, 1), n.m(e, i));
    },
    i(a) {
      r || (g(n), r = !0);
    },
    o(a) {
      h(n), r = !1;
    },
    d(a) {
      a && w(e), c[t].d();
    }
  };
}
function me(l) {
  var d;
  let e, s, t, n, i, r, u, c = (
    /*icon*/
    l[0] && O(l)
  );
  const f = (
    /*#slots*/
    l[12].default
  ), a = D(
    f,
    l,
    /*$$scope*/
    l[11],
    null
  );
  let o = (
    /*keys*/
    (((d = l[6]) == null ? void 0 : d.length) || /*$$slots*/
    l[8].right) && P(l)
  );
  return {
    c() {
      e = p("li"), c && c.c(), s = W(), t = p("span"), a && a.c(), n = W(), o && o.c(), k(t, "class", "spectrum-Menu-itemLabel svelte-b9x87s"), k(e, "class", "spectrum-Menu-item svelte-b9x87s"), k(e, "role", "menuitem"), k(e, "tabindex", "0"), I(
        e,
        "is-disabled",
        /*disabled*/
        l[5]
      );
    },
    m(m, b) {
      C(m, e, b), c && c.m(e, null), M(e, s), M(e, t), a && a.m(t, null), M(e, n), o && o.m(e, null), i = !0, r || (u = [
        E(e, "click", function() {
          ee(
            /*disabled*/
            l[5] ? null : (
              /*onClick*/
              l[7]
            )
          ) && /*disabled*/
          (l[5] ? null : (
            /*onClick*/
            l[7]
          )).apply(this, arguments);
        }),
        E(
          e,
          "auxclick",
          /*auxclick_handler*/
          l[13]
        )
      ], r = !0);
    },
    p(m, [b]) {
      var v;
      l = m, /*icon*/
      l[0] ? c ? (c.p(l, b), b & /*icon*/
      1 && g(c, 1)) : (c = O(l), c.c(), g(c, 1), c.m(e, s)) : c && (S(), h(c, 1, 1, () => {
        c = null;
      }), z()), a && a.p && (!i || b & /*$$scope*/
      2048) && L(
        a,
        f,
        l,
        /*$$scope*/
        l[11],
        i ? q(
          f,
          /*$$scope*/
          l[11],
          b,
          null
        ) : j(
          /*$$scope*/
          l[11]
        ),
        null
      ), /*keys*/
      (v = l[6]) != null && v.length || /*$$slots*/
      l[8].right ? o ? (o.p(l, b), b & /*keys, $$slots*/
      320 && g(o, 1)) : (o = P(l), o.c(), g(o, 1), o.m(e, null)) : o && (S(), h(o, 1, 1, () => {
        o = null;
      }), z()), (!i || b & /*disabled*/
      32) && I(
        e,
        "is-disabled",
        /*disabled*/
        l[5]
      );
    },
    i(m) {
      i || (g(c), g(a, m), g(o), i = !0);
    },
    o(m) {
      h(c), h(a, m), h(o), i = !1;
    },
    d(m) {
      m && w(e), c && c.d(), a && a.d(m), o && o.d(), r = !1, le(u);
    }
  };
}
function he(l, e, s) {
  let t, { $$slots: n = {}, $$scope: i } = e;
  const r = te(n), u = ne(), c = ie("actionMenu");
  let { icon: f = void 0 } = e, { iconWeight: a = "regular" } = e, { iconColour: o = void 0 } = e, { iconHidden: d = !1 } = e, { iconAlign: m = "center" } = e, { disabled: b = void 0 } = e, { noClose: v = !1 } = e, { keyBind: B = void 0 } = e;
  const Z = (_) => {
    let H = (_ == null ? void 0 : _.split("+")) || [];
    for (let A = 0; A < H.length; A++)
      H[A].toLowerCase() === "ctrl" && navigator.platform.startsWith("Mac") && (H[A] = "⌘");
    return H;
  }, x = () => {
    c && !v && c.hideAll(), u("click");
  };
  function $(_) {
    oe.call(this, l, _);
  }
  return l.$$set = (_) => {
    "icon" in _ && s(0, f = _.icon), "iconWeight" in _ && s(1, a = _.iconWeight), "iconColour" in _ && s(2, o = _.iconColour), "iconHidden" in _ && s(3, d = _.iconHidden), "iconAlign" in _ && s(4, m = _.iconAlign), "disabled" in _ && s(5, b = _.disabled), "noClose" in _ && s(9, v = _.noClose), "keyBind" in _ && s(10, B = _.keyBind), "$$scope" in _ && s(11, i = _.$$scope);
  }, l.$$.update = () => {
    l.$$.dirty & /*keyBind*/
    1024 && s(6, t = Z(B));
  }, [
    f,
    a,
    o,
    d,
    m,
    b,
    t,
    x,
    r,
    v,
    B,
    i,
    n,
    $
  ];
}
class ke extends y {
  constructor(e) {
    super(), Q(this, e, he, me, R, {
      icon: 0,
      iconWeight: 1,
      iconColour: 2,
      iconHidden: 3,
      iconAlign: 4,
      disabled: 5,
      noClose: 9,
      keyBind: 10
    });
  }
}
export {
  ke as I,
  be as M
};
