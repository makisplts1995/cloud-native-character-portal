import { S as Z, i as v, s as q, y as B, f as G, k as f, z as H, n as u, A as R, o as U, u as b, v as j, al as x, cD as $, B as ee, c as te, m as ne, p as ie, F as oe, G as le, H as ae, J as se } from "./index-e79f0bb2.js";
import { I as re } from "./InnerForm-04bc2863.js";
function J(a) {
  let o = (
    /*resetKey*/
    a[10]
  ), n, e, t = O(a);
  return {
    c() {
      t.c(), n = B();
    },
    m(i, r) {
      t.m(i, r), G(i, n, r), e = !0;
    },
    p(i, r) {
      r & /*resetKey*/
      1024 && q(o, o = /*resetKey*/
      i[10]) ? (H(), u(t, 1, 1, ee), R(), t = O(i), t.c(), f(t, 1), t.m(n.parentNode, n)) : t.p(i, r);
    },
    i(i) {
      e || (f(t), e = !0);
    },
    o(i) {
      u(t), e = !1;
    },
    d(i) {
      i && U(n), t.d(i);
    }
  };
}
function fe(a) {
  let o;
  const n = (
    /*#slots*/
    a[19].default
  ), e = oe(
    n,
    a,
    /*$$scope*/
    a[20],
    null
  );
  return {
    c() {
      e && e.c();
    },
    m(t, i) {
      e && e.m(t, i), o = !0;
    },
    p(t, i) {
      e && e.p && (!o || i & /*$$scope*/
      1048576) && le(
        e,
        n,
        t,
        /*$$scope*/
        t[20],
        o ? se(
          n,
          /*$$scope*/
          t[20],
          i,
          null
        ) : ae(
          /*$$scope*/
          t[20]
        ),
        null
      );
    },
    i(t) {
      o || (f(e, t), o = !0);
    },
    o(t) {
      u(e, t), o = !1;
    },
    d(t) {
      e && e.d(t);
    }
  };
}
function O(a) {
  let o, n;
  return o = new re({
    props: {
      dataSource: (
        /*dataSource*/
        a[0]
      ),
      size: (
        /*size*/
        a[1]
      ),
      disabled: (
        /*disabled*/
        a[2]
      ),
      readonly: (
        /*readonly*/
        a[3]
      ),
      schema: (
        /*schema*/
        a[6]
      ),
      definition: (
        /*definition*/
        a[8]
      ),
      initialValues: (
        /*initialValues*/
        a[7]
      ),
      disableSchemaValidation: (
        /*disableSchemaValidation*/
        a[4]
      ),
      editAutoColumns: (
        /*editAutoColumns*/
        a[5]
      ),
      currentStep: (
        /*currentStep*/
        a[13]
      ),
      $$slots: { default: [fe] },
      $$scope: { ctx: a }
    }
  }), {
    c() {
      te(o.$$.fragment);
    },
    m(e, t) {
      ne(o, e, t), n = !0;
    },
    p(e, t) {
      const i = {};
      t & /*dataSource*/
      1 && (i.dataSource = /*dataSource*/
      e[0]), t & /*size*/
      2 && (i.size = /*size*/
      e[1]), t & /*disabled*/
      4 && (i.disabled = /*disabled*/
      e[2]), t & /*readonly*/
      8 && (i.readonly = /*readonly*/
      e[3]), t & /*schema*/
      64 && (i.schema = /*schema*/
      e[6]), t & /*definition*/
      256 && (i.definition = /*definition*/
      e[8]), t & /*initialValues*/
      128 && (i.initialValues = /*initialValues*/
      e[7]), t & /*disableSchemaValidation*/
      16 && (i.disableSchemaValidation = /*disableSchemaValidation*/
      e[4]), t & /*editAutoColumns*/
      32 && (i.editAutoColumns = /*editAutoColumns*/
      e[5]), t & /*$$scope*/
      1048576 && (i.$$scope = { dirty: t, ctx: e }), o.$set(i);
    },
    i(e) {
      n || (f(o.$$.fragment, e), n = !0);
    },
    o(e) {
      u(o.$$.fragment, e), n = !1;
    },
    d(e) {
      ie(o, e);
    }
  };
}
function ue(a) {
  let o, n, e = (
    /*loaded*/
    a[9] && J(a)
  );
  return {
    c() {
      e && e.c(), o = B();
    },
    m(t, i) {
      e && e.m(t, i), G(t, o, i), n = !0;
    },
    p(t, [i]) {
      /*loaded*/
      t[9] ? e ? (e.p(t, i), i & /*loaded*/
      512 && f(e, 1)) : (e = J(t), e.c(), f(e, 1), e.m(o.parentNode, o)) : e && (H(), u(e, 1, 1, () => {
        e = null;
      }), R());
    },
    i(t) {
      n || (f(e), n = !0);
    },
    o(t) {
      u(e), n = !1;
    },
    d(t) {
      t && U(o), e && e.d(t);
    }
  };
}
function ce(a, o, n) {
  let e, t, i, r, h, { $$slots: E = {}, $$scope: F } = o, { dataSource: m } = o, { size: I } = o, { disabled: y = !1 } = o, { readonly: S = !1 } = o, { actionType: k = "Create" } = o, { initialFormStep: g = 1 } = o, { disableSchemaValidation: w = !1 } = o, { editAutoColumns: z = !1 } = o;
  const A = b("context");
  j(a, A, (l) => n(17, r = l));
  const N = b("component");
  j(a, N, (l) => n(18, h = l));
  const { fetchDatasourceSchema: L, fetchDatasourceDefinition: M } = b("sdk"), P = () => {
    const l = parseInt(g.toString());
    return isNaN(l) ? 1 : l;
  };
  let V, p, C = !1, Q = b("current-step") || x(P());
  const W = (l, s, c, d) => {
    var D, K;
    if (l !== "Update")
      return {};
    const T = s == null ? void 0 : s.type;
    if (T !== "table" && T !== "viewV2")
      return {};
    for (let _ of c.toReversed().slice(1))
      if (s.type === "viewV2" && ((D = d[_]) == null ? void 0 : D._viewId) === s.id || s.type === "table" && ((K = d[_]) == null ? void 0 : K.tableId) === s.tableId)
        return d[_];
    return {};
  }, X = async (l) => {
    try {
      n(8, V = await M(l));
    } catch {
      n(8, V = void 0);
    }
    const s = await L(l);
    n(6, p = s || {}), C || n(9, C = !0);
  }, Y = (l) => {
    if (!l)
      return null;
    const s = Object.keys(l);
    return s.sort(), s.map((c) => `${c}:${l[c].type}`).join("-");
  };
  return a.$$set = (l) => {
    "dataSource" in l && n(0, m = l.dataSource), "size" in l && n(1, I = l.size), "disabled" in l && n(2, y = l.disabled), "readonly" in l && n(3, S = l.readonly), "actionType" in l && n(14, k = l.actionType), "initialFormStep" in l && n(15, g = l.initialFormStep), "disableSchemaValidation" in l && n(4, w = l.disableSchemaValidation), "editAutoColumns" in l && n(5, z = l.editAutoColumns), "$$scope" in l && n(20, F = l.$$scope);
  }, a.$$.update = () => {
    a.$$.dirty & /*dataSource*/
    1 && X(m), a.$$.dirty & /*schema*/
    64 && n(16, e = Y(p)), a.$$.dirty & /*actionType, dataSource, $component, $context*/
    409601 && n(7, t = W(k, m, h.path, r)), a.$$.dirty & /*schemaKey, initialValues, disabled, readonly*/
    65676 && n(10, i = $(e + JSON.stringify(t) + y + S));
  }, [
    m,
    I,
    y,
    S,
    w,
    z,
    p,
    t,
    V,
    C,
    i,
    A,
    N,
    Q,
    k,
    g,
    e,
    r,
    h,
    E,
    F
  ];
}
class _e extends Z {
  constructor(o) {
    super(), v(this, o, ce, ue, q, {
      dataSource: 0,
      size: 1,
      disabled: 2,
      readonly: 3,
      actionType: 14,
      initialFormStep: 15,
      disableSchemaValidation: 4,
      editAutoColumns: 5
    });
  }
}
export {
  _e as default
};
