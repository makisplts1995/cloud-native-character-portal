import { S as h, i as w, s as z, y as T, f as k, k as r, z as P, n as l, A as U, o as A, aw as v, av as S, a3 as c, a1 as f, c as p, m as g, p as b, bQ as C, a2 as m } from "./index-e79f0bb2.js";
function _(n) {
  let t, s;
  return t = new S({
    props: {
      text: (
        /*showTooltip*/
        n[3] ? c(
          /*user*/
          n[0]
        ) : ""
      ),
      position: (
        /*tooltipPosition*/
        n[2]
      ),
      color: f(
        /*user*/
        n[0]
      ),
      $$slots: { default: [q] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      p(t.$$.fragment);
    },
    m(e, o) {
      g(t, e, o), s = !0;
    },
    p(e, o) {
      const i = {};
      o & /*showTooltip, user*/
      9 && (i.text = /*showTooltip*/
      e[3] ? c(
        /*user*/
        e[0]
      ) : ""), o & /*tooltipPosition*/
      4 && (i.position = /*tooltipPosition*/
      e[2]), o & /*user*/
      1 && (i.color = f(
        /*user*/
        e[0]
      )), o & /*$$scope, size, user*/
      19 && (i.$$scope = { dirty: o, ctx: e }), t.$set(i);
    },
    i(e) {
      s || (r(t.$$.fragment, e), s = !0);
    },
    o(e) {
      l(t.$$.fragment, e), s = !1;
    },
    d(e) {
      b(t, e);
    }
  };
}
function q(n) {
  let t, s;
  return t = new C({
    props: {
      size: (
        /*size*/
        n[1]
      ),
      initials: m(
        /*user*/
        n[0]
      ),
      color: f(
        /*user*/
        n[0]
      )
    }
  }), {
    c() {
      p(t.$$.fragment);
    },
    m(e, o) {
      g(t, e, o), s = !0;
    },
    p(e, o) {
      const i = {};
      o & /*size*/
      2 && (i.size = /*size*/
      e[1]), o & /*user*/
      1 && (i.initials = m(
        /*user*/
        e[0]
      )), o & /*user*/
      1 && (i.color = f(
        /*user*/
        e[0]
      )), t.$set(i);
    },
    i(e) {
      s || (r(t.$$.fragment, e), s = !0);
    },
    o(e) {
      l(t.$$.fragment, e), s = !1;
    },
    d(e) {
      b(t, e);
    }
  };
}
function I(n) {
  let t, s, e = (
    /*user*/
    n[0] && _(n)
  );
  return {
    c() {
      e && e.c(), t = T();
    },
    m(o, i) {
      e && e.m(o, i), k(o, t, i), s = !0;
    },
    p(o, [i]) {
      /*user*/
      o[0] ? e ? (e.p(o, i), i & /*user*/
      1 && r(e, 1)) : (e = _(o), e.c(), r(e, 1), e.m(t.parentNode, t)) : e && (P(), l(e, 1, 1, () => {
        e = null;
      }), U());
    },
    i(o) {
      s || (r(e), s = !0);
    },
    o(o) {
      l(e), s = !1;
    },
    d(o) {
      o && A(t), e && e.d(o);
    }
  };
}
function L(n, t, s) {
  let { user: e } = t, { size: o = "S" } = t, { tooltipPosition: i = v.Top } = t, { showTooltip: u = !0 } = t;
  return n.$$set = (a) => {
    "user" in a && s(0, e = a.user), "size" in a && s(1, o = a.size), "tooltipPosition" in a && s(2, i = a.tooltipPosition), "showTooltip" in a && s(3, u = a.showTooltip);
  }, [e, o, i, u];
}
class Q extends h {
  constructor(t) {
    super(), w(this, t, L, I, z, {
      user: 0,
      size: 1,
      tooltipPosition: 2,
      showTooltip: 3
    });
  }
}
export {
  Q as U
};
