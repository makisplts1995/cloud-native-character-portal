import { S as De, i as Ne, s as Ee, I as nt, F as We, e as $, c as W, a as x, t as de, b as U, f as M, m as K, g as le, j as je, G as Ke, H as Xe, J as Ye, k as p, z as he, n as w, A as we, o as E, p as X, N as He, y as Ae, O as ct, aM as Ht, h as Ue, aD as Ie, d as ne, aP as xt, av as io, w as Vl, aQ as uo, aR as Wt, ae as Ul, ak as me, al as Me, aS as Rt, aT as L, aU as ql, aV as Jt, aW as Gl, aO as co, aX as Wl, aY as ao, aZ as vt, D as fo, a_ as mo, a$ as rt, b0 as Mt, b1 as _o, b2 as Qe, b3 as Kl, b4 as Tt, b5 as go, b6 as yt, b7 as St, b8 as po, b9 as ho, a1 as wo, a3 as bo, ba as Xl, bb as Yl, bc as ko, bd as It, be as Ge, bf as Qt, bg as Kt, bh as Co, ap as Ft, bi as Ro, bj as vo, bk as So, bl as yo, bm as Io, ay as Nt, u as Te, v as A, aa as it, ac as $e, am as Ot, l as ke, bn as Mo, r as lt, bo as Zt, ab as dt, bp as Eo, bq as Ao, br as ln, ai as Bt, aj as en, B as Oe, C as $t, bs as ze, bt as ut, bu as tn, aq as Lo, bv as Do, bw as No, bx as Oo, by as Jl, bz as on, bA as sn, bB as Ql, bC as To, a7 as mt, a8 as st, ag as Ze, af as Vt, bD as zo, bE as rn, bF as Dt, bG as Po, bH as Zl, bI as Ho, bJ as Fo, bK as Bo, ad as jo, bL as un, bM as cn, P as Vo, q as $l, aB as Uo, bN as qo, E as Go, bO as Xt, bP as Wo } from "./index-e79f0bb2.js";
import { C as Ko } from "./CollapsedButtonGroup-789a5dc9.js";
import { c as zt, a as an } from "./table-87f82d38.js";
import { M as xl, I as Pe } from "./Item-8e1549c4.js";
import { U as Xo } from "./UserAvatar-97a868e1.js";
function fn(n, e, t) {
  const l = n.slice();
  return l[12] = e[t], l;
}
function dn(n) {
  let e, t = (
    /*splitMsg*/
    n[12] + ""
  ), l;
  return {
    c() {
      e = $("div"), l = de(t), U(e, "class", "spectrum-InLineAlert-content");
    },
    m(o, s) {
      M(o, e, s), le(e, l);
    },
    p(o, s) {
      s & /*split*/
      128 && t !== (t = /*splitMsg*/
      o[12] + "") && je(l, t);
    },
    d(o) {
      o && E(e);
    }
  };
}
function Yo(n) {
  let e, t = He(
    /*split*/
    n[7]
  ), l = [];
  for (let o = 0; o < t.length; o += 1)
    l[o] = dn(fn(n, t, o));
  return {
    c() {
      for (let o = 0; o < l.length; o += 1)
        l[o].c();
      e = Ae();
    },
    m(o, s) {
      for (let i = 0; i < l.length; i += 1)
        l[i] && l[i].m(o, s);
      M(o, e, s);
    },
    p(o, s) {
      if (s & /*split*/
      128) {
        t = He(
          /*split*/
          o[7]
        );
        let i;
        for (i = 0; i < t.length; i += 1) {
          const r = fn(o, t, i);
          l[i] ? l[i].p(r, s) : (l[i] = dn(r), l[i].c(), l[i].m(e.parentNode, e));
        }
        for (; i < l.length; i += 1)
          l[i].d(1);
        l.length = t.length;
      }
    },
    d(o) {
      o && E(e), ct(l, o);
    }
  };
}
function mn(n) {
  let e, t, l;
  return t = new Ht({
    props: {
      cta: (
        /*cta*/
        n[4]
      ),
      secondary: (
        /*cta*/
        !n[4]
      ),
      $$slots: { default: [Jo] },
      $$scope: { ctx: n }
    }
  }), t.$on("click", function() {
    Ue(
      /*onConfirm*/
      n[2]
    ) && n[2].apply(this, arguments);
  }), {
    c() {
      e = $("div"), W(t.$$.fragment), U(e, "class", "spectrum-InLineAlert-footer button svelte-1399oda");
    },
    m(o, s) {
      M(o, e, s), K(t, e, null), l = !0;
    },
    p(o, s) {
      n = o;
      const i = {};
      s & /*cta*/
      16 && (i.cta = /*cta*/
      n[4]), s & /*cta*/
      16 && (i.secondary = /*cta*/
      !n[4]), s & /*$$scope, buttonText*/
      2056 && (i.$$scope = { dirty: s, ctx: n }), t.$set(i);
    },
    i(o) {
      l || (p(t.$$.fragment, o), l = !0);
    },
    o(o) {
      w(t.$$.fragment, o), l = !1;
    },
    d(o) {
      o && E(e), X(t);
    }
  };
}
function Jo(n) {
  let e = (
    /*buttonText*/
    (n[3] || "OK") + ""
  ), t;
  return {
    c() {
      t = de(e);
    },
    m(l, o) {
      M(l, t, o);
    },
    p(l, o) {
      o & /*buttonText*/
      8 && e !== (e = /*buttonText*/
      (l[3] || "OK") + "") && je(t, e);
    },
    d(l) {
      l && E(t);
    }
  };
}
function _n(n) {
  let e, t, l, o, s, i;
  return s = new nt({
    props: { name: "arrow-square-out", size: "XS" }
  }), {
    c() {
      e = $("div"), t = $("a"), l = de(
        /*linkText*/
        n[6]
      ), o = x(), W(s.$$.fragment), U(
        t,
        "href",
        /*link*/
        n[5]
      ), U(t, "target", "_blank"), U(t, "rel", "noopener noreferrer"), U(t, "class", "docs-link svelte-1399oda"), U(e, "id", "docs-link"), U(e, "class", "svelte-1399oda");
    },
    m(r, u) {
      M(r, e, u), le(e, t), le(t, l), le(t, o), K(s, t, null), i = !0;
    },
    p(r, u) {
      (!i || u & /*linkText*/
      64) && je(
        l,
        /*linkText*/
        r[6]
      ), (!i || u & /*link*/
      32) && U(
        t,
        "href",
        /*link*/
        r[5]
      );
    },
    i(r) {
      i || (p(s.$$.fragment, r), i = !0);
    },
    o(r) {
      w(s.$$.fragment, r), i = !1;
    },
    d(r) {
      r && E(e), X(s);
    }
  };
}
function Qo(n) {
  let e, t, l, o, s, i, r, u, a, c;
  t = new nt({
    props: { name: (
      /*icon*/
      n[8]
    ), size: "M" }
  });
  const f = (
    /*#slots*/
    n[10].default
  ), d = We(
    f,
    n,
    /*$$scope*/
    n[11],
    null
  ), m = d || Yo(n);
  let _ = (
    /*onConfirm*/
    n[2] && mn(n)
  ), g = (
    /*link*/
    n[5] && /*linkText*/
    n[6] && _n(n)
  );
  return {
    c() {
      e = $("div"), W(t.$$.fragment), l = x(), o = $("div"), s = de(
        /*header*/
        n[1]
      ), i = x(), m && m.c(), r = x(), _ && _.c(), u = x(), g && g.c(), U(o, "class", "spectrum-InLineAlert-header"), U(e, "class", a = "spectrum-InLineAlert spectrum-InLineAlert--" + /*type*/
      n[0] + " svelte-1399oda");
    },
    m(v, R) {
      M(v, e, R), K(t, e, null), le(e, l), le(e, o), le(o, s), le(e, i), m && m.m(e, null), le(e, r), _ && _.m(e, null), le(e, u), g && g.m(e, null), c = !0;
    },
    p(v, [R]) {
      const b = {};
      R & /*icon*/
      256 && (b.name = /*icon*/
      v[8]), t.$set(b), (!c || R & /*header*/
      2) && je(
        s,
        /*header*/
        v[1]
      ), d ? d.p && (!c || R & /*$$scope*/
      2048) && Ke(
        d,
        f,
        v,
        /*$$scope*/
        v[11],
        c ? Ye(
          f,
          /*$$scope*/
          v[11],
          R,
          null
        ) : Xe(
          /*$$scope*/
          v[11]
        ),
        null
      ) : m && m.p && (!c || R & /*split*/
      128) && m.p(v, c ? R : -1), /*onConfirm*/
      v[2] ? _ ? (_.p(v, R), R & /*onConfirm*/
      4 && p(_, 1)) : (_ = mn(v), _.c(), p(_, 1), _.m(e, u)) : _ && (he(), w(_, 1, 1, () => {
        _ = null;
      }), we()), /*link*/
      v[5] && /*linkText*/
      v[6] ? g ? (g.p(v, R), R & /*link, linkText*/
      96 && p(g, 1)) : (g = _n(v), g.c(), p(g, 1), g.m(e, null)) : g && (he(), w(g, 1, 1, () => {
        g = null;
      }), we()), (!c || R & /*type*/
      1 && a !== (a = "spectrum-InLineAlert spectrum-InLineAlert--" + /*type*/
      v[0] + " svelte-1399oda")) && U(e, "class", a);
    },
    i(v) {
      c || (p(t.$$.fragment, v), p(m, v), p(_), p(g), c = !0);
    },
    o(v) {
      w(t.$$.fragment, v), w(m, v), w(_), w(g), c = !1;
    },
    d(v) {
      v && E(e), X(t), m && m.d(v), _ && _.d(), g && g.d();
    }
  };
}
function Zo(n) {
  switch (n) {
    case "error":
    case "negative":
      return "warning";
    case "success":
      return "check-circle";
    case "help":
      return "question";
    default:
      return "info";
  }
}
function $o(n, e, t) {
  let l, o, { $$slots: s = {}, $$scope: i } = e, { type: r = "info" } = e, { header: u = "" } = e, { message: a = "" } = e, { onConfirm: c = void 0 } = e, { buttonText: f = "" } = e, { cta: d = !1 } = e, { link: m = "" } = e, { linkText: _ = "" } = e;
  return n.$$set = (g) => {
    "type" in g && t(0, r = g.type), "header" in g && t(1, u = g.header), "message" in g && t(9, a = g.message), "onConfirm" in g && t(2, c = g.onConfirm), "buttonText" in g && t(3, f = g.buttonText), "cta" in g && t(4, d = g.cta), "link" in g && t(5, m = g.link), "linkText" in g && t(6, _ = g.linkText), "$$scope" in g && t(11, i = g.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*type*/
    1 && t(8, l = Zo(r)), n.$$.dirty & /*message*/
    512 && t(7, o = a.split(`
`));
  }, [
    r,
    u,
    c,
    f,
    d,
    m,
    _,
    o,
    l,
    a,
    s,
    i
  ];
}
class xo extends De {
  constructor(e) {
    super(), Ne(this, e, $o, Qo, Ee, {
      type: 0,
      header: 1,
      message: 9,
      onConfirm: 2,
      buttonText: 3,
      cta: 4,
      link: 5,
      linkText: 6
    });
  }
}
function gn(n) {
  let e, t, l;
  const o = (
    /*#slots*/
    n[9].default
  ), s = We(
    o,
    n,
    /*$$scope*/
    n[8],
    null
  );
  return {
    c() {
      e = $("div"), s && s.c(), U(e, "class", t = "spectrum-FieldLabel spectrum-ProgressBar-label spectrum-FieldLabel--size" + /*size*/
      n[6] + " svelte-1nu3ola");
    },
    m(i, r) {
      M(i, e, r), s && s.m(e, null), l = !0;
    },
    p(i, r) {
      s && s.p && (!l || r & /*$$scope*/
      256) && Ke(
        s,
        o,
        i,
        /*$$scope*/
        i[8],
        l ? Ye(
          o,
          /*$$scope*/
          i[8],
          r,
          null
        ) : Xe(
          /*$$scope*/
          i[8]
        ),
        null
      ), (!l || r & /*size*/
      64 && t !== (t = "spectrum-FieldLabel spectrum-ProgressBar-label spectrum-FieldLabel--size" + /*size*/
      i[6] + " svelte-1nu3ola")) && U(e, "class", t);
    },
    i(i) {
      l || (p(s, i), l = !0);
    },
    o(i) {
      w(s, i), l = !1;
    },
    d(i) {
      i && E(e), s && s.d(i);
    }
  };
}
function pn(n) {
  let e, t = Math.round(Number(
    /*value*/
    n[0]
  )) + "", l, o, s;
  return {
    c() {
      e = $("div"), l = de(t), o = de("%"), U(e, "class", s = "spectrum-FieldLabel spectrum-ProgressBar-percentage spectrum-FieldLabel--size" + /*size*/
      n[6] + " svelte-1nu3ola");
    },
    m(i, r) {
      M(i, e, r), le(e, l), le(e, o);
    },
    p(i, r) {
      r & /*value*/
      1 && t !== (t = Math.round(Number(
        /*value*/
        i[0]
      )) + "") && je(l, t), r & /*size*/
      64 && s !== (s = "spectrum-FieldLabel spectrum-ProgressBar-percentage spectrum-FieldLabel--size" + /*size*/
      i[6] + " svelte-1nu3ola") && U(e, "class", s);
    },
    d(i) {
      i && E(e);
    }
  };
}
function es(n) {
  let e, t, l, o, s, i, r, u, a, c, f, d = (
    /*$$slots*/
    n[7] && gn(n)
  ), m = !/*hidePercentage*/
  n[4] && /*value*/
  (n[0] || /*value*/
  n[0] === 0) && pn(n);
  return {
    c() {
      e = $("div"), d && d.c(), t = x(), m && m.c(), l = x(), o = $("div"), s = $("div"), i = x(), r = $("div"), U(s, "class", "spectrum-ProgressBar-fill svelte-1nu3ola"), Ie(s, "width", (typeof /*value*/
      n[0] == "number" ? (
        /*value*/
        n[0]
      ) : 0) + "%"), Ie(
        s,
        "--duration",
        /*duration*/
        n[1] + "ms"
      ), ne(
        s,
        "color-green",
        /*color*/
        n[5] === "green"
      ), ne(
        s,
        "color-red",
        /*color*/
        n[5] === "red"
      ), U(o, "class", "spectrum-ProgressBar-track"), U(r, "class", "spectrum-ProgressBar-label"), r.hidden = !1, U(e, "class", u = "spectrum-ProgressBar spectrum-ProgressBar--size" + /*size*/
      n[6] + " svelte-1nu3ola"), U(e, "role", "progressbar"), U(e, "aria-valuenow", a = typeof /*value*/
      n[0] == "number" ? (
        /*value*/
        n[0]
      ) : void 0), U(e, "aria-valuemin", "0"), U(e, "aria-valuemax", "100"), U(e, "style", c = /*width*/
      n[2] ? `width: ${typeof /*width*/
      n[2] == "string" ? (
        /*width*/
        n[2]
      ) : ""};` : ""), ne(e, "spectrum-ProgressBar--indeterminate", !/*value*/
      n[0] && /*value*/
      n[0] !== 0), ne(
        e,
        "spectrum-ProgressBar--sideLabel",
        /*sideLabel*/
        n[3]
      );
    },
    m(_, g) {
      M(_, e, g), d && d.m(e, null), le(e, t), m && m.m(e, null), le(e, l), le(e, o), le(o, s), le(e, i), le(e, r), f = !0;
    },
    p(_, [g]) {
      /*$$slots*/
      _[7] ? d ? (d.p(_, g), g & /*$$slots*/
      128 && p(d, 1)) : (d = gn(_), d.c(), p(d, 1), d.m(e, t)) : d && (he(), w(d, 1, 1, () => {
        d = null;
      }), we()), !/*hidePercentage*/
      _[4] && /*value*/
      (_[0] || /*value*/
      _[0] === 0) ? m ? m.p(_, g) : (m = pn(_), m.c(), m.m(e, l)) : m && (m.d(1), m = null), (!f || g & /*value*/
      1) && Ie(s, "width", (typeof /*value*/
      _[0] == "number" ? (
        /*value*/
        _[0]
      ) : 0) + "%"), (!f || g & /*duration*/
      2) && Ie(
        s,
        "--duration",
        /*duration*/
        _[1] + "ms"
      ), (!f || g & /*color*/
      32) && ne(
        s,
        "color-green",
        /*color*/
        _[5] === "green"
      ), (!f || g & /*color*/
      32) && ne(
        s,
        "color-red",
        /*color*/
        _[5] === "red"
      ), (!f || g & /*size*/
      64 && u !== (u = "spectrum-ProgressBar spectrum-ProgressBar--size" + /*size*/
      _[6] + " svelte-1nu3ola")) && U(e, "class", u), (!f || g & /*value*/
      1 && a !== (a = typeof /*value*/
      _[0] == "number" ? (
        /*value*/
        _[0]
      ) : void 0)) && U(e, "aria-valuenow", a), (!f || g & /*width*/
      4 && c !== (c = /*width*/
      _[2] ? `width: ${typeof /*width*/
      _[2] == "string" ? (
        /*width*/
        _[2]
      ) : ""};` : "")) && U(e, "style", c), (!f || g & /*size, value*/
      65) && ne(e, "spectrum-ProgressBar--indeterminate", !/*value*/
      _[0] && /*value*/
      _[0] !== 0), (!f || g & /*size, sideLabel*/
      72) && ne(
        e,
        "spectrum-ProgressBar--sideLabel",
        /*sideLabel*/
        _[3]
      );
    },
    i(_) {
      f || (p(d), f = !0);
    },
    o(_) {
      w(d), f = !1;
    },
    d(_) {
      _ && E(e), d && d.d(), m && m.d();
    }
  };
}
function ts(n, e, t) {
  let { $$slots: l = {}, $$scope: o } = e;
  const s = xt(l);
  let { value: i = !1 } = e, { duration: r = 1e3 } = e, { width: u = !1 } = e, { sideLabel: a = !1 } = e, { hidePercentage: c = !0 } = e, { color: f = void 0 } = e, { size: d = "M" } = e;
  return n.$$set = (m) => {
    "value" in m && t(0, i = m.value), "duration" in m && t(1, r = m.duration), "width" in m && t(2, u = m.width), "sideLabel" in m && t(3, a = m.sideLabel), "hidePercentage" in m && t(4, c = m.hidePercentage), "color" in m && t(5, f = m.color), "size" in m && t(6, d = m.size), "$$scope" in m && t(8, o = m.$$scope);
  }, [
    i,
    r,
    u,
    a,
    c,
    f,
    d,
    s,
    o,
    l
  ];
}
class Ut extends De {
  constructor(e) {
    super(), Ne(this, e, ts, es, Ee, {
      value: 0,
      duration: 1,
      width: 2,
      sideLabel: 3,
      hidePercentage: 4,
      color: 5,
      size: 6
    });
  }
}
function ns(n) {
  let e;
  const t = (
    /*#slots*/
    n[6].default
  ), l = We(
    t,
    n,
    /*$$scope*/
    n[7],
    null
  );
  return {
    c() {
      l && l.c();
    },
    m(o, s) {
      l && l.m(o, s), e = !0;
    },
    p(o, s) {
      l && l.p && (!e || s & /*$$scope*/
      128) && Ke(
        l,
        t,
        o,
        /*$$scope*/
        o[7],
        e ? Ye(
          t,
          /*$$scope*/
          o[7],
          s,
          null
        ) : Xe(
          /*$$scope*/
          o[7]
        ),
        null
      );
    },
    i(o) {
      e || (p(l, o), e = !0);
    },
    o(o) {
      w(l, o), e = !1;
    },
    d(o) {
      l && l.d(o);
    }
  };
}
function ls(n) {
  let e, t;
  return e = new io({
    props: {
      position: (
        /*position*/
        n[1]
      ),
      type: (
        /*type*/
        n[2]
      ),
      text: (
        /*visible*/
        n[3] ? (
          /*text*/
          n[0]
        ) : null
      ),
      fixed: (
        /*visible*/
        n[3]
      ),
      $$slots: { default: [ns] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, [o]) {
      const s = {};
      o & /*position*/
      2 && (s.position = /*position*/
      l[1]), o & /*type*/
      4 && (s.type = /*type*/
      l[2]), o & /*visible, text*/
      9 && (s.text = /*visible*/
      l[3] ? (
        /*text*/
        l[0]
      ) : null), o & /*visible*/
      8 && (s.fixed = /*visible*/
      l[3]), o & /*$$scope*/
      128 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function os(n, e, t) {
  let { $$slots: l = {}, $$scope: o } = e, { text: s = null } = e, { condition: i = !0 } = e, { duration: r = 5e3 } = e, { position: u } = e, { type: a } = e, c = !1, f;
  const d = () => {
    t(3, c = !0), f = setTimeout(
      () => {
        t(3, c = !1);
      },
      r
    );
  }, m = () => {
    t(3, c = !1), clearTimeout(f);
  };
  return Vl(m), n.$$set = (_) => {
    "text" in _ && t(0, s = _.text), "condition" in _ && t(4, i = _.condition), "duration" in _ && t(5, r = _.duration), "position" in _ && t(1, u = _.position), "type" in _ && t(2, a = _.type), "$$scope" in _ && t(7, o = _.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*condition*/
    16 && (i ? d() : m());
  }, [s, u, a, c, i, r, l, o];
}
class eo extends De {
  constructor(e) {
    super(), Ne(this, e, os, ls, Ee, {
      text: 0,
      condition: 4,
      duration: 5,
      position: 1,
      type: 2
    });
  }
}
const hn = (n) => {
  if (n.schema.icon && !n.schema.icon.startsWith("ri-"))
    return n.schema.icon;
  if (n.calculationType)
    return "calculator";
  if (n.schema.autocolumn)
    return "shapes";
  if (uo(n.schema))
    return "user";
  const { type: e, subtype: t } = n.schema;
  return (typeof Wt[e] == "object" && t ? Wt[e][t] : Wt[e]) || "article";
}, ss = () => {
  const n = Ul();
  let e = {};
  return { dispatch: (o, s) => {
    n(o, s);
    const i = e[o] || [];
    for (let r = 0; r < i.length; r++)
      i[r](s);
  }, subscribe: (o, s) => {
    const i = e[o] || [];
    return e[o] = [...i, s], () => {
      e[o] = e[o].filter((r) => r !== s);
    };
  } };
}, rs = () => {
  const n = Me({
    left: 0,
    top: 0,
    width: 0,
    height: 0
  }), e = me(n, (l) => l.width, 0), t = me(n, (l) => l.height, 0);
  return { bounds: n, height: t, width: e };
}, is = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createStores: rs
}, Symbol.toStringTag, { value: "Module" })), us = () => {
  const n = Me([]), e = me(n, (t) => {
    let l = Rt, o = 0;
    return t.map((s) => {
      const i = {
        ...s,
        __idx: o,
        __left: l
      };
      return s.visible && (o++, l += s.width ?? 0), i;
    });
  });
  return {
    columns: {
      ...n,
      subscribe: e.subscribe
    }
  };
}, cs = (n) => {
  const { columns: e } = n, t = me(e, (u) => {
    let a = {};
    return u.forEach((c) => {
      a[c.name] = c;
    }), a;
  }), l = me(e, (u) => u.filter((a) => !a.related)), o = me(e, (u) => u.filter((a) => a.visible)), s = me(o, (u) => u.find((a) => a.primaryDisplay)), i = me(o, (u) => u.filter((a) => !a.primaryDisplay)), r = me(e, (u) => u.filter((c) => {
    var f;
    return !((f = c.schema) != null && f.autocolumn);
  }).length > 0);
  return {
    tableColumns: l,
    displayColumn: s,
    columnLookupMap: t,
    visibleColumns: o,
    scrollableColumns: i,
    hasNonAutoColumn: r
  };
}, as = (n) => {
  const { columns: e, datasource: t } = n;
  return {
    columns: {
      ...e,
      actions: {
        changeAllColumnWidths: async (s) => {
          L(e).forEach((r) => {
            const { related: u } = r, a = { width: s };
            u ? t.actions.addSubSchemaMutation(
              u.subField,
              u.field,
              a
            ) : t.actions.addSchemaMutation(r.name, a);
          }), await t.actions.saveSchemaMutations();
        },
        isReadonly: (s) => s != null && s.schema ? s.schema.autocolumn || s.schema.disabled || s.schema.type === "formula" || s.schema.type === "ai" || s.schema.readonly : !1
      }
    }
  };
}, fs = (n) => {
  const { definition: e, columns: t, displayColumn: l, enrichedSchema: o } = n, s = (i) => {
    const r = L(e);
    if (!i || !r) {
      t.set([]);
      return;
    }
    const u = L(l);
    let a;
    const c = r.primaryDisplay || (u == null ? void 0 : u.name);
    c && i[c] && (a = c), t.set(
      Object.keys(i).map((f) => {
        const d = i[f], m = {
          type: d.type,
          name: f,
          label: d.displayName || f,
          schema: d,
          width: d.width || ql,
          visible: d.visible ?? !0,
          readonly: d.readonly,
          order: d.order,
          conditions: d.conditions,
          related: d.related,
          calculationType: d.calculationType,
          format: d.format,
          __left: void 0,
          // TODO
          __idx: void 0
          // TODO
        };
        return f === a && (m.order = 0, m.primaryDisplay = !0), m;
      }).sort((f, d) => {
        var R, b;
        if (f.name === a)
          return -1;
        if (d.name === a)
          return 1;
        const m = f.order, _ = d.order;
        if (m != null && _ != null)
          return m < _ ? -1 : 1;
        if (m != null)
          return -1;
        if (_ != null)
          return 1;
        const g = (R = f.schema) == null ? void 0 : R.autocolumn, v = (b = d.schema) == null ? void 0 : b.autocolumn;
        return g === v ? 0 : g ? 1 : -1;
      })
    );
  };
  o.subscribe(s);
}, ds = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: as,
  createStores: us,
  deriveStores: cs,
  initialise: fs
}, Symbol.toStringTag, { value: "Module" })), tt = (n) => {
  if (!n)
    return { rowId: void 0, field: void 0 };
  const e = n.split(Jt), t = e.pop();
  return { rowId: e.join(Jt), field: t };
}, xe = (n, e) => `${n}${Jt}${e}`, Ct = (n) => {
  var t, l, o, s;
  const e = n;
  return {
    x: e.clientX ?? ((l = (t = e.touches) == null ? void 0 : t[0]) == null ? void 0 : l.clientX),
    y: e.clientY ?? ((s = (o = e.touches) == null ? void 0 : o[0]) == null ? void 0 : s.clientY)
  };
}, ms = () => `${Gl}${co()}`, _s = (n) => n == null ? void 0 : n.startsWith(Gl), gs = () => ({
  menu: Me({
    left: 0,
    top: 0,
    visible: !1,
    multiRowMode: !1,
    multiCellMode: !1
  })
}), ps = (n) => {
  const {
    menu: e,
    focusedCellId: t,
    gridID: l,
    selectedRows: o,
    selectedRowCount: s,
    selectedCellMap: i,
    selectedCellCount: r
  } = n;
  return {
    menu: {
      ...e,
      actions: {
        open: (c, f) => {
          var b;
          f.preventDefault(), f.stopPropagation();
          const d = document.getElementById(l), m = (b = d == null ? void 0 : d.getElementsByClassName("grid-data-outer")) == null ? void 0 : b[0];
          if (!m)
            return;
          const _ = f.target.getBoundingClientRect(), g = m.getBoundingClientRect();
          let v = !1;
          if (L(s) > 1) {
            const { rowId: y } = tt(c);
            y !== void 0 && L(o)[y] && (v = !0);
          }
          let R = !1;
          !v && L(r) > 1 && L(i)[c] && (R = !0), !v && !R && t.set(c), e.set({
            left: _.left - g.left + f.offsetX,
            top: _.top - g.top + f.offsetY,
            visible: !0,
            multiRowMode: v,
            multiCellMode: R
          });
        },
        close: () => {
          e.update((c) => ({
            ...c,
            visible: !1
          }));
        }
      }
    }
  };
}, hs = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: ps,
  createStores: gs
}, Symbol.toStringTag, { value: "Module" })), ws = (n) => {
  const { scrolledRowCount: e, rows: t, visualRowCapacity: l } = n, o = me(t, (r) => r.length, 0), s = me(
    [e, o, l],
    ([r, u, a]) => Math.max(0, u - r - a)
  );
  me(
    [s, o],
    ([r, u]) => r < 25 && u
  ).subscribe((r) => {
    r && t.actions.loadNextPage();
  });
}, bs = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  initialise: ws
}, Symbol.toStringTag, { value: "Module" })), to = {
  sourceColumn: null,
  targetColumn: null,
  insertAfter: !1,
  breakpoints: [],
  gridLeft: 0,
  width: 0,
  increment: 0
}, ks = () => {
  const n = Me(to), e = me(
    n,
    (t) => !!t.sourceColumn,
    !1
  );
  return {
    reorder: n,
    isReordering: e
  };
}, Cs = (n) => {
  const {
    reorder: e,
    columns: t,
    columnLookupMap: l,
    scrollableColumns: o,
    scroll: s,
    bounds: i,
    visibleColumns: r,
    datasource: u,
    stickyWidth: a,
    width: c,
    scrollLeft: f,
    maxScrollLeft: d
  } = n;
  let m = 0, _, g;
  const v = (I, P) => {
    const T = L(o), H = L(i), z = L(a), Z = T.map((te) => ({
      x: te.__left - z,
      column: te.name,
      insertAfter: !1
    })), B = T[T.length - 1];
    B && Z.push({
      x: B.__left + B.width - z,
      column: B.name,
      insertAfter: !0
    }), e.set({
      sourceColumn: I,
      targetColumn: null,
      breakpoints: Z,
      gridLeft: H.left,
      width: H.width
    }), document.addEventListener("mousemove", R), document.addEventListener("mouseup", h), document.addEventListener("touchmove", R), document.addEventListener("touchend", h), document.addEventListener("touchcancel", h), R(P);
  }, R = (I) => {
    const { x: P } = Ct(I);
    m = P, b();
    const T = L(f), H = L(d), z = L(e), Z = Math.min(140, L(c) / 6), B = 16, te = Math.max(0, z.gridLeft + z.width - P), _e = Math.max(0, P - z.gridLeft);
    if (te < Z && T < H) {
      const fe = (Z - te) / Z * B;
      e.update((ae) => ({ ...ae, increment: fe })), y();
    } else if (_e < Z && T > 0) {
      const fe = -1 * (Z - _e) / Z * B;
      e.update((ae) => ({ ...ae, increment: fe })), y();
    } else
      k();
  }, b = () => {
    const I = L(e), P = L(f);
    let T, H = Number.MAX_SAFE_INTEGER;
    const z = m - I.gridLeft + P;
    I.breakpoints.forEach((Z) => {
      const B = Math.abs(Z.x - z);
      B < H && (H = B, T = Z);
    }), T && (T.column !== I.targetColumn || T.insertAfter !== I.insertAfter) && e.update((Z) => ({
      ...Z,
      targetColumn: T.column,
      insertAfter: T.insertAfter
    }));
  }, y = () => {
    g || (g = !0, _ = setInterval(() => {
      const I = L(d), { increment: P } = L(e);
      s.update((T) => ({
        ...T,
        left: Math.max(0, Math.min(I, T.left + P))
      })), b();
    }, 10));
  }, k = () => {
    g = !1, clearInterval(_);
  }, h = async () => {
    k(), document.removeEventListener("mousemove", R), document.removeEventListener("mouseup", h), document.removeEventListener("touchmove", R), document.removeEventListener("touchend", h), document.removeEventListener("touchcancel", h);
    const { sourceColumn: I, targetColumn: P, insertAfter: T } = L(e);
    e.set(to), I !== P && await C({
      sourceColumn: I,
      targetColumn: P,
      insertAfter: T
    });
  }, C = async ({
    sourceColumn: I,
    targetColumn: P,
    insertAfter: T = !1
  }) => {
    const H = L(t);
    let z = H.findIndex((B) => B.name === I), Z = H.findIndex((B) => B.name === P);
    T && Z++, t.update((B) => {
      const te = B.splice(z, 1);
      return --Z < z && Z++, B.toSpliced(Z, 0, te[0]);
    }), L(t).forEach((B, te) => {
      const { related: _e } = B, ie = { order: te };
      _e ? u.actions.addSubSchemaMutation(
        _e.subField,
        _e.field,
        ie
      ) : u.actions.addSchemaMutation(B.name, ie);
    }), await u.actions.saveSchemaMutations();
  };
  return {
    reorder: {
      ...e,
      actions: {
        startReordering: v,
        stopReordering: h,
        moveColumnLeft: async (I) => {
          var z;
          const P = L(r), H = L(l)[I].__idx;
          await C({
            sourceColumn: I,
            targetColumn: (z = P[H - 1]) == null ? void 0 : z.name
          });
        },
        moveColumnRight: async (I) => {
          var z;
          const P = L(r), H = L(l)[I].__idx;
          H !== P.length - 1 && await C({
            sourceColumn: I,
            targetColumn: (z = P[H + 1]) == null ? void 0 : z.name,
            insertAfter: !0
          });
        }
      }
    }
  };
}, Rs = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: Cs,
  createStores: ks
}, Symbol.toStringTag, { value: "Module" })), no = {
  initialMouseX: null,
  initialWidth: null,
  column: null,
  width: 0,
  left: 0
}, vs = () => {
  const n = Me(no), e = me(n, (t) => t.column != null, !1);
  return {
    resize: n,
    isResizing: e
  };
}, Ss = (n) => {
  const { resize: e, ui: t, datasource: l } = n, o = (u, a) => {
    const { x: c } = Ct(a);
    a.stopPropagation(), a.preventDefault(), t.actions.blur(), e.set({
      width: u.width,
      left: u.__left,
      initialWidth: u.width,
      initialMouseX: c,
      column: u.name,
      related: u.related
    }), document.addEventListener("mousemove", s), document.addEventListener("mouseup", i), document.addEventListener("touchmove", s), document.addEventListener("touchend", i), document.addEventListener("touchcancel", i);
  }, s = (u) => {
    const { initialMouseX: a, initialWidth: c, width: f, column: d, related: m } = L(e), { x: _ } = Ct(u), g = _ - a, v = Math.round(Math.max(Wl, c + g));
    Math.abs(f - v) < 5 || (m ? l.actions.addSubSchemaMutation(m.subField, m.field, {
      width: f
    }) : l.actions.addSchemaMutation(d, { width: f }), e.update((R) => ({
      ...R,
      width: v
    })));
  }, i = async () => {
    const u = L(e);
    e.set(no), document.removeEventListener("mousemove", s), document.removeEventListener("mouseup", i), document.removeEventListener("touchmove", s), document.removeEventListener("touchend", i), document.removeEventListener("touchcancel", i), u.width !== u.initialWidth && await l.actions.saveSchemaMutations();
  };
  return {
    resize: {
      ...e,
      actions: {
        startResizing: o,
        resetSize: async (u) => {
          l.actions.addSchemaMutation(u.name, {
            width: ql
          }), await l.actions.saveSchemaMutations();
        }
      }
    }
  };
}, ys = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: Ss,
  createStores: vs
}, Symbol.toStringTag, { value: "Module" })), Is = () => {
  const n = Me([]), e = Me(!1), t = Me(!1), l = Me(!1), o = Me({}), s = Me({}), i = Me(!1), r = Me(null), u = Me(!1), a = Me(null);
  let c = !1;
  return e.subscribe((f) => {
    f ? c = !0 : c && t.set(!0);
  }), {
    rows: n,
    fetch: a,
    loaded: t,
    refreshing: l,
    loading: e,
    rowChangeCache: o,
    inProgressChanges: s,
    hasNextPage: i,
    error: r,
    definitionMissing: u
  };
}, Ms = (n) => {
  const { rows: e, enrichedSchema: t } = n, l = me(
    [e, t],
    ([s, i]) => {
      const r = Object.values(i || {}), u = r.filter((c) => c.related), a = r.filter((c) => c.format);
      return s.map((c, f) => {
        const d = u.reduce(
          (_, g) => {
            const v = i[g.related.field];
            return _[g.name] = ao(
              c,
              { ...g, related: g.related },
              v
            ), _;
          },
          {}
        ), m = a.reduce(
          (_, g) => (_[g.name] = g.format(c), _),
          {}
        );
        return {
          ...c,
          ...d,
          __formatted: m,
          __idx: f
        };
      });
    }
  ), o = me(l, (s) => {
    let i = {};
    for (let r = 0; r < s.length; r++)
      i[s[r]._id] = s[r];
    return i;
  });
  return {
    rows: {
      ...e,
      subscribe: l.subscribe
    },
    rowLookupMap: o
  };
}, Es = (n) => {
  const {
    rows: e,
    rowLookupMap: t,
    definition: l,
    allFilters: o,
    loading: s,
    sort: i,
    datasource: r,
    API: u,
    scroll: a,
    validation: c,
    focusedCellId: f,
    columns: d,
    rowChangeCache: m,
    inProgressChanges: _,
    hasNextPage: g,
    error: v,
    definitionMissing: R,
    notifications: b,
    fetch: y,
    hasBudibaseIdentifiers: k,
    refreshing: h,
    columnLookupMap: C
  } = n, N = Me(!1);
  let S = {}, I = null, P = null;
  r.subscribe(async (F) => {
    if (I == null || I(), I = null, y.set(null), N.set(!1), s.set(!0), !r.actions.isDatasourceValid(F)) {
      v.set("Datasource is invalid");
      return;
    }
    await vt();
    const q = L(o), V = L(i), G = fo({
      API: u,
      datasource: F,
      options: {
        filter: q,
        sortColumn: V.column,
        sortOrder: V.order,
        limit: mo,
        paginate: !0,
        // Disable client side limiting, so that for queries and custom data
        // sources we don't impose fake row limits. We want all the data.
        clientSideLimiting: !1
      }
    });
    I = G.subscribe(async (O) => {
      if (O.error) {
        let se = "An unknown error occurred";
        O.error.status === 403 ? se = "You don't have access to this data" : O.error.status === 404 && O.error.url && O.error.url.includes("/api/tables/") || O.error.url.includes("/api/v2/views/") ? (R.set(!0), se = O.error.message) : O.error.message && (se = O.error.message), v.set(se);
      } else if (O.loaded && !O.loading) {
        v.set(null), g.set(O.hasNextPage);
        const se = L(N), ge = O.resetKey !== P, ue = P;
        P = O.resetKey, !se && ue && (e.set([]), await vt()), (!se || ge) && l.set(O.definition ?? null), se ? ge && a.update((D) => ({ ...D, top: 0 })) : (N.set(!0), a.set({ top: 0, left: 0 })), J(O.rows, ge), s.set(!1);
      }
      h.set(O.loading);
    }), y.set(G);
  });
  const T = (F, q) => {
    var G, O;
    let V;
    if (typeof q == "string" ? V = q : typeof (q == null ? void 0 : q.message) == "string" && (V = q.message), typeof q != "string" && !((G = q == null ? void 0 : q.json) != null && G.validationErrors) && V) {
      const { field: se } = tt(L(f));
      se && (q = {
        json: {
          validationErrors: {
            [se]: q.message
          }
        }
      });
    }
    if (typeof q != "string" && ((O = q == null ? void 0 : q.json) != null && O.validationErrors)) {
      const se = Object.keys(q.json.validationErrors), ge = L(d);
      let ue = [], D = [];
      for (let oe of se)
        r.actions.canUseColumn(oe) ? ue.push(oe) : D.push(oe);
      const { json: re } = q;
      for (let oe of ue) {
        let ye = re.validationErrors[oe];
        Array.isArray(ye) && (ye = ye[0]), (typeof ye != "string" || !ye.length) && (q = "Something went wrong"), c.actions.setError(
          xe(F, oe),
          _o(ye)
        );
        const Le = ge.findIndex((qe) => qe.name === oe);
        Le !== -1 && !ge[Le].visible && d.update((qe) => (qe[Le].visible = !0, qe.slice()));
      }
      for (let oe of D)
        L(b).error(`${oe} is required but is missing`);
    } else
      L(b).error(V || "An unknown error occurred");
  }, H = async ({
    row: F,
    idx: q,
    bubble: V = !1,
    notify: G = !0
  }) => {
    try {
      const O = await r.actions.addRow(F);
      return q != null ? (S[O._id] = !0, e.update((se) => (se.splice(q, 0, O), se.slice()))) : J([O]), G && L(b).success("Row created successfully"), O;
    } catch (O) {
      if (V)
        throw O;
      T(rt, O), c.actions.focusFirstRowError(rt);
    }
  }, z = async (F) => {
    let q = Q(F);
    delete q._id, delete q._rev;
    try {
      const V = await H({
        row: q,
        idx: F.__idx + 1,
        bubble: !0,
        notify: !1
      });
      return L(b).success("Duplicated 1 row"), V;
    } catch (V) {
      T(F._id, V), c.actions.focusFirstRowError(F._id);
    }
  }, Z = async (F, q) => {
    const V = L(t), G = F.map((re) => {
      var oe;
      return (oe = V[re._id]) == null ? void 0 : oe.__idx;
    }), O = Math.max(...G), se = F.length, ge = F.map((re) => {
      let oe = Q(re);
      return delete oe._id, delete oe._rev, oe;
    });
    let ue = [], D = 0;
    for (let re = 0; re < se; re++) {
      try {
        const oe = await r.actions.addRow(ge[re]);
        ue.push(oe), S[oe._id] = !0, await Mt(50);
      } catch (oe) {
        D++, console.error("Duplicating row failed", oe);
      }
      q == null || q((re + 1) / se);
    }
    return ue.length && e.update((re) => re.toSpliced(O + 1, 0, ...ue)), D ? L(b).error(`Failed to duplicate ${D} of ${se} rows`) : ue.length && L(b).success(`Duplicated ${ue.length} rows`), ue;
  }, B = (F, q) => {
    var se;
    const V = L(e), O = (se = L(t)[F]) == null ? void 0 : se.__idx;
    q ? O != null ? e.update((ge) => (ge[O] = { ...q }, ge)) : J([q]) : O != null && be([V[O]]);
  }, te = async (F) => {
    try {
      const q = await r.actions.getRow(F);
      B(F, q);
    } catch {
    }
  }, _e = async () => {
    var F;
    await ((F = L(y)) == null ? void 0 : F.getInitialData());
  }, ie = (F, q) => {
    const V = Object.keys(q || {});
    return !F || !V.length ? !1 : V.some((G) => F[G] !== q[G]);
  }, fe = (F, q) => {
    var se, ge;
    const V = L(t), G = L(C), O = V[F];
    for (let ue of Object.keys(q || {})) {
      const D = (ge = (se = G[ue]) == null ? void 0 : se.schema) == null ? void 0 : ge.type;
      (D === Qe.STRING || D == Qe.LONGFORM) && q[ue] != null && typeof q[ue] != "string" && (q[ue] = JSON.stringify(q[ue]));
    }
    return !O || !ie(O, q) ? !1 : (m.update((ue) => ({
      ...ue,
      [F]: {
        ...ue[F],
        ...q
      }
    })), !0);
  }, ae = async ({
    rowId: F,
    changes: q = null,
    updateState: V = !0,
    handleErrors: G = !0
  }) => {
    const se = L(t)[F];
    if (se == null)
      return;
    let ge;
    try {
      _.update((oe) => ({
        ...oe,
        [F]: (oe[F] || 0) + 1
      }));
      const ue = L(m)[F], D = { ...Q(se), ...ue, ...q };
      ge = await r.actions.updateRow(D), ge != null && ge._id ? V && e.update((oe) => (oe[se.__idx] = ge, oe.slice())) : ge != null && ge.id && await te(ge.id);
      const re = L(m)[F];
      m.update((oe) => (Object.keys(ue || {}).forEach((ye) => {
        ue[ye] === (re == null ? void 0 : re[ye]) && delete oe[F][ye];
      }), oe));
    } catch (ue) {
      G && (T(F, ue), c.actions.focusFirstRowError(F));
    }
    return _.update((ue) => ({
      ...ue,
      [F]: (ue[F] || 1) - 1
    })), ge;
  }, Re = async ({
    rowId: F,
    column: q,
    value: V,
    apply: G = !0
  }) => {
    fe(F, { [q]: V }) && G && await ae({ rowId: F });
  }, Ce = async (F, q) => {
    const V = Object.keys(F || {}), G = V.length;
    if (!G)
      return;
    const O = L(C);
    let se = [], ge = 0;
    for (let ue = 0; ue < G; ue++) {
      const D = V[ue];
      let re = F[D] || {};
      for (let oe of Object.keys(re)) {
        const ye = O[oe];
        d.actions.isReadonly(ye) && delete re[oe];
      }
      if (!Object.keys(re).length) {
        q == null || q((ue + 1) / G);
        continue;
      }
      try {
        const oe = await ae({
          rowId: D,
          changes: F[D],
          updateState: !1,
          handleErrors: !1
        });
        oe ? se.push(oe) : ge++, await Mt(50);
      } catch (oe) {
        ge++, console.error("Failed to update row", oe);
      }
      q == null || q((ue + 1) / G);
    }
    if (se.length) {
      const ue = L(t);
      e.update((D) => {
        for (let re of se) {
          const oe = ue[re._id].__idx;
          D[oe] = re;
        }
        return D.slice();
      });
    }
    if (ge) {
      const ue = `row${G === 1 ? "" : "s"}`;
      L(b).error(`Failed to update ${ge} of ${G} ${ue}`);
    } else if (se.length) {
      const ue = `row${se.length === 1 ? "" : "s"}`;
      L(b).success(`Updated ${se.length} ${ue}`);
    }
  }, ve = async (F) => {
    F != null && F.length && (F.forEach((q) => delete q.__idx), await r.actions.deleteRows(F), be(F));
  }, J = (F, q) => {
    var se;
    q && (S = {});
    let V = [], G;
    const O = L(k);
    for (let ge = 0; ge < F.length; ge++)
      G = F[ge], !O && !((se = G._id) != null && se.length) && (G._id = ms()), S[G._id] || (S[G._id] = !0, V.push(G));
    q ? e.set(V) : V.length && e.update((ge) => [...ge, ...V]);
  }, be = (F) => {
    const q = F.map((V) => V._id);
    e.update((V) => V.filter((G) => !q.includes(G._id)));
  }, j = () => {
    var F;
    (F = L(y)) == null || F.nextPage();
  }, Q = (F) => {
    let q = { ...F };
    return delete q.__idx, delete q.__metadata, delete q.__formatted, !L(k) && _s(q._id) && delete q._id, q;
  };
  return {
    rows: {
      ...e,
      actions: {
        addRow: H,
        duplicateRow: z,
        bulkDuplicate: Z,
        updateValue: Re,
        applyRowChanges: ae,
        deleteRows: ve,
        loadNextPage: j,
        refreshRow: te,
        replaceRow: B,
        refreshData: _e,
        cleanRow: Q,
        bulkUpdate: Ce
      }
    }
  };
}, As = (n) => {
  const {
    rowChangeCache: e,
    inProgressChanges: t,
    previousFocusedRowId: l,
    previousFocusedCellId: o,
    rows: s,
    validation: i
  } = n;
  l.subscribe((r) => {
    r && !L(t)[r] && Object.keys(L(e)[r] || {}).length && e.update((u) => (delete u[r], u));
  }), o.subscribe(async (r) => {
    if (!r)
      return;
    let { rowId: u, field: a } = tt(r);
    u = u, a = a;
    const c = a in (L(e)[u] || {}), f = i.actions.rowHasErrors(u), d = L(t)[u];
    u && !f && c && !d && await s.actions.applyRowChanges({ rowId: u });
  });
}, Ls = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: Es,
  createStores: Is,
  deriveStores: Ms,
  initialise: As
}, Symbol.toStringTag, { value: "Module" })), Ds = () => {
  const n = Me({
    left: 0,
    top: 0
  }), e = me(n, (l) => Math.round(l.top)), t = me(n, (l) => Math.round(l.left));
  return {
    scroll: n,
    scrollTop: e,
    scrollLeft: t
  };
}, Ns = (n) => {
  const {
    rows: e,
    visibleColumns: t,
    displayColumn: l,
    rowHeight: o,
    width: s,
    height: i,
    buttonColumnWidth: r,
    config: u
  } = n, a = me(l, (R) => ((R == null ? void 0 : R.width) || 0) + Rt), c = me(
    [t, r],
    ([R, b]) => {
      let y = Rt + Math.max(b, go);
      return R.forEach((k) => {
        y += k.width;
      }), y;
    }
  ), f = me(
    [s, a],
    ([R, b]) => R + b
  ), d = me(
    [c, f],
    ([R, b]) => Math.round(Math.max(R - b, 0))
  ), m = me(
    [c, f],
    ([R, b]) => R > b
  ), _ = me(
    [e, o, m, u],
    ([R, b, y, k]) => {
      let h = R.length * b + Kl;
      return y && (h += yt * 3), k.canAddRows && (h += b), h;
    }
  ), g = me(
    [i, _],
    ([R, b]) => Math.round(Math.max(b - R, 0))
  ), v = me(
    [_, i],
    ([R, b]) => R > b
  );
  return {
    stickyWidth: a,
    contentHeight: _,
    contentWidth: c,
    screenWidth: f,
    maxScrollTop: g,
    maxScrollLeft: d,
    showHScrollbar: m,
    showVScrollbar: v
  };
}, Os = (n) => {
  const {
    focusedCellId: e,
    focusedRow: t,
    scroll: l,
    bounds: o,
    rowHeight: s,
    stickyWidth: i,
    scrollTop: r,
    maxScrollTop: u,
    scrollLeft: a,
    maxScrollLeft: c,
    buttonColumnWidth: f,
    columnLookupMap: d
  } = n, m = me(
    [r, u],
    ([g, v]) => g > v,
    !1
  ), _ = me(
    [a, c],
    ([g, v]) => g > v,
    !1
  );
  m.subscribe((g) => {
    g && l.update((v) => ({
      ...v,
      top: L(u)
    }));
  }), _.subscribe((g) => {
    g && l.update((v) => ({
      ...v,
      left: L(c)
    }));
  }), e.subscribe(async (g) => {
    await vt();
    const v = L(t), R = L(l), b = L(o), y = L(s);
    if (v) {
      const S = v.__idx * y, I = R.top + b.height - y - Tt;
      let P = S - I;
      if (P > 0)
        l.update((T) => ({
          ...T,
          top: T.top + P
        }));
      else {
        const T = R.top - S + Tt;
        T > 0 && l.update((H) => ({
          ...H,
          top: Math.max(0, H.top - T)
        }));
      }
    }
    const { field: k } = tt(g), h = L(d)[k];
    if (!h || h.primaryDisplay)
      return;
    const C = L(i);
    let N = R.left - h.__left + Tt + C;
    if (N > 0)
      l.update((S) => ({
        ...S,
        left: Math.max(0, S.left - N)
      }));
    else {
      const S = L(f), I = h.__left + h.width, P = b.width + R.left - Tt - S;
      N = I - P - C, N > 0 && l.update((T) => ({
        ...T,
        left: T.left + N
      }));
    }
  });
}, Ts = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createStores: Ds,
  deriveStores: Ns,
  initialise: Os
}, Symbol.toStringTag, { value: "Module" })), zs = (n) => {
  const { props: e } = n, t = Me(null), l = Me(null), o = Me({}), s = Me(null), i = Me(L(e).fixedRowHeight || St), r = Me(null), u = Me(null), a = Me(!1), c = Me(!1), f = Me(!1), d = Me(0), m = Me({
    active: !1,
    sourceCellId: null,
    targetCellId: null
  });
  return {
    focusedCellId: t,
    focusedCellAPI: l,
    previousFocusedRowId: r,
    previousFocusedCellId: u,
    hoveredRowId: s,
    rowHeight: i,
    gridFocused: a,
    keyboardBlocked: c,
    isDragging: f,
    buttonColumnWidth: d,
    selectedRows: o,
    cellSelection: m
  };
}, Ps = (n) => {
  const {
    focusedCellId: e,
    rows: t,
    rowLookupMap: l,
    rowHeight: o,
    width: s,
    selectedRows: i,
    cellSelection: r,
    columnLookupMap: u,
    visibleColumns: a
  } = n, c = me(e, (y) => tt(y).rowId ?? null), f = me(
    [c, l],
    ([y, k]) => {
      if (y !== null)
        return y === rt ? { _id: rt } : k[y];
    }
  ), d = me(o, (y) => y >= po ? 3 : y >= ho ? 2 : 1), m = me(s, (y) => y < 600), _ = me(i, (y) => Object.keys(y).length), g = me(r, (y) => y.active), v = me(
    [r, l, u],
    ([y, k, h]) => {
      var ve, J;
      const { sourceCellId: C, targetCellId: N } = y;
      if (!C || !N || C === N)
        return [];
      const S = L(t), I = L(a), P = tt(C), T = tt(N);
      if (P.rowId === rt)
        return [];
      const H = (ve = k[P.rowId]) == null ? void 0 : ve.__idx, z = (J = k[T.rowId]) == null ? void 0 : J.__idx;
      if (H == null || z == null)
        return [];
      const Z = Math.min(H, z);
      let B = Math.max(H, z);
      B = Math.min(B, Z + 49);
      const te = h[P.field].__idx || 0, _e = h[T.field].__idx || 0, ie = Math.min(te, _e), fe = Math.max(te, _e);
      let ae = [], Re, Ce;
      for (let be = Z; be <= B; be++) {
        let j = [];
        for (let Q = ie; Q <= fe; Q++)
          Re = S[be]._id, Ce = I[Q].name, j.push(xe(Re, Ce));
        ae.push(j);
      }
      return ae;
    }
  ), R = me(v, (y) => {
    let k = {};
    for (let h of y)
      for (let C of h)
        k[C] = !0;
    return k;
  }), b = me(R, (y) => Object.keys(y).length);
  return {
    focusedRowId: c,
    focusedRow: f,
    contentLines: d,
    compact: m,
    selectedRowCount: _,
    isSelectingCells: g,
    selectedCells: v,
    selectedCellMap: R,
    selectedCellCount: b
  };
}, Hs = (n) => {
  const {
    focusedCellId: e,
    hoveredRowId: t,
    selectedRows: l,
    rowLookupMap: o,
    rows: s,
    selectedRowCount: i,
    cellSelection: r,
    selectedCells: u
  } = n;
  let a = null;
  const c = () => {
    e.set(null), t.set(null), R();
  }, f = (b) => {
    l.update((y) => {
      let k = {
        ...y,
        [b]: !y[b]
      };
      return k[b] ? a = L(o)[b].__idx : delete k[b], k;
    });
  }, d = (b) => {
    if (!L(i)) {
      f(b);
      return;
    }
    if (a == null)
      return;
    const y = L(o)[b].__idx;
    if (a === y)
      return;
    const k = Math.min(a, y), h = Math.max(a, y), C = L(s);
    l.update((N) => {
      for (let S = k; S <= h; S++)
        N[C[S]._id] = !0;
      return N;
    });
  }, m = (b) => {
    r.set({
      active: !0,
      sourceCellId: b,
      targetCellId: b
    });
  }, _ = (b) => {
    r.update((y) => ({
      ...y,
      targetCellId: b
    }));
  }, g = () => {
    r.update((b) => ({
      ...b,
      active: !1
    }));
  }, v = (b, y) => {
    r.set({
      active: !1,
      sourceCellId: b,
      targetCellId: y
    });
  }, R = () => {
    r.set({
      active: !1,
      sourceCellId: null,
      targetCellId: null
    });
  };
  return {
    ui: {
      actions: {
        blur: c
      }
    },
    selectedRows: {
      ...l,
      actions: {
        toggleRow: f,
        bulkSelectRows: d
      }
    },
    selectedCells: {
      ...u,
      actions: {
        startSelecting: m,
        updateTarget: _,
        stopSelecting: g,
        selectRange: v,
        clear: R
      }
    }
  };
}, Fs = (n) => {
  const {
    focusedRowId: e,
    previousFocusedRowId: t,
    previousFocusedCellId: l,
    rowLookupMap: o,
    focusedCellId: s,
    selectedRows: i,
    hoveredRowId: r,
    definition: u,
    rowHeight: a,
    fixedRowHeight: c,
    selectedRowCount: f,
    menu: d,
    selectedCellCount: m,
    selectedCells: _,
    cellSelection: g
  } = n;
  o.subscribe(async (b) => {
    await vt();
    const y = L(e), k = L(i), h = L(r), C = (S) => b[S] != null;
    y && !C(y) && s.set(null), h && !C(h) && r.set(null);
    const N = Object.keys(k);
    if (N.length) {
      let S = { ...k }, I = !1;
      for (let P = 0; P < N.length; P++)
        C(N[P]) || (delete S[N[P]], I = !0);
      I && i.set(S);
    }
  });
  let v = null;
  e.subscribe((b) => {
    t.set(v), v = b;
  });
  let R = null;
  s.subscribe((b) => {
    l.set(R), R = b, b && L(r) && r.set(null), b && L(f) && i.set({}), b && L(m) && _.actions.clear(), d.actions.close();
  }), u.subscribe((b) => {
    L(c) || a.set((b == null ? void 0 : b.rowHeight) || St);
  }), c.subscribe((b) => {
    var y;
    b ? a.set(b) : a.set(((y = L(u)) == null ? void 0 : y.rowHeight) || St);
  }), f.subscribe((b) => {
    b && (L(s) && s.set(null), L(m) && _.actions.clear());
  }), m.subscribe((b) => {
    b && L(f) && i.set({});
  }), g.subscribe(async ({ sourceCellId: b, targetCellId: y }) => {
    b && b !== y && L(s) !== b && s.set(b);
  });
}, Bs = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: Hs,
  createStores: zs,
  deriveStores: Ps,
  initialise: Fs
}, Symbol.toStringTag, { value: "Module" })), js = () => {
  const n = Me([]), e = me(n, (t) => t.map((l) => ({
    ...l,
    color: wo(l),
    label: bo(l)
  })));
  return {
    users: {
      ...n,
      subscribe: e.subscribe
    }
  };
}, Vs = (n) => {
  const { users: e, focusedCellId: t } = n;
  return {
    userCellMap: me(
      [e, t],
      ([o, s]) => {
        let i = {};
        return o.forEach((r) => {
          var a;
          const u = (a = r.gridMetadata) == null ? void 0 : a.focusedCellId;
          u && u !== s && (i[u] = r);
        }), i;
      }
    )
  };
}, Us = (n) => {
  const { users: e } = n;
  return {
    users: {
      ...e,
      actions: {
        updateUser: (o) => {
          const s = L(e);
          s.some((i) => i.sessionId === o.sessionId) ? e.update((i) => {
            const r = i.findIndex((u) => u.sessionId === o.sessionId);
            return i[r] = o, i.slice();
          }) : e.set([...s, o]);
        },
        removeUser: (o) => {
          e.update((s) => s.filter((i) => i.sessionId !== o));
        }
      }
    }
  };
}, qs = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: Us,
  createStores: js,
  deriveStores: Vs
}, Symbol.toStringTag, { value: "Module" })), Gs = () => ({
  validation: Me({})
}), Ws = (n) => {
  const { validation: e } = n;
  return {
    validationRowLookupMap: me(e, (l) => {
      const o = {};
      return Object.entries(l).forEach(([s, i]) => {
        if (i) {
          const { rowId: r } = tt(s);
          r !== void 0 && (o[r] || (o[r] = []), o[r].push(s));
        }
      }), o;
    })
  };
}, Ks = (n) => {
  const { validation: e, focusedCellId: t, validationRowLookupMap: l } = n;
  return {
    validation: {
      ...e,
      actions: {
        setError: (r, u) => {
          r && e.update((a) => ({
            ...a,
            [r]: u
          }));
        },
        rowHasErrors: (r) => {
          var u;
          return ((u = L(l)[r]) == null ? void 0 : u.length) > 0;
        },
        focusFirstRowError: (r) => {
          const u = L(l)[r], a = u == null ? void 0 : u[0];
          a && t.set(a);
        }
      }
    }
  };
}, Xs = (n) => {
  const { validation: e, previousFocusedRowId: t, validationRowLookupMap: l } = n;
  t.subscribe((o) => {
    if (o) {
      const s = L(l)[o];
      s != null && s.length && e.update((i) => {
        for (let r of s)
          delete i[r];
        return i;
      });
    }
  });
}, Ys = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: Ks,
  createStores: Gs,
  deriveStores: Ws,
  initialise: Xs
}, Symbol.toStringTag, { value: "Module" })), Js = (n) => {
  const {
    rowHeight: e,
    scrollableColumns: t,
    rows: l,
    scrollTop: o,
    scrollLeft: s,
    width: i,
    height: r,
    rowChangeCache: u,
    metadata: a
  } = n, c = me(
    [o, e],
    ([g, v]) => Math.floor(g / v)
  ), f = me(
    [r, e],
    ([g, v]) => Math.ceil(g / v) + 1
  ), d = me(
    [l, c, f, u, a],
    ([
      g,
      v,
      R,
      b,
      y
    ]) => g.slice(v, v + R).map((k) => ({
      ...k,
      ...b[k._id],
      __metadata: y[k._id]
    }))
  ), m = me(s, (g) => {
    const v = Wl;
    return Math.round(g / v) * v;
  }), _ = me(
    [t, m, i],
    ([g, v, R]) => {
      if (!g.length)
        return {};
      let b = 0, y = g[0].width;
      for (; y < v && b < g.length - 1; )
        b++, y += g[b].width;
      let k = b + 1, h = y;
      for (; h < R + v && k < g.length; )
        h += g[k].width, k++;
      let C = {};
      return g.slice(Math.max(0, b), k).forEach((N) => {
        C[N.name] = !0;
      }), C;
    }
  );
  return {
    scrolledRowCount: c,
    visualRowCapacity: f,
    renderedRows: d,
    columnRenderMap: _
  };
}, Qs = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  deriveStores: Js
}, Symbol.toStringTag, { value: "Module" })), Zs = (n) => {
  var l;
  let e;
  if ((l = n == null ? void 0 : n.externalClipboard) != null && l.clipboard) {
    const o = n.externalClipboard.clipboard.get();
    o.multiCellCopy ? e = {
      value: o.value,
      multiCellCopy: !0
    } : e = {
      value: o.value,
      multiCellCopy: !1
    };
  } else
    e = {
      value: void 0,
      multiCellCopy: !1
    };
  return {
    clipboard: Me(e)
  };
}, $s = (n) => {
  const {
    clipboard: e,
    focusedCellAPI: t,
    selectedCellCount: l,
    config: o,
    focusedRowId: s,
    props: i
  } = n, r = me(t, (a) => a != null), u = me(
    [e, t, l, o, s, i],
    ([
      a,
      c,
      f,
      d,
      m,
      _
    ]) => {
      var R;
      let g = a.value != null;
      if (!g && ((R = _.externalClipboard) != null && R.clipboard) && (g = _.externalClipboard.clipboard.get().value != null), !g || !d.canEditRows || !c || m === rt)
        return !1;
      const v = f > 1;
      return !(!a.multiCellCopy && !v && c.isReadonly());
    }
  );
  return {
    copyAllowed: r,
    pasteAllowed: u
  };
}, xs = (n) => {
  const {
    clipboard: e,
    focusedCellAPI: t,
    copyAllowed: l,
    pasteAllowed: o,
    selectedCells: s,
    selectedCellCount: i,
    rowLookupMap: r,
    rowChangeCache: u,
    rows: a,
    focusedCellId: c,
    columnLookupMap: f,
    visibleColumns: d,
    props: m
  } = n, _ = () => {
    if (!L(l))
      return;
    const R = L(s), b = L(t), k = L(i) > 1;
    if (k) {
      const h = L(r), C = L(u), N = [];
      for (const I of R) {
        const P = [];
        for (const T of I) {
          const { rowId: H = "", field: z = "" } = tt(T), Z = {
            ...h[H],
            ...C[H]
          };
          P.push(Z[z]);
        }
        N.push(P);
      }
      e.set({
        value: N,
        multiCellCopy: !0
      });
      const { externalClipboard: S } = L(m);
      S != null && S.onCopy && S.onCopy({
        value: N,
        multiCellCopy: !0,
        tableId: S.tableId,
        viewId: S.viewId
      });
    } else {
      const h = b == null ? void 0 : b.getValue();
      e.set({
        value: h,
        multiCellCopy: k
      });
      const { externalClipboard: C } = L(m);
      C != null && C.onCopy && C.onCopy({
        value: h,
        multiCellCopy: !1,
        tableId: C.tableId,
        viewId: C.viewId
      });
      let N = "";
      h != null && h !== "" && (N = typeof h == "object" ? JSON.stringify(h) : h), Xl(N);
    }
  }, g = async (R) => {
    var N, S;
    if (!L(o))
      return;
    const { externalClipboard: b } = L(m);
    let y = L(e);
    if (b != null && b.clipboard) {
      const I = b.clipboard.get();
      I.value !== void 0 && (I.multiCellCopy ? y = {
        value: I.value,
        multiCellCopy: !0
      } : y = {
        value: I.value,
        multiCellCopy: !1
      });
    }
    const { value: k, multiCellCopy: h } = y, C = L(i) > 1;
    if (h)
      if (C) {
        let I = k;
        const P = L(s), T = P.length, H = P[0].length, z = k.length, Z = k[0].length;
        if (T > z && H === Z) {
          I = [];
          for (let B = 0; B < T; B++)
            I.push(k[B % z]);
        }
        await v(I, R);
      } else {
        const I = L(c), { rowId: P, field: T } = tt(I), H = L(r), z = L(f), Z = H[P].__idx, B = z[T].__idx || 0, te = L(a), _e = L(d), ie = _e.length, fe = te.length, ae = k.length, Re = k[0].length, Ce = Math.min(ae, fe - Z) - 1, ve = Math.min(Re, ie - B) - 1, J = te[Z + Ce]._id, be = _e[B + ve].name, j = xe(J, be);
        j === I ? (N = L(t)) == null || N.setValue(k[0][0]) : (s.actions.selectRange(I, j), await v(k, R));
      }
    else if (C) {
      const I = L(s).map((P) => P.map(() => k));
      await v(I, R);
    } else
      (S = L(t)) == null || S.setValue(k ?? null);
  }, v = async (R, b) => {
    const y = L(s), k = Math.min(R.length, y.length), h = Math.min(R[0].length, y[0].length);
    let C = {};
    for (let N = 0; N < k; N++)
      for (let S = 0; S < h; S++) {
        const I = y[N][S];
        let { rowId: P, field: T } = tt(I);
        P = P, T = T, C[P] || (C[P] = {}), C[P][T] = R[N][S];
      }
    await a.actions.bulkUpdate(C, b);
  };
  return {
    clipboard: {
      ...e,
      actions: {
        copy: _,
        paste: g
      }
    }
  };
}, er = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: xs,
  createStores: Zs,
  deriveStores: $s
}, Symbol.toStringTag, { value: "Module" })), tr = (n) => {
  const { props: e } = n, t = (f) => ko(e, (d) => d[f]), l = t("datasource"), o = t("initialSortColumn"), s = t("initialSortOrder"), i = t("initialFilter"), r = t("fixedRowHeight"), u = t("schemaOverrides"), a = t("notifySuccess"), c = t("notifyError");
  return {
    datasource: l,
    initialSortColumn: o,
    initialSortOrder: s,
    initialFilter: i,
    fixedRowHeight: r,
    schemaOverrides: u,
    notifySuccess: a,
    notifyError: c
  };
}, nr = (n) => {
  const { props: e, definition: t, hasNonAutoColumn: l } = n;
  return {
    config: me(
      [e, t, l],
      ([s, i, r]) => {
        var c;
        let u = { ...s, canSelectRows: !1 };
        const a = (c = s.datasource) == null ? void 0 : c.type;
        return a === "viewV2" && (u.canEditColumns = !1, (i == null ? void 0 : i.type) === Yl.CALCULATION && (u.canAddRows = !1, u.canEditRows = !1, u.canDeleteRows = !1, u.canExpandRows = !1)), r || (u.canAddRows = !1), a && !["table", "viewV2"].includes(a) && (u.canAddRows = !1, u.canEditRows = !1, u.canDeleteRows = !1, u.canExpandRows = !1, u.canSaveSchema = !1, u.canEditColumns = !1), u.canSelectRows = !0, u;
      }
    )
  };
}, lr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createStores: tr,
  deriveStores: nr
}, Symbol.toStringTag, { value: "Module" })), or = (n) => {
  const { props: e } = n, t = L(e);
  return {
    sort: It({
      column: t.initialSortColumn,
      order: t.initialSortOrder || Ge.ASCENDING
    })
  };
}, sr = (n) => {
  const { sort: e, initialSortColumn: t, initialSortOrder: l, schema: o } = n;
  t.subscribe((i) => {
    e.update((r) => ({ ...r, column: i }));
  }), l.subscribe((i) => {
    e.update((r) => ({
      ...r,
      order: i || Ge.ASCENDING
    }));
  }), me([e, o], ([i, r]) => !(i != null && i.column) || !r ? !0 : r[i.column] != null).subscribe((i) => {
    i || e.set({
      column: null,
      order: Ge.ASCENDING
    });
  });
}, rr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createStores: or,
  initialise: sr
}, Symbol.toStringTag, { value: "Module" })), ir = (n) => {
  const { props: e } = n, t = It(L(e).initialFilter ?? void 0), l = It([]);
  return {
    filter: t,
    inlineFilters: l
  };
}, ur = (n) => {
  const { filter: e, inlineFilters: t } = n;
  return {
    allFilters: me(
      [e, t],
      ([o, s]) => {
        var r;
        if (!(s != null && s.length))
          return o;
        const i = {
          logicalOperator: Qt.ALL,
          groups: [
            {
              logicalOperator: Qt.ALL,
              filters: s
            }
          ]
        };
        return (r = o == null ? void 0 : o.groups) != null && r.length && (i.groups = [...i.groups, ...o.groups]), i;
      }
    )
  };
}, cr = (n) => {
  const { filter: e, inlineFilters: t } = n;
  return {
    filter: {
      ...e,
      actions: {
        addInlineFilter: (o, s) => {
          const i = `inline-${o.name}`, r = o.schema.type, u = {
            field: o.name,
            id: i,
            operator: Kt.STRING,
            valueType: "value",
            type: r,
            value: s
          };
          r === Qe.NUMBER ? (u.value = parseFloat(s), u.operator = Kt.EQUAL) : r === Qe.BIGINT ? u.operator = Kt.EQUAL : r === Qe.ARRAY && (u.operator = Co.CONTAINS), t.update((a) => (a = a == null ? void 0 : a.filter((c) => c.id !== i), s && a.push(u), a));
        }
      }
    }
  };
}, ar = (n) => {
  const { filter: e, initialFilter: t } = n;
  t.subscribe(
    (l) => e.set(l ?? void 0)
  );
}, fr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: cr,
  createStores: ir,
  deriveStores: ur,
  initialise: ar
}, Symbol.toStringTag, { value: "Module" })), dr = (n) => {
  const { notifySuccess: e, notifyError: t } = n;
  return {
    notifications: me(
      [e, t],
      ([o, s]) => ({
        success: o || Ft.success,
        error: s || Ft.error
      })
    )
  };
}, mr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createStores: dr
}, Symbol.toStringTag, { value: "Module" })), _r = () => {
  const n = It(null), e = It({}), t = It({});
  return {
    definition: n,
    schemaMutations: e,
    subSchemaMutations: t
  };
}, gr = (n) => {
  const {
    API: e,
    definition: t,
    schemaOverrides: l,
    datasource: o,
    schemaMutations: s,
    subSchemaMutations: i
  } = n, r = me(t, (c) => {
    const f = Ro({
      API: e,
      datasource: L(o),
      definition: c ?? void 0
    });
    return f ? (Object.keys(f).forEach((d) => {
      typeof f[d] != "object" && (f[d] = { name: d, type: f[d] });
    }), f) : null;
  }), u = me(
    [r, l, s, i],
    ([c, f, d, m]) => {
      if (!c)
        return null;
      const _ = vo(c), g = {};
      return Object.keys(_ || {}).forEach((v) => {
        var R;
        if (g[v] = {
          ..._ == null ? void 0 : _[v],
          ...f == null ? void 0 : f[v],
          ...d[v]
        }, m[v]) {
          (R = g[v]).columns ?? (R.columns = {});
          for (const b of Object.keys(m[v])) {
            const y = m[v][b];
            g[v].columns[b] = {
              ...g[v].columns[b],
              ...y
            };
          }
        }
      }), g;
    }
  ), a = me(
    [o, t],
    ([c, f]) => {
      var m, _;
      let d = c == null ? void 0 : c.type;
      return d === "provider" && (d = (_ = (m = c.value) == null ? void 0 : m.datasource) == null ? void 0 : _.type), d === "viewV2" && f && "type" in f && f.type === Yl.CALCULATION ? !1 : !!d && ["table", "viewV2", "link"].includes(d);
    }
  );
  return {
    schema: r,
    enrichedSchema: u,
    hasBudibaseIdentifiers: a
  };
}, pr = (n) => {
  const {
    API: e,
    datasource: t,
    definition: l,
    config: o,
    dispatch: s,
    table: i,
    viewV2: r,
    nonPlus: u,
    schemaMutations: a,
    subSchemaMutations: c,
    schema: f,
    notifications: d
  } = n, m = () => {
    const T = L(t), H = T == null ? void 0 : T.type;
    if (!H)
      return null;
    switch (H) {
      case "table":
        return i;
      case "viewV2":
        return r;
      default:
        return u;
    }
  }, _ = async () => {
    const T = await So({
      API: e,
      datasource: L(t)
    });
    l.set(T ?? null);
  }, g = async (T) => {
    var z;
    const H = L(l);
    if (l.set(T), L(o).canSaveSchema)
      try {
        await ((z = m()) == null ? void 0 : z.actions.saveDefinition(T)), s("updatedatasource", T);
      } catch (Z) {
        const B = (Z == null ? void 0 : Z.message) || Z || "Unknown error";
        L(d).error(`Error saving schema: ${B}`), l.set(H);
      }
  }, v = async (T) => {
    let H = yo(L(l));
    return H.primaryDisplay = T, H.schema && (H.schema[T].constraints || (H.schema[T].constraints = {}), H.schema[T].constraints.presence = { allowEmpty: !1 }, "default" in H.schema[T] && delete H.schema[T].default), await g(H);
  }, R = (T, H) => {
    !T || !H || a.update((z) => ({
      ...z,
      [T]: {
        ...z[T],
        ...H
      }
    }));
  }, b = (T, H, z) => {
    !T || !H || !z || c.update((Z) => ({
      ...Z,
      [H]: {
        ...Z[H],
        [T]: {
          ...(Z[H] || {})[T],
          ...z
        }
      }
    }));
  }, y = async () => {
    if (!L(o).canSaveSchema)
      return;
    const T = L(l), H = L(a), z = L(c), Z = L(f) || {};
    let B = {};
    Object.keys(Z).forEach((te) => {
      var _e;
      if (B[te] = {
        ...Z[te],
        ...H[te]
      }, z[te]) {
        (_e = B[te]).columns ?? (_e.columns = {});
        for (const ie of Object.keys(z[te])) {
          const fe = z[te][ie];
          B[te].columns[ie] = {
            ...B[te].columns[ie],
            ...fe
          };
        }
      }
    }), await g({
      ...T,
      schema: B
    }), k();
  }, k = () => {
    a.set({}), c.set({});
  };
  return {
    datasource: {
      ...t,
      actions: {
        refreshDefinition: _,
        saveDefinition: g,
        addRow: async (T) => {
          var H;
          return await ((H = m()) == null ? void 0 : H.actions.addRow(T));
        },
        updateRow: async (T) => {
          var H;
          return await ((H = m()) == null ? void 0 : H.actions.updateRow(T));
        },
        deleteRows: async (T) => {
          var H;
          return await ((H = m()) == null ? void 0 : H.actions.deleteRows(T));
        },
        getRow: async (T) => {
          var H;
          return await ((H = m()) == null ? void 0 : H.actions.getRow(T));
        },
        isDatasourceValid: (T) => {
          var H;
          return (H = m()) == null ? void 0 : H.actions.isDatasourceValid(T);
        },
        canUseColumn: (T) => {
          var H;
          return (H = m()) == null ? void 0 : H.actions.canUseColumn(T);
        },
        changePrimaryDisplay: v,
        addSchemaMutation: R,
        addSubSchemaMutation: b,
        saveSchemaMutations: y,
        resetSchemaMutations: k
      }
    }
  };
}, hr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: pr,
  createStores: _r,
  deriveStores: gr
}, Symbol.toStringTag, { value: "Module" })), wr = !0, br = (n) => {
  const { API: e, datasource: t, columns: l } = n, o = async (c) => {
    await e.saveTable(c);
  }, s = async (c) => {
    var d;
    c = {
      ...c,
      tableId: (d = L(t)) == null ? void 0 : d.tableId
    };
    const f = await e.saveRow(c, wr);
    return { ...f, _id: f._id };
  };
  return {
    table: {
      actions: {
        saveDefinition: o,
        addRow: s,
        updateRow: s,
        deleteRows: async (c) => {
          await e.deleteRows(L(t).tableId, c);
        },
        getRow: async (c) => {
          var m;
          const f = await e.searchTable(L(t).tableId, {
            limit: 1,
            query: {
              equal: {
                _id: c
              }
            },
            paginate: !1
          }), d = (m = f == null ? void 0 : f.rows) == null ? void 0 : m[0];
          if (d)
            return { ...d, _id: d._id };
        },
        isDatasourceValid: (c) => (c == null ? void 0 : c.type) === "table" && !!(c != null && c.tableId),
        canUseColumn: (c) => L(l).some((f) => f.name === c)
      }
    }
  };
}, kr = (n) => {
  const {
    datasource: e,
    fetch: t,
    filter: l,
    inlineFilters: o,
    allFilters: s,
    sort: i,
    table: r,
    initialFilter: u,
    initialSortColumn: a,
    initialSortOrder: c
  } = n;
  let f = [];
  e.subscribe((d) => {
    f == null || f.forEach((m) => m()), f = [], r.actions.isDatasourceValid(d) && (l.set(L(u) ?? void 0), o.set([]), i.set({
      column: L(a),
      order: L(c) || Ge.ASCENDING
    }), f.push(
      s.subscribe((m) => {
        var g, v;
        const _ = L(t);
        ((v = (g = _ == null ? void 0 : _.options) == null ? void 0 : g.datasource) == null ? void 0 : v.tableId) === d.tableId && _.update({
          filter: m
        });
      })
    ), f.push(
      i.subscribe((m) => {
        var g, v;
        const _ = L(t);
        ((v = (g = _ == null ? void 0 : _.options) == null ? void 0 : g.datasource) == null ? void 0 : v.tableId) === d.tableId && _.update({
          sortOrder: m.order || Ge.ASCENDING,
          sortColumn: m.column ?? void 0
        });
      })
    ));
  });
}, Cr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: br,
  initialise: kr
}, Symbol.toStringTag, { value: "Module" })), Rr = !0, vr = (n) => {
  const { API: e, datasource: t, columns: l } = n, o = async (c) => {
    await e.viewV2.update(c);
  }, s = async (c) => {
    const f = L(t);
    c = {
      ...c,
      tableId: f == null ? void 0 : f.tableId,
      _viewId: f == null ? void 0 : f.id
    };
    const d = await e.saveRow(c, Rr);
    return {
      ...d,
      _id: d._id,
      _viewId: c._viewId
    };
  };
  return {
    viewV2: {
      actions: {
        saveDefinition: o,
        addRow: s,
        updateRow: s,
        deleteRows: async (c) => {
          await e.deleteRows(L(t).id, c);
        },
        getRow: async (c) => {
          var m;
          const f = await e.viewV2.fetch(L(t).id, {
            limit: 1,
            query: {
              equal: {
                _id: c
              }
            },
            paginate: !1
          }), d = (m = f == null ? void 0 : f.rows) == null ? void 0 : m[0];
          if (d)
            return { ...d, _id: d._id };
        },
        isDatasourceValid: (c) => (c == null ? void 0 : c.type) === "viewV2" && !!(c != null && c.id) && !!(c != null && c.tableId),
        canUseColumn: (c) => L(l).some((f) => f.name === c && f.visible)
      }
    }
  };
}, Sr = (n) => {
  const {
    definition: e,
    datasource: t,
    sort: l,
    rows: o,
    filter: s,
    inlineFilters: i,
    allFilters: r,
    subscribe: u,
    viewV2: a,
    initialFilter: c,
    initialSortColumn: f,
    initialSortOrder: d,
    config: m,
    fetch: _
  } = n;
  let g = [];
  t.subscribe((v) => {
    if (g == null || g.forEach((b) => b()), g = [], !a.actions.isDatasourceValid(v))
      return;
    s.set(L(c) ?? void 0), i.set([]), l.set({
      column: L(f),
      order: L(d) || Ge.ASCENDING
    }), g.push(
      e.subscribe((b) => {
        var y, k;
        L(m).canSaveSchema && (!b || !("id" in b) || (b == null ? void 0 : b.id) === v.id && (L(f) || l.set({
          column: (y = b.sort) == null ? void 0 : y.field,
          order: ((k = b.sort) == null ? void 0 : k.order) || Ge.ASCENDING
        }), L(c) || s.set(b.queryUI)));
      })
    );
    function R(b, y) {
      const k = b.column ?? null, h = (y == null ? void 0 : y.field) ?? null;
      if (k !== h)
        return !0;
      if (!k)
        return !1;
      const C = b.order ?? null, N = (y == null ? void 0 : y.order) ?? null;
      return C !== N;
    }
    g.push(
      l.subscribe(async (b) => {
        var h, C;
        const y = L(e);
        if (!y || !("id" in y) || (y == null ? void 0 : y.id) !== v.id || !R(b, y.sort))
          return;
        L(m).canSaveSchema && await t.actions.saveDefinition({
          ...y,
          sort: {
            field: b.column,
            order: b.order || Ge.ASCENDING
          }
        });
        const k = L(_);
        ((C = (h = k == null ? void 0 : k.options) == null ? void 0 : h.datasource) == null ? void 0 : C.id) === v.id && k.update({
          sortOrder: b.order,
          sortColumn: b.column ?? void 0
        });
      })
    ), g == null || g.push(
      s.subscribe(async (b) => {
        if (!L(m).canSaveSchema)
          return;
        const y = L(e);
        !y || !("id" in y) || (y == null ? void 0 : y.id) === v.id && JSON.stringify(b) !== JSON.stringify(y.queryUI) && (await t.actions.saveDefinition({
          ...y,
          queryUI: b
        }), await o.actions.refreshData());
      })
    ), g.push(
      i.subscribe((b) => {
        var k, h;
        if (!L(m).canSaveSchema)
          return;
        const y = L(_);
        ((h = (k = y == null ? void 0 : y.options) == null ? void 0 : k.datasource) == null ? void 0 : h.id) === v.id && y.update({
          filter: b
        });
      })
    ), g.push(
      r.subscribe((b) => {
        var k, h;
        if (L(m).canSaveSchema)
          return;
        const y = L(_);
        ((h = (k = y == null ? void 0 : y.options) == null ? void 0 : k.datasource) == null ? void 0 : h.id) === v.id && y.update({
          filter: b
        });
      })
    ), g.push(
      u("show-column", async () => {
        await o.actions.refreshData();
      })
    );
  });
}, yr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: vr,
  initialise: Sr
}, Symbol.toStringTag, { value: "Module" })), Ir = (n) => {
  const { columns: e, table: t, viewV2: l } = n, o = async () => {
    throw "This datasource does not support updating the definition";
  }, s = async () => {
    throw "This datasource does not support saving rows";
  };
  return {
    nonPlus: {
      actions: {
        saveDefinition: o,
        addRow: s,
        updateRow: s,
        deleteRows: async () => {
          throw "This datasource does not support deleting rows";
        },
        getRow: () => {
          throw "This datasource does not support fetching individual rows";
        },
        isDatasourceValid: (c) => !t.actions.isDatasourceValid(c) && !l.actions.isDatasourceValid(c) && (c == null ? void 0 : c.type) != null,
        canUseColumn: (c) => L(e).some((f) => f.name === c)
      }
    }
  };
}, wn = (n, e) => JSON.stringify(n) === JSON.stringify(e), Mr = (n) => {
  const {
    datasource: e,
    sort: t,
    filter: l,
    inlineFilters: o,
    allFilters: s,
    nonPlus: i,
    initialFilter: r,
    initialSortColumn: u,
    initialSortOrder: a,
    fetch: c
  } = n;
  let f = [];
  e.subscribe((d) => {
    f == null || f.forEach((m) => m()), f = [], i.actions.isDatasourceValid(d) && (l.set(L(r) ?? void 0), o.set([]), t.set({
      column: L(u),
      order: L(a) || Ge.ASCENDING
    }), f.push(
      s.subscribe((m) => {
        var g;
        const _ = L(c);
        wn((g = _ == null ? void 0 : _.options) == null ? void 0 : g.datasource, d) && (_ == null || _.update({
          filter: m
        }));
      })
    ), f.push(
      t.subscribe((m) => {
        var g;
        const _ = L(c);
        wn((g = _ == null ? void 0 : _.options) == null ? void 0 : g.datasource, d) && (_ == null || _.update({
          sortOrder: m.order || Ge.ASCENDING,
          sortColumn: m.column ?? void 0
        }));
      })
    ));
  });
}, Er = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: Ir,
  initialise: Mr
}, Symbol.toStringTag, { value: "Module" })), Ar = (n) => {
  const { API: e } = n;
  let t = {};
  const l = () => {
    t = {};
  }, o = async (r) => (t[r] || (t[r] = e.fetchTableDefinition(r)), await t[r]);
  return {
    cache: {
      actions: {
        getPrimaryDisplayForTableId: async (r) => {
          var c, f;
          const u = await o(r);
          return (u == null ? void 0 : u.primaryDisplay) || ((f = (c = u == null ? void 0 : u.schema) == null ? void 0 : c[0]) == null ? void 0 : f.name);
        },
        getTable: async (r) => await o(r),
        resetCache: l
      }
    }
  };
}, Lr = (n) => {
  const { datasource: e, cache: t } = n;
  e.subscribe(t.actions.resetCache);
}, Dr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createActions: Ar,
  initialise: Lr
}, Symbol.toStringTag, { value: "Module" })), Pt = [
  rr,
  fr,
  is,
  Cr,
  yr,
  Er,
  hr,
  ds,
  lr,
  Ts,
  Ys,
  Ls,
  Io,
  Bs,
  ys,
  Qs,
  Rs,
  qs,
  hs,
  bs,
  er,
  mr,
  Dr
], Nr = (n) => {
  var e, t, l, o;
  for (let s of Pt)
    "createStores" in s && (n = { ...n, ...(e = s.createStores) == null ? void 0 : e.call(s, n) });
  for (let s of Pt)
    "deriveStores" in s && (n = { ...n, ...(t = s.deriveStores) == null ? void 0 : t.call(s, n) });
  for (let s of Pt)
    "createActions" in s && (n = { ...n, ...(l = s.createActions) == null ? void 0 : l.call(s, n) });
  for (let s of Pt)
    "initialise" in s && ((o = s.initialise) == null || o.call(s, n));
  return n;
};
function bn(n) {
  let e, t;
  return e = new Ut({
    props: {
      size: "L",
      value: (
        /*progressPercentage*/
        n[3]
      ),
      duration: jt,
      width: "100%"
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*progressPercentage*/
      8 && (s.value = /*progressPercentage*/
      l[3]), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Or(n) {
  let e, t, l, o, s, i = (
    /*processing*/
    n[2] && bn(n)
  );
  return {
    c() {
      e = de("Are you sure you want to delete "), t = de(
        /*promptQuantity*/
        n[4]
      ), l = de(` rows?
    `), i && i.c(), o = Ae();
    },
    m(r, u) {
      M(r, e, u), M(r, t, u), M(r, l, u), i && i.m(r, u), M(r, o, u), s = !0;
    },
    p(r, u) {
      (!s || u & /*promptQuantity*/
      16) && je(
        t,
        /*promptQuantity*/
        r[4]
      ), /*processing*/
      r[2] ? i ? (i.p(r, u), u & /*processing*/
      4 && p(i, 1)) : (i = bn(r), i.c(), p(i, 1), i.m(o.parentNode, o)) : i && (he(), w(i, 1, 1, () => {
        i = null;
      }), we());
    },
    i(r) {
      s || (p(i), s = !0);
    },
    o(r) {
      w(i), s = !1;
    },
    d(r) {
      r && (E(e), E(t), E(l), E(o)), i && i.d(r);
    }
  };
}
function Tr(n) {
  let e, t;
  return e = new Ot({
    props: {
      title: "Delete rows",
      confirmText: "Continue",
      cancelText: "Cancel",
      onConfirm: (
        /*bulkDeleteRows*/
        n[12]
      ),
      size: "M",
      $$slots: { default: [Or] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*$$scope, progressPercentage, processing, promptQuantity*/
      268435484 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function kn(n) {
  let e, t;
  return e = new Ut({
    props: {
      size: "L",
      value: (
        /*progressPercentage*/
        n[3]
      ),
      duration: jt,
      width: "100%"
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*progressPercentage*/
      8 && (s.value = /*progressPercentage*/
      l[3]), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function zr(n) {
  let e, t, l, o, s, i = (
    /*processing*/
    n[2] && kn(n)
  );
  return {
    c() {
      e = de("Are you sure you want to delete "), t = de(
        /*promptQuantity*/
        n[4]
      ), l = de(` cells?
    `), i && i.c(), o = Ae();
    },
    m(r, u) {
      M(r, e, u), M(r, t, u), M(r, l, u), i && i.m(r, u), M(r, o, u), s = !0;
    },
    p(r, u) {
      (!s || u & /*promptQuantity*/
      16) && je(
        t,
        /*promptQuantity*/
        r[4]
      ), /*processing*/
      r[2] ? i ? (i.p(r, u), u & /*processing*/
      4 && p(i, 1)) : (i = kn(r), i.c(), p(i, 1), i.m(o.parentNode, o)) : i && (he(), w(i, 1, 1, () => {
        i = null;
      }), we());
    },
    i(r) {
      s || (p(i), s = !0);
    },
    o(r) {
      w(i), s = !1;
    },
    d(r) {
      r && (E(e), E(t), E(l), E(o)), i && i.d(r);
    }
  };
}
function Pr(n) {
  let e, t;
  return e = new Ot({
    props: {
      title: "Delete cells",
      confirmText: "Continue",
      cancelText: "Cancel",
      onConfirm: (
        /*bulkDeleteCells*/
        n[13]
      ),
      size: "M",
      $$slots: { default: [zr] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*$$scope, progressPercentage, processing, promptQuantity*/
      268435484 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Hr(n) {
  let e, t, l, o, s = {
    $$slots: { default: [Tr] },
    $$scope: { ctx: n }
  };
  e = new Nt({ props: s }), n[16](e);
  let i = {
    $$slots: { default: [Pr] },
    $$scope: { ctx: n }
  };
  return l = new Nt({ props: i }), n[17](l), {
    c() {
      W(e.$$.fragment), t = x(), W(l.$$.fragment);
    },
    m(r, u) {
      K(e, r, u), M(r, t, u), K(l, r, u), o = !0;
    },
    p(r, [u]) {
      const a = {};
      u & /*$$scope, progressPercentage, processing, promptQuantity*/
      268435484 && (a.$$scope = { dirty: u, ctx: r }), e.$set(a);
      const c = {};
      u & /*$$scope, progressPercentage, processing, promptQuantity*/
      268435484 && (c.$$scope = { dirty: u, ctx: r }), l.$set(c);
    },
    i(r) {
      o || (p(e.$$.fragment, r), p(l.$$.fragment, r), o = !0);
    },
    o(r) {
      w(e.$$.fragment, r), w(l.$$.fragment, r), o = !1;
    },
    d(r) {
      r && E(t), n[16](null), X(e, r), n[17](null), X(l, r);
    }
  };
}
const jt = 260;
function Fr(n, e, t) {
  let l, o, s, i, r, u, a, c;
  const { selectedRows: f, rows: d, subscribe: m, notifications: _, menu: g, selectedCellCount: v, selectedRowCount: R, selectedCells: b, rowLookupMap: y, config: k } = Te("grid");
  A(n, f, (B) => t(15, c = B)), A(n, _, (B) => t(20, s = B)), A(n, v, (B) => t(21, i = B)), A(n, R, (B) => t(23, u = B)), A(n, b, (B) => t(19, o = B)), A(n, y, (B) => t(14, a = B)), A(n, k, (B) => t(22, r = B));
  let h, C, N = !1, S = 0, I = 0;
  const P = () => {
    t(3, S = 0), g.actions.close(), u && r.canDeleteRows ? u === 1 ? T() : (t(4, I = u), h == null || h.show()) : i && r.canEditRows && (t(4, I = i), C == null || C.show());
  }, T = async () => {
    t(2, N = !0);
    const B = l.length;
    await d.actions.deleteRows(l), t(3, S = 100), await Mt(jt), s.success(`Deleted ${B} row${B === 1 ? "" : "s"}`), t(2, N = !1);
  }, H = async () => {
    t(2, N = !0);
    let B = {};
    for (let te of o)
      for (let _e of te) {
        const { rowId: ie, field: fe } = tt(_e);
        B[ie] || (B[ie] = {}), B[ie][fe] = null;
      }
    await d.actions.bulkUpdate(B, (te) => {
      t(3, S = te * 100);
    }), await Mt(jt), t(2, N = !1);
  };
  it(() => m("request-bulk-delete", P));
  function z(B) {
    $e[B ? "unshift" : "push"](() => {
      h = B, t(0, h);
    });
  }
  function Z(B) {
    $e[B ? "unshift" : "push"](() => {
      C = B, t(1, C);
    });
  }
  return n.$$.update = () => {
    n.$$.dirty & /*$selectedRows, $rowLookupMap*/
    49152 && (l = Object.keys(c).map((B) => a[B]).filter((B) => B != null));
  }, [
    h,
    C,
    N,
    S,
    I,
    f,
    _,
    v,
    R,
    b,
    y,
    k,
    T,
    H,
    a,
    c,
    z,
    Z
  ];
}
class Br extends De {
  constructor(e) {
    super(), Ne(this, e, Fr, Hr, Ee, {});
  }
}
function Cn(n) {
  let e, t;
  return e = new Ut({
    props: {
      size: "L",
      value: (
        /*progressPercentage*/
        n[1]
      ),
      duration: lo,
      width: "100%"
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*progressPercentage*/
      2 && (s.value = /*progressPercentage*/
      l[1]), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function jr(n) {
  let e, t, l, o, s, i = (
    /*processing*/
    n[2] && Cn(n)
  );
  return {
    c() {
      e = de("Are you sure you want to duplicate "), t = de(
        /*promptQuantity*/
        n[3]
      ), l = de(` rows?
    `), i && i.c(), o = Ae();
    },
    m(r, u) {
      M(r, e, u), M(r, t, u), M(r, l, u), i && i.m(r, u), M(r, o, u), s = !0;
    },
    p(r, u) {
      (!s || u & /*promptQuantity*/
      8) && je(
        t,
        /*promptQuantity*/
        r[3]
      ), /*processing*/
      r[2] ? i ? (i.p(r, u), u & /*processing*/
      4 && p(i, 1)) : (i = Cn(r), i.c(), p(i, 1), i.m(o.parentNode, o)) : i && (he(), w(i, 1, 1, () => {
        i = null;
      }), we());
    },
    i(r) {
      s || (p(i), s = !0);
    },
    o(r) {
      w(i), s = !1;
    },
    d(r) {
      r && (E(e), E(t), E(l), E(o)), i && i.d(r);
    }
  };
}
function Vr(n) {
  let e, t;
  return e = new Ot({
    props: {
      title: "Duplicate rows",
      confirmText: "Continue",
      cancelText: "Cancel",
      onConfirm: (
        /*performDuplication*/
        n[8]
      ),
      size: "M",
      $$slots: { default: [jr] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*$$scope, progressPercentage, processing, promptQuantity*/
      262158 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Ur(n) {
  let e, t, l = {
    $$slots: { default: [Vr] },
    $$scope: { ctx: n }
  };
  return e = new Nt({ props: l }), n[9](e), {
    c() {
      W(e.$$.fragment);
    },
    m(o, s) {
      K(e, o, s), t = !0;
    },
    p(o, [s]) {
      const i = {};
      s & /*$$scope, progressPercentage, processing, promptQuantity*/
      262158 && (i.$$scope = { dirty: s, ctx: o }), e.$set(i);
    },
    i(o) {
      t || (p(e.$$.fragment, o), t = !0);
    },
    o(o) {
      w(e.$$.fragment, o), t = !1;
    },
    d(o) {
      n[9](null), X(e, o);
    }
  };
}
const lo = 260;
function qr(n, e, t) {
  let l, o, s, i;
  const { selectedRows: r, rows: u, subscribe: a, selectedRowCount: c, visibleColumns: f, selectedCells: d, rowLookupMap: m } = Te("grid");
  A(n, r, (h) => t(13, i = h)), A(n, c, (h) => t(10, l = h)), A(n, f, (h) => t(11, o = h)), A(n, m, (h) => t(12, s = h));
  let _, g = 0, v = !1, R = 0;
  const b = async () => {
    t(1, g = 0), t(2, v = !0);
    const h = Object.keys(i).map((N) => s[N]), C = await u.actions.bulkDuplicate(h, (N) => {
      t(1, g = N * 100);
    });
    if (await Mt(lo), C.length) {
      const N = C[0], S = C[C.length - 1], I = o[0], P = o[o.length - 1], T = xe(N._id, I.name), H = xe(S._id, P.name);
      d.actions.selectRange(T, H);
    }
    t(2, v = !1);
  }, y = () => {
    t(3, R = l), _ == null || _.show();
  };
  it(() => a("request-bulk-duplicate", y));
  function k(h) {
    $e[h ? "unshift" : "push"](() => {
      _ = h, t(0, _);
    });
  }
  return [
    _,
    g,
    v,
    R,
    r,
    c,
    f,
    m,
    b,
    k
  ];
}
class Gr extends De {
  constructor(e) {
    super(), Ne(this, e, qr, Ur, Ee, {});
  }
}
function Rn(n) {
  let e, t;
  return e = new Ut({
    props: {
      size: "L",
      value: (
        /*progressPercentage*/
        n[1]
      ),
      duration: oo,
      width: "100%"
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*progressPercentage*/
      2 && (s.value = /*progressPercentage*/
      l[1]), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Wr(n) {
  let e, t, l, o = (
    /*processing*/
    n[2] && Rn(n)
  );
  return {
    c() {
      e = de(`Are you sure you want to paste? This will update multiple values.
    `), o && o.c(), t = Ae();
    },
    m(s, i) {
      M(s, e, i), o && o.m(s, i), M(s, t, i), l = !0;
    },
    p(s, i) {
      /*processing*/
      s[2] ? o ? (o.p(s, i), i & /*processing*/
      4 && p(o, 1)) : (o = Rn(s), o.c(), p(o, 1), o.m(t.parentNode, t)) : o && (he(), w(o, 1, 1, () => {
        o = null;
      }), we());
    },
    i(s) {
      l || (p(o), l = !0);
    },
    o(s) {
      w(o), l = !1;
    },
    d(s) {
      s && (E(e), E(t)), o && o.d(s);
    }
  };
}
function Kr(n) {
  let e, t;
  return e = new Ot({
    props: {
      title: "Confirm paste",
      confirmText: "Continue",
      cancelText: "Cancel",
      onConfirm: (
        /*performBulkPaste*/
        n[7]
      ),
      size: "M",
      $$slots: { default: [Wr] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*$$scope, progressPercentage, processing*/
      131078 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Xr(n) {
  let e, t, l = {
    $$slots: { default: [Kr] },
    $$scope: { ctx: n }
  };
  return e = new Nt({ props: l }), n[8](e), {
    c() {
      W(e.$$.fragment);
    },
    m(o, s) {
      K(e, o, s), t = !0;
    },
    p(o, [s]) {
      const i = {};
      s & /*$$scope, progressPercentage, processing*/
      131078 && (i.$$scope = { dirty: s, ctx: o }), e.$set(i);
    },
    i(o) {
      t || (p(e.$$.fragment, o), t = !0);
    },
    o(o) {
      w(e.$$.fragment, o), t = !1;
    },
    d(o) {
      n[8](null), X(e, o);
    }
  };
}
const oo = 260;
function Yr(n, e, t) {
  let l, o, s, i;
  const { clipboard: r, subscribe: u, copyAllowed: a, pasteAllowed: c, selectedCellCount: f, focusedCellAPI: d } = Te("grid");
  A(n, r, (k) => t(9, l = k)), A(n, a, (k) => t(12, i = k)), A(n, c, (k) => t(11, s = k)), A(n, f, (k) => t(10, o = k));
  let m, _ = 0, g = !1;
  const v = () => {
    i && r.actions.copy();
  }, R = async () => {
    var C;
    if ((C = L(d)) != null && C.isActive() || (t(1, _ = 0), !s))
      return;
    const k = o > 1;
    l.multiCellCopy || k ? m == null || m.show() : r.actions.paste();
  }, b = async () => {
    t(2, g = !0), await r.actions.paste((k) => {
      t(1, _ = k * 100);
    }), await Mt(oo), t(2, g = !1);
  };
  it(() => u("copy", v)), it(() => u("paste", R));
  function y(k) {
    $e[k ? "unshift" : "push"](() => {
      m = k, t(0, m);
    });
  }
  return [
    m,
    _,
    g,
    r,
    a,
    c,
    f,
    b,
    y
  ];
}
class Jr extends De {
  constructor(e) {
    super(), Ne(this, e, Yr, Xr, Ee, {});
  }
}
function Qr(n) {
  let e, t, l, o, s;
  const i = (
    /*#slots*/
    n[23].default
  ), r = We(
    i,
    n,
    /*$$scope*/
    n[22],
    null
  );
  return {
    c() {
      e = $("div"), t = $("div"), r && r.c(), U(
        t,
        "style",
        /*style*/
        n[2]
      ), U(t, "class", "inner svelte-i68dpr"), U(e, "class", "outer svelte-i68dpr");
    },
    m(u, a) {
      M(u, e, a), le(e, t), r && r.m(t, null), n[24](t), l = !0, o || (s = [
        ke(e, "wheel", function() {
          Ue(
            /*attachHandlers*/
            n[1] ? (
              /*handleWheel*/
              n[14]
            ) : null
          ) && /*attachHandlers*/
          (n[1] ? (
            /*handleWheel*/
            n[14]
          ) : null).apply(this, arguments);
        }),
        ke(e, "touchstart", function() {
          Ue(
            /*attachHandlers*/
            n[1] ? (
              /*handleTouchStart*/
              n[15]
            ) : null
          ) && /*attachHandlers*/
          (n[1] ? (
            /*handleTouchStart*/
            n[15]
          ) : null).apply(this, arguments);
        }),
        ke(e, "touchmove", function() {
          Ue(
            /*attachHandlers*/
            n[1] ? (
              /*handleTouchMove*/
              n[16]
            ) : null
          ) && /*attachHandlers*/
          (n[1] ? (
            /*handleTouchMove*/
            n[16]
          ) : null).apply(this, arguments);
        }),
        ke(e, "click", Mo(
          /*ui*/
          n[5].actions.blur
        ))
      ], o = !0);
    },
    p(u, a) {
      n = u, r && r.p && (!l || a[0] & /*$$scope*/
      4194304) && Ke(
        r,
        i,
        n,
        /*$$scope*/
        n[22],
        l ? Ye(
          i,
          /*$$scope*/
          n[22],
          a,
          null
        ) : Xe(
          /*$$scope*/
          n[22]
        ),
        null
      ), (!l || a[0] & /*style*/
      4) && U(
        t,
        "style",
        /*style*/
        n[2]
      );
    },
    i(u) {
      l || (p(r, u), l = !0);
    },
    o(u) {
      w(r, u), l = !1;
    },
    d(u) {
      u && E(e), r && r.d(u), n[24](null), o = !1, lt(s);
    }
  };
}
function Zr(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, m, { $$slots: _ = {}, $$scope: g } = e;
  const { rowHeight: v, scroll: R, ui: b, renderedRows: y, maxScrollTop: k, maxScrollLeft: h, bounds: C, hoveredRowId: N, menu: S, focusedCellAPI: I, scrollTop: P, scrollLeft: T } = Te("grid");
  A(n, v, (J) => t(19, o = J)), A(n, R, (J) => t(31, a = J)), A(n, y, (J) => t(27, s = J)), A(n, k, (J) => t(30, u = J)), A(n, h, (J) => t(29, r = J)), A(n, C, (J) => t(28, i = J)), A(n, S, (J) => t(32, c = J)), A(n, I, (J) => t(33, f = J)), A(n, P, (J) => t(20, d = J)), A(n, T, (J) => t(21, m = J));
  let { scrollVertically: H = !1 } = e, { scrollHorizontally: z = !1 } = e, { attachHandlers: Z = !1 } = e, { ref: B } = e, te, _e;
  const ie = (J, be, j) => {
    const Q = z ? -1 * J : 0, F = H ? -1 * (be % j) : 0;
    return `transform: translate(${Q}px, ${F}px);`;
  }, fe = (J) => {
    J.preventDefault(), Ce(J.deltaX, J.deltaY, J.clientY), f == null || f.blur(), c.visible && S.actions.close();
  }, ae = (J) => {
    var be;
    (be = J.touches) != null && be[0] && (te = J.touches[0].clientX, _e = J.touches[0].clientY);
  }, Re = (J) => {
    var Q;
    if (!((Q = J.touches) != null && Q[0]))
      return;
    J.preventDefault();
    const be = te - J.touches[0].clientX, j = _e - J.touches[0].clientY;
    Ce(be, j), te = J.touches[0].clientX, _e = J.touches[0].clientY, c.visible && S.actions.close();
  }, Ce = Zt((J, be, j) => {
    const { top: Q, left: F } = a;
    let q = Q + be;
    q = Math.max(0, Math.min(q, u));
    let V = F + J;
    if (V = Math.max(0, Math.min(V, r)), R.set({
      left: z ? V : F,
      top: H ? q : Q
    }), j != null) {
      const G = j - i.top + q % o, O = s[Math.floor(G / o)];
      N.set(O == null ? void 0 : O._id);
    }
  });
  function ve(J) {
    $e[J ? "unshift" : "push"](() => {
      B = J, t(0, B);
    });
  }
  return n.$$set = (J) => {
    "scrollVertically" in J && t(17, H = J.scrollVertically), "scrollHorizontally" in J && t(18, z = J.scrollHorizontally), "attachHandlers" in J && t(1, Z = J.attachHandlers), "ref" in J && t(0, B = J.ref), "$$scope" in J && t(22, g = J.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*$scrollLeft, $scrollTop, $rowHeight*/
    3670016 && t(2, l = ie(m, d, o));
  }, [
    B,
    Z,
    l,
    v,
    R,
    b,
    y,
    k,
    h,
    C,
    S,
    I,
    P,
    T,
    fe,
    ae,
    Re,
    H,
    z,
    o,
    d,
    m,
    g,
    _,
    ve
  ];
}
class Et extends De {
  constructor(e) {
    super(), Ne(
      this,
      e,
      Zr,
      Qr,
      Ee,
      {
        scrollVertically: 17,
        scrollHorizontally: 18,
        attachHandlers: 1,
        ref: 0
      },
      null,
      [-1, -1]
    );
  }
}
function vn(n) {
  let e, t;
  return {
    c() {
      e = $("div"), t = de(
        /*error*/
        n[4]
      ), U(e, "class", "label svelte-om663h");
    },
    m(l, o) {
      M(l, e, o), le(e, t);
    },
    p(l, o) {
      o & /*error*/
      16 && je(
        t,
        /*error*/
        l[4]
      );
    },
    d(l) {
      l && E(e);
    }
  };
}
function Sn(n) {
  let e, t = (
    /*selectedUser*/
    n[3].label + ""
  ), l;
  return {
    c() {
      e = $("div"), l = de(t), U(e, "class", "label svelte-om663h");
    },
    m(o, s) {
      M(o, e, s), le(e, l);
    },
    p(o, s) {
      s & /*selectedUser*/
      8 && t !== (t = /*selectedUser*/
      o[3].label + "") && je(l, t);
    },
    d(o) {
      o && E(e);
    }
  };
}
function $r(n) {
  let e, t, l, o, s, i, r = (
    /*error*/
    n[4] && vn(n)
  );
  const u = (
    /*#slots*/
    n[15].default
  ), a = We(
    u,
    n,
    /*$$scope*/
    n[14],
    null
  );
  let c = (
    /*selectedUser*/
    n[3] && !/*focused*/
    n[0] && Sn(n)
  );
  return {
    c() {
      e = $("div"), r && r.c(), t = x(), a && a.c(), l = x(), c && c.c(), U(e, "class", "cell svelte-om663h"), U(
        e,
        "style",
        /*style*/
        n[11]
      ), ne(
        e,
        "selected",
        /*selected*/
        n[1]
      ), ne(
        e,
        "highlighted",
        /*highlighted*/
        n[2]
      ), ne(
        e,
        "focused",
        /*focused*/
        n[0]
      ), ne(
        e,
        "error",
        /*error*/
        n[4]
      ), ne(
        e,
        "center",
        /*center*/
        n[8]
      ), ne(
        e,
        "readonly",
        /*readonly*/
        n[9]
      ), ne(
        e,
        "hidden",
        /*hidden*/
        n[10]
      ), ne(
        e,
        "default-height",
        /*defaultHeight*/
        n[7]
      ), ne(
        e,
        "selected-other",
        /*selectedUser*/
        n[3] != null
      ), ne(
        e,
        "alt",
        /*rowIdx*/
        n[5] % 2 === 1
      ), ne(
        e,
        "top",
        /*topRow*/
        n[6]
      );
    },
    m(f, d) {
      M(f, e, d), r && r.m(e, null), le(e, t), a && a.m(e, null), le(e, l), c && c.m(e, null), o = !0, s || (i = [
        ke(
          e,
          "focus",
          /*focus_handler*/
          n[16]
        ),
        ke(
          e,
          "mousedown",
          /*mousedown_handler*/
          n[17]
        ),
        ke(
          e,
          "mouseup",
          /*mouseup_handler*/
          n[18]
        ),
        ke(
          e,
          "click",
          /*click_handler*/
          n[19]
        ),
        ke(
          e,
          "contextmenu",
          /*contextmenu_handler*/
          n[20]
        ),
        ke(
          e,
          "touchstart",
          /*touchstart_handler*/
          n[21],
          { passive: !0 }
        ),
        ke(
          e,
          "touchend",
          /*touchend_handler*/
          n[22]
        ),
        ke(
          e,
          "touchcancel",
          /*touchcancel_handler*/
          n[23]
        ),
        ke(
          e,
          "mouseenter",
          /*mouseenter_handler*/
          n[24]
        )
      ], s = !0);
    },
    p(f, [d]) {
      /*error*/
      f[4] ? r ? r.p(f, d) : (r = vn(f), r.c(), r.m(e, t)) : r && (r.d(1), r = null), a && a.p && (!o || d & /*$$scope*/
      16384) && Ke(
        a,
        u,
        f,
        /*$$scope*/
        f[14],
        o ? Ye(
          u,
          /*$$scope*/
          f[14],
          d,
          null
        ) : Xe(
          /*$$scope*/
          f[14]
        ),
        null
      ), /*selectedUser*/
      f[3] && !/*focused*/
      f[0] ? c ? c.p(f, d) : (c = Sn(f), c.c(), c.m(e, null)) : c && (c.d(1), c = null), (!o || d & /*style*/
      2048) && U(
        e,
        "style",
        /*style*/
        f[11]
      ), (!o || d & /*selected*/
      2) && ne(
        e,
        "selected",
        /*selected*/
        f[1]
      ), (!o || d & /*highlighted*/
      4) && ne(
        e,
        "highlighted",
        /*highlighted*/
        f[2]
      ), (!o || d & /*focused*/
      1) && ne(
        e,
        "focused",
        /*focused*/
        f[0]
      ), (!o || d & /*error*/
      16) && ne(
        e,
        "error",
        /*error*/
        f[4]
      ), (!o || d & /*center*/
      256) && ne(
        e,
        "center",
        /*center*/
        f[8]
      ), (!o || d & /*readonly*/
      512) && ne(
        e,
        "readonly",
        /*readonly*/
        f[9]
      ), (!o || d & /*hidden*/
      1024) && ne(
        e,
        "hidden",
        /*hidden*/
        f[10]
      ), (!o || d & /*defaultHeight*/
      128) && ne(
        e,
        "default-height",
        /*defaultHeight*/
        f[7]
      ), (!o || d & /*selectedUser*/
      8) && ne(
        e,
        "selected-other",
        /*selectedUser*/
        f[3] != null
      ), (!o || d & /*rowIdx*/
      32) && ne(
        e,
        "alt",
        /*rowIdx*/
        f[5] % 2 === 1
      ), (!o || d & /*topRow*/
      64) && ne(
        e,
        "top",
        /*topRow*/
        f[6]
      );
    },
    i(f) {
      o || (p(a, f), o = !0);
    },
    o(f) {
      w(a, f), o = !1;
    },
    d(f) {
      f && E(e), r && r.d(), a && a.d(f), c && c.d(), s = !1, lt(i);
    }
  };
}
function xr(n, e, t) {
  let l, { $$slots: o = {}, $$scope: s } = e, { focused: i = !1 } = e, { selected: r = !1 } = e, { highlighted: u = !1 } = e, { width: a = "" } = e, { selectedUser: c = null } = e, { error: f = null } = e, { rowIdx: d } = e, { topRow: m = !1 } = e, { defaultHeight: _ = !1 } = e, { center: g = !1 } = e, { readonly: v = !1 } = e, { hidden: R = !1 } = e, { metadata: b = null } = e;
  const y = (z, Z, B) => {
    let te;
    return z === "auto" || z === "100%" ? te = `width: ${z};` : te = `flex: 0 0 ${z}px;`, Z && (te += `--user-color :${Z.color};`), B != null && B.backgroundColor && (te += `--cell-background: ${B.backgroundColor};`), B != null && B.textColor && (te += `--cell-font-color: ${B.textColor};`), te;
  };
  function k(z) {
    dt.call(this, n, z);
  }
  function h(z) {
    dt.call(this, n, z);
  }
  function C(z) {
    dt.call(this, n, z);
  }
  function N(z) {
    dt.call(this, n, z);
  }
  function S(z) {
    dt.call(this, n, z);
  }
  function I(z) {
    dt.call(this, n, z);
  }
  function P(z) {
    dt.call(this, n, z);
  }
  function T(z) {
    dt.call(this, n, z);
  }
  function H(z) {
    dt.call(this, n, z);
  }
  return n.$$set = (z) => {
    "focused" in z && t(0, i = z.focused), "selected" in z && t(1, r = z.selected), "highlighted" in z && t(2, u = z.highlighted), "width" in z && t(12, a = z.width), "selectedUser" in z && t(3, c = z.selectedUser), "error" in z && t(4, f = z.error), "rowIdx" in z && t(5, d = z.rowIdx), "topRow" in z && t(6, m = z.topRow), "defaultHeight" in z && t(7, _ = z.defaultHeight), "center" in z && t(8, g = z.center), "readonly" in z && t(9, v = z.readonly), "hidden" in z && t(10, R = z.hidden), "metadata" in z && t(13, b = z.metadata), "$$scope" in z && t(14, s = z.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*width, selectedUser, metadata*/
    12296 && t(11, l = y(a, c, b));
  }, [
    i,
    r,
    u,
    c,
    f,
    d,
    m,
    _,
    g,
    v,
    R,
    l,
    a,
    b,
    s,
    o,
    k,
    h,
    C,
    N,
    S,
    I,
    P,
    T,
    H
  ];
}
class wt extends De {
  constructor(e) {
    super(), Ne(this, e, xr, $r, Ee, {
      focused: 0,
      selected: 1,
      highlighted: 2,
      width: 12,
      selectedUser: 3,
      error: 4,
      rowIdx: 5,
      topRow: 6,
      defaultHeight: 7,
      center: 8,
      readonly: 9,
      hidden: 10,
      metadata: 13
    });
  }
}
function ei(n) {
  let e, t, l, o;
  function s(c) {
    n[33](c);
  }
  var i = (
    /*renderer*/
    n[18]
  );
  function r(c, f) {
    let d = {
      value: (
        /*value*/
        c[13]
      ),
      schema: (
        /*column*/
        c[6].schema
      ),
      onChange: (
        /*cellAPI*/
        c[24].setValue
      ),
      focused: (
        /*focused*/
        c[4]
      ),
      readonly: (
        /*readonly*/
        c[14]
      ),
      contentLines: (
        /*contentLines*/
        c[9]
      )
    };
    return (
      /*api*/
      c[12] !== void 0 && (d.api = /*api*/
      c[12]), { props: d }
    );
  }
  i && (e = ln(i, r(n)), $e.push(() => Bt(e, "api", s)));
  const u = (
    /*#slots*/
    n[32].default
  ), a = We(
    u,
    n,
    /*$$scope*/
    n[35],
    null
  );
  return {
    c() {
      e && W(e.$$.fragment), l = x(), a && a.c();
    },
    m(c, f) {
      e && K(e, c, f), M(c, l, f), a && a.m(c, f), o = !0;
    },
    p(c, f) {
      if (f[0] & /*renderer*/
      262144 && i !== (i = /*renderer*/
      c[18])) {
        if (e) {
          he();
          const d = e;
          w(d.$$.fragment, 1, 0, () => {
            X(d, 1);
          }), we();
        }
        i ? (e = ln(i, r(c)), $e.push(() => Bt(e, "api", s)), W(e.$$.fragment), p(e.$$.fragment, 1), K(e, l.parentNode, l)) : e = null;
      } else if (i) {
        const d = {};
        f[0] & /*value*/
        8192 && (d.value = /*value*/
        c[13]), f[0] & /*column*/
        64 && (d.schema = /*column*/
        c[6].schema), f[0] & /*focused*/
        16 && (d.focused = /*focused*/
        c[4]), f[0] & /*readonly*/
        16384 && (d.readonly = /*readonly*/
        c[14]), f[0] & /*contentLines*/
        512 && (d.contentLines = /*contentLines*/
        c[9]), !t && f[0] & /*api*/
        4096 && (t = !0, d.api = /*api*/
        c[12], en(() => t = !1)), e.$set(d);
      }
      a && a.p && (!o || f[1] & /*$$scope*/
      16) && Ke(
        a,
        u,
        c,
        /*$$scope*/
        c[35],
        o ? Ye(
          u,
          /*$$scope*/
          c[35],
          f,
          null
        ) : Xe(
          /*$$scope*/
          c[35]
        ),
        null
      );
    },
    i(c) {
      o || (e && p(e.$$.fragment, c), p(a, c), o = !0);
    },
    o(c) {
      e && w(e.$$.fragment, c), w(a, c), o = !1;
    },
    d(c) {
      c && E(l), e && X(e, c), a && a.d(c);
    }
  };
}
function ti(n) {
  var l, o;
  let e, t;
  return e = new wt({
    props: {
      highlighted: (
        /*highlighted*/
        n[0]
      ),
      rowIdx: (
        /*rowIdx*/
        n[2]
      ),
      topRow: (
        /*topRow*/
        n[3]
      ),
      focused: (
        /*focused*/
        n[4]
      ),
      selectedUser: (
        /*selectedUser*/
        n[5]
      ),
      readonly: (
        /*readonly*/
        n[14]
      ),
      hidden: (
        /*hidden*/
        n[10]
      ),
      selected: (
        /*rowSelected*/
        n[1] || /*cellSelected*/
        n[11]
      ),
      error: (
        /*$error*/
        n[19]
      ),
      width: (
        /*column*/
        n[6].width
      ),
      metadata: {
        .../*row*/
        (l = n[7].__metadata) == null ? void 0 : l.row,
        .../*row*/
        (o = n[7].__metadata) == null ? void 0 : o.cell[
          /*column*/
          n[6].name
        ]
      },
      $$slots: { default: [ei] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "contextmenu",
    /*contextmenu_handler*/
    n[34]
  ), e.$on(
    "mousedown",
    /*startSelection*/
    n[25]
  ), e.$on("mouseenter", function() {
    Ue(
      /*updateSelectionCallback*/
      n[16]
    ) && n[16].apply(this, arguments);
  }), e.$on("mouseup", function() {
    Ue(
      /*stopSelectionCallback*/
      n[15]
    ) && n[15].apply(this, arguments);
  }), e.$on(
    "click",
    /*handleClick*/
    n[26]
  ), {
    c() {
      W(e.$$.fragment);
    },
    m(s, i) {
      K(e, s, i), t = !0;
    },
    p(s, i) {
      var u, a;
      n = s;
      const r = {};
      i[0] & /*highlighted*/
      1 && (r.highlighted = /*highlighted*/
      n[0]), i[0] & /*rowIdx*/
      4 && (r.rowIdx = /*rowIdx*/
      n[2]), i[0] & /*topRow*/
      8 && (r.topRow = /*topRow*/
      n[3]), i[0] & /*focused*/
      16 && (r.focused = /*focused*/
      n[4]), i[0] & /*selectedUser*/
      32 && (r.selectedUser = /*selectedUser*/
      n[5]), i[0] & /*readonly*/
      16384 && (r.readonly = /*readonly*/
      n[14]), i[0] & /*hidden*/
      1024 && (r.hidden = /*hidden*/
      n[10]), i[0] & /*rowSelected, cellSelected*/
      2050 && (r.selected = /*rowSelected*/
      n[1] || /*cellSelected*/
      n[11]), i[0] & /*$error*/
      524288 && (r.error = /*$error*/
      n[19]), i[0] & /*column*/
      64 && (r.width = /*column*/
      n[6].width), i[0] & /*row, column*/
      192 && (r.metadata = {
        .../*row*/
        (u = n[7].__metadata) == null ? void 0 : u.row,
        .../*row*/
        (a = n[7].__metadata) == null ? void 0 : a.cell[
          /*column*/
          n[6].name
        ]
      }), i[0] & /*renderer, value, column, focused, readonly, contentLines, api*/
      291408 | i[1] & /*$$scope*/
      16 && (r.$$scope = { dirty: i, ctx: n }), e.$set(r);
    },
    i(s) {
      t || (p(e.$$.fragment, s), t = !0);
    },
    o(s) {
      w(e.$$.fragment, s), t = !1;
    },
    d(s) {
      X(e, s);
    }
  };
}
function ni(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, m, _ = Oe, g = () => (_(), _ = $t(i, (D) => t(19, m = D)), i);
  n.$$.on_destroy.push(() => _());
  let { $$slots: v = {}, $$scope: R } = e;
  const { rows: b, columns: y, focusedCellId: k, focusedCellAPI: h, menu: C, config: N, validation: S, selectedCells: I, selectedCellCount: P } = Te("grid");
  A(n, k, (D) => t(37, f = D)), A(n, N, (D) => t(31, d = D)), A(n, P, (D) => t(36, c = D));
  let { highlighted: T } = e, { rowFocused: H } = e, { rowSelected: z } = e, { rowIdx: Z } = e, { topRow: B = !1 } = e, { focused: te } = e, { selectedUser: _e } = e, { column: ie } = e, { row: fe } = e, { cellId: ae } = e, { updateValue: Re = b.actions.updateValue } = e, { contentLines: Ce = 1 } = e, { hidden: ve = !1 } = e, { isSelectingCells: J = !1 } = e, { cellSelected: be = !1 } = e;
  const j = Me(null);
  let Q;
  const F = (D, re) => D ? me(S, (oe) => oe[re]) : j, q = {
    focus: () => {
      var D;
      return (D = Q == null ? void 0 : Q.focus) == null ? void 0 : D.call(Q);
    },
    blur: () => {
      var D;
      return (D = Q == null ? void 0 : Q.blur) == null ? void 0 : D.call(Q);
    },
    isActive: () => {
      var D;
      return ((D = Q == null ? void 0 : Q.isActive) == null ? void 0 : D.call(Q)) ?? !1;
    },
    onKeyDown: (...D) => {
      var re;
      return (re = Q == null ? void 0 : Q.onKeyDown) == null ? void 0 : re.call(Q, ...D);
    },
    isReadonly: () => r,
    getType: () => ie.schema.type,
    getValue: () => s,
    setValue: (D, re = { apply: !0 }) => {
      S.actions.setError(ae, null), Re({
        rowId: fe._id,
        column: ie.name,
        value: D,
        apply: re == null ? void 0 : re.apply
      });
    }
  }, V = (D) => {
    D.button !== 0 || D.shiftKey || I.actions.startSelecting(ae);
  }, G = (D) => {
    if (D.buttons !== 1) {
      I.actions.stopSelecting();
      return;
    }
    I.actions.updateTarget(ae);
  }, O = () => {
    I.actions.stopSelecting();
  }, se = (D) => {
    D.shiftKey && f ? I.actions.selectRange(f, ae) : D.shiftKey && c ? I.actions.updateTarget(ae) : k.set(ae);
  };
  function ge(D) {
    Q = D, t(12, Q);
  }
  const ue = (D) => C.actions.open(ae, D);
  return n.$$set = (D) => {
    "highlighted" in D && t(0, T = D.highlighted), "rowFocused" in D && t(27, H = D.rowFocused), "rowSelected" in D && t(1, z = D.rowSelected), "rowIdx" in D && t(2, Z = D.rowIdx), "topRow" in D && t(3, B = D.topRow), "focused" in D && t(4, te = D.focused), "selectedUser" in D && t(5, _e = D.selectedUser), "column" in D && t(6, ie = D.column), "row" in D && t(7, fe = D.row), "cellId" in D && t(8, ae = D.cellId), "updateValue" in D && t(28, Re = D.updateValue), "contentLines" in D && t(9, Ce = D.contentLines), "hidden" in D && t(10, ve = D.hidden), "isSelectingCells" in D && t(29, J = D.isSelectingCells), "cellSelected" in D && t(11, be = D.cellSelected), "$$scope" in D && t(35, R = D.$$scope);
  }, n.$$.update = () => {
    var D;
    n.$$.dirty[0] & /*column, row*/
    192 && t(30, l = ie.format && !fe._isNewRow), n.$$.dirty[0] & /*hasCustomFormat, column*/
    1073741888 && t(18, o = l ? Eo : Ao(ie)), n.$$.dirty[0] & /*hasCustomFormat, row, column*/
    1073742016 && t(13, s = l ? (D = fe.__formatted) == null ? void 0 : D[ie.name] : fe[ie.name]), n.$$.dirty[0] & /*rowFocused, cellId*/
    134217984 && g(t(17, i = F(H, ae))), n.$$.dirty[0] & /*hasCustomFormat, column, row*/
    1073742016 | n.$$.dirty[1] & /*$config*/
    1 && t(14, r = l || y.actions.isReadonly(ie) || !d.canEditRows && !fe._isNewRow), n.$$.dirty[0] & /*focused*/
    16 && te && h.set(q), n.$$.dirty[0] & /*isSelectingCells*/
    536870912 && t(16, u = J ? G : null), n.$$.dirty[0] & /*isSelectingCells*/
    536870912 && t(15, a = J ? O : null);
  }, [
    T,
    z,
    Z,
    B,
    te,
    _e,
    ie,
    fe,
    ae,
    Ce,
    ve,
    be,
    Q,
    s,
    r,
    a,
    u,
    i,
    o,
    m,
    k,
    C,
    N,
    P,
    q,
    V,
    se,
    H,
    Re,
    J,
    l,
    d,
    v,
    ge,
    ue,
    R
  ];
}
class qt extends De {
  constructor(e) {
    super(), Ne(
      this,
      e,
      ni,
      ti,
      Ee,
      {
        highlighted: 0,
        rowFocused: 27,
        rowSelected: 1,
        rowIdx: 2,
        topRow: 3,
        focused: 4,
        selectedUser: 5,
        column: 6,
        row: 7,
        cellId: 8,
        updateValue: 28,
        contentLines: 9,
        hidden: 10,
        isSelectingCells: 29,
        cellSelected: 11
      },
      null,
      [-1, -1]
    );
  }
}
function yn(n, e, t) {
  const l = n.slice();
  l[44] = e[t];
  const o = xe(
    /*row*/
    l[0]._id,
    /*column*/
    l[44].name
  );
  return l[45] = o, l;
}
function In(n) {
  let e, t;
  return e = new qt({
    props: {
      cellId: (
        /*cellId*/
        n[45]
      ),
      column: (
        /*column*/
        n[44]
      ),
      row: (
        /*row*/
        n[0]
      ),
      rowFocused: (
        /*rowFocused*/
        n[7]
      ),
      rowSelected: (
        /*rowSelected*/
        n[9]
      ),
      cellSelected: (
        /*$selectedCellMap*/
        n[12][
          /*cellId*/
          n[45]
        ]
      ),
      highlighted: (
        /*rowHovered*/
        n[8] || /*rowFocused*/
        n[7] || /*reorderSource*/
        n[6] === /*column*/
        n[44].name
      ),
      rowIdx: (
        /*row*/
        n[0].__idx
      ),
      topRow: (
        /*top*/
        n[1]
      ),
      focused: (
        /*$focusedCellId*/
        n[13] === /*cellId*/
        n[45]
      ),
      selectedUser: (
        /*$userCellMap*/
        n[14][
          /*cellId*/
          n[45]
        ]
      ),
      width: (
        /*column*/
        n[44].width
      ),
      contentLines: (
        /*$contentLines*/
        n[15]
      ),
      hidden: !/*$columnRenderMap*/
      n[16][
        /*column*/
        n[44].name
      ],
      isSelectingCells: (
        /*$isSelectingCells*/
        n[3]
      )
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*row, $scrollableColumns*/
      2049 && (s.cellId = /*cellId*/
      l[45]), o[0] & /*$scrollableColumns*/
      2048 && (s.column = /*column*/
      l[44]), o[0] & /*row*/
      1 && (s.row = /*row*/
      l[0]), o[0] & /*rowFocused*/
      128 && (s.rowFocused = /*rowFocused*/
      l[7]), o[0] & /*rowSelected*/
      512 && (s.rowSelected = /*rowSelected*/
      l[9]), o[0] & /*$selectedCellMap, row, $scrollableColumns*/
      6145 && (s.cellSelected = /*$selectedCellMap*/
      l[12][
        /*cellId*/
        l[45]
      ]), o[0] & /*rowHovered, rowFocused, reorderSource, $scrollableColumns*/
      2496 && (s.highlighted = /*rowHovered*/
      l[8] || /*rowFocused*/
      l[7] || /*reorderSource*/
      l[6] === /*column*/
      l[44].name), o[0] & /*row*/
      1 && (s.rowIdx = /*row*/
      l[0].__idx), o[0] & /*top*/
      2 && (s.topRow = /*top*/
      l[1]), o[0] & /*$focusedCellId, row, $scrollableColumns*/
      10241 && (s.focused = /*$focusedCellId*/
      l[13] === /*cellId*/
      l[45]), o[0] & /*$userCellMap, row, $scrollableColumns*/
      18433 && (s.selectedUser = /*$userCellMap*/
      l[14][
        /*cellId*/
        l[45]
      ]), o[0] & /*$scrollableColumns*/
      2048 && (s.width = /*column*/
      l[44].width), o[0] & /*$contentLines*/
      32768 && (s.contentLines = /*$contentLines*/
      l[15]), o[0] & /*$columnRenderMap, $scrollableColumns*/
      67584 && (s.hidden = !/*$columnRenderMap*/
      l[16][
        /*column*/
        l[44].name
      ]), o[0] & /*$isSelectingCells*/
      8 && (s.isSelectingCells = /*$isSelectingCells*/
      l[3]), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Mn(n) {
  let e, t;
  return e = new wt({
    props: {
      width: (
        /*$buttonColumnWidth*/
        n[2]
      ),
      selected: (
        /*rowSelected*/
        n[9]
      ),
      highlighted: (
        /*rowHovered*/
        n[8] || /*rowFocused*/
        n[7]
      ),
      rowIdx: (
        /*row*/
        n[0].__idx
      )
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*$buttonColumnWidth*/
      4 && (s.width = /*$buttonColumnWidth*/
      l[2]), o[0] & /*rowSelected*/
      512 && (s.selected = /*rowSelected*/
      l[9]), o[0] & /*rowHovered, rowFocused*/
      384 && (s.highlighted = /*rowHovered*/
      l[8] || /*rowFocused*/
      l[7]), o[0] & /*row*/
      1 && (s.rowIdx = /*row*/
      l[0].__idx), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function li(n) {
  let e, t, l, o, s, i = He(
    /*$scrollableColumns*/
    n[11]
  ), r = [];
  for (let c = 0; c < i.length; c += 1)
    r[c] = In(yn(n, i, c));
  const u = (c) => w(r[c], 1, 1, () => {
    r[c] = null;
  });
  let a = (
    /*needsButtonSpacer*/
    n[5] && Mn(n)
  );
  return {
    c() {
      e = $("div");
      for (let c = 0; c < r.length; c += 1)
        r[c].c();
      t = x(), a && a.c(), U(e, "class", "row svelte-1507qm8");
    },
    m(c, f) {
      M(c, e, f);
      for (let d = 0; d < r.length; d += 1)
        r[d] && r[d].m(e, null);
      le(e, t), a && a.m(e, null), l = !0, o || (s = [
        ke(
          e,
          "focus",
          /*focus_handler*/
          n[40]
        ),
        ke(e, "mouseenter", function() {
          Ue(
            /*$isDragging*/
            n[10] ? null : (
              /*mouseenter_handler*/
              n[41]
            )
          ) && /*$isDragging*/
          (n[10] ? null : (
            /*mouseenter_handler*/
            n[41]
          )).apply(this, arguments);
        }),
        ke(e, "mouseleave", function() {
          Ue(
            /*$isDragging*/
            n[10] ? null : (
              /*mouseleave_handler*/
              n[42]
            )
          ) && /*$isDragging*/
          (n[10] ? null : (
            /*mouseleave_handler*/
            n[42]
          )).apply(this, arguments);
        }),
        ke(
          e,
          "click",
          /*click_handler*/
          n[43]
        )
      ], o = !0);
    },
    p(c, f) {
      if (n = c, f[0] & /*row, $scrollableColumns, rowFocused, rowSelected, $selectedCellMap, rowHovered, reorderSource, top, $focusedCellId, $userCellMap, $contentLines, $columnRenderMap, $isSelectingCells*/
      129995) {
        i = He(
          /*$scrollableColumns*/
          n[11]
        );
        let d;
        for (d = 0; d < i.length; d += 1) {
          const m = yn(n, i, d);
          r[d] ? (r[d].p(m, f), p(r[d], 1)) : (r[d] = In(m), r[d].c(), p(r[d], 1), r[d].m(e, t));
        }
        for (he(), d = i.length; d < r.length; d += 1)
          u(d);
        we();
      }
      /*needsButtonSpacer*/
      n[5] ? a ? (a.p(n, f), f[0] & /*needsButtonSpacer*/
      32 && p(a, 1)) : (a = Mn(n), a.c(), p(a, 1), a.m(e, null)) : a && (he(), w(a, 1, 1, () => {
        a = null;
      }), we());
    },
    i(c) {
      if (!l) {
        for (let f = 0; f < i.length; f += 1)
          p(r[f]);
        p(a), l = !0;
      }
    },
    o(c) {
      r = r.filter(Boolean);
      for (let f = 0; f < r.length; f += 1)
        w(r[f]);
      w(a), l = !1;
    },
    d(c) {
      c && E(e), ct(r, c), a && a.d(), o = !1, lt(s);
    }
  };
}
function oi(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, m, _, g, v, R, b, y, k, h, C, N, { row: S } = e, { top: I = !1 } = e;
  const { focusedCellId: P, reorder: T, selectedRows: H, scrollableColumns: z, hoveredRowId: Z, focusedRow: B, contentLines: te, isDragging: _e, dispatch: ie, rows: fe, columnRenderMap: ae, userCellMap: Re, isSelectingCells: Ce, selectedCellMap: ve, selectedCellCount: J, props: be, buttonColumnWidth: j } = Te("grid");
  A(n, P, (G) => t(13, k = G)), A(n, T, (G) => t(36, f = G)), A(n, H, (G) => t(39, v = G)), A(n, z, (G) => t(11, b = G)), A(n, Z, (G) => t(4, g = G)), A(n, B, (G) => t(37, d = G)), A(n, te, (G) => t(15, C = G)), A(n, _e, (G) => t(10, R = G)), A(n, ae, (G) => t(16, N = G)), A(n, Re, (G) => t(14, h = G)), A(n, Ce, (G) => t(3, m = G)), A(n, ve, (G) => t(12, y = G)), A(n, J, (G) => t(38, _ = G)), A(n, be, (G) => t(35, c = G)), A(n, j, (G) => t(2, a = G));
  function Q(G) {
    dt.call(this, n, G);
  }
  const F = () => ze(Z, g = S._id, g), q = () => ze(Z, g = null, g), V = () => ie("rowclick", fe.actions.cleanRow(S));
  return n.$$set = (G) => {
    "row" in G && t(0, S = G.row), "top" in G && t(1, I = G.top);
  }, n.$$.update = () => {
    var G;
    n.$$.dirty[0] & /*row*/
    1 | n.$$.dirty[1] & /*$selectedRows*/
    256 && t(9, l = !!v[S._id]), n.$$.dirty[0] & /*$hoveredRowId, row, $isSelectingCells*/
    25 | n.$$.dirty[1] & /*$selectedCellCount*/
    128 && t(8, o = g === S._id && (!_ || !m)), n.$$.dirty[0] & /*row*/
    1 | n.$$.dirty[1] & /*$focusedRow*/
    64 && t(7, s = (d == null ? void 0 : d._id) === S._id), n.$$.dirty[1] & /*$reorder*/
    32 && t(6, i = f.sourceColumn), n.$$.dirty[1] & /*$props*/
    16 && t(34, r = ((G = c == null ? void 0 : c.buttons) == null ? void 0 : G.length) > 0), n.$$.dirty[0] & /*$buttonColumnWidth*/
    4 | n.$$.dirty[1] & /*hasButtons*/
    8 && t(5, u = r && a > 0);
  }, [
    S,
    I,
    a,
    m,
    g,
    u,
    i,
    s,
    o,
    l,
    R,
    b,
    y,
    k,
    h,
    C,
    N,
    P,
    T,
    H,
    z,
    Z,
    B,
    te,
    _e,
    ie,
    fe,
    ae,
    Re,
    Ce,
    ve,
    J,
    be,
    j,
    r,
    c,
    f,
    d,
    _,
    v,
    Q,
    F,
    q,
    V
  ];
}
class si extends De {
  constructor(e) {
    super(), Ne(this, e, oi, li, Ee, { row: 0, top: 1 }, null, [-1, -1]);
  }
}
function En(n, e, t) {
  var u;
  const l = n.slice();
  l[49] = e[t];
  const o = !!/*$selectedRows*/
  l[7][
    /*row*/
    l[49]._id
  ];
  l[50] = o;
  const s = (
    /*$hoveredRowId*/
    l[5] === /*row*/
    l[49]._id
  );
  l[51] = s;
  const i = (
    /*$focusedRow*/
    ((u = l[8]) == null ? void 0 : u._id) === /*row*/
    l[49]._id
  );
  l[52] = i;
  const r = (
    /*getButtonsForRow*/
    l[28](
      /*buttons*/
      l[4],
      /*row*/
      l[49]
    )
  );
  return l[53] = r, l;
}
function An(n, e, t) {
  const l = n.slice();
  return l[56] = e[t], l;
}
function ri(n) {
  let e, t, l, o = He(
    /*rowButtons*/
    n[53]
  ), s = [];
  for (let u = 0; u < o.length; u += 1)
    s[u] = Dn(An(n, o, u));
  const i = (u) => w(s[u], 1, 1, () => {
    s[u] = null;
  });
  let r = (
    /*rowButtons*/
    n[53].length === 0 && Nn()
  );
  return {
    c() {
      for (let u = 0; u < s.length; u += 1)
        s[u].c();
      e = x(), r && r.c(), t = Ae();
    },
    m(u, a) {
      for (let c = 0; c < s.length; c += 1)
        s[c] && s[c].m(u, a);
      M(u, e, a), r && r.m(u, a), M(u, t, a), l = !0;
    },
    p(u, a) {
      if (a[0] & /*getButtonsForRow, buttons, $renderedRows, handleClick*/
      805306448) {
        o = He(
          /*rowButtons*/
          u[53]
        );
        let c;
        for (c = 0; c < o.length; c += 1) {
          const f = An(u, o, c);
          s[c] ? (s[c].p(f, a), p(s[c], 1)) : (s[c] = Dn(f), s[c].c(), p(s[c], 1), s[c].m(e.parentNode, e));
        }
        for (he(), c = o.length; c < s.length; c += 1)
          i(c);
        we();
      }
      /*rowButtons*/
      u[53].length === 0 ? r || (r = Nn(), r.c(), r.m(t.parentNode, t)) : r && (r.d(1), r = null);
    },
    i(u) {
      if (!l) {
        for (let a = 0; a < o.length; a += 1)
          p(s[a]);
        l = !0;
      }
    },
    o(u) {
      s = s.filter(Boolean);
      for (let a = 0; a < s.length; a += 1)
        w(s[a]);
      l = !1;
    },
    d(u) {
      u && (E(e), E(t)), ct(s, u), r && r.d(u);
    }
  };
}
function ii(n) {
  let e, t, l, o;
  const s = [ai, ci], i = [];
  function r(u, a) {
    return (
      /*rowButtons*/
      u[53].length > 0 ? 0 : 1
    );
  }
  return e = r(n), t = i[e] = s[e](n), {
    c() {
      t.c(), l = Ae();
    },
    m(u, a) {
      i[e].m(u, a), M(u, l, a), o = !0;
    },
    p(u, a) {
      let c = e;
      e = r(u), e === c ? i[e].p(u, a) : (he(), w(i[c], 1, 1, () => {
        i[c] = null;
      }), we(), t = i[e], t ? t.p(u, a) : (t = i[e] = s[e](u), t.c()), p(t, 1), t.m(l.parentNode, l));
    },
    i(u) {
      o || (p(t), o = !0);
    },
    o(u) {
      w(t), o = !1;
    },
    d(u) {
      u && E(l), i[e].d(u);
    }
  };
}
function Ln(n) {
  let e, t;
  return {
    c() {
      e = $("i"), U(e, "class", t = /*button*/
      n[56].icon + " S svelte-1oqghfp");
    },
    m(l, o) {
      M(l, e, o);
    },
    p(l, o) {
      o[0] & /*buttons, $renderedRows*/
      80 && t !== (t = /*button*/
      l[56].icon + " S svelte-1oqghfp") && U(e, "class", t);
    },
    d(l) {
      l && E(e);
    }
  };
}
function ui(n) {
  let e, t = (
    /*button*/
    (n[56].text || "Button") + ""
  ), l, o = (
    /*button*/
    n[56].icon && Ln(n)
  );
  return {
    c() {
      o && o.c(), e = x(), l = de(t);
    },
    m(s, i) {
      o && o.m(s, i), M(s, e, i), M(s, l, i);
    },
    p(s, i) {
      /*button*/
      s[56].icon ? o ? o.p(s, i) : (o = Ln(s), o.c(), o.m(e.parentNode, e)) : o && (o.d(1), o = null), i[0] & /*buttons, $renderedRows*/
      80 && t !== (t = /*button*/
      (s[56].text || "Button") + "") && je(l, t);
    },
    d(s) {
      s && (E(e), E(l)), o && o.d(s);
    }
  };
}
function Dn(n) {
  let e, t;
  function l() {
    return (
      /*click_handler*/
      n[38](
        /*button*/
        n[56],
        /*row*/
        n[49]
      )
    );
  }
  return e = new Ht({
    props: {
      newStyles: !0,
      size: "S",
      cta: (
        /*button*/
        n[56].type === "cta"
      ),
      primary: (
        /*button*/
        n[56].type === "primary"
      ),
      secondary: (
        /*button*/
        n[56].type === "secondary"
      ),
      warning: (
        /*button*/
        n[56].type === "warning"
      ),
      overBackground: (
        /*button*/
        n[56].type === "overBackground"
      ),
      $$slots: { default: [ui] },
      $$scope: { ctx: n }
    }
  }), e.$on("click", l), {
    c() {
      W(e.$$.fragment);
    },
    m(o, s) {
      K(e, o, s), t = !0;
    },
    p(o, s) {
      n = o;
      const i = {};
      s[0] & /*buttons, $renderedRows*/
      80 && (i.cta = /*button*/
      n[56].type === "cta"), s[0] & /*buttons, $renderedRows*/
      80 && (i.primary = /*button*/
      n[56].type === "primary"), s[0] & /*buttons, $renderedRows*/
      80 && (i.secondary = /*button*/
      n[56].type === "secondary"), s[0] & /*buttons, $renderedRows*/
      80 && (i.warning = /*button*/
      n[56].type === "warning"), s[0] & /*buttons, $renderedRows*/
      80 && (i.overBackground = /*button*/
      n[56].type === "overBackground"), s[0] & /*buttons, $renderedRows*/
      80 | s[1] & /*$$scope*/
      268435456 && (i.$$scope = { dirty: s, ctx: n }), e.$set(i);
    },
    i(o) {
      t || (p(e.$$.fragment, o), t = !0);
    },
    o(o) {
      w(e.$$.fragment, o), t = !1;
    },
    d(o) {
      X(e, o);
    }
  };
}
function Nn(n) {
  let e;
  return {
    c() {
      e = $("div"), U(e, "class", "button-placeholder svelte-1oqghfp");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function ci(n) {
  let e;
  return {
    c() {
      e = $("div"), U(e, "class", "button-placeholder-collapsed svelte-1oqghfp");
    },
    m(t, l) {
      M(t, e, l);
    },
    p: Oe,
    i: Oe,
    o: Oe,
    d(t) {
      t && E(e);
    }
  };
}
function ai(n) {
  let e, t;
  function l() {
    return (
      /*mouseenter_handler*/
      n[37](
        /*row*/
        n[49]
      )
    );
  }
  return e = new Ko({
    props: {
      buttons: (
        /*makeCollapsedButtons*/
        n[30](
          /*rowButtons*/
          n[53],
          /*row*/
          n[49]
        )
      ),
      text: (
        /*$props*/
        n[1].buttonsCollapsedText || "Action"
      ),
      align: "right",
      offset: 5,
      size: "S",
      animate: !1
    }
  }), e.$on("mouseenter", l), {
    c() {
      W(e.$$.fragment);
    },
    m(o, s) {
      K(e, o, s), t = !0;
    },
    p(o, s) {
      n = o;
      const i = {};
      s[0] & /*buttons, $renderedRows*/
      80 && (i.buttons = /*makeCollapsedButtons*/
      n[30](
        /*rowButtons*/
        n[53],
        /*row*/
        n[49]
      )), s[0] & /*$props*/
      2 && (i.text = /*$props*/
      n[1].buttonsCollapsedText || "Action"), e.$set(i);
    },
    i(o) {
      t || (p(e.$$.fragment, o), t = !0);
    },
    o(o) {
      w(e.$$.fragment, o), t = !1;
    },
    d(o) {
      X(e, o);
    }
  };
}
function fi(n) {
  let e, t, l, o;
  const s = [ii, ri], i = [];
  function r(u, a) {
    return (
      /*$props*/
      u[1].buttonsCollapsed ? 0 : 1
    );
  }
  return t = r(n), l = i[t] = s[t](n), {
    c() {
      e = $("div"), l.c(), U(e, "class", "buttons svelte-1oqghfp"), ne(
        e,
        "offset",
        /*$showVScrollbar*/
        n[10] && /*$showHScrollbar*/
        n[11]
      );
    },
    m(u, a) {
      M(u, e, a), i[t].m(e, null), o = !0;
    },
    p(u, a) {
      let c = t;
      t = r(u), t === c ? i[t].p(u, a) : (he(), w(i[c], 1, 1, () => {
        i[c] = null;
      }), we(), l = i[t], l ? l.p(u, a) : (l = i[t] = s[t](u), l.c()), p(l, 1), l.m(e, null)), (!o || a[0] & /*$showVScrollbar, $showHScrollbar*/
      3072) && ne(
        e,
        "offset",
        /*$showVScrollbar*/
        u[10] && /*$showHScrollbar*/
        u[11]
      );
    },
    i(u) {
      o || (p(l), o = !0);
    },
    o(u) {
      w(l), o = !1;
    },
    d(u) {
      u && E(e), i[t].d();
    }
  };
}
function On(n) {
  var r;
  let e, t, l, o, s;
  t = new wt({
    props: {
      width: "100%",
      rowIdx: (
        /*row*/
        n[49].__idx
      ),
      selected: (
        /*rowSelected*/
        n[50]
      ),
      highlighted: (
        /*rowHovered*/
        n[51] || /*rowFocused*/
        n[52]
      ),
      metadata: (
        /*row*/
        (r = n[49].__metadata) == null ? void 0 : r.row
      ),
      $$slots: { default: [fi] },
      $$scope: { ctx: n }
    }
  });
  function i() {
    return (
      /*mouseenter_handler_1*/
      n[39](
        /*row*/
        n[49]
      )
    );
  }
  return {
    c() {
      e = $("div"), W(t.$$.fragment), U(e, "class", "row svelte-1oqghfp");
    },
    m(u, a) {
      M(u, e, a), K(t, e, null), l = !0, o || (s = [
        ke(e, "mouseenter", function() {
          Ue(
            /*$isDragging*/
            n[9] ? null : i
          ) && /*$isDragging*/
          (n[9] ? null : i).apply(this, arguments);
        }),
        ke(e, "mouseleave", function() {
          Ue(
            /*$isDragging*/
            n[9] ? null : (
              /*mouseleave_handler*/
              n[40]
            )
          ) && /*$isDragging*/
          (n[9] ? null : (
            /*mouseleave_handler*/
            n[40]
          )).apply(this, arguments);
        })
      ], o = !0);
    },
    p(u, a) {
      var f;
      n = u;
      const c = {};
      a[0] & /*$renderedRows*/
      64 && (c.rowIdx = /*row*/
      n[49].__idx), a[0] & /*$selectedRows, $renderedRows*/
      192 && (c.selected = /*rowSelected*/
      n[50]), a[0] & /*$hoveredRowId, $renderedRows, $focusedRow*/
      352 && (c.highlighted = /*rowHovered*/
      n[51] || /*rowFocused*/
      n[52]), a[0] & /*$renderedRows*/
      64 && (c.metadata = /*row*/
      (f = n[49].__metadata) == null ? void 0 : f.row), a[0] & /*$showVScrollbar, $showHScrollbar, buttons, $renderedRows, $props, $hoveredRowId*/
      3186 | a[1] & /*$$scope*/
      268435456 && (c.$$scope = { dirty: a, ctx: n }), t.$set(c);
    },
    i(u) {
      l || (p(t.$$.fragment, u), l = !0);
    },
    o(u) {
      w(t.$$.fragment, u), l = !1;
    },
    d(u) {
      u && E(e), X(t), o = !1, lt(s);
    }
  };
}
function Tn(n) {
  let e, t, l, o, s;
  return t = new wt({
    props: {
      width: "100%",
      highlighted: (
        /*$hoveredRowId*/
        n[5] === ut
      )
    }
  }), t.$on(
    "click",
    /*click_handler_1*/
    n[41]
  ), {
    c() {
      e = $("div"), W(t.$$.fragment), U(e, "class", "row blank svelte-1oqghfp");
    },
    m(i, r) {
      M(i, e, r), K(t, e, null), l = !0, o || (s = [
        ke(e, "mouseenter", function() {
          Ue(
            /*$isDragging*/
            n[9] ? null : (
              /*mouseenter_handler_2*/
              n[42]
            )
          ) && /*$isDragging*/
          (n[9] ? null : (
            /*mouseenter_handler_2*/
            n[42]
          )).apply(this, arguments);
        }),
        ke(e, "mouseleave", function() {
          Ue(
            /*$isDragging*/
            n[9] ? null : (
              /*mouseleave_handler_1*/
              n[43]
            )
          ) && /*$isDragging*/
          (n[9] ? null : (
            /*mouseleave_handler_1*/
            n[43]
          )).apply(this, arguments);
        })
      ], o = !0);
    },
    p(i, r) {
      n = i;
      const u = {};
      r[0] & /*$hoveredRowId*/
      32 && (u.highlighted = /*$hoveredRowId*/
      n[5] === ut), t.$set(u);
    },
    i(i) {
      l || (p(t.$$.fragment, i), l = !0);
    },
    o(i) {
      w(t.$$.fragment, i), l = !1;
    },
    d(i) {
      i && E(e), X(t), o = !1, lt(s);
    }
  };
}
function di(n) {
  let e, t, l, o = He(
    /*$renderedRows*/
    n[6]
  ), s = [];
  for (let u = 0; u < o.length; u += 1)
    s[u] = On(En(n, o, u));
  const i = (u) => w(s[u], 1, 1, () => {
    s[u] = null;
  });
  let r = (
    /*$config*/
    n[12].canAddRows && Tn(n)
  );
  return {
    c() {
      for (let u = 0; u < s.length; u += 1)
        s[u].c();
      e = x(), r && r.c(), t = Ae();
    },
    m(u, a) {
      for (let c = 0; c < s.length; c += 1)
        s[c] && s[c].m(u, a);
      M(u, e, a), r && r.m(u, a), M(u, t, a), l = !0;
    },
    p(u, a) {
      if (a[0] & /*$isDragging, $hoveredRowId, $renderedRows, $selectedRows, $focusedRow, $showVScrollbar, $showHScrollbar, makeCollapsedButtons, getButtonsForRow, buttons, $props, handleClick*/
      1879052274) {
        o = He(
          /*$renderedRows*/
          u[6]
        );
        let c;
        for (c = 0; c < o.length; c += 1) {
          const f = En(u, o, c);
          s[c] ? (s[c].p(f, a), p(s[c], 1)) : (s[c] = On(f), s[c].c(), p(s[c], 1), s[c].m(e.parentNode, e));
        }
        for (he(), c = o.length; c < s.length; c += 1)
          i(c);
        we();
      }
      /*$config*/
      u[12].canAddRows ? r ? (r.p(u, a), a[0] & /*$config*/
      4096 && p(r, 1)) : (r = Tn(u), r.c(), p(r, 1), r.m(t.parentNode, t)) : r && (he(), w(r, 1, 1, () => {
        r = null;
      }), we());
    },
    i(u) {
      if (!l) {
        for (let a = 0; a < o.length; a += 1)
          p(s[a]);
        p(r), l = !0;
      }
    },
    o(u) {
      s = s.filter(Boolean);
      for (let a = 0; a < s.length; a += 1)
        w(s[a]);
      w(r), l = !1;
    },
    d(u) {
      u && (E(e), E(t)), ct(s, u), r && r.d(u);
    }
  };
}
function mi(n) {
  let e, t, l, o, s, i, r;
  function u(c) {
    n[44](c);
  }
  let a = {
    scrollVertically: !0,
    attachHandlers: !0,
    $$slots: { default: [di] },
    $$scope: { ctx: n }
  };
  return (
    /*container*/
    n[2] !== void 0 && (a.ref = /*container*/
    n[2]), l = new Et({ props: a }), $e.push(() => Bt(l, "ref", u)), {
      c() {
        e = $("div"), t = $("div"), W(l.$$.fragment), U(t, "class", "content svelte-1oqghfp"), U(e, "class", "button-column svelte-1oqghfp"), Ie(
          e,
          "left",
          /*left*/
          n[3] + "px"
        ), ne(
          e,
          "hidden",
          /*$buttonColumnWidth*/
          n[0] === 0
        );
      },
      m(c, f) {
        M(c, e, f), le(e, t), K(l, t, null), s = !0, i || (r = ke(
          t,
          "mouseleave",
          /*mouseleave_handler_2*/
          n[45]
        ), i = !0);
      },
      p(c, f) {
        const d = {};
        f[0] & /*$isDragging, $hoveredRowId, $config, $renderedRows, $selectedRows, $focusedRow, $showVScrollbar, $showHScrollbar, buttons, $props*/
        8178 | f[1] & /*$$scope*/
        268435456 && (d.$$scope = { dirty: f, ctx: c }), !o && f[0] & /*container*/
        4 && (o = !0, d.ref = /*container*/
        c[2], en(() => o = !1)), l.$set(d), (!s || f[0] & /*left*/
        8) && Ie(
          e,
          "left",
          /*left*/
          c[3] + "px"
        ), (!s || f[0] & /*$buttonColumnWidth*/
        1) && ne(
          e,
          "hidden",
          /*$buttonColumnWidth*/
          c[0] === 0
        );
      },
      i(c) {
        s || (p(l.$$.fragment, c), s = !0);
      },
      o(c) {
        w(l.$$.fragment, c), s = !1;
      },
      d(c) {
        c && E(e), X(l), i = !1, r();
      }
    }
  );
}
function _i(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, m, _, g, v, R, b, y, k, h;
  const { renderedRows: C, hoveredRowId: N, props: S, width: I, rows: P, focusedRow: T, selectedRows: H, scrollableColumns: z, scrollLeft: Z, isDragging: B, buttonColumnWidth: te, showVScrollbar: _e, showHScrollbar: ie, dispatch: fe, config: ae, metadata: Re } = Te("grid");
  A(n, C, (D) => t(6, g = D)), A(n, N, (D) => t(5, _ = D)), A(n, S, (D) => t(1, m = D)), A(n, I, (D) => t(34, c = D)), A(n, T, (D) => t(8, R = D)), A(n, H, (D) => t(7, v = D)), A(n, z, (D) => t(36, d = D)), A(n, Z, (D) => t(35, f = D)), A(n, B, (D) => t(9, b = D)), A(n, te, (D) => t(0, a = D)), A(n, _e, (D) => t(10, y = D)), A(n, ie, (D) => t(11, k = D)), A(n, ae, (D) => t(12, h = D)), A(n, Re, (D) => t(46, u = D));
  let Ce;
  const ve = ({ buttons: D, buttonsCollapsed: re }) => {
    let oe = D || [];
    return re ? oe : oe.slice(0, 3);
  }, J = (D, re) => {
    var ye;
    if (!D || !re)
      return D;
    const oe = ((ye = u == null ? void 0 : u[re._id]) == null ? void 0 : ye.button) || {};
    return D.map((Le, qe) => {
      const Ve = oe[qe];
      return Ve ? Ve.hidden ? null : { ...Le, ...Ve } : Le;
    }).filter((Le) => Le !== null);
  }, be = async (D, re) => {
    var oe;
    await ((oe = D.onClick) == null ? void 0 : oe.call(D, P.actions.cleanRow(re))), await P.actions.refreshRow(re._id);
  }, j = (D, re) => D.map((oe) => ({
    ...oe,
    onClick: () => be(oe, re)
  }));
  it(() => {
    new ResizeObserver((re) => {
      var ye, Le;
      const oe = ((Le = (ye = re == null ? void 0 : re[0]) == null ? void 0 : ye.contentRect) == null ? void 0 : Le.width) ?? 0;
      te.set(oe - 1);
    }).observe(Ce);
  });
  const Q = (D) => ze(N, _ = D._id, _), F = (D, re) => be(D, re), q = (D) => ze(N, _ = D._id, _), V = () => ze(N, _ = null, _), G = () => fe("add-row-inline"), O = () => ze(N, _ = ut, _), se = () => ze(N, _ = null, _);
  function ge(D) {
    Ce = D, t(2, Ce);
  }
  const ue = () => ze(N, _ = null, _);
  return n.$$.update = () => {
    n.$$.dirty[0] & /*$props*/
    2 && t(4, l = ve(m)), n.$$.dirty[1] & /*$scrollableColumns*/
    32 && t(33, o = d.reduce((D, re) => D += re.width, 0)), n.$$.dirty[1] & /*columnsWidth, $scrollLeft*/
    20 && t(32, s = o - f - 1), n.$$.dirty[0] & /*$buttonColumnWidth*/
    1 | n.$$.dirty[1] & /*$width*/
    8 && t(31, i = c - a - 1), n.$$.dirty[1] & /*columnEnd, gridEnd*/
    3 && t(3, r = Math.min(s, i));
  }, [
    a,
    m,
    Ce,
    r,
    l,
    _,
    g,
    v,
    R,
    b,
    y,
    k,
    h,
    C,
    N,
    S,
    I,
    T,
    H,
    z,
    Z,
    B,
    te,
    _e,
    ie,
    fe,
    ae,
    Re,
    J,
    be,
    j,
    i,
    s,
    o,
    c,
    f,
    d,
    Q,
    F,
    q,
    V,
    G,
    O,
    se,
    ge,
    ue
  ];
}
class gi extends De {
  constructor(e) {
    super(), Ne(this, e, _i, mi, Ee, {}, null, [-1, -1]);
  }
}
function zn(n, e, t) {
  const l = n.slice();
  return l[21] = e[t], l[23] = t, l;
}
function Pn(n) {
  let e, t;
  return e = new si({
    props: {
      row: (
        /*row*/
        n[21]
      ),
      top: (
        /*idx*/
        n[23] === 0
      )
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*$renderedRows*/
      4 && (s.row = /*row*/
      l[21]), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Hn(n) {
  let e, t, l, o, s;
  return t = new wt({
    props: {
      width: (
        /*columnsWidth*/
        n[1]
      ),
      highlighted: (
        /*$hoveredRowId*/
        n[5] === ut
      )
    }
  }), t.$on(
    "click",
    /*click_handler*/
    n[15]
  ), {
    c() {
      e = $("div"), W(t.$$.fragment), U(e, "class", "row blank svelte-17lftvb");
    },
    m(i, r) {
      M(i, e, r), K(t, e, null), l = !0, o || (s = [
        ke(e, "mouseenter", function() {
          Ue(
            /*$isDragging*/
            n[4] ? null : (
              /*mouseenter_handler*/
              n[16]
            )
          ) && /*$isDragging*/
          (n[4] ? null : (
            /*mouseenter_handler*/
            n[16]
          )).apply(this, arguments);
        }),
        ke(e, "mouseleave", function() {
          Ue(
            /*$isDragging*/
            n[4] ? null : (
              /*mouseleave_handler*/
              n[17]
            )
          ) && /*$isDragging*/
          (n[4] ? null : (
            /*mouseleave_handler*/
            n[17]
          )).apply(this, arguments);
        })
      ], o = !0);
    },
    p(i, r) {
      n = i;
      const u = {};
      r & /*columnsWidth*/
      2 && (u.width = /*columnsWidth*/
      n[1]), r & /*$hoveredRowId*/
      32 && (u.highlighted = /*$hoveredRowId*/
      n[5] === ut), t.$set(u);
    },
    i(i) {
      l || (p(t.$$.fragment, i), l = !0);
    },
    o(i) {
      w(t.$$.fragment, i), l = !1;
    },
    d(i) {
      i && E(e), X(t), o = !1, lt(s);
    }
  };
}
function pi(n) {
  let e, t, l, o = He(
    /*$renderedRows*/
    n[2]
  ), s = [];
  for (let u = 0; u < o.length; u += 1)
    s[u] = Pn(zn(n, o, u));
  const i = (u) => w(s[u], 1, 1, () => {
    s[u] = null;
  });
  let r = (
    /*$config*/
    n[3].canAddRows && Hn(n)
  );
  return {
    c() {
      for (let u = 0; u < s.length; u += 1)
        s[u].c();
      e = x(), r && r.c(), t = Ae();
    },
    m(u, a) {
      for (let c = 0; c < s.length; c += 1)
        s[c] && s[c].m(u, a);
      M(u, e, a), r && r.m(u, a), M(u, t, a), l = !0;
    },
    p(u, a) {
      if (a & /*$renderedRows*/
      4) {
        o = He(
          /*$renderedRows*/
          u[2]
        );
        let c;
        for (c = 0; c < o.length; c += 1) {
          const f = zn(u, o, c);
          s[c] ? (s[c].p(f, a), p(s[c], 1)) : (s[c] = Pn(f), s[c].c(), p(s[c], 1), s[c].m(e.parentNode, e));
        }
        for (he(), c = o.length; c < s.length; c += 1)
          i(c);
        we();
      }
      /*$config*/
      u[3].canAddRows ? r ? (r.p(u, a), a & /*$config*/
      8 && p(r, 1)) : (r = Hn(u), r.c(), p(r, 1), r.m(t.parentNode, t)) : r && (he(), w(r, 1, 1, () => {
        r = null;
      }), we());
    },
    i(u) {
      if (!l) {
        for (let a = 0; a < o.length; a += 1)
          p(s[a]);
        p(r), l = !0;
      }
    },
    o(u) {
      s = s.filter(Boolean);
      for (let a = 0; a < s.length; a += 1)
        w(s[a]);
      w(r), l = !1;
    },
    d(u) {
      u && (E(e), E(t)), ct(s, u), r && r.d(u);
    }
  };
}
function Fn(n) {
  let e, t;
  return e = new gi({}), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function hi(n) {
  var i;
  let e, t, l, o;
  t = new Et({
    props: {
      scrollHorizontally: !0,
      scrollVertically: !0,
      attachHandlers: !0,
      $$slots: { default: [pi] },
      $$scope: { ctx: n }
    }
  });
  let s = (
    /*$props*/
    ((i = n[6].buttons) == null ? void 0 : i.length) && Fn()
  );
  return {
    c() {
      e = $("div"), W(t.$$.fragment), l = x(), s && s.c(), U(e, "class", "grid-body svelte-17lftvb");
    },
    m(r, u) {
      M(r, e, u), K(t, e, null), le(e, l), s && s.m(e, null), n[18](e), o = !0;
    },
    p(r, [u]) {
      var c;
      const a = {};
      u & /*$$scope, $isDragging, $hoveredRowId, columnsWidth, $config, $renderedRows*/
      16777278 && (a.$$scope = { dirty: u, ctx: r }), t.$set(a), /*$props*/
      (c = r[6].buttons) != null && c.length ? s ? u & /*$props*/
      64 && p(s, 1) : (s = Fn(), s.c(), p(s, 1), s.m(e, null)) : s && (he(), w(s, 1, 1, () => {
        s = null;
      }), we());
    },
    i(r) {
      o || (p(t.$$.fragment, r), p(s), o = !0);
    },
    o(r) {
      w(t.$$.fragment, r), w(s), o = !1;
    },
    d(r) {
      r && E(e), X(t), s && s.d(), n[18](null);
    }
  };
}
function wi(n, e, t) {
  let l, o, s, i, r, u, a;
  const { bounds: c, renderedRows: f, scrollableColumns: d, hoveredRowId: m, dispatch: _, isDragging: g, config: v, props: R } = Te("grid");
  A(n, f, (S) => t(2, s = S)), A(n, d, (S) => t(14, o = S)), A(n, m, (S) => t(5, u = S)), A(n, g, (S) => t(4, r = S)), A(n, v, (S) => t(3, i = S)), A(n, R, (S) => t(6, a = S));
  let b;
  const y = () => {
    c.set(b.getBoundingClientRect());
  };
  it(() => {
    const S = new ResizeObserver(y);
    return S.observe(b), window.addEventListener("wheel", y, !0), () => {
      S.disconnect(), window.removeEventListener("wheel", y, !0);
    };
  });
  const k = () => _("add-row-inline"), h = () => ze(m, u = ut, u), C = () => ze(m, u = null, u);
  function N(S) {
    $e[S ? "unshift" : "push"](() => {
      b = S, t(0, b);
    });
  }
  return n.$$.update = () => {
    n.$$.dirty & /*$scrollableColumns*/
    16384 && t(1, l = o.reduce((S, I) => S += I.width, 0));
  }, [
    b,
    l,
    s,
    i,
    r,
    u,
    a,
    f,
    d,
    m,
    _,
    g,
    v,
    R,
    o,
    k,
    h,
    C,
    N
  ];
}
class bi extends De {
  constructor(e) {
    super(), Ne(this, e, wi, hi, Ee, {});
  }
}
function Bn(n, e, t) {
  const l = n.slice();
  return l[12] = e[t], l;
}
function jn(n) {
  let e, t = He(
    /*$visibleColumns*/
    n[1]
  ), l = [];
  for (let o = 0; o < t.length; o += 1)
    l[o] = Vn(Bn(n, t, o));
  return {
    c() {
      for (let o = 0; o < l.length; o += 1)
        l[o].c();
      e = Ae();
    },
    m(o, s) {
      for (let i = 0; i < l.length; i += 1)
        l[i] && l[i].m(o, s);
      M(o, e, s);
    },
    p(o, s) {
      if (s & /*getStyle, $visibleColumns, $scrollLeft, $resize, resize*/
      286) {
        t = He(
          /*$visibleColumns*/
          o[1]
        );
        let i;
        for (i = 0; i < t.length; i += 1) {
          const r = Bn(o, t, i);
          l[i] ? l[i].p(r, s) : (l[i] = Vn(r), l[i].c(), l[i].m(e.parentNode, e));
        }
        for (; i < l.length; i += 1)
          l[i].d(1);
        l.length = t.length;
      }
    },
    d(o) {
      o && E(e), ct(l, o);
    }
  };
}
function Vn(n) {
  let e, t, l, o, s, i;
  function r(...c) {
    return (
      /*mousedown_handler*/
      n[9](
        /*column*/
        n[12],
        ...c
      )
    );
  }
  function u(...c) {
    return (
      /*touchstart_handler*/
      n[10](
        /*column*/
        n[12],
        ...c
      )
    );
  }
  function a() {
    return (
      /*dblclick_handler*/
      n[11](
        /*column*/
        n[12]
      )
    );
  }
  return {
    c() {
      e = $("div"), t = $("div"), l = x(), U(t, "class", "resize-indicator svelte-be62xg"), U(e, "class", "resize-slider svelte-be62xg"), U(e, "style", o = /*getStyle*/
      n[8](
        /*column*/
        n[12],
        /*$scrollLeft*/
        n[3]
      )), ne(
        e,
        "visible",
        /*$resize*/
        n[2].column === /*column*/
        n[12].name
      );
    },
    m(c, f) {
      M(c, e, f), le(e, t), le(e, l), s || (i = [
        ke(e, "mousedown", r),
        ke(e, "touchstart", u),
        ke(e, "dblclick", a)
      ], s = !0);
    },
    p(c, f) {
      n = c, f & /*$visibleColumns, $scrollLeft*/
      10 && o !== (o = /*getStyle*/
      n[8](
        /*column*/
        n[12],
        /*$scrollLeft*/
        n[3]
      )) && U(e, "style", o), f & /*$resize, $visibleColumns*/
      6 && ne(
        e,
        "visible",
        /*$resize*/
        n[2].column === /*column*/
        n[12].name
      );
    },
    d(c) {
      c && E(e), s = !1, lt(i);
    }
  };
}
function ki(n) {
  let e, t = !/*$isReordering*/
  n[0] && jn(n);
  return {
    c() {
      t && t.c(), e = Ae();
    },
    m(l, o) {
      t && t.m(l, o), M(l, e, o);
    },
    p(l, [o]) {
      /*$isReordering*/
      l[0] ? t && (t.d(1), t = null) : t ? t.p(l, o) : (t = jn(l), t.c(), t.m(e.parentNode, e));
    },
    i: Oe,
    o: Oe,
    d(l) {
      l && E(e), t && t.d(l);
    }
  };
}
function Ci(n, e, t) {
  let l, o, s, i;
  const { resize: r, visibleColumns: u, isReordering: a, scrollLeft: c } = Te("grid");
  return A(n, r, (g) => t(2, s = g)), A(n, u, (g) => t(1, o = g)), A(n, a, (g) => t(0, l = g)), A(n, c, (g) => t(3, i = g)), [
    l,
    o,
    s,
    i,
    r,
    u,
    a,
    c,
    (g, v) => {
      let R = g.__left + g.width;
      return g.primaryDisplay || (R -= v), `left:${R}px;`;
    },
    (g, v) => r.actions.startResizing(g, v),
    (g, v) => r.actions.startResizing(g, v),
    (g) => r.actions.resetSize(g)
  ];
}
class Ri extends De {
  constructor(e) {
    super(), Ne(this, e, Ci, ki, Ee, {});
  }
}
function Un(n) {
  let e, t, l;
  return t = new Et({
    props: {
      scrollVertically: !0,
      $$slots: { default: [vi] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      e = $("div"), W(t.$$.fragment), U(e, "class", "reorder-wrapper svelte-1e4eaad");
    },
    m(o, s) {
      M(o, e, s), K(t, e, null), l = !0;
    },
    p(o, s) {
      const i = {};
      s & /*$$scope, style*/
      2097154 && (i.$$scope = { dirty: s, ctx: o }), t.$set(i);
    },
    i(o) {
      l || (p(t.$$.fragment, o), l = !0);
    },
    o(o) {
      w(t.$$.fragment, o), l = !1;
    },
    d(o) {
      o && E(e), X(t);
    }
  };
}
function vi(n) {
  let e;
  return {
    c() {
      e = $("div"), U(e, "class", "reorder-overlay svelte-1e4eaad"), U(
        e,
        "style",
        /*style*/
        n[1]
      );
    },
    m(t, l) {
      M(t, e, l);
    },
    p(t, l) {
      l & /*style*/
      2 && U(
        e,
        "style",
        /*style*/
        t[1]
      );
    },
    d(t) {
      t && E(e);
    }
  };
}
function Si(n) {
  let e, t, l = (
    /*visible*/
    n[0] && Un(n)
  );
  return {
    c() {
      l && l.c(), e = Ae();
    },
    m(o, s) {
      l && l.m(o, s), M(o, e, s), t = !0;
    },
    p(o, [s]) {
      /*visible*/
      o[0] ? l ? (l.p(o, s), s & /*visible*/
      1 && p(l, 1)) : (l = Un(o), l.c(), p(l, 1), l.m(e.parentNode, e)) : l && (he(), w(l, 1, 1, () => {
        l = null;
      }), we());
    },
    i(o) {
      t || (p(l), t = !0);
    },
    o(o) {
      w(l), t = !1;
    },
    d(o) {
      o && E(e), l && l.d(o);
    }
  };
}
function yi(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, m, _, g;
  const { isReordering: v, reorder: R, columnLookupMap: b, rowHeight: y, renderedRows: k, scrollLeft: h, stickyWidth: C } = Te("grid");
  A(n, v, (S) => t(14, c = S)), A(n, R, (S) => t(18, _ = S)), A(n, b, (S) => t(19, g = S)), A(n, y, (S) => t(16, d = S)), A(n, k, (S) => t(15, f = S)), A(n, h, (S) => t(17, m = S)), A(n, C, (S) => t(13, a = S));
  const N = (S, I, P) => {
    if (!S)
      return 0;
    let T = S.__left - P;
    return I && (T += S.width), T;
  };
  return n.$$.update = () => {
    n.$$.dirty & /*$columnLookupMap, $reorder*/
    786432 && t(12, l = g[_.targetColumn]), n.$$.dirty & /*$reorder*/
    262144 && t(11, o = _.insertAfter), n.$$.dirty & /*targetColumn, insertAfter, $scrollLeft*/
    137216 && t(9, s = N(l, o, m)), n.$$.dirty & /*$rowHeight, $renderedRows*/
    98304 && t(10, i = d * f.length + St), n.$$.dirty & /*left, height*/
    1536 && t(1, r = `left:${s}px; height:${i}px;`), n.$$.dirty & /*$isReordering, left, $stickyWidth*/
    25088 && t(0, u = c && s >= a);
  }, [
    u,
    r,
    v,
    R,
    b,
    y,
    k,
    h,
    C,
    s,
    i,
    o,
    l,
    a,
    c,
    f,
    d,
    m,
    _,
    g
  ];
}
class Ii extends De {
  constructor(e) {
    super(), Ne(this, e, yi, Si, Ee, {});
  }
}
function Mi(n) {
  let e;
  return {
    c() {
      e = $("div"), U(e, "class", "grid-popover-container svelte-ws1j1t");
    },
    m(t, l) {
      M(t, e, l);
    },
    p: Oe,
    i: Oe,
    o: Oe,
    d(t) {
      t && E(e);
    }
  };
}
class Ei extends De {
  constructor(e) {
    super(), Ne(this, e, null, Mi, Ee, {});
  }
}
function qn(n) {
  let e, t;
  return e = new tn({
    props: {
      anchor: (
        /*anchor*/
        n[2]
      ),
      align: (
        /*$scrollableColumns*/
        n[1].length ? "right" : "left"
      ),
      maxHeight: null,
      resizable: !0,
      minWidth: 360,
      $$slots: { default: [Ai] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "close",
    /*close*/
    n[8]
  ), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*anchor*/
      4 && (s.anchor = /*anchor*/
      l[2]), o & /*$scrollableColumns*/
      2 && (s.align = /*$scrollableColumns*/
      l[1].length ? "right" : "left"), o & /*$$scope*/
      32768 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Ai(n) {
  let e, t;
  const l = (
    /*#slots*/
    n[13].default
  ), o = We(
    l,
    n,
    /*$$scope*/
    n[15],
    null
  );
  return {
    c() {
      e = $("div"), o && o.c(), U(e, "class", "content svelte-13f8h1i");
    },
    m(s, i) {
      M(s, e, i), o && o.m(e, null), t = !0;
    },
    p(s, i) {
      o && o.p && (!t || i & /*$$scope*/
      32768) && Ke(
        o,
        l,
        s,
        /*$$scope*/
        s[15],
        t ? Ye(
          l,
          /*$$scope*/
          s[15],
          i,
          null
        ) : Xe(
          /*$$scope*/
          s[15]
        ),
        null
      );
    },
    i(s) {
      t || (p(o, s), t = !0);
    },
    o(s) {
      w(o, s), t = !1;
    },
    d(s) {
      s && E(e), o && o.d(s);
    }
  };
}
function Li(n) {
  let e, t, l, o, s, i, r;
  t = new nt({ props: { name: "plus" } });
  let u = (
    /*isOpen*/
    n[0] && qn(n)
  );
  return {
    c() {
      e = $("div"), W(t.$$.fragment), l = x(), u && u.c(), o = Ae(), U(e, "id", "add-column-button"), U(e, "class", "add svelte-13f8h1i"), Ie(
        e,
        "left",
        /*left*/
        n[3] + "px"
      );
    },
    m(a, c) {
      M(a, e, c), K(t, e, null), n[14](e), M(a, l, c), u && u.m(a, c), M(a, o, c), s = !0, i || (r = ke(
        e,
        "click",
        /*open*/
        n[7]
      ), i = !0);
    },
    p(a, [c]) {
      (!s || c & /*left*/
      8) && Ie(
        e,
        "left",
        /*left*/
        a[3] + "px"
      ), /*isOpen*/
      a[0] ? u ? (u.p(a, c), c & /*isOpen*/
      1 && p(u, 1)) : (u = qn(a), u.c(), p(u, 1), u.m(o.parentNode, o)) : u && (he(), w(u, 1, 1, () => {
        u = null;
      }), we());
    },
    i(a) {
      s || (p(t.$$.fragment, a), p(u), s = !0);
    },
    o(a) {
      w(t.$$.fragment, a), w(u), s = !1;
    },
    d(a) {
      a && (E(e), E(l), E(o)), X(t), n[14](null), u && u.d(a), i = !1, r();
    }
  };
}
function Di(n, e, t) {
  let l, o, s, i, r, u, { $$slots: a = {}, $$scope: c } = e;
  const { scrollableColumns: f, scrollLeft: d, width: m, subscribe: _, ui: g, keyboardBlocked: v } = Te("grid");
  A(n, f, (C) => t(1, u = C)), A(n, d, (C) => t(12, r = C)), A(n, m, (C) => t(11, i = C));
  let R, b = !1;
  const y = () => {
    g.actions.blur(), t(0, b = !0);
  }, k = () => {
    t(0, b = !1);
  };
  it(() => _("close-edit-column", k));
  function h(C) {
    $e[C ? "unshift" : "push"](() => {
      R = C, t(2, R);
    });
  }
  return n.$$set = (C) => {
    "$$scope" in C && t(15, c = C.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*$scrollableColumns*/
    2 && t(10, l = u.reduce((C, N) => C += N.width, 0)), n.$$.dirty & /*columnsWidth, $scrollLeft*/
    5120 && t(9, o = l - 1 - r), n.$$.dirty & /*$width, end*/
    2560 && t(3, s = Math.min(i - 40, o)), n.$$.dirty & /*isOpen*/
    1 && v.set(b);
  }, [
    b,
    u,
    R,
    s,
    f,
    d,
    m,
    y,
    k,
    o,
    l,
    i,
    r,
    a,
    h,
    c
  ];
}
class Ni extends De {
  constructor(e) {
    super(), Ne(this, e, Di, Li, Ee, {});
  }
}
function Oi(n) {
  let e, t = (
    /*column*/
    n[0].schema.name + ""
  ), l, o, s, i, r, u, a;
  s = new xo({
    props: {
      type: "error",
      header: "Are you sure?",
      message: "This will leave bindings which utilised the user relationship column in a state where they will need to be updated to use the new column instead."
    }
  });
  function c(d) {
    n[5](d);
  }
  let f = {
    label: "New column name",
    error: (
      /*error*/
      n[2]
    )
  };
  return (
    /*newColumnName*/
    n[1] !== void 0 && (f.value = /*newColumnName*/
    n[1]), r = new Lo({ props: f }), $e.push(() => Bt(r, "value", c)), {
      c() {
        e = de('This operation will kick off a migration of the column "'), l = de(t), o = de(`"
  to a new column, with the name provided - this operation may take a moment to
  complete.

  `), W(s.$$.fragment), i = x(), W(r.$$.fragment);
      },
      m(d, m) {
        M(d, e, m), M(d, l, m), M(d, o, m), K(s, d, m), M(d, i, m), K(r, d, m), a = !0;
      },
      p(d, m) {
        (!a || m & /*column*/
        1) && t !== (t = /*column*/
        d[0].schema.name + "") && je(l, t);
        const _ = {};
        m & /*error*/
        4 && (_.error = /*error*/
        d[2]), !u && m & /*newColumnName*/
        2 && (u = !0, _.value = /*newColumnName*/
        d[1], en(() => u = !1)), r.$set(_);
      },
      i(d) {
        a || (p(s.$$.fragment, d), p(r.$$.fragment, d), a = !0);
      },
      o(d) {
        w(s.$$.fragment, d), w(r.$$.fragment, d), a = !1;
      },
      d(d) {
        d && (E(e), E(l), E(o), E(i)), X(s, d), X(r, d);
      }
    }
  );
}
function Ti(n) {
  let e, t;
  return e = new Ot({
    props: {
      title: "Migrate column",
      confirmText: "Continue",
      cancelText: "Cancel",
      onConfirm: (
        /*migrateUserColumn*/
        n[4]
      ),
      disabled: (
        /*error*/
        n[2] !== void 0
      ),
      size: "M",
      $$slots: { default: [Oi] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, [o]) {
      const s = {};
      o & /*error*/
      4 && (s.disabled = /*error*/
      l[2] !== void 0), o & /*$$scope, error, newColumnName, column*/
      1031 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function zi(n, e, t) {
  let l, o;
  const { API: s, definition: i, rows: r } = Te("grid");
  A(n, i, (m) => t(6, o = m));
  let { column: u } = e, a = `${u.schema.name} migrated`;
  const c = (m) => {
    if (m === "")
      return "Column name can't be empty.";
    if (m in o.schema)
      return "New column name can't be the same as an existing column name.";
    if (m.match(Do) === null)
      return "Illegal character; must be alpha-numeric.";
  }, f = async () => {
    try {
      await s.migrateColumn(o._id, u.schema.name, a), Ft.success("Column migrated");
    } catch (m) {
      Ft.error(`Failed to migrate: ${m.message}`);
    }
    await r.actions.refreshData();
  };
  function d(m) {
    a = m, t(1, a);
  }
  return n.$$set = (m) => {
    "column" in m && t(0, u = m.column);
  }, n.$$.update = () => {
    n.$$.dirty & /*newColumnName*/
    2 && t(2, l = c(a));
  }, [
    u,
    a,
    l,
    i,
    f,
    d
  ];
}
class Pi extends De {
  constructor(e) {
    super(), Ne(this, e, zi, Ti, Ee, { column: 0 });
  }
}
function Hi(n) {
  let e, t;
  return e = new Pi({ props: { column: (
    /*column*/
    n[0]
  ) } }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*column*/
      1 && (s.column = /*column*/
      l[0]), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Gn(n) {
  let e, t, l;
  return {
    c() {
      e = $("input"), U(e, "type", "text"), U(e, "data-grid-ignore", ""), U(e, "class", "svelte-1l2zxuu");
    },
    m(o, s) {
      M(o, e, s), n[50](e), on(
        e,
        /*searchValue*/
        n[3]
      ), t || (l = [
        ke(
          e,
          "input",
          /*input_1_input_handler*/
          n[51]
        ),
        ke(
          e,
          "blur",
          /*onBlurInput*/
          n[44]
        ),
        ke(
          e,
          "click",
          /*click_handler*/
          n[52]
        ),
        ke(
          e,
          "keydown",
          /*onInputKeyDown*/
          n[42]
        )
      ], t = !0);
    },
    p(o, s) {
      s[0] & /*searchValue*/
      8 && e.value !== /*searchValue*/
      o[3] && on(
        e,
        /*searchValue*/
        o[3]
      );
    },
    d(o) {
      o && E(e), n[50](null), t = !1, lt(l);
    }
  };
}
function Wn(n) {
  let e, t, l;
  return t = new nt({
    props: {
      name: hn(
        /*column*/
        n[0]
      ),
      size: "M",
      color: "var(--spectrum-global-color-gray-600)",
      hoverable: !0,
      hoverColor: "var(--spectrum-global-color-gray-800)"
    }
  }), {
    c() {
      e = $("div"), W(t.$$.fragment), U(e, "class", "column-icon svelte-1l2zxuu");
    },
    m(o, s) {
      M(o, e, s), K(t, e, null), l = !0;
    },
    p(o, s) {
      const i = {};
      s[0] & /*column*/
      1 && (i.name = hn(
        /*column*/
        o[0]
      )), t.$set(i);
    },
    i(o) {
      l || (p(t.$$.fragment, o), l = !0);
    },
    o(o) {
      w(t.$$.fragment, o), l = !1;
    },
    d(o) {
      o && E(e), X(t);
    }
  };
}
function Fi(n) {
  let e, t, l, o, s, i, r = (
    /*sortedBy*/
    n[16] && Kn(n)
  );
  return l = new nt({
    props: {
      hoverable: !0,
      size: "S",
      name: "dots-three-vertical"
    }
  }), {
    c() {
      r && r.c(), e = x(), t = $("div"), W(l.$$.fragment), U(t, "class", "more-icon svelte-1l2zxuu");
    },
    m(u, a) {
      r && r.m(u, a), M(u, e, a), M(u, t, a), K(l, t, null), o = !0, s || (i = ke(
        t,
        "click",
        /*click_handler_1*/
        n[53]
      ), s = !0);
    },
    p(u, a) {
      /*sortedBy*/
      u[16] ? r ? (r.p(u, a), a[0] & /*sortedBy*/
      65536 && p(r, 1)) : (r = Kn(u), r.c(), p(r, 1), r.m(e.parentNode, e)) : r && (he(), w(r, 1, 1, () => {
        r = null;
      }), we());
    },
    i(u) {
      o || (p(r), p(l.$$.fragment, u), o = !0);
    },
    o(u) {
      w(r), w(l.$$.fragment, u), o = !1;
    },
    d(u) {
      u && (E(e), E(t)), r && r.d(u), X(l), s = !1, i();
    }
  };
}
function Bi(n) {
  let e, t, l, o, s;
  return t = new nt({
    props: { hoverable: !0, size: "S", name: "x" }
  }), {
    c() {
      e = $("div"), W(t.$$.fragment), U(e, "class", "clear-icon svelte-1l2zxuu");
    },
    m(i, r) {
      M(i, e, r), K(t, e, null), l = !0, o || (s = ke(
        e,
        "click",
        /*stopSearching*/
        n[43]
      ), o = !0);
    },
    p: Oe,
    i(i) {
      l || (p(t.$$.fragment, i), l = !0);
    },
    o(i) {
      w(t.$$.fragment, i), l = !1;
    },
    d(i) {
      i && E(e), X(t), o = !1, s();
    }
  };
}
function Kn(n) {
  let e, t, l;
  return t = new nt({
    props: {
      hoverable: !0,
      size: "S",
      name: (
        /*$sort*/
        n[5].order === Ge.DESCENDING ? "sort-descending" : "sort-ascending"
      )
    }
  }), {
    c() {
      e = $("div"), W(t.$$.fragment), U(e, "class", "sort-indicator svelte-1l2zxuu");
    },
    m(o, s) {
      M(o, e, s), K(t, e, null), l = !0;
    },
    p(o, s) {
      const i = {};
      s[0] & /*$sort*/
      32 && (i.name = /*$sort*/
      o[5].order === Ge.DESCENDING ? "sort-descending" : "sort-ascending"), t.$set(i);
    },
    i(o) {
      l || (p(t.$$.fragment, o), l = !0);
    },
    o(o) {
      w(t.$$.fragment, o), l = !1;
    },
    d(o) {
      o && E(e), X(t);
    }
  };
}
function ji(n) {
  let e, t, l, o, s, i, r = (
    /*column*/
    n[0].label + ""
  ), u, a, c, f, d, m, _, g, v = (
    /*searching*/
    n[10] && Gn(n)
  ), R = !/*$config*/
  n[4].quiet && Wn(n);
  o = new nt({
    props: {
      hoverable: !0,
      size: "S",
      name: "magnifying-glass"
    }
  });
  const b = [Bi, Fi], y = [];
  function k(h, C) {
    return (
      /*searching*/
      h[10] ? 0 : 1
    );
  }
  return c = k(n), f = y[c] = b[c](n), {
    c() {
      v && v.c(), e = x(), R && R.c(), t = x(), l = $("div"), W(o.$$.fragment), s = x(), i = $("div"), u = de(r), a = x(), f.c(), d = Ae(), U(l, "class", "search-icon svelte-1l2zxuu"), U(i, "class", "name svelte-1l2zxuu");
    },
    m(h, C) {
      v && v.m(h, C), M(h, e, C), R && R.m(h, C), M(h, t, C), M(h, l, C), K(o, l, null), M(h, s, C), M(h, i, C), le(i, u), M(h, a, C), y[c].m(h, C), M(h, d, C), m = !0, _ || (g = ke(
        l,
        "click",
        /*startSearching*/
        n[41]
      ), _ = !0);
    },
    p(h, C) {
      /*searching*/
      h[10] ? v ? v.p(h, C) : (v = Gn(h), v.c(), v.m(e.parentNode, e)) : v && (v.d(1), v = null), /*$config*/
      h[4].quiet ? R && (he(), w(R, 1, 1, () => {
        R = null;
      }), we()) : R ? (R.p(h, C), C[0] & /*$config*/
      16 && p(R, 1)) : (R = Wn(h), R.c(), p(R, 1), R.m(t.parentNode, t)), (!m || C[0] & /*column*/
      1) && r !== (r = /*column*/
      h[0].label + "") && je(u, r);
      let N = c;
      c = k(h), c === N ? y[c].p(h, C) : (he(), w(y[N], 1, 1, () => {
        y[N] = null;
      }), we(), f = y[c], f ? f.p(h, C) : (f = y[c] = b[c](h), f.c()), p(f, 1), f.m(d.parentNode, d));
    },
    i(h) {
      m || (p(R), p(o.$$.fragment, h), p(f), m = !0);
    },
    o(h) {
      w(R), w(o.$$.fragment, h), w(f), m = !1;
    },
    d(h) {
      h && (E(e), E(t), E(l), E(s), E(i), E(a), E(d)), v && v.d(h), R && R.d(h), X(o), y[c].d(h), _ = !1, g();
    }
  };
}
function Xn(n) {
  let e, t;
  return e = new tn({
    props: {
      anchor: (
        /*anchor*/
        n[6]
      ),
      align: "left",
      maxHeight: null,
      resizable: !0,
      $$slots: { default: [xi] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "close",
    /*close*/
    n[28]
  ), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*anchor*/
      64 && (s.anchor = /*anchor*/
      l[6]), o[0] & /*editIsOpen, $config, column, canMoveRight, canMoveLeft, $sort, sortingLabels, editable*/
      59569 | o[1] & /*$$scope*/
      16777216 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Vi(n) {
  let e, t;
  return e = new xl({
    props: {
      $$slots: { default: [$i] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*$config, column, canMoveRight, canMoveLeft, $sort, sortingLabels, editable*/
      59441 | o[1] & /*$$scope*/
      16777216 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Ui(n) {
  let e, t;
  const l = (
    /*#slots*/
    n[48].default
  ), o = We(
    l,
    n,
    /*$$scope*/
    n[55],
    null
  );
  return {
    c() {
      e = $("div"), o && o.c(), U(e, "class", "content svelte-1l2zxuu");
    },
    m(s, i) {
      M(s, e, i), o && o.m(e, null), t = !0;
    },
    p(s, i) {
      o && o.p && (!t || i[1] & /*$$scope*/
      16777216) && Ke(
        o,
        l,
        s,
        /*$$scope*/
        s[55],
        t ? Ye(
          l,
          /*$$scope*/
          s[55],
          i,
          null
        ) : Xe(
          /*$$scope*/
          s[55]
        ),
        null
      );
    },
    i(s) {
      t || (p(o, s), t = !0);
    },
    o(s) {
      w(o, s), t = !1;
    },
    d(s) {
      s && E(e), o && o.d(s);
    }
  };
}
function Yn(n) {
  let e, t, l, o, s, i;
  return e = new Pe({
    props: {
      icon: "pencil",
      disabled: !/*editable*/
      n[11],
      $$slots: { default: [qi] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "click",
    /*editColumn*/
    n[29]
  ), l = new Pe({
    props: {
      icon: "copy",
      $$slots: { default: [Gi] },
      $$scope: { ctx: n }
    }
  }), l.$on(
    "click",
    /*duplicateColumn*/
    n[39]
  ), s = new Pe({
    props: {
      icon: "tag",
      disabled: !/*$config*/
      n[4].canEditColumns || /*column*/
      n[0].primaryDisplay || !an(
        /*column*/
        n[0].schema
      ),
      $$slots: { default: [Wi] },
      $$scope: { ctx: n }
    }
  }), s.$on(
    "click",
    /*makeDisplayColumn*/
    n[37]
  ), {
    c() {
      W(e.$$.fragment), t = x(), W(l.$$.fragment), o = x(), W(s.$$.fragment);
    },
    m(r, u) {
      K(e, r, u), M(r, t, u), K(l, r, u), M(r, o, u), K(s, r, u), i = !0;
    },
    p(r, u) {
      const a = {};
      u[0] & /*editable*/
      2048 && (a.disabled = !/*editable*/
      r[11]), u[1] & /*$$scope*/
      16777216 && (a.$$scope = { dirty: u, ctx: r }), e.$set(a);
      const c = {};
      u[1] & /*$$scope*/
      16777216 && (c.$$scope = { dirty: u, ctx: r }), l.$set(c);
      const f = {};
      u[0] & /*$config, column*/
      17 && (f.disabled = !/*$config*/
      r[4].canEditColumns || /*column*/
      r[0].primaryDisplay || !an(
        /*column*/
        r[0].schema
      )), u[1] & /*$$scope*/
      16777216 && (f.$$scope = { dirty: u, ctx: r }), s.$set(f);
    },
    i(r) {
      i || (p(e.$$.fragment, r), p(l.$$.fragment, r), p(s.$$.fragment, r), i = !0);
    },
    o(r) {
      w(e.$$.fragment, r), w(l.$$.fragment, r), w(s.$$.fragment, r), i = !1;
    },
    d(r) {
      r && (E(t), E(o)), X(e, r), X(l, r), X(s, r);
    }
  };
}
function qi(n) {
  let e;
  return {
    c() {
      e = de("Edit column");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function Gi(n) {
  let e;
  return {
    c() {
      e = de("Duplicate column");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function Wi(n) {
  let e;
  return {
    c() {
      e = de("Use as display column");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function Ki(n) {
  let e, t = (
    /*sortingLabels*/
    n[13].ascending + ""
  ), l;
  return {
    c() {
      e = de("Sort "), l = de(t);
    },
    m(o, s) {
      M(o, e, s), M(o, l, s);
    },
    p(o, s) {
      s[0] & /*sortingLabels*/
      8192 && t !== (t = /*sortingLabels*/
      o[13].ascending + "") && je(l, t);
    },
    d(o) {
      o && (E(e), E(l));
    }
  };
}
function Xi(n) {
  let e, t = (
    /*sortingLabels*/
    n[13].descending + ""
  ), l;
  return {
    c() {
      e = de("Sort "), l = de(t);
    },
    m(o, s) {
      M(o, e, s), M(o, l, s);
    },
    p(o, s) {
      s[0] & /*sortingLabels*/
      8192 && t !== (t = /*sortingLabels*/
      o[13].descending + "") && je(l, t);
    },
    d(o) {
      o && (E(e), E(l));
    }
  };
}
function Jn(n) {
  let e, t, l, o, s, i, r, u;
  e = new Pe({
    props: {
      disabled: !/*canMoveLeft*/
      n[15],
      icon: "caret-left",
      $$slots: { default: [Yi] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "click",
    /*moveLeft*/
    n[35]
  ), l = new Pe({
    props: {
      disabled: !/*canMoveRight*/
      n[14],
      icon: "caret-right",
      $$slots: { default: [Ji] },
      $$scope: { ctx: n }
    }
  }), l.$on(
    "click",
    /*moveRight*/
    n[36]
  ), s = new Pe({
    props: {
      disabled: !/*$config*/
      n[4].canEditColumns || /*column*/
      n[0].primaryDisplay || !/*$config*/
      n[4].canHideColumns,
      icon: "eye-slash",
      $$slots: { default: [Qi] },
      $$scope: { ctx: n }
    }
  }), s.$on(
    "click",
    /*hideColumn*/
    n[38]
  );
  let a = (
    /*$config*/
    n[4].canEditColumns && /*column*/
    n[0].schema.type === "link" && /*column*/
    n[0].schema.tableId === sn.USERS && !/*column*/
    n[0].schema.autocolumn && Qn(n)
  );
  return {
    c() {
      W(e.$$.fragment), t = x(), W(l.$$.fragment), o = x(), W(s.$$.fragment), i = x(), a && a.c(), r = Ae();
    },
    m(c, f) {
      K(e, c, f), M(c, t, f), K(l, c, f), M(c, o, f), K(s, c, f), M(c, i, f), a && a.m(c, f), M(c, r, f), u = !0;
    },
    p(c, f) {
      const d = {};
      f[0] & /*canMoveLeft*/
      32768 && (d.disabled = !/*canMoveLeft*/
      c[15]), f[1] & /*$$scope*/
      16777216 && (d.$$scope = { dirty: f, ctx: c }), e.$set(d);
      const m = {};
      f[0] & /*canMoveRight*/
      16384 && (m.disabled = !/*canMoveRight*/
      c[14]), f[1] & /*$$scope*/
      16777216 && (m.$$scope = { dirty: f, ctx: c }), l.$set(m);
      const _ = {};
      f[0] & /*$config, column*/
      17 && (_.disabled = !/*$config*/
      c[4].canEditColumns || /*column*/
      c[0].primaryDisplay || !/*$config*/
      c[4].canHideColumns), f[1] & /*$$scope*/
      16777216 && (_.$$scope = { dirty: f, ctx: c }), s.$set(_), /*$config*/
      c[4].canEditColumns && /*column*/
      c[0].schema.type === "link" && /*column*/
      c[0].schema.tableId === sn.USERS && !/*column*/
      c[0].schema.autocolumn ? a ? (a.p(c, f), f[0] & /*$config, column*/
      17 && p(a, 1)) : (a = Qn(c), a.c(), p(a, 1), a.m(r.parentNode, r)) : a && (he(), w(a, 1, 1, () => {
        a = null;
      }), we());
    },
    i(c) {
      u || (p(e.$$.fragment, c), p(l.$$.fragment, c), p(s.$$.fragment, c), p(a), u = !0);
    },
    o(c) {
      w(e.$$.fragment, c), w(l.$$.fragment, c), w(s.$$.fragment, c), w(a), u = !1;
    },
    d(c) {
      c && (E(t), E(o), E(i), E(r)), X(e, c), X(l, c), X(s, c), a && a.d(c);
    }
  };
}
function Yi(n) {
  let e;
  return {
    c() {
      e = de("Move left");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function Ji(n) {
  let e;
  return {
    c() {
      e = de("Move right");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function Qi(n) {
  let e;
  return {
    c() {
      e = de("Hide column");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function Qn(n) {
  let e, t;
  return e = new Pe({
    props: {
      icon: "user",
      $$slots: { default: [Zi] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "click",
    /*openMigrationModal*/
    n[40]
  ), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[1] & /*$$scope*/
      16777216 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Zi(n) {
  let e;
  return {
    c() {
      e = de("Migrate to user column");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function $i(n) {
  let e, t, l, o, s, i, r, u = (
    /*$config*/
    n[4].canEditColumns && Yn(n)
  );
  t = new Pe({
    props: {
      icon: "sort-ascending",
      disabled: !zt(
        /*column*/
        n[0].schema
      ) || /*column*/
      n[0].name === /*$sort*/
      n[5].column && /*$sort*/
      n[5].order === Ge.ASCENDING,
      $$slots: { default: [Ki] },
      $$scope: { ctx: n }
    }
  }), t.$on(
    "click",
    /*sortAscending*/
    n[33]
  ), o = new Pe({
    props: {
      icon: "sort-descending",
      disabled: !zt(
        /*column*/
        n[0].schema
      ) || /*column*/
      n[0].name === /*$sort*/
      n[5].column && /*$sort*/
      n[5].order === Ge.DESCENDING,
      $$slots: { default: [Xi] },
      $$scope: { ctx: n }
    }
  }), o.$on(
    "click",
    /*sortDescending*/
    n[34]
  );
  let a = (
    /*$config*/
    n[4].canEditColumns && Jn(n)
  );
  return {
    c() {
      u && u.c(), e = x(), W(t.$$.fragment), l = x(), W(o.$$.fragment), s = x(), a && a.c(), i = Ae();
    },
    m(c, f) {
      u && u.m(c, f), M(c, e, f), K(t, c, f), M(c, l, f), K(o, c, f), M(c, s, f), a && a.m(c, f), M(c, i, f), r = !0;
    },
    p(c, f) {
      /*$config*/
      c[4].canEditColumns ? u ? (u.p(c, f), f[0] & /*$config*/
      16 && p(u, 1)) : (u = Yn(c), u.c(), p(u, 1), u.m(e.parentNode, e)) : u && (he(), w(u, 1, 1, () => {
        u = null;
      }), we());
      const d = {};
      f[0] & /*column, $sort*/
      33 && (d.disabled = !zt(
        /*column*/
        c[0].schema
      ) || /*column*/
      c[0].name === /*$sort*/
      c[5].column && /*$sort*/
      c[5].order === Ge.ASCENDING), f[0] & /*sortingLabels*/
      8192 | f[1] & /*$$scope*/
      16777216 && (d.$$scope = { dirty: f, ctx: c }), t.$set(d);
      const m = {};
      f[0] & /*column, $sort*/
      33 && (m.disabled = !zt(
        /*column*/
        c[0].schema
      ) || /*column*/
      c[0].name === /*$sort*/
      c[5].column && /*$sort*/
      c[5].order === Ge.DESCENDING), f[0] & /*sortingLabels*/
      8192 | f[1] & /*$$scope*/
      16777216 && (m.$$scope = { dirty: f, ctx: c }), o.$set(m), /*$config*/
      c[4].canEditColumns ? a ? (a.p(c, f), f[0] & /*$config*/
      16 && p(a, 1)) : (a = Jn(c), a.c(), p(a, 1), a.m(i.parentNode, i)) : a && (he(), w(a, 1, 1, () => {
        a = null;
      }), we());
    },
    i(c) {
      r || (p(u), p(t.$$.fragment, c), p(o.$$.fragment, c), p(a), r = !0);
    },
    o(c) {
      w(u), w(t.$$.fragment, c), w(o.$$.fragment, c), w(a), r = !1;
    },
    d(c) {
      c && (E(e), E(l), E(s), E(i)), u && u.d(c), X(t, c), X(o, c), a && a.d(c);
    }
  };
}
function xi(n) {
  let e, t, l, o;
  const s = [Ui, Vi], i = [];
  function r(u, a) {
    return (
      /*editIsOpen*/
      u[7] ? 0 : 1
    );
  }
  return e = r(n), t = i[e] = s[e](n), {
    c() {
      t.c(), l = Ae();
    },
    m(u, a) {
      i[e].m(u, a), M(u, l, a), o = !0;
    },
    p(u, a) {
      let c = e;
      e = r(u), e === c ? i[e].p(u, a) : (he(), w(i[c], 1, 1, () => {
        i[c] = null;
      }), we(), t = i[e], t ? t.p(u, a) : (t = i[e] = s[e](u), t.c()), p(t, 1), t.m(l.parentNode, l));
    },
    i(u) {
      o || (p(t), o = !0);
    },
    o(u) {
      w(t), o = !1;
    },
    d(u) {
      u && E(l), i[e].d(u);
    }
  };
}
function eu(n) {
  let e, t, l, o, s, i, r, u, a, c = {
    $$slots: { default: [Hi] },
    $$scope: { ctx: n }
  };
  e = new Nt({ props: c }), n[49](e), o = new wt({
    props: {
      width: (
        /*column*/
        n[0].width
      ),
      left: (
        /*column*/
        n[0].__left
      ),
      defaultHeight: !0,
      center: !0,
      $$slots: { default: [ji] },
      $$scope: { ctx: n }
    }
  }), o.$on(
    "mousedown",
    /*onMouseDown*/
    n[30]
  ), o.$on(
    "mouseup",
    /*onMouseUp*/
    n[31]
  ), o.$on(
    "touchstart",
    /*onMouseDown*/
    n[30]
  ), o.$on(
    "touchend",
    /*onMouseUp*/
    n[31]
  ), o.$on(
    "touchcancel",
    /*onMouseUp*/
    n[31]
  ), o.$on(
    "contextmenu",
    /*onContextMenu*/
    n[32]
  );
  let f = (
    /*open*/
    n[2] && Xn(n)
  );
  return {
    c() {
      W(e.$$.fragment), t = x(), l = $("div"), W(o.$$.fragment), s = x(), f && f.c(), i = Ae(), U(l, "class", "header-cell svelte-1l2zxuu"), Ie(l, "flex", "0 0 " + /*column*/
      n[0].width + "px"), ne(
        l,
        "open",
        /*open*/
        n[2]
      ), ne(
        l,
        "searchable",
        /*searchable*/
        n[12]
      ), ne(
        l,
        "searching",
        /*searching*/
        n[10]
      ), ne(
        l,
        "disabled",
        /*$isReordering*/
        n[17] || /*$isResizing*/
        n[18]
      ), ne(
        l,
        "sticky",
        /*idx*/
        n[1] === "sticky"
      );
    },
    m(d, m) {
      K(e, d, m), M(d, t, m), M(d, l, m), K(o, l, null), n[54](l), M(d, s, m), f && f.m(d, m), M(d, i, m), r = !0, u || (a = ke(
        l,
        "dblclick",
        /*handleDoubleClick*/
        n[45]
      ), u = !0);
    },
    p(d, m) {
      const _ = {};
      m[0] & /*column*/
      1 | m[1] & /*$$scope*/
      16777216 && (_.$$scope = { dirty: m, ctx: d }), e.$set(_);
      const g = {};
      m[0] & /*column*/
      1 && (g.width = /*column*/
      d[0].width), m[0] & /*column*/
      1 && (g.left = /*column*/
      d[0].__left), m[0] & /*searching, open, $sort, sortedBy, column, $config, input, searchValue*/
      67133 | m[1] & /*$$scope*/
      16777216 && (g.$$scope = { dirty: m, ctx: d }), o.$set(g), (!r || m[0] & /*column*/
      1) && Ie(l, "flex", "0 0 " + /*column*/
      d[0].width + "px"), (!r || m[0] & /*open*/
      4) && ne(
        l,
        "open",
        /*open*/
        d[2]
      ), (!r || m[0] & /*searchable*/
      4096) && ne(
        l,
        "searchable",
        /*searchable*/
        d[12]
      ), (!r || m[0] & /*searching*/
      1024) && ne(
        l,
        "searching",
        /*searching*/
        d[10]
      ), (!r || m[0] & /*$isReordering, $isResizing*/
      393216) && ne(
        l,
        "disabled",
        /*$isReordering*/
        d[17] || /*$isResizing*/
        d[18]
      ), (!r || m[0] & /*idx*/
      2) && ne(
        l,
        "sticky",
        /*idx*/
        d[1] === "sticky"
      ), /*open*/
      d[2] ? f ? (f.p(d, m), m[0] & /*open*/
      4 && p(f, 1)) : (f = Xn(d), f.c(), p(f, 1), f.m(i.parentNode, i)) : f && (he(), w(f, 1, 1, () => {
        f = null;
      }), we());
    },
    i(d) {
      r || (p(e.$$.fragment, d), p(o.$$.fragment, d), p(f), r = !0);
    },
    o(d) {
      w(e.$$.fragment, d), w(o.$$.fragment, d), w(f), r = !1;
    },
    d(d) {
      d && (E(t), E(l), E(s), E(i)), n[49](null), X(e, d), X(o), n[54](null), f && f.d(d), u = !1, a();
    }
  };
}
function tu(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, m, _, g, v, R, b, y, { $$slots: k = {}, $$scope: h } = e, { column: C } = e, { idx: N } = e;
  const { reorder: S, isReordering: I, isResizing: P, sort: T, scrollableColumns: H, dispatch: z, subscribe: Z, config: B, ui: te, definition: _e, datasource: ie, schema: fe, focusedCellId: ae, filter: Re, inlineFilters: Ce, keyboardBlocked: ve } = Te("grid");
  A(n, I, (ce) => t(17, b = ce)), A(n, P, (ce) => t(18, y = ce)), A(n, T, (ce) => t(5, R = ce)), A(n, H, (ce) => t(47, v = ce)), A(n, B, (ce) => t(4, g = ce)), A(n, _e, (ce) => t(59, m = ce)), A(n, fe, (ce) => t(58, d = ce)), A(n, ae, (ce) => t(57, f = ce)), A(n, Ce, (ce) => t(60, _ = ce));
  const J = [
    Qe.STRING,
    Qe.OPTIONS,
    Qe.NUMBER,
    Qe.BIGINT,
    Qe.ARRAY,
    Qe.LONGFORM
  ];
  let be, j = !1, Q = !1, F, q, V, G;
  const O = () => {
    t(2, j = !1), t(7, Q = !1);
  }, se = (ce) => {
    var gt;
    if (ce.calculationType)
      return {
        ascending: "low-high",
        descending: "high-low"
      };
    let Je = (gt = ce.schema) == null ? void 0 : gt.type;
    switch (No(ce.schema) && (Je = ce.schema.responseType), Je) {
      case Qe.NUMBER:
      case Qe.BIGINT:
        return {
          ascending: "low-high",
          descending: "high-low"
        };
      case Qe.DATETIME:
        return {
          ascending: "old-new",
          descending: "new-old"
        };
      default:
        return { ascending: "A-Z", descending: "Z-A" };
    }
  }, ge = (ce) => {
    var Je;
    t(3, V = (Je = _ == null ? void 0 : _.find((gt) => gt.id === `inline-${ce}`)) == null ? void 0 : Je.value);
  }, ue = (ce) => {
    const { type: Je, formulaType: gt } = ce.schema;
    return J.includes(Je) || Je === Qe.FORMULA && gt === Oo.STATIC || Je === Qe.AI;
  }, D = async () => {
    t(7, Q = !0), await vt(), z("edit-column", C.schema);
  }, re = (ce) => {
    var Je;
    te.actions.blur(), ((Je = ce.touches) != null && Je.length || ce.button === 0) && a && (F = setTimeout(
      () => {
        S.actions.startReordering(C.name, ce);
      },
      200
    ));
  }, oe = () => {
    F && (clearTimeout(F), F = null);
  }, ye = (ce) => {
    ce.preventDefault(), setTimeout(
      () => {
        te.actions.blur(), t(2, j = !j);
      },
      10
    );
  }, Le = () => {
    T.set({
      column: C.name,
      order: Ge.ASCENDING
    }), t(2, j = !1);
  }, qe = () => {
    T.set({
      column: C.name,
      order: Ge.DESCENDING
    }), t(2, j = !1);
  }, Ve = () => {
    S.actions.moveColumnLeft(C.name), t(2, j = !1);
  }, bt = () => {
    S.actions.moveColumnRight(C.name), t(2, j = !1);
  }, pt = () => {
    ie.actions.changePrimaryDisplay(C.name), t(2, j = !1);
  }, at = () => {
    const { related: ce } = C, Je = { visible: !1 };
    ce ? ie.actions.addSubSchemaMutation(ce.subField, ce.field, Je) : ie.actions.addSchemaMutation(C.name, Je), ie.actions.saveSchemaMutations(), t(2, j = !1);
  }, ee = async () => {
    t(2, j = !1);
    let ce = `${C.name} copy`, Je = 2;
    for (; d[ce]; )
      ce = `${C.name} copy ${Je++}`;
    const gt = d[C.name];
    await ie.actions.saveDefinition({
      ...m,
      schema: {
        ...d,
        [ce]: {
          ...gt,
          name: ce,
          schema: { ...gt.schema }
        }
      }
    });
  }, ht = () => {
    q.show(), t(2, j = !1);
  }, At = async () => {
    ze(ae, f = null, f), t(3, V = ""), await vt(), G == null || G.focus();
  }, kt = (ce) => {
    ce.key === "Enter" ? et() : ce.key === "Escape" && (G == null || G.blur());
  }, Lt = () => {
    t(3, V = null), et();
  }, pe = () => {
    V === "" && t(3, V = null), et();
  }, et = () => {
    Re.actions.addInlineFilter(C, V);
  }, _t = Jl(et, 250), Y = () => {
    !c || u || (t(2, j = !0), D());
  };
  it(() => Z("close-edit-column", O));
  function Se(ce) {
    $e[ce ? "unshift" : "push"](() => {
      q = ce, t(8, q);
    });
  }
  function Fe(ce) {
    $e[ce ? "unshift" : "push"](() => {
      G = ce, t(9, G);
    });
  }
  function Be() {
    V = this.value, t(3, V);
  }
  const ot = () => ae.set(null), ft = () => t(2, j = !0);
  function ro(ce) {
    $e[ce ? "unshift" : "push"](() => {
      be = ce, t(6, be);
    });
  }
  return n.$$set = (ce) => {
    "column" in ce && t(0, C = ce.column), "idx" in ce && t(1, N = ce.idx), "$$scope" in ce && t(55, h = ce.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*column, $sort*/
    33 && t(16, l = C.name === R.column), n.$$.dirty[0] & /*column*/
    1 && t(46, a = !C.primaryDisplay), n.$$.dirty[0] & /*idx*/
    2 | n.$$.dirty[1] & /*orderable*/
    32768 && t(15, o = a && N > 0), n.$$.dirty[0] & /*idx*/
    2 | n.$$.dirty[1] & /*orderable, $scrollableColumns*/
    98304 && t(14, s = a && N < v.length - 1), n.$$.dirty[0] & /*column*/
    1 && t(13, i = se(C)), n.$$.dirty[0] & /*column*/
    1 && t(12, r = ue(C)), n.$$.dirty[0] & /*column*/
    1 && ge(C.name), n.$$.dirty[0] & /*searchValue*/
    8 && t(10, u = V != null), n.$$.dirty[0] & /*searchValue*/
    8 && _t(V), n.$$.dirty[0] & /*$config, column*/
    17 && t(11, c = g.canEditColumns && !C.schema.disabled), n.$$.dirty[0] & /*open*/
    4 && ve.set(j);
  }, [
    C,
    N,
    j,
    V,
    g,
    R,
    be,
    Q,
    q,
    G,
    u,
    c,
    r,
    i,
    s,
    o,
    l,
    b,
    y,
    I,
    P,
    T,
    H,
    B,
    _e,
    fe,
    ae,
    Ce,
    O,
    D,
    re,
    oe,
    ye,
    Le,
    qe,
    Ve,
    bt,
    pt,
    at,
    ee,
    ht,
    At,
    kt,
    Lt,
    pe,
    Y,
    a,
    v,
    k,
    Se,
    Fe,
    Be,
    ot,
    ft,
    ro,
    h
  ];
}
class so extends De {
  constructor(e) {
    super(), Ne(this, e, tu, eu, Ee, { column: 0, idx: 1 }, null, [-1, -1, -1]);
  }
}
const nu = (n) => ({}), Zn = (n) => ({});
function $n(n, e, t) {
  const l = n.slice();
  return l[12] = e[t], l[14] = t, l;
}
const lu = (n) => ({}), xn = (n) => ({});
function ou(n) {
  let e, t;
  const l = (
    /*#slots*/
    n[10]["edit-column"]
  ), o = We(
    l,
    n,
    /*$$scope*/
    n[11],
    xn
  );
  return {
    c() {
      o && o.c(), e = x();
    },
    m(s, i) {
      o && o.m(s, i), M(s, e, i), t = !0;
    },
    p(s, i) {
      o && o.p && (!t || i & /*$$scope*/
      2048) && Ke(
        o,
        l,
        s,
        /*$$scope*/
        s[11],
        t ? Ye(
          l,
          /*$$scope*/
          s[11],
          i,
          lu
        ) : Xe(
          /*$$scope*/
          s[11]
        ),
        xn
      );
    },
    i(s) {
      t || (p(o, s), t = !0);
    },
    o(s) {
      w(o, s), t = !1;
    },
    d(s) {
      s && E(e), o && o.d(s);
    }
  };
}
function el(n) {
  let e, t;
  return e = new so({
    props: {
      column: (
        /*column*/
        n[12]
      ),
      idx: (
        /*idx*/
        n[14]
      ),
      $$slots: { default: [ou] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*$scrollableColumns*/
      1 && (s.column = /*column*/
      l[12]), o & /*$$scope*/
      2048 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function su(n) {
  let e, t, l = He(
    /*$scrollableColumns*/
    n[0]
  ), o = [];
  for (let i = 0; i < l.length; i += 1)
    o[i] = el($n(n, l, i));
  const s = (i) => w(o[i], 1, 1, () => {
    o[i] = null;
  });
  return {
    c() {
      e = $("div");
      for (let i = 0; i < o.length; i += 1)
        o[i].c();
      U(e, "class", "row svelte-1rne7xg");
    },
    m(i, r) {
      M(i, e, r);
      for (let u = 0; u < o.length; u += 1)
        o[u] && o[u].m(e, null);
      t = !0;
    },
    p(i, r) {
      if (r & /*$scrollableColumns, $$scope*/
      2049) {
        l = He(
          /*$scrollableColumns*/
          i[0]
        );
        let u;
        for (u = 0; u < l.length; u += 1) {
          const a = $n(i, l, u);
          o[u] ? (o[u].p(a, r), p(o[u], 1)) : (o[u] = el(a), o[u].c(), p(o[u], 1), o[u].m(e, null));
        }
        for (he(), u = l.length; u < o.length; u += 1)
          s(u);
        we();
      }
    },
    i(i) {
      if (!t) {
        for (let r = 0; r < l.length; r += 1)
          p(o[r]);
        t = !0;
      }
    },
    o(i) {
      o = o.filter(Boolean);
      for (let r = 0; r < o.length; r += 1)
        w(o[r]);
      t = !1;
    },
    d(i) {
      i && E(e), ct(o, i);
    }
  };
}
function tl(n) {
  let e = (
    /*$datasource*/
    n[2]
  ), t, l, o = nl(n);
  return {
    c() {
      o.c(), t = Ae();
    },
    m(s, i) {
      o.m(s, i), M(s, t, i), l = !0;
    },
    p(s, i) {
      i & /*$datasource*/
      4 && Ee(e, e = /*$datasource*/
      s[2]) ? (he(), w(o, 1, 1, Oe), we(), o = nl(s), o.c(), p(o, 1), o.m(t.parentNode, t)) : o.p(s, i);
    },
    i(s) {
      l || (p(o), l = !0);
    },
    o(s) {
      w(o), l = !1;
    },
    d(s) {
      s && E(t), o.d(s);
    }
  };
}
function ru(n) {
  let e;
  const t = (
    /*#slots*/
    n[10]["add-column"]
  ), l = We(
    t,
    n,
    /*$$scope*/
    n[11],
    Zn
  );
  return {
    c() {
      l && l.c();
    },
    m(o, s) {
      l && l.m(o, s), e = !0;
    },
    p(o, s) {
      l && l.p && (!e || s & /*$$scope*/
      2048) && Ke(
        l,
        t,
        o,
        /*$$scope*/
        o[11],
        e ? Ye(
          t,
          /*$$scope*/
          o[11],
          s,
          nu
        ) : Xe(
          /*$$scope*/
          o[11]
        ),
        Zn
      );
    },
    i(o) {
      e || (p(l, o), e = !0);
    },
    o(o) {
      w(l, o), e = !1;
    },
    d(o) {
      l && l.d(o);
    }
  };
}
function iu(n) {
  let e, t;
  return e = new Ni({
    props: {
      $$slots: { default: [ru] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*$$scope*/
      2048 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function nl(n) {
  let e, t;
  return e = new eo({
    props: {
      text: "Click here to create your first column",
      type: Ql.Info,
      condition: !/*$hasNonAutoColumn*/
      n[3] && !/*$loading*/
      n[4],
      $$slots: { default: [iu] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*$hasNonAutoColumn, $loading*/
      24 && (s.condition = !/*$hasNonAutoColumn*/
      l[3] && !/*$loading*/
      l[4]), o & /*$$scope*/
      2048 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function uu(n) {
  let e, t, l, o;
  t = new Et({
    props: {
      scrollHorizontally: !0,
      $$slots: { default: [su] },
      $$scope: { ctx: n }
    }
  });
  let s = (
    /*$config*/
    n[1].canEditColumns && tl(n)
  );
  return {
    c() {
      e = $("div"), W(t.$$.fragment), l = x(), s && s.c(), U(e, "class", "header svelte-1rne7xg");
    },
    m(i, r) {
      M(i, e, r), K(t, e, null), le(e, l), s && s.m(e, null), o = !0;
    },
    p(i, [r]) {
      const u = {};
      r & /*$$scope, $scrollableColumns*/
      2049 && (u.$$scope = { dirty: r, ctx: i }), t.$set(u), /*$config*/
      i[1].canEditColumns ? s ? (s.p(i, r), r & /*$config*/
      2 && p(s, 1)) : (s = tl(i), s.c(), p(s, 1), s.m(e, null)) : s && (he(), w(s, 1, 1, () => {
        s = null;
      }), we());
    },
    i(i) {
      o || (p(t.$$.fragment, i), p(s), o = !0);
    },
    o(i) {
      w(t.$$.fragment, i), w(s), o = !1;
    },
    d(i) {
      i && E(e), X(t), s && s.d();
    }
  };
}
function cu(n, e, t) {
  let l, o, s, i, r, { $$slots: u = {}, $$scope: a } = e;
  const { scrollableColumns: c, config: f, hasNonAutoColumn: d, datasource: m, loading: _ } = Te("grid");
  return A(n, c, (g) => t(0, l = g)), A(n, f, (g) => t(1, o = g)), A(n, d, (g) => t(3, i = g)), A(n, m, (g) => t(2, s = g)), A(n, _, (g) => t(4, r = g)), n.$$set = (g) => {
    "$$scope" in g && t(11, a = g.$$scope);
  }, [
    l,
    o,
    s,
    i,
    r,
    c,
    f,
    d,
    m,
    _,
    u,
    a
  ];
}
class au extends De {
  constructor(e) {
    super(), Ne(this, e, cu, uu, Ee, {});
  }
}
function ll(n) {
  let e, t, l;
  return {
    c() {
      e = $("div"), U(e, "class", "v-scrollbar svelte-sio5lm"), Ie(
        e,
        "top",
        /*barTop*/
        n[5] + "px"
      ), Ie(
        e,
        "height",
        /*barHeight*/
        n[3] + "px"
      ), ne(
        e,
        "dragging",
        /*isDraggingV*/
        n[0]
      );
    },
    m(o, s) {
      M(o, e, s), t || (l = [
        ke(
          e,
          "mousedown",
          /*startVDragging*/
          n[20]
        ),
        ke(
          e,
          "touchstart",
          /*startVDragging*/
          n[20]
        )
      ], t = !0);
    },
    p(o, s) {
      s[0] & /*barTop*/
      32 && Ie(
        e,
        "top",
        /*barTop*/
        o[5] + "px"
      ), s[0] & /*barHeight*/
      8 && Ie(
        e,
        "height",
        /*barHeight*/
        o[3] + "px"
      ), s[0] & /*isDraggingV*/
      1 && ne(
        e,
        "dragging",
        /*isDraggingV*/
        o[0]
      );
    },
    d(o) {
      o && E(e), t = !1, lt(l);
    }
  };
}
function ol(n) {
  let e, t, l;
  return {
    c() {
      e = $("div"), U(e, "class", "h-scrollbar svelte-sio5lm"), Ie(
        e,
        "left",
        /*barLeft*/
        n[4] + "px"
      ), Ie(
        e,
        "width",
        /*barWidth*/
        n[2] + "px"
      ), ne(
        e,
        "dragging",
        /*isDraggingH*/
        n[1]
      );
    },
    m(o, s) {
      M(o, e, s), t || (l = [
        ke(
          e,
          "mousedown",
          /*startHDragging*/
          n[21]
        ),
        ke(
          e,
          "touchstart",
          /*startHDragging*/
          n[21]
        )
      ], t = !0);
    },
    p(o, s) {
      s[0] & /*barLeft*/
      16 && Ie(
        e,
        "left",
        /*barLeft*/
        o[4] + "px"
      ), s[0] & /*barWidth*/
      4 && Ie(
        e,
        "width",
        /*barWidth*/
        o[2] + "px"
      ), s[0] & /*isDraggingH*/
      2 && ne(
        e,
        "dragging",
        /*isDraggingH*/
        o[1]
      );
    },
    d(o) {
      o && E(e), t = !1, lt(l);
    }
  };
}
function fu(n) {
  let e, t, l = (
    /*$showVScrollbar*/
    n[6] && ll(n)
  ), o = (
    /*$showHScrollbar*/
    n[7] && ol(n)
  );
  return {
    c() {
      l && l.c(), e = x(), o && o.c(), t = Ae();
    },
    m(s, i) {
      l && l.m(s, i), M(s, e, i), o && o.m(s, i), M(s, t, i);
    },
    p(s, i) {
      /*$showVScrollbar*/
      s[6] ? l ? l.p(s, i) : (l = ll(s), l.c(), l.m(e.parentNode, e)) : l && (l.d(1), l = null), /*$showHScrollbar*/
      s[7] ? o ? o.p(s, i) : (o = ol(s), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null);
    },
    i: Oe,
    o: Oe,
    d(s) {
      s && (E(e), E(t)), l && l.d(s), o && o.d(s);
    }
  };
}
function du(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, m, _, g, v, R, b, y, k, h, C;
  const { scroll: N, contentHeight: S, maxScrollTop: I, contentWidth: P, maxScrollLeft: T, screenWidth: H, showHScrollbar: z, showVScrollbar: Z, scrollLeft: B, scrollTop: te, height: _e, isDragging: ie, menu: fe, focusedCellAPI: ae } = Te("grid");
  A(n, S, (O) => t(32, y = O)), A(n, I, (O) => t(28, m = O)), A(n, P, (O) => t(30, R = O)), A(n, T, (O) => t(26, f = O)), A(n, H, (O) => t(31, b = O)), A(n, z, (O) => t(7, C = O)), A(n, Z, (O) => t(6, h = O)), A(n, B, (O) => t(27, d = O)), A(n, te, (O) => t(29, _ = O)), A(n, _e, (O) => t(33, k = O)), A(n, fe, (O) => t(37, v = O)), A(n, ae, (O) => t(36, g = O));
  let Re, Ce, ve = !1, J = !1;
  const be = () => {
    v.visible && fe.actions.close(), g == null || g.blur();
  }, j = (O) => {
    O.preventDefault(), Re = Ct(O).y, Ce = _, document.addEventListener("mousemove", Q), document.addEventListener("touchmove", Q), document.addEventListener("mouseup", F), document.addEventListener("touchend", F), t(0, ve = !0), be();
  }, Q = Zt((O) => {
    const ge = (Ct(O).y - Re) / s, ue = Ce + ge * m;
    N.update((D) => ({
      ...D,
      top: Math.max(0, Math.min(ue, m))
    }));
  }), F = () => {
    document.removeEventListener("mousemove", Q), document.removeEventListener("touchmove", Q), document.removeEventListener("mouseup", F), document.removeEventListener("touchend", F), t(0, ve = !1);
  }, q = (O) => {
    O.preventDefault(), Re = Ct(O).x, Ce = d, document.addEventListener("mousemove", V), document.addEventListener("touchmove", V), document.addEventListener("mouseup", G), document.addEventListener("touchend", G), t(1, J = !0), be();
  }, V = Zt((O) => {
    const ge = (Ct(O).x - Re) / a, ue = Ce + ge * f;
    N.update((D) => ({
      ...D,
      left: Math.max(0, Math.min(ue, f))
    }));
  }), G = () => {
    document.removeEventListener("mousemove", V), document.removeEventListener("touchmove", V), document.removeEventListener("mouseup", G), document.removeEventListener("touchend", G), t(1, J = !1);
  };
  return n.$$.update = () => {
    n.$$.dirty[0] & /*isDraggingV, isDraggingH*/
    3 && ie.set(ve || J), n.$$.dirty[1] & /*$height*/
    4 && t(25, l = k - 2 * yt), n.$$.dirty[0] & /*renderHeight*/
    33554432 | n.$$.dirty[1] & /*$height, $contentHeight*/
    6 && t(3, o = Math.max(50, k / y * l)), n.$$.dirty[0] & /*renderHeight, barHeight*/
    33554440 && t(23, s = l - o), n.$$.dirty[0] & /*availHeight, $scrollTop, $maxScrollTop*/
    813694976 && t(5, i = yt + St + s * (_ / m)), n.$$.dirty[1] & /*$screenWidth*/
    1 && t(24, r = b - 2 * yt), n.$$.dirty[0] & /*$contentWidth, renderWidth*/
    1090519040 | n.$$.dirty[1] & /*$screenWidth*/
    1 && t(2, u = Math.max(50, b / R * r)), n.$$.dirty[0] & /*renderWidth, barWidth*/
    16777220 && t(22, a = r - u), n.$$.dirty[0] & /*availWidth, $scrollLeft, $maxScrollLeft*/
    205520896 && t(4, c = yt + a * (d / f));
  }, [
    ve,
    J,
    u,
    o,
    c,
    i,
    h,
    C,
    S,
    I,
    P,
    T,
    H,
    z,
    Z,
    B,
    te,
    _e,
    fe,
    ae,
    j,
    q,
    a,
    s,
    r,
    l,
    f,
    d,
    m,
    _,
    R,
    b,
    y,
    k
  ];
}
class mu extends De {
  constructor(e) {
    super(), Ne(this, e, du, fu, Ee, {}, null, [-1, -1]);
  }
}
function sl(n) {
  let e = (
    /*style*/
    n[4]
  ), t, l, o = il(n);
  return {
    c() {
      o.c(), t = Ae();
    },
    m(s, i) {
      o.m(s, i), M(s, t, i), l = !0;
    },
    p(s, i) {
      i[0] & /*style*/
      16 && Ee(e, e = /*style*/
      s[4]) ? (he(), w(o, 1, 1, Oe), we(), o = il(s), o.c(), p(o, 1), o.m(t.parentNode, t)) : o.p(s, i);
    },
    i(s) {
      l || (p(o), l = !0);
    },
    o(s) {
      w(o), l = !1;
    },
    d(s) {
      s && E(t), o.d(s);
    }
  };
}
function _u(n) {
  var b, y;
  let e, t, l, o, s, i, r, u, a, c, f, d, m, _, g, v;
  e = new Pe({
    props: {
      icon: "copy",
      disabled: !/*$copyAllowed*/
      n[8],
      $$slots: { default: [hu] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "click",
    /*click_handler_5*/
    n[36]
  ), e.$on(
    "click",
    /*menu*/
    n[13].actions.close
  ), l = new Pe({
    props: {
      icon: "clipboard-text",
      disabled: !/*$pasteAllowed*/
      n[9],
      $$slots: { default: [wu] },
      $$scope: { ctx: n }
    }
  }), l.$on(
    "click",
    /*click_handler_6*/
    n[37]
  ), l.$on(
    "click",
    /*menu*/
    n[13].actions.close
  ), s = new Pe({
    props: {
      icon: "arrows-out-simple",
      disabled: (
        /*isNewRow*/
        n[3] || !/*$config*/
        n[6].canEditRows || !/*$config*/
        n[6].canExpandRows
      ),
      $$slots: { default: [bu] },
      $$scope: { ctx: n }
    }
  }), s.$on(
    "click",
    /*click_handler_7*/
    n[38]
  ), s.$on(
    "click",
    /*menu*/
    n[13].actions.close
  ), r = new Pe({
    props: {
      icon: "copy",
      disabled: (
        /*isNewRow*/
        n[3] || !/*$focusedRow*/
        ((b = n[5]) != null && b._id) || !/*$hasBudibaseIdentifiers*/
        n[11]
      ),
      $$slots: { default: [ku] },
      $$scope: { ctx: n }
    }
  }), r.$on(
    "click",
    /*click_handler_8*/
    n[39]
  ), r.$on(
    "click",
    /*menu*/
    n[13].actions.close
  ), a = new Pe({
    props: {
      icon: "copy",
      disabled: (
        /*isNewRow*/
        n[3] || !/*$focusedRow*/
        ((y = n[5]) != null && y._rev) || !/*$hasBudibaseIdentifiers*/
        n[11]
      ),
      $$slots: { default: [Cu] },
      $$scope: { ctx: n }
    }
  }), a.$on(
    "click",
    /*click_handler_9*/
    n[40]
  ), a.$on(
    "click",
    /*menu*/
    n[13].actions.close
  ), f = new Pe({
    props: {
      icon: "copy",
      disabled: (
        /*isNewRow*/
        n[3] || !/*$config*/
        n[6].canAddRows
      ),
      $$slots: { default: [Ru] },
      $$scope: { ctx: n }
    }
  }), f.$on(
    "click",
    /*duplicateRow*/
    n[25]
  ), m = new Pe({
    props: {
      icon: "trash",
      disabled: (
        /*isNewRow*/
        n[3] || !/*$config*/
        n[6].canDeleteRows
      ),
      $$slots: { default: [vu] },
      $$scope: { ctx: n }
    }
  }), m.$on(
    "click",
    /*deleteRow*/
    n[24]
  );
  let R = (
    /*$config*/
    n[6].aiEnabled && rl(n)
  );
  return {
    c() {
      W(e.$$.fragment), t = x(), W(l.$$.fragment), o = x(), W(s.$$.fragment), i = x(), W(r.$$.fragment), u = x(), W(a.$$.fragment), c = x(), W(f.$$.fragment), d = x(), W(m.$$.fragment), _ = x(), R && R.c(), g = Ae();
    },
    m(k, h) {
      K(e, k, h), M(k, t, h), K(l, k, h), M(k, o, h), K(s, k, h), M(k, i, h), K(r, k, h), M(k, u, h), K(a, k, h), M(k, c, h), K(f, k, h), M(k, d, h), K(m, k, h), M(k, _, h), R && R.m(k, h), M(k, g, h), v = !0;
    },
    p(k, h) {
      var z, Z;
      const C = {};
      h[0] & /*$copyAllowed*/
      256 && (C.disabled = !/*$copyAllowed*/
      k[8]), h[1] & /*$$scope*/
      16384 && (C.$$scope = { dirty: h, ctx: k }), e.$set(C);
      const N = {};
      h[0] & /*$pasteAllowed*/
      512 && (N.disabled = !/*$pasteAllowed*/
      k[9]), h[1] & /*$$scope*/
      16384 && (N.$$scope = { dirty: h, ctx: k }), l.$set(N);
      const S = {};
      h[0] & /*isNewRow, $config*/
      72 && (S.disabled = /*isNewRow*/
      k[3] || !/*$config*/
      k[6].canEditRows || !/*$config*/
      k[6].canExpandRows), h[1] & /*$$scope*/
      16384 && (S.$$scope = { dirty: h, ctx: k }), s.$set(S);
      const I = {};
      h[0] & /*isNewRow, $focusedRow, $hasBudibaseIdentifiers*/
      2088 && (I.disabled = /*isNewRow*/
      k[3] || !/*$focusedRow*/
      ((z = k[5]) != null && z._id) || !/*$hasBudibaseIdentifiers*/
      k[11]), h[1] & /*$$scope*/
      16384 && (I.$$scope = { dirty: h, ctx: k }), r.$set(I);
      const P = {};
      h[0] & /*isNewRow, $focusedRow, $hasBudibaseIdentifiers*/
      2088 && (P.disabled = /*isNewRow*/
      k[3] || !/*$focusedRow*/
      ((Z = k[5]) != null && Z._rev) || !/*$hasBudibaseIdentifiers*/
      k[11]), h[1] & /*$$scope*/
      16384 && (P.$$scope = { dirty: h, ctx: k }), a.$set(P);
      const T = {};
      h[0] & /*isNewRow, $config*/
      72 && (T.disabled = /*isNewRow*/
      k[3] || !/*$config*/
      k[6].canAddRows), h[1] & /*$$scope*/
      16384 && (T.$$scope = { dirty: h, ctx: k }), f.$set(T);
      const H = {};
      h[0] & /*isNewRow, $config*/
      72 && (H.disabled = /*isNewRow*/
      k[3] || !/*$config*/
      k[6].canDeleteRows), h[1] & /*$$scope*/
      16384 && (H.$$scope = { dirty: h, ctx: k }), m.$set(H), /*$config*/
      k[6].aiEnabled ? R ? (R.p(k, h), h[0] & /*$config*/
      64 && p(R, 1)) : (R = rl(k), R.c(), p(R, 1), R.m(g.parentNode, g)) : R && (he(), w(R, 1, 1, () => {
        R = null;
      }), we());
    },
    i(k) {
      v || (p(e.$$.fragment, k), p(l.$$.fragment, k), p(s.$$.fragment, k), p(r.$$.fragment, k), p(a.$$.fragment, k), p(f.$$.fragment, k), p(m.$$.fragment, k), p(R), v = !0);
    },
    o(k) {
      w(e.$$.fragment, k), w(l.$$.fragment, k), w(s.$$.fragment, k), w(r.$$.fragment, k), w(a.$$.fragment, k), w(f.$$.fragment, k), w(m.$$.fragment, k), w(R), v = !1;
    },
    d(k) {
      k && (E(t), E(o), E(i), E(u), E(c), E(d), E(_), E(g)), X(e, k), X(l, k), X(s, k), X(r, k), X(a, k), X(f, k), X(m, k), R && R.d(k);
    }
  };
}
function gu(n) {
  let e, t, l, o, s, i;
  return e = new Pe({
    props: {
      icon: "copy",
      disabled: !/*$copyAllowed*/
      n[8],
      $$slots: { default: [yu] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "click",
    /*click_handler_2*/
    n[33]
  ), e.$on(
    "click",
    /*menu*/
    n[13].actions.close
  ), l = new Pe({
    props: {
      icon: "clipboard-text",
      disabled: !/*$pasteAllowed*/
      n[9],
      $$slots: { default: [Iu] },
      $$scope: { ctx: n }
    }
  }), l.$on(
    "click",
    /*click_handler_3*/
    n[34]
  ), l.$on(
    "click",
    /*menu*/
    n[13].actions.close
  ), s = new Pe({
    props: {
      icon: "trash",
      disabled: !/*$config*/
      n[6].canEditRows,
      $$slots: { default: [Mu] },
      $$scope: { ctx: n }
    }
  }), s.$on(
    "click",
    /*click_handler_4*/
    n[35]
  ), {
    c() {
      W(e.$$.fragment), t = x(), W(l.$$.fragment), o = x(), W(s.$$.fragment);
    },
    m(r, u) {
      K(e, r, u), M(r, t, u), K(l, r, u), M(r, o, u), K(s, r, u), i = !0;
    },
    p(r, u) {
      const a = {};
      u[0] & /*$copyAllowed*/
      256 && (a.disabled = !/*$copyAllowed*/
      r[8]), u[1] & /*$$scope*/
      16384 && (a.$$scope = { dirty: u, ctx: r }), e.$set(a);
      const c = {};
      u[0] & /*$pasteAllowed*/
      512 && (c.disabled = !/*$pasteAllowed*/
      r[9]), u[1] & /*$$scope*/
      16384 && (c.$$scope = { dirty: u, ctx: r }), l.$set(c);
      const f = {};
      u[0] & /*$config*/
      64 && (f.disabled = !/*$config*/
      r[6].canEditRows), u[0] & /*$selectedCellCount*/
      1024 | u[1] & /*$$scope*/
      16384 && (f.$$scope = { dirty: u, ctx: r }), s.$set(f);
    },
    i(r) {
      i || (p(e.$$.fragment, r), p(l.$$.fragment, r), p(s.$$.fragment, r), i = !0);
    },
    o(r) {
      w(e.$$.fragment, r), w(l.$$.fragment, r), w(s.$$.fragment, r), i = !1;
    },
    d(r) {
      r && (E(t), E(o)), X(e, r), X(l, r), X(s, r);
    }
  };
}
function pu(n) {
  let e, t, l, o;
  return e = new Pe({
    props: {
      icon: "copy",
      disabled: !/*$config*/
      n[6].canAddRows || /*$selectedRowCount*/
      n[7] > 50,
      $$slots: { default: [Eu] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "click",
    /*click_handler*/
    n[31]
  ), e.$on(
    "click",
    /*menu*/
    n[13].actions.close
  ), l = new Pe({
    props: {
      icon: "trash",
      disabled: !/*$config*/
      n[6].canDeleteRows,
      $$slots: { default: [Au] },
      $$scope: { ctx: n }
    }
  }), l.$on(
    "click",
    /*click_handler_1*/
    n[32]
  ), l.$on(
    "click",
    /*menu*/
    n[13].actions.close
  ), {
    c() {
      W(e.$$.fragment), t = x(), W(l.$$.fragment);
    },
    m(s, i) {
      K(e, s, i), M(s, t, i), K(l, s, i), o = !0;
    },
    p(s, i) {
      const r = {};
      i[0] & /*$config, $selectedRowCount*/
      192 && (r.disabled = !/*$config*/
      s[6].canAddRows || /*$selectedRowCount*/
      s[7] > 50), i[0] & /*$selectedRowCount*/
      128 | i[1] & /*$$scope*/
      16384 && (r.$$scope = { dirty: i, ctx: s }), e.$set(r);
      const u = {};
      i[0] & /*$config*/
      64 && (u.disabled = !/*$config*/
      s[6].canDeleteRows), i[0] & /*$selectedRowCount*/
      128 | i[1] & /*$$scope*/
      16384 && (u.$$scope = { dirty: i, ctx: s }), l.$set(u);
    },
    i(s) {
      o || (p(e.$$.fragment, s), p(l.$$.fragment, s), o = !0);
    },
    o(s) {
      w(e.$$.fragment, s), w(l.$$.fragment, s), o = !1;
    },
    d(s) {
      s && E(t), X(e, s), X(l, s);
    }
  };
}
function hu(n) {
  let e;
  return {
    c() {
      e = de("Copy");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function wu(n) {
  let e;
  return {
    c() {
      e = de("Paste");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function bu(n) {
  let e;
  return {
    c() {
      e = de("Edit row in modal");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function ku(n) {
  let e;
  return {
    c() {
      e = de("Copy row _id");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function Cu(n) {
  let e;
  return {
    c() {
      e = de("Copy row _rev");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function Ru(n) {
  let e;
  return {
    c() {
      e = de("Duplicate row");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function vu(n) {
  let e;
  return {
    c() {
      e = de("Delete row");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function rl(n) {
  let e, t;
  return e = new Pe({
    props: {
      icon: "magic-wand",
      disabled: (
        /*isNewRow*/
        n[3] || !/*hasAIColumns*/
        n[2]
      ),
      $$slots: { default: [Su] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "click",
    /*generateAIColumns*/
    n[27]
  ), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*isNewRow, hasAIColumns*/
      12 && (s.disabled = /*isNewRow*/
      l[3] || !/*hasAIColumns*/
      l[2]), o[1] & /*$$scope*/
      16384 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Su(n) {
  let e;
  return {
    c() {
      e = de("Generate AI Columns");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function yu(n) {
  let e;
  return {
    c() {
      e = de("Copy");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function Iu(n) {
  let e;
  return {
    c() {
      e = de("Paste");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function Mu(n) {
  let e, t, l;
  return {
    c() {
      e = de("Delete "), t = de(
        /*$selectedCellCount*/
        n[10]
      ), l = de(" cells");
    },
    m(o, s) {
      M(o, e, s), M(o, t, s), M(o, l, s);
    },
    p(o, s) {
      s[0] & /*$selectedCellCount*/
      1024 && je(
        t,
        /*$selectedCellCount*/
        o[10]
      );
    },
    d(o) {
      o && (E(e), E(t), E(l));
    }
  };
}
function Eu(n) {
  let e, t, l;
  return {
    c() {
      e = de("Duplicate "), t = de(
        /*$selectedRowCount*/
        n[7]
      ), l = de(" rows");
    },
    m(o, s) {
      M(o, e, s), M(o, t, s), M(o, l, s);
    },
    p(o, s) {
      s[0] & /*$selectedRowCount*/
      128 && je(
        t,
        /*$selectedRowCount*/
        o[7]
      );
    },
    d(o) {
      o && (E(e), E(t), E(l));
    }
  };
}
function Au(n) {
  let e, t, l;
  return {
    c() {
      e = de("Delete "), t = de(
        /*$selectedRowCount*/
        n[7]
      ), l = de(" rows");
    },
    m(o, s) {
      M(o, e, s), M(o, t, s), M(o, l, s);
    },
    p(o, s) {
      s[0] & /*$selectedRowCount*/
      128 && je(
        t,
        /*$selectedRowCount*/
        o[7]
      );
    },
    d(o) {
      o && (E(e), E(t), E(l));
    }
  };
}
function Lu(n) {
  let e, t, l, o;
  const s = [pu, gu, _u], i = [];
  function r(u, a) {
    return (
      /*$menu*/
      u[0].multiRowMode ? 0 : (
        /*$menu*/
        u[0].multiCellMode ? 1 : 2
      )
    );
  }
  return e = r(n), t = i[e] = s[e](n), {
    c() {
      t.c(), l = Ae();
    },
    m(u, a) {
      i[e].m(u, a), M(u, l, a), o = !0;
    },
    p(u, a) {
      let c = e;
      e = r(u), e === c ? i[e].p(u, a) : (he(), w(i[c], 1, 1, () => {
        i[c] = null;
      }), we(), t = i[e], t ? t.p(u, a) : (t = i[e] = s[e](u), t.c()), p(t, 1), t.m(l.parentNode, l));
    },
    i(u) {
      o || (p(t), o = !0);
    },
    o(u) {
      w(t), o = !1;
    },
    d(u) {
      u && E(l), i[e].d(u);
    }
  };
}
function Du(n) {
  let e, t;
  return e = new xl({
    props: {
      $$slots: { default: [Lu] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*$config, $selectedRowCount, $menu, $selectedCellCount, $pasteAllowed, $copyAllowed, isNewRow, hasAIColumns, $focusedRow, $hasBudibaseIdentifiers*/
      4077 | o[1] & /*$$scope*/
      16384 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function il(n) {
  let e, t;
  return e = new tn({
    props: {
      anchor: (
        /*anchor*/
        n[1]
      ),
      maxHeight: null,
      $$slots: { default: [Du] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "close",
    /*menu*/
    n[13].actions.close
  ), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*anchor*/
      2 && (s.anchor = /*anchor*/
      l[1]), o[0] & /*$config, $selectedRowCount, $menu, $selectedCellCount, $pasteAllowed, $copyAllowed, isNewRow, hasAIColumns, $focusedRow, $hasBudibaseIdentifiers*/
      4077 | o[1] & /*$$scope*/
      16384 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Nu(n) {
  let e, t, l, o, s = (
    /*$menu*/
    n[0].visible && sl(n)
  );
  return {
    c() {
      e = $("div"), t = x(), s && s.c(), l = Ae(), U(
        e,
        "style",
        /*style*/
        n[4]
      ), U(e, "class", "menu-anchor svelte-825iyj");
    },
    m(i, r) {
      M(i, e, r), n[30](e), M(i, t, r), s && s.m(i, r), M(i, l, r), o = !0;
    },
    p(i, r) {
      (!o || r[0] & /*style*/
      16) && U(
        e,
        "style",
        /*style*/
        i[4]
      ), /*$menu*/
      i[0].visible ? s ? (s.p(i, r), r[0] & /*$menu*/
      1 && p(s, 1)) : (s = sl(i), s.c(), p(s, 1), s.m(l.parentNode, l)) : s && (he(), w(s, 1, 1, () => {
        s = null;
      }), we());
    },
    i(i) {
      o || (p(s), o = !0);
    },
    o(i) {
      w(s), o = !1;
    },
    d(i) {
      i && (E(e), E(t), E(l)), n[30](null), s && s.d(i);
    }
  };
}
function Ou(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, m, _, g, v;
  const { focusedRow: R, menu: b, rows: y, config: k, dispatch: h, focusedRowId: C, notifications: N, hasBudibaseIdentifiers: S, selectedRowCount: I, copyAllowed: P, pasteAllowed: T, selectedCellCount: H, visibleColumns: z, selectedCells: Z } = Te("grid");
  A(n, R, (O) => t(5, a = O)), A(n, b, (O) => t(0, c = O)), A(n, k, (O) => t(6, f = O)), A(n, C, (O) => t(28, r = O)), A(n, N, (O) => t(41, i = O)), A(n, S, (O) => t(11, v = O)), A(n, I, (O) => t(7, d = O)), A(n, P, (O) => t(8, m = O)), A(n, T, (O) => t(9, _ = O)), A(n, H, (O) => t(10, g = O)), A(n, z, (O) => t(29, u = O));
  let B;
  const te = (O) => `left:${O.left}px; top:${O.top}px;`, _e = () => {
    b.actions.close(), y.actions.deleteRows([a]), i.success("Deleted 1 row");
  }, ie = async () => {
    b.actions.close();
    const O = await y.actions.duplicateRow(a);
    if (O) {
      const se = u[0], ge = u[u.length - 1], ue = xe(O._id, se.name), D = xe(O._id, ge.name);
      Z.actions.selectRange(ue, D);
    }
  }, fe = async (O) => {
    await Xl(O), i.success("Copied to clipboard");
  }, ae = async () => {
    b.actions.close(), await y.actions.applyRowChanges({ rowId: r }), i.success("Generated AI columns");
  };
  function Re(O) {
    $e[O ? "unshift" : "push"](() => {
      B = O, t(1, B);
    });
  }
  const Ce = () => h("request-bulk-duplicate"), ve = () => h("request-bulk-delete"), J = () => h("copy"), be = () => h("paste"), j = () => h("request-bulk-delete"), Q = () => h("copy"), F = () => h("paste"), q = () => h("edit-row", a), V = () => fe(a == null ? void 0 : a._id), G = () => fe(a == null ? void 0 : a._rev);
  return n.$$.update = () => {
    n.$$.dirty[0] & /*$menu*/
    1 && t(4, l = te(c)), n.$$.dirty[0] & /*$focusedRowId*/
    268435456 && t(3, o = r === rt), n.$$.dirty[0] & /*$visibleColumns*/
    536870912 && t(2, s = u.some((O) => O.schema.type === Qe.AI));
  }, [
    c,
    B,
    s,
    o,
    l,
    a,
    f,
    d,
    m,
    _,
    g,
    v,
    R,
    b,
    k,
    h,
    C,
    N,
    S,
    I,
    P,
    T,
    H,
    z,
    _e,
    ie,
    fe,
    ae,
    r,
    u,
    Re,
    Ce,
    ve,
    J,
    be,
    j,
    Q,
    F,
    q,
    V,
    G
  ];
}
class Tu extends De {
  constructor(e) {
    super(), Ne(this, e, Ou, Nu, Ee, {}, null, [-1, -1]);
  }
}
function zu(n) {
  let e, t, l, o, s, i, r;
  t = new To({
    props: {
      value: (
        /*rowSelected*/
        n[3]
      ),
      disabled: (
        /*disabled*/
        n[7]
      )
    }
  });
  let u = !/*disableNumber*/
  n[5] && ul(n);
  return {
    c() {
      e = $("div"), W(t.$$.fragment), l = x(), u && u.c(), o = Ae(), U(e, "class", "checkbox svelte-g7itl0"), ne(
        e,
        "visible",
        /*disableNumber*/
        n[5] || /*rowSelected*/
        n[3] || /*rowHovered*/
        n[2] || /*rowFocused*/
        n[1]
      );
    },
    m(a, c) {
      M(a, e, c), K(t, e, null), M(a, l, c), u && u.m(a, c), M(a, o, c), s = !0, i || (r = ke(
        e,
        "click",
        /*select*/
        n[10]
      ), i = !0);
    },
    p(a, c) {
      const f = {};
      c & /*rowSelected*/
      8 && (f.value = /*rowSelected*/
      a[3]), c & /*disabled*/
      128 && (f.disabled = /*disabled*/
      a[7]), t.$set(f), (!s || c & /*disableNumber, rowSelected, rowHovered, rowFocused*/
      46) && ne(
        e,
        "visible",
        /*disableNumber*/
        a[5] || /*rowSelected*/
        a[3] || /*rowHovered*/
        a[2] || /*rowFocused*/
        a[1]
      ), /*disableNumber*/
      a[5] ? u && (u.d(1), u = null) : u ? u.p(a, c) : (u = ul(a), u.c(), u.m(o.parentNode, o));
    },
    i(a) {
      s || (p(t.$$.fragment, a), s = !0);
    },
    o(a) {
      w(t.$$.fragment, a), s = !1;
    },
    d(a) {
      a && (E(e), E(l), E(o)), X(t), u && u.d(a), i = !1, r();
    }
  };
}
function Pu(n) {
  let e;
  const t = (
    /*#slots*/
    n[14].default
  ), l = We(
    t,
    n,
    /*$$scope*/
    n[15],
    null
  );
  return {
    c() {
      l && l.c();
    },
    m(o, s) {
      l && l.m(o, s), e = !0;
    },
    p(o, s) {
      l && l.p && (!e || s & /*$$scope*/
      32768) && Ke(
        l,
        t,
        o,
        /*$$scope*/
        o[15],
        e ? Ye(
          t,
          /*$$scope*/
          o[15],
          s,
          null
        ) : Xe(
          /*$$scope*/
          o[15]
        ),
        null
      );
    },
    i(o) {
      e || (p(l, o), e = !0);
    },
    o(o) {
      w(l, o), e = !1;
    },
    d(o) {
      l && l.d(o);
    }
  };
}
function ul(n) {
  let e, t = (
    /*row*/
    n[0].__idx + 1 + ""
  ), l;
  return {
    c() {
      e = $("div"), l = de(t), U(e, "class", "number svelte-g7itl0"), ne(e, "visible", !/*rowSelected*/
      (n[3] || /*rowHovered*/
      n[2] || /*rowFocused*/
      n[1]));
    },
    m(o, s) {
      M(o, e, s), le(e, l);
    },
    p(o, s) {
      s & /*row*/
      1 && t !== (t = /*row*/
      o[0].__idx + 1 + "") && je(l, t), s & /*rowSelected, rowHovered, rowFocused*/
      14 && ne(e, "visible", !/*rowSelected*/
      (o[3] || /*rowHovered*/
      o[2] || /*rowFocused*/
      o[1]));
    },
    d(o) {
      o && E(e);
    }
  };
}
function Hu(n) {
  let e, t, l;
  return t = new nt({
    props: {
      size: "S",
      name: "arrows-out-simple",
      hoverable: !0
    }
  }), t.$on(
    "click",
    /*expand*/
    n[12]
  ), {
    c() {
      e = $("div"), W(t.$$.fragment), U(e, "class", "expand svelte-g7itl0"), ne(
        e,
        "visible",
        /*$config*/
        n[8].canExpandRows && /*expandable*/
        n[4]
      );
    },
    m(o, s) {
      M(o, e, s), K(t, e, null), l = !0;
    },
    p(o, s) {
      (!l || s & /*$config, expandable*/
      272) && ne(
        e,
        "visible",
        /*$config*/
        o[8].canExpandRows && /*expandable*/
        o[4]
      );
    },
    i(o) {
      l || (p(t.$$.fragment, o), l = !0);
    },
    o(o) {
      w(t.$$.fragment, o), l = !1;
    },
    d(o) {
      o && E(e), X(t);
    }
  };
}
function Fu(n) {
  let e, t, l, o, s;
  return t = new nt({
    props: {
      name: "trash",
      size: "S",
      color: "var(--spectrum-global-color-red-400)"
    }
  }), {
    c() {
      e = $("div"), W(t.$$.fragment), U(e, "class", "delete svelte-g7itl0");
    },
    m(i, r) {
      M(i, e, r), K(t, e, null), l = !0, o || (s = ke(
        e,
        "click",
        /*bulkDelete*/
        n[11]
      ), o = !0);
    },
    p: Oe,
    i(i) {
      l || (p(t.$$.fragment, i), l = !0);
    },
    o(i) {
      w(t.$$.fragment, i), l = !1;
    },
    d(i) {
      i && E(e), X(t), o = !1, s();
    }
  };
}
function Bu(n) {
  let e, t, l, o, s, i, r;
  const u = [Pu, zu], a = [];
  function c(_, g) {
    return (
      /*$$slots*/
      _[13].default ? 0 : 1
    );
  }
  t = c(n), l = a[t] = u[t](n);
  const f = [Fu, Hu], d = [];
  function m(_, g) {
    return (
      /*rowSelected*/
      _[3] && /*$config*/
      _[8].canDeleteRows ? 0 : 1
    );
  }
  return s = m(n), i = d[s] = f[s](n), {
    c() {
      e = $("div"), l.c(), o = x(), i.c(), U(e, "class", "gutter svelte-g7itl0"), ne(
        e,
        "selectable",
        /*$config*/
        n[8].canSelectRows
      );
    },
    m(_, g) {
      M(_, e, g), a[t].m(e, null), le(e, o), d[s].m(e, null), r = !0;
    },
    p(_, g) {
      let v = t;
      t = c(_), t === v ? a[t].p(_, g) : (he(), w(a[v], 1, 1, () => {
        a[v] = null;
      }), we(), l = a[t], l ? l.p(_, g) : (l = a[t] = u[t](_), l.c()), p(l, 1), l.m(e, o));
      let R = s;
      s = m(_), s === R ? d[s].p(_, g) : (he(), w(d[R], 1, 1, () => {
        d[R] = null;
      }), we(), i = d[s], i ? i.p(_, g) : (i = d[s] = f[s](_), i.c()), p(i, 1), i.m(e, null)), (!r || g & /*$config*/
      256) && ne(
        e,
        "selectable",
        /*$config*/
        _[8].canSelectRows
      );
    },
    i(_) {
      r || (p(l), p(i), r = !0);
    },
    o(_) {
      w(l), w(i), r = !1;
    },
    d(_) {
      _ && E(e), a[t].d(), d[s].d();
    }
  };
}
function ju(n) {
  var l, o, s;
  let e, t;
  return e = new wt({
    props: {
      width: Rt,
      highlighted: (
        /*rowFocused*/
        n[1] || /*rowHovered*/
        n[2]
      ),
      selected: (
        /*rowSelected*/
        n[3]
      ),
      defaultHeight: (
        /*defaultHeight*/
        n[6]
      ),
      rowIdx: (
        /*row*/
        (l = n[0]) == null ? void 0 : l.__idx
      ),
      metadata: (
        /*row*/
        (s = (o = n[0]) == null ? void 0 : o.__metadata) == null ? void 0 : s.row
      ),
      $$slots: { default: [Bu] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(i, r) {
      K(e, i, r), t = !0;
    },
    p(i, [r]) {
      var a, c, f;
      const u = {};
      r & /*rowFocused, rowHovered*/
      6 && (u.highlighted = /*rowFocused*/
      i[1] || /*rowHovered*/
      i[2]), r & /*rowSelected*/
      8 && (u.selected = /*rowSelected*/
      i[3]), r & /*defaultHeight*/
      64 && (u.defaultHeight = /*defaultHeight*/
      i[6]), r & /*row*/
      1 && (u.rowIdx = /*row*/
      (a = i[0]) == null ? void 0 : a.__idx), r & /*row*/
      1 && (u.metadata = /*row*/
      (f = (c = i[0]) == null ? void 0 : c.__metadata) == null ? void 0 : f.row), r & /*$$scope, $config, rowSelected, expandable, $$slots, rowHovered, rowFocused, row, disableNumber, disabled*/
      41407 && (u.$$scope = { dirty: r, ctx: i }), e.$set(u);
    },
    i(i) {
      t || (p(e.$$.fragment, i), t = !0);
    },
    o(i) {
      w(e.$$.fragment, i), t = !1;
    },
    d(i) {
      X(e, i);
    }
  };
}
function Vu(n, e, t) {
  let l, { $$slots: o = {}, $$scope: s } = e;
  const i = xt(o);
  let { row: r } = e, { rowFocused: u = !1 } = e, { rowHovered: a = !1 } = e, { rowSelected: c = !1 } = e, { expandable: f = !1 } = e, { disableNumber: d = !1 } = e, { defaultHeight: m = !1 } = e, { disabled: _ = !1 } = e;
  const { config: g, dispatch: v, selectedRows: R } = Te("grid");
  A(n, g, (C) => t(8, l = C));
  const b = Ul(), y = (C) => {
    C.stopPropagation(), b("select");
    const N = r == null ? void 0 : r._id;
    N && (C.shiftKey ? c ? C.preventDefault() : R.actions.bulkSelectRows(N) : R.actions.toggleRow(N));
  }, k = (C) => {
    C.stopPropagation(), v("request-bulk-delete");
  }, h = (C) => {
    C.stopPropagation(), b("expand");
  };
  return n.$$set = (C) => {
    "row" in C && t(0, r = C.row), "rowFocused" in C && t(1, u = C.rowFocused), "rowHovered" in C && t(2, a = C.rowHovered), "rowSelected" in C && t(3, c = C.rowSelected), "expandable" in C && t(4, f = C.expandable), "disableNumber" in C && t(5, d = C.disableNumber), "defaultHeight" in C && t(6, m = C.defaultHeight), "disabled" in C && t(7, _ = C.disabled), "$$scope" in C && t(15, s = C.$$scope);
  }, [
    r,
    u,
    a,
    c,
    f,
    d,
    m,
    _,
    l,
    g,
    y,
    k,
    h,
    i,
    o,
    s
  ];
}
class Gt extends De {
  constructor(e) {
    super(), Ne(this, e, Vu, ju, Ee, {
      row: 0,
      rowFocused: 1,
      rowHovered: 2,
      rowSelected: 3,
      expandable: 4,
      disableNumber: 5,
      defaultHeight: 6,
      disabled: 7
    });
  }
}
function cl(n, e, t) {
  const l = n.slice();
  return l[5] = e[t], l;
}
function al(n) {
  let e, t = (
    /*key*/
    n[5] + ""
  ), l, o;
  return {
    c() {
      e = $("div"), l = de(t), o = x(), U(e, "class", "key svelte-uhg3e3");
    },
    m(s, i) {
      M(s, e, i), le(e, l), le(e, o);
    },
    p(s, i) {
      i & /*parsedKeys*/
      4 && t !== (t = /*key*/
      s[5] + "") && je(l, t);
    },
    d(s) {
      s && E(e);
    }
  };
}
function Uu(n) {
  let e, t = He(
    /*parsedKeys*/
    n[2]
  ), l = [];
  for (let o = 0; o < t.length; o += 1)
    l[o] = al(cl(n, t, o));
  return {
    c() {
      e = $("div");
      for (let o = 0; o < l.length; o += 1)
        l[o].c();
      U(e, "class", "keys svelte-uhg3e3"), ne(
        e,
        "padded",
        /*padded*/
        n[0]
      ), ne(
        e,
        "overlay",
        /*overlay*/
        n[1]
      );
    },
    m(o, s) {
      M(o, e, s);
      for (let i = 0; i < l.length; i += 1)
        l[i] && l[i].m(e, null);
    },
    p(o, [s]) {
      if (s & /*parsedKeys*/
      4) {
        t = He(
          /*parsedKeys*/
          o[2]
        );
        let i;
        for (i = 0; i < t.length; i += 1) {
          const r = cl(o, t, i);
          l[i] ? l[i].p(r, s) : (l[i] = al(r), l[i].c(), l[i].m(e, null));
        }
        for (; i < l.length; i += 1)
          l[i].d(1);
        l.length = t.length;
      }
      s & /*padded*/
      1 && ne(
        e,
        "padded",
        /*padded*/
        o[0]
      ), s & /*overlay*/
      2 && ne(
        e,
        "overlay",
        /*overlay*/
        o[1]
      );
    },
    i: Oe,
    o: Oe,
    d(o) {
      o && E(e), ct(l, o);
    }
  };
}
function qu(n, e, t) {
  let l, { keybind: o } = e, { padded: s = !1 } = e, { overlay: i = !1 } = e;
  const r = (u) => u == null ? void 0 : u.split("+").map((a) => a.toLowerCase() === "ctrl" ? navigator.platform.startsWith("Mac") ? "⌘" : a : a.toLowerCase() === "enter" ? "↵" : a);
  return n.$$set = (u) => {
    "keybind" in u && t(3, o = u.keybind), "padded" in u && t(0, s = u.padded), "overlay" in u && t(1, i = u.overlay);
  }, n.$$.update = () => {
    n.$$.dirty & /*keybind*/
    8 && t(2, l = r(o));
  }, [s, i, l, o];
}
class nn extends De {
  constructor(e) {
    super(), Ne(this, e, qu, Uu, Ee, { keybind: 3, padded: 0, overlay: 1 });
  }
}
function fl(n, e, t) {
  var u, a;
  const l = n.slice();
  l[43] = e[t], l[49] = t;
  const o = !!/*$selectedRows*/
  l[0][
    /*row*/
    l[43]._id
  ];
  l[44] = o;
  const s = (
    /*$hoveredRowId*/
    l[7] === /*row*/
    l[43]._id && (!/*$selectedCellCount*/
    l[8] || !/*$isSelectingCells*/
    l[9])
  );
  l[45] = s;
  const i = (
    /*$focusedRow*/
    ((u = l[10]) == null ? void 0 : u._id) === /*row*/
    l[43]._id
  );
  l[46] = i;
  const r = xe(
    /*row*/
    l[43]._id,
    /*$displayColumn*/
    (a = l[1]) == null ? void 0 : a.name
  );
  return l[47] = r, l;
}
const Gu = (n) => ({}), dl = (n) => ({});
function ml(n) {
  let e, t;
  return e = new so({
    props: {
      column: (
        /*$displayColumn*/
        n[1]
      ),
      orderable: !1,
      idx: "sticky",
      $$slots: { default: [Wu] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*$displayColumn*/
      2 && (s.column = /*$displayColumn*/
      l[1]), o[1] & /*$$scope*/
      2048 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Wu(n) {
  let e;
  const t = (
    /*#slots*/
    n[35]["edit-column"]
  ), l = We(
    t,
    n,
    /*$$scope*/
    n[42],
    dl
  );
  return {
    c() {
      l && l.c();
    },
    m(o, s) {
      l && l.m(o, s), e = !0;
    },
    p(o, s) {
      l && l.p && (!e || s[1] & /*$$scope*/
      2048) && Ke(
        l,
        t,
        o,
        /*$$scope*/
        o[42],
        e ? Ye(
          t,
          /*$$scope*/
          o[42],
          s,
          Gu
        ) : Xe(
          /*$$scope*/
          o[42]
        ),
        dl
      );
    },
    i(o) {
      e || (p(l, o), e = !0);
    },
    o(o) {
      w(l, o), e = !1;
    },
    d(o) {
      l && l.d(o);
    }
  };
}
function _l(n) {
  let e, t;
  return e = new qt({
    props: {
      row: (
        /*row*/
        n[43]
      ),
      cellId: (
        /*cellId*/
        n[47]
      ),
      rowFocused: (
        /*rowFocused*/
        n[46]
      ),
      rowSelected: (
        /*rowSelected*/
        n[44]
      ),
      cellSelected: (
        /*$selectedCellMap*/
        n[12][
          /*cellId*/
          n[47]
        ]
      ),
      highlighted: (
        /*rowHovered*/
        n[45] || /*rowFocused*/
        n[46]
      ),
      rowIdx: (
        /*row*/
        n[43].__idx
      ),
      topRow: (
        /*idx*/
        n[49] === 0
      ),
      focused: (
        /*$focusedCellId*/
        n[13] === /*cellId*/
        n[47]
      ),
      selectedUser: (
        /*$userCellMap*/
        n[14][
          /*cellId*/
          n[47]
        ]
      ),
      width: (
        /*$displayColumn*/
        n[1].width
      ),
      column: (
        /*$displayColumn*/
        n[1]
      ),
      contentLines: (
        /*$contentLines*/
        n[15]
      ),
      isSelectingCells: (
        /*$isSelectingCells*/
        n[9]
      )
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*$renderedRows*/
      64 && (s.row = /*row*/
      l[43]), o[0] & /*$renderedRows, $displayColumn*/
      66 && (s.cellId = /*cellId*/
      l[47]), o[0] & /*$focusedRow, $renderedRows*/
      1088 && (s.rowFocused = /*rowFocused*/
      l[46]), o[0] & /*$selectedRows, $renderedRows*/
      65 && (s.rowSelected = /*rowSelected*/
      l[44]), o[0] & /*$selectedCellMap, $renderedRows, $displayColumn*/
      4162 && (s.cellSelected = /*$selectedCellMap*/
      l[12][
        /*cellId*/
        l[47]
      ]), o[0] & /*$hoveredRowId, $renderedRows, $selectedCellCount, $isSelectingCells, $focusedRow*/
      1984 && (s.highlighted = /*rowHovered*/
      l[45] || /*rowFocused*/
      l[46]), o[0] & /*$renderedRows*/
      64 && (s.rowIdx = /*row*/
      l[43].__idx), o[0] & /*$focusedCellId, $renderedRows, $displayColumn*/
      8258 && (s.focused = /*$focusedCellId*/
      l[13] === /*cellId*/
      l[47]), o[0] & /*$userCellMap, $renderedRows, $displayColumn*/
      16450 && (s.selectedUser = /*$userCellMap*/
      l[14][
        /*cellId*/
        l[47]
      ]), o[0] & /*$displayColumn*/
      2 && (s.width = /*$displayColumn*/
      l[1].width), o[0] & /*$displayColumn*/
      2 && (s.column = /*$displayColumn*/
      l[1]), o[0] & /*$contentLines*/
      32768 && (s.contentLines = /*$contentLines*/
      l[15]), o[0] & /*$isSelectingCells*/
      512 && (s.isSelectingCells = /*$isSelectingCells*/
      l[9]), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function gl(n) {
  let e, t, l, o, s, i;
  t = new Gt({
    props: {
      row: (
        /*row*/
        n[43]
      ),
      rowFocused: (
        /*rowFocused*/
        n[46]
      ),
      rowHovered: (
        /*rowHovered*/
        n[45]
      ),
      rowSelected: (
        /*rowSelected*/
        n[44]
      )
    }
  });
  let r = (
    /*$displayColumn*/
    n[1] && _l(n)
  );
  function u() {
    return (
      /*mouseenter_handler*/
      n[36](
        /*row*/
        n[43]
      )
    );
  }
  function a() {
    return (
      /*click_handler*/
      n[38](
        /*row*/
        n[43]
      )
    );
  }
  return {
    c() {
      e = $("div"), W(t.$$.fragment), l = x(), r && r.c(), U(e, "class", "row svelte-15yu3r0");
    },
    m(c, f) {
      M(c, e, f), K(t, e, null), le(e, l), r && r.m(e, null), o = !0, s || (i = [
        ke(e, "mouseenter", function() {
          Ue(
            /*$isDragging*/
            n[11] ? null : u
          ) && /*$isDragging*/
          (n[11] ? null : u).apply(this, arguments);
        }),
        ke(e, "mouseleave", function() {
          Ue(
            /*$isDragging*/
            n[11] ? null : (
              /*mouseleave_handler*/
              n[37]
            )
          ) && /*$isDragging*/
          (n[11] ? null : (
            /*mouseleave_handler*/
            n[37]
          )).apply(this, arguments);
        }),
        ke(e, "click", a)
      ], s = !0);
    },
    p(c, f) {
      n = c;
      const d = {};
      f[0] & /*$renderedRows*/
      64 && (d.row = /*row*/
      n[43]), f[0] & /*$focusedRow, $renderedRows*/
      1088 && (d.rowFocused = /*rowFocused*/
      n[46]), f[0] & /*$hoveredRowId, $renderedRows, $selectedCellCount, $isSelectingCells*/
      960 && (d.rowHovered = /*rowHovered*/
      n[45]), f[0] & /*$selectedRows, $renderedRows*/
      65 && (d.rowSelected = /*rowSelected*/
      n[44]), t.$set(d), /*$displayColumn*/
      n[1] ? r ? (r.p(n, f), f[0] & /*$displayColumn*/
      2 && p(r, 1)) : (r = _l(n), r.c(), p(r, 1), r.m(e, null)) : r && (he(), w(r, 1, 1, () => {
        r = null;
      }), we());
    },
    i(c) {
      o || (p(t.$$.fragment, c), p(r), o = !0);
    },
    o(c) {
      w(t.$$.fragment, c), w(r), o = !1;
    },
    d(c) {
      c && E(e), X(t), r && r.d(), s = !1, lt(i);
    }
  };
}
function pl(n) {
  let e, t, l, o, s, i;
  t = new Gt({
    props: {
      rowHovered: (
        /*$hoveredRowId*/
        n[7] === ut
      ),
      $$slots: { default: [Ku] },
      $$scope: { ctx: n }
    }
  });
  let r = (
    /*$displayColumn*/
    n[1] && hl(n)
  );
  return {
    c() {
      e = $("div"), W(t.$$.fragment), l = x(), r && r.c(), U(e, "class", "row blank svelte-15yu3r0");
    },
    m(u, a) {
      M(u, e, a), K(t, e, null), le(e, l), r && r.m(e, null), o = !0, s || (i = [
        ke(e, "mouseenter", function() {
          Ue(
            /*$isDragging*/
            n[11] ? null : (
              /*mouseenter_handler_1*/
              n[39]
            )
          ) && /*$isDragging*/
          (n[11] ? null : (
            /*mouseenter_handler_1*/
            n[39]
          )).apply(this, arguments);
        }),
        ke(e, "mouseleave", function() {
          Ue(
            /*$isDragging*/
            n[11] ? null : (
              /*mouseleave_handler_1*/
              n[40]
            )
          ) && /*$isDragging*/
          (n[11] ? null : (
            /*mouseleave_handler_1*/
            n[40]
          )).apply(this, arguments);
        }),
        ke(
          e,
          "click",
          /*click_handler_1*/
          n[41]
        )
      ], s = !0);
    },
    p(u, a) {
      n = u;
      const c = {};
      a[0] & /*$hoveredRowId*/
      128 && (c.rowHovered = /*$hoveredRowId*/
      n[7] === ut), a[1] & /*$$scope*/
      2048 && (c.$$scope = { dirty: a, ctx: n }), t.$set(c), /*$displayColumn*/
      n[1] ? r ? (r.p(n, a), a[0] & /*$displayColumn*/
      2 && p(r, 1)) : (r = hl(n), r.c(), p(r, 1), r.m(e, null)) : r && (he(), w(r, 1, 1, () => {
        r = null;
      }), we());
    },
    i(u) {
      o || (p(t.$$.fragment, u), p(r), o = !0);
    },
    o(u) {
      w(t.$$.fragment, u), w(r), o = !1;
    },
    d(u) {
      u && E(e), X(t), r && r.d(), s = !1, lt(i);
    }
  };
}
function Ku(n) {
  let e, t;
  return e = new nt({
    props: {
      name: "plus",
      color: "var(--spectrum-global-color-gray-500)"
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p: Oe,
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function hl(n) {
  let e, t;
  return e = new wt({
    props: {
      width: (
        /*$displayColumn*/
        n[1].width
      ),
      highlighted: (
        /*$hoveredRowId*/
        n[7] === ut
      ),
      $$slots: { default: [Xu] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*$displayColumn*/
      2 && (s.width = /*$displayColumn*/
      l[1].width), o[0] & /*$hoveredRowId*/
      128 && (s.highlighted = /*$hoveredRowId*/
      l[7] === ut), o[1] & /*$$scope*/
      2048 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Xu(n) {
  let e, t;
  return e = new nn({
    props: { padded: !0, keybind: "Ctrl+Enter" }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p: Oe,
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Yu(n) {
  let e, t, l, o = He(
    /*$renderedRows*/
    n[6]
  ), s = [];
  for (let u = 0; u < o.length; u += 1)
    s[u] = gl(fl(n, o, u));
  const i = (u) => w(s[u], 1, 1, () => {
    s[u] = null;
  });
  let r = (
    /*$config*/
    n[16].canAddRows && pl(n)
  );
  return {
    c() {
      for (let u = 0; u < s.length; u += 1)
        s[u].c();
      e = x(), r && r.c(), t = Ae();
    },
    m(u, a) {
      for (let c = 0; c < s.length; c += 1)
        s[c] && s[c].m(u, a);
      M(u, e, a), r && r.m(u, a), M(u, t, a), l = !0;
    },
    p(u, a) {
      if (a[0] & /*$isDragging, $hoveredRowId, $renderedRows, dispatch, rows, $displayColumn, $focusedRow, $selectedRows, $selectedCellMap, $selectedCellCount, $isSelectingCells, $focusedCellId, $userCellMap, $contentLines*/
      268632003) {
        o = He(
          /*$renderedRows*/
          u[6]
        );
        let c;
        for (c = 0; c < o.length; c += 1) {
          const f = fl(u, o, c);
          s[c] ? (s[c].p(f, a), p(s[c], 1)) : (s[c] = gl(f), s[c].c(), p(s[c], 1), s[c].m(e.parentNode, e));
        }
        for (he(), c = o.length; c < s.length; c += 1)
          i(c);
        we();
      }
      /*$config*/
      u[16].canAddRows ? r ? (r.p(u, a), a[0] & /*$config*/
      65536 && p(r, 1)) : (r = pl(u), r.c(), p(r, 1), r.m(t.parentNode, t)) : r && (he(), w(r, 1, 1, () => {
        r = null;
      }), we());
    },
    i(u) {
      if (!l) {
        for (let a = 0; a < o.length; a += 1)
          p(s[a]);
        p(r), l = !0;
      }
    },
    o(u) {
      s = s.filter(Boolean);
      for (let a = 0; a < s.length; a += 1)
        w(s[a]);
      w(r), l = !1;
    },
    d(u) {
      u && (E(e), E(t)), ct(s, u), r && r.d(u);
    }
  };
}
function Ju(n) {
  let e, t, l, o, s, i, r;
  l = new Gt({
    props: {
      disableNumber: !0,
      defaultHeight: !0,
      rowSelected: (
        /*selectedRowCount*/
        n[3] && /*selectedRowCount*/
        n[3] === /*rowCount*/
        n[2]
      ),
      disabled: !/*$renderedRows*/
      n[6].length
    }
  }), l.$on(
    "select",
    /*selectAll*/
    n[33]
  );
  let u = (
    /*$displayColumn*/
    n[1] && ml(n)
  );
  return i = new Et({
    props: {
      scrollVertically: !0,
      attachHandlers: !0,
      $$slots: { default: [Yu] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      e = $("div"), t = $("div"), W(l.$$.fragment), o = x(), u && u.c(), s = x(), W(i.$$.fragment), U(t, "class", "header row svelte-15yu3r0"), U(e, "class", "sticky-column svelte-15yu3r0"), Ie(e, "flex", "0 0 " + /*width*/
      n[4] + "px"), ne(
        e,
        "scrolled",
        /*$scrollLeft*/
        n[5] > 0
      );
    },
    m(a, c) {
      M(a, e, c), le(e, t), K(l, t, null), le(t, o), u && u.m(t, null), le(e, s), K(i, e, null), r = !0;
    },
    p(a, c) {
      const f = {};
      c[0] & /*selectedRowCount, rowCount*/
      12 && (f.rowSelected = /*selectedRowCount*/
      a[3] && /*selectedRowCount*/
      a[3] === /*rowCount*/
      a[2]), c[0] & /*$renderedRows*/
      64 && (f.disabled = !/*$renderedRows*/
      a[6].length), l.$set(f), /*$displayColumn*/
      a[1] ? u ? (u.p(a, c), c[0] & /*$displayColumn*/
      2 && p(u, 1)) : (u = ml(a), u.c(), p(u, 1), u.m(t, null)) : u && (he(), w(u, 1, 1, () => {
        u = null;
      }), we());
      const d = {};
      c[0] & /*$isDragging, $hoveredRowId, $displayColumn, $config, $renderedRows, $focusedRow, $selectedRows, $selectedCellMap, $selectedCellCount, $isSelectingCells, $focusedCellId, $userCellMap, $contentLines*/
      131011 | c[1] & /*$$scope*/
      2048 && (d.$$scope = { dirty: c, ctx: a }), i.$set(d), (!r || c[0] & /*width*/
      16) && Ie(e, "flex", "0 0 " + /*width*/
      a[4] + "px"), (!r || c[0] & /*$scrollLeft*/
      32) && ne(
        e,
        "scrolled",
        /*$scrollLeft*/
        a[5] > 0
      );
    },
    i(a) {
      r || (p(l.$$.fragment, a), p(u), p(i.$$.fragment, a), r = !0);
    },
    o(a) {
      w(l.$$.fragment, a), w(u), w(i.$$.fragment, a), r = !1;
    },
    d(a) {
      a && E(e), X(l), u && u.d(), X(i);
    }
  };
}
function Qu(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, m, _, g, v, R, b, y, k, { $$slots: h = {}, $$scope: C } = e;
  const { rows: N, selectedRows: S, displayColumn: I, renderedRows: P, focusedCellId: T, hoveredRowId: H, config: z, selectedCellMap: Z, userCellMap: B, focusedRow: te, scrollLeft: _e, dispatch: ie, contentLines: fe, isDragging: ae, isSelectingCells: Re, selectedCellCount: Ce } = Te("grid");
  A(n, N, (V) => t(34, r = V)), A(n, S, (V) => t(0, i = V)), A(n, I, (V) => t(1, u = V)), A(n, P, (V) => t(6, c = V)), A(n, T, (V) => t(13, R = V)), A(n, H, (V) => t(7, f = V)), A(n, z, (V) => t(16, k = V)), A(n, Z, (V) => t(12, v = V)), A(n, B, (V) => t(14, b = V)), A(n, te, (V) => t(10, _ = V)), A(n, _e, (V) => t(5, a = V)), A(n, fe, (V) => t(15, y = V)), A(n, ae, (V) => t(11, g = V)), A(n, Re, (V) => t(9, m = V)), A(n, Ce, (V) => t(8, d = V));
  const ve = () => {
    if (o === l)
      ze(S, i = {}, i);
    else {
      let G = {};
      r.forEach((O) => {
        G[O._id] = !0;
      }), ze(S, i = G, i);
    }
  }, J = (V) => ze(H, f = V._id, f), be = () => ze(H, f = null, f), j = (V) => ie("rowclick", N.actions.cleanRow(V)), Q = () => ze(H, f = ut, f), F = () => ze(H, f = null, f), q = () => ie("add-row-inline");
  return n.$$set = (V) => {
    "$$scope" in V && t(42, C = V.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[1] & /*$rows*/
    8 && t(2, l = r.length), n.$$.dirty[0] & /*$selectedRows*/
    1 && t(3, o = Object.values(i).length), n.$$.dirty[0] & /*$displayColumn*/
    2 && t(4, s = Rt + ((u == null ? void 0 : u.width) || 0));
  }, [
    i,
    u,
    l,
    o,
    s,
    a,
    c,
    f,
    d,
    m,
    _,
    g,
    v,
    R,
    b,
    y,
    k,
    N,
    S,
    I,
    P,
    T,
    H,
    z,
    Z,
    B,
    te,
    _e,
    ie,
    fe,
    ae,
    Re,
    Ce,
    ve,
    r,
    h,
    J,
    be,
    j,
    Q,
    F,
    q,
    C
  ];
}
class Zu extends De {
  constructor(e) {
    super(), Ne(this, e, Qu, Ju, Ee, {}, null, [-1, -1]);
  }
}
function wl(n, e, t) {
  const l = n.slice();
  return l[4] = e[t], l;
}
function bl(n) {
  let e, t;
  return e = new Xo({ props: { user: (
    /*user*/
    n[4]
  ) } }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o & /*uniqueUsers*/
      1 && (s.user = /*user*/
      l[4]), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function $u(n) {
  let e, t, l = He(
    /*uniqueUsers*/
    n[0]
  ), o = [];
  for (let i = 0; i < l.length; i += 1)
    o[i] = bl(wl(n, l, i));
  const s = (i) => w(o[i], 1, 1, () => {
    o[i] = null;
  });
  return {
    c() {
      e = $("div");
      for (let i = 0; i < o.length; i += 1)
        o[i].c();
      U(e, "class", "users svelte-1ex8wrg");
    },
    m(i, r) {
      M(i, e, r);
      for (let u = 0; u < o.length; u += 1)
        o[u] && o[u].m(e, null);
      t = !0;
    },
    p(i, [r]) {
      if (r & /*uniqueUsers*/
      1) {
        l = He(
          /*uniqueUsers*/
          i[0]
        );
        let u;
        for (u = 0; u < l.length; u += 1) {
          const a = wl(i, l, u);
          o[u] ? (o[u].p(a, r), p(o[u], 1)) : (o[u] = bl(a), o[u].c(), p(o[u], 1), o[u].m(e, null));
        }
        for (he(), u = l.length; u < o.length; u += 1)
          s(u);
        we();
      }
    },
    i(i) {
      if (!t) {
        for (let r = 0; r < l.length; r += 1)
          p(o[r]);
        t = !0;
      }
    },
    o(i) {
      o = o.filter(Boolean);
      for (let r = 0; r < o.length; r += 1)
        w(o[r]);
      t = !1;
    },
    d(i) {
      i && E(e), ct(o, i);
    }
  };
}
function xu(n, e, t) {
  let l, o;
  const { users: s } = Te("grid");
  A(n, s, (r) => t(2, o = r));
  const i = (r) => {
    let u = {};
    return r == null || r.forEach((a) => {
      u[a.email] = a;
    }), Object.values(u);
  };
  return n.$$.update = () => {
    n.$$.dirty & /*$users*/
    4 && t(0, l = i(o));
  }, [l, s, o];
}
class ec extends De {
  constructor(e) {
    super(), Ne(this, e, xu, $u, Ee, {});
  }
}
function tc(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, m, _, g;
  const { rows: v, focusedCellId: R, visibleColumns: b, rowLookupMap: y, focusedCellAPI: k, dispatch: h, selectedRowCount: C, config: N, menu: S, gridFocused: I, keyboardBlocked: P, selectedCellCount: T, selectedCells: H, cellSelection: z, columnLookupMap: Z, focusedRowId: B } = Te("grid");
  A(n, v, (j) => t(15, s = j)), A(n, R, (j) => t(18, u = j)), A(n, b, (j) => t(20, c = j)), A(n, y, (j) => t(16, i = j)), A(n, k, (j) => t(13, l = j)), A(n, C, (j) => t(23, m = j)), A(n, N, (j) => t(22, d = j)), A(n, I, (j) => t(25, g = j)), A(n, P, (j) => t(24, _ = j)), A(n, T, (j) => t(14, o = j)), A(n, z, (j) => t(17, r = j)), A(n, Z, (j) => t(21, f = j)), A(n, B, (j) => t(19, a = j));
  const te = [
    ".spectrum-Modal",
    ".date-time-popover",
    "#builder-side-panel-container",
    "[data-grid-ignore]"
  ], _e = (j) => {
    var q, V, G;
    if (!g || _)
      return;
    if ((q = j.target) != null && q.closest) {
      for (let O of te)
        if (j.target.closest(O))
          return;
    }
    const Q = (O) => {
      j.preventDefault(), O();
    };
    if (j.metaKey || j.ctrlKey)
      switch (j.key) {
        case "c":
          return Q(() => h("copy"));
        case "v":
          return h("paste");
        case "Enter":
          return Q(() => {
            d.canAddRows && h("add-row-inline");
          });
      }
    if (o)
      switch (j.key) {
        case "Escape":
          return Q(H.actions.clear);
        case "Delete":
        case "Backspace":
          return Q(() => h("request-bulk-delete"));
      }
    if (!u) {
      j.key === "Tab" || (V = j.key) != null && V.startsWith("Arrow") ? Q(ie) : (j.key === "Delete" || j.key === "Backspace") && Q(() => {
        m && d.canDeleteRows && h("request-bulk-delete");
      });
      return;
    }
    const F = l;
    if (j.key === "Escape")
      return Q(() => {
        F != null && F.isActive() ? setTimeout(F == null ? void 0 : F.blur, 10) : ze(R, u = null, u), S.actions.close();
      });
    if (j.key === "Tab")
      return Q(() => {
        var O;
        (O = F == null ? void 0 : F.blur) == null || O.call(F), fe(1);
      });
    if (!(!(F != null && F.isReadonly()) && ((G = F == null ? void 0 : F.onKeyDown) != null && G.call(F, j))) && !(j.metaKey || j.ctrlKey))
      switch (j.key) {
        case "ArrowLeft":
          return Q(
            () => fe(-1, j.shiftKey)
          );
        case "ArrowRight":
          return Q(() => fe(1, j.shiftKey));
        case "ArrowUp":
          return Q(() => ae(-1, j.shiftKey));
        case "ArrowDown":
          return Q(() => ae(1, j.shiftKey));
        case "Delete":
        case "Backspace":
          return Q(() => {
            m && d.canDeleteRows ? h("request-bulk-delete") : Re();
          });
        case "Enter":
          return Q(Ce);
        default:
          return Q(() => be(j.key, j.which));
      }
  }, ie = () => {
    const j = s[0];
    if (!j)
      return;
    const Q = c[0];
    Q && R.set(xe(j._id, Q.name));
  }, fe = (j, Q) => {
    let F = u;
    if (Q && o && (F = r.targetCellId), !F)
      return;
    const { rowId: q, field: V } = tt(F), G = f[V].__idx, O = c[G + j];
    if (!O)
      return;
    const se = xe(q, O.name);
    Q ? o ? (H.actions.updateTarget(se), o || R.set(se)) : H.actions.selectRange(F, se) : R.set(se);
  }, ae = (j, Q) => {
    if (a === rt)
      return;
    let F = u;
    if (Q && o && (F = r.targetCellId), !F)
      return;
    const { rowId: q, field: V } = tt(F), G = i[q].__idx, O = s[G + j];
    if (!O)
      return;
    const se = xe(O._id, V);
    Q ? o ? (H.actions.updateTarget(se), o || R.set(se)) : H.actions.selectRange(F, se) : R.set(se);
  }, Re = Jl(
    () => {
      l != null && l.isReadonly() || l.setValue(null);
    },
    100
  ), Ce = () => {
    var j;
    l != null && l.isReadonly() || (j = l == null ? void 0 : l.focus) == null || j.call(l);
  }, ve = (j) => j >= 48 && j <= 57, J = (j) => j >= 65 && j <= 90, be = (j, Q) => {
    if (l && !l.isReadonly()) {
      const F = l.getType();
      F === "number" && ve(Q) ? (l.setValue(parseInt(j), { apply: !1 }), l.focus()) : ["string", "barcodeqr", "longform"].includes(F) && (J(Q) || ve(Q)) && (l.setValue(j, { apply: !1 }), l.focus());
    }
  };
  return it(() => (document.addEventListener("keydown", _e), () => {
    document.removeEventListener("keydown", _e);
  })), [
    v,
    R,
    b,
    y,
    k,
    C,
    N,
    I,
    P,
    T,
    z,
    Z,
    B
  ];
}
class nc extends De {
  constructor(e) {
    super(), Ne(this, e, tc, null, Ee, {}, null, [-1, -1]);
  }
}
function kl(n, e, t) {
  const l = n.slice();
  l[64] = e[t];
  const o = xe(
    rt,
    /*column*/
    l[64].name
  );
  return l[65] = o, l;
}
function Yt(n) {
  const e = n.slice(), t = xe(
    rt,
    /*$displayColumn*/
    e[1].name
  );
  return e[65] = t, e;
}
function Cl(n) {
  let e, t, l, o, s, i;
  return t = new nt({ props: { name: "plus", size: "S" } }), {
    c() {
      e = $("div"), W(t.$$.fragment), U(e, "class", "new-row-fab svelte-8ib1kg"), ne(e, "offset", !/*$displayColumn*/
      n[1]);
    },
    m(r, u) {
      M(r, e, u), K(t, e, null), o = !0, s || (i = ke(
        e,
        "click",
        /*click_handler*/
        n[54]
      ), s = !0);
    },
    p(r, u) {
      (!o || u[0] & /*$displayColumn*/
      2) && ne(e, "offset", !/*$displayColumn*/
      r[1]);
    },
    i(r) {
      o || (p(t.$$.fragment, r), r && mt(() => {
        o && (l || (l = st(e, Ze, { duration: 130 }, !0)), l.run(1));
      }), o = !0);
    },
    o(r) {
      w(t.$$.fragment, r), r && (l || (l = st(e, Ze, { duration: 130 }, !1)), l.run(0)), o = !1;
    },
    d(r) {
      r && E(e), X(t), r && l && l.end(), s = !1, i();
    }
  };
}
function lc(n) {
  let e, t, l = !/*visible*/
  n[2] && !/*selectedRowCount*/
  n[7] && /*$config*/
  n[14].canAddRows && Cl(n);
  return {
    c() {
      l && l.c(), e = Ae();
    },
    m(o, s) {
      l && l.m(o, s), M(o, e, s), t = !0;
    },
    p(o, s) {
      !/*visible*/
      o[2] && !/*selectedRowCount*/
      o[7] && /*$config*/
      o[14].canAddRows ? l ? (l.p(o, s), s[0] & /*visible, selectedRowCount, $config*/
      16516 && p(l, 1)) : (l = Cl(o), l.c(), p(l, 1), l.m(e.parentNode, e)) : l && (he(), w(l, 1, 1, () => {
        l = null;
      }), we());
    },
    i(o) {
      t || (p(l), t = !0);
    },
    o(o) {
      w(l), t = !1;
    },
    d(o) {
      o && E(e), l && l.d(o);
    }
  };
}
function Rl(n) {
  let e, t, l, o, s, i, r, u, a, c, f, d, m, _, g, v, R, b, y, k, h, C, N;
  c = new Gt({
    props: {
      expandable: !0,
      rowHovered: !0,
      $$slots: { default: [oc] },
      $$scope: { ctx: n }
    }
  }), c.$on(
    "expand",
    /*addViaModal*/
    n[42]
  );
  let S = (
    /*$displayColumn*/
    n[1] && Sl(Yt(n))
  );
  return g = new Et({
    props: {
      scrollHorizontally: !0,
      attachHandlers: !0,
      $$slots: { default: [ic] },
      $$scope: { ctx: n }
    }
  }), y = new Ht({
    props: {
      size: "M",
      cta: !0,
      disabled: (
        /*isAdding*/
        n[3]
      ),
      $$slots: { default: [uc] },
      $$scope: { ctx: n }
    }
  }), y.$on(
    "click",
    /*addRow*/
    n[39]
  ), h = new Ht({
    props: {
      size: "M",
      secondary: !0,
      newStyles: !0,
      $$slots: { default: [cc] },
      $$scope: { ctx: n }
    }
  }), h.$on(
    "click",
    /*clear*/
    n[40]
  ), {
    c() {
      e = $("div"), t = $("div"), o = x(), s = $("div"), r = x(), u = $("div"), a = $("div"), W(c.$$.fragment), f = x(), S && S.c(), m = x(), _ = $("div"), W(g.$$.fragment), R = x(), b = $("div"), W(y.$$.fragment), k = x(), W(h.$$.fragment), U(t, "class", "underlay sticky svelte-8ib1kg"), U(s, "class", "underlay svelte-8ib1kg"), U(a, "class", "row svelte-8ib1kg"), U(u, "class", "sticky-column svelte-8ib1kg"), U(_, "class", "normal-columns svelte-8ib1kg"), U(b, "class", "buttons svelte-8ib1kg"), ne(
        b,
        "flip",
        /*flipButtons*/
        n[5]
      ), U(e, "class", "new-row svelte-8ib1kg"), Ie(
        e,
        "--offset",
        /*offset*/
        n[0] + "px"
      ), Ie(
        e,
        "--sticky-width",
        /*width*/
        n[8] + "px"
      ), ne(
        e,
        "floating",
        /*offset*/
        n[0] > 0
      );
    },
    m(I, P) {
      M(I, e, P), le(e, t), le(e, o), le(e, s), le(e, r), le(e, u), le(u, a), K(c, a, null), le(a, f), S && S.m(a, null), le(e, m), le(e, _), K(g, _, null), le(e, R), le(e, b), K(y, b, null), le(b, k), K(h, b, null), N = !0;
    },
    p(I, P) {
      const T = {};
      P[0] & /*isAdding*/
      8 | P[2] & /*$$scope*/
      64 && (T.$$scope = { dirty: P, ctx: I }), c.$set(T), /*$displayColumn*/
      I[1] ? S ? (S.p(Yt(I), P), P[0] & /*$displayColumn*/
      2 && p(S, 1)) : (S = Sl(Yt(I)), S.c(), p(S, 1), S.m(a, null)) : S && (he(), w(S, 1, 1, () => {
        S = null;
      }), we());
      const H = {};
      P[0] & /*$scrollableColumns, newRow, $focusedCellId, offset, $columnRenderMap, isAdding*/
      98841 | P[2] & /*$$scope*/
      64 && (H.$$scope = { dirty: P, ctx: I }), g.$set(H);
      const z = {};
      P[0] & /*isAdding*/
      8 && (z.disabled = /*isAdding*/
      I[3]), P[2] & /*$$scope*/
      64 && (z.$$scope = { dirty: P, ctx: I }), y.$set(z);
      const Z = {};
      P[2] & /*$$scope*/
      64 && (Z.$$scope = { dirty: P, ctx: I }), h.$set(Z), (!N || P[0] & /*flipButtons*/
      32) && ne(
        b,
        "flip",
        /*flipButtons*/
        I[5]
      ), (!N || P[0] & /*offset*/
      1) && Ie(
        e,
        "--offset",
        /*offset*/
        I[0] + "px"
      ), (!N || P[0] & /*width*/
      256) && Ie(
        e,
        "--sticky-width",
        /*width*/
        I[8] + "px"
      ), (!N || P[0] & /*offset*/
      1) && ne(
        e,
        "floating",
        /*offset*/
        I[0] > 0
      );
    },
    i(I) {
      N || (I && mt(() => {
        N && (l || (l = st(t, Ze, { duration: 130 }, !0)), l.run(1));
      }), I && mt(() => {
        N && (i || (i = st(s, Ze, { duration: 130 }, !0)), i.run(1));
      }), p(c.$$.fragment, I), p(S), I && mt(() => {
        N && (d || (d = st(u, Ze, { duration: 130 }, !0)), d.run(1));
      }), p(g.$$.fragment, I), I && mt(() => {
        N && (v || (v = st(_, Ze, { duration: 130 }, !0)), v.run(1));
      }), p(y.$$.fragment, I), p(h.$$.fragment, I), I && mt(() => {
        N && (C || (C = st(b, Ze, { duration: 130 }, !0)), C.run(1));
      }), N = !0);
    },
    o(I) {
      I && (l || (l = st(t, Ze, { duration: 130 }, !1)), l.run(0)), I && (i || (i = st(s, Ze, { duration: 130 }, !1)), i.run(0)), w(c.$$.fragment, I), w(S), I && (d || (d = st(u, Ze, { duration: 130 }, !1)), d.run(0)), w(g.$$.fragment, I), I && (v || (v = st(_, Ze, { duration: 130 }, !1)), v.run(0)), w(y.$$.fragment, I), w(h.$$.fragment, I), I && (C || (C = st(b, Ze, { duration: 130 }, !1)), C.run(0)), N = !1;
    },
    d(I) {
      I && E(e), I && l && l.end(), I && i && i.end(), X(c), S && S.d(), I && d && d.end(), X(g), I && v && v.end(), X(y), X(h), I && C && C.end();
    }
  };
}
function vl(n) {
  let e, t;
  return {
    c() {
      e = $("div"), U(e, "class", "loading-overlay svelte-8ib1kg");
    },
    m(l, o) {
      M(l, e, o);
    },
    i(l) {
      l && (t || mt(() => {
        t = Vt(e, Ze, { duration: 130 }), t.start();
      }));
    },
    o: Oe,
    d(l) {
      l && E(e);
    }
  };
}
function oc(n) {
  let e, t, l, o;
  e = new nt({
    props: {
      name: "plus",
      color: "var(--spectrum-global-color-gray-500)"
    }
  });
  let s = (
    /*isAdding*/
    n[3] && vl()
  );
  return {
    c() {
      W(e.$$.fragment), t = x(), s && s.c(), l = Ae();
    },
    m(i, r) {
      K(e, i, r), M(i, t, r), s && s.m(i, r), M(i, l, r), o = !0;
    },
    p(i, r) {
      /*isAdding*/
      i[3] ? s ? r[0] & /*isAdding*/
      8 && p(s, 1) : (s = vl(), s.c(), p(s, 1), s.m(l.parentNode, l)) : s && (s.d(1), s = null);
    },
    i(i) {
      o || (p(e.$$.fragment, i), p(s), o = !0);
    },
    o(i) {
      w(e.$$.fragment, i), o = !1;
    },
    d(i) {
      i && (E(t), E(l)), X(e, i), s && s.d(i);
    }
  };
}
function Sl(n) {
  let e, t;
  return e = new qt({
    props: {
      cellId: (
        /*cellId*/
        n[65]
      ),
      rowFocused: !0,
      column: (
        /*$displayColumn*/
        n[1]
      ),
      row: (
        /*newRow*/
        n[4]
      ),
      focused: (
        /*$focusedCellId*/
        n[9] === /*cellId*/
        n[65]
      ),
      width: (
        /*$displayColumn*/
        n[1].width
      ),
      updateValue: (
        /*updateValue*/
        n[41]
      ),
      topRow: (
        /*offset*/
        n[0] === 0
      ),
      $$slots: { default: [sc] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*$displayColumn*/
      2 && (s.cellId = /*cellId*/
      l[65]), o[0] & /*$displayColumn*/
      2 && (s.column = /*$displayColumn*/
      l[1]), o[0] & /*newRow*/
      16 && (s.row = /*newRow*/
      l[4]), o[0] & /*$focusedCellId, $displayColumn*/
      514 && (s.focused = /*$focusedCellId*/
      l[9] === /*cellId*/
      l[65]), o[0] & /*$displayColumn*/
      2 && (s.width = /*$displayColumn*/
      l[1].width), o[0] & /*offset*/
      1 && (s.topRow = /*offset*/
      l[0] === 0), o[0] & /*isAdding, $displayColumn*/
      10 | o[2] & /*$$scope*/
      64 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function yl(n) {
  let e;
  return {
    c() {
      e = $("div"), e.textContent = "Can't edit auto column", U(e, "class", "readonly-overlay svelte-8ib1kg");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function Il(n) {
  let e, t;
  return {
    c() {
      e = $("div"), U(e, "class", "loading-overlay svelte-8ib1kg");
    },
    m(l, o) {
      M(l, e, o);
    },
    i(l) {
      l && (t || mt(() => {
        t = Vt(e, Ze, { duration: 130 }), t.start();
      }));
    },
    o: Oe,
    d(l) {
      l && E(e);
    }
  };
}
function sc(n) {
  var s, i;
  let e, t, l = (
    /*$displayColumn*/
    ((i = (s = n[1]) == null ? void 0 : s.schema) == null ? void 0 : i.autocolumn) && yl()
  ), o = (
    /*isAdding*/
    n[3] && Il()
  );
  return {
    c() {
      l && l.c(), e = x(), o && o.c(), t = Ae();
    },
    m(r, u) {
      l && l.m(r, u), M(r, e, u), o && o.m(r, u), M(r, t, u);
    },
    p(r, u) {
      var a, c;
      /*$displayColumn*/
      (c = (a = r[1]) == null ? void 0 : a.schema) != null && c.autocolumn ? l || (l = yl(), l.c(), l.m(e.parentNode, e)) : l && (l.d(1), l = null), /*isAdding*/
      r[3] ? o ? u[0] & /*isAdding*/
      8 && p(o, 1) : (o = Il(), o.c(), p(o, 1), o.m(t.parentNode, t)) : o && (o.d(1), o = null);
    },
    d(r) {
      r && (E(e), E(t)), l && l.d(r), o && o.d(r);
    }
  };
}
function Ml(n) {
  let e;
  return {
    c() {
      e = $("div"), e.textContent = "Can't edit auto column", U(e, "class", "readonly-overlay svelte-8ib1kg");
    },
    m(t, l) {
      M(t, e, l);
    },
    d(t) {
      t && E(e);
    }
  };
}
function El(n) {
  let e, t;
  return {
    c() {
      e = $("div"), U(e, "class", "loading-overlay svelte-8ib1kg");
    },
    m(l, o) {
      M(l, e, o);
    },
    i(l) {
      l && (t || mt(() => {
        t = Vt(e, Ze, { duration: 130 }), t.start();
      }));
    },
    o: Oe,
    d(l) {
      l && E(e);
    }
  };
}
function rc(n) {
  var s, i;
  let e, t, l = (
    /*column*/
    ((i = (s = n[64]) == null ? void 0 : s.schema) == null ? void 0 : i.autocolumn) && Ml()
  ), o = (
    /*isAdding*/
    n[3] && El()
  );
  return {
    c() {
      l && l.c(), e = x(), o && o.c(), t = x();
    },
    m(r, u) {
      l && l.m(r, u), M(r, e, u), o && o.m(r, u), M(r, t, u);
    },
    p(r, u) {
      var a, c;
      /*column*/
      (c = (a = r[64]) == null ? void 0 : a.schema) != null && c.autocolumn ? l || (l = Ml(), l.c(), l.m(e.parentNode, e)) : l && (l.d(1), l = null), /*isAdding*/
      r[3] ? o ? u[0] & /*isAdding*/
      8 && p(o, 1) : (o = El(), o.c(), p(o, 1), o.m(t.parentNode, t)) : o && (o.d(1), o = null);
    },
    d(r) {
      r && (E(e), E(t)), l && l.d(r), o && o.d(r);
    }
  };
}
function Al(n) {
  let e, t;
  return e = new qt({
    props: {
      cellId: (
        /*cellId*/
        n[65]
      ),
      column: (
        /*column*/
        n[64]
      ),
      updateValue: (
        /*updateValue*/
        n[41]
      ),
      rowFocused: !0,
      row: (
        /*newRow*/
        n[4]
      ),
      focused: (
        /*$focusedCellId*/
        n[9] === /*cellId*/
        n[65]
      ),
      width: (
        /*column*/
        n[64].width
      ),
      topRow: (
        /*offset*/
        n[0] === 0
      ),
      hidden: !/*$columnRenderMap*/
      n[16][
        /*column*/
        n[64].name
      ],
      $$slots: { default: [rc] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    p(l, o) {
      const s = {};
      o[0] & /*$scrollableColumns*/
      32768 && (s.cellId = /*cellId*/
      l[65]), o[0] & /*$scrollableColumns*/
      32768 && (s.column = /*column*/
      l[64]), o[0] & /*newRow*/
      16 && (s.row = /*newRow*/
      l[4]), o[0] & /*$focusedCellId, $scrollableColumns*/
      33280 && (s.focused = /*$focusedCellId*/
      l[9] === /*cellId*/
      l[65]), o[0] & /*$scrollableColumns*/
      32768 && (s.width = /*column*/
      l[64].width), o[0] & /*offset*/
      1 && (s.topRow = /*offset*/
      l[0] === 0), o[0] & /*$columnRenderMap, $scrollableColumns*/
      98304 && (s.hidden = !/*$columnRenderMap*/
      l[16][
        /*column*/
        l[64].name
      ]), o[0] & /*isAdding, $scrollableColumns*/
      32776 | o[2] & /*$$scope*/
      64 && (s.$$scope = { dirty: o, ctx: l }), e.$set(s);
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function ic(n) {
  let e, t, l = He(
    /*$scrollableColumns*/
    n[15]
  ), o = [];
  for (let i = 0; i < l.length; i += 1)
    o[i] = Al(kl(n, l, i));
  const s = (i) => w(o[i], 1, 1, () => {
    o[i] = null;
  });
  return {
    c() {
      e = $("div");
      for (let i = 0; i < o.length; i += 1)
        o[i].c();
      U(e, "class", "row svelte-8ib1kg");
    },
    m(i, r) {
      M(i, e, r);
      for (let u = 0; u < o.length; u += 1)
        o[u] && o[u].m(e, null);
      t = !0;
    },
    p(i, r) {
      if (r[0] & /*$scrollableColumns, newRow, $focusedCellId, offset, $columnRenderMap, isAdding*/
      98841 | r[1] & /*updateValue*/
      1024) {
        l = He(
          /*$scrollableColumns*/
          i[15]
        );
        let u;
        for (u = 0; u < l.length; u += 1) {
          const a = kl(i, l, u);
          o[u] ? (o[u].p(a, r), p(o[u], 1)) : (o[u] = Al(a), o[u].c(), p(o[u], 1), o[u].m(e, null));
        }
        for (he(), u = l.length; u < o.length; u += 1)
          s(u);
        we();
      }
    },
    i(i) {
      if (!t) {
        for (let r = 0; r < l.length; r += 1)
          p(o[r]);
        t = !0;
      }
    },
    o(i) {
      o = o.filter(Boolean);
      for (let r = 0; r < o.length; r += 1)
        w(o[r]);
      t = !1;
    },
    d(i) {
      i && E(e), ct(o, i);
    }
  };
}
function uc(n) {
  let e, t, l, o;
  return l = new nn({
    props: { overlay: !0, keybind: "Ctrl+Enter" }
  }), {
    c() {
      e = $("div"), t = de(`Save
          `), W(l.$$.fragment), U(e, "class", "button-with-keys svelte-8ib1kg");
    },
    m(s, i) {
      M(s, e, i), le(e, t), K(l, e, null), o = !0;
    },
    p: Oe,
    i(s) {
      o || (p(l.$$.fragment, s), o = !0);
    },
    o(s) {
      w(l.$$.fragment, s), o = !1;
    },
    d(s) {
      s && E(e), X(l);
    }
  };
}
function cc(n) {
  let e, t, l, o;
  return l = new nn({ props: { keybind: "Esc" } }), {
    c() {
      e = $("div"), t = de(`Cancel
          `), W(l.$$.fragment), U(e, "class", "button-with-keys svelte-8ib1kg");
    },
    m(s, i) {
      M(s, e, i), le(e, t), K(l, e, null), o = !0;
    },
    p: Oe,
    i(s) {
      o || (p(l.$$.fragment, s), o = !0);
    },
    o(s) {
      w(l.$$.fragment, s), o = !1;
    },
    d(s) {
      s && E(e), X(l);
    }
  };
}
function ac(n) {
  var i, r;
  let e, t, l, o;
  e = new eo({
    props: {
      text: "Click here to create your first row",
      condition: (
        /*hasNoRows*/
        n[6] && /*$loaded*/
        n[10] && !/*$filter*/
        ((i = n[11]) != null && i.length) && !/*$inlineFilters*/
        ((r = n[12]) != null && r.length) && !/*$refreshing*/
        n[13]
      ),
      type: Ql.Info,
      $$slots: { default: [lc] },
      $$scope: { ctx: n }
    }
  });
  let s = (
    /*visible*/
    n[2] && Rl(n)
  );
  return {
    c() {
      W(e.$$.fragment), t = x(), s && s.c(), l = Ae();
    },
    m(u, a) {
      K(e, u, a), M(u, t, a), s && s.m(u, a), M(u, l, a), o = !0;
    },
    p(u, a) {
      var f, d;
      const c = {};
      a[0] & /*hasNoRows, $loaded, $filter, $inlineFilters, $refreshing*/
      15424 && (c.condition = /*hasNoRows*/
      u[6] && /*$loaded*/
      u[10] && !/*$filter*/
      ((f = u[11]) != null && f.length) && !/*$inlineFilters*/
      ((d = u[12]) != null && d.length) && !/*$refreshing*/
      u[13]), a[0] & /*$displayColumn, visible, selectedRowCount, $config*/
      16518 | a[2] & /*$$scope*/
      64 && (c.$$scope = { dirty: a, ctx: u }), e.$set(c), /*visible*/
      u[2] ? s ? (s.p(u, a), a[0] & /*visible*/
      4 && p(s, 1)) : (s = Rl(u), s.c(), p(s, 1), s.m(l.parentNode, l)) : s && (he(), w(s, 1, 1, () => {
        s = null;
      }), we());
    },
    i(u) {
      o || (p(e.$$.fragment, u), p(s), o = !0);
    },
    o(u) {
      w(e.$$.fragment, u), w(s), o = !1;
    },
    d(u) {
      u && (E(t), E(l)), X(e, u), s && s.d(u);
    }
  };
}
function fc(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, m, _, g, v, R, b, y, k, h, C, N, S, I, P, T, H, z, Z;
  const { hoveredRowId: B, focusedCellId: te, displayColumn: _e, scroll: ie, dispatch: fe, rows: ae, focusedCellAPI: Re, datasource: Ce, subscribe: ve, renderedRows: J, scrollableColumns: be, rowHeight: j, hasNextPage: Q, maxScrollTop: F, selectedRows: q, loaded: V, refreshing: G, config: O, filter: se, inlineFilters: ge, columnRenderMap: ue, visibleColumns: D, scrollTop: re, height: oe } = Te("grid");
  A(n, B, (pe) => t(57, d = pe)), A(n, te, (pe) => t(9, f = pe)), A(n, _e, (pe) => t(1, C = pe)), A(n, ae, (pe) => t(50, y = pe)), A(n, Re, (pe) => t(56, c = pe)), A(n, Ce, (pe) => t(52, h = pe)), A(n, J, (pe) => t(49, b = pe)), A(n, be, (pe) => t(15, z = pe)), A(n, j, (pe) => t(46, g = pe)), A(n, Q, (pe) => t(45, _ = pe)), A(n, F, (pe) => t(58, m = pe)), A(n, q, (pe) => t(51, k = pe)), A(n, V, (pe) => t(10, S = pe)), A(n, G, (pe) => t(13, T = pe)), A(n, O, (pe) => t(14, H = pe)), A(n, se, (pe) => t(11, I = pe)), A(n, ge, (pe) => t(12, P = pe)), A(n, ue, (pe) => t(16, Z = pe)), A(n, D, (pe) => t(53, N = pe)), A(n, re, (pe) => t(48, R = pe)), A(n, oe, (pe) => t(47, v = pe));
  let ye = !1, Le = !1, qe, Ve = 0;
  const bt = (pe, et, _t, Y) => pe ? 0 : (t(0, Ve = et * _t - Y % _t), et !== 0 && t(0, Ve -= 1), Ve), pt = async () => {
    t(3, Le = !0), ze(te, f = null, f), await vt();
    const pe = Ve ? void 0 : 0;
    let et = { ...qe };
    delete et._isNewRow;
    const _t = await ae.actions.addRow({ row: et, idx: pe });
    _t && (at(), l && ze(te, f = xe(_t._id, l.name), f)), t(3, Le = !1);
  }, at = () => {
    t(3, Le = !1), t(2, ye = !1), ze(te, f = null, f), ze(B, d = null, d), document.removeEventListener("keydown", kt);
  }, ee = async () => {
    if (ye && !Le) {
      await pt();
      return;
    }
    ye || !l || (_ || ie.update((pe) => ({ ...pe, top: m })), t(4, qe = { _isNewRow: !0 }), t(2, ye = !0), ze(B, d = rt, d), l && ze(te, f = xe(rt, l.name), f), document.addEventListener("keydown", kt));
  }, ht = ({ column: pe, value: et }) => {
    t(4, qe[pe] = et, qe);
  }, At = () => {
    at(), fe("add-row");
  }, kt = (pe) => {
    ye && pe.key === "Escape" && (c != null && c.isActive() || (pe.preventDefault(), at()));
  };
  it(() => ve("add-row-inline", ee)), Vl(() => {
    document.removeEventListener("keydown", kt);
  });
  const Lt = () => fe("add-row-inline");
  return n.$$.update = () => {
    n.$$.dirty[1] & /*$visibleColumns*/
    4194304 && (l = N[0]), n.$$.dirty[0] & /*$displayColumn*/
    2 && t(8, o = Rt + ((C == null ? void 0 : C.width) || 0)), n.$$.dirty[1] & /*$datasource*/
    2097152 && t(2, ye = !1), n.$$.dirty[1] & /*$selectedRows*/
    1048576 && t(7, s = Object.values(k).length), n.$$.dirty[1] & /*$rows*/
    524288 && t(6, i = !y.length), n.$$.dirty[1] & /*$renderedRows*/
    262144 && t(44, r = b.length), n.$$.dirty[1] & /*$hasNextPage, renderedRowCount, $rowHeight, $scrollTop*/
    188416 && t(0, Ve = bt(_, r, g, R)), n.$$.dirty[0] & /*offset*/
    1 | n.$$.dirty[1] & /*$height, $rowHeight*/
    98304 && t(43, u = v - Ve - g), n.$$.dirty[1] & /*spaceBelow*/
    4096 && t(5, a = u < 36 + St);
  }, [
    Ve,
    C,
    ye,
    Le,
    qe,
    a,
    i,
    s,
    o,
    f,
    S,
    I,
    P,
    T,
    H,
    z,
    Z,
    B,
    te,
    _e,
    fe,
    ae,
    Re,
    Ce,
    J,
    be,
    j,
    Q,
    F,
    q,
    V,
    G,
    O,
    se,
    ge,
    ue,
    D,
    re,
    oe,
    pt,
    at,
    ht,
    At,
    u,
    r,
    _,
    g,
    v,
    R,
    b,
    y,
    k,
    h,
    N,
    Lt
  ];
}
class dc extends De {
  constructor(e) {
    super(), Ne(this, e, fc, ac, Ee, {}, null, [-1, -1, -1]);
  }
}
const mc = (n) => {
  const { rows: e, datasource: t, users: l, focusedCellId: o, definition: s, API: i } = n, r = zo("/socket/grid"), u = (a) => {
    if (!r.connected)
      return;
    const c = i.getAppID();
    r.emit(
      Dt.SelectDatasource,
      {
        datasource: a,
        appId: c
      },
      ({ users: f }) => {
        l.set(f);
      }
    );
  };
  return r.on("connect", () => {
    u(L(t));
  }), r.on("connect_error", (a) => {
    console.error("Failed to connect to grid websocket:", a.message);
  }), r.onOther(rn.UserUpdate, ({ user: a }) => {
    l.actions.updateUser(a);
  }), r.onOther(rn.UserDisconnect, ({ sessionId: a }) => {
    l.actions.removeUser(a);
  }), r.onOther(Dt.RowChange, async ({ id: a, row: c }) => {
    a ? e.actions.replaceRow(a, c) : c.id && await e.actions.refreshRow(c.id);
  }), r.onOther(
    Dt.DatasourceChange,
    ({ datasource: a }) => {
      a && s.set(a);
    }
  ), r.on(
    Dt.DatasourceChange,
    ({ datasource: a }) => {
      var c;
      (a == null ? void 0 : a.name) !== ((c = L(s)) == null ? void 0 : c.name) && s.set(a);
    }
  ), t.subscribe(u), o.subscribe((a) => {
    r.emit(Dt.SelectCell, { cellId: a });
  }), () => r == null ? void 0 : r.disconnect();
}, _c = (n) => ({}), Ll = (n) => ({}), gc = (n) => ({}), Dl = (n) => ({}), pc = (n) => ({}), Nl = (n) => ({}), hc = (n) => ({}), Ol = (n) => ({}), wc = (n) => ({}), Tl = (n) => ({});
function zl(n) {
  let e, t, l, o, s, i;
  const r = (
    /*#slots*/
    n[52].controls
  ), u = We(
    r,
    n,
    /*$$scope*/
    n[55],
    Tl
  ), a = (
    /*#slots*/
    n[52]["controls-right"]
  ), c = We(
    a,
    n,
    /*$$scope*/
    n[55],
    Ol
  );
  let f = (
    /*showAvatars*/
    n[2] && Pl()
  );
  return {
    c() {
      e = $("div"), t = $("div"), u && u.c(), l = x(), o = $("div"), c && c.c(), s = x(), f && f.c(), U(t, "class", "controls-left svelte-fdk5zl"), U(o, "class", "controls-right svelte-fdk5zl"), U(e, "class", "controls svelte-fdk5zl");
    },
    m(d, m) {
      M(d, e, m), le(e, t), u && u.m(t, null), le(e, l), le(e, o), c && c.m(o, null), le(o, s), f && f.m(o, null), i = !0;
    },
    p(d, m) {
      u && u.p && (!i || m[1] & /*$$scope*/
      16777216) && Ke(
        u,
        r,
        d,
        /*$$scope*/
        d[55],
        i ? Ye(
          r,
          /*$$scope*/
          d[55],
          m,
          wc
        ) : Xe(
          /*$$scope*/
          d[55]
        ),
        Tl
      ), c && c.p && (!i || m[1] & /*$$scope*/
      16777216) && Ke(
        c,
        a,
        d,
        /*$$scope*/
        d[55],
        i ? Ye(
          a,
          /*$$scope*/
          d[55],
          m,
          hc
        ) : Xe(
          /*$$scope*/
          d[55]
        ),
        Ol
      ), /*showAvatars*/
      d[2] ? f ? m[0] & /*showAvatars*/
      4 && p(f, 1) : (f = Pl(), f.c(), p(f, 1), f.m(o, null)) : f && (he(), w(f, 1, 1, () => {
        f = null;
      }), we());
    },
    i(d) {
      i || (p(u, d), p(c, d), p(f), i = !0);
    },
    o(d) {
      w(u, d), w(c, d), w(f), i = !1;
    },
    d(d) {
      d && E(e), u && u.d(d), c && c.d(d), f && f.d();
    }
  };
}
function Pl(n) {
  let e, t;
  return e = new ec({}), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function bc(n) {
  let e, t, l, o, s, i, r, u, a, c, f, d, m, _, g, v, R, b, y, k, h, C, N;
  l = new Zu({
    props: {
      $$slots: {
        "edit-column": [Cc]
      },
      $$scope: { ctx: n }
    }
  }), i = new au({
    props: {
      $$slots: {
        "edit-column": [vc],
        "add-column": [Rc]
      },
      $$scope: { ctx: n }
    }
  }), u = new bi({});
  let S = (
    /*$config*/
    n[10].canAddRows && Hl()
  );
  return d = new Ri({}), _ = new Ii({}), v = new mu({}), b = new Tu({}), k = new Ei({}), {
    c() {
      e = $("div"), t = $("div"), W(l.$$.fragment), o = x(), s = $("div"), W(i.$$.fragment), r = x(), W(u.$$.fragment), a = x(), S && S.c(), c = x(), f = $("div"), W(d.$$.fragment), m = x(), W(_.$$.fragment), g = x(), W(v.$$.fragment), R = x(), W(b.$$.fragment), y = x(), W(k.$$.fragment), U(s, "class", "grid-data-content svelte-fdk5zl"), U(f, "class", "overlays svelte-fdk5zl"), U(t, "class", "grid-data-inner svelte-fdk5zl"), U(e, "class", "grid-data-outer svelte-fdk5zl");
    },
    m(I, P) {
      M(I, e, P), le(e, t), K(l, t, null), le(t, o), le(t, s), K(i, s, null), le(s, r), K(u, s, null), le(t, a), S && S.m(t, null), le(t, c), le(t, f), K(d, f, null), le(f, m), K(_, f, null), le(f, g), K(v, f, null), le(f, R), K(b, f, null), le(f, y), K(k, f, null), h = !0, C || (N = $l(Uo.call(
        null,
        e,
        /*ui*/
        n[16].actions.blur
      )), C = !0);
    },
    p(I, P) {
      const T = {};
      P[1] & /*$$scope*/
      16777216 && (T.$$scope = { dirty: P, ctx: I }), l.$set(T);
      const H = {};
      P[1] & /*$$scope*/
      16777216 && (H.$$scope = { dirty: P, ctx: I }), i.$set(H), /*$config*/
      I[10].canAddRows ? S ? P[0] & /*$config*/
      1024 && p(S, 1) : (S = Hl(), S.c(), p(S, 1), S.m(t, c)) : S && (he(), w(S, 1, 1, () => {
        S = null;
      }), we());
    },
    i(I) {
      h || (p(l.$$.fragment, I), p(i.$$.fragment, I), p(u.$$.fragment, I), p(S), p(d.$$.fragment, I), p(_.$$.fragment, I), p(v.$$.fragment, I), p(b.$$.fragment, I), p(k.$$.fragment, I), h = !0);
    },
    o(I) {
      w(l.$$.fragment, I), w(i.$$.fragment, I), w(u.$$.fragment, I), w(S), w(d.$$.fragment, I), w(_.$$.fragment, I), w(v.$$.fragment, I), w(b.$$.fragment, I), w(k.$$.fragment, I), h = !1;
    },
    d(I) {
      I && E(e), X(l), X(i), X(u), S && S.d(), X(d), X(_), X(v), X(b), X(k), C = !1, N();
    }
  };
}
function kc(n) {
  let e, t, l, o, s;
  return {
    c() {
      e = $("div"), t = $("div"), t.textContent = "There was a problem loading your grid", l = x(), o = $("div"), s = de(
        /*$error*/
        n[8]
      ), U(t, "class", "grid-error-title svelte-fdk5zl"), U(o, "class", "grid-error-subtitle svelte-fdk5zl"), U(e, "class", "grid-error svelte-fdk5zl");
    },
    m(i, r) {
      M(i, e, r), le(e, t), le(e, l), le(e, o), le(o, s);
    },
    p(i, r) {
      r[0] & /*$error*/
      256 && je(
        s,
        /*$error*/
        i[8]
      );
    },
    i: Oe,
    o: Oe,
    d(i) {
      i && E(e);
    }
  };
}
function Cc(n) {
  let e;
  const t = (
    /*#slots*/
    n[52]["edit-column"]
  ), l = We(
    t,
    n,
    /*$$scope*/
    n[55],
    Nl
  );
  return {
    c() {
      l && l.c();
    },
    m(o, s) {
      l && l.m(o, s), e = !0;
    },
    p(o, s) {
      l && l.p && (!e || s[1] & /*$$scope*/
      16777216) && Ke(
        l,
        t,
        o,
        /*$$scope*/
        o[55],
        e ? Ye(
          t,
          /*$$scope*/
          o[55],
          s,
          pc
        ) : Xe(
          /*$$scope*/
          o[55]
        ),
        Nl
      );
    },
    i(o) {
      e || (p(l, o), e = !0);
    },
    o(o) {
      w(l, o), e = !1;
    },
    d(o) {
      l && l.d(o);
    }
  };
}
function Rc(n) {
  let e;
  const t = (
    /*#slots*/
    n[52]["add-column"]
  ), l = We(
    t,
    n,
    /*$$scope*/
    n[55],
    Ll
  );
  return {
    c() {
      l && l.c();
    },
    m(o, s) {
      l && l.m(o, s), e = !0;
    },
    p(o, s) {
      l && l.p && (!e || s[1] & /*$$scope*/
      16777216) && Ke(
        l,
        t,
        o,
        /*$$scope*/
        o[55],
        e ? Ye(
          t,
          /*$$scope*/
          o[55],
          s,
          _c
        ) : Xe(
          /*$$scope*/
          o[55]
        ),
        Ll
      );
    },
    i(o) {
      e || (p(l, o), e = !0);
    },
    o(o) {
      w(l, o), e = !1;
    },
    d(o) {
      l && l.d(o);
    }
  };
}
function vc(n) {
  let e;
  const t = (
    /*#slots*/
    n[52]["edit-column"]
  ), l = We(
    t,
    n,
    /*$$scope*/
    n[55],
    Dl
  );
  return {
    c() {
      l && l.c();
    },
    m(o, s) {
      l && l.m(o, s), e = !0;
    },
    p(o, s) {
      l && l.p && (!e || s[1] & /*$$scope*/
      16777216) && Ke(
        l,
        t,
        o,
        /*$$scope*/
        o[55],
        e ? Ye(
          t,
          /*$$scope*/
          o[55],
          s,
          gc
        ) : Xe(
          /*$$scope*/
          o[55]
        ),
        Dl
      );
    },
    i(o) {
      e || (p(l, o), e = !0);
    },
    o(o) {
      w(l, o), e = !1;
    },
    d(o) {
      l && l.d(o);
    }
  };
}
function Hl(n) {
  let e, t;
  return e = new dc({}), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function Fl(n) {
  let e, t, l, o;
  return t = new Vo({}), {
    c() {
      e = $("div"), W(t.$$.fragment), U(e, "class", "grid-loading svelte-fdk5zl");
    },
    m(s, i) {
      M(s, e, i), K(t, e, null), o = !0;
    },
    i(s) {
      o || (p(t.$$.fragment, s), s && (l || mt(() => {
        l = Vt(e, Ze, { duration: 130 }), l.start();
      })), o = !0);
    },
    o(s) {
      w(t.$$.fragment, s), o = !1;
    },
    d(s) {
      s && E(e), X(t);
    }
  };
}
function Bl(n) {
  let e, t;
  return e = new Gr({}), {
    c() {
      W(e.$$.fragment);
    },
    m(l, o) {
      K(e, l, o), t = !0;
    },
    i(l) {
      t || (p(e.$$.fragment, l), t = !0);
    },
    o(l) {
      w(e.$$.fragment, l), t = !1;
    },
    d(l) {
      X(e, l);
    }
  };
}
function jl(n) {
  let e;
  const t = (
    /*#slots*/
    n[52].default
  ), l = We(
    t,
    n,
    /*$$scope*/
    n[55],
    null
  );
  return {
    c() {
      l && l.c();
    },
    m(o, s) {
      l && l.m(o, s), e = !0;
    },
    p(o, s) {
      l && l.p && (!e || s[1] & /*$$scope*/
      16777216) && Ke(
        l,
        t,
        o,
        /*$$scope*/
        o[55],
        e ? Ye(
          t,
          /*$$scope*/
          o[55],
          s,
          null
        ) : Xe(
          /*$$scope*/
          o[55]
        ),
        null
      );
    },
    i(o) {
      e || (p(l, o), e = !0);
    },
    o(o) {
      w(l, o), e = !1;
    },
    d(o) {
      l && l.d(o);
    }
  };
}
function Sc(n) {
  let e, t, l, o, s, i, r, u, a, c, f, d, m, _, g, v, R = (
    /*$$slots*/
    n[25].controls && zl(n)
  );
  const b = [kc, bc], y = [];
  function k(S, I) {
    return (
      /*$error*/
      S[8] ? 0 : (
        /*$loaded*/
        S[9] ? 1 : -1
      )
    );
  }
  ~(l = k(n)) && (o = y[l] = b[l](n));
  let h = (
    /*$loading*/
    n[11] && !/*$error*/
    n[8] && Fl()
  ), C = (
    /*$config*/
    n[10].canAddRows && Bl()
  );
  u = new Br({}), c = new Jr({}), d = new nc({});
  let N = (
    /*$loaded*/
    n[9] && jl(n)
  );
  return {
    c() {
      e = $("div"), R && R.c(), t = x(), o && o.c(), s = x(), h && h.c(), i = x(), C && C.c(), r = x(), W(u.$$.fragment), a = x(), W(c.$$.fragment), f = x(), W(d.$$.fragment), m = x(), N && N.c(), U(e, "class", "grid svelte-fdk5zl"), U(
        e,
        "id",
        /*gridID*/
        n[12]
      ), Ie(
        e,
        "--row-height",
        /*$rowHeight*/
        n[5] + "px"
      ), Ie(e, "--default-row-height", St + "px"), Ie(e, "--gutter-width", Rt + "px"), Ie(e, "--max-cell-render-overflow", Po + "px"), Ie(
        e,
        "--content-lines",
        /*$contentLines*/
        n[6]
      ), Ie(
        e,
        "--min-height",
        /*$minHeight*/
        n[7] + "px"
      ), Ie(e, "--controls-height", Zl + "px"), Ie(e, "--scroll-bar-size", yt + "px"), ne(
        e,
        "is-resizing",
        /*$isResizing*/
        n[3]
      ), ne(
        e,
        "is-reordering",
        /*$isReordering*/
        n[4]
      ), ne(
        e,
        "stripe",
        /*stripeRows*/
        n[0]
      ), ne(
        e,
        "quiet",
        /*quiet*/
        n[1]
      );
    },
    m(S, I) {
      M(S, e, I), R && R.m(e, null), le(e, t), ~l && y[l].m(e, null), le(e, s), h && h.m(e, null), le(e, i), C && C.m(e, null), le(e, r), K(u, e, null), le(e, a), K(c, e, null), le(e, f), K(d, e, null), le(e, m), N && N.m(e, null), _ = !0, g || (v = [
        ke(
          e,
          "mouseenter",
          /*mouseenter_handler*/
          n[53]
        ),
        ke(
          e,
          "mouseleave",
          /*mouseleave_handler*/
          n[54]
        )
      ], g = !0);
    },
    p(S, I) {
      /*$$slots*/
      S[25].controls ? R ? (R.p(S, I), I[0] & /*$$slots*/
      33554432 && p(R, 1)) : (R = zl(S), R.c(), p(R, 1), R.m(e, t)) : R && (he(), w(R, 1, 1, () => {
        R = null;
      }), we());
      let P = l;
      l = k(S), l === P ? ~l && y[l].p(S, I) : (o && (he(), w(y[P], 1, 1, () => {
        y[P] = null;
      }), we()), ~l ? (o = y[l], o ? o.p(S, I) : (o = y[l] = b[l](S), o.c()), p(o, 1), o.m(e, s)) : o = null), /*$loading*/
      S[11] && !/*$error*/
      S[8] ? h ? I[0] & /*$loading, $error*/
      2304 && p(h, 1) : (h = Fl(), h.c(), p(h, 1), h.m(e, i)) : h && (he(), w(h, 1, 1, () => {
        h = null;
      }), we()), /*$config*/
      S[10].canAddRows ? C ? I[0] & /*$config*/
      1024 && p(C, 1) : (C = Bl(), C.c(), p(C, 1), C.m(e, r)) : C && (he(), w(C, 1, 1, () => {
        C = null;
      }), we()), /*$loaded*/
      S[9] ? N ? (N.p(S, I), I[0] & /*$loaded*/
      512 && p(N, 1)) : (N = jl(S), N.c(), p(N, 1), N.m(e, null)) : N && (he(), w(N, 1, 1, () => {
        N = null;
      }), we()), (!_ || I[0] & /*$rowHeight*/
      32) && Ie(
        e,
        "--row-height",
        /*$rowHeight*/
        S[5] + "px"
      ), (!_ || I[0] & /*$contentLines*/
      64) && Ie(
        e,
        "--content-lines",
        /*$contentLines*/
        S[6]
      ), (!_ || I[0] & /*$minHeight*/
      128) && Ie(
        e,
        "--min-height",
        /*$minHeight*/
        S[7] + "px"
      ), (!_ || I[0] & /*$isResizing*/
      8) && ne(
        e,
        "is-resizing",
        /*$isResizing*/
        S[3]
      ), (!_ || I[0] & /*$isReordering*/
      16) && ne(
        e,
        "is-reordering",
        /*$isReordering*/
        S[4]
      ), (!_ || I[0] & /*stripeRows*/
      1) && ne(
        e,
        "stripe",
        /*stripeRows*/
        S[0]
      ), (!_ || I[0] & /*quiet*/
      2) && ne(
        e,
        "quiet",
        /*quiet*/
        S[1]
      );
    },
    i(S) {
      _ || (p(R), p(o), p(h), p(C), p(u.$$.fragment, S), p(c.$$.fragment, S), p(d.$$.fragment, S), p(N), _ = !0);
    },
    o(S) {
      w(R), w(o), w(h), w(C), w(u.$$.fragment, S), w(c.$$.fragment, S), w(d.$$.fragment, S), w(N), _ = !1;
    },
    d(S) {
      S && E(e), R && R.d(), ~l && y[l].d(), h && h.d(), C && C.d(), X(u), X(c), X(d), N && N.d(), g = !1, lt(v);
    }
  };
}
function yc(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, { $$slots: m = {}, $$scope: _ } = e;
  const g = xt(m);
  let { API: v = null } = e, { datasource: R = null } = e, { schemaOverrides: b = null } = e, { canAddRows: y = !0 } = e, { canExpandRows: k = !0 } = e, { canEditRows: h = !0 } = e, { canDeleteRows: C = !0 } = e, { canEditColumns: N = !0 } = e, { canSaveSchema: S = !0 } = e, { stripeRows: I = !1 } = e, { quiet: P = !1 } = e, { collaboration: T = !0 } = e, { showAvatars: H = !0 } = e, { initialFilter: z = null } = e, { initialSortColumn: Z = null } = e, { initialSortOrder: B = null } = e, { fixedRowHeight: te = null } = e, { notifySuccess: _e = null } = e, { notifyError: ie = null } = e, { buttons: fe = null } = e, { buttonsCollapsed: ae = !1 } = e, { buttonsCollapsedText: Re = null } = e, { darkMode: Ce = !1 } = e, { isCloud: ve = null } = e, { aiEnabled: J = !1 } = e, { canHideColumns: be = !0 } = e, { externalClipboard: j = void 0 } = e;
  const Q = `grid-${Math.random().toString().slice(2)}`, F = Me(e);
  let q = Nr({
    API: v || Ho(),
    Constants: Fo,
    gridID: Q,
    props: F,
    ...ss()
  });
  const { config: V, isResizing: G, isReordering: O, ui: se, loaded: ge, loading: ue, rowHeight: D, contentLines: re, gridFocused: oe, error: ye, definitionMissing: Le, dispatch: qe } = q;
  A(n, V, (ee) => t(10, f = ee)), A(n, G, (ee) => t(3, o = ee)), A(n, O, (ee) => t(4, s = ee)), A(n, ge, (ee) => t(9, c = ee)), A(n, ue, (ee) => t(11, d = ee)), A(n, D, (ee) => t(5, i = ee)), A(n, re, (ee) => t(6, r = ee)), A(n, ye, (ee) => t(8, a = ee)), A(n, Le, (ee) => t(51, l = ee));
  const Ve = me(D, (ee) => {
    const ht = g.controls ? Zl : 0;
    return Kl + Bo + ee + ht;
  });
  A(n, Ve, (ee) => t(7, u = ee)), q = { ...q, minHeight: Ve }, jo("grid", q);
  const bt = () => q;
  it(() => {
    if (T)
      return mc(q);
  });
  const pt = () => oe.set(!0), at = () => oe.set(!1);
  return n.$$set = (ee) => {
    t(59, e = un(un({}, e), cn(ee))), "API" in ee && t(26, v = ee.API), "datasource" in ee && t(27, R = ee.datasource), "schemaOverrides" in ee && t(28, b = ee.schemaOverrides), "canAddRows" in ee && t(29, y = ee.canAddRows), "canExpandRows" in ee && t(30, k = ee.canExpandRows), "canEditRows" in ee && t(31, h = ee.canEditRows), "canDeleteRows" in ee && t(32, C = ee.canDeleteRows), "canEditColumns" in ee && t(33, N = ee.canEditColumns), "canSaveSchema" in ee && t(34, S = ee.canSaveSchema), "stripeRows" in ee && t(0, I = ee.stripeRows), "quiet" in ee && t(1, P = ee.quiet), "collaboration" in ee && t(35, T = ee.collaboration), "showAvatars" in ee && t(2, H = ee.showAvatars), "initialFilter" in ee && t(36, z = ee.initialFilter), "initialSortColumn" in ee && t(37, Z = ee.initialSortColumn), "initialSortOrder" in ee && t(38, B = ee.initialSortOrder), "fixedRowHeight" in ee && t(39, te = ee.fixedRowHeight), "notifySuccess" in ee && t(40, _e = ee.notifySuccess), "notifyError" in ee && t(41, ie = ee.notifyError), "buttons" in ee && t(42, fe = ee.buttons), "buttonsCollapsed" in ee && t(43, ae = ee.buttonsCollapsed), "buttonsCollapsedText" in ee && t(44, Re = ee.buttonsCollapsedText), "darkMode" in ee && t(45, Ce = ee.darkMode), "isCloud" in ee && t(46, ve = ee.isCloud), "aiEnabled" in ee && t(47, J = ee.aiEnabled), "canHideColumns" in ee && t(48, be = ee.canHideColumns), "externalClipboard" in ee && t(49, j = ee.externalClipboard), "$$scope" in ee && t(55, _ = ee.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*datasource, schemaOverrides, canAddRows, canExpandRows, stripeRows, quiet, showAvatars*/
    2013265927 | n.$$.dirty[1] & /*canEditRows, canDeleteRows, canEditColumns, canSaveSchema, collaboration, initialFilter, initialSortColumn, initialSortOrder, fixedRowHeight, notifySuccess, notifyError, buttons, buttonsCollapsed, buttonsCollapsedText, darkMode, isCloud, aiEnabled, canHideColumns, externalClipboard*/
    524287 && F.set({
      datasource: R,
      schemaOverrides: b,
      canAddRows: y,
      canExpandRows: k,
      canEditRows: h,
      canDeleteRows: C,
      canEditColumns: N,
      canSaveSchema: S,
      stripeRows: I,
      quiet: P,
      collaboration: T,
      showAvatars: H,
      initialFilter: z,
      initialSortColumn: Z,
      initialSortOrder: B,
      fixedRowHeight: te,
      notifySuccess: _e,
      notifyError: ie,
      buttons: fe,
      buttonsCollapsed: ae,
      buttonsCollapsedText: Re,
      darkMode: Ce,
      isCloud: ve,
      aiEnabled: J,
      canHideColumns: be,
      externalClipboard: j
    }), n.$$.dirty[0] & /*datasource*/
    134217728 | n.$$.dirty[1] & /*$definitionMissing*/
    1048576 && l && qe("definitionMissing", { datasource: R });
  }, e = cn(e), [
    I,
    P,
    H,
    o,
    s,
    i,
    r,
    u,
    a,
    c,
    f,
    d,
    Q,
    V,
    G,
    O,
    se,
    ge,
    ue,
    D,
    re,
    oe,
    ye,
    Le,
    Ve,
    g,
    v,
    R,
    b,
    y,
    k,
    h,
    C,
    N,
    S,
    T,
    z,
    Z,
    B,
    te,
    _e,
    ie,
    fe,
    ae,
    Re,
    Ce,
    ve,
    J,
    be,
    j,
    bt,
    l,
    m,
    pt,
    at,
    _
  ];
}
class Ic extends De {
  constructor(e) {
    super(), Ne(
      this,
      e,
      yc,
      Sc,
      Ee,
      {
        API: 26,
        datasource: 27,
        schemaOverrides: 28,
        canAddRows: 29,
        canExpandRows: 30,
        canEditRows: 31,
        canDeleteRows: 32,
        canEditColumns: 33,
        canSaveSchema: 34,
        stripeRows: 0,
        quiet: 1,
        collaboration: 35,
        showAvatars: 2,
        initialFilter: 36,
        initialSortColumn: 37,
        initialSortOrder: 38,
        fixedRowHeight: 39,
        notifySuccess: 40,
        notifyError: 41,
        buttons: 42,
        buttonsCollapsed: 43,
        buttonsCollapsedText: 44,
        darkMode: 45,
        isCloud: 46,
        aiEnabled: 47,
        canHideColumns: 48,
        externalClipboard: 49,
        getContext: 50
      },
      null,
      [-1, -1]
    );
  }
  get getContext() {
    return this.$$.ctx[50];
  }
}
function Mc(n) {
  let e, t, l, o, s, i, r, u, a = {
    datasource: (
      /*table*/
      n[0]
    ),
    API: (
      /*API*/
      n[29]
    ),
    stripeRows: (
      /*stripeRows*/
      n[4]
    ),
    quiet: (
      /*quiet*/
      n[5]
    ),
    darkMode: (
      /*darkMode*/
      n[21]
    ),
    initialFilter: (
      /*extendedFilter*/
      n[13]
    ),
    initialSortColumn: (
      /*initialSortColumn*/
      n[6]
    ),
    initialSortOrder: (
      /*initialSortOrder*/
      n[7]
    ),
    fixedRowHeight: (
      /*fixedRowHeight*/
      n[8]
    ),
    schemaOverrides: (
      /*schemaOverrides*/
      n[19]
    ),
    canAddRows: (
      /*allowAddRows*/
      n[1]
    ),
    canEditRows: (
      /*allowEditRows*/
      n[2]
    ),
    canDeleteRows: (
      /*allowDeleteRows*/
      n[3]
    ),
    canEditColumns: !1,
    canExpandRows: !1,
    canSaveSchema: !1,
    notifySuccess: (
      /*notificationStore*/
      n[31].actions.success
    ),
    notifyError: (
      /*notificationStore*/
      n[31].actions.error
    ),
    buttons: (
      /*enrichedButtons*/
      n[20]
    ),
    buttonsCollapsed: (
      /*buttonsCollapsed*/
      n[10]
    ),
    buttonsCollapsedText: (
      /*buttonsCollapsedText*/
      n[11]
    ),
    isCloud: (
      /*$environmentStore*/
      n[23].cloud
    ),
    aiEnabled: (
      /*$featuresStore*/
      n[24].aiEnabled
    )
  };
  return t = new Ic({ props: a }), n[46](t), t.$on(
    "rowclick",
    /*rowclick_handler*/
    n[47]
  ), s = new /*Provider*/
  n[32]({
    props: {
      data: (
        /*data*/
        n[15]
      ),
      actions: (
        /*actions*/
        n[14]
      )
    }
  }), {
    c() {
      e = $("div"), W(t.$$.fragment), o = x(), W(s.$$.fragment), U(e, "class", "svelte-1yk90l6"), ne(
        e,
        "in-builder",
        /*$builderStore*/
        n[22].inBuilder
      );
    },
    m(c, f) {
      M(c, e, f), K(t, e, null), M(c, o, f), K(s, c, f), i = !0, r || (u = $l(l = /*styleable*/
      n[28].call(
        null,
        e,
        /*styles*/
        n[17]
      )), r = !0);
    },
    p(c, f) {
      const d = {};
      f[0] & /*table*/
      1 && (d.datasource = /*table*/
      c[0]), f[0] & /*stripeRows*/
      16 && (d.stripeRows = /*stripeRows*/
      c[4]), f[0] & /*quiet*/
      32 && (d.quiet = /*quiet*/
      c[5]), f[0] & /*darkMode*/
      2097152 && (d.darkMode = /*darkMode*/
      c[21]), f[0] & /*extendedFilter*/
      8192 && (d.initialFilter = /*extendedFilter*/
      c[13]), f[0] & /*initialSortColumn*/
      64 && (d.initialSortColumn = /*initialSortColumn*/
      c[6]), f[0] & /*initialSortOrder*/
      128 && (d.initialSortOrder = /*initialSortOrder*/
      c[7]), f[0] & /*fixedRowHeight*/
      256 && (d.fixedRowHeight = /*fixedRowHeight*/
      c[8]), f[0] & /*schemaOverrides*/
      524288 && (d.schemaOverrides = /*schemaOverrides*/
      c[19]), f[0] & /*allowAddRows*/
      2 && (d.canAddRows = /*allowAddRows*/
      c[1]), f[0] & /*allowEditRows*/
      4 && (d.canEditRows = /*allowEditRows*/
      c[2]), f[0] & /*allowDeleteRows*/
      8 && (d.canDeleteRows = /*allowDeleteRows*/
      c[3]), f[0] & /*enrichedButtons*/
      1048576 && (d.buttons = /*enrichedButtons*/
      c[20]), f[0] & /*buttonsCollapsed*/
      1024 && (d.buttonsCollapsed = /*buttonsCollapsed*/
      c[10]), f[0] & /*buttonsCollapsedText*/
      2048 && (d.buttonsCollapsedText = /*buttonsCollapsedText*/
      c[11]), f[0] & /*$environmentStore*/
      8388608 && (d.isCloud = /*$environmentStore*/
      c[23].cloud), f[0] & /*$featuresStore*/
      16777216 && (d.aiEnabled = /*$featuresStore*/
      c[24].aiEnabled), t.$set(d), l && Ue(l.update) && f[0] & /*styles*/
      131072 && l.update.call(
        null,
        /*styles*/
        c[17]
      ), (!i || f[0] & /*$builderStore*/
      4194304) && ne(
        e,
        "in-builder",
        /*$builderStore*/
        c[22].inBuilder
      );
      const m = {};
      f[0] & /*data*/
      32768 && (m.data = /*data*/
      c[15]), f[0] & /*actions*/
      16384 && (m.actions = /*actions*/
      c[14]), s.$set(m);
    },
    i(c) {
      i || (p(t.$$.fragment, c), p(s.$$.fragment, c), i = !0);
    },
    o(c) {
      w(t.$$.fragment, c), w(s.$$.fragment, c), i = !1;
    },
    d(c) {
      c && (E(e), E(o)), n[46](null), X(t), X(s, c), r = !1, u();
    }
  };
}
function Ec(n, e, t) {
  let l, o, s, i, r, u, a, c, f, d, m, _, g, v = Oe, R = () => (v(), v = $t(f, (Y) => t(42, g = Y)), f), b, y, k = Oe, h = () => (k(), k = $t(a, (Y) => t(44, y = Y)), a), C, N, S, I;
  A(n, qo, (Y) => t(24, I = Y)), n.$$.on_destroy.push(() => v()), n.$$.on_destroy.push(() => k());
  let { table: P } = e, { allowAddRows: T = !0 } = e, { allowEditRows: H = !0 } = e, { allowDeleteRows: z = !0 } = e, { stripeRows: Z = !1 } = e, { quiet: B = !1 } = e, { initialFilter: te = null } = e, { initialSortColumn: _e = null } = e, { initialSortOrder: ie = null } = e, { fixedRowHeight: fe = null } = e, { columns: ae = null } = e, { onRowClick: Re = null } = e, { buttons: Ce = null } = e, { buttonsCollapsed: ve = !1 } = e, { buttonsCollapsedText: J = null } = e;
  const be = Te("context");
  A(n, be, (Y) => t(45, C = Y));
  const j = Te("component");
  A(n, j, (Y) => t(43, b = Y));
  const { environmentStore: Q } = Te("sdk");
  A(n, Q, (Y) => t(23, S = Y));
  const { styleable: F, API: q, builderStore: V, notificationStore: G, enrichButtonActions: O, ActionTypes: se, createContextStore: ge, Provider: ue, generateGoldenSample: D } = Te("sdk");
  A(n, V, (Y) => t(22, N = Y));
  let re, oe, ye = 0, Le = {};
  const qe = (Y, Se) => {
    !Y || !Se || t(39, Le = {
      ...Le,
      [Y]: Se
    });
  }, Ve = (Y) => {
    if (!Y)
      return;
    const { [Y]: Se, ...Fe } = Le;
    t(39, Le = { ...Fe });
  }, bt = (Y, Se) => Object.keys(Se || {}).length ? {
    groups: (Y ? [Y] : []).concat(Object.values(Se)),
    logicalOperator: Qt.ALL,
    onEmptyFilter: Go.RETURN_NONE
  } : Y, pt = () => {
    const Y = re == null ? void 0 : re.getContext(), Se = L(Y == null ? void 0 : Y.rows) || [], Fe = (Y == null ? void 0 : Y.rows.actions.cleanRow) || ((ft) => ft), Be = Se.map(Fe), ot = D(Be);
    return {
      // Not sure what this one is for...
      [l]: ot,
      // For row conditions context
      row: ot,
      // For button action context
      eventContext: { row: ot }
    };
  }, at = (Y) => Y != null && Y.length ? Y[0].active !== void 0 ? Y : Y.map((Se) => ({
    label: Se.displayName || Se.name,
    field: Se.name,
    active: !0
  })) : [], ee = (Y, Se) => {
    let Fe = {};
    return Y.forEach((Be, ot) => {
      var ft;
      Fe[Be.field] = {
        displayName: Be.label,
        order: ot,
        visible: !!Be.active,
        conditions: ht(Be.conditions, Se),
        format: At(Be),
        // Small hack to ensure we react to all changes, as our
        // memoization cannot compare differences in functions
        rand: (ft = Be.conditions) != null && ft.length ? Math.random() : null
      }, Be.width && (Fe[Be.field].width = Be.width);
    }), Fe;
  }, ht = (Y, Se) => Y == null ? void 0 : Y.map((Fe) => ({
    ...Fe,
    referenceValue: Xt(Fe.referenceValue || "", Se),
    newValue: Xt(Fe.newValue || "", Se)
  })), At = (Y) => typeof Y.format != "string" || !Y.format.trim().length ? null : (Se) => Xt(Y.format, { [l]: Se }), kt = (Y) => Y != null && Y.length ? Y.map((Se) => {
    const Fe = L(j).id;
    return {
      size: "M",
      text: Se.text,
      type: Se.type,
      icon: Se.icon,
      getRowConditions: (Be) => ht(Se.conditions, { [Fe]: Be }),
      conditions: Se.conditions,
      onClick: async (Be) => {
        const ot = ge(be);
        ot.actions.provideData(Fe, Be);
        const ft = O(Se.onClick, L(ot));
        return await (ft == null ? void 0 : ft({ row: Be }));
      }
    };
  }) : null, Lt = (Y) => Y ? me([Y.selectedRows, Y.rowLookupMap], ([Se, Fe]) => Object.entries(Se || {}).filter(([Be, ot]) => ot).map(([Be]) => Y.rows.actions.cleanRow(Fe[Be]))) : Wo([]), pe = (Y, Se) => ({
    ...Y,
    normal: {
      ...Y == null ? void 0 : Y.normal,
      "min-height": `${Se}px`
    }
  });
  it(() => {
    t(37, oe = re.getContext()), oe.minHeight.subscribe((Y) => t(38, ye = Y));
  });
  function et(Y) {
    $e[Y ? "unshift" : "push"](() => {
      re = Y, t(12, re);
    });
  }
  const _t = (Y) => Re == null ? void 0 : Re({ row: Y.detail });
  return n.$$set = (Y) => {
    "table" in Y && t(0, P = Y.table), "allowAddRows" in Y && t(1, T = Y.allowAddRows), "allowEditRows" in Y && t(2, H = Y.allowEditRows), "allowDeleteRows" in Y && t(3, z = Y.allowDeleteRows), "stripeRows" in Y && t(4, Z = Y.stripeRows), "quiet" in Y && t(5, B = Y.quiet), "initialFilter" in Y && t(33, te = Y.initialFilter), "initialSortColumn" in Y && t(6, _e = Y.initialSortColumn), "initialSortOrder" in Y && t(7, ie = Y.initialSortOrder), "fixedRowHeight" in Y && t(8, fe = Y.fixedRowHeight), "columns" in Y && t(34, ae = Y.columns), "onRowClick" in Y && t(9, Re = Y.onRowClick), "buttons" in Y && t(35, Ce = Y.buttons), "buttonsCollapsed" in Y && t(10, ve = Y.buttonsCollapsed), "buttonsCollapsedText" in Y && t(11, J = Y.buttonsCollapsedText);
  }, n.$$.update = () => {
    var Y;
    n.$$.dirty[1] & /*$component*/
    4096 && (l = b.id), n.$$.dirty[1] & /*$context*/
    16384 && t(41, o = (Y = C == null ? void 0 : C.device) == null ? void 0 : Y.theme), n.$$.dirty[1] & /*currentTheme*/
    1024 && t(21, s = !(o != null && o.includes("light"))), n.$$.dirty[1] & /*columns*/
    8 && t(40, i = at(ae)), n.$$.dirty[1] & /*buttons*/
    16 && t(20, r = kt(Ce)), n.$$.dirty[1] & /*parsedColumns, $context*/
    16896 && t(19, u = ee(i, C)), n.$$.dirty[1] & /*gridContext*/
    64 && h(t(18, a = Lt(oe))), n.$$.dirty[1] & /*$component, minHeight*/
    4224 && t(17, c = pe(b.styles, ye)), n.$$.dirty[1] & /*gridContext*/
    64 && R(t(16, f = oe == null ? void 0 : oe.rowLookupMap)), n.$$.dirty[0] & /*table*/
    1 | n.$$.dirty[1] & /*$selectedRows, $component, $rowMap*/
    14336 && t(15, d = {
      selectedRows: y,
      embeddedData: {
        dataSource: P,
        componentId: b.id,
        loaded: !!g
      }
    }), n.$$.dirty[0] & /*table*/
    1 | n.$$.dirty[1] & /*gridContext*/
    64 && t(14, m = [
      {
        type: se.RefreshDatasource,
        callback: () => oe == null ? void 0 : oe.rows.actions.refreshData(),
        metadata: { dataSource: P }
      },
      {
        type: se.AddDataProviderFilterExtension,
        callback: qe
      },
      {
        type: se.ClearRowSelection,
        callback: () => {
          var Se, Fe;
          return (Fe = (Se = oe == null ? void 0 : oe.selectedRows) == null ? void 0 : Se.set) == null ? void 0 : Fe.call(Se, {});
        }
      },
      {
        type: se.RemoveDataProviderFilterExtension,
        callback: Ve
      }
    ]), n.$$.dirty[1] & /*initialFilter, filterExtensions*/
    260 && t(13, _ = bt(te, Le));
  }, [
    P,
    T,
    H,
    z,
    Z,
    B,
    _e,
    ie,
    fe,
    Re,
    ve,
    J,
    re,
    _,
    m,
    d,
    f,
    c,
    a,
    u,
    r,
    s,
    N,
    S,
    I,
    be,
    j,
    Q,
    F,
    q,
    V,
    G,
    ue,
    te,
    ae,
    Ce,
    pt,
    oe,
    ye,
    Le,
    i,
    o,
    g,
    b,
    y,
    C,
    et,
    _t
  ];
}
class Tc extends De {
  constructor(e) {
    super(), Ne(
      this,
      e,
      Ec,
      Mc,
      Ee,
      {
        table: 0,
        allowAddRows: 1,
        allowEditRows: 2,
        allowDeleteRows: 3,
        stripeRows: 4,
        quiet: 5,
        initialFilter: 33,
        initialSortColumn: 6,
        initialSortOrder: 7,
        fixedRowHeight: 8,
        columns: 34,
        onRowClick: 9,
        buttons: 35,
        buttonsCollapsed: 10,
        buttonsCollapsedText: 11,
        getAdditionalDataContext: 36
      },
      null,
      [-1, -1, -1]
    );
  }
  get getAdditionalDataContext() {
    return this.$$.ctx[36];
  }
}
export {
  Tc as default
};
