import { S as R, i as V, s as W, c as X, m as Y, k as v, n as p, p as $ } from "./index-e79f0bb2.js";
import { A as tt, p as et, f as G } from "./ApexChart-fb0e9d4c.js";
function nt(a) {
  let n, e;
  return n = new tt({ props: { options: (
    /*options*/
    a[0]
  ) } }), {
    c() {
      X(n.$$.fragment);
    },
    m(i, f) {
      Y(n, i, f), e = !0;
    },
    p(i, f) {
      const m = {};
      f[0] & /*options*/
      1 && (m.options = /*options*/
      i[0]), n.$set(m);
    },
    i(i) {
      e || (v(n.$$.fragment, i), e = !0);
    },
    o(i) {
      p(n.$$.fragment, i), e = !1;
    },
    d(i) {
      $(n, i);
    }
  };
}
function it(a, n, e) {
  let i, f, m, C, L, k, H, { title: w } = n, { dataProvider: c } = n, { labelColumn: y } = n, { valueColumns: _ } = n, { xAxisLabel: F } = n, { yAxisLabel: S } = n, { height: r } = n, { width: x } = n, { animate: U } = n, { dataLabels: D } = n, { curve: I } = n, { legend: z } = n, { yAxisUnits: b } = n, { palette: d } = n, { c1: T, c2: q, c3: N, c4: Z, c5: j } = n, { stacked: B } = n, { gradient: E } = n, { onClick: h } = n;
  function M(t) {
    h == null || h({ marker: t });
  }
  const O = (t, u = []) => {
    const o = t.rows ?? [];
    return u.map((l) => ({
      name: l,
      data: o.map((s) => {
        var A, K;
        const g = s == null ? void 0 : s[l];
        return ((K = (A = t == null ? void 0 : t.schema) == null ? void 0 : A[l]) == null ? void 0 : K.type) === "datetime" && g ? Date.parse(g) : g;
      })
    }));
  }, P = (t, u) => (t.rows ?? []).map((l) => {
    const s = l == null ? void 0 : l[u];
    return ["string", "number", "boolean"].includes(typeof s) ? s : "";
  }), J = (t, u, o) => {
    const l = o === "x";
    return t === "datetime" && l ? G.Datetime : l ? G.Default : G[u];
  }, Q = (t) => t ? {
    type: "gradient",
    gradient: {
      shadeIntensity: 1,
      opacityFrom: 0.7,
      opacityTo: 0.9,
      stops: [0, 90, 100]
    }
  } : { type: "solid" };
  return a.$$set = (t) => {
    "title" in t && e(1, w = t.title), "dataProvider" in t && e(2, c = t.dataProvider), "labelColumn" in t && e(3, y = t.labelColumn), "valueColumns" in t && e(4, _ = t.valueColumns), "xAxisLabel" in t && e(5, F = t.xAxisLabel), "yAxisLabel" in t && e(6, S = t.yAxisLabel), "height" in t && e(7, r = t.height), "width" in t && e(8, x = t.width), "animate" in t && e(9, U = t.animate), "dataLabels" in t && e(10, D = t.dataLabels), "curve" in t && e(11, I = t.curve), "legend" in t && e(12, z = t.legend), "yAxisUnits" in t && e(13, b = t.yAxisUnits), "palette" in t && e(14, d = t.palette), "c1" in t && e(15, T = t.c1), "c2" in t && e(16, q = t.c2), "c3" in t && e(17, N = t.c3), "c4" in t && e(18, Z = t.c4), "c5" in t && e(19, j = t.c5), "stacked" in t && e(20, B = t.stacked), "gradient" in t && e(21, E = t.gradient), "onClick" in t && e(22, h = t.onClick);
  }, a.$$.update = () => {
    var t, u;
    a.$$.dirty[0] & /*dataProvider, valueColumns*/
    20 && e(27, i = O(c, _)), a.$$.dirty[0] & /*dataProvider, labelColumn*/
    12 && e(25, f = P(c, y)), a.$$.dirty[0] & /*dataProvider, labelColumn*/
    12 && e(28, m = ((u = (t = c == null ? void 0 : c.schema) == null ? void 0 : t[y]) == null ? void 0 : u.type) === "datetime" ? "datetime" : "category"), a.$$.dirty[0] & /*labelType, yAxisUnits*/
    268443648 && e(24, C = J(m, b, "x")), a.$$.dirty[0] & /*labelType, yAxisUnits*/
    268443648 && e(23, L = J(m, b, "y")), a.$$.dirty[0] & /*gradient*/
    2097152 && e(26, k = Q(E)), a.$$.dirty[0] & /*series, curve, palette, c1, c2, c3, c4, c5, fill, legend, title, dataLabels, height, width, stacked, animate, dataProvider, categories, xAxisFormatter, xAxisLabel, yAxisFormatter, yAxisLabel*/
    262135782 && e(0, H = {
      series: i,
      stroke: { curve: I.toLowerCase() },
      colors: d === "Custom" ? [T, q, N, Z, j] : [],
      theme: { palette: et(d) },
      fill: k,
      legend: {
        show: z,
        position: "top",
        horizontalAlign: "right",
        showForSingleSeries: !0,
        showForNullSeries: !0,
        showForZeroSeries: !0
      },
      title: { text: w },
      dataLabels: { enabled: D },
      chart: {
        height: r == null || r === "" ? "auto" : r,
        width: x == null || x === "" ? "100%" : x,
        type: "area",
        stacked: B,
        animations: { enabled: U },
        toolbar: { show: !1 },
        zoom: { enabled: !1 },
        events: {
          // Clicking on a line
          markerClick(o, l, s) {
            const g = s.dataPointIndex, A = c.rows[g];
            M(A);
          }
        }
      },
      xaxis: {
        categories: f,
        labels: { formatter: C },
        title: { text: F }
      },
      yaxis: {
        labels: { formatter: L },
        title: { text: S }
      }
    });
  }, [
    H,
    w,
    c,
    y,
    _,
    F,
    S,
    r,
    x,
    U,
    D,
    I,
    z,
    b,
    d,
    T,
    q,
    N,
    Z,
    j,
    B,
    E,
    h,
    L,
    C,
    f,
    k,
    i,
    m
  ];
}
class ct extends R {
  constructor(n) {
    super(), V(
      this,
      n,
      it,
      nt,
      W,
      {
        title: 1,
        dataProvider: 2,
        labelColumn: 3,
        valueColumns: 4,
        xAxisLabel: 5,
        yAxisLabel: 6,
        height: 7,
        width: 8,
        animate: 9,
        dataLabels: 10,
        curve: 11,
        legend: 12,
        yAxisUnits: 13,
        palette: 14,
        c1: 15,
        c2: 16,
        c3: 17,
        c4: 18,
        c5: 19,
        stacked: 20,
        gradient: 21,
        onClick: 22
      },
      null,
      [-1, -1]
    );
  }
}
export {
  ct as default
};
