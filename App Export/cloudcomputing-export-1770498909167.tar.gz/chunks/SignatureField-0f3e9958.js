import { S as ae, i as te, s as fe, cJ as se, ac as C, ai as y, c as I, a as ue, m as j, f as T, aj as N, k as p, n as v, o as F, p as q, u as z, v as E, y as H, z as L, A as O, cK as oe, e as de, b as re, cv as _e, t as ce, j as be } from "./index-e79f0bb2.js";
import { F as me } from "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function G(n) {
  let i, l, e, f, s;
  const r = [he, ge], o = [];
  function g(d, b) {
    var m, c, S, k;
    return b & /*fieldState*/
    256 && (i = null), i == null && (i = !!(Array.isArray(
      /*fieldState*/
      (m = d[8]) == null ? void 0 : m.value
    ) && !/*fieldState*/
    ((S = (c = d[8]) == null ? void 0 : c.value) != null && S.length) || !/*fieldState*/
    ((k = d[8]) != null && k.value))), i ? 0 : 1;
  }
  return l = g(n, -1), e = o[l] = r[l](n), {
    c() {
      e.c(), f = H();
    },
    m(d, b) {
      o[l].m(d, b), T(d, f, b), s = !0;
    },
    p(d, b) {
      let m = l;
      l = g(d, b), l === m ? o[l].p(d, b) : (L(), v(o[m], 1, 1, () => {
        o[m] = null;
      }), O(), e = o[l], e ? e.p(d, b) : (e = o[l] = r[l](d), e.c()), p(e, 1), e.m(f.parentNode, f));
    },
    i(d) {
      s || (p(e), s = !0);
    },
    o(d) {
      v(e), s = !1;
    },
    d(d) {
      d && F(f), o[l].d(d);
    }
  };
}
function ge(n) {
  var f;
  let i, l, e;
  return l = new oe({
    props: {
      darkMode: (
        /*darkMode*/
        n[12]
      ),
      disabled: (
        /*$builderStore*/
        n[13].inBuilder || /*fieldState*/
        n[8].disabled
      ),
      editable: !1,
      value: (
        /*fieldState*/
        (f = n[8]) == null ? void 0 : f.value
      )
    }
  }), l.$on(
    "clear",
    /*deleteSignature*/
    n[17]
  ), {
    c() {
      i = de("div"), I(l.$$.fragment), re(i, "class", "signature-field svelte-1v3n4b5");
    },
    m(s, r) {
      T(s, i, r), j(l, i, null), e = !0;
    },
    p(s, r) {
      var g;
      const o = {};
      r & /*darkMode*/
      4096 && (o.darkMode = /*darkMode*/
      s[12]), r & /*$builderStore, fieldState*/
      8448 && (o.disabled = /*$builderStore*/
      s[13].inBuilder || /*fieldState*/
      s[8].disabled), r & /*fieldState*/
      256 && (o.value = /*fieldState*/
      (g = s[8]) == null ? void 0 : g.value), l.$set(o);
    },
    i(s) {
      e || (p(l.$$.fragment, s), e = !0);
    },
    o(s) {
      v(l.$$.fragment, s), e = !1;
    },
    d(s) {
      s && F(i), q(l);
    }
  };
}
function he(n) {
  let i, l;
  return i = new _e({
    props: {
      fullWidth: !0,
      disabled: (
        /*fieldState*/
        n[8].disabled
      ),
      $$slots: { default: [pe] },
      $$scope: { ctx: n }
    }
  }), i.$on(
    "click",
    /*click_handler*/
    n[22]
  ), {
    c() {
      I(i.$$.fragment);
    },
    m(e, f) {
      j(i, e, f), l = !0;
    },
    p(e, f) {
      const s = {};
      f & /*fieldState*/
      256 && (s.disabled = /*fieldState*/
      e[8].disabled), f & /*$$scope, buttonText*/
      536871040 && (s.$$scope = { dirty: f, ctx: e }), i.$set(s);
    },
    i(e) {
      l || (p(i.$$.fragment, e), l = !0);
    },
    o(e) {
      v(i.$$.fragment, e), l = !1;
    },
    d(e) {
      q(i, e);
    }
  };
}
function pe(n) {
  let i = (
    /*buttonText*/
    (n[7] ? (
      /*buttonText*/
      n[7]
    ) : "Add signature") + ""
  ), l;
  return {
    c() {
      l = ce(i);
    },
    m(e, f) {
      T(e, l, f);
    },
    p(e, f) {
      f & /*buttonText*/
      128 && i !== (i = /*buttonText*/
      (e[7] ? (
        /*buttonText*/
        e[7]
      ) : "Add signature") + "") && be(l, i);
    },
    d(e) {
      e && F(l);
    }
  };
}
function Se(n) {
  let i, l, e = (
    /*fieldState*/
    n[8] && G(n)
  );
  return {
    c() {
      e && e.c(), i = H();
    },
    m(f, s) {
      e && e.m(f, s), T(f, i, s), l = !0;
    },
    p(f, s) {
      /*fieldState*/
      f[8] ? e ? (e.p(f, s), s & /*fieldState*/
      256 && p(e, 1)) : (e = G(f), e.c(), p(e, 1), e.m(i.parentNode, i)) : e && (L(), v(e, 1, 1, () => {
        e = null;
      }), O());
    },
    i(f) {
      l || (p(e), l = !0);
    },
    o(f) {
      v(e), l = !1;
    },
    d(f) {
      f && F(i), e && e.d(f);
    }
  };
}
function ke(n) {
  var S, k;
  let i, l, e, f, s, r, o, g = {
    onConfirm: (
      /*saveSignature*/
      n[16]
    ),
    title: (
      /*label*/
      n[1] || /*fieldSchema*/
      ((S = n[10]) == null ? void 0 : S.name) || ""
    ),
    value: (
      /*fieldState*/
      (k = n[8]) == null ? void 0 : k.value
    ),
    darkMode: (
      /*darkMode*/
      n[12]
    )
  };
  i = new se({ props: g }), n[21](i);
  function d(a) {
    n[23](a);
  }
  function b(a) {
    n[24](a);
  }
  function m(a) {
    n[25](a);
  }
  let c = {
    label: (
      /*label*/
      n[1]
    ),
    field: (
      /*field*/
      n[0]
    ),
    disabled: (
      /*disabled*/
      n[2]
    ),
    readonly: (
      /*readonly*/
      n[3]
    ),
    validation: (
      /*validation*/
      n[4]
    ),
    span: (
      /*span*/
      n[5]
    ),
    helpText: (
      /*helpText*/
      n[6]
    ),
    type: "signature_single",
    defaultValue: [],
    $$slots: { default: [Se] },
    $$scope: { ctx: n }
  };
  return (
    /*fieldState*/
    n[8] !== void 0 && (c.fieldState = /*fieldState*/
    n[8]), /*fieldApi*/
    n[9] !== void 0 && (c.fieldApi = /*fieldApi*/
    n[9]), /*fieldSchema*/
    n[10] !== void 0 && (c.fieldSchema = /*fieldSchema*/
    n[10]), e = new me({ props: c }), C.push(() => y(e, "fieldState", d)), C.push(() => y(e, "fieldApi", b)), C.push(() => y(e, "fieldSchema", m)), {
      c() {
        I(i.$$.fragment), l = ue(), I(e.$$.fragment);
      },
      m(a, u) {
        j(i, a, u), T(a, l, u), j(e, a, u), o = !0;
      },
      p(a, [u]) {
        var A, M;
        const h = {};
        u & /*label, fieldSchema*/
        1026 && (h.title = /*label*/
        a[1] || /*fieldSchema*/
        ((A = a[10]) == null ? void 0 : A.name) || ""), u & /*fieldState*/
        256 && (h.value = /*fieldState*/
        (M = a[8]) == null ? void 0 : M.value), u & /*darkMode*/
        4096 && (h.darkMode = /*darkMode*/
        a[12]), i.$set(h);
        const _ = {};
        u & /*label*/
        2 && (_.label = /*label*/
        a[1]), u & /*field*/
        1 && (_.field = /*field*/
        a[0]), u & /*disabled*/
        4 && (_.disabled = /*disabled*/
        a[2]), u & /*readonly*/
        8 && (_.readonly = /*readonly*/
        a[3]), u & /*validation*/
        16 && (_.validation = /*validation*/
        a[4]), u & /*span*/
        32 && (_.span = /*span*/
        a[5]), u & /*helpText*/
        64 && (_.helpText = /*helpText*/
        a[6]), u & /*$$scope, fieldState, $builderStore, modal, buttonText, darkMode*/
        536885632 && (_.$$scope = { dirty: u, ctx: a }), !f && u & /*fieldState*/
        256 && (f = !0, _.fieldState = /*fieldState*/
        a[8], N(() => f = !1)), !s && u & /*fieldApi*/
        512 && (s = !0, _.fieldApi = /*fieldApi*/
        a[9], N(() => s = !1)), !r && u & /*fieldSchema*/
        1024 && (r = !0, _.fieldSchema = /*fieldSchema*/
        a[10], N(() => r = !1)), e.$set(_);
      },
      i(a) {
        o || (p(i.$$.fragment, a), p(e.$$.fragment, a), o = !0);
      },
      o(a) {
        v(i.$$.fragment, a), v(e.$$.fragment, a), o = !1;
      },
      d(a) {
        a && F(l), n[21](null), q(i, a), q(e, a);
      }
    }
  );
}
function ve(n, i, l) {
  let e, f, s, r, { field: o } = i, { label: g } = i, { disabled: d = !1 } = i, { readonly: b = !1 } = i, { validation: m } = i, { onChange: c } = i, { span: S } = i, { helpText: k = null } = i, { buttonText: a = "Add signature" } = i, u, h, _, A;
  const { API: M, notificationStore: Q, builderStore: D } = z("sdk");
  E(n, D, (t) => l(13, r = t));
  const J = z("context");
  E(n, J, (t) => l(20, s = t));
  const w = z("form"), U = async (t) => {
    var K, P;
    try {
      const V = t.toFile();
      let B;
      if (V) {
        let R = new FormData();
        R.append("file", V);
        let W = (K = w == null ? void 0 : w.dataSource) == null ? void 0 : K.tableId;
        ((P = w == null ? void 0 : w.dataSource) == null ? void 0 : P.type) === "viewV2" && (W = w.dataSource.id);
        const ne = await M.uploadAttachment(W, R), [ie] = ne;
        B = ie;
      } else
        B = null;
      const le = h.setValue(B);
      c && le && c({ value: B });
    } catch (V) {
      Q.actions.error("There was a problem saving your signature"), console.error(V);
    }
  }, X = async () => {
    const t = h.setValue(null);
    c && t && c({ value: null });
  };
  function Y(t) {
    C[t ? "unshift" : "push"](() => {
      A = t, l(11, A);
    });
  }
  const Z = () => {
    r.inBuilder || A.show();
  };
  function x(t) {
    u = t, l(8, u);
  }
  function $(t) {
    h = t, l(9, h);
  }
  function ee(t) {
    _ = t, l(10, _);
  }
  return n.$$set = (t) => {
    "field" in t && l(0, o = t.field), "label" in t && l(1, g = t.label), "disabled" in t && l(2, d = t.disabled), "readonly" in t && l(3, b = t.readonly), "validation" in t && l(4, m = t.validation), "onChange" in t && l(18, c = t.onChange), "span" in t && l(5, S = t.span), "helpText" in t && l(6, k = t.helpText), "buttonText" in t && l(7, a = t.buttonText);
  }, n.$$.update = () => {
    var t;
    n.$$.dirty & /*$context*/
    1048576 && l(19, e = (t = s == null ? void 0 : s.device) == null ? void 0 : t.theme), n.$$.dirty & /*currentTheme*/
    524288 && l(12, f = !(e != null && e.includes("light")));
  }, [
    o,
    g,
    d,
    b,
    m,
    S,
    k,
    a,
    u,
    h,
    _,
    A,
    f,
    r,
    D,
    J,
    U,
    X,
    c,
    e,
    s,
    Y,
    Z,
    x,
    $,
    ee
  ];
}
class Me extends ae {
  constructor(i) {
    super(), te(this, i, ve, ke, fe, {
      field: 0,
      label: 1,
      disabled: 2,
      readonly: 3,
      validation: 4,
      onChange: 18,
      span: 5,
      helpText: 6,
      buttonText: 7
    });
  }
}
export {
  Me as default
};
