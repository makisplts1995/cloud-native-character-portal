import { S as K, i as O, s as j, K as D, c as g, m, k as f, n as p, p as d, u as C, v as E, M as q, y as z, f as T, z as M, A as N, o as S, N as y, O as F } from "./index-e79f0bb2.js";
import { C as H } from "./CollapsedButtonGroup-789a5dc9.js";
import "./Item-8e1549c4.js";
function B(c, t, n) {
  const e = c.slice();
  return e[12] = t[n].text, e[13] = t[n].type, e[14] = t[n].quiet, e[15] = t[n].disabled, e[16] = t[n].onClick, e[17] = t[n].size, e[18] = t[n].icon, e[6] = t[n].gap, e;
}
function I(c) {
  let t, n, e = y(
    /*buttons*/
    c[0]
  ), o = [];
  for (let r = 0; r < e.length; r += 1)
    o[r] = w(B(c, e, r));
  const s = (r) => p(o[r], 1, 1, () => {
    o[r] = null;
  });
  return {
    c() {
      for (let r = 0; r < o.length; r += 1)
        o[r].c();
      t = z();
    },
    m(r, a) {
      for (let l = 0; l < o.length; l += 1)
        o[l] && o[l].m(r, a);
      T(r, t, a), n = !0;
    },
    p(r, a) {
      if (a & /*buttons*/
      1) {
        e = y(
          /*buttons*/
          r[0]
        );
        let l;
        for (l = 0; l < e.length; l += 1) {
          const u = B(r, e, l);
          o[l] ? (o[l].p(u, a), f(o[l], 1)) : (o[l] = w(u), o[l].c(), f(o[l], 1), o[l].m(t.parentNode, t));
        }
        for (M(), l = e.length; l < o.length; l += 1)
          s(l);
        N();
      }
    },
    i(r) {
      if (!n) {
        for (let a = 0; a < e.length; a += 1)
          f(o[a]);
        n = !0;
      }
    },
    o(r) {
      o = o.filter(Boolean);
      for (let a = 0; a < o.length; a += 1)
        p(o[a]);
      n = !1;
    },
    d(r) {
      r && S(t), F(o, r);
    }
  };
}
function J(c) {
  let t, n;
  return t = new H({
    props: {
      text: (
        /*collapsedText*/
        c[5] || "Action"
      ),
      buttons: (
        /*collapsedButtons*/
        c[7]
      )
    }
  }), {
    c() {
      g(t.$$.fragment);
    },
    m(e, o) {
      m(t, e, o), n = !0;
    },
    p(e, o) {
      const s = {};
      o & /*collapsedText*/
      32 && (s.text = /*collapsedText*/
      e[5] || "Action"), o & /*collapsedButtons*/
      128 && (s.buttons = /*collapsedButtons*/
      e[7]), t.$set(s);
    },
    i(e) {
      n || (f(t.$$.fragment, e), n = !0);
    },
    o(e) {
      p(t.$$.fragment, e), n = !1;
    },
    d(e) {
      d(t, e);
    }
  };
}
function w(c) {
  let t, n;
  return t = new q({
    props: {
      type: "button",
      props: {
        text: (
          /*text*/
          c[12] || "Button"
        ),
        onClick: (
          /*onClick*/
          c[16]
        ),
        type: (
          /*type*/
          c[13]
        ),
        quiet: (
          /*quiet*/
          c[14]
        ),
        disabled: (
          /*disabled*/
          c[15]
        ),
        icon: (
          /*icon*/
          c[18]
        ),
        gap: (
          /*gap*/
          c[6]
        ),
        size: (
          /*size*/
          c[17] || "M"
        )
      }
    }
  }), {
    c() {
      g(t.$$.fragment);
    },
    m(e, o) {
      m(t, e, o), n = !0;
    },
    p(e, o) {
      const s = {};
      o & /*buttons*/
      1 && (s.props = {
        text: (
          /*text*/
          e[12] || "Button"
        ),
        onClick: (
          /*onClick*/
          e[16]
        ),
        type: (
          /*type*/
          e[13]
        ),
        quiet: (
          /*quiet*/
          e[14]
        ),
        disabled: (
          /*disabled*/
          e[15]
        ),
        icon: (
          /*icon*/
          e[18]
        ),
        gap: (
          /*gap*/
          e[6]
        ),
        size: (
          /*size*/
          e[17] || "M"
        )
      }), t.$set(s);
    },
    i(e) {
      n || (f(t.$$.fragment, e), n = !0);
    },
    o(e) {
      p(t.$$.fragment, e), n = !1;
    },
    d(e) {
      d(t, e);
    }
  };
}
function L(c) {
  let t, n, e, o;
  const s = [J, I], r = [];
  function a(l, u) {
    return (
      /*collapsed*/
      l[4] ? 0 : 1
    );
  }
  return t = a(c), n = r[t] = s[t](c), {
    c() {
      n.c(), e = z();
    },
    m(l, u) {
      r[t].m(l, u), T(l, e, u), o = !0;
    },
    p(l, u) {
      let _ = t;
      t = a(l), t === _ ? r[t].p(l, u) : (M(), p(r[_], 1, 1, () => {
        r[_] = null;
      }), N(), n = r[t], n ? n.p(l, u) : (n = r[t] = s[t](l), n.c()), f(n, 1), n.m(e.parentNode, e));
    },
    i(l) {
      o || (f(n), o = !0);
    },
    o(l) {
      p(n), o = !1;
    },
    d(l) {
      l && S(e), r[t].d(l);
    }
  };
}
function P(c) {
  let t, n;
  return t = new q({
    props: {
      type: "container",
      props: {
        direction: (
          /*direction*/
          c[1]
        ),
        hAlign: (
          /*hAlign*/
          c[2]
        ),
        vAlign: (
          /*vAlign*/
          c[3]
        ),
        gap: (
          /*gap*/
          c[6]
        ),
        wrap: !0
      },
      styles: { normal: { height: "100%" } },
      $$slots: { default: [L] },
      $$scope: { ctx: c }
    }
  }), {
    c() {
      g(t.$$.fragment);
    },
    m(e, o) {
      m(t, e, o), n = !0;
    },
    p(e, o) {
      const s = {};
      o & /*direction, hAlign, vAlign, gap*/
      78 && (s.props = {
        direction: (
          /*direction*/
          e[1]
        ),
        hAlign: (
          /*hAlign*/
          e[2]
        ),
        vAlign: (
          /*vAlign*/
          e[3]
        ),
        gap: (
          /*gap*/
          e[6]
        ),
        wrap: !0
      }), o & /*$$scope, collapsedText, collapsedButtons, collapsed, buttons*/
      2097329 && (s.$$scope = { dirty: o, ctx: e }), t.$set(s);
    },
    i(e) {
      n || (f(t.$$.fragment, e), n = !0);
    },
    o(e) {
      p(t.$$.fragment, e), n = !1;
    },
    d(e) {
      d(t, e);
    }
  };
}
function Q(c) {
  let t, n;
  return t = new D({
    props: {
      $$slots: { default: [P] },
      $$scope: { ctx: c }
    }
  }), {
    c() {
      g(t.$$.fragment);
    },
    m(e, o) {
      m(t, e, o), n = !0;
    },
    p(e, [o]) {
      const s = {};
      o & /*$$scope, direction, hAlign, vAlign, gap, collapsedText, collapsedButtons, collapsed, buttons*/
      2097407 && (s.$$scope = { dirty: o, ctx: e }), t.$set(s);
    },
    i(e) {
      n || (f(t.$$.fragment, e), n = !0);
    },
    o(e) {
      p(t.$$.fragment, e), n = !1;
    },
    d(e) {
      d(t, e);
    }
  };
}
function R(c, t, n) {
  let e, o, { buttons: s = [] } = t, { direction: r = "row" } = t, { hAlign: a = "left" } = t, { vAlign: l = "top" } = t, { gap: u = "S" } = t, { collapsed: _ = !1 } = t, { collapsedText: h = "Action" } = t;
  const { enrichButtonActions: v } = C("sdk"), k = C("context");
  E(c, k, (i) => n(9, o = i));
  const G = (i) => i.map((A) => ({
    ...A,
    onClick: async () => {
      const b = v(A.onClick, o);
      await (b == null ? void 0 : b());
    }
  }));
  return c.$$set = (i) => {
    "buttons" in i && n(0, s = i.buttons), "direction" in i && n(1, r = i.direction), "hAlign" in i && n(2, a = i.hAlign), "vAlign" in i && n(3, l = i.vAlign), "gap" in i && n(6, u = i.gap), "collapsed" in i && n(4, _ = i.collapsed), "collapsedText" in i && n(5, h = i.collapsedText);
  }, c.$$.update = () => {
    c.$$.dirty & /*collapsed, buttons*/
    17 && n(7, e = _ ? G(s) : null);
  }, [
    s,
    r,
    a,
    l,
    _,
    h,
    u,
    e,
    k
  ];
}
class X extends K {
  constructor(t) {
    super(), O(this, t, R, Q, j, {
      buttons: 0,
      direction: 1,
      hAlign: 2,
      vAlign: 3,
      gap: 6,
      collapsed: 4,
      collapsedText: 5
    });
  }
}
export {
  X as default
};
