import { Y as s, Z as t, c3 as a } from "./index-e79f0bb2.js";
function o(n) {
  var i, e, l;
  if (!n)
    return !1;
  const r = (e = (i = n.builder) == null ? void 0 : i.apps) == null ? void 0 : e.length;
  return !!!((l = n.builder) != null && l.global) && r != null && r > 0;
}
function p(n) {
  var r;
  return n ? ((r = n.builder) == null ? void 0 : r.global) || o(n) || f(n) : !1;
}
function f(n) {
  var r;
  return n ? !!((r = n.builder) != null && r.creator) : !1;
}
function b(n) {
  if (typeof n != "string")
    return n;
  const r = `${s.ROW}${t}${a.USER_METADATA}${t}`;
  return n.startsWith(r) ? n.split(r)[1] : n;
}
function g(n) {
  return typeof n != "string" ? !1 : n.includes(`${s.USER}${t}`);
}
export {
  g as c,
  b as g,
  p as h
};
