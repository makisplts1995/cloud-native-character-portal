import { S as m, i as _, s as d, bL as o, c as f, m as p, c7 as u, c8 as g, k as b, n as h, p as w, bM as c } from "./index-e79f0bb2.js";
import x from "./StringField-b0123b03.js";
import "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function S(r) {
  let t, n;
  const s = [
    /*$$props*/
    r[0],
    { type: "password" }
  ];
  let a = {};
  for (let e = 0; e < s.length; e += 1)
    a = o(a, s[e]);
  return t = new x({ props: a }), {
    c() {
      f(t.$$.fragment);
    },
    m(e, i) {
      p(t, e, i), n = !0;
    },
    p(e, [i]) {
      const l = i & /*$$props*/
      1 ? u(s, [g(
        /*$$props*/
        e[0]
      ), s[1]]) : {};
      t.$set(l);
    },
    i(e) {
      n || (b(t.$$.fragment, e), n = !0);
    },
    o(e) {
      h(t.$$.fragment, e), n = !1;
    },
    d(e) {
      w(t, e);
    }
  };
}
function v(r, t, n) {
  return r.$$set = (s) => {
    n(0, t = o(o({}, t), c(s)));
  }, t = c(t), [t];
}
class C extends m {
  constructor(t) {
    super(), _(this, t, v, S, d, {});
  }
}
export {
  C as default
};
