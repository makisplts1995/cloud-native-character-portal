import { Q as Jt, R as Ro, S as ma, i as Ca, s as ya, c as hn, m as fn, k as $r, n as An, p as dn, u as ko, v as Qa, aa as Fa, c6 as Lo, aC as Ua, aM as va, cL as ba, e as Zr, a as fi, b as Br, aD as xa, f as pn, g as Tr, q as Ia, h as Ea, o as Bn, aZ as Ha, ac as Sa, t as No, j as Go, N as Do, y as ka, O as La, d as To, F as Da, G as Ta, H as Ka, J as _a } from "./index-e79f0bb2.js";
import { c as Nn } from "./_commonjs-dynamic-modules-bed80856.js";
var pi = { exports: {} };
(function(CA, J) {
  (function(uA, rA) {
    CA.exports = rA();
  })(Jt, function() {
    var uA, rA, vA, LA, kA, ZA, XA, At, pt, at, YA, Ht, $t, Ae, vt, Bt, St, Tt, ne, Kt, zt, ie, Ne, Be, He, Se, we, ut, ft, _t, ge, te, Ze, $e, Ue, ke, wr, vr, ar, me, Ge, dt, Ft, Le, ve, Ce, De, cr, Ve, lr, ye, Ar, Te, Ot = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(o) {
      return typeof o;
    } : function(o) {
      return o && typeof Symbol == "function" && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, Ct = function(o) {
      var p = "1.3", C = { a0: [2383.94, 3370.39], a1: [1683.78, 2383.94], a2: [1190.55, 1683.78], a3: [841.89, 1190.55], a4: [595.28, 841.89], a5: [419.53, 595.28], a6: [297.64, 419.53], a7: [209.76, 297.64], a8: [147.4, 209.76], a9: [104.88, 147.4], a10: [73.7, 104.88], b0: [2834.65, 4008.19], b1: [2004.09, 2834.65], b2: [1417.32, 2004.09], b3: [1000.63, 1417.32], b4: [708.66, 1000.63], b5: [498.9, 708.66], b6: [354.33, 498.9], b7: [249.45, 354.33], b8: [175.75, 249.45], b9: [124.72, 175.75], b10: [87.87, 124.72], c0: [2599.37, 3676.54], c1: [1836.85, 2599.37], c2: [1298.27, 1836.85], c3: [918.43, 1298.27], c4: [649.13, 918.43], c5: [459.21, 649.13], c6: [323.15, 459.21], c7: [229.61, 323.15], c8: [161.57, 229.61], c9: [113.39, 161.57], c10: [79.37, 113.39], dl: [311.81, 623.62], letter: [612, 792], "government-letter": [576, 756], legal: [612, 1008], "junior-legal": [576, 360], ledger: [1224, 792], tabloid: [792, 1224], "credit-card": [153, 243] };
      function i(n) {
        var s = {};
        this.subscribe = function(c, l, d) {
          if (typeof l != "function")
            return !1;
          s.hasOwnProperty(c) || (s[c] = {});
          var B = Math.random().toString(35);
          return s[c][B] = [l, !!d], B;
        }, this.unsubscribe = function(c) {
          for (var l in s)
            if (s[l][c])
              return delete s[l][c], !0;
          return !1;
        }, this.publish = function(c) {
          if (s.hasOwnProperty(c)) {
            var l = Array.prototype.slice.call(arguments, 1), d = [];
            for (var B in s[c]) {
              var h = s[c][B];
              try {
                h[0].apply(n, l);
              } catch (f) {
                o.console && console.error("jsPDF PubSub Error", f.message, f);
              }
              h[1] && d.push(B);
            }
            d.length && d.forEach(this.unsubscribe);
          }
        };
      }
      function r(n, s, c, l) {
        var d = {};
        (n === void 0 ? "undefined" : Ot(n)) === "object" && (n = (d = n).orientation, s = d.unit || s, c = d.format || c, l = d.compress || d.compressPdf || l), s = s || "mm", c = c || "a4", n = ("" + (n || "P")).toLowerCase(), ("" + c).toLowerCase();
        var B, h, f, m, w, U, I, S, L, N, j, Z = !!l && typeof Uint8Array == "function", W = d.textColor || "0 g", V = d.drawColor || "0 G", y = d.fontSize || 16, P = d.charSpace || 0, _ = d.R2L || !1, Y = d.lineHeight || 1.15, $ = d.lineWidth || 0.200025, hA = "00000000000000000000000000000000", z = 2, k = !1, F = [], R = {}, E = {}, G = 0, M = [], oA = [], X = [], fA = [], nA = [], b = 0, D = 0, u = 0, Q = { title: "", subject: "", author: "", keywords: "", creator: "" }, H = {}, O = new i(H), eA = d.hotfixes || [], sA = function(K) {
          var aA, gA = K.ch1, tA = K.ch2, AA = K.ch3, dA = K.ch4, QA = (K.precision, K.pdfColorType === "draw" ? ["G", "RG", "K"] : ["g", "rg", "k"]);
          if (typeof gA == "string" && gA.charAt(0) !== "#") {
            var bA = new RGBColor(gA);
            bA.ok && (gA = bA.toHex());
          }
          if (typeof gA == "string" && /^#[0-9A-Fa-f]{3}$/.test(gA) && (gA = "#" + gA[1] + gA[1] + gA[2] + gA[2] + gA[3] + gA[3]), typeof gA == "string" && /^#[0-9A-Fa-f]{6}$/.test(gA)) {
            var EA = parseInt(gA.substr(1), 16);
            gA = EA >> 16 & 255, tA = EA >> 8 & 255, AA = 255 & EA;
          }
          if (tA === void 0 || dA === void 0 && gA === tA && tA === AA)
            if (typeof gA == "string")
              aA = gA + " " + QA[0];
            else
              switch (K.precision) {
                case 2:
                  aA = xA(gA / 255) + " " + QA[0];
                  break;
                case 3:
                default:
                  aA = KA(gA / 255) + " " + QA[0];
              }
          else if (dA === void 0 || (dA === void 0 ? "undefined" : Ot(dA)) === "object") {
            if (typeof gA == "string")
              aA = [gA, tA, AA, QA[1]].join(" ");
            else
              switch (K.precision) {
                case 2:
                  aA = [xA(gA / 255), xA(tA / 255), xA(AA / 255), QA[1]].join(" ");
                  break;
                default:
                case 3:
                  aA = [KA(gA / 255), KA(tA / 255), KA(AA / 255), QA[1]].join(" ");
              }
            dA && dA.a === 0 && (aA = ["255", "255", "255", QA[1]].join(" "));
          } else if (typeof gA == "string")
            aA = [gA, tA, AA, dA, QA[2]].join(" ");
          else
            switch (K.precision) {
              case 2:
                aA = [xA(gA), xA(tA), xA(AA), xA(dA), QA[2]].join(" ");
                break;
              case 3:
              default:
                aA = [KA(gA), KA(tA), KA(AA), KA(dA), QA[2]].join(" ");
            }
          return aA;
        }, pA = function(K) {
          var aA = function(bA) {
            return ("0" + parseInt(bA)).slice(-2);
          }, gA = K.getTimezoneOffset(), tA = gA < 0 ? "+" : "-", AA = Math.floor(Math.abs(gA / 60)), dA = Math.abs(gA % 60), QA = [tA, aA(AA), "'", aA(dA), "'"].join("");
          return ["D:", K.getFullYear(), aA(K.getMonth() + 1), aA(K.getDate()), aA(K.getHours()), aA(K.getMinutes()), aA(K.getSeconds()), QA].join("");
        }, yA = function(K) {
          var aA;
          return (K === void 0 ? "undefined" : Ot(K)) === void 0 && (K = /* @__PURE__ */ new Date()), aA = (K === void 0 ? "undefined" : Ot(K)) === "object" && Object.prototype.toString.call(K) === "[object Date]" ? pA(K) : /^D:(20[0-2][0-9]|203[0-7]|19[7-9][0-9])(0[0-9]|1[0-2])([0-2][0-9]|3[0-1])(0[0-9]|1[0-9]|2[0-3])(0[0-9]|[1-5][0-9])(0[0-9]|[1-5][0-9])(\+0[0-9]|\+1[0-4]|\-0[0-9]|\-1[0-1])\'(0[0-9]|[1-5][0-9])\'?$/.test(K) ? K : pA(/* @__PURE__ */ new Date()), N = aA;
        }, wA = function(K) {
          var aA = N;
          return K === "jsDate" && (aA = function(gA) {
            var tA = parseInt(gA.substr(2, 4), 10), AA = parseInt(gA.substr(6, 2), 10) - 1, dA = parseInt(gA.substr(8, 2), 10), QA = parseInt(gA.substr(10, 2), 10), bA = parseInt(gA.substr(12, 2), 10), EA = parseInt(gA.substr(14, 2), 10);
            return parseInt(gA.substr(16, 2), 10), parseInt(gA.substr(20, 2), 10), new Date(tA, AA, dA, QA, bA, EA, 0);
          }(N)), aA;
        }, SA = function(K) {
          return K = K || "12345678901234567890123456789012".split("").map(function() {
            return "ABCDEF0123456789".charAt(Math.floor(16 * Math.random()));
          }).join(""), hA = K;
        }, xA = function(K) {
          return K.toFixed(2);
        }, KA = function(K) {
          return K.toFixed(3);
        }, iA = function(K) {
          K = typeof K == "string" ? K : K.toString(), k ? M[m].push(K) : (u += K.length + 1, fA.push(K));
        }, yt = function() {
          return F[++z] = u, iA(z + " 0 obj"), z;
        }, $A = function(K) {
          iA("stream"), iA(K), iA("endstream");
        }, st = function() {
          for (var K in iA("/ProcSet [/PDF /Text /ImageB /ImageC /ImageI]"), iA("/Font <<"), R)
            R.hasOwnProperty(K) && iA("/" + K + " " + R[K].objectNumber + " 0 R");
          iA(">>"), iA("/XObject <<"), O.publish("putXobjectDict"), iA(">>");
        }, kt = function() {
          (function() {
            for (var K in R)
              R.hasOwnProperty(K) && (aA = R[K], O.publish("putFont", { font: aA, out: iA, newObject: yt }), aA.isAlreadyPutted !== !0 && (aA.objectNumber = yt(), iA("<<"), iA("/Type /Font"), iA("/BaseFont /" + aA.postScriptName), iA("/Subtype /Type1"), typeof aA.encoding == "string" && iA("/Encoding /" + aA.encoding), iA("/FirstChar 32"), iA("/LastChar 255"), iA(">>"), iA("endobj")));
            var aA;
          })(), O.publish("putResources"), F[2] = u, iA("2 0 obj"), iA("<<"), st(), iA(">>"), iA("endobj"), O.publish("postPutResources");
        }, jA = function(K, aA, gA) {
          E.hasOwnProperty(aA) || (E[aA] = {}), E[aA][gA] = K;
        }, gt = function(K, aA, gA, tA) {
          var AA = "F" + (Object.keys(R).length + 1).toString(10), dA = R[AA] = { id: AA, postScriptName: K, fontName: aA, fontStyle: gA, encoding: tA, metadata: {} };
          return jA(AA, aA, gA), O.publish("addFont", dA), AA;
        }, bt = function(K, aA) {
          return function(gA, tA) {
            var AA, dA, QA, bA, EA, _A, et, VA, it;
            if (QA = (tA = tA || {}).sourceEncoding || "Unicode", EA = tA.outputEncoding, (tA.autoencode || EA) && R[B].metadata && R[B].metadata[QA] && R[B].metadata[QA].encoding && (bA = R[B].metadata[QA].encoding, !EA && R[B].encoding && (EA = R[B].encoding), !EA && bA.codePages && (EA = bA.codePages[0]), typeof EA == "string" && (EA = bA[EA]), EA)) {
              for (et = !1, _A = [], AA = 0, dA = gA.length; AA < dA; AA++)
                (VA = EA[gA.charCodeAt(AA)]) ? _A.push(String.fromCharCode(VA)) : _A.push(gA[AA]), _A[AA].charCodeAt(0) >> 8 && (et = !0);
              gA = _A.join("");
            }
            for (AA = gA.length; et === void 0 && AA !== 0; )
              gA.charCodeAt(AA - 1) >> 8 && (et = !0), AA--;
            if (!et)
              return gA;
            for (_A = tA.noBOM ? [] : [254, 255], AA = 0, dA = gA.length; AA < dA; AA++) {
              if ((it = (VA = gA.charCodeAt(AA)) >> 8) >> 8)
                throw new Error("Character at position " + AA + " of string '" + gA + "' exceeds 16bits. Cannot be encoded into UCS-2 BE");
              _A.push(it), _A.push(VA - (it << 8));
            }
            return String.fromCharCode.apply(void 0, _A);
          }(K, aA).replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
        }, ht = function() {
          (function(K, aA) {
            var gA = typeof aA == "string" && aA.toLowerCase();
            if (typeof K == "string") {
              var tA = K.toLowerCase();
              C.hasOwnProperty(tA) && (K = C[tA][0] / h, aA = C[tA][1] / h);
            }
            if (Array.isArray(K) && (aA = K[1], K = K[0]), gA) {
              switch (gA.substr(0, 1)) {
                case "l":
                  K < aA && (gA = "s");
                  break;
                case "p":
                  aA < K && (gA = "s");
              }
              gA === "s" && (f = K, K = aA, aA = f);
            }
            k = !0, M[++G] = [], X[G] = { width: Number(K) || w, height: Number(aA) || U }, oA[G] = {}, ct(G);
          }).apply(this, arguments), iA(xA($ * h) + " w"), iA(V), b !== 0 && iA(b + " J"), D !== 0 && iA(D + " j"), O.publish("addPage", { pageNumber: G });
        }, ct = function(K) {
          0 < K && K <= G && (w = X[m = K].width, U = X[K].height);
        }, xt = function(K, aA, gA) {
          var tA, AA = void 0;
          return gA = gA || {}, K = K !== void 0 ? K : R[B].fontName, aA = aA !== void 0 ? aA : R[B].fontStyle, tA = K.toLowerCase(), E[tA] !== void 0 && E[tA][aA] !== void 0 ? AA = E[tA][aA] : E[K] !== void 0 && E[K][aA] !== void 0 ? AA = E[K][aA] : gA.disableWarning === !1 && console.warn("Unable to look up font label for font '" + K + "', '" + aA + "'. Refer to getFontList() for available fonts."), AA || gA.noFallback || (AA = E.times[aA]) == null && (AA = E.times.normal), AA;
        }, Pt = function() {
          k = !1, z = 2, u = 0, fA = [], F = [], nA = [], O.publish("buildDocument"), iA("%PDF-" + p), iA("%ºß¬à"), function() {
            var AA, dA, QA, bA, EA, _A, et, VA, it, mt = [];
            for (et = o.adler32cs || r.API.adler32cs, Z && et === void 0 && (Z = !1), AA = 1; AA <= G; AA++) {
              if (mt.push(yt()), VA = (w = X[AA].width) * h, it = (U = X[AA].height) * h, iA("<</Type /Page"), iA("/Parent 1 0 R"), iA("/Resources 2 0 R"), iA("/MediaBox [0 0 " + xA(VA) + " " + xA(it) + "]"), O.publish("putPage", { pageNumber: AA, page: M[AA] }), iA("/Contents " + (z + 1) + " 0 R"), iA(">>"), iA("endobj"), dA = M[AA].join(`
`), yt(), Z) {
                for (QA = [], bA = dA.length; bA--; )
                  QA[bA] = dA.charCodeAt(bA);
                _A = et.from(dA), (EA = new Deflater(6)).append(new Uint8Array(QA)), dA = EA.flush(), (QA = new Uint8Array(dA.length + 6)).set(new Uint8Array([120, 156])), QA.set(dA, 2), QA.set(new Uint8Array([255 & _A, _A >> 8 & 255, _A >> 16 & 255, _A >> 24 & 255]), dA.length + 2), dA = String.fromCharCode.apply(null, QA), iA("<</Length " + dA.length + " /Filter [/FlateDecode]>>");
              } else
                iA("<</Length " + dA.length + ">>");
              $A(dA), iA("endobj");
            }
            F[1] = u, iA("1 0 obj"), iA("<</Type /Pages");
            var qt = "/Kids [";
            for (bA = 0; bA < G; bA++)
              qt += mt[bA] + " 0 R ";
            iA(qt + "]"), iA("/Count " + G), iA(">>"), iA("endobj"), O.publish("postPutPages");
          }(), function() {
            O.publish("putAdditionalObjects");
            for (var AA = 0; AA < nA.length; AA++) {
              var dA = nA[AA];
              F[dA.objId] = u, iA(dA.objId + " 0 obj"), iA(dA.content), iA("endobj");
            }
            z += nA.length, O.publish("postPutAdditionalObjects");
          }(), kt(), yt(), iA("<<"), function() {
            for (var AA in iA("/Producer (jsPDF " + r.version + ")"), Q)
              Q.hasOwnProperty(AA) && Q[AA] && iA("/" + AA.substr(0, 1).toUpperCase() + AA.substr(1) + " (" + bt(Q[AA]) + ")");
            iA("/CreationDate (" + N + ")");
          }(), iA(">>"), iA("endobj"), yt(), iA("<<"), function() {
            switch (iA("/Type /Catalog"), iA("/Pages 1 0 R"), S || (S = "fullwidth"), S) {
              case "fullwidth":
                iA("/OpenAction [3 0 R /FitH null]");
                break;
              case "fullheight":
                iA("/OpenAction [3 0 R /FitV null]");
                break;
              case "fullpage":
                iA("/OpenAction [3 0 R /Fit]");
                break;
              case "original":
                iA("/OpenAction [3 0 R /XYZ null null 1]");
                break;
              default:
                var AA = "" + S;
                AA.substr(AA.length - 1) === "%" && (S = parseInt(S) / 100), typeof S == "number" && iA("/OpenAction [3 0 R /XYZ null null " + xA(S) + "]");
            }
            switch (L || (L = "continuous"), L) {
              case "continuous":
                iA("/PageLayout /OneColumn");
                break;
              case "single":
                iA("/PageLayout /SinglePage");
                break;
              case "two":
              case "twoleft":
                iA("/PageLayout /TwoColumnLeft");
                break;
              case "tworight":
                iA("/PageLayout /TwoColumnRight");
            }
            I && iA("/PageMode /" + I), O.publish("putCatalog");
          }(), iA(">>"), iA("endobj");
          var K, aA = u, gA = "0000000000";
          for (iA("xref"), iA("0 " + (z + 1)), iA(gA + " 65535 f "), K = 1; K <= z; K++) {
            var tA = F[K];
            iA(typeof tA == "function" ? (gA + F[K]()).slice(-10) + " 00000 n " : (gA + F[K]).slice(-10) + " 00000 n ");
          }
          return iA("trailer"), iA("<<"), iA("/Size " + (z + 1)), iA("/Root " + z + " 0 R"), iA("/Info " + (z - 1) + " 0 R"), iA("/ID [ <" + hA + "> <" + hA + "> ]"), iA(">>"), iA("startxref"), iA("" + aA), iA("%%EOF"), k = !0, fA.join(`
`);
        }, JA = function(K) {
          var aA = "S";
          return K === "F" ? aA = "f" : K === "FD" || K === "DF" ? aA = "B" : K !== "f" && K !== "f*" && K !== "B" && K !== "B*" || (aA = K), aA;
        }, ee = function() {
          for (var K = Pt(), aA = K.length, gA = new ArrayBuffer(aA), tA = new Uint8Array(gA); aA--; )
            tA[aA] = K.charCodeAt(aA);
          return gA;
        }, oe = function() {
          return new Blob([ee()], { type: "application/pdf" });
        }, be = ((j = function(K, aA) {
          var gA = ("" + K).substr(0, 6) === "dataur" ? "data:application/pdf;base64," + btoa(Pt()) : 0;
          switch (K) {
            case void 0:
              return Pt();
            case "save":
              if ((typeof navigator > "u" ? "undefined" : Ot(navigator)) === "object" && navigator.getUserMedia && (o.URL === void 0 || o.URL.createObjectURL === void 0))
                return H.output("dataurlnewwindow");
              er(oe(), aA), typeof er.unload == "function" && o.setTimeout && setTimeout(er.unload, 911);
              break;
            case "arraybuffer":
              return ee();
            case "blob":
              return oe();
            case "bloburi":
            case "bloburl":
              return o.URL && o.URL.createObjectURL(oe()) || void 0;
            case "datauristring":
            case "dataurlstring":
              return gA;
            case "dataurlnewwindow":
              var tA = o.open(gA);
              if (tA || typeof safari > "u")
                return tA;
            case "datauri":
            case "dataurl":
              return o.document.location.href = gA;
            default:
              throw new Error('Output type "' + K + '" is not supported.');
          }
        }).foo = function() {
          try {
            return j.apply(this, arguments);
          } catch (gA) {
            var K = gA.stack || "";
            ~K.indexOf(" at ") && (K = K.split(" at ")[1]);
            var aA = "Error in function " + K.split(`
`)[0].split("<")[0] + ": " + gA.message;
            if (!o.console)
              throw new Error(aA);
            o.console.error(aA, gA), o.alert && alert(aA);
          }
        }, (j.foo.bar = j).foo), Ke = function(K) {
          return Array.isArray(eA) === !0 && -1 < eA.indexOf(K);
        };
        switch (s) {
          case "pt":
            h = 1;
            break;
          case "mm":
            h = 72 / 25.4;
            break;
          case "cm":
            h = 72 / 2.54;
            break;
          case "in":
            h = 72;
            break;
          case "px":
            h = Ke("px_scaling") == 1 ? 0.75 : 96 / 72;
            break;
          case "pc":
          case "em":
            h = 12;
            break;
          case "ex":
            h = 6;
            break;
          default:
            throw "Invalid unit: " + s;
        }
        for (var Yt in yA(), SA(), H.internal = { pdfEscape: bt, getStyle: JA, getFont: function() {
          return R[xt.apply(H, arguments)];
        }, getFontSize: function() {
          return y;
        }, getCharSpace: function() {
          return P;
        }, getTextColor: function() {
          var K = W.split(" ");
          if (K.length === 2 && K[1] === "g") {
            var aA = parseFloat(K[0]);
            K = [aA, aA, aA, "r"];
          }
          for (var gA = "#", tA = 0; tA < 3; tA++)
            gA += ("0" + Math.floor(255 * parseFloat(K[tA])).toString(16)).slice(-2);
          return gA;
        }, getLineHeight: function() {
          return y * Y;
        }, write: function(K) {
          iA(arguments.length === 1 ? K : Array.prototype.join.call(arguments, " "));
        }, getCoordinateString: function(K) {
          return xA(K * h);
        }, getVerticalCoordinateString: function(K) {
          return xA((U - K) * h);
        }, collections: {}, newObject: yt, newAdditionalObject: function() {
          var K = 2 * M.length + 1, aA = { objId: K += nA.length, content: "" };
          return nA.push(aA), aA;
        }, newObjectDeferred: function() {
          return F[++z] = function() {
            return u;
          }, z;
        }, newObjectDeferredBegin: function(K) {
          F[K] = u;
        }, putStream: $A, events: O, scaleFactor: h, pageSize: { getWidth: function() {
          return w;
        }, getHeight: function() {
          return U;
        } }, output: function(K, aA) {
          return be(K, aA);
        }, getNumberOfPages: function() {
          return M.length - 1;
        }, pages: M, out: iA, f2: xA, getPageInfo: function(K) {
          return { objId: 2 * (K - 1) + 3, pageNumber: K, pageContext: oA[K] };
        }, getCurrentPageInfo: function() {
          return { objId: 2 * (m - 1) + 3, pageNumber: m, pageContext: oA[m] };
        }, getPDFVersion: function() {
          return p;
        }, hasHotfix: Ke }, H.addPage = function() {
          return ht.apply(this, arguments), this;
        }, H.setPage = function() {
          return ct.apply(this, arguments), this;
        }, H.insertPage = function(K) {
          return this.addPage(), this.movePage(m, K), this;
        }, H.movePage = function(K, aA) {
          if (aA < K) {
            for (var gA = M[K], tA = X[K], AA = oA[K], dA = K; aA < dA; dA--)
              M[dA] = M[dA - 1], X[dA] = X[dA - 1], oA[dA] = oA[dA - 1];
            M[aA] = gA, X[aA] = tA, oA[aA] = AA, this.setPage(aA);
          } else if (K < aA) {
            for (gA = M[K], tA = X[K], AA = oA[K], dA = K; dA < aA; dA++)
              M[dA] = M[dA + 1], X[dA] = X[dA + 1], oA[dA] = oA[dA + 1];
            M[aA] = gA, X[aA] = tA, oA[aA] = AA, this.setPage(aA);
          }
          return this;
        }, H.deletePage = function() {
          return (function(K) {
            0 < K && K <= G && (M.splice(K, 1), X.splice(K, 1), --G < m && (m = G), this.setPage(m));
          }).apply(this, arguments), this;
        }, H.setCreationDate = function(K) {
          return yA(K), this;
        }, H.getCreationDate = function(K) {
          return wA(K);
        }, H.setFileId = function(K) {
          return SA(K), this;
        }, H.getFileId = function() {
          return hA;
        }, H.setDisplayMode = function(K, aA, gA) {
          if (S = K, L = aA, [void 0, null, "UseNone", "UseOutlines", "UseThumbs", "FullScreen"].indexOf(I = gA) == -1)
            throw new Error('Page mode must be one of UseNone, UseOutlines, UseThumbs, or FullScreen. "' + gA + '" is not recognized.');
          return this;
        }, H.text = function(K, aA, gA, tA) {
          var AA, dA, QA = "", bA = Y, EA = this;
          function _A(ue) {
            for (var he, _e = ue.concat(), wt = [], gr = _e.length; gr--; )
              typeof (he = _e.shift()) == "string" ? wt.push(he) : Object.prototype.toString.call(ue) === "[object Array]" && he.length === 1 ? wt.push(he[0]) : wt.push([he[0], he[1], he[2]]);
            return wt;
          }
          function et(ue, he) {
            var _e;
            if (typeof ue == "string")
              _e = he(ue)[0];
            else if (Object.prototype.toString.call(ue) === "[object Array]") {
              for (var wt, gr, yn = ue.concat(), on = [], Qn = yn.length; Qn--; )
                typeof (wt = yn.shift()) == "string" ? on.push(he(wt)[0]) : Object.prototype.toString.call(wt) === "[object Array]" && wt[0] === "string" && (gr = he(wt[0], wt[1], wt[2]), on.push([gr[0], gr[1], gr[2]]));
              _e = on;
            }
            return _e;
          }
          typeof K == "number" && (dA = gA, gA = aA, aA = K, K = dA);
          var VA = tA, it = arguments[4], mt = arguments[5];
          (VA === void 0 ? "undefined" : Ot(VA)) === "object" && VA !== null || (typeof it == "string" && (mt = it, it = null), typeof VA == "string" && (mt = VA, VA = null), typeof VA == "number" && (it = VA, VA = null), tA = { flags: VA, angle: it, align: mt });
          var qt = !1, se = !0;
          if (typeof K == "string")
            qt = !0;
          else if (Object.prototype.toString.call(K) === "[object Array]") {
            for (var ae, xr = K.concat(), Mt = [], ce = xr.length; ce--; )
              (typeof (ae = xr.shift()) != "string" || Object.prototype.toString.call(ae) === "[object Array]" && typeof ae[0] != "string") && (se = !1);
            qt = se;
          }
          if (qt === !1)
            throw new Error('Type of text must be string or Array. "' + K + '" is not recognized.');
          var Ir = R[B].encoding;
          Ir !== "WinAnsiEncoding" && Ir !== "StandardEncoding" || (K = et(K, function(ue, he, _e) {
            return [(wt = ue, wt = wt.split("	").join(Array(tA.TabLen || 9).join(" ")), bt(wt, VA)), he, _e];
            var wt;
          })), typeof K == "string" && (K = K.match(/[\r?\n]/) ? K.split(/\r\n|\r|\n/g) : [K]), 0 < (dr = tA.maxWidth || 0) && (typeof K == "string" ? K = EA.splitTextToSize(K, dr) : Object.prototype.toString.call(K) === "[object Array]" && (K = EA.splitTextToSize(K.join(" "), dr)));
          var qe = { text: K, x: aA, y: gA, options: tA, mutex: { pdfEscape: bt, activeFontKey: B, fonts: R, activeFontSize: y } };
          O.publish("preProcessText", qe), K = qe.text, it = (tA = qe.options).angle;
          var Xt = EA.internal.scaleFactor, ur = (EA.internal.pageSize.getHeight(), []);
          if (it) {
            it *= Math.PI / 180;
            var yr = Math.cos(it), Qr = Math.sin(it), hr = function(ue) {
              return ue.toFixed(2);
            };
            ur = [hr(yr), hr(Qr), hr(-1 * Qr), hr(yr)];
          }
          (rn = tA.charSpace) !== void 0 && (QA += rn + ` Tc
`), tA.lang;
          var le = -1, _r = tA.renderingMode || tA.stroke, Er = EA.internal.getCurrentPageInfo().pageContext;
          switch (_r) {
            case 0:
            case !1:
            case "fill":
              le = 0;
              break;
            case 1:
            case !0:
            case "stroke":
              le = 1;
              break;
            case 2:
            case "fillThenStroke":
              le = 2;
              break;
            case 3:
            case "invisible":
              le = 3;
              break;
            case 4:
            case "fillAndAddForClipping":
              le = 4;
              break;
            case 5:
            case "strokeAndAddPathForClipping":
              le = 5;
              break;
            case 6:
            case "fillThenStrokeAndAddToPathForClipping":
              le = 6;
              break;
            case 7:
            case "addToPathForClipping":
              le = 7;
          }
          var Or = Er.usedRenderingMode || -1;
          le !== -1 ? QA += le + ` Tr
` : Or !== -1 && (QA += `0 Tr
`), le !== -1 && (Er.usedRenderingMode = le), mt = tA.align || "left";
          var fr = y * bA, nr = EA.internal.pageSize.getHeight(), en = EA.internal.pageSize.getWidth(), Vn = (Xt = EA.internal.scaleFactor, R[B]), rn = tA.charSpace || P, dr = tA.maxWidth || 0, Pr = (VA = {}, []);
          if (Object.prototype.toString.call(K) === "[object Array]") {
            var je, xe;
            Mt = _A(K), mt !== "left" && (xe = Mt.map(function(ue) {
              return EA.getStringUnitWidth(ue, { font: Vn, charSpace: rn, fontSize: y }) * y / Xt;
            }));
            var Xe, Cn = Math.max.apply(Math, xe), Mr = 0;
            if (mt === "right") {
              aA -= xe[0], K = [];
              var ot = 0;
              for (ce = Mt.length; ot < ce; ot++)
                Cn - xe[ot], ot === 0 ? (Xe = aA * Xt, je = (nr - gA) * Xt) : (Xe = (Mr - xe[ot]) * Xt, je = -fr), K.push([Mt[ot], Xe, je]), Mr = xe[ot];
            } else if (mt === "center")
              for (aA -= xe[0] / 2, K = [], ot = 0, ce = Mt.length; ot < ce; ot++)
                (Cn - xe[ot]) / 2, ot === 0 ? (Xe = aA * Xt, je = (nr - gA) * Xt) : (Xe = (Mr - xe[ot]) / 2 * Xt, je = -fr), K.push([Mt[ot], Xe, je]), Mr = xe[ot];
            else if (mt === "left")
              for (K = [], ot = 0, ce = Mt.length; ot < ce; ot++)
                je = ot === 0 ? (nr - gA) * Xt : -fr, Xe = ot === 0 ? aA * Xt : 0, K.push(Mt[ot]);
            else {
              if (mt !== "justify")
                throw new Error('Unrecognized alignment option, use "left", "center", "right" or "justify".');
              for (K = [], dr = dr !== 0 ? dr : en, ot = 0, ce = Mt.length; ot < ce; ot++)
                je = ot === 0 ? (nr - gA) * Xt : -fr, Xe = ot === 0 ? aA * Xt : 0, ot < ce - 1 && Pr.push(((dr - xe[ot]) / (Mt[ot].split(" ").length - 1) * Xt).toFixed(2)), K.push([Mt[ot], Xe, je]);
            }
          }
          (typeof tA.R2L == "boolean" ? tA.R2L : _) === !0 && (K = et(K, function(ue, he, _e) {
            return [ue.split("").reverse().join(""), he, _e];
          })), qe = { text: K, x: aA, y: gA, options: tA, mutex: { pdfEscape: bt, activeFontKey: B, fonts: R, activeFontSize: y } }, O.publish("postProcessText", qe), K = qe.text, AA = qe.mutex.isHex, Mt = _A(K), K = [];
          var Rr, Nr, Hr, Gr = 0, Sr = (ce = Mt.length, "");
          for (ot = 0; ot < ce; ot++)
            Sr = "", Object.prototype.toString.call(Mt[ot]) !== "[object Array]" ? (Rr = parseFloat(aA * Xt).toFixed(2), Nr = parseFloat((nr - gA) * Xt).toFixed(2), Hr = (AA ? "<" : "(") + Mt[ot] + (AA ? ">" : ")")) : Object.prototype.toString.call(Mt[ot]) === "[object Array]" && (Rr = parseFloat(Mt[ot][1]).toFixed(2), Nr = parseFloat(Mt[ot][2]).toFixed(2), Hr = (AA ? "<" : "(") + Mt[ot][0] + (AA ? ">" : ")"), Gr = 1), Pr !== void 0 && Pr[ot] !== void 0 && (Sr = Pr[ot] + ` Tw
`), ur.length !== 0 && ot === 0 ? K.push(Sr + ur.join(" ") + " " + Rr + " " + Nr + ` Tm
` + Hr) : Gr === 1 || Gr === 0 && ot === 0 ? K.push(Sr + Rr + " " + Nr + ` Td
` + Hr) : K.push(Sr + Hr);
          K = Gr === 0 ? K.join(` Tj
T* `) : K.join(` Tj
`), K += ` Tj
`;
          var nn = `BT
/` + B + " " + y + ` Tf
` + (y * bA).toFixed(2) + ` TL
` + W + `
`;
          return nn += QA, nn += K, iA(nn += "ET"), EA;
        }, H.lstext = function(K, aA, gA, tA) {
          console.warn("jsPDF.lstext is deprecated");
          for (var AA = 0, dA = K.length; AA < dA; AA++, aA += tA)
            this.text(K[AA], aA, gA);
          return this;
        }, H.line = function(K, aA, gA, tA) {
          return this.lines([[gA - K, tA - aA]], K, aA);
        }, H.clip = function() {
          iA("W"), iA("S");
        }, H.clip_fixed = function(K) {
          iA(K === "evenodd" ? "W*" : "W"), iA("n");
        }, H.lines = function(K, aA, gA, tA, AA, dA) {
          var QA, bA, EA, _A, et, VA, it, mt, qt, se, ae;
          for (typeof K == "number" && (f = gA, gA = aA, aA = K, K = f), tA = tA || [1, 1], iA(KA(aA * h) + " " + KA((U - gA) * h) + " m "), QA = tA[0], bA = tA[1], _A = K.length, se = aA, ae = gA, EA = 0; EA < _A; EA++)
            (et = K[EA]).length === 2 ? (se = et[0] * QA + se, ae = et[1] * bA + ae, iA(KA(se * h) + " " + KA((U - ae) * h) + " l")) : (VA = et[0] * QA + se, it = et[1] * bA + ae, mt = et[2] * QA + se, qt = et[3] * bA + ae, se = et[4] * QA + se, ae = et[5] * bA + ae, iA(KA(VA * h) + " " + KA((U - it) * h) + " " + KA(mt * h) + " " + KA((U - qt) * h) + " " + KA(se * h) + " " + KA((U - ae) * h) + " c"));
          return dA && iA(" h"), AA !== null && iA(JA(AA)), this;
        }, H.rect = function(K, aA, gA, tA, AA) {
          return JA(AA), iA([xA(K * h), xA((U - aA) * h), xA(gA * h), xA(-tA * h), "re"].join(" ")), AA !== null && iA(JA(AA)), this;
        }, H.triangle = function(K, aA, gA, tA, AA, dA, QA) {
          return this.lines([[gA - K, tA - aA], [AA - gA, dA - tA], [K - AA, aA - dA]], K, aA, [1, 1], QA, !0), this;
        }, H.roundedRect = function(K, aA, gA, tA, AA, dA, QA) {
          var bA = 1.3333333333333333 * (Math.SQRT2 - 1);
          return this.lines([[gA - 2 * AA, 0], [AA * bA, 0, AA, dA - dA * bA, AA, dA], [0, tA - 2 * dA], [0, dA * bA, -AA * bA, dA, -AA, dA], [2 * AA - gA, 0], [-AA * bA, 0, -AA, -dA * bA, -AA, -dA], [0, 2 * dA - tA], [0, -dA * bA, AA * bA, -dA, AA, -dA]], K + AA, aA, [1, 1], QA), this;
        }, H.ellipse = function(K, aA, gA, tA, AA) {
          var dA = 1.3333333333333333 * (Math.SQRT2 - 1) * gA, QA = 4 / 3 * (Math.SQRT2 - 1) * tA;
          return iA([xA((K + gA) * h), xA((U - aA) * h), "m", xA((K + gA) * h), xA((U - (aA - QA)) * h), xA((K + dA) * h), xA((U - (aA - tA)) * h), xA(K * h), xA((U - (aA - tA)) * h), "c"].join(" ")), iA([xA((K - dA) * h), xA((U - (aA - tA)) * h), xA((K - gA) * h), xA((U - (aA - QA)) * h), xA((K - gA) * h), xA((U - aA) * h), "c"].join(" ")), iA([xA((K - gA) * h), xA((U - (aA + QA)) * h), xA((K - dA) * h), xA((U - (aA + tA)) * h), xA(K * h), xA((U - (aA + tA)) * h), "c"].join(" ")), iA([xA((K + dA) * h), xA((U - (aA + tA)) * h), xA((K + gA) * h), xA((U - (aA + QA)) * h), xA((K + gA) * h), xA((U - aA) * h), "c"].join(" ")), AA !== null && iA(JA(AA)), this;
        }, H.circle = function(K, aA, gA, tA) {
          return this.ellipse(K, aA, gA, gA, tA);
        }, H.setProperties = function(K) {
          for (var aA in Q)
            Q.hasOwnProperty(aA) && K[aA] && (Q[aA] = K[aA]);
          return this;
        }, H.setFontSize = function(K) {
          return y = K, this;
        }, H.setFont = function(K, aA) {
          return B = xt(K, aA), this;
        }, H.setFontStyle = H.setFontType = function(K) {
          return B = xt(void 0, K), this;
        }, H.getFontList = function() {
          var K, aA, gA, tA = {};
          for (K in E)
            if (E.hasOwnProperty(K))
              for (aA in tA[K] = gA = [], E[K])
                E[K].hasOwnProperty(aA) && gA.push(aA);
          return tA;
        }, H.addFont = function(K, aA, gA, tA) {
          gt(K, aA, gA, tA = tA || "Identity-H");
        }, H.setLineWidth = function(K) {
          return iA((K * h).toFixed(2) + " w"), this;
        }, H.setDrawColor = function(K, aA, gA, tA) {
          return iA(sA({ ch1: K, ch2: aA, ch3: gA, ch4: tA, pdfColorType: "draw", precision: 2 })), this;
        }, H.setFillColor = function(K, aA, gA, tA) {
          return iA(sA({ ch1: K, ch2: aA, ch3: gA, ch4: tA, pdfColorType: "fill", precision: 2 })), this;
        }, H.setTextColor = function(K, aA, gA, tA) {
          return W = sA({ ch1: K, ch2: aA, ch3: gA, ch4: tA, pdfColorType: "text", precision: 3 }), this;
        }, H.setCharSpace = function(K) {
          return P = K, this;
        }, H.setR2L = function(K) {
          return _ = K, this;
        }, H.CapJoinStyles = { 0: 0, butt: 0, but: 0, miter: 0, 1: 1, round: 1, rounded: 1, circle: 1, 2: 2, projecting: 2, project: 2, square: 2, bevel: 2 }, H.setLineCap = function(K) {
          var aA = this.CapJoinStyles[K];
          if (aA === void 0)
            throw new Error("Line cap style of '" + K + "' is not recognized. See or extend .CapJoinStyles property for valid styles");
          return iA((b = aA) + " J"), this;
        }, H.setLineJoin = function(K) {
          var aA = this.CapJoinStyles[K];
          if (aA === void 0)
            throw new Error("Line join style of '" + K + "' is not recognized. See or extend .CapJoinStyles property for valid styles");
          return iA((D = aA) + " j"), this;
        }, H.output = be, H.save = function(K) {
          H.output("save", K);
        }, r.API)
          r.API.hasOwnProperty(Yt) && (Yt === "events" && r.API.events.length ? function(K, aA) {
            var gA, tA, AA;
            for (AA = aA.length - 1; AA !== -1; AA--)
              gA = aA[AA][0], tA = aA[AA][1], K.subscribe.apply(K, [gA].concat(typeof tA == "function" ? [tA] : tA));
          }(O, r.API.events) : H[Yt] = r.API[Yt]);
        return function() {
          for (var K = "helvetica", aA = "times", gA = "courier", tA = "normal", AA = "bold", dA = "italic", QA = "bolditalic", bA = [["Helvetica", K, tA, "WinAnsiEncoding"], ["Helvetica-Bold", K, AA, "WinAnsiEncoding"], ["Helvetica-Oblique", K, dA, "WinAnsiEncoding"], ["Helvetica-BoldOblique", K, QA, "WinAnsiEncoding"], ["Courier", gA, tA, "WinAnsiEncoding"], ["Courier-Bold", gA, AA, "WinAnsiEncoding"], ["Courier-Oblique", gA, dA, "WinAnsiEncoding"], ["Courier-BoldOblique", gA, QA, "WinAnsiEncoding"], ["Times-Roman", aA, tA, "WinAnsiEncoding"], ["Times-Bold", aA, AA, "WinAnsiEncoding"], ["Times-Italic", aA, dA, "WinAnsiEncoding"], ["Times-BoldItalic", aA, QA, "WinAnsiEncoding"], ["ZapfDingbats", "zapfdingbats", tA, null], ["Symbol", "symbol", tA, null]], EA = 0, _A = bA.length; EA < _A; EA++) {
            var et = gt(bA[EA][0], bA[EA][1], bA[EA][2], bA[EA][3]), VA = bA[EA][0].split("-");
            jA(et, VA[0], VA[1] || "");
          }
          O.publish("addFonts", { fonts: R, dictionary: E });
        }(), B = "F1", ht(c, n), O.publish("initialized"), H;
      }
      return r.API = { events: [] }, r.version = "0.0.0", CA.exports ? (CA.exports = r, CA.exports.jsPDF = r) : o.jsPDF = r, r;
    }(typeof self < "u" && self || typeof window < "u" && window || typeof Jt < "u" && Jt || Function('return typeof this === "object" && this.content')() || Function("return this")());
    /** @preserve
       * jsPDF - PDF Document creation from JavaScript
       * Version 1.4.1 Built on 2018-06-06T07:49:34.040Z
       *                           CommitID 3233f44044
       *
       * Copyright (c) 2010-2016 James Hall <james@parall.ax>, https://github.com/MrRio/jsPDF
       *               2010 Aaron Spike, https://github.com/acspike
       *               2012 Willow Systems Corporation, willow-systems.com
       *               2012 Pablo Hess, https://github.com/pablohess
       *               2012 Florian Jenett, https://github.com/fjenett
       *               2013 Warren Weckesser, https://github.com/warrenweckesser
       *               2013 Youssef Beddad, https://github.com/lifof
       *               2013 Lee Driscoll, https://github.com/lsdriscoll
       *               2013 Stefan Slonevskiy, https://github.com/stefslon
       *               2013 Jeremy Morel, https://github.com/jmorel
       *               2013 Christoph Hartmann, https://github.com/chris-rock
       *               2014 Juan Pablo Gaviria, https://github.com/juanpgaviria
       *               2014 James Makes, https://github.com/dollaruw
       *               2014 Diego Casorran, https://github.com/diegocr
       *               2014 Steven Spungin, https://github.com/Flamenco
       *               2014 Kenneth Glassey, https://github.com/Gavvers
       *
       * Licensed under the MIT License
       *
       * Contributor(s):
       *    siefkenj, ahwolf, rickygu, Midnith, saintclair, eaparango,
       *    kim3er, mfo, alnorth, Flamenco
       */
    (function(o, p) {
      var C, i, r = 1, n = function(b, D) {
        b.prototype = Object.create(D.prototype), b.prototype.constructor = b;
      }, s = function(b) {
        return b * (r / 1);
      }, c = function(b) {
        var D = new _(), u = nA.internal.getHeight(b) || 0, Q = nA.internal.getWidth(b) || 0;
        return D.BBox = [0, 0, Q.toFixed(2), u.toFixed(2)], D;
      }, l = function(b, D, u) {
        b = b || 0;
        var Q = 1;
        return Q <<= D - 1, (u = u || 1) == 1 ? b = b | Q : b = b & ~Q, b;
      }, d = function(b, D, u) {
        return u = u || 1.3, b = b || 0, D.readOnly == 1 && (b = l(b, 1)), D.required == 1 && (b = l(b, 2)), D.noExport == 1 && (b = l(b, 3)), D.multiline == 1 && (b = l(b, 13)), D.password && (b = l(b, 14)), D.noToggleToOff && (b = l(b, 15)), D.radio && (b = l(b, 16)), D.pushbutton && (b = l(b, 17)), D.combo && (b = l(b, 18)), D.edit && (b = l(b, 19)), D.sort && (b = l(b, 20)), D.fileSelect && 1.4 <= u && (b = l(b, 21)), D.multiSelect && 1.4 <= u && (b = l(b, 22)), D.doNotSpellCheck && 1.4 <= u && (b = l(b, 23)), D.doNotScroll == 1 && 1.4 <= u && (b = l(b, 24)), D.richText && 1.4 <= u && (b = l(b, 25)), b;
      }, B = function(b) {
        var D = b[0], u = b[1], Q = b[2], H = b[3], O = {};
        return Array.isArray(D) ? (D[0] = s(D[0]), D[1] = s(D[1]), D[2] = s(D[2]), D[3] = s(D[3])) : (D = s(D), u = s(u), Q = s(Q), H = s(H)), O.lowerLeft_X = D || 0, O.lowerLeft_Y = s(i) - u - H || 0, O.upperRight_X = D + Q || 0, O.upperRight_Y = s(i) - u || 0, [O.lowerLeft_X.toFixed(2), O.lowerLeft_Y.toFixed(2), O.upperRight_X.toFixed(2), O.upperRight_Y.toFixed(2)];
      }, h = function(b) {
        if (b.appearanceStreamContent)
          return b.appearanceStreamContent;
        if (b.V || b.DV) {
          var D = [], u = b.V || b.DV, Q = f(b, u);
          D.push("/Tx BMC"), D.push("q"), D.push("/F1 " + Q.fontSize.toFixed(2) + " Tf"), D.push("1 0 0 1 0 0 Tm"), D.push("BT"), D.push(Q.text), D.push("ET"), D.push("Q"), D.push("EMC");
          var H = new c(b);
          return H.stream = D.join(`
`), H;
        }
      }, f = function(b, D, u, Q) {
        Q = Q || 12, u = u || "helvetica";
        var H = { text: "", fontSize: "" }, O = (D = (D = D.substr(0, 1) == "(" ? D.substr(1) : D).substr(D.length - 1) == ")" ? D.substr(0, D.length - 1) : D).split(" "), eA = Q, sA = nA.internal.getHeight(b) || 0;
        sA = sA < 0 ? -sA : sA;
        var pA = nA.internal.getWidth(b) || 0;
        pA = pA < 0 ? -pA : pA;
        var yA = function(Pt, JA, ee) {
          if (Pt + 1 < O.length) {
            var oe = JA + " " + O[Pt + 1];
            return m(oe, ee + "px", u).width <= pA - 4;
          }
          return !1;
        };
        eA++;
        A:
          for (; ; ) {
            D = "";
            var wA = m("3", --eA + "px", u).height, SA = b.multiline ? sA - eA : (sA - wA) / 2, xA = -2, KA = SA += 2, iA = 0, yt = 0, $A = 0;
            if (eA <= 0) {
              eA = 12, D = `(...) Tj
`, D += "% Width of Text: " + m(D, "1px").width + ", FieldWidth:" + pA + `
`;
              break;
            }
            $A = m(O[0] + " ", eA + "px", u).width;
            var st = "", kt = 0;
            for (var jA in O) {
              st = (st += O[jA] + " ").substr(st.length - 1) == " " ? st.substr(0, st.length - 1) : st;
              var gt = parseInt(jA);
              $A = m(st + " ", eA + "px", u).width;
              var bt = yA(gt, st, eA), ht = jA >= O.length - 1;
              if (!bt || ht) {
                if (bt || ht) {
                  if (ht)
                    yt = gt;
                  else if (b.multiline && sA < (wA + 2) * (kt + 2) + 2)
                    continue A;
                } else {
                  if (!b.multiline || sA < (wA + 2) * (kt + 2) + 2)
                    continue A;
                  yt = gt;
                }
                for (var ct = "", xt = iA; xt <= yt; xt++)
                  ct += O[xt] + " ";
                switch (ct = ct.substr(ct.length - 1) == " " ? ct.substr(0, ct.length - 1) : ct, $A = m(ct, eA + "px", u).width, b.Q) {
                  case 2:
                    xA = pA - $A - 2;
                    break;
                  case 1:
                    xA = (pA - $A) / 2;
                    break;
                  case 0:
                  default:
                    xA = 2;
                }
                D += xA.toFixed(2) + " " + KA.toFixed(2) + ` Td
`, D += "(" + ct + `) Tj
`, D += -xA.toFixed(2) + ` 0 Td
`, KA = -(eA + 2), $A = 0, iA = yt + 1, kt++, st = "";
              } else
                st += " ";
            }
            break;
          }
        return H.text = D, H.fontSize = eA, H;
      }, m = function(b, D, u) {
        u = u || "helvetica";
        var Q = C.internal.getFont(u), H = C.getStringUnitWidth(b, { font: Q, fontSize: parseFloat(D), charSpace: 0 }) * parseFloat(D);
        return { height: C.getStringUnitWidth("3", { font: Q, fontSize: parseFloat(D), charSpace: 0 }) * parseFloat(D) * 1.5, width: H };
      }, w = { fields: [], xForms: [], acroFormDictionaryRoot: null, printedOut: !1, internal: null, isInitialized: !1 }, U = function() {
        for (var b in C.internal.acroformPlugin.acroFormDictionaryRoot.Fields) {
          var D = C.internal.acroformPlugin.acroFormDictionaryRoot.Fields[b];
          D.hasAnnotation && S.call(C, D);
        }
      }, I = function(b) {
        C.internal.acroformPlugin.printedOut && (C.internal.acroformPlugin.printedOut = !1, C.internal.acroformPlugin.acroFormDictionaryRoot = null), C.internal.acroformPlugin.acroFormDictionaryRoot || W.call(C), C.internal.acroformPlugin.acroFormDictionaryRoot.Fields.push(b);
      }, S = function(b) {
        var D = { type: "reference", object: b };
        C.annotationPlugin.annotations[C.internal.getPageInfo(b.page).pageNumber].push(D);
      }, L = function() {
        C.internal.acroformPlugin.acroFormDictionaryRoot !== void 0 ? C.internal.write("/AcroForm " + C.internal.acroformPlugin.acroFormDictionaryRoot.objId + " 0 R") : console.log("Root missing...");
      }, N = function() {
        C.internal.events.unsubscribe(C.internal.acroformPlugin.acroFormDictionaryRoot._eventID), delete C.internal.acroformPlugin.acroFormDictionaryRoot._eventID, C.internal.acroformPlugin.printedOut = !0;
      }, j = function(b) {
        var D = !b;
        b || (C.internal.newObjectDeferredBegin(C.internal.acroformPlugin.acroFormDictionaryRoot.objId), C.internal.out(C.internal.acroformPlugin.acroFormDictionaryRoot.getString())), b = b || C.internal.acroformPlugin.acroFormDictionaryRoot.Kids;
        for (var u in b) {
          var Q = b[u], H = Q.Rect;
          Q.Rect && (Q.Rect = B.call(this, Q.Rect)), C.internal.newObjectDeferredBegin(Q.objId);
          var O = Q.objId + ` 0 obj
<<
`;
          if ((Q === void 0 ? "undefined" : Ot(Q)) === "object" && typeof Q.getContent == "function" && (O += Q.getContent()), Q.Rect = H, Q.hasAppearanceStream && !Q.appearanceStreamContent) {
            var eA = h.call(this, Q);
            O += "/AP << /N " + eA + ` >>
`, C.internal.acroformPlugin.xForms.push(eA);
          }
          if (Q.appearanceStreamContent) {
            for (var sA in O += "/AP << ", Q.appearanceStreamContent) {
              var pA = Q.appearanceStreamContent[sA];
              if (O += "/" + sA + " ", O += "<< ", 1 <= Object.keys(pA).length || Array.isArray(pA))
                for (var u in pA) {
                  var yA;
                  typeof (yA = pA[u]) == "function" && (yA = yA.call(this, Q)), O += "/" + u + " " + yA + " ", 0 <= C.internal.acroformPlugin.xForms.indexOf(yA) || C.internal.acroformPlugin.xForms.push(yA);
                }
              else
                typeof (yA = pA) == "function" && (yA = yA.call(this, Q)), O += "/" + u + " " + yA + ` 
`, 0 <= C.internal.acroformPlugin.xForms.indexOf(yA) || C.internal.acroformPlugin.xForms.push(yA);
              O += ` >>
`;
            }
            O += `>>
`;
          }
          O += `>>
endobj
`, C.internal.out(O);
        }
        D && Z.call(this, C.internal.acroformPlugin.xForms);
      }, Z = function(b) {
        for (var D in b) {
          var u = D, Q = b[D];
          C.internal.newObjectDeferredBegin(Q && Q.objId);
          var H = "";
          (Q === void 0 ? "undefined" : Ot(Q)) === "object" && typeof Q.getString == "function" && (H = Q.getString()), C.internal.out(H), delete b[u];
        }
      }, W = function() {
        if (this.internal !== void 0 && (this.internal.acroformPlugin === void 0 || this.internal.acroformPlugin.isInitialized === !1)) {
          if (C = this, $.FieldNum = 0, this.internal.acroformPlugin = JSON.parse(JSON.stringify(w)), this.internal.acroformPlugin.acroFormDictionaryRoot)
            throw new Error("Exception while creating AcroformDictionary");
          r = C.internal.scaleFactor, i = C.internal.pageSize.getHeight(), C.internal.acroformPlugin.acroFormDictionaryRoot = new Y(), C.internal.acroformPlugin.acroFormDictionaryRoot._eventID = C.internal.events.subscribe("postPutResources", N), C.internal.events.subscribe("buildDocument", U), C.internal.events.subscribe("putCatalog", L), C.internal.events.subscribe("postPutPages", j), C.internal.acroformPlugin.isInitialized = !0;
        }
      }, V = function(b) {
        if (Array.isArray(b)) {
          var D = " [";
          for (var u in b)
            D += b[u].toString(), D += u < b.length - 1 ? " " : "";
          return D += "]";
        }
      }, y = function(b) {
        return (b = b || "").indexOf("(") !== 0 && (b = "(" + b), b.substring(b.length - 1) != ")" && (b += ")"), b;
      }, P = function() {
        var b;
        Object.defineProperty(this, "objId", { get: function() {
          return b || (b = C.internal.newObjectDeferred()), b || console.log("Couldn't create Object ID"), b;
        }, configurable: !1 });
      };
      P.prototype.toString = function() {
        return this.objId + " 0 R";
      }, P.prototype.getString = function() {
        var b = this.objId + ` 0 obj
<<`;
        return b += this.getContent() + `>>
`, this.stream && (b += `stream
`, b += this.stream, b += `
endstream
`), b += `endobj
`;
      }, P.prototype.getContent = function() {
        var b = "";
        return b += function(D) {
          var u = "", Q = Object.keys(D).filter(function(sA) {
            return sA != "content" && sA != "appearanceStreamContent" && sA.substring(0, 1) != "_";
          });
          for (var H in Q) {
            var O = Q[H], eA = D[O];
            eA && (Array.isArray(eA) ? u += "/" + O + " " + V(eA) + `
` : u += eA instanceof P ? "/" + O + " " + eA.objId + ` 0 R
` : "/" + O + " " + eA + `
`);
          }
          return u;
        }(this);
      };
      var _ = function() {
        var b;
        P.call(this), this.Type = "/XObject", this.Subtype = "/Form", this.FormType = 1, this.BBox, this.Matrix, this.Resources = "2 0 R", this.PieceInfo, Object.defineProperty(this, "Length", { enumerable: !0, get: function() {
          return b !== void 0 ? b.length : 0;
        } }), Object.defineProperty(this, "stream", { enumerable: !1, set: function(D) {
          b = D.trim();
        }, get: function() {
          return b || null;
        } });
      };
      n(_, P);
      var Y = function() {
        P.call(this);
        var b = [];
        Object.defineProperty(this, "Kids", { enumerable: !1, configurable: !0, get: function() {
          return 0 < b.length ? b : void 0;
        } }), Object.defineProperty(this, "Fields", { enumerable: !0, configurable: !0, get: function() {
          return b;
        } }), this.DA;
      };
      n(Y, P);
      var $ = function b() {
        var D;
        P.call(this), Object.defineProperty(this, "Rect", { enumerable: !0, configurable: !1, get: function() {
          if (D)
            return D;
        }, set: function(sA) {
          D = sA;
        } });
        var u, Q, H, O, eA = "";
        Object.defineProperty(this, "FT", { enumerable: !0, set: function(sA) {
          eA = sA;
        }, get: function() {
          return eA;
        } }), Object.defineProperty(this, "T", { enumerable: !0, configurable: !1, set: function(sA) {
          u = sA;
        }, get: function() {
          return !u || u.length < 1 ? this instanceof M ? void 0 : "(FieldObject" + b.FieldNum++ + ")" : u.substring(0, 1) == "(" && u.substring(u.length - 1) ? u : "(" + u + ")";
        } }), Object.defineProperty(this, "DA", { enumerable: !0, get: function() {
          if (Q)
            return "(" + Q + ")";
        }, set: function(sA) {
          Q = sA;
        } }), Object.defineProperty(this, "DV", { enumerable: !0, configurable: !0, get: function() {
          if (H)
            return H;
        }, set: function(sA) {
          H = sA;
        } }), Object.defineProperty(this, "V", { enumerable: !0, configurable: !0, get: function() {
          if (O)
            return O;
        }, set: function(sA) {
          O = sA;
        } }), Object.defineProperty(this, "Type", { enumerable: !0, get: function() {
          return this.hasAnnotation ? "/Annot" : null;
        } }), Object.defineProperty(this, "Subtype", { enumerable: !0, get: function() {
          return this.hasAnnotation ? "/Widget" : null;
        } }), this.BG, Object.defineProperty(this, "hasAnnotation", { enumerable: !1, get: function() {
          return !!(this.Rect || this.BC || this.BG);
        } }), Object.defineProperty(this, "hasAppearanceStream", { enumerable: !1, configurable: !0, writable: !0 }), Object.defineProperty(this, "page", { enumerable: !1, configurable: !0, writable: !0 });
      };
      n($, P);
      var hA = function() {
        $.call(this), this.FT = "/Ch", this.Opt = [], this.V = "()", this.TI = 0;
        var b = !1;
        Object.defineProperty(this, "combo", { enumerable: !1, get: function() {
          return b;
        }, set: function(D) {
          b = D;
        } }), Object.defineProperty(this, "edit", { enumerable: !0, set: function(D) {
          D == 1 ? (this._edit = !0, this.combo = !0) : this._edit = !1;
        }, get: function() {
          return !!this._edit && this._edit;
        }, configurable: !1 }), this.hasAppearanceStream = !0;
      };
      n(hA, $);
      var z = function() {
        hA.call(this), this.combo = !1;
      };
      n(z, hA);
      var k = function() {
        z.call(this), this.combo = !0;
      };
      n(k, z);
      var F = function() {
        k.call(this), this.edit = !0;
      };
      n(F, k);
      var R = function() {
        $.call(this), this.FT = "/Btn";
      };
      n(R, $);
      var E = function() {
        R.call(this);
        var b = !0;
        Object.defineProperty(this, "pushbutton", { enumerable: !1, get: function() {
          return b;
        }, set: function(D) {
          b = D;
        } });
      };
      n(E, R);
      var G = function() {
        R.call(this);
        var b = !0;
        Object.defineProperty(this, "radio", { enumerable: !1, get: function() {
          return b;
        }, set: function(Q) {
          b = Q;
        } });
        var D, u = [];
        Object.defineProperty(this, "Kids", { enumerable: !0, get: function() {
          if (0 < u.length)
            return u;
        } }), Object.defineProperty(this, "__Kids", { get: function() {
          return u;
        } }), Object.defineProperty(this, "noToggleToOff", { enumerable: !1, get: function() {
          return D;
        }, set: function(Q) {
          D = Q;
        } });
      };
      n(G, R);
      var M = function(b, D) {
        $.call(this), this.Parent = b, this._AppearanceType = nA.RadioButton.Circle, this.appearanceStreamContent = this._AppearanceType.createAppearanceStream(D), this.F = l(this.F, 3, 1), this.MK = this._AppearanceType.createMK(), this.AS = "/Off", this._Name = D;
      };
      n(M, $), G.prototype.setAppearance = function(b) {
        if ("createAppearanceStream" in b && "createMK" in b)
          for (var D in this.__Kids) {
            var u = this.__Kids[D];
            u.appearanceStreamContent = b.createAppearanceStream(u._Name), u.MK = b.createMK();
          }
        else
          console.log("Couldn't assign Appearance to RadioButton. Appearance was Invalid!");
      }, G.prototype.createOption = function(b) {
        this.__Kids.length;
        var D = new M(this, b);
        return this.__Kids.push(D), o.addField(D), D;
      };
      var oA = function() {
        R.call(this), this.appearanceStreamContent = nA.CheckBox.createAppearanceStream(), this.MK = nA.CheckBox.createMK(), this.AS = "/On", this.V = "/On";
      };
      n(oA, R);
      var X = function() {
        var b, D;
        $.call(this), this.DA = nA.createDefaultAppearanceStream(), this.F = 4, Object.defineProperty(this, "V", { get: function() {
          return b && y(b);
        }, enumerable: !0, set: function(sA) {
          b = sA;
        } }), Object.defineProperty(this, "DV", { get: function() {
          return D && y(D);
        }, enumerable: !0, set: function(sA) {
          D = sA;
        } });
        var u = !1;
        Object.defineProperty(this, "multiline", { enumerable: !1, get: function() {
          return u;
        }, set: function(sA) {
          u = sA;
        } });
        var Q = !1;
        Object.defineProperty(this, "fileSelect", { enumerable: !1, get: function() {
          return Q;
        }, set: function(sA) {
          Q = sA;
        } });
        var H = !1;
        Object.defineProperty(this, "doNotSpellCheck", { enumerable: !1, get: function() {
          return H;
        }, set: function(sA) {
          H = sA;
        } });
        var O = !1;
        Object.defineProperty(this, "doNotScroll", { enumerable: !1, get: function() {
          return O;
        }, set: function(sA) {
          O = sA;
        } });
        var eA = !1;
        Object.defineProperty(this, "MaxLen", { enumerable: !0, get: function() {
          return eA;
        }, set: function(sA) {
          eA = sA;
        } }), Object.defineProperty(this, "hasAppearanceStream", { enumerable: !1, get: function() {
          return this.V || this.DV;
        } });
      };
      n(X, $);
      var fA = function() {
        X.call(this);
        var b = !0;
        Object.defineProperty(this, "password", { enumerable: !1, get: function() {
          return b;
        }, set: function(D) {
          b = D;
        } });
      };
      n(fA, X);
      var nA = { CheckBox: { createAppearanceStream: function() {
        return { N: { On: nA.CheckBox.YesNormal }, D: { On: nA.CheckBox.YesPushDown, Off: nA.CheckBox.OffPushDown } };
      }, createMK: function() {
        return "<< /CA (3)>>";
      }, YesPushDown: function(b) {
        var D = c(b), u = [], Q = C.internal.getFont("zapfdingbats", "normal").id;
        b.Q = 1;
        var H = f(b, "3", "ZapfDingbats", 50);
        return u.push("0.749023 g"), u.push("0 0 " + nA.internal.getWidth(b).toFixed(2) + " " + nA.internal.getHeight(b).toFixed(2) + " re"), u.push("f"), u.push("BMC"), u.push("q"), u.push("0 0 1 rg"), u.push("/" + Q + " " + H.fontSize.toFixed(2) + " Tf 0 g"), u.push("BT"), u.push(H.text), u.push("ET"), u.push("Q"), u.push("EMC"), D.stream = u.join(`
`), D;
      }, YesNormal: function(b) {
        var D = c(b), u = C.internal.getFont("zapfdingbats", "normal").id, Q = [];
        b.Q = 1;
        var H = nA.internal.getHeight(b), O = nA.internal.getWidth(b), eA = f(b, "3", "ZapfDingbats", 0.9 * H);
        return Q.push("1 g"), Q.push("0 0 " + O.toFixed(2) + " " + H.toFixed(2) + " re"), Q.push("f"), Q.push("q"), Q.push("0 0 1 rg"), Q.push("0 0 " + (O - 1).toFixed(2) + " " + (H - 1).toFixed(2) + " re"), Q.push("W"), Q.push("n"), Q.push("0 g"), Q.push("BT"), Q.push("/" + u + " " + eA.fontSize.toFixed(2) + " Tf 0 g"), Q.push(eA.text), Q.push("ET"), Q.push("Q"), D.stream = Q.join(`
`), D;
      }, OffPushDown: function(b) {
        var D = c(b), u = [];
        return u.push("0.749023 g"), u.push("0 0 " + nA.internal.getWidth(b).toFixed(2) + " " + nA.internal.getHeight(b).toFixed(2) + " re"), u.push("f"), D.stream = u.join(`
`), D;
      } }, RadioButton: { Circle: { createAppearanceStream: function(b) {
        var D = { D: { Off: nA.RadioButton.Circle.OffPushDown }, N: {} };
        return D.N[b] = nA.RadioButton.Circle.YesNormal, D.D[b] = nA.RadioButton.Circle.YesPushDown, D;
      }, createMK: function() {
        return "<< /CA (l)>>";
      }, YesNormal: function(b) {
        var D = c(b), u = [], Q = nA.internal.getWidth(b) <= nA.internal.getHeight(b) ? nA.internal.getWidth(b) / 4 : nA.internal.getHeight(b) / 4;
        Q *= 0.9;
        var H = nA.internal.Bezier_C;
        return u.push("q"), u.push("1 0 0 1 " + nA.internal.getWidth(b) / 2 + " " + nA.internal.getHeight(b) / 2 + " cm"), u.push(Q + " 0 m"), u.push(Q + " " + Q * H + " " + Q * H + " " + Q + " 0 " + Q + " c"), u.push("-" + Q * H + " " + Q + " -" + Q + " " + Q * H + " -" + Q + " 0 c"), u.push("-" + Q + " -" + Q * H + " -" + Q * H + " -" + Q + " 0 -" + Q + " c"), u.push(Q * H + " -" + Q + " " + Q + " -" + Q * H + " " + Q + " 0 c"), u.push("f"), u.push("Q"), D.stream = u.join(`
`), D;
      }, YesPushDown: function(b) {
        var D = c(b), u = [], Q = nA.internal.getWidth(b) <= nA.internal.getHeight(b) ? nA.internal.getWidth(b) / 4 : nA.internal.getHeight(b) / 4, H = 2 * (Q *= 0.9), O = H * nA.internal.Bezier_C, eA = Q * nA.internal.Bezier_C;
        return u.push("0.749023 g"), u.push("q"), u.push("1 0 0 1 " + (nA.internal.getWidth(b) / 2).toFixed(2) + " " + (nA.internal.getHeight(b) / 2).toFixed(2) + " cm"), u.push(H + " 0 m"), u.push(H + " " + O + " " + O + " " + H + " 0 " + H + " c"), u.push("-" + O + " " + H + " -" + H + " " + O + " -" + H + " 0 c"), u.push("-" + H + " -" + O + " -" + O + " -" + H + " 0 -" + H + " c"), u.push(O + " -" + H + " " + H + " -" + O + " " + H + " 0 c"), u.push("f"), u.push("Q"), u.push("0 g"), u.push("q"), u.push("1 0 0 1 " + (nA.internal.getWidth(b) / 2).toFixed(2) + " " + (nA.internal.getHeight(b) / 2).toFixed(2) + " cm"), u.push(Q + " 0 m"), u.push(Q + " " + eA + " " + eA + " " + Q + " 0 " + Q + " c"), u.push("-" + eA + " " + Q + " -" + Q + " " + eA + " -" + Q + " 0 c"), u.push("-" + Q + " -" + eA + " -" + eA + " -" + Q + " 0 -" + Q + " c"), u.push(eA + " -" + Q + " " + Q + " -" + eA + " " + Q + " 0 c"), u.push("f"), u.push("Q"), D.stream = u.join(`
`), D;
      }, OffPushDown: function(b) {
        var D = c(b), u = [], Q = nA.internal.getWidth(b) <= nA.internal.getHeight(b) ? nA.internal.getWidth(b) / 4 : nA.internal.getHeight(b) / 4, H = 2 * (Q *= 0.9), O = H * nA.internal.Bezier_C;
        return u.push("0.749023 g"), u.push("q"), u.push("1 0 0 1 " + (nA.internal.getWidth(b) / 2).toFixed(2) + " " + (nA.internal.getHeight(b) / 2).toFixed(2) + " cm"), u.push(H + " 0 m"), u.push(H + " " + O + " " + O + " " + H + " 0 " + H + " c"), u.push("-" + O + " " + H + " -" + H + " " + O + " -" + H + " 0 c"), u.push("-" + H + " -" + O + " -" + O + " -" + H + " 0 -" + H + " c"), u.push(O + " -" + H + " " + H + " -" + O + " " + H + " 0 c"), u.push("f"), u.push("Q"), D.stream = u.join(`
`), D;
      } }, Cross: { createAppearanceStream: function(b) {
        var D = { D: { Off: nA.RadioButton.Cross.OffPushDown }, N: {} };
        return D.N[b] = nA.RadioButton.Cross.YesNormal, D.D[b] = nA.RadioButton.Cross.YesPushDown, D;
      }, createMK: function() {
        return "<< /CA (8)>>";
      }, YesNormal: function(b) {
        var D = c(b), u = [], Q = nA.internal.calculateCross(b);
        return u.push("q"), u.push("1 1 " + (nA.internal.getWidth(b) - 2).toFixed(2) + " " + (nA.internal.getHeight(b) - 2).toFixed(2) + " re"), u.push("W"), u.push("n"), u.push(Q.x1.x.toFixed(2) + " " + Q.x1.y.toFixed(2) + " m"), u.push(Q.x2.x.toFixed(2) + " " + Q.x2.y.toFixed(2) + " l"), u.push(Q.x4.x.toFixed(2) + " " + Q.x4.y.toFixed(2) + " m"), u.push(Q.x3.x.toFixed(2) + " " + Q.x3.y.toFixed(2) + " l"), u.push("s"), u.push("Q"), D.stream = u.join(`
`), D;
      }, YesPushDown: function(b) {
        var D = c(b), u = nA.internal.calculateCross(b), Q = [];
        return Q.push("0.749023 g"), Q.push("0 0 " + nA.internal.getWidth(b).toFixed(2) + " " + nA.internal.getHeight(b).toFixed(2) + " re"), Q.push("f"), Q.push("q"), Q.push("1 1 " + (nA.internal.getWidth(b) - 2).toFixed(2) + " " + (nA.internal.getHeight(b) - 2).toFixed(2) + " re"), Q.push("W"), Q.push("n"), Q.push(u.x1.x.toFixed(2) + " " + u.x1.y.toFixed(2) + " m"), Q.push(u.x2.x.toFixed(2) + " " + u.x2.y.toFixed(2) + " l"), Q.push(u.x4.x.toFixed(2) + " " + u.x4.y.toFixed(2) + " m"), Q.push(u.x3.x.toFixed(2) + " " + u.x3.y.toFixed(2) + " l"), Q.push("s"), Q.push("Q"), D.stream = Q.join(`
`), D;
      }, OffPushDown: function(b) {
        var D = c(b), u = [];
        return u.push("0.749023 g"), u.push("0 0 " + nA.internal.getWidth(b).toFixed(2) + " " + nA.internal.getHeight(b).toFixed(2) + " re"), u.push("f"), D.stream = u.join(`
`), D;
      } } }, createDefaultAppearanceStream: function(b) {
        return "/F1 0 Tf 0 g";
      } };
      nA.internal = { Bezier_C: 0.551915024494, calculateCross: function(b) {
        var D, u, Q = nA.internal.getWidth(b), H = nA.internal.getHeight(b), O = (u = H) < (D = Q) ? u : D;
        return { x1: { x: (Q - O) / 2, y: (H - O) / 2 + O }, x2: { x: (Q - O) / 2 + O, y: (H - O) / 2 }, x3: { x: (Q - O) / 2, y: (H - O) / 2 }, x4: { x: (Q - O) / 2 + O, y: (H - O) / 2 + O } };
      } }, nA.internal.getWidth = function(b) {
        var D = 0;
        return (b === void 0 ? "undefined" : Ot(b)) === "object" && (D = s(b.Rect[2])), D;
      }, nA.internal.getHeight = function(b) {
        var D = 0;
        return (b === void 0 ? "undefined" : Ot(b)) === "object" && (D = s(b.Rect[3])), D;
      }, o.addField = function(b) {
        return W.call(this), b instanceof X ? this.addTextField.call(this, b) : b instanceof hA ? this.addChoiceField.call(this, b) : b instanceof R ? this.addButton.call(this, b) : b instanceof M ? I.call(this, b) : b && I.call(this, b), b.page = C.internal.getCurrentPageInfo().pageNumber, this;
      }, o.addButton = function(b) {
        W.call(this);
        var D = b || new $();
        D.FT = "/Btn", D.Ff = d(D.Ff, b, C.internal.getPDFVersion()), I.call(this, D);
      }, o.addTextField = function(b) {
        W.call(this);
        var D = b || new $();
        D.FT = "/Tx", D.Ff = d(D.Ff, b, C.internal.getPDFVersion()), I.call(this, D);
      }, o.addChoiceField = function(b) {
        W.call(this);
        var D = b || new $();
        D.FT = "/Ch", D.Ff = d(D.Ff, b, C.internal.getPDFVersion()), I.call(this, D);
      }, (p === void 0 ? "undefined" : Ot(p)) == "object" && (p.ChoiceField = hA, p.ListBox = z, p.ComboBox = k, p.EditBox = F, p.Button = R, p.PushButton = E, p.RadioButton = G, p.CheckBox = oA, p.TextField = X, p.PasswordField = fA, p.AcroForm = { Appearance: nA }), o.AcroFormChoiceField = hA, o.AcroFormListBox = z, o.AcroFormComboBox = k, o.AcroFormEditBox = F, o.AcroFormButton = R, o.AcroFormPushButton = E, o.AcroFormRadioButton = G, o.AcroFormCheckBox = oA, o.AcroFormTextField = X, o.AcroFormPasswordField = fA, o.AcroForm = { ChoiceField: hA, ListBox: z, ComboBox: k, EditBox: F, Button: R, PushButton: E, RadioButton: G, CheckBox: oA, TextField: X, PasswordField: fA };
    })(Ct.API, typeof window < "u" && window || typeof Jt < "u" && Jt), Ct.API.addHTML = function(o, p, C, i, r) {
      if (typeof html2canvas > "u" && typeof rasterizeHTML > "u")
        throw new Error("You need either https://github.com/niklasvh/html2canvas or https://github.com/cburgmer/rasterizeHTML.js");
      typeof p != "number" && (i = p, r = C), typeof i == "function" && (r = i, i = null), typeof r != "function" && (r = function() {
      });
      var n = this.internal, s = n.scaleFactor, c = n.pageSize.getWidth(), l = n.pageSize.getHeight();
      if ((i = i || {}).onrendered = (function(B) {
        p = parseInt(p) || 0, C = parseInt(C) || 0;
        var h = i.dim || {}, f = Object.assign({ top: 0, right: 0, bottom: 0, left: 0, useFor: "content" }, i.margin), m = h.h || Math.min(l, B.height / s), w = h.w || Math.min(c, B.width / s) - p, U = i.format || "JPEG", I = i.imageCompression || "SLOW";
        if (B.height > l - f.top - f.bottom && i.pagesplit) {
          var S = function(W, V, y, P, _) {
            var Y = document.createElement("canvas");
            Y.height = _, Y.width = P;
            var $ = Y.getContext("2d");
            return $.mozImageSmoothingEnabled = !1, $.webkitImageSmoothingEnabled = !1, $.msImageSmoothingEnabled = !1, $.imageSmoothingEnabled = !1, $.fillStyle = i.backgroundColor || "#ffffff", $.fillRect(0, 0, P, _), $.drawImage(W, V, y, P, _, 0, 0, P, _), Y;
          }, L = (function() {
            for (var W, V, y = 0, P = 0, _ = {}, Y = !1; ; ) {
              var $;
              if (P = 0, _.top = y !== 0 ? f.top : C, _.left = y !== 0 ? f.left : p, Y = (c - f.left - f.right) * s < B.width, f.useFor === "content" ? y === 0 ? (W = Math.min((c - f.left) * s, B.width), V = Math.min((l - f.top) * s, B.height - y)) : (W = Math.min(c * s, B.width), V = Math.min(l * s, B.height - y), _.top = 0) : (W = Math.min((c - f.left - f.right) * s, B.width), V = Math.min((l - f.bottom - f.top) * s, B.height - y)), Y)
                for (; ; ) {
                  f.useFor === "content" && (P === 0 ? W = Math.min((c - f.left) * s, B.width) : (W = Math.min(c * s, B.width - P), _.left = 0));
                  var hA = [$ = S(B, P, y, W, V), _.left, _.top, $.width / s, $.height / s, U, null, I];
                  if (this.addImage.apply(this, hA), (P += W) >= B.width)
                    break;
                  this.addPage();
                }
              else
                hA = [$ = S(B, 0, y, W, V), _.left, _.top, $.width / s, $.height / s, U, null, I], this.addImage.apply(this, hA);
              if ((y += V) >= B.height)
                break;
              this.addPage();
            }
            r(w, y, null, hA);
          }).bind(this);
          if (B.nodeName === "CANVAS") {
            var N = new Image();
            N.onload = L, N.src = B.toDataURL("image/png"), B = N;
          } else
            L();
        } else {
          var j = Math.random().toString(35), Z = [B, p, C, w, m, U, j, I];
          this.addImage.apply(this, Z), r(w, m, j, Z);
        }
      }).bind(this), typeof html2canvas < "u" && !i.rstz)
        return html2canvas(o, i);
      if (typeof rasterizeHTML < "u") {
        var d = "drawDocument";
        return typeof o == "string" && (d = /^http/.test(o) ? "drawURL" : "drawHTML"), i.width = i.width || c * s, rasterizeHTML[d](o, void 0, i).then(function(B) {
          i.onrendered(B.image);
        }, function(B) {
          r(null, B);
        });
      }
      return null;
    }, /** @preserve
       * jsPDF addImage plugin
       * Copyright (c) 2012 Jason Siefken, https://github.com/siefkenj/
       *               2013 Chris Dowling, https://github.com/gingerchris
       *               2013 Trinh Ho, https://github.com/ineedfat
       *               2013 Edwin Alejandro Perez, https://github.com/eaparango
       *               2013 Norah Smith, https://github.com/burnburnrocket
       *               2014 Diego Casorran, https://github.com/diegocr
       *               2014 James Robb, https://github.com/jamesbrobb
       *
       * 
       */
    function(o) {
      var p = "addImage_", C = { PNG: [[137, 80, 78, 71]], TIFF: [[77, 77, 0, 42], [73, 73, 42, 0]], JPEG: [[255, 216, 255, 224, void 0, void 0, 74, 70, 73, 70, 0], [255, 216, 255, 225, void 0, void 0, 69, 120, 105, 102, 0, 0]], JPEG2000: [[0, 0, 0, 12, 106, 80, 32, 32]], GIF87a: [[71, 73, 70, 56, 55, 97]], GIF89a: [[71, 73, 70, 56, 57, 97]], BMP: [[66, 77], [66, 65], [67, 73], [67, 80], [73, 67], [80, 84]] };
      o.getImageFileTypeByImageData = function(h, f) {
        var m, w;
        f = f || "UNKNOWN";
        var U, I, S, L = "UNKNOWN";
        for (S in C)
          for (U = C[S], m = 0; m < U.length; m += 1) {
            for (I = !0, w = 0; w < U[m].length; w += 1)
              if (U[m][w] !== void 0 && U[m][w] !== h.charCodeAt(w)) {
                I = !1;
                break;
              }
            if (I === !0) {
              L = S;
              break;
            }
          }
        return L === "UNKOWN" && f !== "UNKNOWN" && (console.warn('FileType of Image not recognized. Processing image as "' + f + '".'), L = f), L;
      };
      var i = function h(f) {
        var m = this.internal.newObject(), w = this.internal.write, U = this.internal.putStream;
        if (f.n = m, w("<</Type /XObject"), w("/Subtype /Image"), w("/Width " + f.w), w("/Height " + f.h), f.cs === this.color_spaces.INDEXED ? w("/ColorSpace [/Indexed /DeviceRGB " + (f.pal.length / 3 - 1) + " " + ("smask" in f ? m + 2 : m + 1) + " 0 R]") : (w("/ColorSpace /" + f.cs), f.cs === this.color_spaces.DEVICE_CMYK && w("/Decode [1 0 1 0 1 0 1 0]")), w("/BitsPerComponent " + f.bpc), "f" in f && w("/Filter /" + f.f), "dp" in f && w("/DecodeParms <<" + f.dp + ">>"), "trns" in f && f.trns.constructor == Array) {
          for (var I = "", S = 0, L = f.trns.length; S < L; S++)
            I += f.trns[S] + " " + f.trns[S] + " ";
          w("/Mask [" + I + "]");
        }
        if ("smask" in f && w("/SMask " + (m + 1) + " 0 R"), w("/Length " + f.data.length + ">>"), U(f.data), w("endobj"), "smask" in f) {
          var N = "/Predictor " + f.p + " /Colors 1 /BitsPerComponent " + f.bpc + " /Columns " + f.w, j = { w: f.w, h: f.h, cs: "DeviceGray", bpc: f.bpc, dp: N, data: f.smask };
          "f" in f && (j.f = f.f), h.call(this, j);
        }
        f.cs === this.color_spaces.INDEXED && (this.internal.newObject(), w("<< /Length " + f.pal.length + ">>"), U(this.arrayBufferToBinaryString(new Uint8Array(f.pal))), w("endobj"));
      }, r = function() {
        var h = this.internal.collections[p + "images"];
        for (var f in h)
          i.call(this, h[f]);
      }, n = function() {
        var h, f = this.internal.collections[p + "images"], m = this.internal.write;
        for (var w in f)
          m("/I" + (h = f[w]).i, h.n, "0", "R");
      }, s = function(h) {
        return typeof o["process" + h.toUpperCase()] == "function";
      }, c = function(h) {
        return (h === void 0 ? "undefined" : Ot(h)) === "object" && h.nodeType === 1;
      }, l = function(h, f) {
        if (h.nodeName === "IMG" && h.hasAttribute("src")) {
          var m = "" + h.getAttribute("src");
          if (m.indexOf("data:image/") === 0)
            return m;
          !f && /\.png(?:[?#].*)?$/i.test(m) && (f = "png");
        }
        if (h.nodeName === "CANVAS")
          var w = h;
        else {
          (w = document.createElement("canvas")).width = h.clientWidth || h.width, w.height = h.clientHeight || h.height;
          var U = w.getContext("2d");
          if (!U)
            throw "addImage requires canvas to be supported by browser.";
          U.drawImage(h, 0, 0, w.width, w.height);
        }
        return w.toDataURL(("" + f).toLowerCase() == "png" ? "image/png" : "image/jpeg");
      }, d = function(h, f) {
        var m;
        if (f) {
          for (var w in f)
            if (h === f[w].alias) {
              m = f[w];
              break;
            }
        }
        return m;
      };
      o.color_spaces = { DEVICE_RGB: "DeviceRGB", DEVICE_GRAY: "DeviceGray", DEVICE_CMYK: "DeviceCMYK", CAL_GREY: "CalGray", CAL_RGB: "CalRGB", LAB: "Lab", ICC_BASED: "ICCBased", INDEXED: "Indexed", PATTERN: "Pattern", SEPARATION: "Separation", DEVICE_N: "DeviceN" }, o.decode = { DCT_DECODE: "DCTDecode", FLATE_DECODE: "FlateDecode", LZW_DECODE: "LZWDecode", JPX_DECODE: "JPXDecode", JBIG2_DECODE: "JBIG2Decode", ASCII85_DECODE: "ASCII85Decode", ASCII_HEX_DECODE: "ASCIIHexDecode", RUN_LENGTH_DECODE: "RunLengthDecode", CCITT_FAX_DECODE: "CCITTFaxDecode" }, o.image_compression = { NONE: "NONE", FAST: "FAST", MEDIUM: "MEDIUM", SLOW: "SLOW" }, o.sHashCode = function(h) {
        return h = h || "", Array.prototype.reduce && h.split("").reduce(function(f, m) {
          return (f = (f << 5) - f + m.charCodeAt(0)) & f;
        }, 0);
      }, o.isString = function(h) {
        return typeof h == "string";
      }, o.validateStringAsBase64 = function(h) {
        var f = !0;
        return (h = h || "").length % 4 != 0 && (f = !1), /[A-Za-z0-9\/]+/.test(h.substr(0, h.length - 2)) === !1 && (f = !1), /[A-Za-z0-9\/][A-Za-z0-9+\/]|[A-Za-z0-9+\/]=|==/.test(h.substr(-2)) === !1 && (f = !1), f;
      }, o.extractInfoFromBase64DataURI = function(h) {
        return /^data:([\w]+?\/([\w]+?));base64,(.+)$/g.exec(h);
      }, o.supportsArrayBuffer = function() {
        return typeof ArrayBuffer < "u" && typeof Uint8Array < "u";
      }, o.isArrayBuffer = function(h) {
        return !!this.supportsArrayBuffer() && h instanceof ArrayBuffer;
      }, o.isArrayBufferView = function(h) {
        return !!this.supportsArrayBuffer() && typeof Uint32Array < "u" && (h instanceof Int8Array || h instanceof Uint8Array || typeof Uint8ClampedArray < "u" && h instanceof Uint8ClampedArray || h instanceof Int16Array || h instanceof Uint16Array || h instanceof Int32Array || h instanceof Uint32Array || h instanceof Float32Array || h instanceof Float64Array);
      }, o.binaryStringToUint8Array = function(h) {
        for (var f = h.length, m = new Uint8Array(f), w = 0; w < f; w++)
          m[w] = h.charCodeAt(w);
        return m;
      }, o.arrayBufferToBinaryString = function(h) {
        if (typeof atob == "function")
          return atob(this.arrayBufferToBase64(h));
        if (typeof TextDecoder == "function") {
          var f = new TextDecoder("ascii");
          if (f.encoding === "ascii")
            return f.decode(h);
        }
        for (var m = this.isArrayBuffer(h) ? h : new Uint8Array(h), w = 20480, U = "", I = Math.ceil(m.byteLength / w), S = 0; S < I; S++)
          U += String.fromCharCode.apply(null, m.slice(S * w, S * w + w));
        return U;
      }, o.arrayBufferToBase64 = function(h) {
        for (var f, m = "", w = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", U = new Uint8Array(h), I = U.byteLength, S = I % 3, L = I - S, N = 0; N < L; N += 3)
          m += w[(16515072 & (f = U[N] << 16 | U[N + 1] << 8 | U[N + 2])) >> 18] + w[(258048 & f) >> 12] + w[(4032 & f) >> 6] + w[63 & f];
        return S == 1 ? m += w[(252 & (f = U[L])) >> 2] + w[(3 & f) << 4] + "==" : S == 2 && (m += w[(64512 & (f = U[L] << 8 | U[L + 1])) >> 10] + w[(1008 & f) >> 4] + w[(15 & f) << 2] + "="), m;
      }, o.createImageInfo = function(h, f, m, w, U, I, S, L, N, j, Z, W, V) {
        var y = { alias: L, w: f, h: m, cs: w, bpc: U, i: S, data: h };
        return I && (y.f = I), N && (y.dp = N), j && (y.trns = j), Z && (y.pal = Z), W && (y.smask = W), V && (y.p = V), y;
      }, o.addImage = function(h, f, m, w, U, I, S, L, N) {
        var j = "";
        if (typeof f != "string") {
          var Z = I;
          I = U, U = w, w = m, m = f, f = Z;
        }
        if ((h === void 0 ? "undefined" : Ot(h)) === "object" && !c(h) && "imageData" in h) {
          var W = h;
          h = W.imageData, f = W.format || f, m = W.x || m || 0, w = W.y || w || 0, U = W.w || U, I = W.h || I, S = W.alias || S, L = W.compression || L, N = W.rotation || W.angle || N;
        }
        if (isNaN(m) || isNaN(w))
          throw console.error("jsPDF.addImage: Invalid coordinates", arguments), new Error("Invalid coordinates passed to jsPDF.addImage");
        var V, y, P, _, Y, $, hA, z = (function() {
          var k = this.internal.collections[p + "images"];
          return k || (this.internal.collections[p + "images"] = k = {}, this.internal.events.subscribe("putResources", r), this.internal.events.subscribe("putXobjectDict", n)), k;
        }).call(this);
        if (!(V = d(h, z)) && (c(h) && (h = l(h, f)), ((hA = S) == null || hA.length === 0) && (S = typeof ($ = h) == "string" && o.sHashCode($)), !(V = d(S, z)))) {
          if (this.isString(h) && ((j = this.convertStringToImageData(h)) !== "" || (j = this.loadImageFile(h)) !== void 0) && (h = j), f = this.getImageFileTypeByImageData(h, f), !s(f))
            throw new Error("addImage does not support files of type '" + f + "', please ensure that a plugin for '" + f + "' support is added.");
          if (this.supportsArrayBuffer() && (h instanceof Uint8Array || (y = h, h = this.binaryStringToUint8Array(h))), !(V = this["process" + f.toUpperCase()](h, (Y = 0, (_ = z) && (Y = Object.keys ? Object.keys(_).length : function(k) {
            var F = 0;
            for (var R in k)
              k.hasOwnProperty(R) && F++;
            return F;
          }(_)), Y), S, ((P = L) && typeof P == "string" && (P = P.toUpperCase()), P in o.image_compression ? P : o.image_compression.NONE), y)))
            throw new Error("An unkwown error occurred whilst processing the image");
        }
        return (function(k, F, R, E, G, M, oA, X) {
          var fA = (function(O, eA, sA) {
            return O || eA || (eA = O = -96), O < 0 && (O = -1 * sA.w * 72 / O / this.internal.scaleFactor), eA < 0 && (eA = -1 * sA.h * 72 / eA / this.internal.scaleFactor), O === 0 && (O = eA * sA.w / sA.h), eA === 0 && (eA = O * sA.h / sA.w), [O, eA];
          }).call(this, R, E, G), nA = this.internal.getCoordinateString, b = this.internal.getVerticalCoordinateString;
          if (R = fA[0], E = fA[1], oA[M] = G, X) {
            X *= Math.PI / 180;
            var D = Math.cos(X), u = Math.sin(X), Q = function(O) {
              return O.toFixed(4);
            }, H = [Q(D), Q(u), Q(-1 * u), Q(D), 0, 0, "cm"];
          }
          this.internal.write("q"), X ? (this.internal.write([1, "0", "0", 1, nA(k), b(F + E), "cm"].join(" ")), this.internal.write(H.join(" ")), this.internal.write([nA(R), "0", "0", nA(E), "0", "0", "cm"].join(" "))) : this.internal.write([nA(R), "0", "0", nA(E), nA(k), b(F + E), "cm"].join(" ")), this.internal.write("/I" + G.i + " Do"), this.internal.write("Q");
        }).call(this, m, w, U, I, V, V.i, z, N), this;
      }, o.convertStringToImageData = function(h) {
        var f, m = "";
        return this.isString(h) && ((f = this.extractInfoFromBase64DataURI(h)) !== null ? o.validateStringAsBase64(f[3]) && (m = atob(f[3])) : o.validateStringAsBase64(h) && (m = atob(h))), m;
      };
      var B = function(h, f) {
        return h.subarray(f, f + 5);
      };
      o.processJPEG = function(h, f, m, w, U, I) {
        var S, L = this.decode.DCT_DECODE;
        if (!this.isString(h) && !this.isArrayBuffer(h) && !this.isArrayBufferView(h))
          return null;
        if (this.isString(h) && (S = function(N) {
          var j;
          if (!N.charCodeAt(0) === 255 || !N.charCodeAt(1) === 216 || !N.charCodeAt(2) === 255 || !N.charCodeAt(3) === 224 || !N.charCodeAt(6) === "J".charCodeAt(0) || !N.charCodeAt(7) === "F".charCodeAt(0) || !N.charCodeAt(8) === "I".charCodeAt(0) || !N.charCodeAt(9) === "F".charCodeAt(0) || !N.charCodeAt(10) === 0)
            throw new Error("getJpegSize requires a binary string jpeg file");
          for (var Z = 256 * N.charCodeAt(4) + N.charCodeAt(5), W = 4, V = N.length; W < V; ) {
            if (W += Z, N.charCodeAt(W) !== 255)
              throw new Error("getJpegSize could not find the size of the image");
            if (N.charCodeAt(W + 1) === 192 || N.charCodeAt(W + 1) === 193 || N.charCodeAt(W + 1) === 194 || N.charCodeAt(W + 1) === 195 || N.charCodeAt(W + 1) === 196 || N.charCodeAt(W + 1) === 197 || N.charCodeAt(W + 1) === 198 || N.charCodeAt(W + 1) === 199)
              return j = 256 * N.charCodeAt(W + 5) + N.charCodeAt(W + 6), [256 * N.charCodeAt(W + 7) + N.charCodeAt(W + 8), j, N.charCodeAt(W + 9)];
            W += 2, Z = 256 * N.charCodeAt(W) + N.charCodeAt(W + 1);
          }
        }(h)), this.isArrayBuffer(h) && (h = new Uint8Array(h)), this.isArrayBufferView(h) && (S = function(N) {
          if ((N[0] << 8 | N[1]) != 65496)
            throw new Error("Supplied data is not a JPEG");
          for (var j, Z = N.length, W = (N[4] << 8) + N[5], V = 4; V < Z; ) {
            if (W = ((j = B(N, V += W))[2] << 8) + j[3], (j[1] === 192 || j[1] === 194) && j[0] === 255 && 7 < W)
              return { width: ((j = B(N, V + 5))[2] << 8) + j[3], height: (j[0] << 8) + j[1], numcomponents: j[4] };
            V += 2;
          }
          throw new Error("getJpegSizeFromBytes could not find the size of the image");
        }(h), h = U || this.arrayBufferToBinaryString(h)), I === void 0)
          switch (S.numcomponents) {
            case 1:
              I = this.color_spaces.DEVICE_GRAY;
              break;
            case 4:
              I = this.color_spaces.DEVICE_CMYK;
              break;
            default:
            case 3:
              I = this.color_spaces.DEVICE_RGB;
          }
        return this.createImageInfo(h, S.width, S.height, I, 8, L, f, m);
      }, o.processJPG = function() {
        return this.processJPEG.apply(this, arguments);
      }, o.loadImageFile = function(h, f, m) {
        if (f = f || !0, Object.prototype.toString.call(typeof process < "u" ? process : 0), (typeof window > "u" ? "undefined" : Ot(window)) !== void 0 && (typeof location > "u" ? "undefined" : Ot(location)) === "object" && location.protocol.substr(0, 4) === "http")
          return function(w, U, I) {
            var S = new XMLHttpRequest(), L = [], N = 0, j = function(Z) {
              var W = Z.length, V = String.fromCharCode;
              for (N = 0; N < W; N += 1)
                L.push(V(255 & Z.charCodeAt(N)));
              return L.join("");
            };
            if (S.open("GET", w, !U), S.overrideMimeType("text/plain; charset=x-user-defined"), U === !1 && (S.onload = function() {
              return j(this.responseText);
            }), S.send(null), S.status === 200)
              return U ? j(S.responseText) : void 0;
            console.warn('Unable to load file "' + w + '"');
          }(h, f);
      }, o.getImageProperties = function(h) {
        var f, m, w = "";
        if (c(h) && (h = l(h)), this.isString(h) && ((w = this.convertStringToImageData(h)) !== "" || (w = this.loadImageFile(h)) !== void 0) && (h = w), m = this.getImageFileTypeByImageData(h), !s(m))
          throw new Error("addImage does not support files of type '" + m + "', please ensure that a plugin for '" + m + "' support is added.");
        if (this.supportsArrayBuffer() && (h instanceof Uint8Array || (h = this.binaryStringToUint8Array(h))), !(f = this["process" + m.toUpperCase()](h)))
          throw new Error("An unkwown error occurred whilst processing the image");
        return { fileType: m, width: f.w, height: f.h, colorSpace: f.cs, compressionMode: f.f, bitsPerComponent: f.bpc };
      };
    }(Ct.API), /**
       * jsPDF Annotations PlugIn
       * Copyright (c) 2014 Steven Spungin (TwelveTone LLC)  steven@twelvetone.tv
       *
       * Licensed under the MIT License.
       * http://opensource.org/licenses/mit-license
       */
    uA = Ct.API, rA = { annotations: [], f2: function(o) {
      return o.toFixed(2);
    }, notEmpty: function(o) {
      if (o !== void 0 && o != "")
        return !0;
    } }, Ct.API.annotationPlugin = rA, Ct.API.events.push(["addPage", function(o) {
      this.annotationPlugin.annotations[o.pageNumber] = [];
    }]), uA.events.push(["putPage", function(o) {
      for (var p = this.annotationPlugin.annotations[o.pageNumber], C = !1, i = 0; i < p.length && !C; i++)
        switch ((l = p[i]).type) {
          case "link":
            if (rA.notEmpty(l.options.url) || rA.notEmpty(l.options.pageNumber)) {
              C = !0;
              break;
            }
          case "reference":
          case "text":
          case "freetext":
            C = !0;
        }
      if (C != 0) {
        this.internal.write("/Annots [");
        var r = this.annotationPlugin.f2, n = this.internal.scaleFactor, s = this.internal.pageSize.getHeight(), c = this.internal.getPageInfo(o.pageNumber);
        for (i = 0; i < p.length; i++) {
          var l;
          switch ((l = p[i]).type) {
            case "reference":
              this.internal.write(" " + l.object.objId + " 0 R ");
              break;
            case "text":
              var d = this.internal.newAdditionalObject(), B = this.internal.newAdditionalObject(), h = l.title || "Note";
              I = "<</Type /Annot /Subtype /Text " + (m = "/Rect [" + r(l.bounds.x * n) + " " + r(s - (l.bounds.y + l.bounds.h) * n) + " " + r((l.bounds.x + l.bounds.w) * n) + " " + r((s - l.bounds.y) * n) + "] ") + "/Contents (" + l.contents + ")", I += " /Popup " + B.objId + " 0 R", I += " /P " + c.objId + " 0 R", I += " /T (" + h + ") >>", d.content = I;
              var f = d.objId + " 0 R";
              I = "<</Type /Annot /Subtype /Popup " + (m = "/Rect [" + r((l.bounds.x + 30) * n) + " " + r(s - (l.bounds.y + l.bounds.h) * n) + " " + r((l.bounds.x + l.bounds.w + 30) * n) + " " + r((s - l.bounds.y) * n) + "] ") + " /Parent " + f, l.open && (I += " /Open true"), I += " >>", B.content = I, this.internal.write(d.objId, "0 R", B.objId, "0 R");
              break;
            case "freetext":
              var m = "/Rect [" + r(l.bounds.x * n) + " " + r((s - l.bounds.y) * n) + " " + r(l.bounds.x + l.bounds.w * n) + " " + r(s - (l.bounds.y + l.bounds.h) * n) + "] ", w = l.color || "#000000";
              I = "<</Type /Annot /Subtype /FreeText " + m + "/Contents (" + l.contents + ")", I += " /DS(font: Helvetica,sans-serif 12.0pt; text-align:left; color:#" + w + ")", I += " /Border [0 0 0]", I += " >>", this.internal.write(I);
              break;
            case "link":
              if (l.options.name) {
                var U = this.annotations._nameMap[l.options.name];
                l.options.pageNumber = U.page, l.options.top = U.y;
              } else
                l.options.top || (l.options.top = 0);
              m = "/Rect [" + r(l.x * n) + " " + r((s - l.y) * n) + " " + r((l.x + l.w) * n) + " " + r((s - (l.y + l.h)) * n) + "] ";
              var I = "";
              if (l.options.url)
                I = "<</Type /Annot /Subtype /Link " + m + "/Border [0 0 0] /A <</S /URI /URI (" + l.options.url + ") >>";
              else if (l.options.pageNumber)
                switch (I = "<</Type /Annot /Subtype /Link " + m + "/Border [0 0 0] /Dest [" + (o = this.internal.getPageInfo(l.options.pageNumber)).objId + " 0 R", l.options.magFactor = l.options.magFactor || "XYZ", l.options.magFactor) {
                  case "Fit":
                    I += " /Fit]";
                    break;
                  case "FitH":
                    I += " /FitH " + l.options.top + "]";
                    break;
                  case "FitV":
                    l.options.left = l.options.left || 0, I += " /FitV " + l.options.left + "]";
                    break;
                  case "XYZ":
                  default:
                    var S = r((s - l.options.top) * n);
                    l.options.left = l.options.left || 0, l.options.zoom === void 0 && (l.options.zoom = 0), I += " /XYZ " + l.options.left + " " + S + " " + l.options.zoom + "]";
                }
              I != "" && (I += " >>", this.internal.write(I));
          }
        }
        this.internal.write("]");
      }
    }]), uA.createAnnotation = function(o) {
      switch (o.type) {
        case "link":
          this.link(o.bounds.x, o.bounds.y, o.bounds.w, o.bounds.h, o);
          break;
        case "text":
        case "freetext":
          this.annotationPlugin.annotations[this.internal.getCurrentPageInfo().pageNumber].push(o);
      }
    }, uA.link = function(o, p, C, i, r) {
      this.annotationPlugin.annotations[this.internal.getCurrentPageInfo().pageNumber].push({ x: o, y: p, w: C, h: i, options: r, type: "link" });
    }, uA.textWithLink = function(o, p, C, i) {
      var r = this.getTextWidth(o), n = this.internal.getLineHeight() / this.internal.scaleFactor;
      return this.text(o, p, C), C += 0.2 * n, this.link(p, C - n, r, n, i), r;
    }, uA.getTextWidth = function(o) {
      var p = this.internal.getFontSize();
      return this.getStringUnitWidth(o) * p / this.internal.scaleFactor;
    }, uA.getLineHeight = function() {
      return this.internal.getLineHeight();
    }, function(o) {
      var p = Object.keys({ ar: "Arabic (Standard)", "ar-DZ": "Arabic (Algeria)", "ar-BH": "Arabic (Bahrain)", "ar-EG": "Arabic (Egypt)", "ar-IQ": "Arabic (Iraq)", "ar-JO": "Arabic (Jordan)", "ar-KW": "Arabic (Kuwait)", "ar-LB": "Arabic (Lebanon)", "ar-LY": "Arabic (Libya)", "ar-MA": "Arabic (Morocco)", "ar-OM": "Arabic (Oman)", "ar-QA": "Arabic (Qatar)", "ar-SA": "Arabic (Saudi Arabia)", "ar-SY": "Arabic (Syria)", "ar-TN": "Arabic (Tunisia)", "ar-AE": "Arabic (U.A.E.)", "ar-YE": "Arabic (Yemen)", fa: "Persian", "fa-IR": "Persian/Iran", ur: "Urdu" }), C = { 1569: [65152], 1570: [65153, 65154, 65153, 65154], 1571: [65155, 65156, 65155, 65156], 1572: [65157, 65158], 1573: [65159, 65160, 65159, 65160], 1574: [65161, 65162, 65163, 65164], 1575: [65165, 65166, 65165, 65166], 1576: [65167, 65168, 65169, 65170], 1577: [65171, 65172], 1578: [65173, 65174, 65175, 65176], 1579: [65177, 65178, 65179, 65180], 1580: [65181, 65182, 65183, 65184], 1581: [65185, 65186, 65187, 65188], 1582: [65189, 65190, 65191, 65192], 1583: [65193, 65194, 65193], 1584: [65195, 65196, 65195], 1585: [65197, 65198, 65197], 1586: [65199, 65200, 65199], 1587: [65201, 65202, 65203, 65204], 1588: [65205, 65206, 65207, 65208], 1589: [65209, 65210, 65211, 65212], 1590: [65213, 65214, 65215, 65216], 1591: [65217, 65218, 65219, 65220], 1592: [65221, 65222, 65223, 65224], 1593: [65225, 65226, 65227, 65228], 1594: [65229, 65230, 65231, 65232], 1601: [65233, 65234, 65235, 65236], 1602: [65237, 65238, 65239, 65240], 1603: [65241, 65242, 65243, 65244], 1604: [65245, 65246, 65247, 65248], 1605: [65249, 65250, 65251, 65252], 1606: [65253, 65254, 65255, 65256], 1607: [65257, 65258, 65259, 65260], 1608: [65261, 65262, 65261], 1609: [65263, 65264, 64488, 64489], 1610: [65265, 65266, 65267, 65268], 1649: [64336, 64337], 1655: [64477], 1657: [64358, 64359, 64360, 64361], 1658: [64350, 64351, 64352, 64353], 1659: [64338, 64339, 64340, 64341], 1662: [64342, 64343, 64344, 64345], 1663: [64354, 64355, 64356, 64357], 1664: [64346, 64347, 64348, 64349], 1667: [64374, 64375, 64376, 64377], 1668: [64370, 64371, 64372, 64373], 1670: [64378, 64379, 64380, 64381], 1671: [64382, 64383, 64384, 64385], 1672: [64392, 64393], 1676: [64388, 64389], 1677: [64386, 64387], 1678: [64390, 64391], 1681: [64396, 64397], 1688: [64394, 64395, 64394], 1700: [64362, 64363, 64364, 64365], 1702: [64366, 64367, 64368, 64369], 1705: [64398, 64399, 64400, 64401], 1709: [64467, 64468, 64469, 64470], 1711: [64402, 64403, 64404, 64405], 1713: [64410, 64411, 64412, 64413], 1715: [64406, 64407, 64408, 64409], 1722: [64414, 64415], 1723: [64416, 64417, 64418, 64419], 1726: [64426, 64427, 64428, 64429], 1728: [64420, 64421], 1729: [64422, 64423, 64424, 64425], 1733: [64480, 64481], 1734: [64473, 64474], 1735: [64471, 64472], 1736: [64475, 64476], 1737: [64482, 64483], 1739: [64478, 64479], 1740: [64508, 64509, 64510, 64511], 1744: [64484, 64485, 64486, 64487], 1746: [64430, 64431], 1747: [64432, 64433] }, i = { 1570: [65269, 65270, 65269, 65270], 1571: [65271, 65272, 65271, 65272], 1573: [65273, 65274, 65273, 65274], 1575: [65275, 65276, 65275, 65276] }, r = { 1570: [65153, 65154, 65153, 65154], 1571: [65155, 65156, 65155, 65156], 1573: [65159, 65160, 65159, 65160], 1575: [65165, 65166, 65165, 65166] }, n = { 1612: 64606, 1613: 64607, 1614: 64608, 1615: 64609, 1616: 64610 }, s = [1570, 1571, 1573, 1575], c = [1569, 1570, 1571, 1572, 1573, 1575, 1577, 1583, 1584, 1585, 1586, 1608, 1688], l = 0, d = 1, B = 2, h = 3;
      function f(L) {
        return L !== void 0 && C[L.charCodeAt(0)] !== void 0;
      }
      function m(L) {
        return L !== void 0 && 0 <= c.indexOf(L.charCodeAt(0));
      }
      function w(L) {
        return L !== void 0 && 0 <= s.indexOf(L.charCodeAt(0));
      }
      function U(L) {
        return f(L) && 2 <= C[L.charCodeAt(0)].length;
      }
      function I(L, N, j, Z) {
        return f(L) ? (Z = Z || {}, C = Object.assign(C, Z), !U(L) || !f(N) && !f(j) || !f(j) && m(N) || m(L) && !f(N) || m(L) && w(N) || m(L) && m(N) ? (C = Object.assign(C, r), l) : f(W = L) && C[W.charCodeAt(0)].length == 4 && f(N) && !m(N) && f(j) && U(j) ? (C = Object.assign(C, r), h) : m(L) || !f(j) ? (C = Object.assign(C, r), d) : (C = Object.assign(C, r), B)) : -1;
        var W;
      }
      var S = o.processArabic = function(L, N) {
        L = L || "", N = N || !1;
        var j, Z, W, V = "", y = 0, P = 0, _ = "", Y = "", $ = "";
        for (y = 0; y < L.length; y += 1)
          _ = L[y], Y = L[y - 1], $ = L[y + 1], f(_) ? Y !== void 0 && Y.charCodeAt(0) === 1604 && w(_) ? (P = I(_, L[y - 2], L[y + 1], i), j = String.fromCharCode(i[_.charCodeAt(0)][P]), V = V.substr(0, V.length - 1) + j) : Y !== void 0 && Y.charCodeAt(0) === 1617 && (Z = _) !== void 0 && n[Z.charCodeAt(0)] !== void 0 ? (P = I(_, L[y - 2], L[y + 1], r), j = String.fromCharCode(n[_.charCodeAt(0)][P]), V = V.substr(0, V.length - 1) + j) : (P = I(_, Y, $, r), V += String.fromCharCode(C[_.charCodeAt(0)][P])) : V += N ? { "(": ")", ")": "(" }[W = _] || W : _;
        return N ? V.split("").reverse().join("") : V;
      };
      o.events.push(["preProcessText", function(L) {
        var N = L.text, j = (L.x, L.y, L.options || {}), Z = (L.mutex, j.lang), W = [];
        if (0 <= p.indexOf(Z)) {
          if (Object.prototype.toString.call(N) === "[object Array]") {
            var V = 0;
            for (W = [], V = 0; V < N.length; V += 1)
              Object.prototype.toString.call(N[V]) === "[object Array]" ? W.push([S(N[V][0], !0), N[V][1], N[V][2]]) : W.push([S(N[V], !0)]);
            L.text = W;
          } else
            L.text = S(N, !0);
          j.charSpace === void 0 && (L.options.charSpace = 0), j.R2L === !0 && (L.options.R2L = !1);
        }
      }]);
    }(Ct.API), Ct.API.autoPrint = function(o) {
      var p;
      switch ((o = o || {}).variant = o.variant || "non-conform", o.variant) {
        case "javascript":
          this.addJS("print({});");
          break;
        case "non-conform":
        default:
          this.internal.events.subscribe("postPutResources", function() {
            p = this.internal.newObject(), this.internal.out("<<"), this.internal.out("/S /Named"), this.internal.out("/Type /Action"), this.internal.out("/N /Print"), this.internal.out(">>"), this.internal.out("endobj");
          }), this.internal.events.subscribe("putCatalog", function() {
            this.internal.out("/OpenAction " + p + " 0 R");
          });
      }
      return this;
    }, /**
       * jsPDF Canvas PlugIn
       * Copyright (c) 2014 Steven Spungin (TwelveTone LLC)  steven@twelvetone.tv
       *
       * Licensed under the MIT License.
       * http://opensource.org/licenses/mit-license
       */
    (vA = Ct.API).events.push(["initialized", function() {
      this.canvas.pdf = this;
    }]), vA.canvas = { getContext: function(o) {
      return (this.pdf.context2d._canvas = this).pdf.context2d;
    }, childNodes: [] }, Object.defineProperty(vA.canvas, "width", { get: function() {
      return this._width;
    }, set: function(o) {
      this._width = o, this.getContext("2d").pageWrapX = o + 1;
    } }), Object.defineProperty(vA.canvas, "height", { get: function() {
      return this._height;
    }, set: function(o) {
      this._height = o, this.getContext("2d").pageWrapY = o + 1;
    } }), /** ====================================================================
       * jsPDF Cell plugin
       * Copyright (c) 2013 Youssef Beddad, youssef.beddad@gmail.com
       *               2013 Eduardo Menezes de Morais, eduardo.morais@usp.br
       *               2013 Lee Driscoll, https://github.com/lsdriscoll
       *               2014 Juan Pablo Gaviria, https://github.com/juanpgaviria
       *               2014 James Hall, james@parall.ax
       *               2014 Diego Casorran, https://github.com/diegocr
       *
       * 
       * ====================================================================
       */
    LA = Ct.API, pt = { x: void 0, y: void 0, w: void 0, h: void 0, ln: void 0 }, at = 1, YA = function(o, p, C, i, r) {
      pt = { x: o, y: p, w: C, h: i, ln: r };
    }, Ht = function() {
      return pt;
    }, $t = { left: 0, top: 0, bottom: 0 }, LA.setHeaderFunction = function(o) {
      At = o;
    }, LA.getTextDimensions = function(o) {
      kA = this.internal.getFont().fontName, ZA = this.table_font_size || this.internal.getFontSize(), XA = this.internal.getFont().fontStyle;
      var p, C, i = 19.049976 / 25.4;
      (C = document.createElement("font")).id = "jsPDFCell";
      try {
        C.style.fontStyle = XA;
      } catch {
        C.style.fontWeight = XA;
      }
      C.style.fontSize = ZA + "pt", C.style.fontFamily = kA;
      try {
        C.textContent = o;
      } catch {
        C.innerText = o;
      }
      return document.body.appendChild(C), p = { w: (C.offsetWidth + 1) * i, h: (C.offsetHeight + 1) * i }, document.body.removeChild(C), p;
    }, LA.cellAddPage = function() {
      var o = this.margins || $t;
      this.addPage(), YA(o.left, o.top, void 0, void 0), at += 1;
    }, LA.cellInitialize = function() {
      pt = { x: void 0, y: void 0, w: void 0, h: void 0, ln: void 0 }, at = 1;
    }, LA.cell = function(o, p, C, i, r, n, s) {
      var c = Ht(), l = !1;
      if (c.ln !== void 0)
        if (c.ln === n)
          o = c.x + c.w, p = c.y;
        else {
          var d = this.margins || $t;
          c.y + c.h + i + 13 >= this.internal.pageSize.getHeight() - d.bottom && (this.cellAddPage(), l = !0, this.printHeaders && this.tableHeaderRow && this.printHeaderRow(n, !0)), p = Ht().y + Ht().h, l && (p = 23);
        }
      if (r[0] !== void 0)
        if (this.printingHeaderRow ? this.rect(o, p, C, i, "FD") : this.rect(o, p, C, i), s === "right") {
          r instanceof Array || (r = [r]);
          for (var B = 0; B < r.length; B++) {
            var h = r[B], f = this.getStringUnitWidth(h) * this.internal.getFontSize();
            this.text(h, o + C - f - 3, p + this.internal.getLineHeight() * (B + 1));
          }
        } else
          this.text(r, o + 3, p + this.internal.getLineHeight());
      return YA(o, p, C, i, n), this;
    }, LA.arrayMax = function(o, p) {
      var C, i, r, n = o[0];
      for (C = 0, i = o.length; C < i; C += 1)
        r = o[C], p ? p(n, r) === -1 && (n = r) : n < r && (n = r);
      return n;
    }, LA.table = function(o, p, C, i, r) {
      if (!C)
        throw "No data for PDF table";
      var n, s, c, l, d, B, h, f, m, w, U = [], I = [], S = {}, L = {}, N = [], j = [], Z = !1, W = !0, V = 12, y = $t;
      if (y.width = this.internal.pageSize.getWidth(), r && (r.autoSize === !0 && (Z = !0), r.printHeaders === !1 && (W = !1), r.fontSize && (V = r.fontSize), r.css && r.css["font-size"] !== void 0 && (V = 16 * r.css["font-size"]), r.margins && (y = r.margins)), this.lnMod = 0, pt = { x: void 0, y: void 0, w: void 0, h: void 0, ln: void 0 }, at = 1, this.printHeaders = W, this.margins = y, this.setFontSize(V), this.table_font_size = V, i == null)
        U = Object.keys(C[0]);
      else if (i[0] && typeof i[0] != "string")
        for (s = 0, c = i.length; s < c; s += 1)
          n = i[s], U.push(n.name), I.push(n.prompt), L[n.name] = n.width * (19.049976 / 25.4);
      else
        U = i;
      if (Z)
        for (w = function(_) {
          return _[n];
        }, s = 0, c = U.length; s < c; s += 1) {
          for (S[n = U[s]] = C.map(w), N.push(this.getTextDimensions(I[s] || n).w), h = 0, l = (B = S[n]).length; h < l; h += 1)
            d = B[h], N.push(this.getTextDimensions(d).w);
          L[n] = LA.arrayMax(N), N = [];
        }
      if (W) {
        var P = this.calculateLineHeight(U, L, I.length ? I : U);
        for (s = 0, c = U.length; s < c; s += 1)
          n = U[s], j.push([o, p, L[n], P, String(I.length ? I[s] : n)]);
        this.setTableHeaderRow(j), this.printHeaderRow(1, !1);
      }
      for (s = 0, c = C.length; s < c; s += 1)
        for (f = C[s], P = this.calculateLineHeight(U, L, f), h = 0, m = U.length; h < m; h += 1)
          n = U[h], this.cell(o, p, L[n], P, f[n], s + 2, n.align);
      return this.lastCellPos = pt, this.table_x = o, this.table_y = p, this;
    }, LA.calculateLineHeight = function(o, p, C) {
      for (var i, r = 0, n = 0; n < o.length; n++) {
        C[i = o[n]] = this.splitTextToSize(String(C[i]), p[i] - 3);
        var s = this.internal.getLineHeight() * C[i].length + 3;
        r < s && (r = s);
      }
      return r;
    }, LA.setTableHeaderRow = function(o) {
      this.tableHeaderRow = o;
    }, LA.printHeaderRow = function(o, p) {
      if (!this.tableHeaderRow)
        throw "Property tableHeaderRow does not exist.";
      var C, i, r, n;
      if (this.printingHeaderRow = !0, At !== void 0) {
        var s = At(this, at);
        YA(s[0], s[1], s[2], s[3], -1);
      }
      this.setFontStyle("bold");
      var c = [];
      for (r = 0, n = this.tableHeaderRow.length; r < n; r += 1)
        this.setFillColor(200, 200, 200), C = this.tableHeaderRow[r], p && (this.margins.top = 13, C[1] = this.margins && this.margins.top || 0, c.push(C)), i = [].concat(C), this.cell.apply(this, i.concat(o));
      0 < c.length && this.setTableHeaderRow(c), this.setFontStyle("normal"), this.printingHeaderRow = !1;
    }, /**
       * jsPDF Context2D PlugIn Copyright (c) 2014 Steven Spungin (TwelveTone LLC) steven@twelvetone.tv
       *
       * Licensed under the MIT License. http://opensource.org/licenses/mit-license
       */
    function(o) {
      o.events.push(["initialized", function() {
        ((this.context2d.pdf = this).context2d.internal.pdf = this).context2d.ctx = new C(), this.context2d.ctxStack = [], this.context2d.path = [];
      }]), o.context2d = { pageWrapXEnabled: !1, pageWrapYEnabled: !1, pageWrapX: 9999999, pageWrapY: 9999999, ctx: new C(), f2: function(i) {
        return i.toFixed(2);
      }, fillRect: function(i, r, n, s) {
        if (!this._isFillTransparent()) {
          i = this._wrapX(i), r = this._wrapY(r);
          var c = this._matrix_map_rect(this.ctx._transform, { x: i, y: r, w: n, h: s });
          this.pdf.rect(c.x, c.y, c.w, c.h, "f");
        }
      }, strokeRect: function(i, r, n, s) {
        if (!this._isStrokeTransparent()) {
          i = this._wrapX(i), r = this._wrapY(r);
          var c = this._matrix_map_rect(this.ctx._transform, { x: i, y: r, w: n, h: s });
          this.pdf.rect(c.x, c.y, c.w, c.h, "s");
        }
      }, clearRect: function(i, r, n, s) {
        if (!this.ctx.ignoreClearRect) {
          i = this._wrapX(i), r = this._wrapY(r);
          var c = this._matrix_map_rect(this.ctx._transform, { x: i, y: r, w: n, h: s });
          this.save(), this.setFillStyle("#ffffff"), this.pdf.rect(c.x, c.y, c.w, c.h, "f"), this.restore();
        }
      }, save: function() {
        this.ctx._fontSize = this.pdf.internal.getFontSize();
        var i = new C();
        i.copy(this.ctx), this.ctxStack.push(this.ctx), this.ctx = i;
      }, restore: function() {
        this.ctx = this.ctxStack.pop(), this.setFillStyle(this.ctx.fillStyle), this.setStrokeStyle(this.ctx.strokeStyle), this.setFont(this.ctx.font), this.pdf.setFontSize(this.ctx._fontSize), this.setLineCap(this.ctx.lineCap), this.setLineWidth(this.ctx.lineWidth), this.setLineJoin(this.ctx.lineJoin);
      }, rect: function(i, r, n, s) {
        this.moveTo(i, r), this.lineTo(i + n, r), this.lineTo(i + n, r + s), this.lineTo(i, r + s), this.lineTo(i, r), this.closePath();
      }, beginPath: function() {
        this.path = [];
      }, closePath: function() {
        this.path.push({ type: "close" });
      }, _getRGBA: function(i) {
        var r, n, s, c, l = new RGBColor(i);
        if (!i)
          return { r: 0, g: 0, b: 0, a: 0, style: i };
        if (this.internal.rxTransparent.test(i))
          c = s = n = r = 0;
        else {
          var d = this.internal.rxRgb.exec(i);
          d != null ? (r = parseInt(d[1]), n = parseInt(d[2]), s = parseInt(d[3]), c = 1) : (d = this.internal.rxRgba.exec(i)) != null ? (r = parseInt(d[1]), n = parseInt(d[2]), s = parseInt(d[3]), c = parseFloat(d[4])) : (c = 1, i.charAt(0) != "#" && (i = l.ok ? l.toHex() : "#000000"), i.length === 4 ? (r = i.substring(1, 2), r += r, n = i.substring(2, 3), n += n, s = i.substring(3, 4), s += s) : (r = i.substring(1, 3), n = i.substring(3, 5), s = i.substring(5, 7)), r = parseInt(r, 16), n = parseInt(n, 16), s = parseInt(s, 16));
        }
        return { r, g: n, b: s, a: c, style: i };
      }, setFillStyle: function(i) {
        var r = this._getRGBA(i);
        this.ctx.fillStyle = i, this.ctx._isFillTransparent = r.a === 0, this.ctx._fillOpacity = r.a, this.pdf.setFillColor(r.r, r.g, r.b, { a: r.a }), this.pdf.setTextColor(r.r, r.g, r.b, { a: r.a });
      }, setStrokeStyle: function(i) {
        var r = this._getRGBA(i);
        this.ctx.strokeStyle = r.style, this.ctx._isStrokeTransparent = r.a === 0, this.ctx._strokeOpacity = r.a, r.a === 0 ? this.pdf.setDrawColor(255, 255, 255) : (r.a, this.pdf.setDrawColor(r.r, r.g, r.b));
      }, fillText: function(i, r, n, s) {
        if (!this._isFillTransparent()) {
          r = this._wrapX(r), n = this._wrapY(n);
          var c = this._matrix_map_point(this.ctx._transform, [r, n]);
          r = c[0], n = c[1];
          var l = 57.2958 * this._matrix_rotation(this.ctx._transform);
          if (0 < this.ctx._clip_path.length) {
            var d;
            (d = window.outIntercept ? window.outIntercept.type === "group" ? window.outIntercept.stream : window.outIntercept : this.internal.getCurrentPage()).push("q");
            var B = this.path;
            this.path = this.ctx._clip_path, this.ctx._clip_path = [], this._fill(null, !0), this.ctx._clip_path = this.path, this.path = B;
          }
          var h = 1;
          try {
            h = this._matrix_decompose(this._getTransform()).scale[0];
          } catch (m) {
            console.warn(m);
          }
          if (h < 0.01)
            this.pdf.text(i, r, this._getBaseline(n), null, l);
          else {
            var f = this.pdf.internal.getFontSize();
            this.pdf.setFontSize(f * h), this.pdf.text(i, r, this._getBaseline(n), null, l), this.pdf.setFontSize(f);
          }
          0 < this.ctx._clip_path.length && d.push("Q");
        }
      }, strokeText: function(i, r, n, s) {
        if (!this._isStrokeTransparent()) {
          r = this._wrapX(r), n = this._wrapY(n);
          var c = this._matrix_map_point(this.ctx._transform, [r, n]);
          r = c[0], n = c[1];
          var l = 57.2958 * this._matrix_rotation(this.ctx._transform);
          if (0 < this.ctx._clip_path.length) {
            var d;
            (d = window.outIntercept ? window.outIntercept.type === "group" ? window.outIntercept.stream : window.outIntercept : this.internal.getCurrentPage()).push("q");
            var B = this.path;
            this.path = this.ctx._clip_path, this.ctx._clip_path = [], this._fill(null, !0), this.ctx._clip_path = this.path, this.path = B;
          }
          var h = 1;
          try {
            h = this._matrix_decompose(this._getTransform()).scale[0];
          } catch (m) {
            console.warn(m);
          }
          if (h === 1)
            this.pdf.text(i, r, this._getBaseline(n), { stroke: !0 }, l);
          else {
            var f = this.pdf.internal.getFontSize();
            this.pdf.setFontSize(f * h), this.pdf.text(i, r, this._getBaseline(n), { stroke: !0 }, l), this.pdf.setFontSize(f);
          }
          0 < this.ctx._clip_path.length && d.push("Q");
        }
      }, setFont: function(i) {
        if (this.ctx.font = i, (f = /\s*(\w+)\s+(\w+)\s+(\w+)\s+([\d\.]+)(px|pt|em)\s+(.*)?/.exec(i)) != null) {
          var r = f[1], n = (f[2], f[3]), s = f[4], c = f[5], l = f[6];
          s = Math.floor(c === "px" ? parseFloat(s) : c === "em" ? parseFloat(s) * this.pdf.getFontSize() : parseFloat(s)), this.pdf.setFontSize(s), n === "bold" || n === "700" ? this.pdf.setFontStyle("bold") : r === "italic" ? this.pdf.setFontStyle("italic") : this.pdf.setFontStyle("normal"), m = n === "bold" || n === "700" ? r === "italic" ? "bolditalic" : "bold" : r === "italic" ? "italic" : "normal";
          for (var d = l.toLowerCase().split(/\s*,\s*/), B = "Times", h = 0; h < d.length; h++) {
            if (this.pdf.internal.getFont(d[h], m, { noFallback: !0, disableWarning: !0 }) !== void 0) {
              B = d[h];
              break;
            }
            if (m === "bolditalic" && this.pdf.internal.getFont(d[h], "bold", { noFallback: !0, disableWarning: !0 }) !== void 0)
              B = d[h], m = "bold";
            else if (this.pdf.internal.getFont(d[h], "normal", { noFallback: !0, disableWarning: !0 }) !== void 0) {
              B = d[h], m = "normal";
              break;
            }
          }
          this.pdf.setFont(B, m);
        } else {
          var f = /\s*(\d+)(pt|px|em)\s+([\w "]+)\s*([\w "]+)?/.exec(i);
          if (f != null) {
            var m, w = f[1], U = (f[2], f[3]);
            (m = f[4]) || (m = "normal"), w = Math.floor(c === "em" ? parseFloat(s) * this.pdf.getFontSize() : parseFloat(w)), this.pdf.setFontSize(w), this.pdf.setFont(U, m);
          }
        }
      }, setTextBaseline: function(i) {
        this.ctx.textBaseline = i;
      }, getTextBaseline: function() {
        return this.ctx.textBaseline;
      }, setTextAlign: function(i) {
        this.ctx.textAlign = i;
      }, getTextAlign: function() {
        return this.ctx.textAlign;
      }, setLineWidth: function(i) {
        this.ctx.lineWidth = i, this.pdf.setLineWidth(i);
      }, setLineCap: function(i) {
        this.ctx.lineCap = i, this.pdf.setLineCap(i);
      }, setLineJoin: function(i) {
        this.ctx.lineJoin = i, this.pdf.setLineJoin(i);
      }, moveTo: function(i, r) {
        i = this._wrapX(i), r = this._wrapY(r);
        var n = this._matrix_map_point(this.ctx._transform, [i, r]), s = { type: "mt", x: i = n[0], y: r = n[1] };
        this.path.push(s);
      }, _wrapX: function(i) {
        return this.pageWrapXEnabled ? i % this.pageWrapX : i;
      }, _wrapY: function(i) {
        return this.pageWrapYEnabled ? (this._gotoPage(this._page(i)), (i - this.lastBreak) % this.pageWrapY) : i;
      }, transform: function(i, r, n, s, c, l) {
        this.ctx._transform = this._matrix_multiply(this.ctx._transform, [i, r, n, s, c, l]);
      }, setTransform: function(i, r, n, s, c, l) {
        this.ctx._transform = [i, r, n, s, c, l];
      }, _getTransform: function() {
        return this.ctx._transform;
      }, lastBreak: 0, pageBreaks: [], _page: function(i) {
        if (this.pageWrapYEnabled) {
          for (var r = this.lastBreak = 0, n = 0, s = 0; s < this.pageBreaks.length; s++)
            if (i >= this.pageBreaks[s]) {
              r++, this.lastBreak === 0 && n++;
              var c = this.pageBreaks[s] - this.lastBreak;
              this.lastBreak = this.pageBreaks[s], n += Math.floor(c / this.pageWrapY);
            }
          return this.lastBreak === 0 && (n += Math.floor(i / this.pageWrapY) + 1), n + r;
        }
        return this.pdf.internal.getCurrentPageInfo().pageNumber;
      }, _gotoPage: function(i) {
      }, lineTo: function(i, r) {
        i = this._wrapX(i), r = this._wrapY(r);
        var n = this._matrix_map_point(this.ctx._transform, [i, r]), s = { type: "lt", x: i = n[0], y: r = n[1] };
        this.path.push(s);
      }, bezierCurveTo: function(i, r, n, s, c, l) {
        var d;
        i = this._wrapX(i), r = this._wrapY(r), n = this._wrapX(n), s = this._wrapY(s), c = this._wrapX(c), l = this._wrapY(l), c = (d = this._matrix_map_point(this.ctx._transform, [c, l]))[0], l = d[1];
        var B = { type: "bct", x1: i = (d = this._matrix_map_point(this.ctx._transform, [i, r]))[0], y1: r = d[1], x2: n = (d = this._matrix_map_point(this.ctx._transform, [n, s]))[0], y2: s = d[1], x: c, y: l };
        this.path.push(B);
      }, quadraticCurveTo: function(i, r, n, s) {
        var c;
        i = this._wrapX(i), r = this._wrapY(r), n = this._wrapX(n), s = this._wrapY(s), n = (c = this._matrix_map_point(this.ctx._transform, [n, s]))[0], s = c[1];
        var l = { type: "qct", x1: i = (c = this._matrix_map_point(this.ctx._transform, [i, r]))[0], y1: r = c[1], x: n, y: s };
        this.path.push(l);
      }, arc: function(i, r, n, s, c, l) {
        if (i = this._wrapX(i), r = this._wrapY(r), !this._matrix_is_identity(this.ctx._transform)) {
          var d = this._matrix_map_point(this.ctx._transform, [i, r]);
          i = d[0], r = d[1];
          var B = this._matrix_map_point(this.ctx._transform, [0, 0]), h = this._matrix_map_point(this.ctx._transform, [0, n]);
          n = Math.sqrt(Math.pow(h[0] - B[0], 2) + Math.pow(h[1] - B[1], 2));
        }
        var f = { type: "arc", x: i, y: r, radius: n, startAngle: s, endAngle: c, anticlockwise: l };
        this.path.push(f);
      }, drawImage: function(i, r, n, s, c, l, d, B, h) {
        l !== void 0 && (r = l, n = d, s = B, c = h), r = this._wrapX(r), n = this._wrapY(n);
        var f, m = this._matrix_map_rect(this.ctx._transform, { x: r, y: n, w: s, h: c }), w = (this._matrix_map_rect(this.ctx._transform, { x: l, y: d, w: B, h }), /data:image\/(\w+).*/i.exec(i));
        f = w != null ? w[1] : "png", this.pdf.addImage(i, f, m.x, m.y, m.w, m.h);
      }, _matrix_multiply: function(i, r) {
        var n = r[0], s = r[1], c = r[2], l = r[3], d = r[4], B = r[5], h = n * i[0] + s * i[2], f = c * i[0] + l * i[2], m = d * i[0] + B * i[2] + i[4];
        return s = n * i[1] + s * i[3], l = c * i[1] + l * i[3], B = d * i[1] + B * i[3] + i[5], [n = h, s, c = f, l, d = m, B];
      }, _matrix_rotation: function(i) {
        return Math.atan2(i[2], i[0]);
      }, _matrix_decompose: function(i) {
        var r = i[0], n = i[1], s = i[2], c = i[3], l = Math.sqrt(r * r + n * n), d = (r /= l) * s + (n /= l) * c;
        s -= r * d, c -= n * d;
        var B = Math.sqrt(s * s + c * c);
        return d /= B, r * (c /= B) < n * (s /= B) && (r = -r, n = -n, d = -d, l = -l), { scale: [l, 0, 0, B, 0, 0], translate: [1, 0, 0, 1, i[4], i[5]], rotate: [r, n, -n, r, 0, 0], skew: [1, 0, d, 1, 0, 0] };
      }, _matrix_map_point: function(i, r) {
        var n = i[0], s = i[1], c = i[2], l = i[3], d = i[4], B = i[5], h = r[0], f = r[1];
        return [h * n + f * c + d, h * s + f * l + B];
      }, _matrix_map_point_obj: function(i, r) {
        var n = this._matrix_map_point(i, [r.x, r.y]);
        return { x: n[0], y: n[1] };
      }, _matrix_map_rect: function(i, r) {
        var n = this._matrix_map_point(i, [r.x, r.y]), s = this._matrix_map_point(i, [r.x + r.w, r.y + r.h]);
        return { x: n[0], y: n[1], w: s[0] - n[0], h: s[1] - n[1] };
      }, _matrix_is_identity: function(i) {
        return i[0] == 1 && i[1] == 0 && i[2] == 0 && i[3] == 1 && i[4] == 0 && i[5] == 0;
      }, rotate: function(i) {
        var r = [Math.cos(i), Math.sin(i), -Math.sin(i), Math.cos(i), 0, 0];
        this.ctx._transform = this._matrix_multiply(this.ctx._transform, r);
      }, scale: function(i, r) {
        var n = [i, 0, 0, r, 0, 0];
        this.ctx._transform = this._matrix_multiply(this.ctx._transform, n);
      }, translate: function(i, r) {
        var n = [1, 0, 0, 1, i, r];
        this.ctx._transform = this._matrix_multiply(this.ctx._transform, n);
      }, stroke: function() {
        if (0 < this.ctx._clip_path.length) {
          var i;
          (i = window.outIntercept ? window.outIntercept.type === "group" ? window.outIntercept.stream : window.outIntercept : this.internal.getCurrentPage()).push("q");
          var r = this.path;
          this.path = this.ctx._clip_path, this.ctx._clip_path = [], this._stroke(!0), this.ctx._clip_path = this.path, this.path = r, this._stroke(!1), i.push("Q");
        } else
          this._stroke(!1);
      }, _stroke: function(i) {
        if (i || !this._isStrokeTransparent()) {
          for (var r = [], n = this.path, s = 0; s < n.length; s++) {
            var c = n[s];
            switch (c.type) {
              case "mt":
                r.push({ start: c, deltas: [], abs: [] });
                break;
              case "lt":
                var l = [c.x - n[s - 1].x, c.y - n[s - 1].y];
                r[r.length - 1].deltas.push(l), r[r.length - 1].abs.push(c);
                break;
              case "bct":
                l = [c.x1 - n[s - 1].x, c.y1 - n[s - 1].y, c.x2 - n[s - 1].x, c.y2 - n[s - 1].y, c.x - n[s - 1].x, c.y - n[s - 1].y], r[r.length - 1].deltas.push(l);
                break;
              case "qct":
                var d = n[s - 1].x + 2 / 3 * (c.x1 - n[s - 1].x), B = n[s - 1].y + 2 / 3 * (c.y1 - n[s - 1].y), h = c.x + 2 / 3 * (c.x1 - c.x), f = c.y + 2 / 3 * (c.y1 - c.y), m = c.x, w = c.y;
                l = [d - n[s - 1].x, B - n[s - 1].y, h - n[s - 1].x, f - n[s - 1].y, m - n[s - 1].x, w - n[s - 1].y], r[r.length - 1].deltas.push(l);
                break;
              case "arc":
                r.length == 0 && r.push({ start: { x: 0, y: 0 }, deltas: [], abs: [] }), r[r.length - 1].arc = !0, Array.isArray(r[r.length - 1].abs) && r[r.length - 1].abs.push(c);
            }
          }
          for (s = 0; s < r.length; s++) {
            var U;
            if (U = s == r.length - 1 ? "s" : null, r[s].arc)
              for (var I = r[s].abs, S = 0; S < I.length; S++) {
                var L = I[S], N = 360 * L.startAngle / (2 * Math.PI), j = 360 * L.endAngle / (2 * Math.PI), Z = L.x, W = L.y;
                this.internal.arc2(this, Z, W, L.radius, N, j, L.anticlockwise, U, i);
              }
            else
              Z = r[s].start.x, W = r[s].start.y, i ? (this.pdf.lines(r[s].deltas, Z, W, null, null), this.pdf.clip_fixed()) : this.pdf.lines(r[s].deltas, Z, W, null, U);
          }
        }
      }, _isFillTransparent: function() {
        return this.ctx._isFillTransparent || this.globalAlpha == 0;
      }, _isStrokeTransparent: function() {
        return this.ctx._isStrokeTransparent || this.globalAlpha == 0;
      }, fill: function(i) {
        if (0 < this.ctx._clip_path.length) {
          var r;
          (r = window.outIntercept ? window.outIntercept.type === "group" ? window.outIntercept.stream : window.outIntercept : this.internal.getCurrentPage()).push("q");
          var n = this.path;
          this.path = this.ctx._clip_path, this.ctx._clip_path = [], this._fill(i, !0), this.ctx._clip_path = this.path, this.path = n, this._fill(i, !1), r.push("Q");
        } else
          this._fill(i, !1);
      }, _fill: function(i, r) {
        if (!this._isFillTransparent()) {
          var n, s = typeof this.pdf.internal.newObject2 == "function";
          n = window.outIntercept ? window.outIntercept.type === "group" ? window.outIntercept.stream : window.outIntercept : this.internal.getCurrentPage();
          var c = [], l = window.outIntercept;
          if (s)
            switch (this.ctx.globalCompositeOperation) {
              case "normal":
              case "source-over":
                break;
              case "destination-in":
              case "destination-out":
                var d = this.pdf.internal.newStreamObject(), B = this.pdf.internal.newObject2();
                B.push("<</Type /ExtGState"), B.push("/SMask <</S /Alpha /G " + d.objId + " 0 R>>"), B.push(">>");
                var h = "MASK" + B.objId;
                this.pdf.internal.addGraphicsState(h, B.objId);
                var f = "/" + h + " gs";
                n.splice(0, 0, "q"), n.splice(1, 0, f), n.push("Q"), window.outIntercept = d;
                break;
              default:
                var m = "/" + this.pdf.internal.blendModeMap[this.ctx.globalCompositeOperation.toUpperCase()];
                m && this.pdf.internal.out(m + " gs");
            }
          var w = this.ctx.globalAlpha;
          if (this.ctx._fillOpacity < 1 && (w = this.ctx._fillOpacity), s) {
            var U = this.pdf.internal.newObject2();
            U.push("<</Type /ExtGState"), U.push("/CA " + w), U.push("/ca " + w), U.push(">>"), h = "GS_O_" + U.objId, this.pdf.internal.addGraphicsState(h, U.objId), this.pdf.internal.out("/" + h + " gs");
          }
          for (var I = this.path, S = 0; S < I.length; S++) {
            var L = I[S];
            switch (L.type) {
              case "mt":
                c.push({ start: L, deltas: [], abs: [] });
                break;
              case "lt":
                var N = [L.x - I[S - 1].x, L.y - I[S - 1].y];
                c[c.length - 1].deltas.push(N), c[c.length - 1].abs.push(L);
                break;
              case "bct":
                N = [L.x1 - I[S - 1].x, L.y1 - I[S - 1].y, L.x2 - I[S - 1].x, L.y2 - I[S - 1].y, L.x - I[S - 1].x, L.y - I[S - 1].y], c[c.length - 1].deltas.push(N);
                break;
              case "qct":
                var j = I[S - 1].x + 2 / 3 * (L.x1 - I[S - 1].x), Z = I[S - 1].y + 2 / 3 * (L.y1 - I[S - 1].y), W = L.x + 2 / 3 * (L.x1 - L.x), V = L.y + 2 / 3 * (L.y1 - L.y), y = L.x, P = L.y;
                N = [j - I[S - 1].x, Z - I[S - 1].y, W - I[S - 1].x, V - I[S - 1].y, y - I[S - 1].x, P - I[S - 1].y], c[c.length - 1].deltas.push(N);
                break;
              case "arc":
                c.length === 0 && c.push({ deltas: [], abs: [] }), c[c.length - 1].arc = !0, Array.isArray(c[c.length - 1].abs) && c[c.length - 1].abs.push(L);
                break;
              case "close":
                c.push({ close: !0 });
            }
          }
          for (S = 0; S < c.length; S++) {
            var _;
            if (S == c.length - 1 ? (_ = "f", i === "evenodd" && (_ += "*")) : _ = null, c[S].close)
              this.pdf.internal.out("h"), _ && this.pdf.internal.out(_);
            else if (c[S].arc) {
              c[S].start && this.internal.move2(this, c[S].start.x, c[S].start.y);
              for (var Y = c[S].abs, $ = 0; $ < Y.length; $++) {
                var hA = Y[$];
                if (hA.startAngle !== void 0) {
                  var z = 360 * hA.startAngle / (2 * Math.PI), k = 360 * hA.endAngle / (2 * Math.PI), F = hA.x, R = hA.y;
                  $ === 0 && this.internal.move2(this, F, R), this.internal.arc2(this, F, R, hA.radius, z, k, hA.anticlockwise, null, r), $ === Y.length - 1 && c[S].start && (F = c[S].start.x, R = c[S].start.y, this.internal.line2(p, F, R));
                } else
                  this.internal.line2(p, hA.x, hA.y);
              }
            } else
              F = c[S].start.x, R = c[S].start.y, r ? (this.pdf.lines(c[S].deltas, F, R, null, null), this.pdf.clip_fixed()) : this.pdf.lines(c[S].deltas, F, R, null, _);
          }
          window.outIntercept = l;
        }
      }, pushMask: function() {
        if (typeof this.pdf.internal.newObject2 == "function") {
          var i = this.pdf.internal.newStreamObject(), r = this.pdf.internal.newObject2();
          r.push("<</Type /ExtGState"), r.push("/SMask <</S /Alpha /G " + i.objId + " 0 R>>"), r.push(">>");
          var n = "MASK" + r.objId;
          this.pdf.internal.addGraphicsState(n, r.objId);
          var s = "/" + n + " gs";
          this.pdf.internal.out(s);
        } else
          console.log("jsPDF v2 not enabled");
      }, clip: function() {
        if (0 < this.ctx._clip_path.length)
          for (var i = 0; i < this.path.length; i++)
            this.ctx._clip_path.push(this.path[i]);
        else
          this.ctx._clip_path = this.path;
        this.path = [];
      }, measureText: function(i) {
        var r = this.pdf;
        return { getWidth: function() {
          var n = r.internal.getFontSize(), s = r.getStringUnitWidth(i) * n / r.internal.scaleFactor;
          return s *= 1.3333;
        }, get width() {
          return this.getWidth(i);
        } };
      }, _getBaseline: function(i) {
        var r = parseInt(this.pdf.internal.getFontSize()), n = 0.25 * r;
        switch (this.ctx.textBaseline) {
          case "bottom":
            return i - n;
          case "top":
            return i + r;
          case "hanging":
            return i + r - n;
          case "middle":
            return i + r / 2 - n;
          case "ideographic":
            return i;
          case "alphabetic":
          default:
            return i;
        }
      } };
      var p = o.context2d;
      function C() {
        this._isStrokeTransparent = !1, this._strokeOpacity = 1, this.strokeStyle = "#000000", this.fillStyle = "#000000", this._isFillTransparent = !1, this._fillOpacity = 1, this.font = "12pt times", this.textBaseline = "alphabetic", this.textAlign = "start", this.lineWidth = 1, this.lineJoin = "miter", this.lineCap = "butt", this._transform = [1, 0, 0, 1, 0, 0], this.globalCompositeOperation = "normal", this.globalAlpha = 1, this._clip_path = [], this.ignoreClearRect = !1, this.copy = function(i) {
          this._isStrokeTransparent = i._isStrokeTransparent, this._strokeOpacity = i._strokeOpacity, this.strokeStyle = i.strokeStyle, this._isFillTransparent = i._isFillTransparent, this._fillOpacity = i._fillOpacity, this.fillStyle = i.fillStyle, this.font = i.font, this.lineWidth = i.lineWidth, this.lineJoin = i.lineJoin, this.lineCap = i.lineCap, this.textBaseline = i.textBaseline, this.textAlign = i.textAlign, this._fontSize = i._fontSize, this._transform = i._transform.slice(0), this.globalCompositeOperation = i.globalCompositeOperation, this.globalAlpha = i.globalAlpha, this._clip_path = i._clip_path.slice(0), this.ignoreClearRect = i.ignoreClearRect;
        };
      }
      Object.defineProperty(p, "fillStyle", { set: function(i) {
        this.setFillStyle(i);
      }, get: function() {
        return this.ctx.fillStyle;
      } }), Object.defineProperty(p, "strokeStyle", { set: function(i) {
        this.setStrokeStyle(i);
      }, get: function() {
        return this.ctx.strokeStyle;
      } }), Object.defineProperty(p, "lineWidth", { set: function(i) {
        this.setLineWidth(i);
      }, get: function() {
        return this.ctx.lineWidth;
      } }), Object.defineProperty(p, "lineCap", { set: function(i) {
        this.setLineCap(i);
      }, get: function() {
        return this.ctx.lineCap;
      } }), Object.defineProperty(p, "lineJoin", { set: function(i) {
        this.setLineJoin(i);
      }, get: function() {
        return this.ctx.lineJoin;
      } }), Object.defineProperty(p, "miterLimit", { set: function(i) {
        this.ctx.miterLimit = i;
      }, get: function() {
        return this.ctx.miterLimit;
      } }), Object.defineProperty(p, "textBaseline", { set: function(i) {
        this.setTextBaseline(i);
      }, get: function() {
        return this.getTextBaseline();
      } }), Object.defineProperty(p, "textAlign", { set: function(i) {
        this.setTextAlign(i);
      }, get: function() {
        return this.getTextAlign();
      } }), Object.defineProperty(p, "font", { set: function(i) {
        this.setFont(i);
      }, get: function() {
        return this.ctx.font;
      } }), Object.defineProperty(p, "globalCompositeOperation", { set: function(i) {
        this.ctx.globalCompositeOperation = i;
      }, get: function() {
        return this.ctx.globalCompositeOperation;
      } }), Object.defineProperty(p, "globalAlpha", { set: function(i) {
        this.ctx.globalAlpha = i;
      }, get: function() {
        return this.ctx.globalAlpha;
      } }), Object.defineProperty(p, "canvas", { get: function() {
        return { parentNode: !1, style: !1 };
      } }), Object.defineProperty(p, "ignoreClearRect", { set: function(i) {
        this.ctx.ignoreClearRect = i;
      }, get: function() {
        return this.ctx.ignoreClearRect;
      } }), p.internal = {}, p.internal.rxRgb = /rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/, p.internal.rxRgba = /rgba\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([\d\.]+)\s*\)/, p.internal.rxTransparent = /transparent|rgba\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*0+\s*\)/, p.internal.arc = function(i, r, n, s, c, l, d, B) {
        for (var h = this.pdf.internal.scaleFactor, f = this.pdf.internal.pageSize.getHeight(), m = this.pdf.internal.f2, w = c * (Math.PI / 180), U = l * (Math.PI / 180), I = this.createArc(s, w, U, d), S = 0; S < I.length; S++) {
          var L = I[S];
          S === 0 ? this.pdf.internal.out([m((L.x1 + r) * h), m((f - (L.y1 + n)) * h), "m", m((L.x2 + r) * h), m((f - (L.y2 + n)) * h), m((L.x3 + r) * h), m((f - (L.y3 + n)) * h), m((L.x4 + r) * h), m((f - (L.y4 + n)) * h), "c"].join(" ")) : this.pdf.internal.out([m((L.x2 + r) * h), m((f - (L.y2 + n)) * h), m((L.x3 + r) * h), m((f - (L.y3 + n)) * h), m((L.x4 + r) * h), m((f - (L.y4 + n)) * h), "c"].join(" ")), i._lastPoint = { x: r, y: n };
        }
        B !== null && this.pdf.internal.out(this.pdf.internal.getStyle(B));
      }, p.internal.arc2 = function(i, r, n, s, c, l, d, B, h) {
        var f = r, m = n;
        h ? (this.arc(i, f, m, s, c, l, d, null), this.pdf.clip_fixed()) : this.arc(i, f, m, s, c, l, d, B);
      }, p.internal.move2 = function(i, r, n) {
        var s = this.pdf.internal.scaleFactor, c = this.pdf.internal.pageSize.getHeight(), l = this.pdf.internal.f2;
        this.pdf.internal.out([l(r * s), l((c - n) * s), "m"].join(" ")), i._lastPoint = { x: r, y: n };
      }, p.internal.line2 = function(i, r, n) {
        var s = this.pdf.internal.scaleFactor, c = this.pdf.internal.pageSize.getHeight(), l = this.pdf.internal.f2, d = { x: r, y: n };
        this.pdf.internal.out([l(d.x * s), l((c - d.y) * s), "l"].join(" ")), i._lastPoint = d;
      }, p.internal.createArc = function(i, r, n, s) {
        var c = 2 * Math.PI, l = Math.PI / 2, d = r;
        for ((d < c || c < d) && (d %= c), d < 0 && (d = c + d); n < r; )
          r -= c;
        var B = Math.abs(n - r);
        B < c && s && (B = c - B);
        for (var h = [], f = s ? -1 : 1, m = d; 1e-5 < B; ) {
          var w = m + f * Math.min(B, l);
          h.push(this.createSmallArc(i, m, w)), B -= Math.abs(w - m), m = w;
        }
        return h;
      }, p.internal.getCurrentPage = function() {
        return this.pdf.internal.pages[this.pdf.internal.getCurrentPageInfo().pageNumber];
      }, p.internal.createSmallArc = function(i, r, n) {
        var s = (n - r) / 2, c = i * Math.cos(s), l = i * Math.sin(s), d = c, B = -l, h = d * d + B * B, f = h + d * c + B * l, m = 4 / 3 * (Math.sqrt(2 * h * f) - f) / (d * l - B * c), w = d - m * B, U = B + m * d, I = w, S = -U, L = s + r, N = Math.cos(L), j = Math.sin(L);
        return { x1: i * Math.cos(r), y1: i * Math.sin(r), x2: w * N - U * j, y2: w * j + U * N, x3: I * N - S * j, y3: I * j + S * N, x4: i * Math.cos(n), y4: i * Math.sin(n) };
      };
    }(Ct.API, typeof self < "u" && self || typeof window < "u" && window || typeof Jt < "u" && Jt || Function('return typeof this === "object" && this.content')() || Function("return this")()), /** @preserve
       * jsPDF fromHTML plugin. BETA stage. API subject to change. Needs browser
       * Copyright (c) 2012 Willow Systems Corporation, willow-systems.com
       *               2014 Juan Pablo Gaviria, https://github.com/juanpgaviria
       *               2014 Diego Casorran, https://github.com/diegocr
       *               2014 Daniel Husar, https://github.com/danielhusar
       *               2014 Wolfgang Gassler, https://github.com/woolfg
       *               2014 Steven Spungin, https://github.com/flamenco
       *
       * 
       * ====================================================================
       */
    function(o) {
      var p, C, i, r, n, s, c, l, d, B, h, f, m, w, U, I, S, L, N, j;
      p = function() {
        return function(y) {
          return V.prototype = y, new V();
        };
        function V() {
        }
      }(), B = function(V) {
        var y, P, _, Y, $, hA, z;
        for (P = 0, _ = V.length, y = void 0, hA = Y = !1; !Y && P !== _; )
          (y = V[P] = V[P].trimLeft()) && (Y = !0), P++;
        for (P = _ - 1; _ && !hA && P !== -1; )
          (y = V[P] = V[P].trimRight()) && (hA = !0), P--;
        for ($ = /\s+$/g, z = !0, P = 0; P !== _; )
          V[P] != "\u2028" && (y = V[P].replace(/\s+/g, " "), z && (y = y.trimLeft()), y && (z = $.test(y)), V[P] = y), P++;
        return V;
      }, f = function(V) {
        var y, P, _;
        for (y = void 0, P = (_ = V.split(",")).shift(); !y && P; )
          y = i[P.trim().toLowerCase()], P = _.shift();
        return y;
      }, m = function(V) {
        var y;
        return -1 < (V = V === "auto" ? "0px" : V).indexOf("em") && !isNaN(Number(V.replace("em", ""))) && (V = 18.719 * Number(V.replace("em", "")) + "px"), -1 < V.indexOf("pt") && !isNaN(Number(V.replace("pt", ""))) && (V = 1.333 * Number(V.replace("pt", "")) + "px"), (y = w[V]) ? y : (y = { "xx-small": 9, "x-small": 11, small: 13, medium: 16, large: 19, "x-large": 23, "xx-large": 28, auto: 0 }[V]) !== void 0 || (y = parseFloat(V)) ? w[V] = y / 16 : (y = V.match(/([\d\.]+)(px)/), Array.isArray(y) && y.length === 3 ? w[V] = parseFloat(y[1]) / 16 : w[V] = 1);
      }, d = function(V) {
        var y, P, _, Y, $;
        return $ = V, Y = document.defaultView && document.defaultView.getComputedStyle ? document.defaultView.getComputedStyle($, null) : $.currentStyle ? $.currentStyle : $.style, P = void 0, (y = {})["font-family"] = f((_ = function(hA) {
          return hA = hA.replace(/-\D/g, function(z) {
            return z.charAt(1).toUpperCase();
          }), Y[hA];
        })("font-family")) || "times", y["font-style"] = r[_("font-style")] || "normal", y["text-align"] = n[_("text-align")] || "left", (P = s[_("font-weight")] || "normal") === "bold" && (y["font-style"] === "normal" ? y["font-style"] = P : y["font-style"] = P + y["font-style"]), y["font-size"] = m(_("font-size")) || 1, y["line-height"] = m(_("line-height")) || 1, y.display = _("display") === "inline" ? "inline" : "block", P = y.display === "block", y["margin-top"] = P && m(_("margin-top")) || 0, y["margin-bottom"] = P && m(_("margin-bottom")) || 0, y["padding-top"] = P && m(_("padding-top")) || 0, y["padding-bottom"] = P && m(_("padding-bottom")) || 0, y["margin-left"] = P && m(_("margin-left")) || 0, y["margin-right"] = P && m(_("margin-right")) || 0, y["padding-left"] = P && m(_("padding-left")) || 0, y["padding-right"] = P && m(_("padding-right")) || 0, y["page-break-before"] = _("page-break-before") || "auto", y.float = c[_("cssFloat")] || "none", y.clear = l[_("clear")] || "none", y.color = _("color"), y;
      }, U = function(V, y, P) {
        var _, Y, $, hA, z;
        if ($ = !1, hA = Y = void 0, _ = P["#" + V.id])
          if (typeof _ == "function")
            $ = _(V, y);
          else
            for (Y = 0, hA = _.length; !$ && Y !== hA; )
              $ = _[Y](V, y), Y++;
        if (_ = P[V.nodeName], !$ && _)
          if (typeof _ == "function")
            $ = _(V, y);
          else
            for (Y = 0, hA = _.length; !$ && Y !== hA; )
              $ = _[Y](V, y), Y++;
        for (z = typeof V.className == "string" ? V.className.split(" ") : [], Y = 0; Y < z.length; Y++)
          if (_ = P["." + z[Y]], !$ && _)
            if (typeof _ == "function")
              $ = _(V, y);
            else
              for (Y = 0, hA = _.length; !$ && Y !== hA; )
                $ = _[Y](V, y), Y++;
        return $;
      }, j = function(V, y) {
        var P, _, Y, $, hA, z, k, F, R;
        for (P = [], _ = [], Y = 0, R = V.rows[0].cells.length, k = V.clientWidth; Y < R; )
          F = V.rows[0].cells[Y], _[Y] = { name: F.textContent.toLowerCase().replace(/\s+/g, ""), prompt: F.textContent.replace(/\r?\n/g, ""), width: F.clientWidth / k * y.pdf.internal.pageSize.getWidth() }, Y++;
        for (Y = 1; Y < V.rows.length; ) {
          for (z = V.rows[Y], hA = {}, $ = 0; $ < z.cells.length; )
            hA[_[$].name] = z.cells[$].textContent.replace(/\r?\n/g, ""), $++;
          P.push(hA), Y++;
        }
        return { rows: P, headers: _ };
      };
      var Z = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, OBJECT: 1, EMBED: 1, SELECT: 1 }, W = 1;
      C = function(V, y, P) {
        var _, Y, $, hA, z, k, F, R;
        for (Y = V.childNodes, _ = void 0, (z = ($ = d(V)).display === "block") && (y.setBlockBoundary(), y.setBlockStyle($)), hA = 0, k = Y.length; hA < k; ) {
          if (((_ = Y[hA]) === void 0 ? "undefined" : Ot(_)) === "object") {
            if (y.executeWatchFunctions(_), _.nodeType === 1 && _.nodeName === "HEADER") {
              var E = _, G = y.pdf.margins_doc.top;
              y.pdf.internal.events.subscribe("addPage", function(wA) {
                y.y = G, C(E, y, P), y.pdf.margins_doc.top = y.y + 10, y.y += 10;
              }, !1);
            }
            if (_.nodeType === 8 && _.nodeName === "#comment")
              ~_.textContent.indexOf("ADD_PAGE") && (y.pdf.addPage(), y.y = y.pdf.margins_doc.top);
            else if (_.nodeType !== 1 || Z[_.nodeName])
              if (_.nodeType === 3) {
                var M = _.nodeValue;
                if (_.nodeValue && _.parentNode.nodeName === "LI")
                  if (_.parentNode.parentNode.nodeName === "OL")
                    M = W++ + ". " + M;
                  else {
                    var oA = $["font-size"], X = (3 - 0.75 * oA) * y.pdf.internal.scaleFactor, fA = 0.75 * oA * y.pdf.internal.scaleFactor, nA = 1.74 * oA / y.pdf.internal.scaleFactor;
                    R = function(wA, SA) {
                      this.pdf.circle(wA + X, SA + fA, nA, "FD");
                    };
                  }
                16 & _.ownerDocument.body.compareDocumentPosition(_) && y.addText(M, $);
              } else
                typeof _ == "string" && y.addText(_, $);
            else {
              var b;
              if (_.nodeName === "IMG") {
                var D = _.getAttribute("src");
                b = I[y.pdf.sHashCode(D) || D];
              }
              if (b) {
                y.pdf.internal.pageSize.getHeight() - y.pdf.margins_doc.bottom < y.y + _.height && y.y > y.pdf.margins_doc.top && (y.pdf.addPage(), y.y = y.pdf.margins_doc.top, y.executeWatchFunctions(_));
                var u = d(_), Q = y.x, H = 12 / y.pdf.internal.scaleFactor, O = (u["margin-left"] + u["padding-left"]) * H, eA = (u["margin-right"] + u["padding-right"]) * H, sA = (u["margin-top"] + u["padding-top"]) * H, pA = (u["margin-bottom"] + u["padding-bottom"]) * H;
                u.float !== void 0 && u.float === "right" ? Q += y.settings.width - _.width - eA : Q += O, y.pdf.addImage(b, Q, y.y + sA, _.width, _.height), b = void 0, u.float === "right" || u.float === "left" ? (y.watchFunctions.push((function(wA, SA, xA, KA) {
                  return y.y >= SA ? (y.x += wA, y.settings.width += xA, !0) : !!(KA && KA.nodeType === 1 && !Z[KA.nodeName] && y.x + KA.width > y.pdf.margins_doc.left + y.pdf.margins_doc.width) && (y.x += wA, y.y = SA, y.settings.width += xA, !0);
                }).bind(this, u.float === "left" ? -_.width - O - eA : 0, y.y + _.height + sA + pA, _.width)), y.watchFunctions.push((function(wA, SA, xA) {
                  return !(y.y < wA && SA === y.pdf.internal.getNumberOfPages()) || xA.nodeType === 1 && d(xA).clear === "both" && (y.y = wA, !0);
                }).bind(this, y.y + _.height, y.pdf.internal.getNumberOfPages())), y.settings.width -= _.width + O + eA, u.float === "left" && (y.x += _.width + O + eA)) : y.y += _.height + sA + pA;
              } else if (_.nodeName === "TABLE")
                F = j(_, y), y.y += 10, y.pdf.table(y.x, y.y, F.rows, F.headers, { autoSize: !1, printHeaders: P.printHeaders, margins: y.pdf.margins_doc, css: d(_) }), y.y = y.pdf.lastCellPos.y + y.pdf.lastCellPos.h + 20;
              else if (_.nodeName === "OL" || _.nodeName === "UL")
                W = 1, U(_, y, P) || C(_, y, P), y.y += 10;
              else if (_.nodeName === "LI") {
                var yA = y.x;
                y.x += 20 / y.pdf.internal.scaleFactor, y.y += 3, U(_, y, P) || C(_, y, P), y.x = yA;
              } else
                _.nodeName === "BR" ? (y.y += $["font-size"] * y.pdf.internal.scaleFactor, y.addText("\u2028", p($))) : U(_, y, P) || C(_, y, P);
            }
          }
          hA++;
        }
        if (P.outY = y.y, z)
          return y.setBlockBoundary(R);
      }, I = {}, S = function(V, y, P, _) {
        var Y, $ = V.getElementsByTagName("img"), hA = $.length, z = 0;
        function k() {
          y.pdf.internal.events.publish("imagesLoaded"), _(Y);
        }
        function F(R, E, G) {
          if (R) {
            var M = new Image();
            Y = ++z, M.crossOrigin = "", M.onerror = M.onload = function() {
              if (M.complete && (M.src.indexOf("data:image/") === 0 && (M.width = E || M.width || 0, M.height = G || M.height || 0), M.width + M.height)) {
                var oA = y.pdf.sHashCode(R) || R;
                I[oA] = I[oA] || M;
              }
              --z || k();
            }, M.src = R;
          }
        }
        for (; hA--; )
          F($[hA].getAttribute("src"), $[hA].width, $[hA].height);
        return z || k();
      }, L = function(V, y, P) {
        var _ = V.getElementsByTagName("footer");
        if (0 < _.length) {
          _ = _[0];
          var Y = y.pdf.internal.write, $ = y.y;
          y.pdf.internal.write = function() {
          }, C(_, y, P);
          var hA = Math.ceil(y.y - $) + 5;
          y.y = $, y.pdf.internal.write = Y, y.pdf.margins_doc.bottom += hA;
          for (var z = function(R) {
            var E = R !== void 0 ? R.pageNumber : 1, G = y.y;
            y.y = y.pdf.internal.pageSize.getHeight() - y.pdf.margins_doc.bottom, y.pdf.margins_doc.bottom -= hA;
            for (var M = _.getElementsByTagName("span"), oA = 0; oA < M.length; ++oA)
              -1 < (" " + M[oA].className + " ").replace(/[\n\t]/g, " ").indexOf(" pageCounter ") && (M[oA].innerHTML = E), -1 < (" " + M[oA].className + " ").replace(/[\n\t]/g, " ").indexOf(" totalPages ") && (M[oA].innerHTML = "###jsPDFVarTotalPages###");
            C(_, y, P), y.pdf.margins_doc.bottom += hA, y.y = G;
          }, k = _.getElementsByTagName("span"), F = 0; F < k.length; ++F)
            -1 < (" " + k[F].className + " ").replace(/[\n\t]/g, " ").indexOf(" totalPages ") && y.pdf.internal.events.subscribe("htmlRenderingFinished", y.pdf.putTotalPages.bind(y.pdf, "###jsPDFVarTotalPages###"), !0);
          y.pdf.internal.events.subscribe("addPage", z, !1), z(), Z.FOOTER = 1;
        }
      }, N = function(V, y, P, _, Y, $) {
        if (!y)
          return !1;
        var hA, z, k, F;
        typeof y == "string" || y.parentNode || (y = "" + y.innerHTML), typeof y == "string" && (hA = y.replace(/<\/?script[^>]*?>/gi, ""), F = "jsPDFhtmlText" + Date.now().toString() + (1e3 * Math.random()).toFixed(0), (k = document.createElement("div")).style.cssText = "position: absolute !important;clip: rect(1px 1px 1px 1px); /* IE6, IE7 */clip: rect(1px, 1px, 1px, 1px);padding:0 !important;border:0 !important;height: 1px !important;width: 1px !important; top:auto;left:-100px;overflow: hidden;", k.innerHTML = '<iframe style="height:1px;width:1px" name="' + F + '" />', document.body.appendChild(k), (z = window.frames[F]).document.open(), z.document.writeln(hA), z.document.close(), y = z.document.body);
        var R, E = new h(V, P, _, Y);
        return S.call(this, y, E, Y.elementHandlers, function(G) {
          L(y, E, Y.elementHandlers), C(y, E, Y.elementHandlers), E.pdf.internal.events.publish("htmlRenderingFinished"), R = E.dispose(), typeof $ == "function" ? $(R) : G && console.error("jsPDF Warning: rendering issues? provide a callback to fromHTML!");
        }), R || { x: E.x, y: E.y };
      }, (h = function(V, y, P, _) {
        return this.pdf = V, this.x = y, this.y = P, this.settings = _, this.watchFunctions = [], this.init(), this;
      }).prototype.init = function() {
        return this.paragraph = { text: [], style: [] }, this.pdf.internal.write("q");
      }, h.prototype.dispose = function() {
        return this.pdf.internal.write("Q"), { x: this.x, y: this.y, ready: !0 };
      }, h.prototype.executeWatchFunctions = function(V) {
        var y = !1, P = [];
        if (0 < this.watchFunctions.length) {
          for (var _ = 0; _ < this.watchFunctions.length; ++_)
            this.watchFunctions[_](V) === !0 ? y = !0 : P.push(this.watchFunctions[_]);
          this.watchFunctions = P;
        }
        return y;
      }, h.prototype.splitFragmentsIntoLines = function(V, y) {
        var P, _, Y, $, hA, z, k, F, R, E, G, M, oA, X;
        for (E = this.pdf.internal.scaleFactor, $ = {}, z = k = F = X = hA = Y = R = _ = void 0, M = [G = []], P = 0, oA = this.settings.width; V.length; )
          if (hA = V.shift(), X = y.shift(), hA)
            if ((Y = $[(_ = X["font-family"]) + (R = X["font-style"])]) || (Y = this.pdf.internal.getFont(_, R).metadata.Unicode, $[_ + R] = Y), F = { widths: Y.widths, kerning: Y.kerning, fontSize: 12 * X["font-size"], textIndent: P }, k = this.pdf.getStringUnitWidth(hA, F) * F.fontSize / E, hA == "\u2028")
              G = [], M.push(G);
            else if (oA < P + k) {
              for (z = this.pdf.splitTextToSize(hA, oA, F), G.push([z.shift(), X]); z.length; )
                G = [[z.shift(), X]], M.push(G);
              P = this.pdf.getStringUnitWidth(G[0][0], F) * F.fontSize / E;
            } else
              G.push([hA, X]), P += k;
        if (X["text-align"] !== void 0 && (X["text-align"] === "center" || X["text-align"] === "right" || X["text-align"] === "justify"))
          for (var fA = 0; fA < M.length; ++fA) {
            var nA = this.pdf.getStringUnitWidth(M[fA][0][0], F) * F.fontSize / E;
            0 < fA && (M[fA][0][1] = p(M[fA][0][1]));
            var b = oA - nA;
            if (X["text-align"] === "right")
              M[fA][0][1]["margin-left"] = b;
            else if (X["text-align"] === "center")
              M[fA][0][1]["margin-left"] = b / 2;
            else if (X["text-align"] === "justify") {
              var D = M[fA][0][0].split(" ").length - 1;
              M[fA][0][1]["word-spacing"] = b / D, fA === M.length - 1 && (M[fA][0][1]["word-spacing"] = 0);
            }
          }
        return M;
      }, h.prototype.RenderTextFragment = function(V, y) {
        var P, _;
        _ = 0, this.pdf.internal.pageSize.getHeight() - this.pdf.margins_doc.bottom < this.y + this.pdf.internal.getFontSize() && (this.pdf.internal.write("ET", "Q"), this.pdf.addPage(), this.y = this.pdf.margins_doc.top, this.pdf.internal.write("q", "BT", this.getPdfColor(y.color), this.pdf.internal.getCoordinateString(this.x), this.pdf.internal.getVerticalCoordinateString(this.y), "Td"), _ = Math.max(_, y["line-height"], y["font-size"]), this.pdf.internal.write(0, (-12 * _).toFixed(2), "Td")), P = this.pdf.internal.getFont(y["font-family"], y["font-style"]);
        var Y = this.getPdfColor(y.color);
        Y !== this.lastTextColor && (this.pdf.internal.write(Y), this.lastTextColor = Y), y["word-spacing"] !== void 0 && 0 < y["word-spacing"] && this.pdf.internal.write(y["word-spacing"].toFixed(2), "Tw"), this.pdf.internal.write("/" + P.id, (12 * y["font-size"]).toFixed(2), "Tf", "(" + this.pdf.internal.pdfEscape(V) + ") Tj"), y["word-spacing"] !== void 0 && this.pdf.internal.write(0, "Tw");
      }, h.prototype.getPdfColor = function(V) {
        var y, P, _, Y = new RGBColor(V), $ = /rgb\s*\(\s*(\d+),\s*(\d+),\s*(\d+\s*)\)/.exec(V);
        if ($ != null ? (y = parseInt($[1]), P = parseInt($[2]), _ = parseInt($[3])) : (V.charAt(0) != "#" && (V = Y.ok ? Y.toHex() : "#000000"), y = V.substring(1, 3), y = parseInt(y, 16), P = V.substring(3, 5), P = parseInt(P, 16), _ = V.substring(5, 7), _ = parseInt(_, 16)), typeof y == "string" && /^#[0-9A-Fa-f]{6}$/.test(y)) {
          var hA = parseInt(y.substr(1), 16);
          y = hA >> 16 & 255, P = hA >> 8 & 255, _ = 255 & hA;
        }
        var z = this.f3;
        return y === 0 && P === 0 && _ === 0 || P === void 0 ? z(y / 255) + " g" : [z(y / 255), z(P / 255), z(_ / 255), "rg"].join(" ");
      }, h.prototype.f3 = function(V) {
        return V.toFixed(3);
      }, h.prototype.renderParagraph = function(V) {
        var y, P, _, Y, $, hA, z, k, F, R, E, G, M;
        if (_ = B(this.paragraph.text), G = this.paragraph.style, y = this.paragraph.blockstyle, this.paragraph.priorblockstyle, this.paragraph = { text: [], style: [], blockstyle: {}, priorblockstyle: y }, _.join("").trim()) {
          z = this.splitFragmentsIntoLines(_, G), k = hA = void 0, P = 12 / this.pdf.internal.scaleFactor, this.priorMarginBottom = this.priorMarginBottom || 0, E = (Math.max((y["margin-top"] || 0) - this.priorMarginBottom, 0) + (y["padding-top"] || 0)) * P, R = ((y["margin-bottom"] || 0) + (y["padding-bottom"] || 0)) * P, this.priorMarginBottom = y["margin-bottom"] || 0, y["page-break-before"] === "always" && (this.pdf.addPage(), this.y = 0, E = ((y["margin-top"] || 0) + (y["padding-top"] || 0)) * P), F = this.pdf.internal.write, $ = Y = void 0, this.y += E, F("q", "BT 0 g", this.pdf.internal.getCoordinateString(this.x), this.pdf.internal.getVerticalCoordinateString(this.y), "Td");
          for (var oA = 0; z.length; ) {
            for (Y = k = 0, $ = (hA = z.shift()).length; Y !== $; )
              hA[Y][0].trim() && (k = Math.max(k, hA[Y][1]["line-height"], hA[Y][1]["font-size"]), M = 7 * hA[Y][1]["font-size"]), Y++;
            var X = 0, fA = 0;
            for (hA[0][1]["margin-left"] !== void 0 && 0 < hA[0][1]["margin-left"] && (X = (fA = this.pdf.internal.getCoordinateString(hA[0][1]["margin-left"])) - oA, oA = fA), F(X + Math.max(y["margin-left"] || 0, 0) * P, (-12 * k).toFixed(2), "Td"), Y = 0, $ = hA.length; Y !== $; )
              hA[Y][0] && this.RenderTextFragment(hA[Y][0], hA[Y][1]), Y++;
            if (this.y += k * P, this.executeWatchFunctions(hA[0][1]) && 0 < z.length) {
              var nA = [], b = [];
              z.forEach(function(D) {
                for (var u = 0, Q = D.length; u !== Q; )
                  D[u][0] && (nA.push(D[u][0] + " "), b.push(D[u][1])), ++u;
              }), z = this.splitFragmentsIntoLines(B(nA), b), F("ET", "Q"), F("q", "BT 0 g", this.pdf.internal.getCoordinateString(this.x), this.pdf.internal.getVerticalCoordinateString(this.y), "Td");
            }
          }
          return V && typeof V == "function" && V.call(this, this.x - 9, this.y - M / 2), F("ET", "Q"), this.y += R;
        }
      }, h.prototype.setBlockBoundary = function(V) {
        return this.renderParagraph(V);
      }, h.prototype.setBlockStyle = function(V) {
        return this.paragraph.blockstyle = V;
      }, h.prototype.addText = function(V, y) {
        return this.paragraph.text.push(V), this.paragraph.style.push(y);
      }, i = { helvetica: "helvetica", "sans-serif": "helvetica", "times new roman": "times", serif: "times", times: "times", monospace: "courier", courier: "courier" }, s = { 100: "normal", 200: "normal", 300: "normal", 400: "normal", 500: "bold", 600: "bold", 700: "bold", 800: "bold", 900: "bold", normal: "normal", bold: "bold", bolder: "bold", lighter: "normal" }, r = { normal: "normal", italic: "italic", oblique: "italic" }, n = { left: "left", right: "right", center: "center", justify: "justify" }, c = { none: "none", right: "right", left: "left" }, l = { none: "none", both: "both" }, w = { normal: 1 }, o.fromHTML = function(V, y, P, _, Y, $) {
        return this.margins_doc = $ || { top: 0, bottom: 0 }, _ || (_ = {}), _.elementHandlers || (_.elementHandlers = {}), N(this, V, isNaN(y) ? 4 : y, isNaN(P) ? 4 : P, _, Y);
      };
    }(Ct.API), Ct.API.addJS = function(o) {
      return Bt = o, this.internal.events.subscribe("postPutResources", function(p) {
        Ae = this.internal.newObject(), this.internal.out("<<"), this.internal.out("/Names [(EmbeddedJS) " + (Ae + 1) + " 0 R]"), this.internal.out(">>"), this.internal.out("endobj"), vt = this.internal.newObject(), this.internal.out("<<"), this.internal.out("/S /JavaScript"), this.internal.out("/JS (" + Bt + ")"), this.internal.out(">>"), this.internal.out("endobj");
      }), this.internal.events.subscribe("putCatalog", function() {
        Ae !== void 0 && vt !== void 0 && this.internal.out("/Names <</JavaScript " + Ae + " 0 R>>");
      }), this;
    }, /**
       * jsPDF Outline PlugIn
       * Copyright (c) 2014 Steven Spungin (TwelveTone LLC)  steven@twelvetone.tv
       *
       * Licensed under the MIT License.
       * http://opensource.org/licenses/mit-license
       */
    (St = Ct.API).events.push(["postPutResources", function() {
      var o = this, p = /^(\d+) 0 obj$/;
      if (0 < this.outline.root.children.length)
        for (var C = o.outline.render().split(/\r\n/), i = 0; i < C.length; i++) {
          var r = C[i], n = p.exec(r);
          if (n != null) {
            var s = n[1];
            o.internal.newObjectDeferredBegin(s);
          }
          o.internal.write(r);
        }
      if (this.outline.createNamedDestinations) {
        var c = this.internal.pages.length, l = [];
        for (i = 0; i < c; i++) {
          var d = o.internal.newObject();
          l.push(d);
          var B = o.internal.getPageInfo(i + 1);
          o.internal.write("<< /D[" + B.objId + " 0 R /XYZ null null null]>> endobj");
        }
        var h = o.internal.newObject();
        for (o.internal.write("<< /Names [ "), i = 0; i < l.length; i++)
          o.internal.write("(page_" + (i + 1) + ")" + l[i] + " 0 R");
        o.internal.write(" ] >>", "endobj"), o.internal.newObject(), o.internal.write("<< /Dests " + h + " 0 R"), o.internal.write(">>", "endobj");
      }
    }]), St.events.push(["putCatalog", function() {
      0 < this.outline.root.children.length && (this.internal.write("/Outlines", this.outline.makeRef(this.outline.root)), this.outline.createNamedDestinations && this.internal.write("/Names " + namesOid + " 0 R"));
    }]), St.events.push(["initialized", function() {
      var o = this;
      o.outline = { createNamedDestinations: !1, root: { children: [] } }, o.outline.add = function(p, C, i) {
        var r = { title: C, options: i, children: [] };
        return p == null && (p = this.root), p.children.push(r), r;
      }, o.outline.render = function() {
        return this.ctx = {}, this.ctx.val = "", this.ctx.pdf = o, this.genIds_r(this.root), this.renderRoot(this.root), this.renderItems(this.root), this.ctx.val;
      }, o.outline.genIds_r = function(p) {
        p.id = o.internal.newObjectDeferred();
        for (var C = 0; C < p.children.length; C++)
          this.genIds_r(p.children[C]);
      }, o.outline.renderRoot = function(p) {
        this.objStart(p), this.line("/Type /Outlines"), 0 < p.children.length && (this.line("/First " + this.makeRef(p.children[0])), this.line("/Last " + this.makeRef(p.children[p.children.length - 1]))), this.line("/Count " + this.count_r({ count: 0 }, p)), this.objEnd();
      }, o.outline.renderItems = function(p) {
        for (var C = 0; C < p.children.length; C++) {
          var i = p.children[C];
          this.objStart(i), this.line("/Title " + this.makeString(i.title)), this.line("/Parent " + this.makeRef(p)), 0 < C && this.line("/Prev " + this.makeRef(p.children[C - 1])), C < p.children.length - 1 && this.line("/Next " + this.makeRef(p.children[C + 1])), 0 < i.children.length && (this.line("/First " + this.makeRef(i.children[0])), this.line("/Last " + this.makeRef(i.children[i.children.length - 1])));
          var r = this.count = this.count_r({ count: 0 }, i);
          if (0 < r && this.line("/Count " + r), i.options && i.options.pageNumber) {
            var n = o.internal.getPageInfo(i.options.pageNumber);
            this.line("/Dest [" + n.objId + " 0 R /XYZ 0 " + this.ctx.pdf.internal.pageSize.getHeight() * this.ctx.pdf.internal.scaleFactor + " 0]");
          }
          this.objEnd();
        }
        for (C = 0; C < p.children.length; C++)
          i = p.children[C], this.renderItems(i);
      }, o.outline.line = function(p) {
        this.ctx.val += p + `\r
`;
      }, o.outline.makeRef = function(p) {
        return p.id + " 0 R";
      }, o.outline.makeString = function(p) {
        return "(" + o.internal.pdfEscape(p) + ")";
      }, o.outline.objStart = function(p) {
        this.ctx.val += `\r
` + p.id + ` 0 obj\r
<<\r
`;
      }, o.outline.objEnd = function(p) {
        this.ctx.val += `>> \r
endobj\r
`;
      }, o.outline.count_r = function(p, C) {
        for (var i = 0; i < C.children.length; i++)
          p.count++, this.count_r(p, C.children[i]);
        return p.count;
      };
    }]), /**@preserve
       *  ====================================================================
       * jsPDF PNG PlugIn
       * Copyright (c) 2014 James Robb, https://github.com/jamesbrobb
       *
       * 
       * ====================================================================
       */
    Tt = Ct.API, ne = function() {
      var o = typeof Deflater == "function";
      if (!o)
        throw new Error("requires deflate.js for compression");
      return o;
    }, Kt = function(o, p, C, i) {
      var r = 5, n = Se;
      switch (i) {
        case Tt.image_compression.FAST:
          r = 3, n = He;
          break;
        case Tt.image_compression.MEDIUM:
          r = 6, n = we;
          break;
        case Tt.image_compression.SLOW:
          r = 9, n = ut;
      }
      o = Ne(o, p, C, n);
      var s = new Uint8Array(zt(r)), c = ie(o), l = new Deflater(r), d = l.append(o), B = l.flush(), h = s.length + d.length + B.length, f = new Uint8Array(h + 4);
      return f.set(s), f.set(d, s.length), f.set(B, s.length + d.length), f[h++] = c >>> 24 & 255, f[h++] = c >>> 16 & 255, f[h++] = c >>> 8 & 255, f[h++] = 255 & c, Tt.arrayBufferToBinaryString(f);
    }, zt = function(o, p) {
      var C = Math.LOG2E * Math.log(32768) - 8 << 4 | 8, i = C << 8;
      return i |= Math.min(3, (p - 1 & 255) >> 1) << 6, i |= 0, [C, 255 & (i += 31 - i % 31)];
    }, ie = function(o, p) {
      for (var C, i = 1, r = 0, n = o.length, s = 0; 0 < n; ) {
        for (n -= C = p < n ? p : n; r += i += o[s++], --C; )
          ;
        i %= 65521, r %= 65521;
      }
      return (r << 16 | i) >>> 0;
    }, Ne = function(o, p, C, i) {
      for (var r, n, s, c = o.length / p, l = new Uint8Array(o.length + c), d = _t(), B = 0; B < c; B++) {
        if (s = B * p, r = o.subarray(s, s + p), i)
          l.set(i(r, C, n), s + B);
        else {
          for (var h = 0, f = d.length, m = []; h < f; h++)
            m[h] = d[h](r, C, n);
          var w = ge(m.concat());
          l.set(m[w], s + B);
        }
        n = r;
      }
      return l;
    }, Be = function(o, p, C) {
      var i = Array.apply([], o);
      return i.unshift(0), i;
    }, He = function(o, p, C) {
      var i, r = [], n = 0, s = o.length;
      for (r[0] = 1; n < s; n++)
        i = o[n - p] || 0, r[n + 1] = o[n] - i + 256 & 255;
      return r;
    }, Se = function(o, p, C) {
      var i, r = [], n = 0, s = o.length;
      for (r[0] = 2; n < s; n++)
        i = C && C[n] || 0, r[n + 1] = o[n] - i + 256 & 255;
      return r;
    }, we = function(o, p, C) {
      var i, r, n = [], s = 0, c = o.length;
      for (n[0] = 3; s < c; s++)
        i = o[s - p] || 0, r = C && C[s] || 0, n[s + 1] = o[s] + 256 - (i + r >>> 1) & 255;
      return n;
    }, ut = function(o, p, C) {
      var i, r, n, s, c = [], l = 0, d = o.length;
      for (c[0] = 4; l < d; l++)
        i = o[l - p] || 0, r = C && C[l] || 0, n = C && C[l - p] || 0, s = ft(i, r, n), c[l + 1] = o[l] - s + 256 & 255;
      return c;
    }, ft = function(o, p, C) {
      var i = o + p - C, r = Math.abs(i - o), n = Math.abs(i - p), s = Math.abs(i - C);
      return r <= n && r <= s ? o : n <= s ? p : C;
    }, _t = function() {
      return [Be, He, Se, we, ut];
    }, ge = function(o) {
      for (var p, C, i, r = 0, n = o.length; r < n; )
        ((p = te(o[r].slice(1))) < C || !C) && (C = p, i = r), r++;
      return i;
    }, te = function(o) {
      for (var p = 0, C = o.length, i = 0; p < C; )
        i += Math.abs(o[p++]);
      return i;
    }, Tt.processPNG = function(o, p, C, i, r) {
      var n, s, c, l, d, B, h = this.color_spaces.DEVICE_RGB, f = this.decode.FLATE_DECODE, m = 8;
      if (this.isArrayBuffer(o) && (o = new Uint8Array(o)), this.isArrayBufferView(o)) {
        if (typeof PNG != "function" || typeof mn != "function")
          throw new Error("PNG support requires png.js and zlib.js");
        if (o = (n = new PNG(o)).imgData, m = n.bits, h = n.colorSpace, l = n.colors, [4, 6].indexOf(n.colorType) !== -1) {
          if (n.bits === 8)
            for (var w, U = (_ = n.pixelBitlength == 32 ? new Uint32Array(n.decodePixels().buffer) : n.pixelBitlength == 16 ? new Uint16Array(n.decodePixels().buffer) : new Uint8Array(n.decodePixels().buffer)).length, I = new Uint8Array(U * n.colors), S = new Uint8Array(U), L = n.pixelBitlength - n.bits, N = 0, j = 0; N < U; N++) {
              for (Z = _[N], w = 0; w < L; )
                I[j++] = Z >>> w & 255, w += n.bits;
              S[N] = Z >>> w & 255;
            }
          if (n.bits === 16) {
            U = (_ = new Uint32Array(n.decodePixels().buffer)).length, I = new Uint8Array(U * (32 / n.pixelBitlength) * n.colors), S = new Uint8Array(U * (32 / n.pixelBitlength));
            for (var Z, W = 1 < n.colors, V = j = N = 0; N < U; )
              Z = _[N++], I[j++] = Z >>> 0 & 255, W && (I[j++] = Z >>> 16 & 255, Z = _[N++], I[j++] = Z >>> 0 & 255), S[V++] = Z >>> 16 & 255;
            m = 8;
          }
          i !== Tt.image_compression.NONE && ne() ? (o = Kt(I, n.width * n.colors, n.colors, i), B = Kt(S, n.width, 1, i)) : (o = I, B = S, f = null);
        }
        if (n.colorType === 3 && (h = this.color_spaces.INDEXED, d = n.palette, n.transparency.indexed)) {
          var y = n.transparency.indexed, P = 0;
          for (N = 0, U = y.length; N < U; ++N)
            P += y[N];
          if ((P /= 255) == U - 1 && y.indexOf(0) !== -1)
            c = [y.indexOf(0)];
          else if (P !== U) {
            var _ = n.decodePixels();
            for (S = new Uint8Array(_.length), N = 0, U = _.length; N < U; N++)
              S[N] = y[_[N]];
            B = Kt(S, n.width, 1);
          }
        }
        var Y = function($) {
          var hA;
          switch ($) {
            case Tt.image_compression.FAST:
              hA = 11;
              break;
            case Tt.image_compression.MEDIUM:
              hA = 13;
              break;
            case Tt.image_compression.SLOW:
              hA = 14;
              break;
            default:
              hA = 12;
          }
          return hA;
        }(i);
        return s = f === this.decode.FLATE_DECODE ? "/Predictor " + Y + " /Colors " + l + " /BitsPerComponent " + m + " /Columns " + n.width : "/Colors " + l + " /BitsPerComponent " + m + " /Columns " + n.width, (this.isArrayBuffer(o) || this.isArrayBufferView(o)) && (o = this.arrayBufferToBinaryString(o)), (B && this.isArrayBuffer(B) || this.isArrayBufferView(B)) && (B = this.arrayBufferToBinaryString(B)), this.createImageInfo(o, n.width, n.height, h, m, f, p, C, s, c, d, B, Y);
      }
      throw new Error("Unsupported PNG image data, try using JPEG instead.");
    }, /**
       * jsPDF gif Support PlugIn
       * Copyright (c) 2017 Aras Abbasi 
       *
       * Licensed under the MIT License.
       * http://opensource.org/licenses/mit-license
       */
    (Ze = Ct.API).processGIF89A = function(o, p, C, i, r) {
      var n = new tn(o), s = n.width, c = n.height, l = [];
      n.decodeAndBlitFrameRGBA(0, l);
      var d = { data: l, width: s, height: c }, B = new Cr(100).encode(d, 100);
      return Ze.processJPEG.call(this, B, p, C, i);
    }, Ze.processGIF87A = Ze.processGIF89A, /**
       * jsPDF bmp Support PlugIn
       * Copyright (c) 2018 Aras Abbasi 
       *
       * Licensed under the MIT License.
       * http://opensource.org/licenses/mit-license
       */
    ($e = Ct.API).processBMP = function(o, p, C, i, r) {
      var n = new pe(o, !1), s = n.width, c = n.height, l = { data: n.getData(), width: s, height: c }, d = new Cr(100).encode(l, 100);
      return $e.processJPEG.call(this, d, p, C, i);
    }, Ct.API.setLanguage = function(o) {
      return this.internal.languageSettings === void 0 && (this.internal.languageSettings = {}, this.internal.languageSettings.isSubscribed = !1), { af: "Afrikaans", sq: "Albanian", ar: "Arabic (Standard)", "ar-DZ": "Arabic (Algeria)", "ar-BH": "Arabic (Bahrain)", "ar-EG": "Arabic (Egypt)", "ar-IQ": "Arabic (Iraq)", "ar-JO": "Arabic (Jordan)", "ar-KW": "Arabic (Kuwait)", "ar-LB": "Arabic (Lebanon)", "ar-LY": "Arabic (Libya)", "ar-MA": "Arabic (Morocco)", "ar-OM": "Arabic (Oman)", "ar-QA": "Arabic (Qatar)", "ar-SA": "Arabic (Saudi Arabia)", "ar-SY": "Arabic (Syria)", "ar-TN": "Arabic (Tunisia)", "ar-AE": "Arabic (U.A.E.)", "ar-YE": "Arabic (Yemen)", an: "Aragonese", hy: "Armenian", as: "Assamese", ast: "Asturian", az: "Azerbaijani", eu: "Basque", be: "Belarusian", bn: "Bengali", bs: "Bosnian", br: "Breton", bg: "Bulgarian", my: "Burmese", ca: "Catalan", ch: "Chamorro", ce: "Chechen", zh: "Chinese", "zh-HK": "Chinese (Hong Kong)", "zh-CN": "Chinese (PRC)", "zh-SG": "Chinese (Singapore)", "zh-TW": "Chinese (Taiwan)", cv: "Chuvash", co: "Corsican", cr: "Cree", hr: "Croatian", cs: "Czech", da: "Danish", nl: "Dutch (Standard)", "nl-BE": "Dutch (Belgian)", en: "English", "en-AU": "English (Australia)", "en-BZ": "English (Belize)", "en-CA": "English (Canada)", "en-IE": "English (Ireland)", "en-JM": "English (Jamaica)", "en-NZ": "English (New Zealand)", "en-PH": "English (Philippines)", "en-ZA": "English (South Africa)", "en-TT": "English (Trinidad & Tobago)", "en-GB": "English (United Kingdom)", "en-US": "English (United States)", "en-ZW": "English (Zimbabwe)", eo: "Esperanto", et: "Estonian", fo: "Faeroese", fj: "Fijian", fi: "Finnish", fr: "French (Standard)", "fr-BE": "French (Belgium)", "fr-CA": "French (Canada)", "fr-FR": "French (France)", "fr-LU": "French (Luxembourg)", "fr-MC": "French (Monaco)", "fr-CH": "French (Switzerland)", fy: "Frisian", fur: "Friulian", gd: "Gaelic (Scots)", "gd-IE": "Gaelic (Irish)", gl: "Galacian", ka: "Georgian", de: "German (Standard)", "de-AT": "German (Austria)", "de-DE": "German (Germany)", "de-LI": "German (Liechtenstein)", "de-LU": "German (Luxembourg)", "de-CH": "German (Switzerland)", el: "Greek", gu: "Gujurati", ht: "Haitian", he: "Hebrew", hi: "Hindi", hu: "Hungarian", is: "Icelandic", id: "Indonesian", iu: "Inuktitut", ga: "Irish", it: "Italian (Standard)", "it-CH": "Italian (Switzerland)", ja: "Japanese", kn: "Kannada", ks: "Kashmiri", kk: "Kazakh", km: "Khmer", ky: "Kirghiz", tlh: "Klingon", ko: "Korean", "ko-KP": "Korean (North Korea)", "ko-KR": "Korean (South Korea)", la: "Latin", lv: "Latvian", lt: "Lithuanian", lb: "Luxembourgish", mk: "FYRO Macedonian", ms: "Malay", ml: "Malayalam", mt: "Maltese", mi: "Maori", mr: "Marathi", mo: "Moldavian", nv: "Navajo", ng: "Ndonga", ne: "Nepali", no: "Norwegian", nb: "Norwegian (Bokmal)", nn: "Norwegian (Nynorsk)", oc: "Occitan", or: "Oriya", om: "Oromo", fa: "Persian", "fa-IR": "Persian/Iran", pl: "Polish", pt: "Portuguese", "pt-BR": "Portuguese (Brazil)", pa: "Punjabi", "pa-IN": "Punjabi (India)", "pa-PK": "Punjabi (Pakistan)", qu: "Quechua", rm: "Rhaeto-Romanic", ro: "Romanian", "ro-MO": "Romanian (Moldavia)", ru: "Russian", "ru-MO": "Russian (Moldavia)", sz: "Sami (Lappish)", sg: "Sango", sa: "Sanskrit", sc: "Sardinian", sd: "Sindhi", si: "Singhalese", sr: "Serbian", sk: "Slovak", sl: "Slovenian", so: "Somani", sb: "Sorbian", es: "Spanish", "es-AR": "Spanish (Argentina)", "es-BO": "Spanish (Bolivia)", "es-CL": "Spanish (Chile)", "es-CO": "Spanish (Colombia)", "es-CR": "Spanish (Costa Rica)", "es-DO": "Spanish (Dominican Republic)", "es-EC": "Spanish (Ecuador)", "es-SV": "Spanish (El Salvador)", "es-GT": "Spanish (Guatemala)", "es-HN": "Spanish (Honduras)", "es-MX": "Spanish (Mexico)", "es-NI": "Spanish (Nicaragua)", "es-PA": "Spanish (Panama)", "es-PY": "Spanish (Paraguay)", "es-PE": "Spanish (Peru)", "es-PR": "Spanish (Puerto Rico)", "es-ES": "Spanish (Spain)", "es-UY": "Spanish (Uruguay)", "es-VE": "Spanish (Venezuela)", sx: "Sutu", sw: "Swahili", sv: "Swedish", "sv-FI": "Swedish (Finland)", "sv-SV": "Swedish (Sweden)", ta: "Tamil", tt: "Tatar", te: "Teluga", th: "Thai", tig: "Tigre", ts: "Tsonga", tn: "Tswana", tr: "Turkish", tk: "Turkmen", uk: "Ukrainian", hsb: "Upper Sorbian", ur: "Urdu", ve: "Venda", vi: "Vietnamese", vo: "Volapuk", wa: "Walloon", cy: "Welsh", xh: "Xhosa", ji: "Yiddish", zu: "Zulu" }[o] !== void 0 && (this.internal.languageSettings.languageCode = o, this.internal.languageSettings.isSubscribed === !1 && (this.internal.events.subscribe("putCatalog", function() {
        this.internal.write("/Lang (" + this.internal.languageSettings.languageCode + ")");
      }), this.internal.languageSettings.isSubscribed = !0)), this;
    }, /** @preserve
       * jsPDF split_text_to_size plugin - MIT license.
       * Copyright (c) 2012 Willow Systems Corporation, willow-systems.com
       *               2014 Diego Casorran, https://github.com/diegocr
       */
    Ue = Ct.API, ke = Ue.getCharWidthsArray = function(o, p) {
      var C, i, r, n = (p = p || {}).font || this.internal.getFont(), s = p.fontSize || this.internal.getFontSize(), c = p.charSpace || this.internal.getCharSpace(), l = p.widths ? p.widths : n.metadata.Unicode.widths, d = l.fof ? l.fof : 1, B = p.kerning ? p.kerning : n.metadata.Unicode.kerning, h = B.fof ? B.fof : 1, f = 0, m = l[0] || d, w = [];
      for (C = 0, i = o.length; C < i; C++)
        r = o.charCodeAt(C), typeof n.metadata.widthOfString == "function" ? w.push((n.metadata.widthOfGlyph(n.metadata.characterToGlyph(r)) + c * (1e3 / s) || 0) / 1e3) : w.push((l[r] || m) / d + (B[r] && B[r][f] || 0) / h), f = r;
      return w;
    }, wr = Ue.getArraySum = function(o) {
      for (var p = o.length, C = 0; p; )
        C += o[--p];
      return C;
    }, vr = Ue.getStringUnitWidth = function(o, p) {
      var C = (p = p || {}).fontSize || this.internal.getFontSize(), i = p.font || this.internal.getFont(), r = p.charSpace || this.internal.getCharSpace();
      return typeof i.metadata.widthOfString == "function" ? i.metadata.widthOfString(o, C, r) / C : wr(ke.apply(this, arguments));
    }, ar = function(o, p, C, i) {
      for (var r = [], n = 0, s = o.length, c = 0; n !== s && c + p[n] < C; )
        c += p[n], n++;
      r.push(o.slice(0, n));
      var l = n;
      for (c = 0; n !== s; )
        c + p[n] > i && (r.push(o.slice(l, n)), c = 0, l = n), c += p[n], n++;
      return l !== n && r.push(o.slice(l, n)), r;
    }, me = function(o, p, C) {
      C || (C = {});
      var i, r, n, s, c, l, d = [], B = [d], h = C.textIndent || 0, f = 0, m = 0, w = o.split(" "), U = ke.apply(this, [" ", C])[0];
      if (l = C.lineIndent === -1 ? w[0].length + 2 : C.lineIndent || 0) {
        var I = Array(l).join(" "), S = [];
        w.map(function(j) {
          1 < (j = j.split(/\s*\n/)).length ? S = S.concat(j.map(function(Z, W) {
            return (W && Z.length ? `
` : "") + Z;
          })) : S.push(j[0]);
        }), w = S, l = vr.apply(this, [I, C]);
      }
      for (n = 0, s = w.length; n < s; n++) {
        var L = 0;
        if (i = w[n], l && i[0] == `
` && (i = i.substr(1), L = 1), r = ke.apply(this, [i, C]), p < h + f + (m = wr(r)) || L) {
          if (p < m) {
            for (c = ar.apply(this, [i, r, p - (h + f), p]), d.push(c.shift()), d = [c.pop()]; c.length; )
              B.push([c.shift()]);
            m = wr(r.slice(i.length - (d[0] ? d[0].length : 0)));
          } else
            d = [i];
          B.push(d), h = m + l, f = U;
        } else
          d.push(i), h += f + m, f = U;
      }
      if (l)
        var N = function(j, Z) {
          return (Z ? I : "") + j.join(" ");
        };
      else
        N = function(j) {
          return j.join(" ");
        };
      return B.map(N);
    }, Ue.splitTextToSize = function(o, p, C) {
      var i, r = (C = C || {}).fontSize || this.internal.getFontSize(), n = (function(B) {
        var h = { 0: 1 }, f = {};
        if (B.widths && B.kerning)
          return { widths: B.widths, kerning: B.kerning };
        var m = this.internal.getFont(B.fontName, B.fontStyle), w = "Unicode";
        return m.metadata[w] ? { widths: m.metadata[w].widths || h, kerning: m.metadata[w].kerning || f } : { font: m.metadata, fontSize: this.internal.getFontSize(), charSpace: this.internal.getCharSpace() };
      }).call(this, C);
      i = Array.isArray(o) ? o : o.split(/\r?\n/);
      var s = 1 * this.internal.scaleFactor * p / r;
      n.textIndent = C.textIndent ? 1 * C.textIndent * this.internal.scaleFactor / r : 0, n.lineIndent = C.lineIndent;
      var c, l, d = [];
      for (c = 0, l = i.length; c < l; c++)
        d = d.concat(me.apply(this, [i[c], s, n]));
      return d;
    }, /** @preserve 
      jsPDF standard_fonts_metrics plugin
      Copyright (c) 2012 Willow Systems Corporation, willow-systems.com
      MIT license.
      */
    Ge = Ct.API, Ft = { codePages: ["WinAnsiEncoding"], WinAnsiEncoding: (dt = function(o) {
      for (var p = "klmnopqrstuvwxyz", C = {}, i = 0; i < p.length; i++)
        C[p[i]] = "0123456789abcdef"[i];
      var r, n, s, c, l, d = {}, B = 1, h = d, f = [], m = "", w = "", U = o.length - 1;
      for (i = 1; i != U; )
        l = o[i], i += 1, l == "'" ? n ? (c = n.join(""), n = r) : n = [] : n ? n.push(l) : l == "{" ? (f.push([h, c]), h = {}, c = r) : l == "}" ? ((s = f.pop())[0][s[1]] = h, c = r, h = s[0]) : l == "-" ? B = -1 : c === r ? C.hasOwnProperty(l) ? (m += C[l], c = parseInt(m, 16) * B, B = 1, m = "") : m += l : C.hasOwnProperty(l) ? (w += C[l], h[c] = parseInt(w, 16) * B, B = 1, c = r, w = "") : w += l;
      return d;
    })("{19m8n201n9q201o9r201s9l201t9m201u8m201w9n201x9o201y8o202k8q202l8r202m9p202q8p20aw8k203k8t203t8v203u9v2cq8s212m9t15m8w15n9w2dw9s16k8u16l9u17s9z17x8y17y9y}") }, Le = {
      Unicode: { Courier: Ft, "Courier-Bold": Ft, "Courier-BoldOblique": Ft, "Courier-Oblique": Ft, Helvetica: Ft, "Helvetica-Bold": Ft, "Helvetica-BoldOblique": Ft, "Helvetica-Oblique": Ft, "Times-Roman": Ft, "Times-Bold": Ft, "Times-BoldItalic": Ft, "Times-Italic": Ft }
      /** 
          Resources:
          Font metrics data is reprocessed derivative of contents of
          "Font Metrics for PDF Core 14 Fonts" package, which exhibits the following copyright and license:
          
          Copyright (c) 1989, 1990, 1991, 1992, 1993, 1997 Adobe Systems Incorporated. All Rights Reserved.
          
          This file and the 14 PostScript(R) AFM files it accompanies may be used,
          copied, and distributed for any purpose and without charge, with or without
          modification, provided that all copyright notices are retained; that the AFM
          files are not distributed without this file; that all modifications to this
          file or any of the AFM files are prominently noted in the modified file(s);
          and that this paragraph is not modified. Adobe Systems has no responsibility
          or obligation to support the use of the AFM files.
          
          */
    }, ve = { Unicode: { "Courier-Oblique": dt("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"), "Times-BoldItalic": dt("{'widths'{k3o2q4ycx2r201n3m201o6o201s2l201t2l201u2l201w3m201x3m201y3m2k1t2l2r202m2n2n3m2o3m2p5n202q6o2r1w2s2l2t2l2u3m2v3t2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v2l3w3t3x3t3y3t3z3m4k5n4l4m4m4m4n4m4o4s4p4m4q4m4r4s4s4y4t2r4u3m4v4m4w3x4x5t4y4s4z4s5k3x5l4s5m4m5n3r5o3x5p4s5q4m5r5t5s4m5t3x5u3x5v2l5w1w5x2l5y3t5z3m6k2l6l3m6m3m6n2w6o3m6p2w6q2l6r3m6s3r6t1w6u1w6v3m6w1w6x4y6y3r6z3m7k3m7l3m7m2r7n2r7o1w7p3r7q2w7r4m7s3m7t2w7u2r7v2n7w1q7x2n7y3t202l3mcl4mal2ram3man3mao3map3mar3mas2lat4uau1uav3maw3way4uaz2lbk2sbl3t'fof'6obo2lbp3tbq3mbr1tbs2lbu1ybv3mbz3mck4m202k3mcm4mcn4mco4mcp4mcq5ycr4mcs4mct4mcu4mcv4mcw2r2m3rcy2rcz2rdl4sdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek3mel3mem3men3meo3mep3meq4ser2wes2wet2weu2wev2wew1wex1wey1wez1wfl3rfm3mfn3mfo3mfp3mfq3mfr3tfs3mft3rfu3rfv3rfw3rfz2w203k6o212m6o2dw2l2cq2l3t3m3u2l17s3x19m3m}'kerning'{cl{4qu5kt5qt5rs17ss5ts}201s{201ss}201t{cks4lscmscnscoscpscls2wu2yu201ts}201x{2wu2yu}2k{201ts}2w{4qx5kx5ou5qx5rs17su5tu}2x{17su5tu5ou}2y{4qx5kx5ou5qx5rs17ss5ts}'fof'-6ofn{17sw5tw5ou5qw5rs}7t{cksclscmscnscoscps4ls}3u{17su5tu5os5qs}3v{17su5tu5os5qs}7p{17su5tu}ck{4qu5kt5qt5rs17ss5ts}4l{4qu5kt5qt5rs17ss5ts}cm{4qu5kt5qt5rs17ss5ts}cn{4qu5kt5qt5rs17ss5ts}co{4qu5kt5qt5rs17ss5ts}cp{4qu5kt5qt5rs17ss5ts}6l{4qu5ou5qw5rt17su5tu}5q{ckuclucmucnucoucpu4lu}5r{ckuclucmucnucoucpu4lu}7q{cksclscmscnscoscps4ls}6p{4qu5ou5qw5rt17sw5tw}ek{4qu5ou5qw5rt17su5tu}el{4qu5ou5qw5rt17su5tu}em{4qu5ou5qw5rt17su5tu}en{4qu5ou5qw5rt17su5tu}eo{4qu5ou5qw5rt17su5tu}ep{4qu5ou5qw5rt17su5tu}es{17ss5ts5qs4qu}et{4qu5ou5qw5rt17sw5tw}eu{4qu5ou5qw5rt17ss5ts}ev{17ss5ts5qs4qu}6z{17sw5tw5ou5qw5rs}fm{17sw5tw5ou5qw5rs}7n{201ts}fo{17sw5tw5ou5qw5rs}fp{17sw5tw5ou5qw5rs}fq{17sw5tw5ou5qw5rs}7r{cksclscmscnscoscps4ls}fs{17sw5tw5ou5qw5rs}ft{17su5tu}fu{17su5tu}fv{17su5tu}fw{17su5tu}fz{cksclscmscnscoscps4ls}}}"), "Helvetica-Bold": dt("{'widths'{k3s2q4scx1w201n3r201o6o201s1w201t1w201u1w201w3m201x3m201y3m2k1w2l2l202m2n2n3r2o3r2p5t202q6o2r1s2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v2l3w3u3x3u3y3u3z3x4k6l4l4s4m4s4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3r4v4s4w3x4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v2l5w1w5x2l5y3u5z3r6k2l6l3r6m3x6n3r6o3x6p3r6q2l6r3x6s3x6t1w6u1w6v3r6w1w6x5t6y3x6z3x7k3x7l3x7m2r7n3r7o2l7p3x7q3r7r4y7s3r7t3r7u3m7v2r7w1w7x2r7y3u202l3rcl4sal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3xbq3rbr1wbs2lbu2obv3rbz3xck4s202k3rcm4scn4sco4scp4scq6ocr4scs4mct4mcu4mcv4mcw1w2m2zcy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3res3ret3reu3rev3rew1wex1wey1wez1wfl3xfm3xfn3xfo3xfp3xfq3xfr3ufs3xft3xfu3xfv3xfw3xfz3r203k6o212m6o2dw2l2cq2l3t3r3u2l17s4m19m3r}'kerning'{cl{4qs5ku5ot5qs17sv5tv}201t{2ww4wy2yw}201w{2ks}201x{2ww4wy2yw}2k{201ts201xs}2w{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}2x{5ow5qs}2y{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}'fof'-6o7p{17su5tu5ot}ck{4qs5ku5ot5qs17sv5tv}4l{4qs5ku5ot5qs17sv5tv}cm{4qs5ku5ot5qs17sv5tv}cn{4qs5ku5ot5qs17sv5tv}co{4qs5ku5ot5qs17sv5tv}cp{4qs5ku5ot5qs17sv5tv}6l{17st5tt5os}17s{2kwclvcmvcnvcovcpv4lv4wwckv}5o{2kucltcmtcntcotcpt4lt4wtckt}5q{2ksclscmscnscoscps4ls4wvcks}5r{2ks4ws}5t{2kwclvcmvcnvcovcpv4lv4wwckv}eo{17st5tt5os}fu{17su5tu5ot}6p{17ss5ts}ek{17st5tt5os}el{17st5tt5os}em{17st5tt5os}en{17st5tt5os}6o{201ts}ep{17st5tt5os}es{17ss5ts}et{17ss5ts}eu{17ss5ts}ev{17ss5ts}6z{17su5tu5os5qt}fm{17su5tu5os5qt}fn{17su5tu5os5qt}fo{17su5tu5os5qt}fp{17su5tu5os5qt}fq{17su5tu5os5qt}fs{17su5tu5os5qt}ft{17su5tu5ot}7m{5os}fv{17su5tu5ot}fw{17su5tu5ot}}}"), Courier: dt("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"), "Courier-BoldOblique": dt("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"), "Times-Bold": dt("{'widths'{k3q2q5ncx2r201n3m201o6o201s2l201t2l201u2l201w3m201x3m201y3m2k1t2l2l202m2n2n3m2o3m2p6o202q6o2r1w2s2l2t2l2u3m2v3t2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v2l3w3t3x3t3y3t3z3m4k5x4l4s4m4m4n4s4o4s4p4m4q3x4r4y4s4y4t2r4u3m4v4y4w4m4x5y4y4s4z4y5k3x5l4y5m4s5n3r5o4m5p4s5q4s5r6o5s4s5t4s5u4m5v2l5w1w5x2l5y3u5z3m6k2l6l3m6m3r6n2w6o3r6p2w6q2l6r3m6s3r6t1w6u2l6v3r6w1w6x5n6y3r6z3m7k3r7l3r7m2w7n2r7o2l7p3r7q3m7r4s7s3m7t3m7u2w7v2r7w1q7x2r7y3o202l3mcl4sal2lam3man3mao3map3mar3mas2lat4uau1yav3maw3tay4uaz2lbk2sbl3t'fof'6obo2lbp3rbr1tbs2lbu2lbv3mbz3mck4s202k3mcm4scn4sco4scp4scq6ocr4scs4mct4mcu4mcv4mcw2r2m3rcy2rcz2rdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3rek3mel3mem3men3meo3mep3meq4ser2wes2wet2weu2wev2wew1wex1wey1wez1wfl3rfm3mfn3mfo3mfp3mfq3mfr3tfs3mft3rfu3rfv3rfw3rfz3m203k6o212m6o2dw2l2cq2l3t3m3u2l17s4s19m3m}'kerning'{cl{4qt5ks5ot5qy5rw17sv5tv}201t{cks4lscmscnscoscpscls4wv}2k{201ts}2w{4qu5ku7mu5os5qx5ru17su5tu}2x{17su5tu5ou5qs}2y{4qv5kv7mu5ot5qz5ru17su5tu}'fof'-6o7t{cksclscmscnscoscps4ls}3u{17su5tu5os5qu}3v{17su5tu5os5qu}fu{17su5tu5ou5qu}7p{17su5tu5ou5qu}ck{4qt5ks5ot5qy5rw17sv5tv}4l{4qt5ks5ot5qy5rw17sv5tv}cm{4qt5ks5ot5qy5rw17sv5tv}cn{4qt5ks5ot5qy5rw17sv5tv}co{4qt5ks5ot5qy5rw17sv5tv}cp{4qt5ks5ot5qy5rw17sv5tv}6l{17st5tt5ou5qu}17s{ckuclucmucnucoucpu4lu4wu}5o{ckuclucmucnucoucpu4lu4wu}5q{ckzclzcmzcnzcozcpz4lz4wu}5r{ckxclxcmxcnxcoxcpx4lx4wu}5t{ckuclucmucnucoucpu4lu4wu}7q{ckuclucmucnucoucpu4lu}6p{17sw5tw5ou5qu}ek{17st5tt5qu}el{17st5tt5ou5qu}em{17st5tt5qu}en{17st5tt5qu}eo{17st5tt5qu}ep{17st5tt5ou5qu}es{17ss5ts5qu}et{17sw5tw5ou5qu}eu{17sw5tw5ou5qu}ev{17ss5ts5qu}6z{17sw5tw5ou5qu5rs}fm{17sw5tw5ou5qu5rs}fn{17sw5tw5ou5qu5rs}fo{17sw5tw5ou5qu5rs}fp{17sw5tw5ou5qu5rs}fq{17sw5tw5ou5qu5rs}7r{cktcltcmtcntcotcpt4lt5os}fs{17sw5tw5ou5qu5rs}ft{17su5tu5ou5qu}7m{5os}fv{17su5tu5ou5qu}fw{17su5tu5ou5qu}fz{cksclscmscnscoscps4ls}}}"), Symbol: dt("{'widths'{k3uaw4r19m3m2k1t2l2l202m2y2n3m2p5n202q6o3k3m2s2l2t2l2v3r2w1t3m3m2y1t2z1wbk2sbl3r'fof'6o3n3m3o3m3p3m3q3m3r3m3s3m3t3m3u1w3v1w3w3r3x3r3y3r3z2wbp3t3l3m5v2l5x2l5z3m2q4yfr3r7v3k7w1o7x3k}'kerning'{'fof'-6o}}"), Helvetica: dt("{'widths'{k3p2q4mcx1w201n3r201o6o201s1q201t1q201u1q201w2l201x2l201y2l2k1w2l1w202m2n2n3r2o3r2p5t202q6o2r1n2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v1w3w3u3x3u3y3u3z3r4k6p4l4m4m4m4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3m4v4m4w3r4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v1w5w1w5x1w5y2z5z3r6k2l6l3r6m3r6n3m6o3r6p3r6q1w6r3r6s3r6t1q6u1q6v3m6w1q6x5n6y3r6z3r7k3r7l3r7m2l7n3m7o1w7p3r7q3m7r4s7s3m7t3m7u3m7v2l7w1u7x2l7y3u202l3rcl4mal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3rbr1wbs2lbu2obv3rbz3xck4m202k3rcm4mcn4mco4mcp4mcq6ocr4scs4mct4mcu4mcv4mcw1w2m2ncy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3mes3ret3reu3rev3rew1wex1wey1wez1wfl3rfm3rfn3rfo3rfp3rfq3rfr3ufs3xft3rfu3rfv3rfw3rfz3m203k6o212m6o2dw2l2cq2l3t3r3u1w17s4m19m3r}'kerning'{5q{4wv}cl{4qs5kw5ow5qs17sv5tv}201t{2wu4w1k2yu}201x{2wu4wy2yu}17s{2ktclucmucnu4otcpu4lu4wycoucku}2w{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}2x{17sy5ty5oy5qs}2y{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}'fof'-6o7p{17sv5tv5ow}ck{4qs5kw5ow5qs17sv5tv}4l{4qs5kw5ow5qs17sv5tv}cm{4qs5kw5ow5qs17sv5tv}cn{4qs5kw5ow5qs17sv5tv}co{4qs5kw5ow5qs17sv5tv}cp{4qs5kw5ow5qs17sv5tv}6l{17sy5ty5ow}do{17st5tt}4z{17st5tt}7s{fst}dm{17st5tt}dn{17st5tt}5o{ckwclwcmwcnwcowcpw4lw4wv}dp{17st5tt}dq{17st5tt}7t{5ow}ds{17st5tt}5t{2ktclucmucnu4otcpu4lu4wycoucku}fu{17sv5tv5ow}6p{17sy5ty5ow5qs}ek{17sy5ty5ow}el{17sy5ty5ow}em{17sy5ty5ow}en{5ty}eo{17sy5ty5ow}ep{17sy5ty5ow}es{17sy5ty5qs}et{17sy5ty5ow5qs}eu{17sy5ty5ow5qs}ev{17sy5ty5ow5qs}6z{17sy5ty5ow5qs}fm{17sy5ty5ow5qs}fn{17sy5ty5ow5qs}fo{17sy5ty5ow5qs}fp{17sy5ty5qs}fq{17sy5ty5ow5qs}7r{5ow}fs{17sy5ty5ow5qs}ft{17sv5tv5ow}7m{5ow}fv{17sv5tv5ow}fw{17sv5tv5ow}}}"), "Helvetica-BoldOblique": dt("{'widths'{k3s2q4scx1w201n3r201o6o201s1w201t1w201u1w201w3m201x3m201y3m2k1w2l2l202m2n2n3r2o3r2p5t202q6o2r1s2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v2l3w3u3x3u3y3u3z3x4k6l4l4s4m4s4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3r4v4s4w3x4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v2l5w1w5x2l5y3u5z3r6k2l6l3r6m3x6n3r6o3x6p3r6q2l6r3x6s3x6t1w6u1w6v3r6w1w6x5t6y3x6z3x7k3x7l3x7m2r7n3r7o2l7p3x7q3r7r4y7s3r7t3r7u3m7v2r7w1w7x2r7y3u202l3rcl4sal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3xbq3rbr1wbs2lbu2obv3rbz3xck4s202k3rcm4scn4sco4scp4scq6ocr4scs4mct4mcu4mcv4mcw1w2m2zcy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3res3ret3reu3rev3rew1wex1wey1wez1wfl3xfm3xfn3xfo3xfp3xfq3xfr3ufs3xft3xfu3xfv3xfw3xfz3r203k6o212m6o2dw2l2cq2l3t3r3u2l17s4m19m3r}'kerning'{cl{4qs5ku5ot5qs17sv5tv}201t{2ww4wy2yw}201w{2ks}201x{2ww4wy2yw}2k{201ts201xs}2w{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}2x{5ow5qs}2y{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}'fof'-6o7p{17su5tu5ot}ck{4qs5ku5ot5qs17sv5tv}4l{4qs5ku5ot5qs17sv5tv}cm{4qs5ku5ot5qs17sv5tv}cn{4qs5ku5ot5qs17sv5tv}co{4qs5ku5ot5qs17sv5tv}cp{4qs5ku5ot5qs17sv5tv}6l{17st5tt5os}17s{2kwclvcmvcnvcovcpv4lv4wwckv}5o{2kucltcmtcntcotcpt4lt4wtckt}5q{2ksclscmscnscoscps4ls4wvcks}5r{2ks4ws}5t{2kwclvcmvcnvcovcpv4lv4wwckv}eo{17st5tt5os}fu{17su5tu5ot}6p{17ss5ts}ek{17st5tt5os}el{17st5tt5os}em{17st5tt5os}en{17st5tt5os}6o{201ts}ep{17st5tt5os}es{17ss5ts}et{17ss5ts}eu{17ss5ts}ev{17ss5ts}6z{17su5tu5os5qt}fm{17su5tu5os5qt}fn{17su5tu5os5qt}fo{17su5tu5os5qt}fp{17su5tu5os5qt}fq{17su5tu5os5qt}fs{17su5tu5os5qt}ft{17su5tu5ot}7m{5os}fv{17su5tu5ot}fw{17su5tu5ot}}}"), ZapfDingbats: dt("{'widths'{k4u2k1w'fof'6o}'kerning'{'fof'-6o}}"), "Courier-Bold": dt("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"), "Times-Italic": dt("{'widths'{k3n2q4ycx2l201n3m201o5t201s2l201t2l201u2l201w3r201x3r201y3r2k1t2l2l202m2n2n3m2o3m2p5n202q5t2r1p2s2l2t2l2u3m2v4n2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v2l3w4n3x4n3y4n3z3m4k5w4l3x4m3x4n4m4o4s4p3x4q3x4r4s4s4s4t2l4u2w4v4m4w3r4x5n4y4m4z4s5k3x5l4s5m3x5n3m5o3r5p4s5q3x5r5n5s3x5t3r5u3r5v2r5w1w5x2r5y2u5z3m6k2l6l3m6m3m6n2w6o3m6p2w6q1w6r3m6s3m6t1w6u1w6v2w6w1w6x4s6y3m6z3m7k3m7l3m7m2r7n2r7o1w7p3m7q2w7r4m7s2w7t2w7u2r7v2s7w1v7x2s7y3q202l3mcl3xal2ram3man3mao3map3mar3mas2lat4wau1vav3maw4nay4waz2lbk2sbl4n'fof'6obo2lbp3mbq3obr1tbs2lbu1zbv3mbz3mck3x202k3mcm3xcn3xco3xcp3xcq5tcr4mcs3xct3xcu3xcv3xcw2l2m2ucy2lcz2ldl4mdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek3mel3mem3men3meo3mep3meq4mer2wes2wet2weu2wev2wew1wex1wey1wez1wfl3mfm3mfn3mfo3mfp3mfq3mfr4nfs3mft3mfu3mfv3mfw3mfz2w203k6o212m6m2dw2l2cq2l3t3m3u2l17s3r19m3m}'kerning'{cl{5kt4qw}201s{201sw}201t{201tw2wy2yy6q-t}201x{2wy2yy}2k{201tw}2w{7qs4qy7rs5ky7mw5os5qx5ru17su5tu}2x{17ss5ts5os}2y{7qs4qy7rs5ky7mw5os5qx5ru17su5tu}'fof'-6o6t{17ss5ts5qs}7t{5os}3v{5qs}7p{17su5tu5qs}ck{5kt4qw}4l{5kt4qw}cm{5kt4qw}cn{5kt4qw}co{5kt4qw}cp{5kt4qw}6l{4qs5ks5ou5qw5ru17su5tu}17s{2ks}5q{ckvclvcmvcnvcovcpv4lv}5r{ckuclucmucnucoucpu4lu}5t{2ks}6p{4qs5ks5ou5qw5ru17su5tu}ek{4qs5ks5ou5qw5ru17su5tu}el{4qs5ks5ou5qw5ru17su5tu}em{4qs5ks5ou5qw5ru17su5tu}en{4qs5ks5ou5qw5ru17su5tu}eo{4qs5ks5ou5qw5ru17su5tu}ep{4qs5ks5ou5qw5ru17su5tu}es{5ks5qs4qs}et{4qs5ks5ou5qw5ru17su5tu}eu{4qs5ks5qw5ru17su5tu}ev{5ks5qs4qs}ex{17ss5ts5qs}6z{4qv5ks5ou5qw5ru17su5tu}fm{4qv5ks5ou5qw5ru17su5tu}fn{4qv5ks5ou5qw5ru17su5tu}fo{4qv5ks5ou5qw5ru17su5tu}fp{4qv5ks5ou5qw5ru17su5tu}fq{4qv5ks5ou5qw5ru17su5tu}7r{5os}fs{4qv5ks5ou5qw5ru17su5tu}ft{17su5tu5qs}fu{17su5tu5qs}fv{17su5tu5qs}fw{17su5tu5qs}}}"), "Times-Roman": dt("{'widths'{k3n2q4ycx2l201n3m201o6o201s2l201t2l201u2l201w2w201x2w201y2w2k1t2l2l202m2n2n3m2o3m2p5n202q6o2r1m2s2l2t2l2u3m2v3s2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v1w3w3s3x3s3y3s3z2w4k5w4l4s4m4m4n4m4o4s4p3x4q3r4r4s4s4s4t2l4u2r4v4s4w3x4x5t4y4s4z4s5k3r5l4s5m4m5n3r5o3x5p4s5q4s5r5y5s4s5t4s5u3x5v2l5w1w5x2l5y2z5z3m6k2l6l2w6m3m6n2w6o3m6p2w6q2l6r3m6s3m6t1w6u1w6v3m6w1w6x4y6y3m6z3m7k3m7l3m7m2l7n2r7o1w7p3m7q3m7r4s7s3m7t3m7u2w7v3k7w1o7x3k7y3q202l3mcl4sal2lam3man3mao3map3mar3mas2lat4wau1vav3maw3say4waz2lbk2sbl3s'fof'6obo2lbp3mbq2xbr1tbs2lbu1zbv3mbz2wck4s202k3mcm4scn4sco4scp4scq5tcr4mcs3xct3xcu3xcv3xcw2l2m2tcy2lcz2ldl4sdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek2wel2wem2wen2weo2wep2weq4mer2wes2wet2weu2wev2wew1wex1wey1wez1wfl3mfm3mfn3mfo3mfp3mfq3mfr3sfs3mft3mfu3mfv3mfw3mfz3m203k6o212m6m2dw2l2cq2l3t3m3u1w17s4s19m3m}'kerning'{cl{4qs5ku17sw5ou5qy5rw201ss5tw201ws}201s{201ss}201t{ckw4lwcmwcnwcowcpwclw4wu201ts}2k{201ts}2w{4qs5kw5os5qx5ru17sx5tx}2x{17sw5tw5ou5qu}2y{4qs5kw5os5qx5ru17sx5tx}'fof'-6o7t{ckuclucmucnucoucpu4lu5os5rs}3u{17su5tu5qs}3v{17su5tu5qs}7p{17sw5tw5qs}ck{4qs5ku17sw5ou5qy5rw201ss5tw201ws}4l{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cm{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cn{4qs5ku17sw5ou5qy5rw201ss5tw201ws}co{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cp{4qs5ku17sw5ou5qy5rw201ss5tw201ws}6l{17su5tu5os5qw5rs}17s{2ktclvcmvcnvcovcpv4lv4wuckv}5o{ckwclwcmwcnwcowcpw4lw4wu}5q{ckyclycmycnycoycpy4ly4wu5ms}5r{cktcltcmtcntcotcpt4lt4ws}5t{2ktclvcmvcnvcovcpv4lv4wuckv}7q{cksclscmscnscoscps4ls}6p{17su5tu5qw5rs}ek{5qs5rs}el{17su5tu5os5qw5rs}em{17su5tu5os5qs5rs}en{17su5qs5rs}eo{5qs5rs}ep{17su5tu5os5qw5rs}es{5qs}et{17su5tu5qw5rs}eu{17su5tu5qs5rs}ev{5qs}6z{17sv5tv5os5qx5rs}fm{5os5qt5rs}fn{17sv5tv5os5qx5rs}fo{17sv5tv5os5qx5rs}fp{5os5qt5rs}fq{5os5qt5rs}7r{ckuclucmucnucoucpu4lu5os}fs{17sv5tv5os5qx5rs}ft{17ss5ts5qs}fu{17sw5tw5qs}fv{17sw5tw5qs}fw{17ss5ts5qs}fz{ckuclucmucnucoucpu4lu5os5rs}}}"), "Helvetica-Oblique": dt("{'widths'{k3p2q4mcx1w201n3r201o6o201s1q201t1q201u1q201w2l201x2l201y2l2k1w2l1w202m2n2n3r2o3r2p5t202q6o2r1n2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v1w3w3u3x3u3y3u3z3r4k6p4l4m4m4m4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3m4v4m4w3r4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v1w5w1w5x1w5y2z5z3r6k2l6l3r6m3r6n3m6o3r6p3r6q1w6r3r6s3r6t1q6u1q6v3m6w1q6x5n6y3r6z3r7k3r7l3r7m2l7n3m7o1w7p3r7q3m7r4s7s3m7t3m7u3m7v2l7w1u7x2l7y3u202l3rcl4mal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3rbr1wbs2lbu2obv3rbz3xck4m202k3rcm4mcn4mco4mcp4mcq6ocr4scs4mct4mcu4mcv4mcw1w2m2ncy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3mes3ret3reu3rev3rew1wex1wey1wez1wfl3rfm3rfn3rfo3rfp3rfq3rfr3ufs3xft3rfu3rfv3rfw3rfz3m203k6o212m6o2dw2l2cq2l3t3r3u1w17s4m19m3r}'kerning'{5q{4wv}cl{4qs5kw5ow5qs17sv5tv}201t{2wu4w1k2yu}201x{2wu4wy2yu}17s{2ktclucmucnu4otcpu4lu4wycoucku}2w{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}2x{17sy5ty5oy5qs}2y{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}'fof'-6o7p{17sv5tv5ow}ck{4qs5kw5ow5qs17sv5tv}4l{4qs5kw5ow5qs17sv5tv}cm{4qs5kw5ow5qs17sv5tv}cn{4qs5kw5ow5qs17sv5tv}co{4qs5kw5ow5qs17sv5tv}cp{4qs5kw5ow5qs17sv5tv}6l{17sy5ty5ow}do{17st5tt}4z{17st5tt}7s{fst}dm{17st5tt}dn{17st5tt}5o{ckwclwcmwcnwcowcpw4lw4wv}dp{17st5tt}dq{17st5tt}7t{5ow}ds{17st5tt}5t{2ktclucmucnu4otcpu4lu4wycoucku}fu{17sv5tv5ow}6p{17sy5ty5ow5qs}ek{17sy5ty5ow}el{17sy5ty5ow}em{17sy5ty5ow}en{5ty}eo{17sy5ty5ow}ep{17sy5ty5ow}es{17sy5ty5qs}et{17sy5ty5ow5qs}eu{17sy5ty5ow5qs}ev{17sy5ty5ow5qs}6z{17sy5ty5ow5qs}fm{17sy5ty5ow5qs}fn{17sy5ty5ow5qs}fo{17sy5ty5ow5qs}fp{17sy5ty5qs}fq{17sy5ty5ow5qs}7r{5ow}fs{17sy5ty5ow5qs}ft{17sv5tv5ow}7m{5ow}fv{17sv5tv5ow}fw{17sv5tv5ow}}}") } }, Ge.events.push(["addFont", function(o) {
      var p, C, i, r = "Unicode";
      (p = ve[r][o.postScriptName]) && ((C = o.metadata[r] ? o.metadata[r] : o.metadata[r] = {}).widths = p.widths, C.kerning = p.kerning), (i = Le[r][o.postScriptName]) && ((C = o.metadata[r] ? o.metadata[r] : o.metadata[r] = {}).encoding = i).codePages && i.codePages.length && (o.encoding = i.codePages[0]);
    }]), Ce = Ct, typeof self < "u" && self || typeof Jt < "u" && Jt || typeof window < "u" && window || Function("return this")(), Ce.API.events.push(["addFont", function(o) {
      Ce.API.existsFileInVFS(o.postScriptName) ? (o.metadata = Ce.API.TTFFont.open(o.postScriptName, o.fontName, Ce.API.getFileFromVFS(o.postScriptName), o.encoding), o.metadata.Unicode = o.metadata.Unicode || { encoding: {}, kerning: {}, widths: [] }) : 14 < o.id.slice(1) && console.error("Font does not exist in FileInVFS, import fonts or remove declaration doc.addFont('" + o.postScriptName + "').");
    }]), /** @preserve
      jsPDF SVG plugin
      Copyright (c) 2012 Willow Systems Corporation, willow-systems.com
      */
    (De = Ct.API).addSvg = function(o, p, C, i, r) {
      if (p === void 0 || C === void 0)
        throw new Error("addSVG needs values for 'x' and 'y'");
      function n(y) {
        for (var P = parseFloat(y[1]), _ = parseFloat(y[2]), Y = [], $ = 3, hA = y.length; $ < hA; )
          y[$] === "c" ? (Y.push([parseFloat(y[$ + 1]), parseFloat(y[$ + 2]), parseFloat(y[$ + 3]), parseFloat(y[$ + 4]), parseFloat(y[$ + 5]), parseFloat(y[$ + 6])]), $ += 7) : y[$] === "l" ? (Y.push([parseFloat(y[$ + 1]), parseFloat(y[$ + 2])]), $ += 3) : $ += 1;
        return [P, _, Y];
      }
      var s, c, l, d, B, h, f, m, w = (d = document, m = d.createElement("iframe"), B = ".jsPDF_sillysvg_iframe {display:none;position:absolute;}", (f = (h = d).createElement("style")).type = "text/css", f.styleSheet ? f.styleSheet.cssText = B : f.appendChild(h.createTextNode(B)), h.getElementsByTagName("head")[0].appendChild(f), m.name = "childframe", m.setAttribute("width", 0), m.setAttribute("height", 0), m.setAttribute("frameborder", "0"), m.setAttribute("scrolling", "no"), m.setAttribute("seamless", "seamless"), m.setAttribute("class", "jsPDF_sillysvg_iframe"), d.body.appendChild(m), m), U = (s = o, (l = ((c = w).contentWindow || c.contentDocument).document).write(s), l.close(), l.getElementsByTagName("svg")[0]), I = [1, 1], S = parseFloat(U.getAttribute("width")), L = parseFloat(U.getAttribute("height"));
      S && L && (i && r ? I = [i / S, r / L] : i ? I = [i / S, i / S] : r && (I = [r / L, r / L]));
      var N, j, Z, W, V = U.childNodes;
      for (N = 0, j = V.length; N < j; N++)
        (Z = V[N]).tagName && Z.tagName.toUpperCase() === "PATH" && ((W = n(Z.getAttribute("d").split(" ")))[0] = W[0] * I[0] + p, W[1] = W[1] * I[1] + C, this.lines.call(this, W[2], W[0], W[1], I));
      return this;
    }, De.addSVG = De.addSvg, De.addSvgAsImage = function(o, p, C, i, r, n, s, c) {
      if (isNaN(p) || isNaN(C))
        throw console.error("jsPDF.addSvgAsImage: Invalid coordinates", arguments), new Error("Invalid coordinates passed to jsPDF.addSvgAsImage");
      if (isNaN(i) || isNaN(r))
        throw console.error("jsPDF.addSvgAsImage: Invalid measurements", arguments), new Error("Invalid measurements (width and/or height) passed to jsPDF.addSvgAsImage");
      var l = document.createElement("canvas");
      l.width = i, l.height = r;
      var d = l.getContext("2d");
      return d.fillStyle = "#fff", d.fillRect(0, 0, l.width, l.height), canvg(l, o, { ignoreMouse: !0, ignoreAnimation: !0, ignoreDimensions: !0, ignoreClear: !0 }), this.addImage(l.toDataURL("image/jpeg", 1), p, C, i, r, s, c), this;
    }, Ct.API.putTotalPages = function(o) {
      for (var p = new RegExp(o, "g"), C = 1; C <= this.internal.getNumberOfPages(); C++)
        for (var i = 0; i < this.internal.pages[C].length; i++)
          this.internal.pages[C][i] = this.internal.pages[C][i].replace(p, this.internal.getNumberOfPages());
      return this;
    }, Ct.API.viewerPreferences = function(o, p) {
      var C;
      o = o || {}, p = p || !1;
      var i, r, n = { HideToolbar: { defaultValue: !1, value: !1, type: "boolean", explicitSet: !1, valueSet: [!0, !1], pdfVersion: 1.3 }, HideMenubar: { defaultValue: !1, value: !1, type: "boolean", explicitSet: !1, valueSet: [!0, !1], pdfVersion: 1.3 }, HideWindowUI: { defaultValue: !1, value: !1, type: "boolean", explicitSet: !1, valueSet: [!0, !1], pdfVersion: 1.3 }, FitWindow: { defaultValue: !1, value: !1, type: "boolean", explicitSet: !1, valueSet: [!0, !1], pdfVersion: 1.3 }, CenterWindow: { defaultValue: !1, value: !1, type: "boolean", explicitSet: !1, valueSet: [!0, !1], pdfVersion: 1.3 }, DisplayDocTitle: { defaultValue: !1, value: !1, type: "boolean", explicitSet: !1, valueSet: [!0, !1], pdfVersion: 1.4 }, NonFullScreenPageMode: { defaultValue: "UseNone", value: "UseNone", type: "name", explicitSet: !1, valueSet: ["UseNone", "UseOutlines", "UseThumbs", "UseOC"], pdfVersion: 1.3 }, Direction: { defaultValue: "L2R", value: "L2R", type: "name", explicitSet: !1, valueSet: ["L2R", "R2L"], pdfVersion: 1.3 }, ViewArea: { defaultValue: "CropBox", value: "CropBox", type: "name", explicitSet: !1, valueSet: ["MediaBox", "CropBox", "TrimBox", "BleedBox", "ArtBox"], pdfVersion: 1.4 }, ViewClip: { defaultValue: "CropBox", value: "CropBox", type: "name", explicitSet: !1, valueSet: ["MediaBox", "CropBox", "TrimBox", "BleedBox", "ArtBox"], pdfVersion: 1.4 }, PrintArea: { defaultValue: "CropBox", value: "CropBox", type: "name", explicitSet: !1, valueSet: ["MediaBox", "CropBox", "TrimBox", "BleedBox", "ArtBox"], pdfVersion: 1.4 }, PrintClip: { defaultValue: "CropBox", value: "CropBox", type: "name", explicitSet: !1, valueSet: ["MediaBox", "CropBox", "TrimBox", "BleedBox", "ArtBox"], pdfVersion: 1.4 }, PrintScaling: { defaultValue: "AppDefault", value: "AppDefault", type: "name", explicitSet: !1, valueSet: ["AppDefault", "None"], pdfVersion: 1.6 }, Duplex: { defaultValue: "", value: "none", type: "name", explicitSet: !1, valueSet: ["Simplex", "DuplexFlipShortEdge", "DuplexFlipLongEdge", "none"], pdfVersion: 1.7 }, PickTrayByPDFSize: { defaultValue: !1, value: !1, type: "boolean", explicitSet: !1, valueSet: [!0, !1], pdfVersion: 1.7 }, PrintPageRange: { defaultValue: "", value: "", type: "array", explicitSet: !1, valueSet: null, pdfVersion: 1.7 }, NumCopies: { defaultValue: 1, value: 1, type: "integer", explicitSet: !1, valueSet: null, pdfVersion: 1.7 } }, s = Object.keys(n), c = [], l = 0, d = 0, B = 0, h = !0;
      function f(w, U) {
        var I, S = !1;
        for (I = 0; I < w.length; I += 1)
          w[I] === U && (S = !0);
        return S;
      }
      if (this.internal.viewerpreferences === void 0 && (this.internal.viewerpreferences = {}, this.internal.viewerpreferences.configuration = JSON.parse(JSON.stringify(n)), this.internal.viewerpreferences.isSubscribed = !1), C = this.internal.viewerpreferences.configuration, o === "reset" || p === !0) {
        var m = s.length;
        for (B = 0; B < m; B += 1)
          C[s[B]].value = C[s[B]].defaultValue, C[s[B]].explicitSet = !1;
      }
      if ((o === void 0 ? "undefined" : Ot(o)) === "object") {
        for (i in o)
          if (r = o[i], f(s, i) && r !== void 0) {
            if (C[i].type === "boolean" && typeof r == "boolean")
              C[i].value = r;
            else if (C[i].type === "name" && f(C[i].valueSet, r))
              C[i].value = r;
            else if (C[i].type === "integer" && Number.isInteger(r))
              C[i].value = r;
            else if (C[i].type === "array") {
              for (l = 0; l < r.length; l += 1)
                if (h = !0, r[l].length === 1 && typeof r[l][0] == "number")
                  c.push(String(r[l]));
                else if (1 < r[l].length) {
                  for (d = 0; d < r[l].length; d += 1)
                    typeof r[l][d] != "number" && (h = !1);
                  h === !0 && c.push(String(r[l].join("-")));
                }
              C[i].value = String(c);
            } else
              C[i].value = C[i].defaultValue;
            C[i].explicitSet = !0;
          }
      }
      return this.internal.viewerpreferences.isSubscribed === !1 && (this.internal.events.subscribe("putCatalog", function() {
        var w, U = [];
        for (w in C)
          C[w].explicitSet === !0 && (C[w].type === "name" ? U.push("/" + w + " /" + C[w].value) : U.push("/" + w + " " + C[w].value));
        U.length !== 0 && this.internal.write(`/ViewerPreferences
<<
` + U.join(`
`) + `
>>`);
      }), this.internal.viewerpreferences.isSubscribed = !0), this.internal.viewerpreferences.configuration = C, this;
    }, /** ==================================================================== 
       * jsPDF XMP metadata plugin
       * Copyright (c) 2016 Jussi Utunen, u-jussi@suomi24.fi
       * 
       * 
       * ====================================================================
       */
    cr = Ct.API, ye = lr = Ve = "", cr.addMetadata = function(o, p) {
      return lr = p || "http://jspdf.default.namespaceuri/", Ve = o, this.internal.events.subscribe("postPutResources", function() {
        if (Ve) {
          var C = '<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><rdf:Description rdf:about="" xmlns:jspdf="' + lr + '"><jspdf:metadata>', i = unescape(encodeURIComponent('<x:xmpmeta xmlns:x="adobe:ns:meta/">')), r = unescape(encodeURIComponent(C)), n = unescape(encodeURIComponent(Ve)), s = unescape(encodeURIComponent("</jspdf:metadata></rdf:Description></rdf:RDF>")), c = unescape(encodeURIComponent("</x:xmpmeta>")), l = r.length + n.length + s.length + i.length + c.length;
          ye = this.internal.newObject(), this.internal.write("<< /Type /Metadata /Subtype /XML /Length " + l + " >>"), this.internal.write("stream"), this.internal.write(i + r + n + s + c), this.internal.write("endstream"), this.internal.write("endobj");
        } else
          ye = "";
      }), this.internal.events.subscribe("putCatalog", function() {
        ye && this.internal.write("/Metadata " + ye + " 0 R");
      }), this;
    }, function(o, p) {
      var C = o.API, i = [0];
      C.events.push(["putFont", function(n) {
        (function(s, c, l) {
          if (s.metadata instanceof o.API.TTFFont && s.encoding === "Identity-H") {
            for (var d = s.metadata.Unicode.widths, B = s.metadata.subset.encode(i), h = "", f = 0; f < B.length; f++)
              h += String.fromCharCode(B[f]);
            var m = l();
            c("<<"), c("/Length " + h.length), c("/Length1 " + h.length), c(">>"), c("stream"), c(h), c("endstream"), c("endobj");
            var w = l();
            c("<<"), c("/Type /FontDescriptor"), c("/FontName /" + s.fontName), c("/FontFile2 " + m + " 0 R"), c("/FontBBox " + o.API.PDFObject.convert(s.metadata.bbox)), c("/Flags " + s.metadata.flags), c("/StemV " + s.metadata.stemV), c("/ItalicAngle " + s.metadata.italicAngle), c("/Ascent " + s.metadata.ascender), c("/Descent " + s.metadata.decender), c("/CapHeight " + s.metadata.capHeight), c(">>"), c("endobj");
            var U = l();
            c("<<"), c("/Type /Font"), c("/BaseFont /" + s.fontName), c("/FontDescriptor " + w + " 0 R"), c("/W " + o.API.PDFObject.convert(d)), c("/CIDToGIDMap /Identity"), c("/DW 1000"), c("/Subtype /CIDFontType2"), c("/CIDSystemInfo"), c("<<"), c("/Supplement 0"), c("/Registry (Adobe)"), c("/Ordering (" + s.encoding + ")"), c(">>"), c(">>"), c("endobj"), s.objectNumber = l(), c("<<"), c("/Type /Font"), c("/Subtype /Type0"), c("/BaseFont /" + s.fontName), c("/Encoding /" + s.encoding), c("/DescendantFonts [" + U + " 0 R]"), c(">>"), c("endobj"), s.isAlreadyPutted = !0;
          }
        })(n.font, n.out, n.newObject);
      }]), C.events.push(["putFont", function(n) {
        (function(s, c, l) {
          if (s.metadata instanceof o.API.TTFFont && s.encoding === "WinAnsiEncoding") {
            s.metadata.Unicode.widths;
            for (var d = s.metadata.rawData, B = "", h = 0; h < d.length; h++)
              B += String.fromCharCode(d[h]);
            var f = l();
            c("<<"), c("/Length " + B.length), c("/Length1 " + B.length), c(">>"), c("stream"), c(B), c("endstream"), c("endobj");
            var m = l();
            for (c("<<"), c("/Descent " + s.metadata.decender), c("/CapHeight " + s.metadata.capHeight), c("/StemV " + s.metadata.stemV), c("/Type /FontDescriptor"), c("/FontFile2 " + f + " 0 R"), c("/Flags 96"), c("/FontBBox " + o.API.PDFObject.convert(s.metadata.bbox)), c("/FontName /" + s.fontName), c("/ItalicAngle " + s.metadata.italicAngle), c("/Ascent " + s.metadata.ascender), c(">>"), c("endobj"), s.objectNumber = l(), h = 0; h < s.metadata.hmtx.widths.length; h++)
              s.metadata.hmtx.widths[h] = parseInt(s.metadata.hmtx.widths[h] * (1e3 / s.metadata.head.unitsPerEm));
            c("<</Subtype/TrueType/Type/Font/BaseFont/" + s.fontName + "/FontDescriptor " + m + " 0 R/Encoding/" + s.encoding + " /FirstChar 29 /LastChar 255 /Widths " + o.API.PDFObject.convert(s.metadata.hmtx.widths) + ">>"), c("endobj"), s.isAlreadyPutted = !0;
          }
        })(n.font, n.out, n.newObject);
      }]);
      var r = function(n) {
        var s, c, l = n.text || "", d = n.x, B = n.y, h = n.options || {}, f = n.mutex || {}, m = f.pdfEscape, w = f.activeFontKey, U = f.fonts, I = (f.activeFontSize, ""), S = 0, L = "", N = U[c = w].encoding;
        if (U[c].encoding !== "Identity-H")
          return { text: l, x: d, y: B, options: h, mutex: f };
        for (L = l, c = w, Object.prototype.toString.call(l) === "[object Array]" && (L = l[0]), S = 0; S < L.length; S += 1)
          U[c].metadata.hasOwnProperty("cmap") && (s = U[c].metadata.cmap.unicode.codeMap[L[S].charCodeAt(0)]), s || L[S].charCodeAt(0) < 256 && U[c].metadata.hasOwnProperty("Unicode") ? I += L[S] : I += "";
        var j = "";
        return parseInt(c.slice(1)) < 14 || N === "WinAnsiEncoding" ? j = function(Z) {
          for (var W = "", V = 0; V < Z.length; V++)
            W += "" + Z.charCodeAt(V).toString(16);
          return W;
        }(m(I, c)) : N === "Identity-H" && (j = function(Z, W) {
          for (var V, y = W.metadata.Unicode.widths, P = ["", "0", "00", "000", "0000"], _ = [""], Y = 0, $ = Z.length; Y < $; ++Y) {
            if (V = W.metadata.characterToGlyph(Z.charCodeAt(Y)), i.push(V), y.indexOf(V) == -1 && (y.push(V), y.push([parseInt(W.metadata.widthOfGlyph(V), 10)])), V == "0")
              return _.join("");
            V = V.toString(16), _.push(P[4 - V.length], V);
          }
          return _.join("");
        }(I, U[c])), f.isHex = !0, { text: j, x: d, y: B, options: h, mutex: f };
      };
      C.events.push(["postProcessText", function(n) {
        var s = n.text || "", c = n.x, l = n.y, d = n.options, B = n.mutex, h = (d.lang, []), f = { text: s, x: c, y: l, options: d, mutex: B };
        if (Object.prototype.toString.call(s) === "[object Array]") {
          var m = 0;
          for (m = 0; m < s.length; m += 1)
            Object.prototype.toString.call(s[m]) === "[object Array]" && s[m].length === 3 ? h.push([r(Object.assign({}, f, { text: s[m][0] })).text, s[m][1], s[m][2]]) : h.push(r(Object.assign({}, f, { text: s[m] })).text);
          n.text = h;
        } else
          n.text = r(Object.assign({}, f, { text: s })).text;
      }]);
    }(Ct, typeof self < "u" && self || typeof Jt < "u" && Jt || typeof window < "u" && window || Function("return this")()), Ar = Ct.API, Te = {}, Ar.existsFileInVFS = function(o) {
      return Te.hasOwnProperty(o);
    }, Ar.addFileToVFS = function(o, p) {
      return Te[o] = p, this;
    }, Ar.getFileFromVFS = function(o) {
      return Te.hasOwnProperty(o) ? Te[o] : null;
    }, function(o) {
      if (o.URL = o.URL || o.webkitURL, o.Blob && o.URL)
        try {
          return new Blob();
        } catch {
        }
      var p = o.BlobBuilder || o.WebKitBlobBuilder || o.MozBlobBuilder || function(i) {
        var r = function(W) {
          return Object.prototype.toString.call(W).match(/^\[object\s(.*)\]$/)[1];
        }, n = function() {
          this.data = [];
        }, s = function(W, V, y) {
          this.data = W, this.size = W.length, this.type = V, this.encoding = y;
        }, c = n.prototype, l = s.prototype, d = i.FileReaderSync, B = function(W) {
          this.code = this[this.name = W];
        }, h = "NOT_FOUND_ERR SECURITY_ERR ABORT_ERR NOT_READABLE_ERR ENCODING_ERR NO_MODIFICATION_ALLOWED_ERR INVALID_STATE_ERR SYNTAX_ERR".split(" "), f = h.length, m = i.URL || i.webkitURL || i, w = m.createObjectURL, U = m.revokeObjectURL, I = m, S = i.btoa, L = i.atob, N = i.ArrayBuffer, j = i.Uint8Array, Z = /^[\w-]+:\/*\[?[\w\.:-]+\]?(?::[0-9]+)?/;
        for (s.fake = l.fake = !0; f--; )
          B.prototype[h[f]] = f + 1;
        return m.createObjectURL || (I = i.URL = function(W) {
          var V, y = document.createElementNS("http://www.w3.org/1999/xhtml", "a");
          return y.href = W, "origin" in y || (y.protocol.toLowerCase() === "data:" ? y.origin = null : (V = W.match(Z), y.origin = V && V[1])), y;
        }), I.createObjectURL = function(W) {
          var V, y = W.type;
          return y === null && (y = "application/octet-stream"), W instanceof s ? (V = "data:" + y, W.encoding === "base64" ? V + ";base64," + W.data : W.encoding === "URI" ? V + "," + decodeURIComponent(W.data) : S ? V + ";base64," + S(W.data) : V + "," + encodeURIComponent(W.data)) : w ? w.call(m, W) : void 0;
        }, I.revokeObjectURL = function(W) {
          W.substring(0, 5) !== "data:" && U && U.call(m, W);
        }, c.append = function(W) {
          var V = this.data;
          if (j && (W instanceof N || W instanceof j)) {
            for (var y = "", P = new j(W), _ = 0, Y = P.length; _ < Y; _++)
              y += String.fromCharCode(P[_]);
            V.push(y);
          } else if (r(W) === "Blob" || r(W) === "File") {
            if (!d)
              throw new B("NOT_READABLE_ERR");
            var $ = new d();
            V.push($.readAsBinaryString(W));
          } else
            W instanceof s ? W.encoding === "base64" && L ? V.push(L(W.data)) : W.encoding === "URI" ? V.push(decodeURIComponent(W.data)) : W.encoding === "raw" && V.push(W.data) : (typeof W != "string" && (W += ""), V.push(unescape(encodeURIComponent(W))));
        }, c.getBlob = function(W) {
          return arguments.length || (W = null), new s(this.data.join(""), W, "raw");
        }, c.toString = function() {
          return "[object BlobBuilder]";
        }, l.slice = function(W, V, y) {
          var P = arguments.length;
          return P < 3 && (y = null), new s(this.data.slice(W, 1 < P ? V : this.data.length), y, this.encoding);
        }, l.toString = function() {
          return "[object Blob]";
        }, l.close = function() {
          this.size = 0, delete this.data;
        }, n;
      }(o);
      o.Blob = function(i, r) {
        var n = r && r.type || "", s = new p();
        if (i)
          for (var c = 0, l = i.length; c < l; c++)
            Uint8Array && i[c] instanceof Uint8Array ? s.append(i[c].buffer) : s.append(i[c]);
        var d = s.getBlob(n);
        return !d.slice && d.webkitSlice && (d.slice = d.webkitSlice), d;
      };
      var C = Object.getPrototypeOf || function(i) {
        return i.__proto__;
      };
      o.Blob.prototype = C(new o.Blob());
    }(typeof self < "u" && self || typeof window < "u" && window || window.content || window);
    var Kr, lt, mr, Ut, Qe, UA, HA, TA, WA, nt, tt, Lt, Fe, Vt, tr, br, er = er || function(o) {
      if (!(o === void 0 || typeof navigator < "u" && /MSIE [1-9]\./.test(navigator.userAgent))) {
        var p = o.document, C = function() {
          return o.URL || o.webkitURL || o;
        }, i = p.createElementNS("http://www.w3.org/1999/xhtml", "a"), r = "download" in i, n = /constructor/i.test(o.HTMLElement) || o.safari, s = /CriOS\/[\d]+/.test(navigator.userAgent), c = function(f) {
          (o.setImmediate || o.setTimeout)(function() {
            throw f;
          }, 0);
        }, l = function(f) {
          setTimeout(function() {
            typeof f == "string" ? C().revokeObjectURL(f) : f.remove();
          }, 4e4);
        }, d = function(f) {
          return /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(f.type) ? new Blob([String.fromCharCode(65279), f], { type: f.type }) : f;
        }, B = function(f, m, w) {
          w || (f = d(f));
          var U, I = this, S = f.type === "application/octet-stream", L = function() {
            (function(N, j, Z) {
              for (var W = (j = [].concat(j)).length; W--; ) {
                var V = N["on" + j[W]];
                if (typeof V == "function")
                  try {
                    V.call(N, Z || N);
                  } catch (y) {
                    c(y);
                  }
              }
            })(I, "writestart progress write writeend".split(" "));
          };
          if (I.readyState = I.INIT, r)
            return U = C().createObjectURL(f), void setTimeout(function() {
              var N, j;
              i.href = U, i.download = m, N = i, j = new MouseEvent("click"), N.dispatchEvent(j), L(), l(U), I.readyState = I.DONE;
            });
          (function() {
            if ((s || S && n) && o.FileReader) {
              var N = new FileReader();
              return N.onloadend = function() {
                var j = s ? N.result : N.result.replace(/^data:[^;]*;/, "data:attachment/file;");
                o.open(j, "_blank") || (o.location.href = j), j = void 0, I.readyState = I.DONE, L();
              }, N.readAsDataURL(f), I.readyState = I.INIT;
            }
            U || (U = C().createObjectURL(f)), S ? o.location.href = U : o.open(U, "_blank") || (o.location.href = U), I.readyState = I.DONE, L(), l(U);
          })();
        }, h = B.prototype;
        return typeof navigator < "u" && navigator.msSaveOrOpenBlob ? function(f, m, w) {
          return m = m || f.name || "download", w || (f = d(f)), navigator.msSaveOrOpenBlob(f, m);
        } : (h.abort = function() {
        }, h.readyState = h.INIT = 0, h.WRITING = 1, h.DONE = 2, h.error = h.onwritestart = h.onprogress = h.onwrite = h.onabort = h.onerror = h.onwriteend = null, function(f, m, w) {
          return new B(f, m || f.name || "download", w);
        });
      }
    }(typeof self < "u" && self || typeof window < "u" && window || window.content);
    function tn(o) {
      var p = 0;
      if (o[p++] !== 71 || o[p++] !== 73 || o[p++] !== 70 || o[p++] !== 56 || (o[p++] + 1 & 253) != 56 || o[p++] !== 97)
        throw "Invalid GIF 87a/89a header.";
      var C = o[p++] | o[p++] << 8, i = o[p++] | o[p++] << 8, r = o[p++], n = r >> 7, s = 1 << (7 & r) + 1;
      o[p++], o[p++];
      var c = null;
      n && (c = p, p += 3 * s);
      var l = !0, d = [], B = 0, h = null, f = 0, m = null;
      for (this.width = C, this.height = i; l && p < o.length; )
        switch (o[p++]) {
          case 33:
            switch (o[p++]) {
              case 255:
                if (o[p] !== 11 || o[p + 1] == 78 && o[p + 2] == 69 && o[p + 3] == 84 && o[p + 4] == 83 && o[p + 5] == 67 && o[p + 6] == 65 && o[p + 7] == 80 && o[p + 8] == 69 && o[p + 9] == 50 && o[p + 10] == 46 && o[p + 11] == 48 && o[p + 12] == 3 && o[p + 13] == 1 && o[p + 16] == 0)
                  p += 14, m = o[p++] | o[p++] << 8, p++;
                else
                  for (p += 12; (y = o[p++]) !== 0; )
                    p += y;
                break;
              case 249:
                if (o[p++] !== 4 || o[p + 4] !== 0)
                  throw "Invalid graphics extension block.";
                var w = o[p++];
                B = o[p++] | o[p++] << 8, h = o[p++], !(1 & w) && (h = null), f = w >> 2 & 7, p++;
                break;
              case 254:
                for (; (y = o[p++]) !== 0; )
                  p += y;
                break;
              default:
                throw "Unknown graphic control label: 0x" + o[p - 1].toString(16);
            }
            break;
          case 44:
            var U = o[p++] | o[p++] << 8, I = o[p++] | o[p++] << 8, S = o[p++] | o[p++] << 8, L = o[p++] | o[p++] << 8, N = o[p++], j = N >> 6 & 1, Z = c, W = !1;
            N >> 7 && (W = !0, Z = p, p += 3 * (1 << (7 & N) + 1));
            var V = p;
            for (p++; ; ) {
              var y;
              if ((y = o[p++]) === 0)
                break;
              p += y;
            }
            d.push({ x: U, y: I, width: S, height: L, has_local_palette: W, palette_offset: Z, data_offset: V, data_length: p - V, transparent_index: h, interlaced: !!j, delay: B, disposal: f });
            break;
          case 59:
            l = !1;
            break;
          default:
            throw "Unknown gif block: 0x" + o[p - 1].toString(16);
        }
      this.numFrames = function() {
        return d.length;
      }, this.loopCount = function() {
        return m;
      }, this.frameInfo = function(P) {
        if (P < 0 || P >= d.length)
          throw "Frame index out of range.";
        return d[P];
      }, this.decodeAndBlitFrameBGRA = function(P, _) {
        var Y = this.frameInfo(P), $ = Y.width * Y.height, hA = new Uint8Array($);
        rr(o, Y.data_offset, hA, $);
        var z = Y.palette_offset, k = Y.transparent_index;
        k === null && (k = 256);
        var F = Y.width, R = C - F, E = F, G = 4 * (Y.y * C + Y.x), M = 4 * ((Y.y + Y.height) * C + Y.x), oA = G, X = 4 * R;
        Y.interlaced === !0 && (X += 4 * (F + R) * 7);
        for (var fA = 8, nA = 0, b = hA.length; nA < b; ++nA) {
          var D = hA[nA];
          if (E === 0 && (E = F, M <= (oA += X) && (X = R + 4 * (F + R) * (fA - 1), oA = G + (F + R) * (fA << 1), fA >>= 1)), D === k)
            oA += 4;
          else {
            var u = o[z + 3 * D], Q = o[z + 3 * D + 1], H = o[z + 3 * D + 2];
            _[oA++] = H, _[oA++] = Q, _[oA++] = u, _[oA++] = 255;
          }
          --E;
        }
      }, this.decodeAndBlitFrameRGBA = function(P, _) {
        var Y = this.frameInfo(P), $ = Y.width * Y.height, hA = new Uint8Array($);
        rr(o, Y.data_offset, hA, $);
        var z = Y.palette_offset, k = Y.transparent_index;
        k === null && (k = 256);
        var F = Y.width, R = C - F, E = F, G = 4 * (Y.y * C + Y.x), M = 4 * ((Y.y + Y.height) * C + Y.x), oA = G, X = 4 * R;
        Y.interlaced === !0 && (X += 4 * (F + R) * 7);
        for (var fA = 8, nA = 0, b = hA.length; nA < b; ++nA) {
          var D = hA[nA];
          if (E === 0 && (E = F, M <= (oA += X) && (X = R + 4 * (F + R) * (fA - 1), oA = G + (F + R) * (fA << 1), fA >>= 1)), D === k)
            oA += 4;
          else {
            var u = o[z + 3 * D], Q = o[z + 3 * D + 1], H = o[z + 3 * D + 2];
            _[oA++] = u, _[oA++] = Q, _[oA++] = H, _[oA++] = 255;
          }
          --E;
        }
      };
    }
    function rr(o, p, C, i) {
      for (var r = o[p++], n = 1 << r, s = n + 1, c = s + 1, l = r + 1, d = (1 << l) - 1, B = 0, h = 0, f = 0, m = o[p++], w = new Int32Array(4096), U = null; ; ) {
        for (; B < 16 && m !== 0; )
          h |= o[p++] << B, B += 8, m === 1 ? m = o[p++] : --m;
        if (B < l)
          break;
        var I = h & d;
        if (h >>= l, B -= l, I !== n) {
          if (I === s)
            break;
          for (var S = I < c ? I : U, L = 0, N = S; n < N; )
            N = w[N] >> 8, ++L;
          var j = N;
          if (i < f + L + (S !== I ? 1 : 0))
            return void console.log("Warning, gif stream longer than expected.");
          C[f++] = j;
          var Z = f += L;
          for (S !== I && (C[f++] = j), N = S; L--; )
            N = w[N], C[--Z] = 255 & N, N >>= 8;
          U !== null && c < 4096 && (w[c++] = U << 8 | j, d + 1 <= c && l < 12 && (++l, d = d << 1 | 1)), U = I;
        } else
          c = s + 1, d = (1 << (l = r + 1)) - 1, U = null;
      }
      return f !== i && console.log("Warning, gif stream shorter than expected."), C;
    }
    CA.exports && (CA.exports.saveAs = er), Ct.API.adler32cs = (UA = typeof ArrayBuffer == "function" && typeof Uint8Array == "function", HA = null, TA = function() {
      if (!UA)
        return function() {
          return !1;
        };
      try {
        var o = {};
        typeof o.Buffer == "function" && (HA = o.Buffer);
      } catch {
      }
      return function(p) {
        return p instanceof ArrayBuffer || HA !== null && p instanceof HA;
      };
    }(), WA = HA !== null ? function(o) {
      return new HA(o, "utf8").toString("binary");
    } : function(o) {
      return unescape(encodeURIComponent(o));
    }, nt = 65521, tt = function(o, p) {
      for (var C = 65535 & o, i = o >>> 16, r = 0, n = p.length; r < n; r++)
        C = (C + (255 & p.charCodeAt(r))) % nt, i = (i + C) % nt;
      return (i << 16 | C) >>> 0;
    }, Lt = function(o, p) {
      for (var C = 65535 & o, i = o >>> 16, r = 0, n = p.length; r < n; r++)
        C = (C + p[r]) % nt, i = (i + C) % nt;
      return (i << 16 | C) >>> 0;
    }, Vt = (Fe = {}).Adler32 = (((Qe = (Ut = function(o) {
      if (!(this instanceof Ut))
        throw new TypeError("Constructor cannot called be as a function.");
      if (!isFinite(o = o == null ? 1 : +o))
        throw new Error("First arguments needs to be a finite number.");
      this.checksum = o >>> 0;
    }).prototype = {}).constructor = Ut).from = ((Kr = function(o) {
      if (!(this instanceof Ut))
        throw new TypeError("Constructor cannot called be as a function.");
      if (o == null)
        throw new Error("First argument needs to be a string.");
      this.checksum = tt(1, o.toString());
    }).prototype = Qe, Kr), Ut.fromUtf8 = ((lt = function(o) {
      if (!(this instanceof Ut))
        throw new TypeError("Constructor cannot called be as a function.");
      if (o == null)
        throw new Error("First argument needs to be a string.");
      var p = WA(o.toString());
      this.checksum = tt(1, p);
    }).prototype = Qe, lt), UA && (Ut.fromBuffer = ((mr = function(o) {
      if (!(this instanceof Ut))
        throw new TypeError("Constructor cannot called be as a function.");
      if (!TA(o))
        throw new Error("First argument needs to be ArrayBuffer.");
      var p = new Uint8Array(o);
      return this.checksum = Lt(1, p);
    }).prototype = Qe, mr)), Qe.update = function(o) {
      if (o == null)
        throw new Error("First argument needs to be a string.");
      return o = o.toString(), this.checksum = tt(this.checksum, o);
    }, Qe.updateUtf8 = function(o) {
      if (o == null)
        throw new Error("First argument needs to be a string.");
      var p = WA(o.toString());
      return this.checksum = tt(this.checksum, p);
    }, UA && (Qe.updateBuffer = function(o) {
      if (!TA(o))
        throw new Error("First argument needs to be ArrayBuffer.");
      var p = new Uint8Array(o);
      return this.checksum = Lt(this.checksum, p);
    }), Qe.clone = function() {
      return new Vt(this.checksum);
    }, Ut), Fe.from = function(o) {
      if (o == null)
        throw new Error("First argument needs to be a string.");
      return tt(1, o.toString());
    }, Fe.fromUtf8 = function(o) {
      if (o == null)
        throw new Error("First argument needs to be a string.");
      var p = WA(o.toString());
      return tt(1, p);
    }, UA && (Fe.fromBuffer = function(o) {
      if (!TA(o))
        throw new Error("First argument need to be ArrayBuffer.");
      var p = new Uint8Array(o);
      return Lt(1, p);
    }), Fe);
    try {
      J.GifWriter = function(o, p, C, i) {
        var r = 0, n = (i = i === void 0 ? {} : i).loop === void 0 ? null : i.loop, s = i.palette === void 0 ? null : i.palette;
        if (p <= 0 || C <= 0 || 65535 < p || 65535 < C)
          throw "Width/Height invalid.";
        function c(U) {
          var I = U.length;
          if (I < 2 || 256 < I || I & I - 1)
            throw "Invalid code/color length, must be power of 2 and 2 .. 256.";
          return I;
        }
        o[r++] = 71, o[r++] = 73, o[r++] = 70, o[r++] = 56, o[r++] = 57, o[r++] = 97;
        var l = 0, d = 0;
        if (s !== null) {
          for (var B = c(s); B >>= 1; )
            ++l;
          if (B = 1 << l, --l, i.background !== void 0) {
            if (B <= (d = i.background))
              throw "Background index out of range.";
            if (d === 0)
              throw "Background index explicitly passed as 0.";
          }
        }
        if (o[r++] = 255 & p, o[r++] = p >> 8 & 255, o[r++] = 255 & C, o[r++] = C >> 8 & 255, o[r++] = (s !== null ? 128 : 0) | l, o[r++] = d, o[r++] = 0, s !== null)
          for (var h = 0, f = s.length; h < f; ++h) {
            var m = s[h];
            o[r++] = m >> 16 & 255, o[r++] = m >> 8 & 255, o[r++] = 255 & m;
          }
        if (n !== null) {
          if (n < 0 || 65535 < n)
            throw "Loop count invalid.";
          o[r++] = 33, o[r++] = 255, o[r++] = 11, o[r++] = 78, o[r++] = 69, o[r++] = 84, o[r++] = 83, o[r++] = 67, o[r++] = 65, o[r++] = 80, o[r++] = 69, o[r++] = 50, o[r++] = 46, o[r++] = 48, o[r++] = 3, o[r++] = 1, o[r++] = 255 & n, o[r++] = n >> 8 & 255, o[r++] = 0;
        }
        var w = !1;
        this.addFrame = function(U, I, S, L, N, j) {
          if (w === !0 && (--r, w = !1), j = j === void 0 ? {} : j, U < 0 || I < 0 || 65535 < U || 65535 < I)
            throw "x/y invalid.";
          if (S <= 0 || L <= 0 || 65535 < S || 65535 < L)
            throw "Width/Height invalid.";
          if (N.length < S * L)
            throw "Not enough pixels for the frame size.";
          var Z = !0, W = j.palette;
          if (W == null && (Z = !1, W = s), W == null)
            throw "Must supply either a local or global palette.";
          for (var V = c(W), y = 0; V >>= 1; )
            ++y;
          V = 1 << y;
          var P = j.delay === void 0 ? 0 : j.delay, _ = j.disposal === void 0 ? 0 : j.disposal;
          if (_ < 0 || 3 < _)
            throw "Disposal out of range.";
          var Y = !1, $ = 0;
          if (j.transparent !== void 0 && j.transparent !== null && (Y = !0, ($ = j.transparent) < 0 || V <= $))
            throw "Transparent color index.";
          if ((_ !== 0 || Y || P !== 0) && (o[r++] = 33, o[r++] = 249, o[r++] = 4, o[r++] = _ << 2 | (Y === !0 ? 1 : 0), o[r++] = 255 & P, o[r++] = P >> 8 & 255, o[r++] = $, o[r++] = 0), o[r++] = 44, o[r++] = 255 & U, o[r++] = U >> 8 & 255, o[r++] = 255 & I, o[r++] = I >> 8 & 255, o[r++] = 255 & S, o[r++] = S >> 8 & 255, o[r++] = 255 & L, o[r++] = L >> 8 & 255, o[r++] = Z === !0 ? 128 | y - 1 : 0, Z === !0)
            for (var hA = 0, z = W.length; hA < z; ++hA) {
              var k = W[hA];
              o[r++] = k >> 16 & 255, o[r++] = k >> 8 & 255, o[r++] = 255 & k;
            }
          r = function(F, R, E, G) {
            F[R++] = E;
            var M = R++, oA = 1 << E, X = oA - 1, fA = oA + 1, nA = fA + 1, b = E + 1, D = 0, u = 0;
            function Q(xA) {
              for (; xA <= D; )
                F[R++] = 255 & u, u >>= 8, D -= 8, R === M + 256 && (F[M] = 255, M = R++);
            }
            function H(xA) {
              u |= xA << D, D += b, Q(8);
            }
            var O = G[0] & X, eA = {};
            H(oA);
            for (var sA = 1, pA = G.length; sA < pA; ++sA) {
              var yA = G[sA] & X, wA = O << 8 | yA, SA = eA[wA];
              if (SA === void 0) {
                for (u |= O << D, D += b; 8 <= D; )
                  F[R++] = 255 & u, u >>= 8, D -= 8, R === M + 256 && (F[M] = 255, M = R++);
                nA === 4096 ? (H(oA), nA = fA + 1, b = E + 1, eA = {}) : (1 << b <= nA && ++b, eA[wA] = nA++), O = yA;
              } else
                O = SA;
            }
            return H(O), H(fA), Q(1), M + 1 === R ? F[M] = 0 : (F[M] = R - M - 1, F[R++] = 0), R;
          }(o, r, y < 2 ? 2 : y, N);
        }, this.end = function() {
          return w === !1 && (o[r++] = 59, w = !0), r;
        };
      }, J.GifReader = tn;
    } catch {
    }
    function Cr(o) {
      var p, C, i, r, n, s = Math.floor, c = new Array(64), l = new Array(64), d = new Array(64), B = new Array(64), h = new Array(65535), f = new Array(65535), m = new Array(64), w = new Array(64), U = [], I = 0, S = 7, L = new Array(64), N = new Array(64), j = new Array(64), Z = new Array(256), W = new Array(2048), V = [0, 1, 5, 6, 14, 15, 27, 28, 2, 4, 7, 13, 16, 26, 29, 42, 3, 8, 12, 17, 25, 30, 41, 43, 9, 11, 18, 24, 31, 40, 44, 53, 10, 19, 23, 32, 39, 45, 52, 54, 20, 22, 33, 38, 46, 51, 55, 60, 21, 34, 37, 47, 50, 56, 59, 61, 35, 36, 48, 49, 57, 58, 62, 63], y = [0, 0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0], P = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], _ = [0, 0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 125], Y = [1, 2, 3, 0, 4, 17, 5, 18, 33, 49, 65, 6, 19, 81, 97, 7, 34, 113, 20, 50, 129, 145, 161, 8, 35, 66, 177, 193, 21, 82, 209, 240, 36, 51, 98, 114, 130, 9, 10, 22, 23, 24, 25, 26, 37, 38, 39, 40, 41, 42, 52, 53, 54, 55, 56, 57, 58, 67, 68, 69, 70, 71, 72, 73, 74, 83, 84, 85, 86, 87, 88, 89, 90, 99, 100, 101, 102, 103, 104, 105, 106, 115, 116, 117, 118, 119, 120, 121, 122, 131, 132, 133, 134, 135, 136, 137, 138, 146, 147, 148, 149, 150, 151, 152, 153, 154, 162, 163, 164, 165, 166, 167, 168, 169, 170, 178, 179, 180, 181, 182, 183, 184, 185, 186, 194, 195, 196, 197, 198, 199, 200, 201, 202, 210, 211, 212, 213, 214, 215, 216, 217, 218, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250], $ = [0, 0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0], hA = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], z = [0, 0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 119], k = [0, 1, 2, 3, 17, 4, 5, 33, 49, 6, 18, 65, 81, 7, 97, 113, 19, 34, 50, 129, 8, 20, 66, 145, 161, 177, 193, 9, 35, 51, 82, 240, 21, 98, 114, 209, 10, 22, 36, 52, 225, 37, 241, 23, 24, 25, 26, 38, 39, 40, 41, 42, 53, 54, 55, 56, 57, 58, 67, 68, 69, 70, 71, 72, 73, 74, 83, 84, 85, 86, 87, 88, 89, 90, 99, 100, 101, 102, 103, 104, 105, 106, 115, 116, 117, 118, 119, 120, 121, 122, 130, 131, 132, 133, 134, 135, 136, 137, 138, 146, 147, 148, 149, 150, 151, 152, 153, 154, 162, 163, 164, 165, 166, 167, 168, 169, 170, 178, 179, 180, 181, 182, 183, 184, 185, 186, 194, 195, 196, 197, 198, 199, 200, 201, 202, 210, 211, 212, 213, 214, 215, 216, 217, 218, 226, 227, 228, 229, 230, 231, 232, 233, 234, 242, 243, 244, 245, 246, 247, 248, 249, 250];
      function F(X, fA) {
        for (var nA = 0, b = 0, D = new Array(), u = 1; u <= 16; u++) {
          for (var Q = 1; Q <= X[u]; Q++)
            D[fA[b]] = [], D[fA[b]][0] = nA, D[fA[b]][1] = u, b++, nA++;
          nA *= 2;
        }
        return D;
      }
      function R(X) {
        for (var fA = X[0], nA = X[1] - 1; 0 <= nA; )
          fA & 1 << nA && (I |= 1 << S), nA--, --S < 0 && (I == 255 ? (E(255), E(0)) : E(I), S = 7, I = 0);
      }
      function E(X) {
        U.push(X);
      }
      function G(X) {
        E(X >> 8 & 255), E(255 & X);
      }
      function M(X, fA, nA, b, D) {
        for (var u, Q = D[0], H = D[240], O = function(iA, yt) {
          var $A, st, kt, jA, gt, bt, ht, ct, xt, Pt, JA = 0;
          for (xt = 0; xt < 8; ++xt) {
            $A = iA[JA], st = iA[JA + 1], kt = iA[JA + 2], jA = iA[JA + 3], gt = iA[JA + 4], bt = iA[JA + 5], ht = iA[JA + 6];
            var ee = $A + (ct = iA[JA + 7]), oe = $A - ct, be = st + ht, Ke = st - ht, Yt = kt + bt, K = kt - bt, aA = jA + gt, gA = jA - gt, tA = ee + aA, AA = ee - aA, dA = be + Yt, QA = be - Yt;
            iA[JA] = tA + dA, iA[JA + 4] = tA - dA;
            var bA = 0.707106781 * (QA + AA);
            iA[JA + 2] = AA + bA, iA[JA + 6] = AA - bA;
            var EA = 0.382683433 * ((tA = gA + K) - (QA = Ke + oe)), _A = 0.5411961 * tA + EA, et = 1.306562965 * QA + EA, VA = 0.707106781 * (dA = K + Ke), it = oe + VA, mt = oe - VA;
            iA[JA + 5] = mt + _A, iA[JA + 3] = mt - _A, iA[JA + 1] = it + et, iA[JA + 7] = it - et, JA += 8;
          }
          for (xt = JA = 0; xt < 8; ++xt) {
            $A = iA[JA], st = iA[JA + 8], kt = iA[JA + 16], jA = iA[JA + 24], gt = iA[JA + 32], bt = iA[JA + 40], ht = iA[JA + 48];
            var qt = $A + (ct = iA[JA + 56]), se = $A - ct, ae = st + ht, xr = st - ht, Mt = kt + bt, ce = kt - bt, Ir = jA + gt, qe = jA - gt, Xt = qt + Ir, ur = qt - Ir, yr = ae + Mt, Qr = ae - Mt;
            iA[JA] = Xt + yr, iA[JA + 32] = Xt - yr;
            var hr = 0.707106781 * (Qr + ur);
            iA[JA + 16] = ur + hr, iA[JA + 48] = ur - hr;
            var le = 0.382683433 * ((Xt = qe + ce) - (Qr = xr + se)), _r = 0.5411961 * Xt + le, Er = 1.306562965 * Qr + le, Or = 0.707106781 * (yr = ce + xr), fr = se + Or, nr = se - Or;
            iA[JA + 40] = nr + _r, iA[JA + 24] = nr - _r, iA[JA + 8] = fr + Er, iA[JA + 56] = fr - Er, JA++;
          }
          for (xt = 0; xt < 64; ++xt)
            Pt = iA[xt] * yt[xt], m[xt] = 0 < Pt ? Pt + 0.5 | 0 : Pt - 0.5 | 0;
          return m;
        }(X, fA), eA = 0; eA < 64; ++eA)
          w[V[eA]] = O[eA];
        var sA = w[0] - nA;
        nA = w[0], sA == 0 ? R(b[0]) : (R(b[f[u = 32767 + sA]]), R(h[u]));
        for (var pA = 63; 0 < pA && w[pA] == 0; pA--)
          ;
        if (pA == 0)
          return R(Q), nA;
        for (var yA, wA = 1; wA <= pA; ) {
          for (var SA = wA; w[wA] == 0 && wA <= pA; ++wA)
            ;
          var xA = wA - SA;
          if (16 <= xA) {
            yA = xA >> 4;
            for (var KA = 1; KA <= yA; ++KA)
              R(H);
            xA &= 15;
          }
          u = 32767 + w[wA], R(D[(xA << 4) + f[u]]), R(h[u]), wA++;
        }
        return pA != 63 && R(Q), nA;
      }
      function oA(X) {
        X <= 0 && (X = 1), 100 < X && (X = 100), n != X && (function(fA) {
          for (var nA = [16, 11, 10, 16, 24, 40, 51, 61, 12, 12, 14, 19, 26, 58, 60, 55, 14, 13, 16, 24, 40, 57, 69, 56, 14, 17, 22, 29, 51, 87, 80, 62, 18, 22, 37, 56, 68, 109, 103, 77, 24, 35, 55, 64, 81, 104, 113, 92, 49, 64, 78, 87, 103, 121, 120, 101, 72, 92, 95, 98, 112, 100, 103, 99], b = 0; b < 64; b++) {
            var D = s((nA[b] * fA + 50) / 100);
            D < 1 ? D = 1 : 255 < D && (D = 255), c[V[b]] = D;
          }
          for (var u = [17, 18, 24, 47, 99, 99, 99, 99, 18, 21, 26, 66, 99, 99, 99, 99, 24, 26, 56, 99, 99, 99, 99, 99, 47, 66, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99], Q = 0; Q < 64; Q++) {
            var H = s((u[Q] * fA + 50) / 100);
            H < 1 ? H = 1 : 255 < H && (H = 255), l[V[Q]] = H;
          }
          for (var O = [1, 1.387039845, 1.306562965, 1.175875602, 1, 0.785694958, 0.5411961, 0.275899379], eA = 0, sA = 0; sA < 8; sA++)
            for (var pA = 0; pA < 8; pA++)
              d[eA] = 1 / (c[V[eA]] * O[sA] * O[pA] * 8), B[eA] = 1 / (l[V[eA]] * O[sA] * O[pA] * 8), eA++;
        }(X < 50 ? Math.floor(5e3 / X) : Math.floor(200 - 2 * X)), n = X);
      }
      this.encode = function(X, fA) {
        var nA, b;
        (/* @__PURE__ */ new Date()).getTime(), fA && oA(fA), U = new Array(), I = 0, S = 7, G(65496), G(65504), G(16), E(74), E(70), E(73), E(70), E(0), E(1), E(1), E(0), G(1), G(1), E(0), E(0), function() {
          G(65499), G(132), E(0);
          for (var jA = 0; jA < 64; jA++)
            E(c[jA]);
          E(1);
          for (var gt = 0; gt < 64; gt++)
            E(l[gt]);
        }(), nA = X.width, b = X.height, G(65472), G(17), E(8), G(b), G(nA), E(3), E(1), E(17), E(0), E(2), E(17), E(1), E(3), E(17), E(1), function() {
          G(65476), G(418), E(0);
          for (var jA = 0; jA < 16; jA++)
            E(y[jA + 1]);
          for (var gt = 0; gt <= 11; gt++)
            E(P[gt]);
          E(16);
          for (var bt = 0; bt < 16; bt++)
            E(_[bt + 1]);
          for (var ht = 0; ht <= 161; ht++)
            E(Y[ht]);
          E(1);
          for (var ct = 0; ct < 16; ct++)
            E($[ct + 1]);
          for (var xt = 0; xt <= 11; xt++)
            E(hA[xt]);
          E(17);
          for (var Pt = 0; Pt < 16; Pt++)
            E(z[Pt + 1]);
          for (var JA = 0; JA <= 161; JA++)
            E(k[JA]);
        }(), G(65498), G(12), E(3), E(1), E(0), E(2), E(17), E(3), E(17), E(0), E(63), E(0);
        var D = 0, u = 0, Q = 0;
        I = 0, S = 7, this.encode.displayName = "_encode_";
        for (var H, O, eA, sA, pA, yA, wA, SA, xA, KA = X.data, iA = X.width, yt = X.height, $A = 4 * iA, st = 0; st < yt; ) {
          for (H = 0; H < $A; ) {
            for (yA = pA = $A * st + H, wA = -1, xA = SA = 0; xA < 64; xA++)
              yA = pA + (SA = xA >> 3) * $A + (wA = 4 * (7 & xA)), yt <= st + SA && (yA -= $A * (st + 1 + SA - yt)), $A <= H + wA && (yA -= H + wA - $A + 4), O = KA[yA++], eA = KA[yA++], sA = KA[yA++], L[xA] = (W[O] + W[eA + 256 >> 0] + W[sA + 512 >> 0] >> 16) - 128, N[xA] = (W[O + 768 >> 0] + W[eA + 1024 >> 0] + W[sA + 1280 >> 0] >> 16) - 128, j[xA] = (W[O + 1280 >> 0] + W[eA + 1536 >> 0] + W[sA + 1792 >> 0] >> 16) - 128;
            D = M(L, d, D, p, i), u = M(N, B, u, C, r), Q = M(j, B, Q, C, r), H += 32;
          }
          st += 8;
        }
        if (0 <= S) {
          var kt = [];
          kt[1] = S + 1, kt[0] = (1 << S + 1) - 1, R(kt);
        }
        return G(65497), new Uint8Array(U);
      }, function() {
        (/* @__PURE__ */ new Date()).getTime(), o || (o = 50), function() {
          for (var X = String.fromCharCode, fA = 0; fA < 256; fA++)
            Z[fA] = X(fA);
        }(), p = F(y, P), C = F($, hA), i = F(_, Y), r = F(z, k), function() {
          for (var X = 1, fA = 2, nA = 1; nA <= 15; nA++) {
            for (var b = X; b < fA; b++)
              f[32767 + b] = nA, h[32767 + b] = [], h[32767 + b][1] = nA, h[32767 + b][0] = b;
            for (var D = -(fA - 1); D <= -X; D++)
              f[32767 + D] = nA, h[32767 + D] = [], h[32767 + D][1] = nA, h[32767 + D][0] = fA - 1 + D;
            X <<= 1, fA <<= 1;
          }
        }(), function() {
          for (var X = 0; X < 256; X++)
            W[X] = 19595 * X, W[X + 256 >> 0] = 38470 * X, W[X + 512 >> 0] = 7471 * X + 32768, W[X + 768 >> 0] = -11059 * X, W[X + 1024 >> 0] = -21709 * X, W[X + 1280 >> 0] = 32768 * X + 8421375, W[X + 1536 >> 0] = -27439 * X, W[X + 1792 >> 0] = -5329 * X;
        }(), oA(o), (/* @__PURE__ */ new Date()).getTime();
      }();
    }
    try {
      CA.exports = Cr;
    } catch {
    }
    function pe(o, p) {
      if (this.pos = 0, this.buffer = o, this.datav = new DataView(o.buffer), this.is_with_alpha = !!p, this.bottom_up = !0, this.flag = String.fromCharCode(this.buffer[0]) + String.fromCharCode(this.buffer[1]), this.pos += 2, ["BM", "BA", "CI", "CP", "IC", "PT"].indexOf(this.flag) === -1)
        throw new Error("Invalid BMP File");
      this.parseHeader(), this.parseBGR();
    }
    pe.prototype.parseHeader = function() {
      if (this.fileSize = this.datav.getUint32(this.pos, !0), this.pos += 4, this.reserved = this.datav.getUint32(this.pos, !0), this.pos += 4, this.offset = this.datav.getUint32(this.pos, !0), this.pos += 4, this.headerSize = this.datav.getUint32(this.pos, !0), this.pos += 4, this.width = this.datav.getUint32(this.pos, !0), this.pos += 4, this.height = this.datav.getInt32(this.pos, !0), this.pos += 4, this.planes = this.datav.getUint16(this.pos, !0), this.pos += 2, this.bitPP = this.datav.getUint16(this.pos, !0), this.pos += 2, this.compress = this.datav.getUint32(this.pos, !0), this.pos += 4, this.rawSize = this.datav.getUint32(this.pos, !0), this.pos += 4, this.hr = this.datav.getUint32(this.pos, !0), this.pos += 4, this.vr = this.datav.getUint32(this.pos, !0), this.pos += 4, this.colors = this.datav.getUint32(this.pos, !0), this.pos += 4, this.importantColors = this.datav.getUint32(this.pos, !0), this.pos += 4, this.bitPP === 16 && this.is_with_alpha && (this.bitPP = 15), this.bitPP < 15) {
        var o = this.colors === 0 ? 1 << this.bitPP : this.colors;
        this.palette = new Array(o);
        for (var p = 0; p < o; p++) {
          var C = this.datav.getUint8(this.pos++, !0), i = this.datav.getUint8(this.pos++, !0), r = this.datav.getUint8(this.pos++, !0), n = this.datav.getUint8(this.pos++, !0);
          this.palette[p] = { red: r, green: i, blue: C, quad: n };
        }
      }
      this.height < 0 && (this.height *= -1, this.bottom_up = !1);
    }, pe.prototype.parseBGR = function() {
      this.pos = this.offset;
      try {
        var o = "bit" + this.bitPP, p = this.width * this.height * 4;
        this.data = new Uint8Array(p), this[o]();
      } catch (C) {
        console.log("bit decode error:" + C);
      }
    }, pe.prototype.bit1 = function() {
      var o = Math.ceil(this.width / 8), p = o % 4, C = 0 <= this.height ? this.height - 1 : -this.height;
      for (C = this.height - 1; 0 <= C; C--) {
        for (var i = this.bottom_up ? C : this.height - 1 - C, r = 0; r < o; r++)
          for (var n = this.datav.getUint8(this.pos++, !0), s = i * this.width * 4 + 8 * r * 4, c = 0; c < 8 && 8 * r + c < this.width; c++) {
            var l = this.palette[n >> 7 - c & 1];
            this.data[s + 4 * c] = l.blue, this.data[s + 4 * c + 1] = l.green, this.data[s + 4 * c + 2] = l.red, this.data[s + 4 * c + 3] = 255;
          }
        p != 0 && (this.pos += 4 - p);
      }
    }, pe.prototype.bit4 = function() {
      for (var o = Math.ceil(this.width / 2), p = o % 4, C = this.height - 1; 0 <= C; C--) {
        for (var i = this.bottom_up ? C : this.height - 1 - C, r = 0; r < o; r++) {
          var n = this.datav.getUint8(this.pos++, !0), s = i * this.width * 4 + 2 * r * 4, c = n >> 4, l = 15 & n, d = this.palette[c];
          if (this.data[s] = d.blue, this.data[s + 1] = d.green, this.data[s + 2] = d.red, this.data[s + 3] = 255, 2 * r + 1 >= this.width)
            break;
          d = this.palette[l], this.data[s + 4] = d.blue, this.data[s + 4 + 1] = d.green, this.data[s + 4 + 2] = d.red, this.data[s + 4 + 3] = 255;
        }
        p != 0 && (this.pos += 4 - p);
      }
    }, pe.prototype.bit8 = function() {
      for (var o = this.width % 4, p = this.height - 1; 0 <= p; p--) {
        for (var C = this.bottom_up ? p : this.height - 1 - p, i = 0; i < this.width; i++) {
          var r = this.datav.getUint8(this.pos++, !0), n = C * this.width * 4 + 4 * i;
          if (r < this.palette.length) {
            var s = this.palette[r];
            this.data[n] = s.red, this.data[n + 1] = s.green, this.data[n + 2] = s.blue, this.data[n + 3] = 255;
          } else
            this.data[n] = 255, this.data[n + 1] = 255, this.data[n + 2] = 255, this.data[n + 3] = 255;
        }
        o != 0 && (this.pos += 4 - o);
      }
    }, pe.prototype.bit15 = function() {
      for (var o = this.width % 3, p = parseInt("11111", 2), C = this.height - 1; 0 <= C; C--) {
        for (var i = this.bottom_up ? C : this.height - 1 - C, r = 0; r < this.width; r++) {
          var n = this.datav.getUint16(this.pos, !0);
          this.pos += 2;
          var s = (n & p) / p * 255 | 0, c = (n >> 5 & p) / p * 255 | 0, l = (n >> 10 & p) / p * 255 | 0, d = n >> 15 ? 255 : 0, B = i * this.width * 4 + 4 * r;
          this.data[B] = l, this.data[B + 1] = c, this.data[B + 2] = s, this.data[B + 3] = d;
        }
        this.pos += o;
      }
    }, pe.prototype.bit16 = function() {
      for (var o = this.width % 3, p = parseInt("11111", 2), C = parseInt("111111", 2), i = this.height - 1; 0 <= i; i--) {
        for (var r = this.bottom_up ? i : this.height - 1 - i, n = 0; n < this.width; n++) {
          var s = this.datav.getUint16(this.pos, !0);
          this.pos += 2;
          var c = (s & p) / p * 255 | 0, l = (s >> 5 & C) / C * 255 | 0, d = (s >> 11) / p * 255 | 0, B = r * this.width * 4 + 4 * n;
          this.data[B] = d, this.data[B + 1] = l, this.data[B + 2] = c, this.data[B + 3] = 255;
        }
        this.pos += o;
      }
    }, pe.prototype.bit24 = function() {
      for (var o = this.height - 1; 0 <= o; o--) {
        for (var p = this.bottom_up ? o : this.height - 1 - o, C = 0; C < this.width; C++) {
          var i = this.datav.getUint8(this.pos++, !0), r = this.datav.getUint8(this.pos++, !0), n = this.datav.getUint8(this.pos++, !0), s = p * this.width * 4 + 4 * C;
          this.data[s] = n, this.data[s + 1] = r, this.data[s + 2] = i, this.data[s + 3] = 255;
        }
        this.pos += this.width % 4;
      }
    }, pe.prototype.bit32 = function() {
      for (var o = this.height - 1; 0 <= o; o--)
        for (var p = this.bottom_up ? o : this.height - 1 - o, C = 0; C < this.width; C++) {
          var i = this.datav.getUint8(this.pos++, !0), r = this.datav.getUint8(this.pos++, !0), n = this.datav.getUint8(this.pos++, !0), s = this.datav.getUint8(this.pos++, !0), c = p * this.width * 4 + 4 * C;
          this.data[c] = n, this.data[c + 1] = r, this.data[c + 2] = i, this.data[c + 3] = s;
        }
    }, pe.prototype.getData = function() {
      return this.data;
    };
    try {
      CA.exports = function(o) {
        var p = new pe(o);
        return { data: p.getData(), width: p.width, height: p.height };
      };
    } catch {
    }
    (function(o) {
      var p = 15, C = 573, i = [0, 1, 2, 3, 4, 4, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 0, 0, 16, 17, 18, 18, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29];
      function r() {
        var w = this;
        function U(I, S) {
          for (var L = 0; L |= 1 & I, I >>>= 1, L <<= 1, 0 < --S; )
            ;
          return L >>> 1;
        }
        w.build_tree = function(I) {
          var S, L, N, j = w.dyn_tree, Z = w.stat_desc.static_tree, W = w.stat_desc.elems, V = -1;
          for (I.heap_len = 0, I.heap_max = C, S = 0; S < W; S++)
            j[2 * S] !== 0 ? (I.heap[++I.heap_len] = V = S, I.depth[S] = 0) : j[2 * S + 1] = 0;
          for (; I.heap_len < 2; )
            j[2 * (N = I.heap[++I.heap_len] = V < 2 ? ++V : 0)] = 1, I.depth[N] = 0, I.opt_len--, Z && (I.static_len -= Z[2 * N + 1]);
          for (w.max_code = V, S = Math.floor(I.heap_len / 2); 1 <= S; S--)
            I.pqdownheap(j, S);
          for (N = W; S = I.heap[1], I.heap[1] = I.heap[I.heap_len--], I.pqdownheap(j, 1), L = I.heap[1], I.heap[--I.heap_max] = S, I.heap[--I.heap_max] = L, j[2 * N] = j[2 * S] + j[2 * L], I.depth[N] = Math.max(I.depth[S], I.depth[L]) + 1, j[2 * S + 1] = j[2 * L + 1] = N, I.heap[1] = N++, I.pqdownheap(j, 1), 2 <= I.heap_len; )
            ;
          I.heap[--I.heap_max] = I.heap[1], function(y) {
            var P, _, Y, $, hA, z, k = w.dyn_tree, F = w.stat_desc.static_tree, R = w.stat_desc.extra_bits, E = w.stat_desc.extra_base, G = w.stat_desc.max_length, M = 0;
            for ($ = 0; $ <= p; $++)
              y.bl_count[$] = 0;
            for (k[2 * y.heap[y.heap_max] + 1] = 0, P = y.heap_max + 1; P < C; P++)
              G < ($ = k[2 * k[2 * (_ = y.heap[P]) + 1] + 1] + 1) && ($ = G, M++), k[2 * _ + 1] = $, _ > w.max_code || (y.bl_count[$]++, hA = 0, E <= _ && (hA = R[_ - E]), z = k[2 * _], y.opt_len += z * ($ + hA), F && (y.static_len += z * (F[2 * _ + 1] + hA)));
            if (M !== 0) {
              do {
                for ($ = G - 1; y.bl_count[$] === 0; )
                  $--;
                y.bl_count[$]--, y.bl_count[$ + 1] += 2, y.bl_count[G]--, M -= 2;
              } while (0 < M);
              for ($ = G; $ !== 0; $--)
                for (_ = y.bl_count[$]; _ !== 0; )
                  (Y = y.heap[--P]) > w.max_code || (k[2 * Y + 1] != $ && (y.opt_len += ($ - k[2 * Y + 1]) * k[2 * Y], k[2 * Y + 1] = $), _--);
            }
          }(I), function(y, P, _) {
            var Y, $, hA, z = [], k = 0;
            for (Y = 1; Y <= p; Y++)
              z[Y] = k = k + _[Y - 1] << 1;
            for ($ = 0; $ <= P; $++)
              (hA = y[2 * $ + 1]) !== 0 && (y[2 * $] = U(z[hA]++, hA));
          }(j, w.max_code, I.bl_count);
        };
      }
      function n(w, U, I, S, L) {
        var N = this;
        N.static_tree = w, N.extra_bits = U, N.extra_base = I, N.elems = S, N.max_length = L;
      }
      r._length_code = [0, 1, 2, 3, 4, 5, 6, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14, 15, 15, 15, 15, 16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 17, 17, 17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 19, 19, 19, 19, 19, 19, 19, 19, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 28], r.base_length = [0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 16, 20, 24, 28, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 0], r.base_dist = [0, 1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512, 768, 1024, 1536, 2048, 3072, 4096, 6144, 8192, 12288, 16384, 24576], r.d_code = function(w) {
        return w < 256 ? i[w] : i[256 + (w >>> 7)];
      }, r.extra_lbits = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0], r.extra_dbits = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13], r.extra_blbits = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7], r.bl_order = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], n.static_ltree = [12, 8, 140, 8, 76, 8, 204, 8, 44, 8, 172, 8, 108, 8, 236, 8, 28, 8, 156, 8, 92, 8, 220, 8, 60, 8, 188, 8, 124, 8, 252, 8, 2, 8, 130, 8, 66, 8, 194, 8, 34, 8, 162, 8, 98, 8, 226, 8, 18, 8, 146, 8, 82, 8, 210, 8, 50, 8, 178, 8, 114, 8, 242, 8, 10, 8, 138, 8, 74, 8, 202, 8, 42, 8, 170, 8, 106, 8, 234, 8, 26, 8, 154, 8, 90, 8, 218, 8, 58, 8, 186, 8, 122, 8, 250, 8, 6, 8, 134, 8, 70, 8, 198, 8, 38, 8, 166, 8, 102, 8, 230, 8, 22, 8, 150, 8, 86, 8, 214, 8, 54, 8, 182, 8, 118, 8, 246, 8, 14, 8, 142, 8, 78, 8, 206, 8, 46, 8, 174, 8, 110, 8, 238, 8, 30, 8, 158, 8, 94, 8, 222, 8, 62, 8, 190, 8, 126, 8, 254, 8, 1, 8, 129, 8, 65, 8, 193, 8, 33, 8, 161, 8, 97, 8, 225, 8, 17, 8, 145, 8, 81, 8, 209, 8, 49, 8, 177, 8, 113, 8, 241, 8, 9, 8, 137, 8, 73, 8, 201, 8, 41, 8, 169, 8, 105, 8, 233, 8, 25, 8, 153, 8, 89, 8, 217, 8, 57, 8, 185, 8, 121, 8, 249, 8, 5, 8, 133, 8, 69, 8, 197, 8, 37, 8, 165, 8, 101, 8, 229, 8, 21, 8, 149, 8, 85, 8, 213, 8, 53, 8, 181, 8, 117, 8, 245, 8, 13, 8, 141, 8, 77, 8, 205, 8, 45, 8, 173, 8, 109, 8, 237, 8, 29, 8, 157, 8, 93, 8, 221, 8, 61, 8, 189, 8, 125, 8, 253, 8, 19, 9, 275, 9, 147, 9, 403, 9, 83, 9, 339, 9, 211, 9, 467, 9, 51, 9, 307, 9, 179, 9, 435, 9, 115, 9, 371, 9, 243, 9, 499, 9, 11, 9, 267, 9, 139, 9, 395, 9, 75, 9, 331, 9, 203, 9, 459, 9, 43, 9, 299, 9, 171, 9, 427, 9, 107, 9, 363, 9, 235, 9, 491, 9, 27, 9, 283, 9, 155, 9, 411, 9, 91, 9, 347, 9, 219, 9, 475, 9, 59, 9, 315, 9, 187, 9, 443, 9, 123, 9, 379, 9, 251, 9, 507, 9, 7, 9, 263, 9, 135, 9, 391, 9, 71, 9, 327, 9, 199, 9, 455, 9, 39, 9, 295, 9, 167, 9, 423, 9, 103, 9, 359, 9, 231, 9, 487, 9, 23, 9, 279, 9, 151, 9, 407, 9, 87, 9, 343, 9, 215, 9, 471, 9, 55, 9, 311, 9, 183, 9, 439, 9, 119, 9, 375, 9, 247, 9, 503, 9, 15, 9, 271, 9, 143, 9, 399, 9, 79, 9, 335, 9, 207, 9, 463, 9, 47, 9, 303, 9, 175, 9, 431, 9, 111, 9, 367, 9, 239, 9, 495, 9, 31, 9, 287, 9, 159, 9, 415, 9, 95, 9, 351, 9, 223, 9, 479, 9, 63, 9, 319, 9, 191, 9, 447, 9, 127, 9, 383, 9, 255, 9, 511, 9, 0, 7, 64, 7, 32, 7, 96, 7, 16, 7, 80, 7, 48, 7, 112, 7, 8, 7, 72, 7, 40, 7, 104, 7, 24, 7, 88, 7, 56, 7, 120, 7, 4, 7, 68, 7, 36, 7, 100, 7, 20, 7, 84, 7, 52, 7, 116, 7, 3, 8, 131, 8, 67, 8, 195, 8, 35, 8, 163, 8, 99, 8, 227, 8], n.static_dtree = [0, 5, 16, 5, 8, 5, 24, 5, 4, 5, 20, 5, 12, 5, 28, 5, 2, 5, 18, 5, 10, 5, 26, 5, 6, 5, 22, 5, 14, 5, 30, 5, 1, 5, 17, 5, 9, 5, 25, 5, 5, 5, 21, 5, 13, 5, 29, 5, 3, 5, 19, 5, 11, 5, 27, 5, 7, 5, 23, 5], n.static_l_desc = new n(n.static_ltree, r.extra_lbits, 257, 286, p), n.static_d_desc = new n(n.static_dtree, r.extra_dbits, 0, 30, p), n.static_bl_desc = new n(null, r.extra_blbits, 0, 19, 7);
      function s(w, U, I, S, L) {
        var N = this;
        N.good_length = w, N.max_lazy = U, N.nice_length = I, N.max_chain = S, N.func = L;
      }
      var c = [new s(0, 0, 0, 0, 0), new s(4, 4, 8, 4, 1), new s(4, 5, 16, 8, 1), new s(4, 6, 32, 32, 1), new s(4, 4, 16, 16, 2), new s(8, 16, 32, 32, 2), new s(8, 16, 128, 128, 2), new s(8, 32, 128, 256, 2), new s(32, 128, 258, 1024, 2), new s(32, 258, 258, 4096, 2)], l = ["need dictionary", "stream end", "", "", "stream error", "data error", "", "buffer error", "", ""], d = 262;
      function B(w, U, I, S) {
        var L = w[2 * U], N = w[2 * I];
        return L < N || L == N && S[U] <= S[I];
      }
      function h() {
        var w, U, I, S, L, N, j, Z, W, V, y, P, _, Y, $, hA, z, k, F, R, E, G, M, oA, X, fA, nA, b, D, u, Q, H, O, eA, sA, pA, yA, wA, SA, xA, KA, iA = this, yt = new r(), $A = new r(), st = new r();
        function kt() {
          var tA;
          for (tA = 0; tA < 286; tA++)
            Q[2 * tA] = 0;
          for (tA = 0; tA < 30; tA++)
            H[2 * tA] = 0;
          for (tA = 0; tA < 19; tA++)
            O[2 * tA] = 0;
          Q[512] = 1, iA.opt_len = iA.static_len = 0, pA = wA = 0;
        }
        function jA(tA, AA) {
          var dA, QA, bA = -1, EA = tA[1], _A = 0, et = 7, VA = 4;
          for (EA === 0 && (et = 138, VA = 3), tA[2 * (AA + 1) + 1] = 65535, dA = 0; dA <= AA; dA++)
            QA = EA, EA = tA[2 * (dA + 1) + 1], ++_A < et && QA == EA || (_A < VA ? O[2 * QA] += _A : QA !== 0 ? (QA != bA && O[2 * QA]++, O[32]++) : _A <= 10 ? O[34]++ : O[36]++, bA = QA, (_A = 0) === EA ? (et = 138, VA = 3) : QA == EA ? (et = 6, VA = 3) : (et = 7, VA = 4));
        }
        function gt(tA) {
          iA.pending_buf[iA.pending++] = tA;
        }
        function bt(tA) {
          gt(255 & tA), gt(tA >>> 8 & 255);
        }
        function ht(tA, AA) {
          var dA, QA = AA;
          16 - QA < KA ? (bt(xA |= (dA = tA) << KA & 65535), xA = dA >>> 16 - KA, KA += QA - 16) : (xA |= tA << KA & 65535, KA += QA);
        }
        function ct(tA, AA) {
          var dA = 2 * tA;
          ht(65535 & AA[dA], 65535 & AA[dA + 1]);
        }
        function xt(tA, AA) {
          var dA, QA, bA = -1, EA = tA[1], _A = 0, et = 7, VA = 4;
          for (EA === 0 && (et = 138, VA = 3), dA = 0; dA <= AA; dA++)
            if (QA = EA, EA = tA[2 * (dA + 1) + 1], !(++_A < et && QA == EA)) {
              if (_A < VA)
                for (; ct(QA, O), --_A != 0; )
                  ;
              else
                QA !== 0 ? (QA != bA && (ct(QA, O), _A--), ct(16, O), ht(_A - 3, 2)) : _A <= 10 ? (ct(17, O), ht(_A - 3, 3)) : (ct(18, O), ht(_A - 11, 7));
              bA = QA, (_A = 0) === EA ? (et = 138, VA = 3) : QA == EA ? (et = 6, VA = 3) : (et = 7, VA = 4);
            }
        }
        function Pt() {
          KA == 16 ? (bt(xA), KA = xA = 0) : 8 <= KA && (gt(255 & xA), xA >>>= 8, KA -= 8);
        }
        function JA(tA, AA) {
          var dA, QA, bA;
          if (iA.pending_buf[yA + 2 * pA] = tA >>> 8 & 255, iA.pending_buf[yA + 2 * pA + 1] = 255 & tA, iA.pending_buf[eA + pA] = 255 & AA, pA++, tA === 0 ? Q[2 * AA]++ : (wA++, tA--, Q[2 * (r._length_code[AA] + 256 + 1)]++, H[2 * r.d_code(tA)]++), (8191 & pA) == 0 && 2 < nA) {
            for (dA = 8 * pA, QA = E - z, bA = 0; bA < 30; bA++)
              dA += H[2 * bA] * (5 + r.extra_dbits[bA]);
            if (dA >>>= 3, wA < Math.floor(pA / 2) && dA < Math.floor(QA / 2))
              return !0;
          }
          return pA == sA - 1;
        }
        function ee(tA, AA) {
          var dA, QA, bA, EA, _A = 0;
          if (pA !== 0)
            for (; dA = iA.pending_buf[yA + 2 * _A] << 8 & 65280 | 255 & iA.pending_buf[yA + 2 * _A + 1], QA = 255 & iA.pending_buf[eA + _A], _A++, dA === 0 ? ct(QA, tA) : (ct((bA = r._length_code[QA]) + 256 + 1, tA), (EA = r.extra_lbits[bA]) !== 0 && ht(QA -= r.base_length[bA], EA), ct(bA = r.d_code(--dA), AA), (EA = r.extra_dbits[bA]) !== 0 && ht(dA -= r.base_dist[bA], EA)), _A < pA; )
              ;
          ct(256, tA), SA = tA[513];
        }
        function oe() {
          8 < KA ? bt(xA) : 0 < KA && gt(255 & xA), KA = xA = 0;
        }
        function be(tA, AA, dA) {
          var QA, bA, EA;
          ht(0 + (dA ? 1 : 0), 3), QA = tA, bA = AA, EA = !0, oe(), SA = 8, EA && (bt(bA), bt(~bA)), iA.pending_buf.set(Z.subarray(QA, QA + bA), iA.pending), iA.pending += bA;
        }
        function Ke(tA, AA, dA) {
          var QA, bA, EA = 0;
          0 < nA ? (yt.build_tree(iA), $A.build_tree(iA), EA = function() {
            var _A;
            for (jA(Q, yt.max_code), jA(H, $A.max_code), st.build_tree(iA), _A = 18; 3 <= _A && O[2 * r.bl_order[_A] + 1] === 0; _A--)
              ;
            return iA.opt_len += 3 * (_A + 1) + 5 + 5 + 4, _A;
          }(), QA = iA.opt_len + 3 + 7 >>> 3, (bA = iA.static_len + 3 + 7 >>> 3) <= QA && (QA = bA)) : QA = bA = AA + 5, AA + 4 <= QA && tA != -1 ? be(tA, AA, dA) : bA == QA ? (ht(2 + (dA ? 1 : 0), 3), ee(n.static_ltree, n.static_dtree)) : (ht(4 + (dA ? 1 : 0), 3), function(_A, et, VA) {
            var it;
            for (ht(_A - 257, 5), ht(et - 1, 5), ht(VA - 4, 4), it = 0; it < VA; it++)
              ht(O[2 * r.bl_order[it] + 1], 3);
            xt(Q, _A - 1), xt(H, et - 1);
          }(yt.max_code + 1, $A.max_code + 1, EA + 1), ee(Q, H)), kt(), dA && oe();
        }
        function Yt(tA) {
          Ke(0 <= z ? z : -1, E - z, tA), z = E, w.flush_pending();
        }
        function K() {
          var tA, AA, dA, QA;
          do {
            if ((QA = W - M - E) === 0 && E === 0 && M === 0)
              QA = L;
            else if (QA == -1)
              QA--;
            else if (L + L - d <= E) {
              for (Z.set(Z.subarray(L, L + L), 0), G -= L, E -= L, z -= L, dA = tA = _; AA = 65535 & y[--dA], y[dA] = L <= AA ? AA - L : 0, --tA != 0; )
                ;
              for (dA = tA = L; AA = 65535 & V[--dA], V[dA] = L <= AA ? AA - L : 0, --tA != 0; )
                ;
              QA += L;
            }
            if (w.avail_in === 0)
              return;
            tA = w.read_buf(Z, E + M, QA), 3 <= (M += tA) && (P = ((P = 255 & Z[E]) << hA ^ 255 & Z[E + 1]) & $);
          } while (M < d && w.avail_in !== 0);
        }
        function aA(tA) {
          var AA, dA, QA = X, bA = E, EA = oA, _A = L - d < E ? E - (L - d) : 0, et = u, VA = j, it = E + 258, mt = Z[bA + EA - 1], qt = Z[bA + EA];
          D <= oA && (QA >>= 2), M < et && (et = M);
          do
            if (Z[(AA = tA) + EA] == qt && Z[AA + EA - 1] == mt && Z[AA] == Z[bA] && Z[++AA] == Z[bA + 1]) {
              bA += 2, AA++;
              do
                ;
              while (Z[++bA] == Z[++AA] && Z[++bA] == Z[++AA] && Z[++bA] == Z[++AA] && Z[++bA] == Z[++AA] && Z[++bA] == Z[++AA] && Z[++bA] == Z[++AA] && Z[++bA] == Z[++AA] && Z[++bA] == Z[++AA] && bA < it);
              if (dA = 258 - (it - bA), bA = it - 258, EA < dA) {
                if (G = tA, et <= (EA = dA))
                  break;
                mt = Z[bA + EA - 1], qt = Z[bA + EA];
              }
            }
          while ((tA = 65535 & V[tA & VA]) > _A && --QA != 0);
          return EA <= M ? EA : M;
        }
        function gA(tA) {
          return tA.total_in = tA.total_out = 0, tA.msg = null, iA.pending = 0, iA.pending_out = 0, U = 113, S = 0, yt.dyn_tree = Q, yt.stat_desc = n.static_l_desc, $A.dyn_tree = H, $A.stat_desc = n.static_d_desc, st.dyn_tree = O, st.stat_desc = n.static_bl_desc, KA = xA = 0, SA = 8, kt(), function() {
            var AA;
            for (W = 2 * L, AA = y[_ - 1] = 0; AA < _ - 1; AA++)
              y[AA] = 0;
            fA = c[nA].max_lazy, D = c[nA].good_length, u = c[nA].nice_length, X = c[nA].max_chain, k = oA = 2, P = R = M = z = E = 0;
          }(), 0;
        }
        iA.depth = [], iA.bl_count = [], iA.heap = [], Q = [], H = [], O = [], iA.pqdownheap = function(tA, AA) {
          for (var dA = iA.heap, QA = dA[AA], bA = AA << 1; bA <= iA.heap_len && (bA < iA.heap_len && B(tA, dA[bA + 1], dA[bA], iA.depth) && bA++, !B(tA, QA, dA[bA], iA.depth)); )
            dA[AA] = dA[bA], AA = bA, bA <<= 1;
          dA[AA] = QA;
        }, iA.deflateInit = function(tA, AA, dA, QA, bA, EA) {
          return QA || (QA = 8), bA || (bA = 8), EA || (EA = 0), tA.msg = null, AA == -1 && (AA = 6), bA < 1 || 9 < bA || QA != 8 || dA < 9 || 15 < dA || AA < 0 || 9 < AA || EA < 0 || 2 < EA ? -2 : (tA.dstate = iA, j = (L = 1 << (N = dA)) - 1, $ = (_ = 1 << (Y = bA + 7)) - 1, hA = Math.floor((Y + 3 - 1) / 3), Z = new Uint8Array(2 * L), V = [], y = [], sA = 1 << bA + 6, iA.pending_buf = new Uint8Array(4 * sA), I = 4 * sA, yA = Math.floor(sA / 2), eA = 3 * sA, nA = AA, b = EA, gA(tA));
        }, iA.deflateEnd = function() {
          return U != 42 && U != 113 && U != 666 ? -2 : (iA.pending_buf = null, Z = V = y = null, iA.dstate = null, U == 113 ? -3 : 0);
        }, iA.deflateParams = function(tA, AA, dA) {
          var QA = 0;
          return AA == -1 && (AA = 6), AA < 0 || 9 < AA || dA < 0 || 2 < dA ? -2 : (c[nA].func != c[AA].func && tA.total_in !== 0 && (QA = tA.deflate(1)), nA != AA && (fA = c[nA = AA].max_lazy, D = c[nA].good_length, u = c[nA].nice_length, X = c[nA].max_chain), b = dA, QA);
        }, iA.deflateSetDictionary = function(tA, AA, dA) {
          var QA, bA = dA, EA = 0;
          if (!AA || U != 42)
            return -2;
          if (bA < 3)
            return 0;
          for (L - d < bA && (EA = dA - (bA = L - d)), Z.set(AA.subarray(EA, EA + bA), 0), z = E = bA, P = ((P = 255 & Z[0]) << hA ^ 255 & Z[1]) & $, QA = 0; QA <= bA - 3; QA++)
            P = (P << hA ^ 255 & Z[QA + 2]) & $, V[QA & j] = y[P], y[P] = QA;
          return 0;
        }, iA.deflate = function(tA, AA) {
          var dA, QA, bA, EA, _A, et;
          if (4 < AA || AA < 0)
            return -2;
          if (!tA.next_out || !tA.next_in && tA.avail_in !== 0 || U == 666 && AA != 4)
            return tA.msg = l[4], -2;
          if (tA.avail_out === 0)
            return tA.msg = l[7], -5;
          if (w = tA, EA = S, S = AA, U == 42 && (QA = 8 + (N - 8 << 4) << 8, 3 < (bA = (nA - 1 & 255) >> 1) && (bA = 3), QA |= bA << 6, E !== 0 && (QA |= 32), U = 113, gt((et = QA += 31 - QA % 31) >> 8 & 255), gt(255 & et)), iA.pending !== 0) {
            if (w.flush_pending(), w.avail_out === 0)
              return S = -1, 0;
          } else if (w.avail_in === 0 && AA <= EA && AA != 4)
            return w.msg = l[7], -5;
          if (U == 666 && w.avail_in !== 0)
            return tA.msg = l[7], -5;
          if (w.avail_in !== 0 || M !== 0 || AA != 0 && U != 666) {
            switch (_A = -1, c[nA].func) {
              case 0:
                _A = function(VA) {
                  var it, mt = 65535;
                  for (I - 5 < mt && (mt = I - 5); ; ) {
                    if (M <= 1) {
                      if (K(), M === 0 && VA == 0)
                        return 0;
                      if (M === 0)
                        break;
                    }
                    if (E += M, it = z + mt, ((M = 0) === E || it <= E) && (M = E - it, E = it, Yt(!1), w.avail_out === 0) || L - d <= E - z && (Yt(!1), w.avail_out === 0))
                      return 0;
                  }
                  return Yt(VA == 4), w.avail_out === 0 ? VA == 4 ? 2 : 0 : VA == 4 ? 3 : 1;
                }(AA);
                break;
              case 1:
                _A = function(VA) {
                  for (var it, mt = 0; ; ) {
                    if (M < d) {
                      if (K(), M < d && VA == 0)
                        return 0;
                      if (M === 0)
                        break;
                    }
                    if (3 <= M && (P = (P << hA ^ 255 & Z[E + 2]) & $, mt = 65535 & y[P], V[E & j] = y[P], y[P] = E), mt !== 0 && (E - mt & 65535) <= L - d && b != 2 && (k = aA(mt)), 3 <= k)
                      if (it = JA(E - G, k - 3), M -= k, k <= fA && 3 <= M) {
                        for (k--; P = (P << hA ^ 255 & Z[++E + 2]) & $, mt = 65535 & y[P], V[E & j] = y[P], y[P] = E, --k != 0; )
                          ;
                        E++;
                      } else
                        E += k, k = 0, P = ((P = 255 & Z[E]) << hA ^ 255 & Z[E + 1]) & $;
                    else
                      it = JA(0, 255 & Z[E]), M--, E++;
                    if (it && (Yt(!1), w.avail_out === 0))
                      return 0;
                  }
                  return Yt(VA == 4), w.avail_out === 0 ? VA == 4 ? 2 : 0 : VA == 4 ? 3 : 1;
                }(AA);
                break;
              case 2:
                _A = function(VA) {
                  for (var it, mt, qt = 0; ; ) {
                    if (M < d) {
                      if (K(), M < d && VA == 0)
                        return 0;
                      if (M === 0)
                        break;
                    }
                    if (3 <= M && (P = (P << hA ^ 255 & Z[E + 2]) & $, qt = 65535 & y[P], V[E & j] = y[P], y[P] = E), oA = k, F = G, k = 2, qt !== 0 && oA < fA && (E - qt & 65535) <= L - d && (b != 2 && (k = aA(qt)), k <= 5 && (b == 1 || k == 3 && 4096 < E - G) && (k = 2)), 3 <= oA && k <= oA) {
                      for (mt = E + M - 3, it = JA(E - 1 - F, oA - 3), M -= oA - 1, oA -= 2; ++E <= mt && (P = (P << hA ^ 255 & Z[E + 2]) & $, qt = 65535 & y[P], V[E & j] = y[P], y[P] = E), --oA != 0; )
                        ;
                      if (R = 0, k = 2, E++, it && (Yt(!1), w.avail_out === 0))
                        return 0;
                    } else if (R !== 0) {
                      if ((it = JA(0, 255 & Z[E - 1])) && Yt(!1), E++, M--, w.avail_out === 0)
                        return 0;
                    } else
                      R = 1, E++, M--;
                  }
                  return R !== 0 && (it = JA(0, 255 & Z[E - 1]), R = 0), Yt(VA == 4), w.avail_out === 0 ? VA == 4 ? 2 : 0 : VA == 4 ? 3 : 1;
                }(AA);
            }
            if (_A != 2 && _A != 3 || (U = 666), _A == 0 || _A == 2)
              return w.avail_out === 0 && (S = -1), 0;
            if (_A == 1) {
              if (AA == 1)
                ht(2, 3), ct(256, n.static_ltree), Pt(), 1 + SA + 10 - KA < 9 && (ht(2, 3), ct(256, n.static_ltree), Pt()), SA = 7;
              else if (be(0, 0, !1), AA == 3)
                for (dA = 0; dA < _; dA++)
                  y[dA] = 0;
              if (w.flush_pending(), w.avail_out === 0)
                return S = -1, 0;
            }
          }
          return AA != 4 ? 0 : 1;
        };
      }
      function f() {
        var w = this;
        w.next_in_index = 0, w.next_out_index = 0, w.avail_in = 0, w.total_in = 0, w.avail_out = 0, w.total_out = 0;
      }
      f.prototype = { deflateInit: function(w, U) {
        return this.dstate = new h(), U || (U = p), this.dstate.deflateInit(this, w, U);
      }, deflate: function(w) {
        return this.dstate ? this.dstate.deflate(this, w) : -2;
      }, deflateEnd: function() {
        if (!this.dstate)
          return -2;
        var w = this.dstate.deflateEnd();
        return this.dstate = null, w;
      }, deflateParams: function(w, U) {
        return this.dstate ? this.dstate.deflateParams(this, w, U) : -2;
      }, deflateSetDictionary: function(w, U) {
        return this.dstate ? this.dstate.deflateSetDictionary(this, w, U) : -2;
      }, read_buf: function(w, U, I) {
        var S = this, L = S.avail_in;
        return I < L && (L = I), L === 0 ? 0 : (S.avail_in -= L, w.set(S.next_in.subarray(S.next_in_index, S.next_in_index + L), U), S.next_in_index += L, S.total_in += L, L);
      }, flush_pending: function() {
        var w = this, U = w.dstate.pending;
        U > w.avail_out && (U = w.avail_out), U !== 0 && (w.next_out.set(w.dstate.pending_buf.subarray(w.dstate.pending_out, w.dstate.pending_out + U), w.next_out_index), w.next_out_index += U, w.dstate.pending_out += U, w.total_out += U, w.avail_out -= U, w.dstate.pending -= U, w.dstate.pending === 0 && (w.dstate.pending_out = 0));
      } };
      var m = o.zip || o;
      m.Deflater = m._jzlib_Deflater = function(w) {
        var U = new f(), I = new Uint8Array(512), S = w ? w.level : -1;
        S === void 0 && (S = -1), U.deflateInit(S), U.next_out = I, this.append = function(L, N) {
          var j, Z = [], W = 0, V = 0, y = 0;
          if (L.length) {
            U.next_in_index = 0, U.next_in = L, U.avail_in = L.length;
            do {
              if (U.next_out_index = 0, U.avail_out = 512, U.deflate(0) != 0)
                throw new Error("deflating: " + U.msg);
              U.next_out_index && (U.next_out_index == 512 ? Z.push(new Uint8Array(I)) : Z.push(new Uint8Array(I.subarray(0, U.next_out_index)))), y += U.next_out_index, N && 0 < U.next_in_index && U.next_in_index != W && (N(U.next_in_index), W = U.next_in_index);
            } while (0 < U.avail_in || U.avail_out === 0);
            return j = new Uint8Array(y), Z.forEach(function(P) {
              j.set(P, V), V += P.length;
            }), j;
          }
        }, this.flush = function() {
          var L, N, j = [], Z = 0, W = 0;
          do {
            if (U.next_out_index = 0, U.avail_out = 512, (L = U.deflate(4)) != 1 && L != 0)
              throw new Error("deflating: " + U.msg);
            0 < 512 - U.avail_out && j.push(new Uint8Array(I.subarray(0, U.next_out_index))), W += U.next_out_index;
          } while (0 < U.avail_in || U.avail_out === 0);
          return U.deflateEnd(), N = new Uint8Array(W), j.forEach(function(V) {
            N.set(V, Z), Z += V.length;
          }), N;
        };
      };
    })(typeof self < "u" && self || typeof window < "u" && window || typeof Jt < "u" && Jt || Function('return typeof this === "object" && this.content')() || Function("return this")()), /**
       * A class to parse color values
       * @author Stoyan Stefanov <sstoo@gmail.com>
       * @link   http://www.phpied.com/rgb-color-parser-in-javascript/
       * @license Use it if you like it
       */
    function(o) {
      function p(C) {
        var i;
        this.ok = !1, C.charAt(0) == "#" && (C = C.substr(1, 6)), C = (C = C.replace(/ /g, "")).toLowerCase();
        var r = { aliceblue: "f0f8ff", antiquewhite: "faebd7", aqua: "00ffff", aquamarine: "7fffd4", azure: "f0ffff", beige: "f5f5dc", bisque: "ffe4c4", black: "000000", blanchedalmond: "ffebcd", blue: "0000ff", blueviolet: "8a2be2", brown: "a52a2a", burlywood: "deb887", cadetblue: "5f9ea0", chartreuse: "7fff00", chocolate: "d2691e", coral: "ff7f50", cornflowerblue: "6495ed", cornsilk: "fff8dc", crimson: "dc143c", cyan: "00ffff", darkblue: "00008b", darkcyan: "008b8b", darkgoldenrod: "b8860b", darkgray: "a9a9a9", darkgreen: "006400", darkkhaki: "bdb76b", darkmagenta: "8b008b", darkolivegreen: "556b2f", darkorange: "ff8c00", darkorchid: "9932cc", darkred: "8b0000", darksalmon: "e9967a", darkseagreen: "8fbc8f", darkslateblue: "483d8b", darkslategray: "2f4f4f", darkturquoise: "00ced1", darkviolet: "9400d3", deeppink: "ff1493", deepskyblue: "00bfff", dimgray: "696969", dodgerblue: "1e90ff", feldspar: "d19275", firebrick: "b22222", floralwhite: "fffaf0", forestgreen: "228b22", fuchsia: "ff00ff", gainsboro: "dcdcdc", ghostwhite: "f8f8ff", gold: "ffd700", goldenrod: "daa520", gray: "808080", green: "008000", greenyellow: "adff2f", honeydew: "f0fff0", hotpink: "ff69b4", indianred: "cd5c5c", indigo: "4b0082", ivory: "fffff0", khaki: "f0e68c", lavender: "e6e6fa", lavenderblush: "fff0f5", lawngreen: "7cfc00", lemonchiffon: "fffacd", lightblue: "add8e6", lightcoral: "f08080", lightcyan: "e0ffff", lightgoldenrodyellow: "fafad2", lightgrey: "d3d3d3", lightgreen: "90ee90", lightpink: "ffb6c1", lightsalmon: "ffa07a", lightseagreen: "20b2aa", lightskyblue: "87cefa", lightslateblue: "8470ff", lightslategray: "778899", lightsteelblue: "b0c4de", lightyellow: "ffffe0", lime: "00ff00", limegreen: "32cd32", linen: "faf0e6", magenta: "ff00ff", maroon: "800000", mediumaquamarine: "66cdaa", mediumblue: "0000cd", mediumorchid: "ba55d3", mediumpurple: "9370d8", mediumseagreen: "3cb371", mediumslateblue: "7b68ee", mediumspringgreen: "00fa9a", mediumturquoise: "48d1cc", mediumvioletred: "c71585", midnightblue: "191970", mintcream: "f5fffa", mistyrose: "ffe4e1", moccasin: "ffe4b5", navajowhite: "ffdead", navy: "000080", oldlace: "fdf5e6", olive: "808000", olivedrab: "6b8e23", orange: "ffa500", orangered: "ff4500", orchid: "da70d6", palegoldenrod: "eee8aa", palegreen: "98fb98", paleturquoise: "afeeee", palevioletred: "d87093", papayawhip: "ffefd5", peachpuff: "ffdab9", peru: "cd853f", pink: "ffc0cb", plum: "dda0dd", powderblue: "b0e0e6", purple: "800080", red: "ff0000", rosybrown: "bc8f8f", royalblue: "4169e1", saddlebrown: "8b4513", salmon: "fa8072", sandybrown: "f4a460", seagreen: "2e8b57", seashell: "fff5ee", sienna: "a0522d", silver: "c0c0c0", skyblue: "87ceeb", slateblue: "6a5acd", slategray: "708090", snow: "fffafa", springgreen: "00ff7f", steelblue: "4682b4", tan: "d2b48c", teal: "008080", thistle: "d8bfd8", tomato: "ff6347", turquoise: "40e0d0", violet: "ee82ee", violetred: "d02090", wheat: "f5deb3", white: "ffffff", whitesmoke: "f5f5f5", yellow: "ffff00", yellowgreen: "9acd32" };
        for (var n in r)
          C == n && (C = r[n]);
        for (var s = [{ re: /^rgb\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\)$/, example: ["rgb(123, 234, 45)", "rgb(255,234,245)"], process: function(h) {
          return [parseInt(h[1]), parseInt(h[2]), parseInt(h[3])];
        } }, { re: /^(\w{2})(\w{2})(\w{2})$/, example: ["#00ff00", "336699"], process: function(h) {
          return [parseInt(h[1], 16), parseInt(h[2], 16), parseInt(h[3], 16)];
        } }, { re: /^(\w{1})(\w{1})(\w{1})$/, example: ["#fb0", "f0f"], process: function(h) {
          return [parseInt(h[1] + h[1], 16), parseInt(h[2] + h[2], 16), parseInt(h[3] + h[3], 16)];
        } }], c = 0; c < s.length; c++) {
          var l = s[c].re, d = s[c].process, B = l.exec(C);
          B && (i = d(B), this.r = i[0], this.g = i[1], this.b = i[2], this.ok = !0);
        }
        this.r = this.r < 0 || isNaN(this.r) ? 0 : 255 < this.r ? 255 : this.r, this.g = this.g < 0 || isNaN(this.g) ? 0 : 255 < this.g ? 255 : this.g, this.b = this.b < 0 || isNaN(this.b) ? 0 : 255 < this.b ? 255 : this.b, this.toRGB = function() {
          return "rgb(" + this.r + ", " + this.g + ", " + this.b + ")";
        }, this.toHex = function() {
          var h = this.r.toString(16), f = this.g.toString(16), m = this.b.toString(16);
          return h.length == 1 && (h = "0" + h), f.length == 1 && (f = "0" + f), m.length == 1 && (m = "0" + m), "#" + h + f + m;
        }, this.getHelpXML = function() {
          for (var h = new Array(), f = 0; f < s.length; f++)
            for (var m = s[f].example, w = 0; w < m.length; w++)
              h[h.length] = m[w];
          for (var U in r)
            h[h.length] = U;
          var I = document.createElement("ul");
          for (I.setAttribute("id", "rgbcolor-examples"), f = 0; f < h.length; f++)
            try {
              var S = document.createElement("li"), L = new p(h[f]), N = document.createElement("div");
              N.style.cssText = "margin: 3px; border: 1px solid black; background:" + L.toHex() + "; color:" + L.toHex(), N.appendChild(document.createTextNode("test"));
              var j = document.createTextNode(" " + h[f] + " -> " + L.toRGB() + " -> " + L.toHex());
              S.appendChild(N), S.appendChild(j), I.appendChild(S);
            } catch {
            }
          return I;
        };
      }
      CA.exports && (CA.exports = p), o.RGBColor = p;
    }(typeof self < "u" && self || typeof window < "u" && window || typeof Jt < "u" && Jt || Function('return typeof this === "object" && this.content')() || Function("return this")()), function(o) {
      CA.exports = o();
    }(function() {
      return function o(p, C, i) {
        function r(c, l) {
          if (!C[c]) {
            if (!p[c]) {
              var d = typeof Nn == "function" && Nn;
              if (!l && d)
                return d(c, !0);
              if (n)
                return n(c, !0);
              var B = new Error("Cannot find module '" + c + "'");
              throw B.code = "MODULE_NOT_FOUND", B;
            }
            var h = C[c] = { exports: {} };
            p[c][0].call(h.exports, function(f) {
              var m = p[c][1][f];
              return r(m || f);
            }, h, h.exports, o, p, C, i);
          }
          return C[c].exports;
        }
        for (var n = typeof Nn == "function" && Nn, s = 0; s < i.length; s++)
          r(i[s]);
        return r;
      }({ 1: [function(o, p, C) {
        (function(i) {
          (function(r) {
            var n = typeof C == "object" && C, s = typeof p == "object" && p && p.exports == n && p, c = typeof i == "object" && i;
            c.global !== c && c.window !== c || (r = c);
            var l, d, B = 2147483647, h = 36, f = 1, m = 26, w = 38, U = 700, I = 72, S = 128, L = "-", N = /^xn--/, j = /[^ -~]/, Z = /\x2E|\u3002|\uFF0E|\uFF61/g, W = { overflow: "Overflow: input needs wider integers to process", "not-basic": "Illegal input >= 0x80 (not a basic code point)", "invalid-input": "Invalid input" }, V = h - f, y = Math.floor, P = String.fromCharCode;
            function _(G) {
              throw RangeError(W[G]);
            }
            function Y(G, M) {
              for (var oA = G.length; oA--; )
                G[oA] = M(G[oA]);
              return G;
            }
            function $(G, M) {
              return Y(G.split(Z), M).join(".");
            }
            function hA(G) {
              for (var M, oA, X = [], fA = 0, nA = G.length; fA < nA; )
                55296 <= (M = G.charCodeAt(fA++)) && M <= 56319 && fA < nA ? (64512 & (oA = G.charCodeAt(fA++))) == 56320 ? X.push(((1023 & M) << 10) + (1023 & oA) + 65536) : (X.push(M), fA--) : X.push(M);
              return X;
            }
            function z(G) {
              return Y(G, function(M) {
                var oA = "";
                return 65535 < M && (oA += P((M -= 65536) >>> 10 & 1023 | 55296), M = 56320 | 1023 & M), oA += P(M);
              }).join("");
            }
            function k(G, M) {
              return G + 22 + 75 * (G < 26) - ((M != 0) << 5);
            }
            function F(G, M, oA) {
              var X = 0;
              for (G = oA ? y(G / U) : G >> 1, G += y(G / M); V * m >> 1 < G; X += h)
                G = y(G / V);
              return y(X + (V + 1) * G / (G + w));
            }
            function R(G) {
              var M, oA, X, fA, nA, b, D, u, Q, H, O, eA = [], sA = G.length, pA = 0, yA = S, wA = I;
              for ((oA = G.lastIndexOf(L)) < 0 && (oA = 0), X = 0; X < oA; ++X)
                128 <= G.charCodeAt(X) && _("not-basic"), eA.push(G.charCodeAt(X));
              for (fA = 0 < oA ? oA + 1 : 0; fA < sA; ) {
                for (nA = pA, b = 1, D = h; sA <= fA && _("invalid-input"), O = G.charCodeAt(fA++), (h <= (u = O - 48 < 10 ? O - 22 : O - 65 < 26 ? O - 65 : O - 97 < 26 ? O - 97 : h) || u > y((B - pA) / b)) && _("overflow"), pA += u * b, !(u < (Q = D <= wA ? f : wA + m <= D ? m : D - wA)); D += h)
                  b > y(B / (H = h - Q)) && _("overflow"), b *= H;
                wA = F(pA - nA, M = eA.length + 1, nA == 0), y(pA / M) > B - yA && _("overflow"), yA += y(pA / M), pA %= M, eA.splice(pA++, 0, yA);
              }
              return z(eA);
            }
            function E(G) {
              var M, oA, X, fA, nA, b, D, u, Q, H, O, eA, sA, pA, yA, wA = [];
              for (eA = (G = hA(G)).length, M = S, nA = I, b = oA = 0; b < eA; ++b)
                (O = G[b]) < 128 && wA.push(P(O));
              for (X = fA = wA.length, fA && wA.push(L); X < eA; ) {
                for (D = B, b = 0; b < eA; ++b)
                  M <= (O = G[b]) && O < D && (D = O);
                for (D - M > y((B - oA) / (sA = X + 1)) && _("overflow"), oA += (D - M) * sA, M = D, b = 0; b < eA; ++b)
                  if ((O = G[b]) < M && ++oA > B && _("overflow"), O == M) {
                    for (u = oA, Q = h; !(u < (H = Q <= nA ? f : nA + m <= Q ? m : Q - nA)); Q += h)
                      yA = u - H, pA = h - H, wA.push(P(k(H + yA % pA, 0))), u = y(yA / pA);
                    wA.push(P(k(u, 0))), nA = F(oA, sA, X == fA), oA = 0, ++X;
                  }
                ++oA, ++M;
              }
              return wA.join("");
            }
            if (l = { version: "1.2.4", ucs2: { decode: hA, encode: z }, decode: R, encode: E, toASCII: function(G) {
              return $(G, function(M) {
                return j.test(M) ? "xn--" + E(M) : M;
              });
            }, toUnicode: function(G) {
              return $(G, function(M) {
                return N.test(M) ? R(M.slice(4).toLowerCase()) : M;
              });
            } }, n && !n.nodeType)
              if (s)
                s.exports = l;
              else
                for (d in l)
                  l.hasOwnProperty(d) && (n[d] = l[d]);
            else
              r.punycode = l;
          })(this);
        }).call(this, typeof Jt < "u" ? Jt : typeof self < "u" ? self : typeof window < "u" ? window : {});
      }, {}], 2: [function(o, p, C) {
        var i = o("./log");
        function r(n, s) {
          for (var c = n.nodeType === 3 ? document.createTextNode(n.nodeValue) : n.cloneNode(!1), l = n.firstChild; l; )
            s !== !0 && l.nodeType === 1 && l.nodeName === "SCRIPT" || c.appendChild(r(l, s)), l = l.nextSibling;
          return n.nodeType === 1 && (c._scrollTop = n.scrollTop, c._scrollLeft = n.scrollLeft, n.nodeName === "CANVAS" ? function(d, B) {
            try {
              B && (B.width = d.width, B.height = d.height, B.getContext("2d").putImageData(d.getContext("2d").getImageData(0, 0, d.width, d.height), 0, 0));
            } catch (h) {
              i("Unable to copy canvas content from", d, h);
            }
          }(n, c) : n.nodeName !== "TEXTAREA" && n.nodeName !== "SELECT" || (c.value = n.value)), c;
        }
        p.exports = function(n, s, c, l, d, B, h) {
          var f = r(n.documentElement, d.javascriptEnabled), m = s.createElement("iframe");
          return m.className = "html2canvas-container", m.style.visibility = "hidden", m.style.position = "fixed", m.style.left = "-10000px", m.style.top = "0px", m.style.border = "0", m.width = c, m.height = l, m.scrolling = "no", s.body.appendChild(m), new Promise(function(w) {
            var U, I, S, L = m.contentWindow.document;
            m.contentWindow.onload = m.onload = function() {
              var N = setInterval(function() {
                0 < L.body.childNodes.length && (function j(Z) {
                  if (Z.nodeType === 1) {
                    Z.scrollTop = Z._scrollTop, Z.scrollLeft = Z._scrollLeft;
                    for (var W = Z.firstChild; W; )
                      j(W), W = W.nextSibling;
                  }
                }(L.documentElement), clearInterval(N), d.type === "view" && (m.contentWindow.scrollTo(B, h), !/(iPad|iPhone|iPod)/g.test(navigator.userAgent) || m.contentWindow.scrollY === h && m.contentWindow.scrollX === B || (L.documentElement.style.top = -h + "px", L.documentElement.style.left = -B + "px", L.documentElement.style.position = "absolute")), w(m));
              }, 50);
            }, L.open(), L.write("<!DOCTYPE html><html></html>"), I = B, S = h, !(U = n).defaultView || I === U.defaultView.pageXOffset && S === U.defaultView.pageYOffset || U.defaultView.scrollTo(I, S), L.replaceChild(L.adoptNode(f), L.documentElement), L.close();
          });
        };
      }, { "./log": 13 }], 3: [function(o, p, C) {
        function i(d) {
          this.r = 0, this.g = 0, this.b = 0, this.a = null, this.fromArray(d) || this.namedColor(d) || this.rgb(d) || this.rgba(d) || this.hex6(d) || this.hex3(d);
        }
        i.prototype.darken = function(d) {
          var B = 1 - d;
          return new i([Math.round(this.r * B), Math.round(this.g * B), Math.round(this.b * B), this.a]);
        }, i.prototype.isTransparent = function() {
          return this.a === 0;
        }, i.prototype.isBlack = function() {
          return this.r === 0 && this.g === 0 && this.b === 0;
        }, i.prototype.fromArray = function(d) {
          return Array.isArray(d) && (this.r = Math.min(d[0], 255), this.g = Math.min(d[1], 255), this.b = Math.min(d[2], 255), 3 < d.length && (this.a = d[3])), Array.isArray(d);
        };
        var r = /^#([a-f0-9]{3})$/i;
        i.prototype.hex3 = function(d) {
          var B;
          return (B = d.match(r)) !== null && (this.r = parseInt(B[1][0] + B[1][0], 16), this.g = parseInt(B[1][1] + B[1][1], 16), this.b = parseInt(B[1][2] + B[1][2], 16)), B !== null;
        };
        var n = /^#([a-f0-9]{6})$/i;
        i.prototype.hex6 = function(d) {
          var B = null;
          return (B = d.match(n)) !== null && (this.r = parseInt(B[1].substring(0, 2), 16), this.g = parseInt(B[1].substring(2, 4), 16), this.b = parseInt(B[1].substring(4, 6), 16)), B !== null;
        };
        var s = /^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/;
        i.prototype.rgb = function(d) {
          var B;
          return (B = d.match(s)) !== null && (this.r = Number(B[1]), this.g = Number(B[2]), this.b = Number(B[3])), B !== null;
        };
        var c = /^rgba\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d?\.?\d+)\s*\)$/;
        i.prototype.rgba = function(d) {
          var B;
          return (B = d.match(c)) !== null && (this.r = Number(B[1]), this.g = Number(B[2]), this.b = Number(B[3]), this.a = Number(B[4])), B !== null;
        }, i.prototype.toString = function() {
          return this.a !== null && this.a !== 1 ? "rgba(" + [this.r, this.g, this.b, this.a].join(",") + ")" : "rgb(" + [this.r, this.g, this.b].join(",") + ")";
        }, i.prototype.namedColor = function(d) {
          d = d.toLowerCase();
          var B = l[d];
          if (B)
            this.r = B[0], this.g = B[1], this.b = B[2];
          else if (d === "transparent")
            return this.r = this.g = this.b = this.a = 0, !0;
          return !!B;
        }, i.prototype.isColor = !0;
        var l = { aliceblue: [240, 248, 255], antiquewhite: [250, 235, 215], aqua: [0, 255, 255], aquamarine: [127, 255, 212], azure: [240, 255, 255], beige: [245, 245, 220], bisque: [255, 228, 196], black: [0, 0, 0], blanchedalmond: [255, 235, 205], blue: [0, 0, 255], blueviolet: [138, 43, 226], brown: [165, 42, 42], burlywood: [222, 184, 135], cadetblue: [95, 158, 160], chartreuse: [127, 255, 0], chocolate: [210, 105, 30], coral: [255, 127, 80], cornflowerblue: [100, 149, 237], cornsilk: [255, 248, 220], crimson: [220, 20, 60], cyan: [0, 255, 255], darkblue: [0, 0, 139], darkcyan: [0, 139, 139], darkgoldenrod: [184, 134, 11], darkgray: [169, 169, 169], darkgreen: [0, 100, 0], darkgrey: [169, 169, 169], darkkhaki: [189, 183, 107], darkmagenta: [139, 0, 139], darkolivegreen: [85, 107, 47], darkorange: [255, 140, 0], darkorchid: [153, 50, 204], darkred: [139, 0, 0], darksalmon: [233, 150, 122], darkseagreen: [143, 188, 143], darkslateblue: [72, 61, 139], darkslategray: [47, 79, 79], darkslategrey: [47, 79, 79], darkturquoise: [0, 206, 209], darkviolet: [148, 0, 211], deeppink: [255, 20, 147], deepskyblue: [0, 191, 255], dimgray: [105, 105, 105], dimgrey: [105, 105, 105], dodgerblue: [30, 144, 255], firebrick: [178, 34, 34], floralwhite: [255, 250, 240], forestgreen: [34, 139, 34], fuchsia: [255, 0, 255], gainsboro: [220, 220, 220], ghostwhite: [248, 248, 255], gold: [255, 215, 0], goldenrod: [218, 165, 32], gray: [128, 128, 128], green: [0, 128, 0], greenyellow: [173, 255, 47], grey: [128, 128, 128], honeydew: [240, 255, 240], hotpink: [255, 105, 180], indianred: [205, 92, 92], indigo: [75, 0, 130], ivory: [255, 255, 240], khaki: [240, 230, 140], lavender: [230, 230, 250], lavenderblush: [255, 240, 245], lawngreen: [124, 252, 0], lemonchiffon: [255, 250, 205], lightblue: [173, 216, 230], lightcoral: [240, 128, 128], lightcyan: [224, 255, 255], lightgoldenrodyellow: [250, 250, 210], lightgray: [211, 211, 211], lightgreen: [144, 238, 144], lightgrey: [211, 211, 211], lightpink: [255, 182, 193], lightsalmon: [255, 160, 122], lightseagreen: [32, 178, 170], lightskyblue: [135, 206, 250], lightslategray: [119, 136, 153], lightslategrey: [119, 136, 153], lightsteelblue: [176, 196, 222], lightyellow: [255, 255, 224], lime: [0, 255, 0], limegreen: [50, 205, 50], linen: [250, 240, 230], magenta: [255, 0, 255], maroon: [128, 0, 0], mediumaquamarine: [102, 205, 170], mediumblue: [0, 0, 205], mediumorchid: [186, 85, 211], mediumpurple: [147, 112, 219], mediumseagreen: [60, 179, 113], mediumslateblue: [123, 104, 238], mediumspringgreen: [0, 250, 154], mediumturquoise: [72, 209, 204], mediumvioletred: [199, 21, 133], midnightblue: [25, 25, 112], mintcream: [245, 255, 250], mistyrose: [255, 228, 225], moccasin: [255, 228, 181], navajowhite: [255, 222, 173], navy: [0, 0, 128], oldlace: [253, 245, 230], olive: [128, 128, 0], olivedrab: [107, 142, 35], orange: [255, 165, 0], orangered: [255, 69, 0], orchid: [218, 112, 214], palegoldenrod: [238, 232, 170], palegreen: [152, 251, 152], paleturquoise: [175, 238, 238], palevioletred: [219, 112, 147], papayawhip: [255, 239, 213], peachpuff: [255, 218, 185], peru: [205, 133, 63], pink: [255, 192, 203], plum: [221, 160, 221], powderblue: [176, 224, 230], purple: [128, 0, 128], rebeccapurple: [102, 51, 153], red: [255, 0, 0], rosybrown: [188, 143, 143], royalblue: [65, 105, 225], saddlebrown: [139, 69, 19], salmon: [250, 128, 114], sandybrown: [244, 164, 96], seagreen: [46, 139, 87], seashell: [255, 245, 238], sienna: [160, 82, 45], silver: [192, 192, 192], skyblue: [135, 206, 235], slateblue: [106, 90, 205], slategray: [112, 128, 144], slategrey: [112, 128, 144], snow: [255, 250, 250], springgreen: [0, 255, 127], steelblue: [70, 130, 180], tan: [210, 180, 140], teal: [0, 128, 128], thistle: [216, 191, 216], tomato: [255, 99, 71], turquoise: [64, 224, 208], violet: [238, 130, 238], wheat: [245, 222, 179], white: [255, 255, 255], whitesmoke: [245, 245, 245], yellow: [255, 255, 0], yellowgreen: [154, 205, 50] };
        p.exports = i;
      }, {}], 4: [function(o, p, C) {
        var i = o("./support"), r = o("./renderers/canvas"), n = o("./imageloader"), s = o("./nodeparser"), c = o("./nodecontainer"), l = o("./log"), d = o("./utils"), B = o("./clone"), h = o("./proxy").loadUrlDocument, f = d.getBounds, m = "data-html2canvas-node", w = 0;
        function U(N, j) {
          var Z, W, V = w++;
          if ((j = j || {}).logging && (l.options.logging = !0, l.options.start = Date.now()), j.async = j.async === void 0 || j.async, j.allowTaint = j.allowTaint !== void 0 && j.allowTaint, j.removeContainer = j.removeContainer === void 0 || j.removeContainer, j.javascriptEnabled = j.javascriptEnabled !== void 0 && j.javascriptEnabled, j.imageTimeout = j.imageTimeout === void 0 ? 1e4 : j.imageTimeout, j.renderer = typeof j.renderer == "function" ? j.renderer : r, j.strict = !!j.strict, typeof N == "string") {
            if (typeof j.proxy != "string")
              return Promise.reject("Proxy must be used when rendering url");
            var y = j.width != null ? j.width : window.innerWidth, P = j.height != null ? j.height : window.innerHeight;
            return h((Z = N, W = document.createElement("a"), W.href = Z, W.href = W.href, W), j.proxy, document, y, P, j).then(function(F) {
              return S(F.contentWindow.document.documentElement, F, j, y, P);
            });
          }
          var _, Y, $, hA, z, k = (N === void 0 ? [document.documentElement] : N.length ? N : [N])[0];
          return k.setAttribute(m + V, V), (_ = k.ownerDocument, Y = j, $ = k.ownerDocument.defaultView.innerWidth, hA = k.ownerDocument.defaultView.innerHeight, z = V, B(_, _, $, hA, Y, _.defaultView.pageXOffset, _.defaultView.pageYOffset).then(function(F) {
            l("Document cloned");
            var R = m + z, E = "[" + R + "='" + z + "']";
            _.querySelector(E).removeAttribute(R);
            var G = F.contentWindow, M = G.document.querySelector(E), oA = typeof Y.onclone == "function" ? Promise.resolve(Y.onclone(G.document)) : Promise.resolve(!0);
            return oA.then(function() {
              return S(M, F, Y, $, hA);
            });
          })).then(function(F) {
            return typeof j.onrendered == "function" && (l("options.onrendered is deprecated, html2canvas returns a Promise containing the canvas"), j.onrendered(F)), F;
          });
        }
        U.CanvasRenderer = r, U.NodeContainer = c, U.log = l, U.utils = d;
        var I = typeof document > "u" || typeof Object.create != "function" || typeof document.createElement("canvas").getContext != "function" ? function() {
          return Promise.reject("No canvas support");
        } : U;
        function S(N, j, Z, W, V) {
          var y, P, _ = j.contentWindow, Y = new i(_.document), $ = new n(Z, Y), hA = f(N), z = Z.type === "view" ? W : (y = _.document, Math.max(Math.max(y.body.scrollWidth, y.documentElement.scrollWidth), Math.max(y.body.offsetWidth, y.documentElement.offsetWidth), Math.max(y.body.clientWidth, y.documentElement.clientWidth))), k = Z.type === "view" ? V : (P = _.document, Math.max(Math.max(P.body.scrollHeight, P.documentElement.scrollHeight), Math.max(P.body.offsetHeight, P.documentElement.offsetHeight), Math.max(P.body.clientHeight, P.documentElement.clientHeight))), F = new Z.renderer(z, k, $, Z, document);
          return new s(N, F, Y, $, Z).ready.then(function() {
            var R, E;
            return l("Finished rendering"), R = Z.type === "view" ? L(F.canvas, { width: F.canvas.width, height: F.canvas.height, top: 0, left: 0, x: 0, y: 0 }) : N === _.document.body || N === _.document.documentElement || Z.canvas != null ? F.canvas : L(F.canvas, { width: Z.width != null ? Z.width : hA.width, height: Z.height != null ? Z.height : hA.height, top: hA.top, left: hA.left, x: 0, y: 0 }), E = j, Z.removeContainer && (E.parentNode.removeChild(E), l("Cleaned up container")), R;
          });
        }
        function L(N, j) {
          var Z = document.createElement("canvas"), W = Math.min(N.width - 1, Math.max(0, j.left)), V = Math.min(N.width, Math.max(1, j.left + j.width)), y = Math.min(N.height - 1, Math.max(0, j.top)), P = Math.min(N.height, Math.max(1, j.top + j.height));
          Z.width = j.width, Z.height = j.height;
          var _ = V - W, Y = P - y;
          return l("Cropping canvas at:", "left:", j.left, "top:", j.top, "width:", _, "height:", Y), l("Resulting crop with width", j.width, "and height", j.height, "with x", W, "and y", y), Z.getContext("2d").drawImage(N, W, y, _, Y, j.x, j.y, _, Y), Z;
        }
        p.exports = I;
      }, { "./clone": 2, "./imageloader": 11, "./log": 13, "./nodecontainer": 14, "./nodeparser": 15, "./proxy": 16, "./renderers/canvas": 20, "./support": 22, "./utils": 26 }], 5: [function(o, p, C) {
        var i = o("./log"), r = o("./utils").smallImage;
        p.exports = function n(s) {
          if (this.src = s, i("DummyImageContainer for", s), !this.promise || !this.image) {
            i("Initiating DummyImageContainer"), n.prototype.image = new Image();
            var c = this.image;
            n.prototype.promise = new Promise(function(l, d) {
              c.onload = l, c.onerror = d, c.src = r(), c.complete === !0 && l(c);
            });
          }
        };
      }, { "./log": 13, "./utils": 26 }], 6: [function(o, p, C) {
        var i = o("./utils").smallImage;
        p.exports = function(r, n) {
          var s, c, l = document.createElement("div"), d = document.createElement("img"), B = document.createElement("span"), h = "Hidden Text";
          l.style.visibility = "hidden", l.style.fontFamily = r, l.style.fontSize = n, l.style.margin = 0, l.style.padding = 0, document.body.appendChild(l), d.src = i(), d.width = 1, d.height = 1, d.style.margin = 0, d.style.padding = 0, d.style.verticalAlign = "baseline", B.style.fontFamily = r, B.style.fontSize = n, B.style.margin = 0, B.style.padding = 0, B.appendChild(document.createTextNode(h)), l.appendChild(B), l.appendChild(d), s = d.offsetTop - B.offsetTop + 1, l.removeChild(B), l.appendChild(document.createTextNode(h)), l.style.lineHeight = "normal", d.style.verticalAlign = "super", c = d.offsetTop - l.offsetTop + 1, document.body.removeChild(l), this.baseline = s, this.lineWidth = 1, this.middle = c;
        };
      }, { "./utils": 26 }], 7: [function(o, p, C) {
        var i = o("./font");
        function r() {
          this.data = {};
        }
        r.prototype.getMetrics = function(n, s) {
          return this.data[n + "-" + s] === void 0 && (this.data[n + "-" + s] = new i(n, s)), this.data[n + "-" + s];
        }, p.exports = r;
      }, { "./font": 6 }], 8: [function(o, p, C) {
        var i = o("./utils").getBounds, r = o("./proxy").loadUrlDocument;
        function n(s, c, l) {
          this.image = null, this.src = s;
          var d = this, B = i(s);
          this.promise = (c ? new Promise(function(h) {
            s.contentWindow.document.URL === "about:blank" || s.contentWindow.document.documentElement == null ? s.contentWindow.onload = s.onload = function() {
              h(s);
            } : h(s);
          }) : this.proxyLoad(l.proxy, B, l)).then(function(h) {
            return o("./core")(h.contentWindow.document.documentElement, { type: "view", width: h.width, height: h.height, proxy: l.proxy, javascriptEnabled: l.javascriptEnabled, removeContainer: l.removeContainer, allowTaint: l.allowTaint, imageTimeout: l.imageTimeout / 2 });
          }).then(function(h) {
            return d.image = h;
          });
        }
        n.prototype.proxyLoad = function(s, c, l) {
          var d = this.src;
          return r(d.src, s, d.ownerDocument, c.width, c.height, l);
        }, p.exports = n;
      }, { "./core": 4, "./proxy": 16, "./utils": 26 }], 9: [function(o, p, C) {
        function i(r) {
          this.src = r.value, this.colorStops = [], this.type = null, this.x0 = 0.5, this.y0 = 0.5, this.x1 = 0.5, this.y1 = 0.5, this.promise = Promise.resolve(!0);
        }
        i.TYPES = { LINEAR: 1, RADIAL: 2 }, i.REGEXP_COLORSTOP = /^\s*(rgba?\(\s*\d{1,3},\s*\d{1,3},\s*\d{1,3}(?:,\s*[0-9\.]+)?\s*\)|[a-z]{3,20}|#[a-f0-9]{3,6})(?:\s+(\d{1,3}(?:\.\d+)?)(%|px)?)?(?:\s|$)/i, p.exports = i;
      }, {}], 10: [function(o, p, C) {
        p.exports = function(i, r) {
          this.src = i, this.image = new Image();
          var n = this;
          this.tainted = null, this.promise = new Promise(function(s, c) {
            n.image.onload = s, n.image.onerror = c, r && (n.image.crossOrigin = "anonymous"), n.image.src = i, n.image.complete === !0 && s(n.image);
          });
        };
      }, {}], 11: [function(o, p, C) {
        var i = o("./log"), r = o("./imagecontainer"), n = o("./dummyimagecontainer"), s = o("./proxyimagecontainer"), c = o("./framecontainer"), l = o("./svgcontainer"), d = o("./svgnodecontainer"), B = o("./lineargradientcontainer"), h = o("./webkitgradientcontainer"), f = o("./utils").bind;
        function m(w, U) {
          this.link = null, this.options = w, this.support = U, this.origin = this.getOrigin(window.location.href);
        }
        m.prototype.findImages = function(w) {
          var U = [];
          return w.reduce(function(I, S) {
            switch (S.node.nodeName) {
              case "IMG":
                return I.concat([{ args: [S.node.src], method: "url" }]);
              case "svg":
              case "IFRAME":
                return I.concat([{ args: [S.node], method: S.node.nodeName }]);
            }
            return I;
          }, []).forEach(this.addImage(U, this.loadImage), this), U;
        }, m.prototype.findBackgroundImage = function(w, U) {
          return U.parseBackgroundImages().filter(this.hasImageBackground).forEach(this.addImage(w, this.loadImage), this), w;
        }, m.prototype.addImage = function(w, U) {
          return function(I) {
            I.args.forEach(function(S) {
              this.imageExists(w, S) || (w.splice(0, 0, U.call(this, I)), i("Added image #" + w.length, typeof S == "string" ? S.substring(0, 100) : S));
            }, this);
          };
        }, m.prototype.hasImageBackground = function(w) {
          return w.method !== "none";
        }, m.prototype.loadImage = function(w) {
          if (w.method === "url") {
            var U = w.args[0];
            return !this.isSVG(U) || this.support.svg || this.options.allowTaint ? U.match(/data:image\/.*;base64,/i) ? new r(U.replace(/url\(['"]{0,}|['"]{0,}\)$/gi, ""), !1) : this.isSameOrigin(U) || this.options.allowTaint === !0 || this.isSVG(U) ? new r(U, !1) : this.support.cors && !this.options.allowTaint && this.options.useCORS ? new r(U, !0) : this.options.proxy ? new s(U, this.options.proxy) : new n(U) : new l(U);
          }
          return w.method === "linear-gradient" ? new B(w) : w.method === "gradient" ? new h(w) : w.method === "svg" ? new d(w.args[0], this.support.svg) : w.method === "IFRAME" ? new c(w.args[0], this.isSameOrigin(w.args[0].src), this.options) : new n(w);
        }, m.prototype.isSVG = function(w) {
          return w.substring(w.length - 3).toLowerCase() === "svg" || l.prototype.isInline(w);
        }, m.prototype.imageExists = function(w, U) {
          return w.some(function(I) {
            return I.src === U;
          });
        }, m.prototype.isSameOrigin = function(w) {
          return this.getOrigin(w) === this.origin;
        }, m.prototype.getOrigin = function(w) {
          var U = this.link || (this.link = document.createElement("a"));
          return U.href = w, U.href = U.href, U.protocol + U.hostname + U.port;
        }, m.prototype.getPromise = function(w) {
          return this.timeout(w, this.options.imageTimeout).catch(function() {
            return new n(w.src).promise.then(function(U) {
              w.image = U;
            });
          });
        }, m.prototype.get = function(w) {
          var U = null;
          return this.images.some(function(I) {
            return (U = I).src === w;
          }) ? U : null;
        }, m.prototype.fetch = function(w) {
          return this.images = w.reduce(f(this.findBackgroundImage, this), this.findImages(w)), this.images.forEach(function(U, I) {
            U.promise.then(function() {
              i("Succesfully loaded image #" + (I + 1), U);
            }, function(S) {
              i("Failed loading image #" + (I + 1), U, S);
            });
          }), this.ready = Promise.all(this.images.map(this.getPromise, this)), i("Finished searching images"), this;
        }, m.prototype.timeout = function(w, U) {
          var I, S = Promise.race([w.promise, new Promise(function(L, N) {
            I = setTimeout(function() {
              i("Timed out loading image", w), N(w);
            }, U);
          })]).then(function(L) {
            return clearTimeout(I), L;
          });
          return S.catch(function() {
            clearTimeout(I);
          }), S;
        }, p.exports = m;
      }, { "./dummyimagecontainer": 5, "./framecontainer": 8, "./imagecontainer": 10, "./lineargradientcontainer": 12, "./log": 13, "./proxyimagecontainer": 17, "./svgcontainer": 23, "./svgnodecontainer": 24, "./utils": 26, "./webkitgradientcontainer": 27 }], 12: [function(o, p, C) {
        var i = o("./gradientcontainer"), r = o("./color");
        function n(s) {
          i.apply(this, arguments), this.type = i.TYPES.LINEAR;
          var c = n.REGEXP_DIRECTION.test(s.args[0]) || !i.REGEXP_COLORSTOP.test(s.args[0]);
          c ? s.args[0].split(/\s+/).reverse().forEach(function(l, d) {
            switch (l) {
              case "left":
                this.x0 = 0, this.x1 = 1;
                break;
              case "top":
                this.y0 = 0, this.y1 = 1;
                break;
              case "right":
                this.x0 = 1, this.x1 = 0;
                break;
              case "bottom":
                this.y0 = 1, this.y1 = 0;
                break;
              case "to":
                var B = this.y0, h = this.x0;
                this.y0 = this.y1, this.x0 = this.x1, this.x1 = h, this.y1 = B;
                break;
              case "center":
                break;
              default:
                var f = 0.01 * parseFloat(l, 10);
                if (isNaN(f))
                  break;
                d === 0 ? (this.y0 = f, this.y1 = 1 - this.y0) : (this.x0 = f, this.x1 = 1 - this.x0);
            }
          }, this) : (this.y0 = 0, this.y1 = 1), this.colorStops = s.args.slice(c ? 1 : 0).map(function(l) {
            var d = l.match(i.REGEXP_COLORSTOP), B = +d[2], h = B === 0 ? "%" : d[3];
            return { color: new r(d[1]), stop: h === "%" ? B / 100 : null };
          }), this.colorStops[0].stop === null && (this.colorStops[0].stop = 0), this.colorStops[this.colorStops.length - 1].stop === null && (this.colorStops[this.colorStops.length - 1].stop = 1), this.colorStops.forEach(function(l, d) {
            l.stop === null && this.colorStops.slice(d).some(function(B, h) {
              return B.stop !== null && (l.stop = (B.stop - this.colorStops[d - 1].stop) / (h + 1) + this.colorStops[d - 1].stop, !0);
            }, this);
          }, this);
        }
        n.prototype = Object.create(i.prototype), n.REGEXP_DIRECTION = /^\s*(?:to|left|right|top|bottom|center|\d{1,3}(?:\.\d+)?%?)(?:\s|$)/i, p.exports = n;
      }, { "./color": 3, "./gradientcontainer": 9 }], 13: [function(o, p, C) {
        var i = function() {
          i.options.logging && window.console && window.console.log && Function.prototype.bind.call(window.console.log, window.console).apply(window.console, [Date.now() - i.options.start + "ms", "html2canvas:"].concat([].slice.call(arguments, 0)));
        };
        i.options = { logging: !1 }, p.exports = i;
      }, {}], 14: [function(o, p, C) {
        var i = o("./color"), r = o("./utils"), n = r.getBounds, s = r.parseBackgrounds, c = r.offsetBounds;
        function l(f, m) {
          this.node = f, this.parent = m, this.stack = null, this.bounds = null, this.borders = null, this.clip = [], this.backgroundClip = [], this.offsetBounds = null, this.visible = null, this.computedStyles = null, this.colors = {}, this.styles = {}, this.backgroundImages = null, this.transformData = null, this.transformMatrix = null, this.isPseudoElement = !1, this.opacity = null;
        }
        function d(f) {
          return f.toString().indexOf("%") !== -1;
        }
        function B(f) {
          return f.replace("px", "");
        }
        function h(f) {
          return parseFloat(f);
        }
        l.prototype.cloneTo = function(f) {
          f.visible = this.visible, f.borders = this.borders, f.bounds = this.bounds, f.clip = this.clip, f.backgroundClip = this.backgroundClip, f.computedStyles = this.computedStyles, f.styles = this.styles, f.backgroundImages = this.backgroundImages, f.opacity = this.opacity;
        }, l.prototype.getOpacity = function() {
          return this.opacity === null ? this.opacity = this.cssFloat("opacity") : this.opacity;
        }, l.prototype.assignStack = function(f) {
          (this.stack = f).children.push(this);
        }, l.prototype.isElementVisible = function() {
          return this.node.nodeType === Node.TEXT_NODE ? this.parent.visible : this.css("display") !== "none" && this.css("visibility") !== "hidden" && !this.node.hasAttribute("data-html2canvas-ignore") && (this.node.nodeName !== "INPUT" || this.node.getAttribute("type") !== "hidden");
        }, l.prototype.css = function(f) {
          return this.computedStyles || (this.computedStyles = this.isPseudoElement ? this.parent.computedStyle(this.before ? ":before" : ":after") : this.computedStyle(null)), this.styles[f] || (this.styles[f] = this.computedStyles[f]);
        }, l.prototype.prefixedCss = function(f) {
          var m = this.css(f);
          return m === void 0 && ["webkit", "moz", "ms", "o"].some(function(w) {
            return (m = this.css(w + f.substr(0, 1).toUpperCase() + f.substr(1))) !== void 0;
          }, this), m === void 0 ? null : m;
        }, l.prototype.computedStyle = function(f) {
          return this.node.ownerDocument.defaultView.getComputedStyle(this.node, f);
        }, l.prototype.cssInt = function(f) {
          var m = parseInt(this.css(f), 10);
          return isNaN(m) ? 0 : m;
        }, l.prototype.color = function(f) {
          return this.colors[f] || (this.colors[f] = new i(this.css(f)));
        }, l.prototype.cssFloat = function(f) {
          var m = parseFloat(this.css(f));
          return isNaN(m) ? 0 : m;
        }, l.prototype.fontWeight = function() {
          var f = this.css("fontWeight");
          switch (parseInt(f, 10)) {
            case 401:
              f = "bold";
              break;
            case 400:
              f = "normal";
          }
          return f;
        }, l.prototype.parseClip = function() {
          var f = this.css("clip").match(this.CLIP);
          return f ? { top: parseInt(f[1], 10), right: parseInt(f[2], 10), bottom: parseInt(f[3], 10), left: parseInt(f[4], 10) } : null;
        }, l.prototype.parseBackgroundImages = function() {
          return this.backgroundImages || (this.backgroundImages = s(this.css("backgroundImage")));
        }, l.prototype.cssList = function(f, m) {
          var w = (this.css(f) || "").split(",");
          return (w = (w = w[m || 0] || w[0] || "auto").trim().split(" ")).length === 1 && (w = [w[0], d(w[0]) ? "auto" : w[0]]), w;
        }, l.prototype.parseBackgroundSize = function(f, m, w) {
          var U, I, S = this.cssList("backgroundSize", w);
          if (d(S[0]))
            U = f.width * parseFloat(S[0]) / 100;
          else {
            if (/contain|cover/.test(S[0])) {
              var L = f.width / f.height, N = m.width / m.height;
              return L < N ^ S[0] === "contain" ? { width: f.height * N, height: f.height } : { width: f.width, height: f.width / N };
            }
            U = parseInt(S[0], 10);
          }
          return I = S[0] === "auto" && S[1] === "auto" ? m.height : S[1] === "auto" ? U / m.width * m.height : d(S[1]) ? f.height * parseFloat(S[1]) / 100 : parseInt(S[1], 10), S[0] === "auto" && (U = I / m.height * m.width), { width: U, height: I };
        }, l.prototype.parseBackgroundPosition = function(f, m, w, U) {
          var I, S, L = this.cssList("backgroundPosition", w);
          return I = d(L[0]) ? (f.width - (U || m).width) * (parseFloat(L[0]) / 100) : parseInt(L[0], 10), S = L[1] === "auto" ? I / m.width * m.height : d(L[1]) ? (f.height - (U || m).height) * parseFloat(L[1]) / 100 : parseInt(L[1], 10), L[0] === "auto" && (I = S / m.height * m.width), { left: I, top: S };
        }, l.prototype.parseBackgroundRepeat = function(f) {
          return this.cssList("backgroundRepeat", f)[0];
        }, l.prototype.parseTextShadows = function() {
          var f = this.css("textShadow"), m = [];
          if (f && f !== "none")
            for (var w = f.match(this.TEXT_SHADOW_PROPERTY), U = 0; w && U < w.length; U++) {
              var I = w[U].match(this.TEXT_SHADOW_VALUES);
              m.push({ color: new i(I[0]), offsetX: I[1] ? parseFloat(I[1].replace("px", "")) : 0, offsetY: I[2] ? parseFloat(I[2].replace("px", "")) : 0, blur: I[3] ? I[3].replace("px", "") : 0 });
            }
          return m;
        }, l.prototype.parseTransform = function() {
          if (!this.transformData)
            if (this.hasTransform()) {
              var f = this.parseBounds(), m = this.prefixedCss("transformOrigin").split(" ").map(B).map(h);
              m[0] += f.left, m[1] += f.top, this.transformData = { origin: m, matrix: this.parseTransformMatrix() };
            } else
              this.transformData = { origin: [0, 0], matrix: [1, 0, 0, 1, 0, 0] };
          return this.transformData;
        }, l.prototype.parseTransformMatrix = function() {
          if (!this.transformMatrix) {
            var f = this.prefixedCss("transform"), m = f ? function(w) {
              {
                if (w && w[1] === "matrix")
                  return w[2].split(",").map(function(I) {
                    return parseFloat(I.trim());
                  });
                if (w && w[1] === "matrix3d") {
                  var U = w[2].split(",").map(function(I) {
                    return parseFloat(I.trim());
                  });
                  return [U[0], U[1], U[4], U[5], U[12], U[13]];
                }
              }
            }(f.match(this.MATRIX_PROPERTY)) : null;
            this.transformMatrix = m || [1, 0, 0, 1, 0, 0];
          }
          return this.transformMatrix;
        }, l.prototype.parseBounds = function() {
          return this.bounds || (this.bounds = this.hasTransform() ? c(this.node) : n(this.node));
        }, l.prototype.hasTransform = function() {
          return this.parseTransformMatrix().join(",") !== "1,0,0,1,0,0" || this.parent && this.parent.hasTransform();
        }, l.prototype.getValue = function() {
          var f, m, w = this.node.value || "";
          return this.node.tagName === "SELECT" ? (f = this.node, w = (m = f.options[f.selectedIndex || 0]) && m.text || "") : this.node.type === "password" && (w = Array(w.length + 1).join("•")), w.length === 0 ? this.node.placeholder || "" : w;
        }, l.prototype.MATRIX_PROPERTY = /(matrix|matrix3d)\((.+)\)/, l.prototype.TEXT_SHADOW_PROPERTY = /((rgba|rgb)\([^\)]+\)(\s-?\d+px){0,})/g, l.prototype.TEXT_SHADOW_VALUES = /(-?\d+px)|(#.+)|(rgb\(.+\))|(rgba\(.+\))/g, l.prototype.CLIP = /^rect\((\d+)px,? (\d+)px,? (\d+)px,? (\d+)px\)$/, p.exports = l;
      }, { "./color": 3, "./utils": 26 }], 15: [function(o, p, C) {
        var i = o("./log"), r = o("punycode"), n = o("./nodecontainer"), s = o("./textcontainer"), c = o("./pseudoelementcontainer"), l = o("./fontmetrics"), d = o("./color"), B = o("./stackingcontext"), h = o("./utils"), f = h.bind, m = h.getBounds, w = h.parseBackgrounds, U = h.offsetBounds;
        function I(u, Q, H, O, eA) {
          i("Starting NodeParser"), this.renderer = Q, this.options = eA, this.range = null, this.support = H, this.renderQueue = [], this.stack = new B(!0, 1, u.ownerDocument, null);
          var sA = new n(u, null);
          if (eA.background && Q.rectangle(0, 0, Q.width, Q.height, new d(eA.background)), u === u.ownerDocument.documentElement) {
            var pA = new n(sA.color("backgroundColor").isTransparent() ? u.ownerDocument.body : u.ownerDocument.documentElement, null);
            Q.rectangle(0, 0, Q.width, Q.height, pA.color("backgroundColor"));
          }
          sA.visibile = sA.isElementVisible(), this.createPseudoHideStyles(u.ownerDocument), this.disableAnimations(u.ownerDocument), this.nodes = D([sA].concat(this.getChildren(sA)).filter(function(yA) {
            return yA.visible = yA.isElementVisible();
          }).map(this.getPseudoElements, this)), this.fontMetrics = new l(), i("Fetched nodes, total:", this.nodes.length), i("Calculate overflow clips"), this.calculateOverflowClips(), i("Start fetching images"), this.images = O.fetch(this.nodes.filter(M)), this.ready = this.images.ready.then(f(function() {
            return i("Images loaded, starting parsing"), i("Creating stacking contexts"), this.createStackingContexts(), i("Sorting stacking contexts"), this.sortStackingContexts(this.stack), this.parse(this.stack), i("Render queue created with " + this.renderQueue.length + " items"), new Promise(f(function(yA) {
              eA.async ? typeof eA.async == "function" ? eA.async.call(this, this.renderQueue, yA) : 0 < this.renderQueue.length ? (this.renderIndex = 0, this.asyncRenderer(this.renderQueue, yA)) : yA() : (this.renderQueue.forEach(this.paint, this), yA());
            }, this));
          }, this));
        }
        function S(u) {
          return u.parent && u.parent.clip.length;
        }
        function L() {
        }
        I.prototype.calculateOverflowClips = function() {
          this.nodes.forEach(function(u) {
            if (M(u)) {
              oA(u) && u.appendToDOM(), u.borders = this.parseBorders(u);
              var Q = u.css("overflow") === "hidden" ? [u.borders.clip] : [], H = u.parseClip();
              H && ["absolute", "fixed"].indexOf(u.css("position")) !== -1 && Q.push([["rect", u.bounds.left + H.left, u.bounds.top + H.top, H.right - H.left, H.bottom - H.top]]), u.clip = S(u) ? u.parent.clip.concat(Q) : Q, u.backgroundClip = u.css("overflow") !== "hidden" ? u.clip.concat([u.borders.clip]) : u.clip, oA(u) && u.cleanDOM();
            } else
              X(u) && (u.clip = S(u) ? u.parent.clip : []);
            oA(u) || (u.bounds = null);
          }, this);
        }, I.prototype.asyncRenderer = function(u, Q, H) {
          H = H || Date.now(), this.paint(u[this.renderIndex++]), u.length === this.renderIndex ? Q() : H + 20 > Date.now() ? this.asyncRenderer(u, Q, H) : setTimeout(f(function() {
            this.asyncRenderer(u, Q);
          }, this), 0);
        }, I.prototype.createPseudoHideStyles = function(u) {
          this.createStyles(u, "." + c.prototype.PSEUDO_HIDE_ELEMENT_CLASS_BEFORE + ':before { content: "" !important; display: none !important; }.' + c.prototype.PSEUDO_HIDE_ELEMENT_CLASS_AFTER + ':after { content: "" !important; display: none !important; }');
        }, I.prototype.disableAnimations = function(u) {
          this.createStyles(u, "* { -webkit-animation: none !important; -moz-animation: none !important; -o-animation: none !important; animation: none !important; -webkit-transition: none !important; -moz-transition: none !important; -o-transition: none !important; transition: none !important;}");
        }, I.prototype.createStyles = function(u, Q) {
          var H = u.createElement("style");
          H.innerHTML = Q, u.body.appendChild(H);
        }, I.prototype.getPseudoElements = function(u) {
          var Q = [[u]];
          if (u.node.nodeType === Node.ELEMENT_NODE) {
            var H = this.getPseudoElement(u, ":before"), O = this.getPseudoElement(u, ":after");
            H && Q.push(H), O && Q.push(O);
          }
          return D(Q);
        }, I.prototype.getPseudoElement = function(u, Q) {
          var H = u.computedStyle(Q);
          if (!H || !H.content || H.content === "none" || H.content === "-moz-alt-content" || H.display === "none")
            return null;
          for (var O, eA, sA = (O = H.content, (eA = O.substr(0, 1)) === O.substr(O.length - 1) && eA.match(/'|"/) ? O.substr(1, O.length - 2) : O), pA = sA.substr(0, 3) === "url", yA = document.createElement(pA ? "img" : "html2canvaspseudoelement"), wA = new c(yA, u, Q), SA = H.length - 1; 0 <= SA; SA--) {
            var xA = H.item(SA).replace(/(\-[a-z])/g, function(iA) {
              return iA.toUpperCase().replace("-", "");
            });
            yA.style[xA] = H[xA];
          }
          if (yA.className = c.prototype.PSEUDO_HIDE_ELEMENT_CLASS_BEFORE + " " + c.prototype.PSEUDO_HIDE_ELEMENT_CLASS_AFTER, pA)
            return yA.src = w(sA)[0].args[0], [wA];
          var KA = document.createTextNode(sA);
          return yA.appendChild(KA), [wA, new s(KA, wA)];
        }, I.prototype.getChildren = function(u) {
          return D([].filter.call(u.node.childNodes, F).map(function(Q) {
            var H = [Q.nodeType === Node.TEXT_NODE ? new s(Q, u) : new n(Q, u)].filter(b);
            return Q.nodeType === Node.ELEMENT_NODE && H.length && Q.tagName !== "TEXTAREA" ? H[0].isElementVisible() ? H.concat(this.getChildren(H[0])) : [] : H;
          }, this));
        }, I.prototype.newStackingContext = function(u, Q) {
          var H = new B(Q, u.getOpacity(), u.node, u.parent);
          u.cloneTo(H), (Q ? H.getParentStack(this) : H.parent.stack).contexts.push(H), u.stack = H;
        }, I.prototype.createStackingContexts = function() {
          this.nodes.forEach(function(u) {
            var Q, H;
            M(u) && (this.isRootElement(u) || u.getOpacity() < 1 || (H = (Q = u).css("position"), (["absolute", "relative", "fixed"].indexOf(H) !== -1 ? Q.css("zIndex") : "auto") !== "auto") || this.isBodyWithTransparentRoot(u) || u.hasTransform()) ? this.newStackingContext(u, !0) : M(u) && (R(u) && $(u) || ["inline-block", "inline-table"].indexOf(u.css("display")) !== -1 || E(u)) ? this.newStackingContext(u, !1) : u.assignStack(u.parent.stack);
          }, this);
        }, I.prototype.isBodyWithTransparentRoot = function(u) {
          return u.node.nodeName === "BODY" && u.parent.color("backgroundColor").isTransparent();
        }, I.prototype.isRootElement = function(u) {
          return u.parent === null;
        }, I.prototype.sortStackingContexts = function(u) {
          var Q;
          u.contexts.sort((Q = u.contexts.slice(0), function(H, O) {
            return H.cssInt("zIndex") + Q.indexOf(H) / Q.length - (O.cssInt("zIndex") + Q.indexOf(O) / Q.length);
          })), u.contexts.forEach(this.sortStackingContexts, this);
        }, I.prototype.parseTextBounds = function(u) {
          return function(Q, H, O) {
            if (u.parent.css("textDecoration").substr(0, 4) !== "none" || Q.trim().length !== 0) {
              if (this.support.rangeBounds && !u.parent.hasTransform()) {
                var eA = O.slice(0, H).join("").length;
                return this.getRangeBounds(u.node, eA, Q.length);
              }
              if (u.node && typeof u.node.data == "string") {
                var sA = u.node.splitText(Q.length), pA = this.getWrapperBounds(u.node, u.parent.hasTransform());
                return u.node = sA, pA;
              }
            } else
              this.support.rangeBounds && !u.parent.hasTransform() || (u.node = u.node.splitText(Q.length));
            return {};
          };
        }, I.prototype.getWrapperBounds = function(u, Q) {
          var H = u.ownerDocument.createElement("html2canvaswrapper"), O = u.parentNode, eA = u.cloneNode(!0);
          H.appendChild(u.cloneNode(!0)), O.replaceChild(H, u);
          var sA = Q ? U(H) : m(H);
          return O.replaceChild(eA, H), sA;
        }, I.prototype.getRangeBounds = function(u, Q, H) {
          var O = this.range || (this.range = u.ownerDocument.createRange());
          return O.setStart(u, Q), O.setEnd(u, Q + H), O.getBoundingClientRect();
        }, I.prototype.parse = function(u) {
          var Q = u.contexts.filter(_), H = u.children.filter(M), O = H.filter(G(E)), eA = O.filter(G(R)).filter(G(hA)), sA = H.filter(G(R)).filter(E), pA = O.filter(G(R)).filter(hA), yA = u.contexts.concat(O.filter(R)).filter($), wA = u.children.filter(X).filter(k), SA = u.contexts.filter(Y);
          Q.concat(eA).concat(sA).concat(pA).concat(yA).concat(wA).concat(SA).forEach(function(xA) {
            this.renderQueue.push(xA), z(xA) && (this.parse(xA), this.renderQueue.push(new L()));
          }, this);
        }, I.prototype.paint = function(u) {
          try {
            u instanceof L ? this.renderer.ctx.restore() : X(u) ? (oA(u.parent) && u.parent.appendToDOM(), this.paintText(u), oA(u.parent) && u.parent.cleanDOM()) : this.paintNode(u);
          } catch (Q) {
            if (i(Q), this.options.strict)
              throw Q;
          }
        }, I.prototype.paintNode = function(u) {
          z(u) && (this.renderer.setOpacity(u.opacity), this.renderer.ctx.save(), u.hasTransform() && this.renderer.setTransform(u.parseTransform())), u.node.nodeName === "INPUT" && u.node.type === "checkbox" ? this.paintCheckbox(u) : u.node.nodeName === "INPUT" && u.node.type === "radio" ? this.paintRadio(u) : this.paintElement(u);
        }, I.prototype.paintElement = function(u) {
          var Q = u.parseBounds();
          this.renderer.clip(u.backgroundClip, function() {
            this.renderer.renderBackground(u, Q, u.borders.borders.map(nA));
          }, this), this.renderer.clip(u.clip, function() {
            this.renderer.renderBorders(u.borders.borders);
          }, this), this.renderer.clip(u.backgroundClip, function() {
            switch (u.node.nodeName) {
              case "svg":
              case "IFRAME":
                var H = this.images.get(u.node);
                H ? this.renderer.renderImage(u, Q, u.borders, H) : i("Error loading <" + u.node.nodeName + ">", u.node);
                break;
              case "IMG":
                var O = this.images.get(u.node.src);
                O ? this.renderer.renderImage(u, Q, u.borders, O) : i("Error loading <img>", u.node.src);
                break;
              case "CANVAS":
                this.renderer.renderImage(u, Q, u.borders, { image: u.node });
                break;
              case "SELECT":
              case "INPUT":
              case "TEXTAREA":
                this.paintFormValue(u);
            }
          }, this);
        }, I.prototype.paintCheckbox = function(u) {
          var Q = u.parseBounds(), H = Math.min(Q.width, Q.height), O = { width: H - 1, height: H - 1, top: Q.top, left: Q.left }, eA = [3, 3], sA = [eA, eA, eA, eA], pA = [1, 1, 1, 1].map(function(wA) {
            return { color: new d("#A5A5A5"), width: wA };
          }), yA = W(O, sA, pA);
          this.renderer.clip(u.backgroundClip, function() {
            this.renderer.rectangle(O.left + 1, O.top + 1, O.width - 2, O.height - 2, new d("#DEDEDE")), this.renderer.renderBorders(j(pA, O, yA, sA)), u.node.checked && (this.renderer.font(new d("#424242"), "normal", "normal", "bold", H - 3 + "px", "arial"), this.renderer.text("✔", O.left + H / 6, O.top + H - 1));
          }, this);
        }, I.prototype.paintRadio = function(u) {
          var Q = u.parseBounds(), H = Math.min(Q.width, Q.height) - 2;
          this.renderer.clip(u.backgroundClip, function() {
            this.renderer.circleStroke(Q.left + 1, Q.top + 1, H, new d("#DEDEDE"), 1, new d("#A5A5A5")), u.node.checked && this.renderer.circle(Math.ceil(Q.left + H / 4) + 1, Math.ceil(Q.top + H / 4) + 1, Math.floor(H / 2), new d("#424242"));
          }, this);
        }, I.prototype.paintFormValue = function(u) {
          var Q = u.getValue();
          if (0 < Q.length) {
            var H = u.node.ownerDocument, O = H.createElement("html2canvaswrapper");
            ["lineHeight", "textAlign", "fontFamily", "fontWeight", "fontSize", "color", "paddingLeft", "paddingTop", "paddingRight", "paddingBottom", "width", "height", "borderLeftStyle", "borderTopStyle", "borderLeftWidth", "borderTopWidth", "boxSizing", "whiteSpace", "wordWrap"].forEach(function(sA) {
              try {
                O.style[sA] = u.css(sA);
              } catch (pA) {
                i("html2canvas: Parse: Exception caught in renderFormValue: " + pA.message);
              }
            });
            var eA = u.parseBounds();
            O.style.position = "fixed", O.style.left = eA.left + "px", O.style.top = eA.top + "px", O.textContent = Q, H.body.appendChild(O), this.paintText(new s(O.firstChild, u)), H.body.removeChild(O);
          }
        }, I.prototype.paintText = function(u) {
          u.applyTextTransform();
          var Q, H = r.ucs2.decode(u.node.data), O = this.options.letterRendering && !/^(normal|none|0px)$/.test(u.parent.css("letterSpacing")) || (Q = u.node.data, /[^\u0000-\u00ff]/.test(Q)) ? H.map(function(wA) {
            return r.ucs2.encode([wA]);
          }) : function(wA) {
            for (var SA, xA = [], KA = 0, iA = !1; wA.length; )
              yt = wA[KA], [32, 13, 10, 9, 45].indexOf(yt) !== -1 === iA ? ((SA = wA.splice(0, KA)).length && xA.push(r.ucs2.encode(SA)), iA = !iA, KA = 0) : KA++, KA >= wA.length && (SA = wA.splice(0, KA)).length && xA.push(r.ucs2.encode(SA));
            var yt;
            return xA;
          }(H), eA = u.parent.fontWeight(), sA = u.parent.css("fontSize"), pA = u.parent.css("fontFamily"), yA = u.parent.parseTextShadows();
          this.renderer.font(u.parent.color("color"), u.parent.css("fontStyle"), u.parent.css("fontVariant"), eA, sA, pA), yA.length ? this.renderer.fontShadow(yA[0].color, yA[0].offsetX, yA[0].offsetY, yA[0].blur) : this.renderer.clearShadow(), this.renderer.clip(u.parent.clip, function() {
            O.map(this.parseTextBounds(u), this).forEach(function(wA, SA) {
              wA && /^\s*$/.test(O[SA]) === !1 && (this.renderer.text(O[SA], wA.left, wA.bottom), this.renderTextDecoration(u.parent, wA, this.fontMetrics.getMetrics(pA, sA)));
            }, this);
          }, this);
        }, I.prototype.renderTextDecoration = function(u, Q, H) {
          switch (u.css("textDecoration").split(" ")[0]) {
            case "underline":
              this.renderer.rectangle(Q.left, Math.round(Q.top + H.baseline + H.lineWidth), Q.width, 1, u.color("color"));
              break;
            case "overline":
              this.renderer.rectangle(Q.left, Math.round(Q.top), Q.width, 1, u.color("color"));
              break;
            case "line-through":
              this.renderer.rectangle(Q.left, Math.ceil(Q.top + H.middle + H.lineWidth), Q.width, 1, u.color("color"));
          }
        };
        var N = { inset: [["darken", 0.6], ["darken", 0.1], ["darken", 0.1], ["darken", 0.6]] };
        function j(u, Q, H, O) {
          return u.map(function(eA, sA) {
            if (0 < eA.width) {
              var pA = Q.left, yA = Q.top, wA = Q.width, SA = Q.height - u[2].width;
              switch (sA) {
                case 0:
                  SA = u[0].width, eA.args = y({ c1: [pA, yA], c2: [pA + wA, yA], c3: [pA + wA - u[1].width, yA + SA], c4: [pA + u[3].width, yA + SA] }, O[0], O[1], H.topLeftOuter, H.topLeftInner, H.topRightOuter, H.topRightInner);
                  break;
                case 1:
                  pA = Q.left + Q.width - u[1].width, wA = u[1].width, eA.args = y({ c1: [pA + wA, yA], c2: [pA + wA, yA + SA + u[2].width], c3: [pA, yA + SA], c4: [pA, yA + u[0].width] }, O[1], O[2], H.topRightOuter, H.topRightInner, H.bottomRightOuter, H.bottomRightInner);
                  break;
                case 2:
                  yA = yA + Q.height - u[2].width, SA = u[2].width, eA.args = y({ c1: [pA + wA, yA + SA], c2: [pA, yA + SA], c3: [pA + u[3].width, yA], c4: [pA + wA - u[3].width, yA] }, O[2], O[3], H.bottomRightOuter, H.bottomRightInner, H.bottomLeftOuter, H.bottomLeftInner);
                  break;
                case 3:
                  wA = u[3].width, eA.args = y({ c1: [pA, yA + SA + u[2].width], c2: [pA, yA], c3: [pA + wA, yA + u[0].width], c4: [pA + wA, yA + SA] }, O[3], O[0], H.bottomLeftOuter, H.bottomLeftInner, H.topLeftOuter, H.topLeftInner);
              }
            }
            return eA;
          });
        }
        function Z(u, Q, H, O) {
          var eA = (Math.sqrt(2) - 1) / 3 * 4, sA = H * eA, pA = O * eA, yA = u + H, wA = Q + O;
          return { topLeft: V({ x: u, y: wA }, { x: u, y: wA - pA }, { x: yA - sA, y: Q }, { x: yA, y: Q }), topRight: V({ x: u, y: Q }, { x: u + sA, y: Q }, { x: yA, y: wA - pA }, { x: yA, y: wA }), bottomRight: V({ x: yA, y: Q }, { x: yA, y: Q + pA }, { x: u + sA, y: wA }, { x: u, y: wA }), bottomLeft: V({ x: yA, y: wA }, { x: yA - sA, y: wA }, { x: u, y: Q + pA }, { x: u, y: Q }) };
        }
        function W(u, Q, H) {
          var O = u.left, eA = u.top, sA = u.width, pA = u.height, yA = Q[0][0] < sA / 2 ? Q[0][0] : sA / 2, wA = Q[0][1] < pA / 2 ? Q[0][1] : pA / 2, SA = Q[1][0] < sA / 2 ? Q[1][0] : sA / 2, xA = Q[1][1] < pA / 2 ? Q[1][1] : pA / 2, KA = Q[2][0] < sA / 2 ? Q[2][0] : sA / 2, iA = Q[2][1] < pA / 2 ? Q[2][1] : pA / 2, yt = Q[3][0] < sA / 2 ? Q[3][0] : sA / 2, $A = Q[3][1] < pA / 2 ? Q[3][1] : pA / 2, st = sA - SA, kt = pA - iA, jA = sA - KA, gt = pA - $A;
          return { topLeftOuter: Z(O, eA, yA, wA).topLeft.subdivide(0.5), topLeftInner: Z(O + H[3].width, eA + H[0].width, Math.max(0, yA - H[3].width), Math.max(0, wA - H[0].width)).topLeft.subdivide(0.5), topRightOuter: Z(O + st, eA, SA, xA).topRight.subdivide(0.5), topRightInner: Z(O + Math.min(st, sA + H[3].width), eA + H[0].width, st > sA + H[3].width ? 0 : SA - H[3].width, xA - H[0].width).topRight.subdivide(0.5), bottomRightOuter: Z(O + jA, eA + kt, KA, iA).bottomRight.subdivide(0.5), bottomRightInner: Z(O + Math.min(jA, sA - H[3].width), eA + Math.min(kt, pA + H[0].width), Math.max(0, KA - H[1].width), iA - H[2].width).bottomRight.subdivide(0.5), bottomLeftOuter: Z(O, eA + gt, yt, $A).bottomLeft.subdivide(0.5), bottomLeftInner: Z(O + H[3].width, eA + gt, Math.max(0, yt - H[3].width), $A - H[2].width).bottomLeft.subdivide(0.5) };
        }
        function V(u, Q, H, O) {
          var eA = function(sA, pA, yA) {
            return { x: sA.x + (pA.x - sA.x) * yA, y: sA.y + (pA.y - sA.y) * yA };
          };
          return { start: u, startControl: Q, endControl: H, end: O, subdivide: function(sA) {
            var pA = eA(u, Q, sA), yA = eA(Q, H, sA), wA = eA(H, O, sA), SA = eA(pA, yA, sA), xA = eA(yA, wA, sA), KA = eA(SA, xA, sA);
            return [V(u, pA, SA, KA), V(KA, xA, wA, O)];
          }, curveTo: function(sA) {
            sA.push(["bezierCurve", Q.x, Q.y, H.x, H.y, O.x, O.y]);
          }, curveToReversed: function(sA) {
            sA.push(["bezierCurve", H.x, H.y, Q.x, Q.y, u.x, u.y]);
          } };
        }
        function y(u, Q, H, O, eA, sA, pA) {
          var yA = [];
          return 0 < Q[0] || 0 < Q[1] ? (yA.push(["line", O[1].start.x, O[1].start.y]), O[1].curveTo(yA)) : yA.push(["line", u.c1[0], u.c1[1]]), 0 < H[0] || 0 < H[1] ? (yA.push(["line", sA[0].start.x, sA[0].start.y]), sA[0].curveTo(yA), yA.push(["line", pA[0].end.x, pA[0].end.y]), pA[0].curveToReversed(yA)) : (yA.push(["line", u.c2[0], u.c2[1]]), yA.push(["line", u.c3[0], u.c3[1]])), 0 < Q[0] || 0 < Q[1] ? (yA.push(["line", eA[1].end.x, eA[1].end.y]), eA[1].curveToReversed(yA)) : yA.push(["line", u.c4[0], u.c4[1]]), yA;
        }
        function P(u, Q, H, O, eA, sA, pA) {
          0 < Q[0] || 0 < Q[1] ? (u.push(["line", O[0].start.x, O[0].start.y]), O[0].curveTo(u), O[1].curveTo(u)) : u.push(["line", sA, pA]), (0 < H[0] || 0 < H[1]) && u.push(["line", eA[0].start.x, eA[0].start.y]);
        }
        function _(u) {
          return u.cssInt("zIndex") < 0;
        }
        function Y(u) {
          return 0 < u.cssInt("zIndex");
        }
        function $(u) {
          return u.cssInt("zIndex") === 0;
        }
        function hA(u) {
          return ["inline", "inline-block", "inline-table"].indexOf(u.css("display")) !== -1;
        }
        function z(u) {
          return u instanceof B;
        }
        function k(u) {
          return 0 < u.node.data.trim().length;
        }
        function F(u) {
          return u.nodeType === Node.TEXT_NODE || u.nodeType === Node.ELEMENT_NODE;
        }
        function R(u) {
          return u.css("position") !== "static";
        }
        function E(u) {
          return u.css("float") !== "none";
        }
        function G(u) {
          var Q = this;
          return function() {
            return !u.apply(Q, arguments);
          };
        }
        function M(u) {
          return u.node.nodeType === Node.ELEMENT_NODE;
        }
        function oA(u) {
          return u.isPseudoElement === !0;
        }
        function X(u) {
          return u.node.nodeType === Node.TEXT_NODE;
        }
        function fA(u) {
          return parseInt(u, 10);
        }
        function nA(u) {
          return u.width;
        }
        function b(u) {
          return u.node.nodeType !== Node.ELEMENT_NODE || ["SCRIPT", "HEAD", "TITLE", "OBJECT", "BR", "OPTION"].indexOf(u.node.nodeName) === -1;
        }
        function D(u) {
          return [].concat.apply([], u);
        }
        I.prototype.parseBorders = function(u) {
          var Q, H = u.parseBounds(), O = (Q = u, ["TopLeft", "TopRight", "BottomRight", "BottomLeft"].map(function(pA) {
            var yA = Q.css("border" + pA + "Radius"), wA = yA.split(" ");
            return wA.length <= 1 && (wA[1] = wA[0]), wA.map(fA);
          })), eA = ["Top", "Right", "Bottom", "Left"].map(function(pA, yA) {
            var wA = u.css("border" + pA + "Style"), SA = u.color("border" + pA + "Color");
            wA === "inset" && SA.isBlack() && (SA = new d([255, 255, 255, SA.a]));
            var xA = N[wA] ? N[wA][yA] : null;
            return { width: u.cssInt("border" + pA + "Width"), color: xA ? SA[xA[0]](xA[1]) : SA, args: null };
          }), sA = W(H, O, eA);
          return { clip: this.parseBackgroundClip(u, sA, eA, O, H), borders: j(eA, H, sA, O) };
        }, I.prototype.parseBackgroundClip = function(u, Q, H, O, eA) {
          var sA = [];
          switch (u.css("backgroundClip")) {
            case "content-box":
            case "padding-box":
              P(sA, O[0], O[1], Q.topLeftInner, Q.topRightInner, eA.left + H[3].width, eA.top + H[0].width), P(sA, O[1], O[2], Q.topRightInner, Q.bottomRightInner, eA.left + eA.width - H[1].width, eA.top + H[0].width), P(sA, O[2], O[3], Q.bottomRightInner, Q.bottomLeftInner, eA.left + eA.width - H[1].width, eA.top + eA.height - H[2].width), P(sA, O[3], O[0], Q.bottomLeftInner, Q.topLeftInner, eA.left + H[3].width, eA.top + eA.height - H[2].width);
              break;
            default:
              P(sA, O[0], O[1], Q.topLeftOuter, Q.topRightOuter, eA.left, eA.top), P(sA, O[1], O[2], Q.topRightOuter, Q.bottomRightOuter, eA.left + eA.width, eA.top), P(sA, O[2], O[3], Q.bottomRightOuter, Q.bottomLeftOuter, eA.left + eA.width, eA.top + eA.height), P(sA, O[3], O[0], Q.bottomLeftOuter, Q.topLeftOuter, eA.left, eA.top + eA.height);
          }
          return sA;
        }, p.exports = I;
      }, { "./color": 3, "./fontmetrics": 7, "./log": 13, "./nodecontainer": 14, "./pseudoelementcontainer": 18, "./stackingcontext": 21, "./textcontainer": 25, "./utils": 26, punycode: 1 }], 16: [function(o, p, C) {
        var i = o("./xhr"), r = o("./utils"), n = o("./log"), s = o("./clone"), c = r.decode64;
        function l(m, w, U) {
          var I = "withCredentials" in new XMLHttpRequest();
          if (!w)
            return Promise.reject("No proxy configured");
          var S = h(I), L = f(w, m, S);
          return I ? i(L) : B(U, L, S).then(function(N) {
            return c(N.content);
          });
        }
        var d = 0;
        function B(m, w, U) {
          return new Promise(function(I, S) {
            var L = m.createElement("script"), N = function() {
              delete window.html2canvas.proxy[U], m.body.removeChild(L);
            };
            window.html2canvas.proxy[U] = function(j) {
              N(), I(j);
            }, L.src = w, L.onerror = function(j) {
              N(), S(j);
            }, m.body.appendChild(L);
          });
        }
        function h(m) {
          return m ? "" : "html2canvas_" + Date.now() + "_" + ++d + "_" + Math.round(1e5 * Math.random());
        }
        function f(m, w, U) {
          return m + "?url=" + encodeURIComponent(w) + (U.length ? "&callback=html2canvas.proxy." + U : "");
        }
        C.Proxy = l, C.ProxyURL = function(m, w, U) {
          var I = "crossOrigin" in new Image(), S = h(I), L = f(w, m, S);
          return I ? Promise.resolve(L) : B(U, L, S).then(function(N) {
            return "data:" + N.type + ";base64," + N.content;
          });
        }, C.loadUrlDocument = function(m, w, U, I, S, L) {
          return new l(m, w, window.document).then((N = m, function(j) {
            var Z, W = new DOMParser();
            try {
              Z = W.parseFromString(j, "text/html");
            } catch {
              n("DOMParser not supported, falling back to createHTMLDocument"), Z = document.implementation.createHTMLDocument("");
              try {
                Z.open(), Z.write(j), Z.close();
              } catch {
                n("createHTMLDocument write not supported, falling back to document.body.innerHTML"), Z.body.innerHTML = j;
              }
            }
            var V = Z.querySelector("base");
            if (!V || !V.href.host) {
              var y = Z.createElement("base");
              y.href = N, Z.head.insertBefore(y, Z.head.firstChild);
            }
            return Z;
          })).then(function(j) {
            return s(j, U, I, S, L, 0, 0);
          });
          var N;
        };
      }, { "./clone": 2, "./log": 13, "./utils": 26, "./xhr": 28 }], 17: [function(o, p, C) {
        var i = o("./proxy").ProxyURL;
        p.exports = function(r, n) {
          var s = document.createElement("a");
          s.href = r, r = s.href, this.src = r, this.image = new Image();
          var c = this;
          this.promise = new Promise(function(l, d) {
            c.image.crossOrigin = "Anonymous", c.image.onload = l, c.image.onerror = d, new i(r, n, document).then(function(B) {
              c.image.src = B;
            }).catch(d);
          });
        };
      }, { "./proxy": 16 }], 18: [function(o, p, C) {
        var i = o("./nodecontainer");
        function r(n, s, c) {
          i.call(this, n, s), this.isPseudoElement = !0, this.before = c === ":before";
        }
        r.prototype.cloneTo = function(n) {
          r.prototype.cloneTo.call(this, n), n.isPseudoElement = !0, n.before = this.before;
        }, (r.prototype = Object.create(i.prototype)).appendToDOM = function() {
          this.before ? this.parent.node.insertBefore(this.node, this.parent.node.firstChild) : this.parent.node.appendChild(this.node), this.parent.node.className += " " + this.getHideClass();
        }, r.prototype.cleanDOM = function() {
          this.node.parentNode.removeChild(this.node), this.parent.node.className = this.parent.node.className.replace(this.getHideClass(), "");
        }, r.prototype.getHideClass = function() {
          return this["PSEUDO_HIDE_ELEMENT_CLASS_" + (this.before ? "BEFORE" : "AFTER")];
        }, r.prototype.PSEUDO_HIDE_ELEMENT_CLASS_BEFORE = "___html2canvas___pseudoelement_before", r.prototype.PSEUDO_HIDE_ELEMENT_CLASS_AFTER = "___html2canvas___pseudoelement_after", p.exports = r;
      }, { "./nodecontainer": 14 }], 19: [function(o, p, C) {
        var i = o("./log");
        function r(n, s, c, l, d) {
          this.width = n, this.height = s, this.images = c, this.options = l, this.document = d;
        }
        r.prototype.renderImage = function(n, s, c, l) {
          var d = n.cssInt("paddingLeft"), B = n.cssInt("paddingTop"), h = n.cssInt("paddingRight"), f = n.cssInt("paddingBottom"), m = c.borders, w = s.width - (m[1].width + m[3].width + d + h), U = s.height - (m[0].width + m[2].width + B + f);
          this.drawImage(l, 0, 0, l.image.width || w, l.image.height || U, s.left + d + m[3].width, s.top + B + m[0].width, w, U);
        }, r.prototype.renderBackground = function(n, s, c) {
          0 < s.height && 0 < s.width && (this.renderBackgroundColor(n, s), this.renderBackgroundImage(n, s, c));
        }, r.prototype.renderBackgroundColor = function(n, s) {
          var c = n.color("backgroundColor");
          c.isTransparent() || this.rectangle(s.left, s.top, s.width, s.height, c);
        }, r.prototype.renderBorders = function(n) {
          n.forEach(this.renderBorder, this);
        }, r.prototype.renderBorder = function(n) {
          n.color.isTransparent() || n.args === null || this.drawShape(n.args, n.color);
        }, r.prototype.renderBackgroundImage = function(n, s, c) {
          n.parseBackgroundImages().reverse().forEach(function(l, d, B) {
            switch (l.method) {
              case "url":
                var h = this.images.get(l.args[0]);
                h ? this.renderBackgroundRepeating(n, s, h, B.length - (d + 1), c) : i("Error loading background-image", l.args[0]);
                break;
              case "linear-gradient":
              case "gradient":
                var f = this.images.get(l.value);
                f ? this.renderBackgroundGradient(f, s, c) : i("Error loading background-image", l.args[0]);
                break;
              case "none":
                break;
              default:
                i("Unknown background-image type", l.args[0]);
            }
          }, this);
        }, r.prototype.renderBackgroundRepeating = function(n, s, c, l, d) {
          var B = n.parseBackgroundSize(s, c.image, l), h = n.parseBackgroundPosition(s, c.image, l, B);
          switch (n.parseBackgroundRepeat(l)) {
            case "repeat-x":
            case "repeat no-repeat":
              this.backgroundRepeatShape(c, h, B, s, s.left + d[3], s.top + h.top + d[0], 99999, B.height, d);
              break;
            case "repeat-y":
            case "no-repeat repeat":
              this.backgroundRepeatShape(c, h, B, s, s.left + h.left + d[3], s.top + d[0], B.width, 99999, d);
              break;
            case "no-repeat":
              this.backgroundRepeatShape(c, h, B, s, s.left + h.left + d[3], s.top + h.top + d[0], B.width, B.height, d);
              break;
            default:
              this.renderBackgroundRepeat(c, h, B, { top: s.top, left: s.left }, d[3], d[0]);
          }
        }, p.exports = r;
      }, { "./log": 13 }], 20: [function(o, p, C) {
        var i = o("../renderer"), r = o("../lineargradientcontainer"), n = o("../log");
        function s(l, d) {
          i.apply(this, arguments), this.canvas = this.options.canvas || this.document.createElement("canvas"), this.options.canvas || (this.canvas.width = l, this.canvas.height = d), this.ctx = this.canvas.getContext("2d"), this.taintCtx = this.document.createElement("canvas").getContext("2d"), this.ctx.textBaseline = "bottom", this.variables = {}, n("Initialized CanvasRenderer with size", l, "x", d);
        }
        function c(l) {
          return 0 < l.length;
        }
        (s.prototype = Object.create(i.prototype)).setFillStyle = function(l) {
          return this.ctx.fillStyle = typeof l == "object" && l.isColor ? l.toString() : l, this.ctx;
        }, s.prototype.rectangle = function(l, d, B, h, f) {
          this.setFillStyle(f).fillRect(l, d, B, h);
        }, s.prototype.circle = function(l, d, B, h) {
          this.setFillStyle(h), this.ctx.beginPath(), this.ctx.arc(l + B / 2, d + B / 2, B / 2, 0, 2 * Math.PI, !0), this.ctx.closePath(), this.ctx.fill();
        }, s.prototype.circleStroke = function(l, d, B, h, f, m) {
          this.circle(l, d, B, h), this.ctx.strokeStyle = m.toString(), this.ctx.stroke();
        }, s.prototype.drawShape = function(l, d) {
          this.shape(l), this.setFillStyle(d).fill();
        }, s.prototype.taints = function(l) {
          if (l.tainted === null) {
            this.taintCtx.drawImage(l.image, 0, 0);
            try {
              this.taintCtx.getImageData(0, 0, 1, 1), l.tainted = !1;
            } catch {
              this.taintCtx = document.createElement("canvas").getContext("2d"), l.tainted = !0;
            }
          }
          return l.tainted;
        }, s.prototype.drawImage = function(l, d, B, h, f, m, w, U, I) {
          this.taints(l) && !this.options.allowTaint || this.ctx.drawImage(l.image, d, B, h, f, m, w, U, I);
        }, s.prototype.clip = function(l, d, B) {
          this.ctx.save(), l.filter(c).forEach(function(h) {
            this.shape(h).clip();
          }, this), d.call(B), this.ctx.restore();
        }, s.prototype.shape = function(l) {
          return this.ctx.beginPath(), l.forEach(function(d, B) {
            d[0] === "rect" ? this.ctx.rect.apply(this.ctx, d.slice(1)) : this.ctx[B === 0 ? "moveTo" : d[0] + "To"].apply(this.ctx, d.slice(1));
          }, this), this.ctx.closePath(), this.ctx;
        }, s.prototype.font = function(l, d, B, h, f, m) {
          this.setFillStyle(l).font = [d, B, h, f, m].join(" ").split(",")[0];
        }, s.prototype.fontShadow = function(l, d, B, h) {
          this.setVariable("shadowColor", l.toString()).setVariable("shadowOffsetY", d).setVariable("shadowOffsetX", B).setVariable("shadowBlur", h);
        }, s.prototype.clearShadow = function() {
          this.setVariable("shadowColor", "rgba(0,0,0,0)");
        }, s.prototype.setOpacity = function(l) {
          this.ctx.globalAlpha = l;
        }, s.prototype.setTransform = function(l) {
          this.ctx.translate(l.origin[0], l.origin[1]), this.ctx.transform.apply(this.ctx, l.matrix), this.ctx.translate(-l.origin[0], -l.origin[1]);
        }, s.prototype.setVariable = function(l, d) {
          return this.variables[l] !== d && (this.variables[l] = this.ctx[l] = d), this;
        }, s.prototype.text = function(l, d, B) {
          this.ctx.fillText(l, d, B);
        }, s.prototype.backgroundRepeatShape = function(l, d, B, h, f, m, w, U, I) {
          var S = [["line", Math.round(f), Math.round(m)], ["line", Math.round(f + w), Math.round(m)], ["line", Math.round(f + w), Math.round(U + m)], ["line", Math.round(f), Math.round(U + m)]];
          this.clip([S], function() {
            this.renderBackgroundRepeat(l, d, B, h, I[3], I[0]);
          }, this);
        }, s.prototype.renderBackgroundRepeat = function(l, d, B, h, f, m) {
          var w = Math.round(h.left + d.left + f), U = Math.round(h.top + d.top + m);
          this.setFillStyle(this.ctx.createPattern(this.resizeImage(l, B), "repeat")), this.ctx.translate(w, U), this.ctx.fill(), this.ctx.translate(-w, -U);
        }, s.prototype.renderBackgroundGradient = function(l, d) {
          if (l instanceof r) {
            var B = this.ctx.createLinearGradient(d.left + d.width * l.x0, d.top + d.height * l.y0, d.left + d.width * l.x1, d.top + d.height * l.y1);
            l.colorStops.forEach(function(h) {
              B.addColorStop(h.stop, h.color.toString());
            }), this.rectangle(d.left, d.top, d.width, d.height, B);
          }
        }, s.prototype.resizeImage = function(l, d) {
          var B = l.image;
          if (B.width === d.width && B.height === d.height)
            return B;
          var h = document.createElement("canvas");
          return h.width = d.width, h.height = d.height, h.getContext("2d").drawImage(B, 0, 0, B.width, B.height, 0, 0, d.width, d.height), h;
        }, p.exports = s;
      }, { "../lineargradientcontainer": 12, "../log": 13, "../renderer": 19 }], 21: [function(o, p, C) {
        var i = o("./nodecontainer");
        function r(n, s, c, l) {
          i.call(this, c, l), this.ownStacking = n, this.contexts = [], this.children = [], this.opacity = (this.parent ? this.parent.stack.opacity : 1) * s;
        }
        (r.prototype = Object.create(i.prototype)).getParentStack = function(n) {
          var s = this.parent ? this.parent.stack : null;
          return s ? s.ownStacking ? s : s.getParentStack(n) : n.stack;
        }, p.exports = r;
      }, { "./nodecontainer": 14 }], 22: [function(o, p, C) {
        function i(r) {
          this.rangeBounds = this.testRangeBounds(r), this.cors = this.testCORS(), this.svg = this.testSVG();
        }
        i.prototype.testRangeBounds = function(r) {
          var n, s, c = !1;
          return r.createRange && (n = r.createRange()).getBoundingClientRect && ((s = r.createElement("boundtest")).style.height = "123px", s.style.display = "block", r.body.appendChild(s), n.selectNode(s), n.getBoundingClientRect().height === 123 && (c = !0), r.body.removeChild(s)), c;
        }, i.prototype.testCORS = function() {
          return new Image().crossOrigin !== void 0;
        }, i.prototype.testSVG = function() {
          var r = new Image(), n = document.createElement("canvas"), s = n.getContext("2d");
          r.src = "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg'></svg>";
          try {
            s.drawImage(r, 0, 0), n.toDataURL();
          } catch {
            return !1;
          }
          return !0;
        }, p.exports = i;
      }, {}], 23: [function(o, p, C) {
        var i = o("./xhr"), r = o("./utils").decode64;
        function n(s) {
          this.src = s, this.image = null;
          var c = this;
          this.promise = this.hasFabric().then(function() {
            return c.isInline(s) ? Promise.resolve(c.inlineFormatting(s)) : i(s);
          }).then(function(l) {
            return new Promise(function(d) {
              window.html2canvas.svg.fabric.loadSVGFromString(l, c.createCanvas.call(c, d));
            });
          });
        }
        n.prototype.hasFabric = function() {
          return window.html2canvas.svg && window.html2canvas.svg.fabric ? Promise.resolve() : Promise.reject(new Error("html2canvas.svg.js is not loaded, cannot render svg"));
        }, n.prototype.inlineFormatting = function(s) {
          return /^data:image\/svg\+xml;base64,/.test(s) ? this.decode64(this.removeContentType(s)) : this.removeContentType(s);
        }, n.prototype.removeContentType = function(s) {
          return s.replace(/^data:image\/svg\+xml(;base64)?,/, "");
        }, n.prototype.isInline = function(s) {
          return /^data:image\/svg\+xml/i.test(s);
        }, n.prototype.createCanvas = function(s) {
          var c = this;
          return function(l, d) {
            var B = new window.html2canvas.svg.fabric.StaticCanvas("c");
            c.image = B.lowerCanvasEl, B.setWidth(d.width).setHeight(d.height).add(window.html2canvas.svg.fabric.util.groupSVGElements(l, d)).renderAll(), s(B.lowerCanvasEl);
          };
        }, n.prototype.decode64 = function(s) {
          return typeof window.atob == "function" ? window.atob(s) : r(s);
        }, p.exports = n;
      }, { "./utils": 26, "./xhr": 28 }], 24: [function(o, p, C) {
        var i = o("./svgcontainer");
        function r(n, s) {
          this.src = n, this.image = null;
          var c = this;
          this.promise = s ? new Promise(function(l, d) {
            c.image = new Image(), c.image.onload = l, c.image.onerror = d, c.image.src = "data:image/svg+xml," + new XMLSerializer().serializeToString(n), c.image.complete === !0 && l(c.image);
          }) : this.hasFabric().then(function() {
            return new Promise(function(l) {
              window.html2canvas.svg.fabric.parseSVGDocument(n, c.createCanvas.call(c, l));
            });
          });
        }
        r.prototype = Object.create(i.prototype), p.exports = r;
      }, { "./svgcontainer": 23 }], 25: [function(o, p, C) {
        var i = o("./nodecontainer");
        function r(s, c) {
          i.call(this, s, c);
        }
        function n(s, c, l) {
          if (0 < s.length)
            return c + l.toUpperCase();
        }
        (r.prototype = Object.create(i.prototype)).applyTextTransform = function() {
          this.node.data = this.transform(this.parent.css("textTransform"));
        }, r.prototype.transform = function(s) {
          var c = this.node.data;
          switch (s) {
            case "lowercase":
              return c.toLowerCase();
            case "capitalize":
              return c.replace(/(^|\s|:|-|\(|\))([a-z])/g, n);
            case "uppercase":
              return c.toUpperCase();
            default:
              return c;
          }
        }, p.exports = r;
      }, { "./nodecontainer": 14 }], 26: [function(o, p, C) {
        C.smallImage = function() {
          return "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
        }, C.bind = function(i, r) {
          return function() {
            return i.apply(r, arguments);
          };
        }, /*
           * base64-arraybuffer
           * https://github.com/niklasvh/base64-arraybuffer
           *
           * Copyright (c) 2012 Niklas von Hertzen
           * Licensed under the MIT license.
           */
        C.decode64 = function(i) {
          var r, n, s, c, l, d, B, h = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", f = i.length, m = "";
          for (r = 0; r < f; r += 4)
            l = h.indexOf(i[r]) << 2 | (n = h.indexOf(i[r + 1])) >> 4, d = (15 & n) << 4 | (s = h.indexOf(i[r + 2])) >> 2, B = (3 & s) << 6 | (c = h.indexOf(i[r + 3])), m += s === 64 ? String.fromCharCode(l) : c === 64 || c === -1 ? String.fromCharCode(l, d) : String.fromCharCode(l, d, B);
          return m;
        }, C.getBounds = function(i) {
          if (i.getBoundingClientRect) {
            var r = i.getBoundingClientRect(), n = i.offsetWidth == null ? r.width : i.offsetWidth;
            return { top: r.top, bottom: r.bottom || r.top + r.height, right: r.left + n, left: r.left, width: n, height: i.offsetHeight == null ? r.height : i.offsetHeight };
          }
          return {};
        }, C.offsetBounds = function(i) {
          var r = i.offsetParent ? C.offsetBounds(i.offsetParent) : { top: 0, left: 0 };
          return { top: i.offsetTop + r.top, bottom: i.offsetTop + i.offsetHeight + r.top, right: i.offsetLeft + r.left + i.offsetWidth, left: i.offsetLeft + r.left, width: i.offsetWidth, height: i.offsetHeight };
        }, C.parseBackgrounds = function(i) {
          var r, n, s, c, l, d, B, h = [], f = 0, m = 0, w = function() {
            r && (n.substr(0, 1) === '"' && (n = n.substr(1, n.length - 2)), n && B.push(n), r.substr(0, 1) === "-" && 0 < (c = r.indexOf("-", 1) + 1) && (s = r.substr(0, c), r = r.substr(c)), h.push({ prefix: s, method: r.toLowerCase(), value: l, args: B, image: null })), B = [], r = s = n = l = "";
          };
          return B = [], r = s = n = l = "", i.split("").forEach(function(U) {
            if (!(f === 0 && -1 < ` \r
	`.indexOf(U))) {
              switch (U) {
                case '"':
                  d ? d === U && (d = null) : d = U;
                  break;
                case "(":
                  if (d)
                    break;
                  if (f === 0)
                    return f = 1, void (l += U);
                  m++;
                  break;
                case ")":
                  if (d)
                    break;
                  if (f === 1) {
                    if (m === 0)
                      return f = 0, l += U, void w();
                    m--;
                  }
                  break;
                case ",":
                  if (d)
                    break;
                  if (f === 0)
                    return void w();
                  if (f === 1 && m === 0 && !r.match(/^url$/i))
                    return B.push(n), n = "", void (l += U);
              }
              l += U, f === 0 ? r += U : n += U;
            }
          }), w(), h;
        };
      }, {}], 27: [function(o, p, C) {
        var i = o("./gradientcontainer");
        function r(n) {
          i.apply(this, arguments), this.type = n.args[0] === "linear" ? i.TYPES.LINEAR : i.TYPES.RADIAL;
        }
        r.prototype = Object.create(i.prototype), p.exports = r;
      }, { "./gradientcontainer": 9 }], 28: [function(o, p, C) {
        p.exports = function(i) {
          return new Promise(function(r, n) {
            var s = new XMLHttpRequest();
            s.open("GET", i), s.onload = function() {
              s.status === 200 ? r(s.responseText) : n(new Error(s.statusText));
            }, s.onerror = function() {
              n(new Error("Network Error"));
            }, s.send();
          });
        };
      }, {}] }, {}, [4])(4);
    }), function(o) {
      var p = "+".charCodeAt(0), C = "/".charCodeAt(0), i = "0".charCodeAt(0), r = "a".charCodeAt(0), n = "A".charCodeAt(0), s = "-".charCodeAt(0), c = "_".charCodeAt(0), l = function(z) {
        var k = z.charCodeAt(0);
        return k === p || k === s ? 62 : k === C || k === c ? 63 : k < i ? -1 : k < i + 10 ? k - i + 26 + 26 : k < n + 26 ? k - n : k < r + 26 ? k - r + 26 : void 0;
      };
      o.API.TTFFont = function() {
        function z(k, F, R) {
          var E;
          if (this.rawData = k, E = this.contents = new B(k), this.contents.pos = 4, E.readString(4) === "ttcf")
            throw F ? new Error("Font " + F + " not found in TTC file.") : new Error("Must specify a font name for TTC files.");
          E.pos = 0, this.parse(), this.subset = new hA(this), this.registerTTF();
        }
        return z.open = function(k, F, R, E) {
          return new z(function(G) {
            var M, oA, X, fA, nA, b;
            if (0 < G.length % 4)
              throw new Error("Invalid string. Length must be a multiple of 4");
            var D = G.length;
            nA = G.charAt(D - 2) === "=" ? 2 : G.charAt(D - 1) === "=" ? 1 : 0, b = new Uint8Array(3 * G.length / 4 - nA), X = 0 < nA ? G.length - 4 : G.length;
            var u = 0;
            function Q(H) {
              b[u++] = H;
            }
            for (oA = M = 0; M < X; M += 4, oA += 3)
              Q((16711680 & (fA = l(G.charAt(M)) << 18 | l(G.charAt(M + 1)) << 12 | l(G.charAt(M + 2)) << 6 | l(G.charAt(M + 3)))) >> 16), Q((65280 & fA) >> 8), Q(255 & fA);
            return nA === 2 ? Q(255 & (fA = l(G.charAt(M)) << 2 | l(G.charAt(M + 1)) >> 4)) : nA === 1 && (Q((fA = l(G.charAt(M)) << 10 | l(G.charAt(M + 1)) << 4 | l(G.charAt(M + 2)) >> 2) >> 8 & 255), Q(255 & fA)), b;
          }(R), F);
        }, z.prototype.parse = function() {
          return this.directory = new h(this.contents), this.head = new w(this), this.name = new Z(this), this.cmap = new I(this), this.hhea = new S(this), this.maxp = new W(this), this.hmtx = new V(this), this.post = new N(this), this.os2 = new L(this), this.loca = new $(this), this.glyf = new P(this), this.ascender = this.os2.exists && this.os2.ascender || this.hhea.ascender, this.decender = this.os2.exists && this.os2.decender || this.hhea.decender, this.lineGap = this.os2.exists && this.os2.lineGap || this.hhea.lineGap, this.bbox = [this.head.xMin, this.head.yMin, this.head.xMax, this.head.yMax];
        }, z.prototype.registerTTF = function() {
          var k, F, R, E, G;
          if (this.scaleFactor = 1e3 / this.head.unitsPerEm, this.bbox = (function() {
            var M, oA, X, fA;
            for (fA = [], M = 0, oA = (X = this.bbox).length; M < oA; M++)
              k = X[M], fA.push(Math.round(k * this.scaleFactor));
            return fA;
          }).call(this), this.stemV = 0, this.post.exists ? (R = 255 & (E = this.post.italic_angle), !0 & (F = E >> 16) && (F = -(1 + (65535 ^ F))), this.italicAngle = +(F + "." + R)) : this.italicAngle = 0, this.ascender = Math.round(this.ascender * this.scaleFactor), this.decender = Math.round(this.decender * this.scaleFactor), this.lineGap = Math.round(this.lineGap * this.scaleFactor), this.capHeight = this.os2.exists && this.os2.capHeight || this.ascender, this.xHeight = this.os2.exists && this.os2.xHeight || 0, this.familyClass = (this.os2.exists && this.os2.familyClass || 0) >> 8, this.isSerif = (G = this.familyClass) === 1 || G === 2 || G === 3 || G === 4 || G === 5 || G === 7, this.isScript = this.familyClass === 10, this.flags = 0, this.post.isFixedPitch && (this.flags |= 1), this.isSerif && (this.flags |= 2), this.isScript && (this.flags |= 8), this.italicAngle !== 0 && (this.flags |= 64), this.flags |= 32, !this.cmap.unicode)
            throw new Error("No unicode cmap for font");
        }, z.prototype.characterToGlyph = function(k) {
          var F;
          return ((F = this.cmap.unicode) != null ? F.codeMap[k] : void 0) || 0;
        }, z.prototype.widthOfGlyph = function(k) {
          var F;
          return F = 1e3 / this.head.unitsPerEm, this.hmtx.forGlyph(k).advance * F;
        }, z.prototype.widthOfString = function(k, F, R) {
          var E, G, M, oA, X;
          for (G = oA = M = 0, X = (k = "" + k).length; 0 <= X ? oA < X : X < oA; G = 0 <= X ? ++oA : --oA)
            E = k.charCodeAt(G), M += this.widthOfGlyph(this.characterToGlyph(E)) + R * (1e3 / F) || 0;
          return M * (F / 1e3);
        }, z.prototype.lineHeight = function(k, F) {
          var R;
          return F == null && (F = !1), R = F ? this.lineGap : 0, (this.ascender + R - this.decender) / 1e3 * k;
        }, z;
      }();
      var d, B = function() {
        function z(k) {
          this.data = k ?? [], this.pos = 0, this.length = this.data.length;
        }
        return z.prototype.readByte = function() {
          return this.data[this.pos++];
        }, z.prototype.writeByte = function(k) {
          return this.data[this.pos++] = k;
        }, z.prototype.readUInt32 = function() {
          return 16777216 * this.readByte() + (this.readByte() << 16) + (this.readByte() << 8) + this.readByte();
        }, z.prototype.writeUInt32 = function(k) {
          return this.writeByte(k >>> 24 & 255), this.writeByte(k >> 16 & 255), this.writeByte(k >> 8 & 255), this.writeByte(255 & k);
        }, z.prototype.readInt32 = function() {
          var k;
          return 2147483648 <= (k = this.readUInt32()) ? k - 4294967296 : k;
        }, z.prototype.writeInt32 = function(k) {
          return k < 0 && (k += 4294967296), this.writeUInt32(k);
        }, z.prototype.readUInt16 = function() {
          return this.readByte() << 8 | this.readByte();
        }, z.prototype.writeUInt16 = function(k) {
          return this.writeByte(k >> 8 & 255), this.writeByte(255 & k);
        }, z.prototype.readInt16 = function() {
          var k;
          return 32768 <= (k = this.readUInt16()) ? k - 65536 : k;
        }, z.prototype.writeInt16 = function(k) {
          return k < 0 && (k += 65536), this.writeUInt16(k);
        }, z.prototype.readString = function(k) {
          var F, R, E;
          for (R = [], F = E = 0; 0 <= k ? E < k : k < E; F = 0 <= k ? ++E : --E)
            R[F] = String.fromCharCode(this.readByte());
          return R.join("");
        }, z.prototype.writeString = function(k) {
          var F, R, E, G;
          for (G = [], F = R = 0, E = k.length; 0 <= E ? R < E : E < R; F = 0 <= E ? ++R : --R)
            G.push(this.writeByte(k.charCodeAt(F)));
          return G;
        }, z.prototype.readShort = function() {
          return this.readInt16();
        }, z.prototype.writeShort = function(k) {
          return this.writeInt16(k);
        }, z.prototype.readLongLong = function() {
          var k, F, R, E, G, M, oA, X;
          return k = this.readByte(), F = this.readByte(), R = this.readByte(), E = this.readByte(), G = this.readByte(), M = this.readByte(), oA = this.readByte(), X = this.readByte(), 128 & k ? -1 * (72057594037927940 * (255 ^ k) + 281474976710656 * (255 ^ F) + 1099511627776 * (255 ^ R) + 4294967296 * (255 ^ E) + 16777216 * (255 ^ G) + 65536 * (255 ^ M) + 256 * (255 ^ oA) + (255 ^ X) + 1) : 72057594037927940 * k + 281474976710656 * F + 1099511627776 * R + 4294967296 * E + 16777216 * G + 65536 * M + 256 * oA + X;
        }, z.prototype.readInt = function() {
          return this.readInt32();
        }, z.prototype.writeInt = function(k) {
          return this.writeInt32(k);
        }, z.prototype.read = function(k) {
          var F, R;
          for (F = [], R = 0; 0 <= k ? R < k : k < R; 0 <= k ? ++R : --R)
            F.push(this.readByte());
          return F;
        }, z.prototype.write = function(k) {
          var F, R, E, G;
          for (G = [], R = 0, E = k.length; R < E; R++)
            F = k[R], G.push(this.writeByte(F));
          return G;
        }, z;
      }(), h = function() {
        var z;
        function k(F) {
          var R, E, G;
          for (this.scalarType = F.readInt(), this.tableCount = F.readShort(), this.searchRange = F.readShort(), this.entrySelector = F.readShort(), this.rangeShift = F.readShort(), this.tables = {}, E = 0, G = this.tableCount; 0 <= G ? E < G : G < E; 0 <= G ? ++E : --E)
            R = { tag: F.readString(4), checksum: F.readInt(), offset: F.readInt(), length: F.readInt() }, this.tables[R.tag] = R;
        }
        return k.prototype.encode = function(F) {
          var R, E, G, M, oA, X, fA, nA, b, D, u, Q, H;
          for (H in u = Object.keys(F).length, X = Math.log(2), b = 16 * Math.floor(Math.log(u) / X), M = Math.floor(b / X), nA = 16 * u - b, (E = new B()).writeInt(this.scalarType), E.writeShort(u), E.writeShort(b), E.writeShort(M), E.writeShort(nA), G = 16 * u, fA = E.pos + G, oA = null, Q = [], F)
            for (D = F[H], E.writeString(H), E.writeInt(z(D)), E.writeInt(fA), E.writeInt(D.length), Q = Q.concat(D), H === "head" && (oA = fA), fA += D.length; fA % 4; )
              Q.push(0), fA++;
          return E.write(Q), R = 2981146554 - z(E.data), E.pos = oA + 8, E.writeUInt32(R), E.data;
        }, z = function(F) {
          var R, E, G, M;
          for (F = y.call(F); F.length % 4; )
            F.push(0);
          for (E = new B(F), G = R = 0, M = F.length; G < M; G += 4)
            R += E.readUInt32();
          return 4294967295 & R;
        }, k;
      }(), f = {}.hasOwnProperty, m = function(z, k) {
        for (var F in k)
          f.call(k, F) && (z[F] = k[F]);
        function R() {
          this.constructor = z;
        }
        return R.prototype = k.prototype, z.prototype = new R(), z.__super__ = k.prototype, z;
      };
      d = function() {
        function z(k) {
          var F;
          this.file = k, F = this.file.directory.tables[this.tag], this.exists = !!F, F && (this.offset = F.offset, this.length = F.length, this.parse(this.file.contents));
        }
        return z.prototype.parse = function() {
        }, z.prototype.encode = function() {
        }, z.prototype.raw = function() {
          return this.exists ? (this.file.contents.pos = this.offset, this.file.contents.read(this.length)) : null;
        }, z;
      }();
      var w = function(z) {
        function k() {
          return k.__super__.constructor.apply(this, arguments);
        }
        return m(k, d), k.prototype.tag = "head", k.prototype.parse = function(F) {
          return F.pos = this.offset, this.version = F.readInt(), this.revision = F.readInt(), this.checkSumAdjustment = F.readInt(), this.magicNumber = F.readInt(), this.flags = F.readShort(), this.unitsPerEm = F.readShort(), this.created = F.readLongLong(), this.modified = F.readLongLong(), this.xMin = F.readShort(), this.yMin = F.readShort(), this.xMax = F.readShort(), this.yMax = F.readShort(), this.macStyle = F.readShort(), this.lowestRecPPEM = F.readShort(), this.fontDirectionHint = F.readShort(), this.indexToLocFormat = F.readShort(), this.glyphDataFormat = F.readShort();
        }, k;
      }(), U = function() {
        function z(k, F) {
          var R, E, G, M, oA, X, fA, nA, b, D, u, Q, H, O, eA, sA, pA, yA;
          switch (this.platformID = k.readUInt16(), this.encodingID = k.readShort(), this.offset = F + k.readInt(), b = k.pos, k.pos = this.offset, this.format = k.readUInt16(), this.length = k.readUInt16(), this.language = k.readUInt16(), this.isUnicode = this.platformID === 3 && this.encodingID === 1 && this.format === 4 || this.platformID === 0 && this.format === 4, this.codeMap = {}, this.format) {
            case 0:
              for (X = eA = 0; eA < 256; X = ++eA)
                this.codeMap[X] = k.readByte();
              break;
            case 4:
              for (u = k.readUInt16(), D = u / 2, k.pos += 6, G = function() {
                var wA, SA;
                for (SA = [], X = wA = 0; 0 <= D ? wA < D : D < wA; X = 0 <= D ? ++wA : --wA)
                  SA.push(k.readUInt16());
                return SA;
              }(), k.pos += 2, H = function() {
                var wA, SA;
                for (SA = [], X = wA = 0; 0 <= D ? wA < D : D < wA; X = 0 <= D ? ++wA : --wA)
                  SA.push(k.readUInt16());
                return SA;
              }(), fA = function() {
                var wA, SA;
                for (SA = [], X = wA = 0; 0 <= D ? wA < D : D < wA; X = 0 <= D ? ++wA : --wA)
                  SA.push(k.readUInt16());
                return SA;
              }(), nA = function() {
                var wA, SA;
                for (SA = [], X = wA = 0; 0 <= D ? wA < D : D < wA; X = 0 <= D ? ++wA : --wA)
                  SA.push(k.readUInt16());
                return SA;
              }(), E = (this.length - k.pos + this.offset) / 2, oA = function() {
                var wA, SA;
                for (SA = [], X = wA = 0; 0 <= E ? wA < E : E < wA; X = 0 <= E ? ++wA : --wA)
                  SA.push(k.readUInt16());
                return SA;
              }(), X = sA = 0, yA = G.length; sA < yA; X = ++sA)
                for (O = G[X], R = pA = Q = H[X]; Q <= O ? pA <= O : O <= pA; R = Q <= O ? ++pA : --pA)
                  nA[X] === 0 ? M = R + fA[X] : (M = oA[nA[X] / 2 + (R - Q) - (D - X)] || 0) !== 0 && (M += fA[X]), this.codeMap[R] = 65535 & M;
          }
          k.pos = b;
        }
        return z.encode = function(k, F) {
          var R, E, G, M, oA, X, fA, nA, b, D, u, Q, H, O, eA, sA, pA, yA, wA, SA, xA, KA, iA, yt, $A, st, kt, jA, gt, bt, ht, ct, xt, Pt, JA, ee, oe, be, Ke, Yt, K, aA, gA, tA, AA, dA;
          switch (jA = new B(), M = Object.keys(k).sort(function(QA, bA) {
            return QA - bA;
          }), F) {
            case "macroman":
              for (H = 0, O = function() {
                var QA, bA;
                for (bA = [], Q = QA = 0; QA < 256; Q = ++QA)
                  bA.push(0);
                return bA;
              }(), sA = { 0: 0 }, G = {}, gt = 0, xt = M.length; gt < xt; gt++)
                sA[gA = k[E = M[gt]]] == null && (sA[gA] = ++H), G[E] = { old: k[E], new: sA[k[E]] }, O[E] = sA[k[E]];
              return jA.writeUInt16(1), jA.writeUInt16(0), jA.writeUInt32(12), jA.writeUInt16(0), jA.writeUInt16(262), jA.writeUInt16(0), jA.write(O), { charMap: G, subtable: jA.data, maxGlyphID: H + 1 };
            case "unicode":
              for (st = [], b = [], sA = {}, R = {}, eA = fA = null, bt = pA = 0, Pt = M.length; bt < Pt; bt++)
                sA[wA = k[E = M[bt]]] == null && (sA[wA] = ++pA), R[E] = { old: wA, new: sA[wA] }, oA = sA[wA] - E, eA != null && oA === fA || (eA && b.push(eA), st.push(E), fA = oA), eA = E;
              for (eA && b.push(eA), b.push(65535), st.push(65535), yt = 2 * (iA = st.length), KA = 2 * Math.pow(Math.log(iA) / Math.LN2, 2), D = Math.log(KA / 2) / Math.LN2, xA = 2 * iA - KA, X = [], SA = [], u = [], Q = ht = 0, JA = st.length; ht < JA; Q = ++ht) {
                if ($A = st[Q], nA = b[Q], $A === 65535) {
                  X.push(0), SA.push(0);
                  break;
                }
                if (32768 <= $A - (kt = R[$A].new))
                  for (X.push(0), SA.push(2 * (u.length + iA - Q)), E = ct = $A; $A <= nA ? ct <= nA : nA <= ct; E = $A <= nA ? ++ct : --ct)
                    u.push(R[E].new);
                else
                  X.push(kt - $A), SA.push(0);
              }
              for (jA.writeUInt16(3), jA.writeUInt16(1), jA.writeUInt32(12), jA.writeUInt16(4), jA.writeUInt16(16 + 8 * iA + 2 * u.length), jA.writeUInt16(0), jA.writeUInt16(yt), jA.writeUInt16(KA), jA.writeUInt16(D), jA.writeUInt16(xA), K = 0, ee = b.length; K < ee; K++)
                E = b[K], jA.writeUInt16(E);
              for (jA.writeUInt16(0), aA = 0, oe = st.length; aA < oe; aA++)
                E = st[aA], jA.writeUInt16(E);
              for (tA = 0, be = X.length; tA < be; tA++)
                oA = X[tA], jA.writeUInt16(oA);
              for (AA = 0, Ke = SA.length; AA < Ke; AA++)
                yA = SA[AA], jA.writeUInt16(yA);
              for (dA = 0, Yt = u.length; dA < Yt; dA++)
                H = u[dA], jA.writeUInt16(H);
              return { charMap: R, subtable: jA.data, maxGlyphID: pA + 1 };
          }
        }, z;
      }(), I = function(z) {
        function k() {
          return k.__super__.constructor.apply(this, arguments);
        }
        return m(k, d), k.prototype.tag = "cmap", k.prototype.parse = function(F) {
          var R, E, G;
          for (F.pos = this.offset, this.version = F.readUInt16(), E = F.readUInt16(), this.tables = [], this.unicode = null, G = 0; 0 <= E ? G < E : E < G; 0 <= E ? ++G : --G)
            R = new U(F, this.offset), this.tables.push(R), R.isUnicode && this.unicode == null && (this.unicode = R);
          return !0;
        }, k.encode = function(F, R) {
          var E, G;
          return R == null && (R = "macroman"), E = U.encode(F, R), (G = new B()).writeUInt16(0), G.writeUInt16(1), E.table = G.data.concat(E.subtable), E;
        }, k;
      }(), S = function(z) {
        function k() {
          return k.__super__.constructor.apply(this, arguments);
        }
        return m(k, d), k.prototype.tag = "hhea", k.prototype.parse = function(F) {
          return F.pos = this.offset, this.version = F.readInt(), this.ascender = F.readShort(), this.decender = F.readShort(), this.lineGap = F.readShort(), this.advanceWidthMax = F.readShort(), this.minLeftSideBearing = F.readShort(), this.minRightSideBearing = F.readShort(), this.xMaxExtent = F.readShort(), this.caretSlopeRise = F.readShort(), this.caretSlopeRun = F.readShort(), this.caretOffset = F.readShort(), F.pos += 8, this.metricDataFormat = F.readShort(), this.numberOfMetrics = F.readUInt16();
        }, k;
      }(), L = function(z) {
        function k() {
          return k.__super__.constructor.apply(this, arguments);
        }
        return m(k, d), k.prototype.tag = "OS/2", k.prototype.parse = function(F) {
          if (F.pos = this.offset, this.version = F.readUInt16(), this.averageCharWidth = F.readShort(), this.weightClass = F.readUInt16(), this.widthClass = F.readUInt16(), this.type = F.readShort(), this.ySubscriptXSize = F.readShort(), this.ySubscriptYSize = F.readShort(), this.ySubscriptXOffset = F.readShort(), this.ySubscriptYOffset = F.readShort(), this.ySuperscriptXSize = F.readShort(), this.ySuperscriptYSize = F.readShort(), this.ySuperscriptXOffset = F.readShort(), this.ySuperscriptYOffset = F.readShort(), this.yStrikeoutSize = F.readShort(), this.yStrikeoutPosition = F.readShort(), this.familyClass = F.readShort(), this.panose = function() {
            var R, E;
            for (E = [], R = 0; R < 10; ++R)
              E.push(F.readByte());
            return E;
          }(), this.charRange = function() {
            var R, E;
            for (E = [], R = 0; R < 4; ++R)
              E.push(F.readInt());
            return E;
          }(), this.vendorID = F.readString(4), this.selection = F.readShort(), this.firstCharIndex = F.readShort(), this.lastCharIndex = F.readShort(), 0 < this.version && (this.ascent = F.readShort(), this.descent = F.readShort(), this.lineGap = F.readShort(), this.winAscent = F.readShort(), this.winDescent = F.readShort(), this.codePageRange = function() {
            var R, E;
            for (E = [], R = 0; R < 2; ++R)
              E.push(F.readInt());
            return E;
          }(), 1 < this.version))
            return this.xHeight = F.readShort(), this.capHeight = F.readShort(), this.defaultChar = F.readShort(), this.breakChar = F.readShort(), this.maxContext = F.readShort();
        }, k;
      }(), N = function(z) {
        function k() {
          return k.__super__.constructor.apply(this, arguments);
        }
        return m(k, d), k.prototype.tag = "post", k.prototype.parse = function(F) {
          var R, E, G, M;
          switch (F.pos = this.offset, this.format = F.readInt(), this.italicAngle = F.readInt(), this.underlinePosition = F.readShort(), this.underlineThickness = F.readShort(), this.isFixedPitch = F.readInt(), this.minMemType42 = F.readInt(), this.maxMemType42 = F.readInt(), this.minMemType1 = F.readInt(), this.maxMemType1 = F.readInt(), this.format) {
            case 65536:
              break;
            case 131072:
              for (E = F.readUInt16(), this.glyphNameIndex = [], G = 0; 0 <= E ? G < E : E < G; 0 <= E ? ++G : --G)
                this.glyphNameIndex.push(F.readUInt16());
              for (this.names = [], M = []; F.pos < this.offset + this.length; )
                R = F.readByte(), M.push(this.names.push(F.readString(R)));
              return M;
            case 151552:
              return E = F.readUInt16(), this.offsets = F.read(E);
            case 196608:
              break;
            case 262144:
              return this.map = (function() {
                var oA, X, fA;
                for (fA = [], oA = 0, X = this.file.maxp.numGlyphs; 0 <= X ? oA < X : X < oA; 0 <= X ? ++oA : --oA)
                  fA.push(F.readUInt32());
                return fA;
              }).call(this);
          }
        }, k;
      }(), j = function(z, k) {
        this.raw = z, this.length = z.length, this.platformID = k.platformID, this.encodingID = k.encodingID, this.languageID = k.languageID;
      }, Z = function(z) {
        function k() {
          return k.__super__.constructor.apply(this, arguments);
        }
        return m(k, d), k.prototype.tag = "name", k.prototype.parse = function(F) {
          var R, E, G, M, oA, X, fA, nA, b, D, u, Q;
          for (F.pos = this.offset, F.readShort(), R = F.readShort(), X = F.readShort(), E = [], M = b = 0; 0 <= R ? b < R : R < b; M = 0 <= R ? ++b : --b)
            E.push({ platformID: F.readShort(), encodingID: F.readShort(), languageID: F.readShort(), nameID: F.readShort(), length: F.readShort(), offset: this.offset + X + F.readShort() });
          for (fA = {}, M = D = 0, u = E.length; D < u; M = ++D)
            G = E[M], F.pos = G.offset, nA = F.readString(G.length), oA = new j(nA, G), fA[Q = G.nameID] == null && (fA[Q] = []), fA[G.nameID].push(oA);
          return this.strings = fA, this.copyright = fA[0], this.fontFamily = fA[1], this.fontSubfamily = fA[2], this.uniqueSubfamily = fA[3], this.fontName = fA[4], this.version = fA[5], this.postscriptName = fA[6][0].raw.replace(/[\x00-\x19\x80-\xff]/g, ""), this.trademark = fA[7], this.manufacturer = fA[8], this.designer = fA[9], this.description = fA[10], this.vendorUrl = fA[11], this.designerUrl = fA[12], this.license = fA[13], this.licenseUrl = fA[14], this.preferredFamily = fA[15], this.preferredSubfamily = fA[17], this.compatibleFull = fA[18], this.sampleText = fA[19];
        }, k;
      }(), W = function(z) {
        function k() {
          return k.__super__.constructor.apply(this, arguments);
        }
        return m(k, d), k.prototype.tag = "maxp", k.prototype.parse = function(F) {
          return F.pos = this.offset, this.version = F.readInt(), this.numGlyphs = F.readUInt16(), this.maxPoints = F.readUInt16(), this.maxContours = F.readUInt16(), this.maxCompositePoints = F.readUInt16(), this.maxComponentContours = F.readUInt16(), this.maxZones = F.readUInt16(), this.maxTwilightPoints = F.readUInt16(), this.maxStorage = F.readUInt16(), this.maxFunctionDefs = F.readUInt16(), this.maxInstructionDefs = F.readUInt16(), this.maxStackElements = F.readUInt16(), this.maxSizeOfInstructions = F.readUInt16(), this.maxComponentElements = F.readUInt16(), this.maxComponentDepth = F.readUInt16();
        }, k;
      }(), V = function(z) {
        function k() {
          return k.__super__.constructor.apply(this, arguments);
        }
        return m(k, d), k.prototype.tag = "hmtx", k.prototype.parse = function(F) {
          var R, E, G, M, oA, X, fA;
          for (F.pos = this.offset, this.metrics = [], M = 0, X = this.file.hhea.numberOfMetrics; 0 <= X ? M < X : X < M; 0 <= X ? ++M : --M)
            this.metrics.push({ advance: F.readUInt16(), lsb: F.readInt16() });
          for (E = this.file.maxp.numGlyphs - this.file.hhea.numberOfMetrics, this.leftSideBearings = function() {
            var nA, b;
            for (b = [], nA = 0; 0 <= E ? nA < E : E < nA; 0 <= E ? ++nA : --nA)
              b.push(F.readInt16());
            return b;
          }(), this.widths = (function() {
            var nA, b, D, u;
            for (u = [], nA = 0, b = (D = this.metrics).length; nA < b; nA++)
              G = D[nA], u.push(G.advance);
            return u;
          }).call(this), R = this.widths[this.widths.length - 1], fA = [], oA = 0; 0 <= E ? oA < E : E < oA; 0 <= E ? ++oA : --oA)
            fA.push(this.widths.push(R));
          return fA;
        }, k.prototype.forGlyph = function(F) {
          return F in this.metrics ? this.metrics[F] : { advance: this.metrics[this.metrics.length - 1].advance, lsb: this.leftSideBearings[F - this.metrics.length] };
        }, k;
      }(), y = [].slice, P = function(z) {
        function k() {
          return k.__super__.constructor.apply(this, arguments);
        }
        return m(k, d), k.prototype.tag = "glyf", k.prototype.parse = function(F) {
          return this.cache = {};
        }, k.prototype.glyphFor = function(F) {
          var R, E, G, M, oA, X, fA, nA, b, D;
          return (F = F) in this.cache ? this.cache[F] : (M = this.file.loca, R = this.file.contents, E = M.indexOf(F), (G = M.lengthOf(F)) === 0 ? this.cache[F] = null : (R.pos = this.offset + E, oA = (X = new B(R.read(G))).readShort(), nA = X.readShort(), D = X.readShort(), fA = X.readShort(), b = X.readShort(), this.cache[F] = oA === -1 ? new Y(X, nA, D, fA, b) : new _(X, oA, nA, D, fA, b), this.cache[F]));
        }, k.prototype.encode = function(F, R, E) {
          var G, M, oA, X, fA;
          for (oA = [], M = [], X = 0, fA = R.length; X < fA; X++)
            G = F[R[X]], M.push(oA.length), G && (oA = oA.concat(G.encode(E)));
          return M.push(oA.length), { table: oA, offsets: M };
        }, k;
      }(), _ = function() {
        function z(k, F, R, E, G, M) {
          this.raw = k, this.numberOfContours = F, this.xMin = R, this.yMin = E, this.xMax = G, this.yMax = M, this.compound = !1;
        }
        return z.prototype.encode = function() {
          return this.raw.data;
        }, z;
      }(), Y = function() {
        function z(k, F, R, E, G) {
          var M, oA;
          for (this.raw = k, this.xMin = F, this.yMin = R, this.xMax = E, this.yMax = G, this.compound = !0, this.glyphIDs = [], this.glyphOffsets = [], M = this.raw; oA = M.readShort(), this.glyphOffsets.push(M.pos), this.glyphIDs.push(M.readShort()), 32 & oA; )
            M.pos += 1 & oA ? 4 : 2, 128 & oA ? M.pos += 8 : 64 & oA ? M.pos += 4 : 8 & oA && (M.pos += 2);
        }
        return z.prototype.encode = function(k) {
          var F, R, E, G, M;
          for (R = new B(y.call(this.raw.data)), F = E = 0, G = (M = this.glyphIDs).length; E < G; F = ++E)
            M[F], R.pos = this.glyphOffsets[F];
          return R.data;
        }, z;
      }(), $ = function(z) {
        function k() {
          return k.__super__.constructor.apply(this, arguments);
        }
        return m(k, d), k.prototype.tag = "loca", k.prototype.parse = function(F) {
          var R;
          return F.pos = this.offset, R = this.file.head.indexToLocFormat, this.offsets = R === 0 ? (function() {
            var E, G, M;
            for (M = [], E = 0, G = this.length; E < G; E += 2)
              M.push(2 * F.readUInt16());
            return M;
          }).call(this) : (function() {
            var E, G, M;
            for (M = [], E = 0, G = this.length; E < G; E += 4)
              M.push(F.readUInt32());
            return M;
          }).call(this);
        }, k.prototype.indexOf = function(F) {
          return this.offsets[F];
        }, k.prototype.lengthOf = function(F) {
          return this.offsets[F + 1] - this.offsets[F];
        }, k.prototype.encode = function(F, R) {
          for (var E = new Uint32Array(this.offsets.length), G = 0, M = 0, oA = 0; oA < E.length; ++oA)
            if (E[oA] = G, M < R.length && R[M] == oA) {
              ++M, E[oA] = G;
              var X = this.offsets[oA], fA = this.offsets[oA + 1] - X;
              0 < fA && (G += fA);
            }
          for (var nA = new Array(4 * E.length), b = 0; b < E.length; ++b)
            nA[4 * b + 3] = 255 & E[b], nA[4 * b + 2] = (65280 & E[b]) >> 8, nA[4 * b + 1] = (16711680 & E[b]) >> 16, nA[4 * b] = (4278190080 & E[b]) >> 24;
          return nA;
        }, k;
      }(), hA = function() {
        function z(k) {
          this.font = k, this.subset = {}, this.unicodes = {}, this.next = 33;
        }
        return z.prototype.generateCmap = function() {
          var k, F, R, E, G;
          for (F in E = this.font.cmap.tables[0].codeMap, k = {}, G = this.subset)
            R = G[F], k[F] = E[R];
          return k;
        }, z.prototype.glyphsFor = function(k) {
          var F, R, E, G, M, oA, X;
          for (E = {}, M = 0, oA = k.length; M < oA; M++)
            E[G = k[M]] = this.font.glyf.glyphFor(G);
          for (G in F = [], E)
            (R = E[G]) != null && R.compound && F.push.apply(F, R.glyphIDs);
          if (0 < F.length)
            for (G in X = this.glyphsFor(F))
              R = X[G], E[G] = R;
          return E;
        }, z.prototype.encode = function(k) {
          var F, R, E, G, M, oA, X, fA, nA, b, D, u, Q, H, O;
          for (R in F = I.encode(this.generateCmap(), "unicode"), G = this.glyphsFor(k), D = { 0: 0 }, O = F.charMap)
            D[(oA = O[R]).old] = oA.new;
          for (u in b = F.maxGlyphID, G)
            u in D || (D[u] = b++);
          return fA = function(eA) {
            var sA, pA;
            for (sA in pA = {}, eA)
              pA[eA[sA]] = sA;
            return pA;
          }(D), nA = Object.keys(fA).sort(function(eA, sA) {
            return eA - sA;
          }), Q = function() {
            var eA, sA, pA;
            for (pA = [], eA = 0, sA = nA.length; eA < sA; eA++)
              M = nA[eA], pA.push(fA[M]);
            return pA;
          }(), E = this.font.glyf.encode(G, Q, D), X = this.font.loca.encode(E.offsets, Q), H = { cmap: this.font.cmap.raw(), glyf: E.table, loca: X, hmtx: this.font.hmtx.raw(), hhea: this.font.hhea.raw(), maxp: this.font.maxp.raw(), post: this.font.post.raw(), name: this.font.name.raw(), head: this.font.head.raw() }, this.font.os2.exists && (H["OS/2"] = this.font.os2.raw()), this.font.directory.encode(H);
        }, z;
      }();
      o.API.PDFObject = function() {
        var z;
        function k() {
        }
        return z = function(F, R) {
          return (Array(R + 1).join("0") + F).slice(-R);
        }, k.convert = function(F) {
          var R, E, G, M;
          if (Array.isArray(F))
            return "[" + function() {
              var oA, X, fA;
              for (fA = [], oA = 0, X = F.length; oA < X; oA++)
                R = F[oA], fA.push(k.convert(R));
              return fA;
            }().join(" ") + "]";
          if (typeof F == "string")
            return "/" + F;
          if (F != null && F.isString)
            return "(" + F + ")";
          if (F instanceof Date)
            return "(D:" + z(F.getUTCFullYear(), 4) + z(F.getUTCMonth(), 2) + z(F.getUTCDate(), 2) + z(F.getUTCHours(), 2) + z(F.getUTCMinutes(), 2) + z(F.getUTCSeconds(), 2) + "Z)";
          if ({}.toString.call(F) === "[object Object]") {
            for (E in G = ["<<"], F)
              M = F[E], G.push("/" + E + " " + k.convert(M));
            return G.push(">>"), G.join(`
`);
          }
          return "" + F;
        }, k;
      }();
    }(Ct), /*
      # PNG.js
      # Copyright (c) 2011 Devon Govett
      # MIT LICENSE
      # 
      # 
      */
    tr = typeof self < "u" && self || typeof window < "u" && window || typeof Jt < "u" && Jt || Function('return typeof this === "object" && this.content')() || Function("return this")(), br = function() {
      var o, p, C;
      function i(r) {
        var n, s, c, l, d, B, h, f, m, w, U, I, S, L;
        for (this.data = r, this.pos = 8, this.palette = [], this.imgData = [], this.transparency = {}, this.animation = null, this.text = {}, B = null; ; ) {
          switch (n = this.readUInt32(), m = (function() {
            var N, j;
            for (j = [], N = 0; N < 4; ++N)
              j.push(String.fromCharCode(this.data[this.pos++]));
            return j;
          }).call(this).join("")) {
            case "IHDR":
              this.width = this.readUInt32(), this.height = this.readUInt32(), this.bits = this.data[this.pos++], this.colorType = this.data[this.pos++], this.compressionMethod = this.data[this.pos++], this.filterMethod = this.data[this.pos++], this.interlaceMethod = this.data[this.pos++];
              break;
            case "acTL":
              this.animation = { numFrames: this.readUInt32(), numPlays: this.readUInt32() || 1 / 0, frames: [] };
              break;
            case "PLTE":
              this.palette = this.read(n);
              break;
            case "fcTL":
              B && this.animation.frames.push(B), this.pos += 4, B = { width: this.readUInt32(), height: this.readUInt32(), xOffset: this.readUInt32(), yOffset: this.readUInt32() }, d = this.readUInt16(), l = this.readUInt16() || 100, B.delay = 1e3 * d / l, B.disposeOp = this.data[this.pos++], B.blendOp = this.data[this.pos++], B.data = [];
              break;
            case "IDAT":
            case "fdAT":
              for (m === "fdAT" && (this.pos += 4, n -= 4), r = (B != null ? B.data : void 0) || this.imgData, I = 0; 0 <= n ? I < n : n < I; 0 <= n ? ++I : --I)
                r.push(this.data[this.pos++]);
              break;
            case "tRNS":
              switch (this.transparency = {}, this.colorType) {
                case 3:
                  if (c = this.palette.length / 3, this.transparency.indexed = this.read(n), this.transparency.indexed.length > c)
                    throw new Error("More transparent colors than palette size");
                  if (0 < (w = c - this.transparency.indexed.length))
                    for (S = 0; 0 <= w ? S < w : w < S; 0 <= w ? ++S : --S)
                      this.transparency.indexed.push(255);
                  break;
                case 0:
                  this.transparency.grayscale = this.read(n)[0];
                  break;
                case 2:
                  this.transparency.rgb = this.read(n);
              }
              break;
            case "tEXt":
              h = (U = this.read(n)).indexOf(0), f = String.fromCharCode.apply(String, U.slice(0, h)), this.text[f] = String.fromCharCode.apply(String, U.slice(h + 1));
              break;
            case "IEND":
              return B && this.animation.frames.push(B), this.colors = (function() {
                switch (this.colorType) {
                  case 0:
                  case 3:
                  case 4:
                    return 1;
                  case 2:
                  case 6:
                    return 3;
                }
              }).call(this), this.hasAlphaChannel = (L = this.colorType) === 4 || L === 6, s = this.colors + (this.hasAlphaChannel ? 1 : 0), this.pixelBitlength = this.bits * s, this.colorSpace = (function() {
                switch (this.colors) {
                  case 1:
                    return "DeviceGray";
                  case 3:
                    return "DeviceRGB";
                }
              }).call(this), void (this.imgData = new Uint8Array(this.imgData));
            default:
              this.pos += n;
          }
          if (this.pos += 4, this.pos > this.data.length)
            throw new Error("Incomplete or corrupt PNG file");
        }
      }
      i.load = function(r, n, s) {
        var c;
        return typeof n == "function" && (s = n), (c = new XMLHttpRequest()).open("GET", r, !0), c.responseType = "arraybuffer", c.onload = function() {
          var l;
          return l = new i(new Uint8Array(c.response || c.mozResponseArrayBuffer)), typeof (n != null ? n.getContext : void 0) == "function" && l.render(n), typeof s == "function" ? s(l) : void 0;
        }, c.send(null);
      }, i.prototype.read = function(r) {
        var n, s;
        for (s = [], n = 0; 0 <= r ? n < r : r < n; 0 <= r ? ++n : --n)
          s.push(this.data[this.pos++]);
        return s;
      }, i.prototype.readUInt32 = function() {
        return this.data[this.pos++] << 24 | this.data[this.pos++] << 16 | this.data[this.pos++] << 8 | this.data[this.pos++];
      }, i.prototype.readUInt16 = function() {
        return this.data[this.pos++] << 8 | this.data[this.pos++];
      }, i.prototype.decodePixels = function(r) {
        var n = this.pixelBitlength / 8, s = new Uint8Array(this.width * this.height * n), c = 0, l = this;
        if (r == null && (r = this.imgData), r.length === 0)
          return new Uint8Array(0);
        function d(B, h, f, m) {
          var w, U, I, S, L, N, j, Z, W, V, y, P, _, Y, $, hA, z, k, F, R, E, G = Math.ceil((l.width - B) / f), M = Math.ceil((l.height - h) / m), oA = l.width == G && l.height == M;
          for (Y = n * G, P = oA ? s : new Uint8Array(Y * M), N = r.length, U = _ = 0; _ < M && c < N; ) {
            switch (r[c++]) {
              case 0:
                for (S = z = 0; z < Y; S = z += 1)
                  P[U++] = r[c++];
                break;
              case 1:
                for (S = k = 0; k < Y; S = k += 1)
                  w = r[c++], L = S < n ? 0 : P[U - n], P[U++] = (w + L) % 256;
                break;
              case 2:
                for (S = F = 0; F < Y; S = F += 1)
                  w = r[c++], I = (S - S % n) / n, $ = _ && P[(_ - 1) * Y + I * n + S % n], P[U++] = ($ + w) % 256;
                break;
              case 3:
                for (S = R = 0; R < Y; S = R += 1)
                  w = r[c++], I = (S - S % n) / n, L = S < n ? 0 : P[U - n], $ = _ && P[(_ - 1) * Y + I * n + S % n], P[U++] = (w + Math.floor((L + $) / 2)) % 256;
                break;
              case 4:
                for (S = E = 0; E < Y; S = E += 1)
                  w = r[c++], I = (S - S % n) / n, L = S < n ? 0 : P[U - n], _ === 0 ? $ = hA = 0 : ($ = P[(_ - 1) * Y + I * n + S % n], hA = I && P[(_ - 1) * Y + (I - 1) * n + S % n]), j = L + $ - hA, Z = Math.abs(j - L), V = Math.abs(j - $), y = Math.abs(j - hA), W = Z <= V && Z <= y ? L : V <= y ? $ : hA, P[U++] = (w + W) % 256;
                break;
              default:
                throw new Error("Invalid filter algorithm: " + r[c - 1]);
            }
            if (!oA) {
              var X = ((h + _ * m) * l.width + B) * n, fA = _ * Y;
              for (S = 0; S < G; S += 1) {
                for (var nA = 0; nA < n; nA += 1)
                  s[X++] = P[fA++];
                X += (f - 1) * n;
              }
            }
            _++;
          }
        }
        return r = (r = new mn(r)).getBytes(), l.interlaceMethod == 1 ? (d(0, 0, 8, 8), d(4, 0, 8, 8), d(0, 4, 4, 8), d(2, 0, 4, 4), d(0, 2, 2, 4), d(1, 0, 2, 2), d(0, 1, 1, 2)) : d(0, 0, 1, 1), s;
      }, i.prototype.decodePalette = function() {
        var r, n, s, c, l, d, B, h, f;
        for (s = this.palette, d = this.transparency.indexed || [], l = new Uint8Array((d.length || 0) + s.length), c = 0, s.length, n = B = r = 0, h = s.length; B < h; n = B += 3)
          l[c++] = s[n], l[c++] = s[n + 1], l[c++] = s[n + 2], l[c++] = (f = d[r++]) != null ? f : 255;
        return l;
      }, i.prototype.copyToImageData = function(r, n) {
        var s, c, l, d, B, h, f, m, w, U, I;
        if (c = this.colors, w = null, s = this.hasAlphaChannel, this.palette.length && (w = (I = this._decodedPalette) != null ? I : this._decodedPalette = this.decodePalette(), c = 4, s = !0), m = (l = r.data || r).length, B = w || n, d = h = 0, c === 1)
          for (; d < m; )
            f = w ? 4 * n[d / 4] : h, U = B[f++], l[d++] = U, l[d++] = U, l[d++] = U, l[d++] = s ? B[f++] : 255, h = f;
        else
          for (; d < m; )
            f = w ? 4 * n[d / 4] : h, l[d++] = B[f++], l[d++] = B[f++], l[d++] = B[f++], l[d++] = s ? B[f++] : 255, h = f;
      }, i.prototype.decode = function() {
        var r;
        return r = new Uint8Array(this.width * this.height * 4), this.copyToImageData(r, this.decodePixels()), r;
      };
      try {
        p = tr.document.createElement("canvas"), C = p.getContext("2d");
      } catch {
        return -1;
      }
      return o = function(r) {
        var n;
        return C.width = r.width, C.height = r.height, C.clearRect(0, 0, r.width, r.height), C.putImageData(r, 0, 0), (n = new Image()).src = p.toDataURL(), n;
      }, i.prototype.decodeFrames = function(r) {
        var n, s, c, l, d, B, h, f;
        if (this.animation) {
          for (f = [], s = d = 0, B = (h = this.animation.frames).length; d < B; s = ++d)
            n = h[s], c = r.createImageData(n.width, n.height), l = this.decodePixels(new Uint8Array(n.data)), this.copyToImageData(c, l), n.imageData = c, f.push(n.image = o(c));
          return f;
        }
      }, i.prototype.renderFrame = function(r, n) {
        var s, c, l;
        return s = (c = this.animation.frames)[n], l = c[n - 1], n === 0 && r.clearRect(0, 0, this.width, this.height), (l != null ? l.disposeOp : void 0) === 1 ? r.clearRect(l.xOffset, l.yOffset, l.width, l.height) : (l != null ? l.disposeOp : void 0) === 2 && r.putImageData(l.imageData, l.xOffset, l.yOffset), s.blendOp === 0 && r.clearRect(s.xOffset, s.yOffset, s.width, s.height), r.drawImage(s.image, s.xOffset, s.yOffset);
      }, i.prototype.animate = function(r) {
        var n, s, c, l, d, B, h = this;
        return s = 0, B = this.animation, l = B.numFrames, c = B.frames, d = B.numPlays, (n = function() {
          var f, m;
          if (f = s++ % l, m = c[f], h.renderFrame(r, f), 1 < l && s / l < d)
            return h.animation._timeout = setTimeout(n, m.delay);
        })();
      }, i.prototype.stopAnimation = function() {
        var r;
        return clearTimeout((r = this.animation) != null ? r._timeout : void 0);
      }, i.prototype.render = function(r) {
        var n, s;
        return r._png && r._png.stopAnimation(), r._png = this, r.width = this.width, r.height = this.height, n = r.getContext("2d"), this.animation ? (this.decodeFrames(n), this.animate(n)) : (s = n.createImageData(this.width, this.height), this.copyToImageData(s, this.decodePixels()), n.putImageData(s, 0, 0));
      }, i;
    }(), tr.PNG = br;
    var wn = function() {
      function o() {
        this.pos = 0, this.bufferLength = 0, this.eof = !1, this.buffer = null;
      }
      return o.prototype = { ensureBuffer: function(p) {
        var C = this.buffer, i = C ? C.byteLength : 0;
        if (p < i)
          return C;
        for (var r = 512; r < p; )
          r <<= 1;
        for (var n = new Uint8Array(r), s = 0; s < i; ++s)
          n[s] = C[s];
        return this.buffer = n;
      }, getByte: function() {
        for (var p = this.pos; this.bufferLength <= p; ) {
          if (this.eof)
            return null;
          this.readBlock();
        }
        return this.buffer[this.pos++];
      }, getBytes: function(p) {
        var C = this.pos;
        if (p) {
          this.ensureBuffer(C + p);
          for (var i = C + p; !this.eof && this.bufferLength < i; )
            this.readBlock();
          var r = this.bufferLength;
          r < i && (i = r);
        } else {
          for (; !this.eof; )
            this.readBlock();
          i = this.bufferLength;
        }
        return this.pos = i, this.buffer.subarray(C, i);
      }, lookChar: function() {
        for (var p = this.pos; this.bufferLength <= p; ) {
          if (this.eof)
            return null;
          this.readBlock();
        }
        return String.fromCharCode(this.buffer[this.pos]);
      }, getChar: function() {
        for (var p = this.pos; this.bufferLength <= p; ) {
          if (this.eof)
            return null;
          this.readBlock();
        }
        return String.fromCharCode(this.buffer[this.pos++]);
      }, makeSubStream: function(p, C, i) {
        for (var r = p + C; this.bufferLength <= r && !this.eof; )
          this.readBlock();
        return new Stream(this.buffer, p, C, i);
      }, skip: function(p) {
        p || (p = 1), this.pos += p;
      }, reset: function() {
        this.pos = 0;
      } }, o;
    }(), mn = function() {
      if (typeof Uint32Array < "u") {
        var o = new Uint32Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), p = new Uint32Array([3, 4, 5, 6, 7, 8, 9, 10, 65547, 65549, 65551, 65553, 131091, 131095, 131099, 131103, 196643, 196651, 196659, 196667, 262211, 262227, 262243, 262259, 327811, 327843, 327875, 327907, 258, 258, 258]), C = new Uint32Array([1, 2, 3, 4, 65541, 65543, 131081, 131085, 196625, 196633, 262177, 262193, 327745, 327777, 393345, 393409, 459009, 459137, 524801, 525057, 590849, 591361, 657409, 658433, 724993, 727041, 794625, 798721, 868353, 876545]), i = [new Uint32Array([459008, 524368, 524304, 524568, 459024, 524400, 524336, 590016, 459016, 524384, 524320, 589984, 524288, 524416, 524352, 590048, 459012, 524376, 524312, 589968, 459028, 524408, 524344, 590032, 459020, 524392, 524328, 59e4, 524296, 524424, 524360, 590064, 459010, 524372, 524308, 524572, 459026, 524404, 524340, 590024, 459018, 524388, 524324, 589992, 524292, 524420, 524356, 590056, 459014, 524380, 524316, 589976, 459030, 524412, 524348, 590040, 459022, 524396, 524332, 590008, 524300, 524428, 524364, 590072, 459009, 524370, 524306, 524570, 459025, 524402, 524338, 590020, 459017, 524386, 524322, 589988, 524290, 524418, 524354, 590052, 459013, 524378, 524314, 589972, 459029, 524410, 524346, 590036, 459021, 524394, 524330, 590004, 524298, 524426, 524362, 590068, 459011, 524374, 524310, 524574, 459027, 524406, 524342, 590028, 459019, 524390, 524326, 589996, 524294, 524422, 524358, 590060, 459015, 524382, 524318, 589980, 459031, 524414, 524350, 590044, 459023, 524398, 524334, 590012, 524302, 524430, 524366, 590076, 459008, 524369, 524305, 524569, 459024, 524401, 524337, 590018, 459016, 524385, 524321, 589986, 524289, 524417, 524353, 590050, 459012, 524377, 524313, 589970, 459028, 524409, 524345, 590034, 459020, 524393, 524329, 590002, 524297, 524425, 524361, 590066, 459010, 524373, 524309, 524573, 459026, 524405, 524341, 590026, 459018, 524389, 524325, 589994, 524293, 524421, 524357, 590058, 459014, 524381, 524317, 589978, 459030, 524413, 524349, 590042, 459022, 524397, 524333, 590010, 524301, 524429, 524365, 590074, 459009, 524371, 524307, 524571, 459025, 524403, 524339, 590022, 459017, 524387, 524323, 589990, 524291, 524419, 524355, 590054, 459013, 524379, 524315, 589974, 459029, 524411, 524347, 590038, 459021, 524395, 524331, 590006, 524299, 524427, 524363, 590070, 459011, 524375, 524311, 524575, 459027, 524407, 524343, 590030, 459019, 524391, 524327, 589998, 524295, 524423, 524359, 590062, 459015, 524383, 524319, 589982, 459031, 524415, 524351, 590046, 459023, 524399, 524335, 590014, 524303, 524431, 524367, 590078, 459008, 524368, 524304, 524568, 459024, 524400, 524336, 590017, 459016, 524384, 524320, 589985, 524288, 524416, 524352, 590049, 459012, 524376, 524312, 589969, 459028, 524408, 524344, 590033, 459020, 524392, 524328, 590001, 524296, 524424, 524360, 590065, 459010, 524372, 524308, 524572, 459026, 524404, 524340, 590025, 459018, 524388, 524324, 589993, 524292, 524420, 524356, 590057, 459014, 524380, 524316, 589977, 459030, 524412, 524348, 590041, 459022, 524396, 524332, 590009, 524300, 524428, 524364, 590073, 459009, 524370, 524306, 524570, 459025, 524402, 524338, 590021, 459017, 524386, 524322, 589989, 524290, 524418, 524354, 590053, 459013, 524378, 524314, 589973, 459029, 524410, 524346, 590037, 459021, 524394, 524330, 590005, 524298, 524426, 524362, 590069, 459011, 524374, 524310, 524574, 459027, 524406, 524342, 590029, 459019, 524390, 524326, 589997, 524294, 524422, 524358, 590061, 459015, 524382, 524318, 589981, 459031, 524414, 524350, 590045, 459023, 524398, 524334, 590013, 524302, 524430, 524366, 590077, 459008, 524369, 524305, 524569, 459024, 524401, 524337, 590019, 459016, 524385, 524321, 589987, 524289, 524417, 524353, 590051, 459012, 524377, 524313, 589971, 459028, 524409, 524345, 590035, 459020, 524393, 524329, 590003, 524297, 524425, 524361, 590067, 459010, 524373, 524309, 524573, 459026, 524405, 524341, 590027, 459018, 524389, 524325, 589995, 524293, 524421, 524357, 590059, 459014, 524381, 524317, 589979, 459030, 524413, 524349, 590043, 459022, 524397, 524333, 590011, 524301, 524429, 524365, 590075, 459009, 524371, 524307, 524571, 459025, 524403, 524339, 590023, 459017, 524387, 524323, 589991, 524291, 524419, 524355, 590055, 459013, 524379, 524315, 589975, 459029, 524411, 524347, 590039, 459021, 524395, 524331, 590007, 524299, 524427, 524363, 590071, 459011, 524375, 524311, 524575, 459027, 524407, 524343, 590031, 459019, 524391, 524327, 589999, 524295, 524423, 524359, 590063, 459015, 524383, 524319, 589983, 459031, 524415, 524351, 590047, 459023, 524399, 524335, 590015, 524303, 524431, 524367, 590079]), 9], r = [new Uint32Array([327680, 327696, 327688, 327704, 327684, 327700, 327692, 327708, 327682, 327698, 327690, 327706, 327686, 327702, 327694, 0, 327681, 327697, 327689, 327705, 327685, 327701, 327693, 327709, 327683, 327699, 327691, 327707, 327687, 327703, 327695, 0]), 5];
        return (s.prototype = Object.create(wn.prototype)).getBits = function(c) {
          for (var l, d = this.codeSize, B = this.codeBuf, h = this.bytes, f = this.bytesPos; d < c; )
            (l = h[f++]) === void 0 && n("Bad encoding in flate stream"), B |= l << d, d += 8;
          return l = B & (1 << c) - 1, this.codeBuf = B >> c, this.codeSize = d -= c, this.bytesPos = f, l;
        }, s.prototype.getCode = function(c) {
          for (var l = c[0], d = c[1], B = this.codeSize, h = this.codeBuf, f = this.bytes, m = this.bytesPos; B < d; ) {
            var w;
            (w = f[m++]) === void 0 && n("Bad encoding in flate stream"), h |= w << B, B += 8;
          }
          var U = l[h & (1 << d) - 1], I = U >> 16, S = 65535 & U;
          return (B == 0 || B < I || I == 0) && n("Bad encoding in flate stream"), this.codeBuf = h >> I, this.codeSize = B - I, this.bytesPos = m, S;
        }, s.prototype.generateHuffmanTable = function(c) {
          for (var l = c.length, d = 0, B = 0; B < l; ++B)
            c[B] > d && (d = c[B]);
          for (var h = 1 << d, f = new Uint32Array(h), m = 1, w = 0, U = 2; m <= d; ++m, w <<= 1, U <<= 1)
            for (var I = 0; I < l; ++I)
              if (c[I] == m) {
                var S = 0, L = w;
                for (B = 0; B < m; ++B)
                  S = S << 1 | 1 & L, L >>= 1;
                for (B = S; B < h; B += U)
                  f[B] = m << 16 | I;
                ++w;
              }
          return [f, d];
        }, s.prototype.readBlock = function() {
          function c(M, oA, X, fA, nA) {
            for (var b = M.getBits(X) + fA; 0 < b--; )
              oA[U++] = nA;
          }
          var l = this.getBits(3);
          if (1 & l && (this.eof = !0), (l >>= 1) != 0) {
            var d, B;
            if (l == 1)
              d = i, B = r;
            else if (l == 2) {
              for (var h = this.getBits(5) + 257, f = this.getBits(5) + 1, m = this.getBits(4) + 4, w = Array(o.length), U = 0; U < m; )
                w[o[U++]] = this.getBits(3);
              for (var I = this.generateHuffmanTable(w), S = 0, L = (U = 0, h + f), N = new Array(L); U < L; ) {
                var j = this.getCode(I);
                j == 16 ? c(this, N, 2, 3, S) : j == 17 ? c(this, N, 3, 3, S = 0) : j == 18 ? c(this, N, 7, 11, S = 0) : N[U++] = S = j;
              }
              d = this.generateHuffmanTable(N.slice(0, h)), B = this.generateHuffmanTable(N.slice(h, L));
            } else
              n("Unknown block type in flate stream");
            for (var Z = (R = this.buffer) ? R.length : 0, W = this.bufferLength; ; ) {
              var V = this.getCode(d);
              if (V < 256)
                Z <= W + 1 && (Z = (R = this.ensureBuffer(W + 1)).length), R[W++] = V;
              else {
                if (V == 256)
                  return void (this.bufferLength = W);
                var y = (V = p[V -= 257]) >> 16;
                0 < y && (y = this.getBits(y)), S = (65535 & V) + y, V = this.getCode(B), 0 < (y = (V = C[V]) >> 16) && (y = this.getBits(y));
                var P = (65535 & V) + y;
                Z <= W + S && (Z = (R = this.ensureBuffer(W + S)).length);
                for (var _ = 0; _ < S; ++_, ++W)
                  R[W] = R[W - P];
              }
            }
          } else {
            var Y, $ = this.bytes, hA = this.bytesPos;
            (Y = $[hA++]) === void 0 && n("Bad block header in flate stream");
            var z = Y;
            (Y = $[hA++]) === void 0 && n("Bad block header in flate stream"), z |= Y << 8, (Y = $[hA++]) === void 0 && n("Bad block header in flate stream");
            var k = Y;
            (Y = $[hA++]) === void 0 && n("Bad block header in flate stream"), (k |= Y << 8) != (65535 & ~z) && n("Bad uncompressed block length in flate stream"), this.codeBuf = 0, this.codeSize = 0;
            var F = this.bufferLength, R = this.ensureBuffer(F + z), E = F + z;
            this.bufferLength = E;
            for (var G = F; G < E; ++G) {
              if ((Y = $[hA++]) === void 0) {
                this.eof = !0;
                break;
              }
              R[G] = Y;
            }
            this.bytesPos = hA;
          }
        }, s;
      }
      function n(c) {
        throw new Error(c);
      }
      function s(c) {
        var l = 0, d = c[l++], B = c[l++];
        d != -1 && B != -1 || n("Invalid header in flate stream"), (15 & d) != 8 && n("Unknown compression method in flate stream"), ((d << 8) + B) % 31 != 0 && n("Bad FCHECK in flate stream"), 32 & B && n("FDICT bit set in flate stream"), this.bytes = c, this.bytesPos = 2, this.codeSize = 0, this.codeBuf = 0, wn.call(this);
      }
    }();
    return function(o) {
      if (typeof o.console != "object") {
        o.console = {};
        for (var p, C, i = o.console, r = function() {
        }, n = ["memory"], s = "assert,clear,count,debug,dir,dirxml,error,exception,group,groupCollapsed,groupEnd,info,log,markTimeline,profile,profiles,profileEnd,show,table,time,timeEnd,timeline,timelineEnd,timeStamp,trace,warn".split(","); p = n.pop(); )
          i[p] || (i[p] = {});
        for (; C = s.pop(); )
          i[C] || (i[C] = r);
      }
      var c, l, d, B, h = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
      o.btoa === void 0 && (o.btoa = function(f) {
        var m, w, U, I, S, L = 0, N = 0, j = "", Z = [];
        if (!f)
          return f;
        for (; m = (S = f.charCodeAt(L++) << 16 | f.charCodeAt(L++) << 8 | f.charCodeAt(L++)) >> 18 & 63, w = S >> 12 & 63, U = S >> 6 & 63, I = 63 & S, Z[N++] = h.charAt(m) + h.charAt(w) + h.charAt(U) + h.charAt(I), L < f.length; )
          ;
        j = Z.join("");
        var W = f.length % 3;
        return (W ? j.slice(0, W - 3) : j) + "===".slice(W || 3);
      }), o.atob === void 0 && (o.atob = function(f) {
        var m, w, U, I, S, L, N = 0, j = 0, Z = [];
        if (!f)
          return f;
        for (f += ""; m = (L = h.indexOf(f.charAt(N++)) << 18 | h.indexOf(f.charAt(N++)) << 12 | (I = h.indexOf(f.charAt(N++))) << 6 | (S = h.indexOf(f.charAt(N++)))) >> 16 & 255, w = L >> 8 & 255, U = 255 & L, Z[j++] = I == 64 ? String.fromCharCode(m) : S == 64 ? String.fromCharCode(m, w) : String.fromCharCode(m, w, U), N < f.length; )
          ;
        return Z.join("");
      }), Array.prototype.map || (Array.prototype.map = function(f) {
        if (this == null || typeof f != "function")
          throw new TypeError();
        for (var m = Object(this), w = m.length >>> 0, U = new Array(w), I = 1 < arguments.length ? arguments[1] : void 0, S = 0; S < w; S++)
          S in m && (U[S] = f.call(I, m[S], S, m));
        return U;
      }), Array.isArray || (Array.isArray = function(f) {
        return Object.prototype.toString.call(f) === "[object Array]";
      }), Array.prototype.forEach || (Array.prototype.forEach = function(f, m) {
        if (this == null || typeof f != "function")
          throw new TypeError();
        for (var w = Object(this), U = w.length >>> 0, I = 0; I < U; I++)
          I in w && f.call(m, w[I], I, w);
      }), Object.keys || (Object.keys = (c = Object.prototype.hasOwnProperty, l = !{ toString: null }.propertyIsEnumerable("toString"), B = (d = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"]).length, function(f) {
        if (typeof f != "object" && (typeof f != "function" || f === null))
          throw new TypeError();
        var m, w, U = [];
        for (m in f)
          c.call(f, m) && U.push(m);
        if (l)
          for (w = 0; w < B; w++)
            c.call(f, d[w]) && U.push(d[w]);
        return U;
      })), typeof Object.assign != "function" && (Object.assign = function(f) {
        if (f == null)
          throw new TypeError("Cannot convert undefined or null to object");
        f = Object(f);
        for (var m = 1; m < arguments.length; m++) {
          var w = arguments[m];
          if (w != null)
            for (var U in w)
              Object.prototype.hasOwnProperty.call(w, U) && (f[U] = w[U]);
        }
        return f;
      }), String.prototype.trim || (String.prototype.trim = function() {
        return this.replace(/^\s+|\s+$/g, "");
      }), String.prototype.trimLeft || (String.prototype.trimLeft = function() {
        return this.replace(/^\s+/g, "");
      }), String.prototype.trimRight || (String.prototype.trimRight = function() {
        return this.replace(/\s+$/g, "");
      });
    }(typeof self < "u" && self || typeof window < "u" && window || typeof Jt < "u" && Jt || Function('return typeof this === "object" && this.content')() || Function("return this")()), Ct;
  });
})(pi, pi.exports);
var Oa = pi.exports;
const wi = /* @__PURE__ */ Ro(Oa);
var Vo = { exports: {} };
/*!
 * html2canvas 1.4.1 <https://html2canvas.hertzen.com>
 * Copyright (c) 2022 Niklas von Hertzen <https://hertzen.com>
 * Released under MIT License
 */
(function(CA, J) {
  (function(uA, rA) {
    CA.exports = rA();
  })(Jt, function() {
    /*! *****************************************************************************
    	    Copyright (c) Microsoft Corporation.
    
    	    Permission to use, copy, modify, and/or distribute this software for any
    	    purpose with or without fee is hereby granted.
    
    	    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    	    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    	    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    	    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    	    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    	    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    	    PERFORMANCE OF THIS SOFTWARE.
    	    ***************************************************************************** */
    var uA = function(A, t) {
      return (uA = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(e, a) {
        e.__proto__ = a;
      } || function(e, a) {
        for (var g in a)
          Object.prototype.hasOwnProperty.call(a, g) && (e[g] = a[g]);
      })(A, t);
    };
    function rA(A, t) {
      if (typeof t != "function" && t !== null)
        throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
      function e() {
        this.constructor = A;
      }
      uA(A, t), A.prototype = t === null ? Object.create(t) : (e.prototype = t.prototype, new e());
    }
    var vA = function() {
      return (vA = Object.assign || function(A) {
        for (var t, e = 1, a = arguments.length; e < a; e++)
          for (var g in t = arguments[e])
            Object.prototype.hasOwnProperty.call(t, g) && (A[g] = t[g]);
        return A;
      }).apply(this, arguments);
    };
    function LA(A, t, e, a) {
      return new (e = e || Promise)(function(g, v) {
        function x(lA) {
          try {
            T(a.next(lA));
          } catch (cA) {
            v(cA);
          }
        }
        function q(lA) {
          try {
            T(a.throw(lA));
          } catch (cA) {
            v(cA);
          }
        }
        function T(lA) {
          var cA;
          lA.done ? g(lA.value) : ((cA = lA.value) instanceof e ? cA : new e(function(BA) {
            BA(cA);
          })).then(x, q);
        }
        T((a = a.apply(A, t || [])).next());
      });
    }
    function kA(A, t) {
      var e, a, g, v = { label: 0, sent: function() {
        if (1 & g[0])
          throw g[1];
        return g[1];
      }, trys: [], ops: [] }, x = { next: q(0), throw: q(1), return: q(2) };
      return typeof Symbol == "function" && (x[Symbol.iterator] = function() {
        return this;
      }), x;
      function q(T) {
        return function(lA) {
          return function(cA) {
            if (e)
              throw new TypeError("Generator is already executing.");
            for (; v; )
              try {
                if (e = 1, a && (g = 2 & cA[0] ? a.return : cA[0] ? a.throw || ((g = a.return) && g.call(a), 0) : a.next) && !(g = g.call(a, cA[1])).done)
                  return g;
                switch (a = 0, (cA = g ? [2 & cA[0], g.value] : cA)[0]) {
                  case 0:
                  case 1:
                    g = cA;
                    break;
                  case 4:
                    return v.label++, { value: cA[1], done: !1 };
                  case 5:
                    v.label++, a = cA[1], cA = [0];
                    continue;
                  case 7:
                    cA = v.ops.pop(), v.trys.pop();
                    continue;
                  default:
                    if (!(g = 0 < (g = v.trys).length && g[g.length - 1]) && (cA[0] === 6 || cA[0] === 2)) {
                      v = 0;
                      continue;
                    }
                    if (cA[0] === 3 && (!g || cA[1] > g[0] && cA[1] < g[3])) {
                      v.label = cA[1];
                      break;
                    }
                    if (cA[0] === 6 && v.label < g[1]) {
                      v.label = g[1], g = cA;
                      break;
                    }
                    if (g && v.label < g[2]) {
                      v.label = g[2], v.ops.push(cA);
                      break;
                    }
                    g[2] && v.ops.pop(), v.trys.pop();
                    continue;
                }
                cA = t.call(A, v);
              } catch (BA) {
                cA = [6, BA], a = 0;
              } finally {
                e = g = 0;
              }
            if (5 & cA[0])
              throw cA[1];
            return { value: cA[0] ? cA[1] : void 0, done: !0 };
          }([T, lA]);
        };
      }
    }
    function ZA(A, t, e) {
      if (e || arguments.length === 2)
        for (var a, g = 0, v = t.length; g < v; g++)
          !a && g in t || ((a = a || Array.prototype.slice.call(t, 0, g))[g] = t[g]);
      return A.concat(a || t);
    }
    var XA = (At.prototype.add = function(A, t, e, a) {
      return new At(this.left + A, this.top + t, this.width + e, this.height + a);
    }, At.fromClientRect = function(A, t) {
      return new At(t.left + A.windowBounds.left, t.top + A.windowBounds.top, t.width, t.height);
    }, At.fromDOMRectList = function(A, t) {
      return t = Array.from(t).find(function(e) {
        return e.width !== 0;
      }), t ? new At(t.left + A.windowBounds.left, t.top + A.windowBounds.top, t.width, t.height) : At.EMPTY;
    }, At.EMPTY = new At(0, 0, 0, 0), At);
    function At(A, t, e, a) {
      this.left = A, this.top = t, this.width = e, this.height = a;
    }
    for (var pt = function(A, t) {
      return XA.fromClientRect(A, t.getBoundingClientRect());
    }, at = function(A) {
      for (var t = [], e = 0, a = A.length; e < a; ) {
        var g, v = A.charCodeAt(e++);
        55296 <= v && v <= 56319 && e < a ? (64512 & (g = A.charCodeAt(e++))) == 56320 ? t.push(((1023 & v) << 10) + (1023 & g) + 65536) : (t.push(v), e--) : t.push(v);
      }
      return t;
    }, YA = function() {
      for (var A = [], t = 0; t < arguments.length; t++)
        A[t] = arguments[t];
      if (String.fromCodePoint)
        return String.fromCodePoint.apply(String, A);
      var e = A.length;
      if (!e)
        return "";
      for (var a = [], g = -1, v = ""; ++g < e; ) {
        var x = A[g];
        x <= 65535 ? a.push(x) : (x -= 65536, a.push(55296 + (x >> 10), x % 1024 + 56320)), (g + 1 === e || 16384 < a.length) && (v += String.fromCharCode.apply(String, a), a.length = 0);
      }
      return v;
    }, Ht = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", $t = typeof Uint8Array > "u" ? [] : new Uint8Array(256), Ae = 0; Ae < Ht.length; Ae++)
      $t[Ht.charCodeAt(Ae)] = Ae;
    for (var vt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", Bt = typeof Uint8Array > "u" ? [] : new Uint8Array(256), St = 0; St < vt.length; St++)
      Bt[vt.charCodeAt(St)] = St;
    function Tt(A, t, e) {
      return A.slice ? A.slice(t, e) : new Uint16Array(Array.prototype.slice.call(A, t, e));
    }
    var ne = (Kt.prototype.get = function(A) {
      var t;
      if (0 <= A) {
        if (A < 55296 || 56319 < A && A <= 65535)
          return t = this.index[A >> 5], this.data[t = (t << 2) + (31 & A)];
        if (A <= 65535)
          return t = this.index[2048 + (A - 55296 >> 5)], this.data[t = (t << 2) + (31 & A)];
        if (A < this.highStart)
          return t = this.index[t = 2080 + (A >> 11)], t = this.index[t += A >> 5 & 63], this.data[t = (t << 2) + (31 & A)];
        if (A <= 1114111)
          return this.data[this.highValueIndex];
      }
      return this.errorValue;
    }, Kt);
    function Kt(A, t, e, a, g, v) {
      this.initialValue = A, this.errorValue = t, this.highStart = e, this.highValueIndex = a, this.index = g, this.data = v;
    }
    for (var zt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", ie = typeof Uint8Array > "u" ? [] : new Uint8Array(256), Ne = 0; Ne < zt.length; Ne++)
      ie[zt.charCodeAt(Ne)] = Ne;
    function Be(A, t, e, a) {
      var g = a[e];
      if (Array.isArray(A) ? A.indexOf(g) !== -1 : A === g)
        for (var v = e; v <= a.length; ) {
          if ((q = a[++v]) === t)
            return 1;
          if (q !== te)
            break;
        }
      if (g === te)
        for (v = e; 0 < v; ) {
          var x = a[--v];
          if (Array.isArray(A) ? A.indexOf(x) !== -1 : A === x)
            for (var q, T = e; T <= a.length; ) {
              if ((q = a[++T]) === t)
                return 1;
              if (q !== te)
                break;
            }
          if (x !== te)
            break;
        }
    }
    function He(A, t) {
      for (var e = A; 0 <= e; ) {
        var a = t[e];
        if (a !== te)
          return a;
        e--;
      }
      return 0;
    }
    function Se(A, t) {
      var e = (g = function(v, x) {
        x === void 0 && (x = "strict");
        var q = [], T = [], lA = [];
        return v.forEach(function(cA, BA) {
          var mA = mr.get(cA);
          return 50 < mA ? (lA.push(!0), mA -= 50) : lA.push(!1), ["normal", "auto", "loose"].indexOf(x) !== -1 && [8208, 8211, 12316, 12448].indexOf(cA) !== -1 ? (T.push(BA), q.push(16)) : mA !== 4 && mA !== 11 ? (T.push(BA), mA === 31 ? q.push(x === "strict" ? ar : ye) : mA === Ct || mA === 29 ? q.push(Ce) : mA === 43 ? 131072 <= cA && cA <= 196605 || 196608 <= cA && cA <= 262141 ? q.push(ye) : q.push(Ce) : void q.push(mA)) : BA === 0 ? (T.push(BA), q.push(Ce)) : (mA = q[BA - 1], TA.indexOf(mA) === -1 ? (T.push(T[BA - 1]), q.push(mA)) : (T.push(BA), q.push(Ce)));
        }), [T, q, lA];
      }(A, (t = t || { lineBreak: "normal", wordBreak: "normal" }).lineBreak))[0], a = g[1], g = g[2];
      return [e, a = t.wordBreak === "break-all" || t.wordBreak === "break-word" ? a.map(function(v) {
        return [dt, Ce, Ct].indexOf(v) !== -1 ? ye : v;
      }) : a, t.wordBreak === "keep-all" ? g.map(function(v, x) {
        return v && 19968 <= A[x] && A[x] <= 40959;
      }) : void 0];
    }
    var we, ut, ft, _t, ge, te = 10, Ze = 13, $e = 15, Ue = 17, ke = 18, wr = 19, vr = 20, ar = 21, me = 22, Ge = 24, dt = 25, Ft = 26, Le = 27, ve = 28, Ce = 30, De = 32, cr = 33, Ve = 34, lr = 35, ye = 37, Ar = 38, Te = 39, Ot = 40, Ct = 42, Kr = [9001, 65288], lt = "×", mr = (ft = function(A) {
      var t, e, a, g, v = 0.75 * A.length, x = A.length, q = 0;
      A[A.length - 1] === "=" && (v--, A[A.length - 2] === "=" && v--);
      for (var v = new (typeof ArrayBuffer < "u" && typeof Uint8Array < "u" && Uint8Array.prototype.slice !== void 0 ? ArrayBuffer : Array)(v), T = Array.isArray(v) ? v : new Uint8Array(v), lA = 0; lA < x; lA += 4)
        t = Bt[A.charCodeAt(lA)], e = Bt[A.charCodeAt(lA + 1)], a = Bt[A.charCodeAt(lA + 2)], g = Bt[A.charCodeAt(lA + 3)], T[q++] = t << 2 | e >> 4, T[q++] = (15 & e) << 4 | a >> 2, T[q++] = (3 & a) << 6 | 63 & g;
      return v;
    }(we = "KwAAAAAAAAAACA4AUD0AADAgAAACAAAAAAAIABAAGABAAEgAUABYAGAAaABgAGgAYgBqAF8AZwBgAGgAcQB5AHUAfQCFAI0AlQCdAKIAqgCyALoAYABoAGAAaABgAGgAwgDKAGAAaADGAM4A0wDbAOEA6QDxAPkAAQEJAQ8BFwF1AH0AHAEkASwBNAE6AUIBQQFJAVEBWQFhAWgBcAF4ATAAgAGGAY4BlQGXAZ8BpwGvAbUBvQHFAc0B0wHbAeMB6wHxAfkBAQIJAvEBEQIZAiECKQIxAjgCQAJGAk4CVgJeAmQCbAJ0AnwCgQKJApECmQKgAqgCsAK4ArwCxAIwAMwC0wLbAjAA4wLrAvMC+AIAAwcDDwMwABcDHQMlAy0DNQN1AD0DQQNJA0kDSQNRA1EDVwNZA1kDdQB1AGEDdQBpA20DdQN1AHsDdQCBA4kDkQN1AHUAmQOhA3UAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AKYDrgN1AHUAtgO+A8YDzgPWAxcD3gPjA+sD8wN1AHUA+wMDBAkEdQANBBUEHQQlBCoEFwMyBDgEYABABBcDSARQBFgEYARoBDAAcAQzAXgEgASIBJAEdQCXBHUAnwSnBK4EtgS6BMIEyAR1AHUAdQB1AHUAdQCVANAEYABgAGAAYABgAGAAYABgANgEYADcBOQEYADsBPQE/AQEBQwFFAUcBSQFLAU0BWQEPAVEBUsFUwVbBWAAYgVgAGoFcgV6BYIFigWRBWAAmQWfBaYFYABgAGAAYABgAKoFYACxBbAFuQW6BcEFwQXHBcEFwQXPBdMF2wXjBeoF8gX6BQIGCgYSBhoGIgYqBjIGOgZgAD4GRgZMBmAAUwZaBmAAYABgAGAAYABgAGAAYABgAGAAYABgAGIGYABpBnAGYABgAGAAYABgAGAAYABgAGAAYAB4Bn8GhQZgAGAAYAB1AHcDFQSLBmAAYABgAJMGdQA9A3UAmwajBqsGqwaVALMGuwbDBjAAywbSBtIG1QbSBtIG0gbSBtIG0gbdBuMG6wbzBvsGAwcLBxMHAwcbByMHJwcsBywHMQcsB9IGOAdAB0gHTgfSBkgHVgfSBtIG0gbSBtIG0gbSBtIG0gbSBiwHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAdgAGAALAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAdbB2MHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsB2kH0gZwB64EdQB1AHUAdQB1AHUAdQB1AHUHfQdgAIUHjQd1AHUAlQedB2AAYAClB6sHYACzB7YHvgfGB3UAzgfWBzMB3gfmB1EB7gf1B/0HlQENAQUIDQh1ABUIHQglCBcDLQg1CD0IRQhNCEEDUwh1AHUAdQBbCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIcAh3CHoIMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIgggwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAALAcsBywHLAcsBywHLAcsBywHLAcsB4oILAcsB44I0gaWCJ4Ipgh1AHUAqgiyCHUAdQB1AHUAdQB1AHUAdQB1AHUAtwh8AXUAvwh1AMUIyQjRCNkI4AjoCHUAdQB1AO4I9gj+CAYJDgkTCS0HGwkjCYIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiAAIAAAAFAAYABgAGIAXwBgAHEAdQBFAJUAogCyAKAAYABgAEIA4ABGANMA4QDxAMEBDwE1AFwBLAE6AQEBUQF4QkhCmEKoQrhCgAHIQsAB0MLAAcABwAHAAeDC6ABoAHDCwMMAAcABwAHAAdDDGMMAAcAB6MM4wwjDWMNow3jDaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAEjDqABWw6bDqABpg6gAaABoAHcDvwOPA+gAaABfA/8DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DpcPAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcAB9cPKwkyCToJMAB1AHUAdQBCCUoJTQl1AFUJXAljCWcJawkwADAAMAAwAHMJdQB2CX4JdQCECYoJjgmWCXUAngkwAGAAYABxAHUApgn3A64JtAl1ALkJdQDACTAAMAAwADAAdQB1AHUAdQB1AHUAdQB1AHUAowYNBMUIMAAwADAAMADICcsJ0wnZCRUE4QkwAOkJ8An4CTAAMAB1AAAKvwh1AAgKDwoXCh8KdQAwACcKLgp1ADYKqAmICT4KRgowADAAdQB1AE4KMAB1AFYKdQBeCnUAZQowADAAMAAwADAAMAAwADAAMAAVBHUAbQowADAAdQC5CXUKMAAwAHwBxAijBogEMgF9CoQKiASMCpQKmgqIBKIKqgquCogEDQG2Cr4KxgrLCjAAMADTCtsKCgHjCusK8Qr5CgELMAAwADAAMAB1AIsECQsRC3UANAEZCzAAMAAwADAAMAB1ACELKQswAHUANAExCzkLdQBBC0kLMABRC1kLMAAwADAAMAAwADAAdQBhCzAAMAAwAGAAYABpC3ELdwt/CzAAMACHC4sLkwubC58Lpwt1AK4Ltgt1APsDMAAwADAAMAAwADAAMAAwAL4LwwvLC9IL1wvdCzAAMADlC+kL8Qv5C/8LSQswADAAMAAwADAAMAAwADAAMAAHDDAAMAAwADAAMAAODBYMHgx1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1ACYMMAAwADAAdQB1AHUALgx1AHUAdQB1AHUAdQA2DDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AD4MdQBGDHUAdQB1AHUAdQB1AEkMdQB1AHUAdQB1AFAMMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQBYDHUAdQB1AF8MMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUA+wMVBGcMMAAwAHwBbwx1AHcMfwyHDI8MMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAYABgAJcMMAAwADAAdQB1AJ8MlQClDDAAMACtDCwHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsB7UMLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AA0EMAC9DDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAsBywHLAcsBywHLAcsBywHLQcwAMEMyAwsBywHLAcsBywHLAcsBywHLAcsBywHzAwwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAHUAdQB1ANQM2QzhDDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMABgAGAAYABgAGAAYABgAOkMYADxDGAA+AwADQYNYABhCWAAYAAODTAAMAAwADAAFg1gAGAAHg37AzAAMAAwADAAYABgACYNYAAsDTQNPA1gAEMNPg1LDWAAYABgAGAAYABgAGAAYABgAGAAUg1aDYsGVglhDV0NcQBnDW0NdQ15DWAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAlQCBDZUAiA2PDZcNMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAnw2nDTAAMAAwADAAMAAwAHUArw23DTAAMAAwADAAMAAwADAAMAAwADAAMAB1AL8NMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAB1AHUAdQB1AHUAdQDHDTAAYABgAM8NMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAA1w11ANwNMAAwAD0B5A0wADAAMAAwADAAMADsDfQN/A0EDgwOFA4wABsOMAAwADAAMAAwADAAMAAwANIG0gbSBtIG0gbSBtIG0gYjDigOwQUuDsEFMw7SBjoO0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGQg5KDlIOVg7SBtIGXg5lDm0OdQ7SBtIGfQ6EDooOjQ6UDtIGmg6hDtIG0gaoDqwO0ga0DrwO0gZgAGAAYADEDmAAYAAkBtIGzA5gANIOYADaDokO0gbSBt8O5w7SBu8O0gb1DvwO0gZgAGAAxA7SBtIG0gbSBtIGYABgAGAAYAAED2AAsAUMD9IG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGFA8sBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAccD9IGLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHJA8sBywHLAcsBywHLAccDywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywPLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAc0D9IG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAccD9IG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGFA8sBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHPA/SBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gYUD0QPlQCVAJUAMAAwADAAMACVAJUAlQCVAJUAlQCVAEwPMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAA//8EAAQABAAEAAQABAAEAAQABAANAAMAAQABAAIABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQACgATABcAHgAbABoAHgAXABYAEgAeABsAGAAPABgAHABLAEsASwBLAEsASwBLAEsASwBLABgAGAAeAB4AHgATAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQABYAGwASAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAWAA0AEQAeAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAFAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAJABYAGgAbABsAGwAeAB0AHQAeAE8AFwAeAA0AHgAeABoAGwBPAE8ADgBQAB0AHQAdAE8ATwAXAE8ATwBPABYAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAFAAUABQAFAAUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAB4AHgAeAFAATwBAAE8ATwBPAEAATwBQAFAATwBQAB4AHgAeAB4AHgAeAB0AHQAdAB0AHgAdAB4ADgBQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgBQAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAJAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAkACQAJAAkACQAJAAkABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAFAAHgAeAB4AKwArAFAAUABQAFAAGABQACsAKwArACsAHgAeAFAAHgBQAFAAUAArAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAUAAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAYAA0AKwArAB4AHgAbACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQADQAEAB4ABAAEAB4ABAAEABMABAArACsAKwArACsAKwArACsAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAKwArACsAKwBWAFYAVgBWAB4AHgArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AGgAaABoAGAAYAB4AHgAEAAQABAAEAAQABAAEAAQABAAEAAQAEwAEACsAEwATAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABLAEsASwBLAEsASwBLAEsASwBLABoAGQAZAB4AUABQAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQABMAUAAEAAQABAAEAAQABAAEAB4AHgAEAAQABAAEAAQABABQAFAABAAEAB4ABAAEAAQABABQAFAASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUAAeAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAFAABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQAUABQAB4AHgAYABMAUAArACsABAAbABsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAFAABAAEAAQABAAEAFAABAAEAAQAUAAEAAQABAAEAAQAKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAArACsAHgArAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAUAAEAAQABAAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAABAAEAA0ADQBLAEsASwBLAEsASwBLAEsASwBLAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUAArACsAKwBQAFAAUABQACsAKwAEAFAABAAEAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABABQACsAKwArACsAKwArACsAKwAEACsAKwArACsAUABQACsAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAFAAUAAaABoAUABQAFAAUABQAEwAHgAbAFAAHgAEACsAKwAEAAQABAArAFAAUABQAFAAUABQACsAKwArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQACsAUABQACsAKwAEACsABAAEAAQABAAEACsAKwArACsABAAEACsAKwAEAAQABAArACsAKwAEACsAKwArACsAKwArACsAUABQAFAAUAArAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLAAQABABQAFAAUAAEAB4AKwArACsAKwArACsAKwArACsAKwAEAAQABAArAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQACsAKwAEAFAABAAEAAQABAAEAAQABAAEACsABAAEAAQAKwAEAAQABAArACsAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAB4AGwArACsAKwArACsAKwArAFAABAAEAAQABAAEAAQAKwAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABAArACsAKwArACsAKwArAAQABAAEACsAKwArACsAUABQACsAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAB4AUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArAAQAUAArAFAAUABQAFAAUABQACsAKwArAFAAUABQACsAUABQAFAAUAArACsAKwBQAFAAKwBQACsAUABQACsAKwArAFAAUAArACsAKwBQAFAAUAArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArAAQABAAEAAQABAArACsAKwAEAAQABAArAAQABAAEAAQAKwArAFAAKwArACsAKwArACsABAArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAHgAeAB4AHgAeAB4AGwAeACsAKwArACsAKwAEAAQABAAEAAQAUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAUAAEAAQABAAEAAQABAAEACsABAAEAAQAKwAEAAQABAAEACsAKwArACsAKwArACsABAAEACsAUABQAFAAKwArACsAKwArAFAAUAAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAKwAOAFAAUABQAFAAUABQAFAAHgBQAAQABAAEAA4AUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAKwArAAQAUAAEAAQABAAEAAQABAAEACsABAAEAAQAKwAEAAQABAAEACsAKwArACsAKwArACsABAAEACsAKwArACsAKwArACsAUAArAFAAUAAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwBQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAFAABAAEAAQABAAEAAQABAArAAQABAAEACsABAAEAAQABABQAB4AKwArACsAKwBQAFAAUAAEAFAAUABQAFAAUABQAFAAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAFAAUABQAFAAUABQAFAAUABQABoAUABQAFAAUABQAFAAKwAEAAQABAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQACsAUAArACsAUABQAFAAUABQAFAAUAArACsAKwAEACsAKwArACsABAAEAAQABAAEAAQAKwAEACsABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArAAQABAAeACsAKwArACsAKwArACsAKwArACsAKwArAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAAqAFwAXAAqACoAKgAqACoAKgAqACsAKwArACsAGwBcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAeAEsASwBLAEsASwBLAEsASwBLAEsADQANACsAKwArACsAKwBcAFwAKwBcACsAXABcAFwAXABcACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACsAXAArAFwAXABcAFwAXABcAFwAXABcAFwAKgBcAFwAKgAqACoAKgAqACoAKgAqACoAXAArACsAXABcAFwAXABcACsAXAArACoAKgAqACoAKgAqACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwBcAFwAXABcAFAADgAOAA4ADgAeAA4ADgAJAA4ADgANAAkAEwATABMAEwATAAkAHgATAB4AHgAeAAQABAAeAB4AHgAeAB4AHgBLAEsASwBLAEsASwBLAEsASwBLAFAAUABQAFAAUABQAFAAUABQAFAADQAEAB4ABAAeAAQAFgARABYAEQAEAAQAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQADQAEAAQABAAEAAQADQAEAAQAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArAA0ADQAeAB4AHgAeAB4AHgAEAB4AHgAeAB4AHgAeACsAHgAeAA4ADgANAA4AHgAeAB4AHgAeAAkACQArACsAKwArACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgBcAEsASwBLAEsASwBLAEsASwBLAEsADQANAB4AHgAeAB4AXABcAFwAXABcAFwAKgAqACoAKgBcAFwAXABcACoAKgAqAFwAKgAqACoAXABcACoAKgAqACoAKgAqACoAXABcAFwAKgAqACoAKgBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAqACoAKgAqAFwAKgBLAEsASwBLAEsASwBLAEsASwBLACoAKgAqACoAKgAqAFAAUABQAFAAUABQACsAUAArACsAKwArACsAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgBQAFAAUABQAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUAArACsAUABQAFAAUABQAFAAUAArAFAAKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAKwBQACsAUABQAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsABAAEAAQAHgANAB4AHgAeAB4AHgAeAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUAArACsADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAANAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAWABEAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAA0ADQANAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAANAA0AKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUAArAAQABAArACsAKwArACsAKwArACsAKwArACsAKwBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqAA0ADQAVAFwADQAeAA0AGwBcACoAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwAeAB4AEwATAA0ADQAOAB4AEwATAB4ABAAEAAQACQArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUAAEAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAHgArACsAKwATABMASwBLAEsASwBLAEsASwBLAEsASwBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAArACsAXABcAFwAXABcACsAKwArACsAKwArACsAKwArACsAKwBcAFwAXABcAFwAXABcAFwAXABcAFwAXAArACsAKwArAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAXAArACsAKwAqACoAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAArACsAHgAeAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAqACoAKwAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKwArAAQASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArACoAKgAqACoAKgAqACoAXAAqACoAKgAqACoAKgArACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABAAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABABQAFAAUABQAFAAUABQACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwANAA0AHgANAA0ADQANAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAEAAQAHgAeAB4AHgAeAB4AHgAeAB4AKwArACsABAAEAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwAeAB4AHgAeAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArAA0ADQANAA0ADQBLAEsASwBLAEsASwBLAEsASwBLACsAKwArAFAAUABQAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAA0ADQBQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUAAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArAAQABAAEAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAAQAUABQAFAAUABQAFAABABQAFAABAAEAAQAUAArACsAKwArACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsABAAEAAQABAAEAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAKwBQACsAUAArAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgBQAB4AHgAeAFAAUABQACsAHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQACsAKwAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAFAAUABQACsAHgAeAB4AHgAeAB4AHgAOAB4AKwANAA0ADQANAA0ADQANAAkADQANAA0ACAAEAAsABAAEAA0ACQANAA0ADAAdAB0AHgAXABcAFgAXABcAFwAWABcAHQAdAB4AHgAUABQAFAANAAEAAQAEAAQABAAEAAQACQAaABoAGgAaABoAGgAaABoAHgAXABcAHQAVABUAHgAeAB4AHgAeAB4AGAAWABEAFQAVABUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ADQAeAA0ADQANAA0AHgANAA0ADQAHAB4AHgAeAB4AKwAEAAQABAAEAAQABAAEAAQABAAEAFAAUAArACsATwBQAFAAUABQAFAAHgAeAB4AFgARAE8AUABPAE8ATwBPAFAAUABQAFAAUAAeAB4AHgAWABEAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArABsAGwAbABsAGwAbABsAGgAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGgAbABsAGwAbABoAGwAbABoAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAHgAeAFAAGgAeAB0AHgBQAB4AGgAeAB4AHgAeAB4AHgAeAB4AHgBPAB4AUAAbAB4AHgBQAFAAUABQAFAAHgAeAB4AHQAdAB4AUAAeAFAAHgBQAB4AUABPAFAAUAAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAHgBQAFAAUABQAE8ATwBQAFAAUABQAFAATwBQAFAATwBQAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAFAAUABQAFAATwBPAE8ATwBPAE8ATwBPAE8ATwBQAFAAUABQAFAAUABQAFAAUAAeAB4AUABQAFAAUABPAB4AHgArACsAKwArAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB4AHQAdAB4AHgAeAB0AHQAeAB4AHQAeAB4AHgAdAB4AHQAbABsAHgAdAB4AHgAeAB4AHQAeAB4AHQAdAB0AHQAeAB4AHQAeAB0AHgAdAB0AHQAdAB0AHQAeAB0AHgAeAB4AHgAeAB0AHQAdAB0AHgAeAB4AHgAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB4AHgAeAB0AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHgAeAB0AHQAdAB0AHgAeAB0AHQAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAeAB4AHgAdAB4AHgAeAB4AHgAeAB4AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABYAEQAWABEAHgAeAB4AHgAeAB4AHQAeAB4AHgAeAB4AHgAeACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAWABEAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAFAAHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAeAB4AHQAdAB0AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB4AHQAdAB4AHgAeAB4AHQAdAB4AHgAeAB4AHQAdAB0AHgAeAB0AHgAeAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlAB4AHQAdAB4AHgAdAB4AHgAeAB4AHQAdAB4AHgAeAB4AJQAlAB0AHQAlAB4AJQAlACUAIAAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAeAB4AHgAeAB0AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHgAdAB0AHQAeAB0AJQAdAB0AHgAdAB0AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAdAB0AHQAdACUAHgAlACUAJQAdACUAJQAdAB0AHQAlACUAHQAdACUAHQAdACUAJQAlAB4AHQAeAB4AHgAeAB0AHQAlAB0AHQAdAB0AHQAdACUAJQAlACUAJQAdACUAJQAgACUAHQAdACUAJQAlACUAJQAlACUAJQAeAB4AHgAlACUAIAAgACAAIAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AFwAXABcAFwAXABcAHgATABMAJQAeAB4AHgAWABEAFgARABYAEQAWABEAFgARABYAEQAWABEATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABYAEQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAWABEAFgARABYAEQAWABEAFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFgARABYAEQAWABEAFgARABYAEQAWABEAFgARABYAEQAWABEAFgARABYAEQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAWABEAFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAEAAQABAAeAB4AKwArACsAKwArABMADQANAA0AUAATAA0AUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAUAANACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAA0ADQANAA0ADQANAA0ADQAeAA0AFgANAB4AHgAXABcAHgAeABcAFwAWABEAFgARABYAEQAWABEADQANAA0ADQATAFAADQANAB4ADQANAB4AHgAeAB4AHgAMAAwADQANAA0AHgANAA0AFgANAA0ADQANAA0ADQANAA0AHgANAB4ADQANAB4AHgAeACsAKwArACsAKwArACsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwArACsAKwArACsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArAA0AEQARACUAJQBHAFcAVwAWABEAFgARABYAEQAWABEAFgARACUAJQAWABEAFgARABYAEQAWABEAFQAWABEAEQAlAFcAVwBXAFcAVwBXAFcAVwBXAAQABAAEAAQABAAEACUAVwBXAFcAVwA2ACUAJQBXAFcAVwBHAEcAJQAlACUAKwBRAFcAUQBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFEAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBRAFcAUQBXAFEAVwBXAFcAVwBXAFcAUQBXAFcAVwBXAFcAVwBRAFEAKwArAAQABAAVABUARwBHAFcAFQBRAFcAUQBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBRAFcAVwBXAFcAVwBXAFEAUQBXAFcAVwBXABUAUQBHAEcAVwArACsAKwArACsAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwAlACUAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACsAKwArACsAKwArACsAKwArACsAKwArAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBPAE8ATwBPAE8ATwBPAE8AJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQAlAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAEcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAADQATAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABLAEsASwBLAEsASwBLAEsASwBLAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAABAAEAAQABAAeAAQABAAEAAQABAAEAAQABAAEAAQAHgBQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUABQAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAeAA0ADQANAA0ADQArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAB4AHgAeAB4AHgAeAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAeAB4AUABQAFAAUABQAFAAUABQAFAAUABQAAQAUABQAFAABABQAFAAUABQAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAeAB4AHgAeAAQAKwArACsAUABQAFAAUABQAFAAHgAeABoAHgArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAADgAOABMAEwArACsAKwArACsAKwArACsABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwANAA0ASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAFAAUAAeAB4AHgBQAA4AUABQAAQAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAA0ADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArAB4AWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYACsAKwArAAQAHgAeAB4AHgAeAB4ADQANAA0AHgAeAB4AHgArAFAASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArAB4AHgBcAFwAXABcAFwAKgBcAFwAXABcAFwAXABcAFwAXABcAEsASwBLAEsASwBLAEsASwBLAEsAXABcAFwAXABcACsAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArAFAAUABQAAQAUABQAFAAUABQAFAAUABQAAQABAArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAHgANAA0ADQBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKgAqACoAXAAqACoAKgBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAAqAFwAKgAqACoAXABcACoAKgBcAFwAXABcAFwAKgAqAFwAKgBcACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFwAXABcACoAKgBQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAA0ADQBQAFAAUAAEAAQAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUAArACsAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQADQAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAVABVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBUAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVACsAKwArACsAKwArACsAKwArACsAKwArAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAKwArACsAKwBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAKwArACsAKwAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAKwArACsAKwArAFYABABWAFYAVgBWAFYAVgBWAFYAVgBWAB4AVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgArAFYAVgBWAFYAVgArAFYAKwBWAFYAKwBWAFYAKwBWAFYAVgBWAFYAVgBWAFYAVgBWAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAEQAWAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAaAB4AKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAGAARABEAGAAYABMAEwAWABEAFAArACsAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACUAJQAlACUAJQAWABEAFgARABYAEQAWABEAFgARABYAEQAlACUAFgARACUAJQAlACUAJQAlACUAEQAlABEAKwAVABUAEwATACUAFgARABYAEQAWABEAJQAlACUAJQAlACUAJQAlACsAJQAbABoAJQArACsAKwArAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAcAKwATACUAJQAbABoAJQAlABYAEQAlACUAEQAlABEAJQBXAFcAVwBXAFcAVwBXAFcAVwBXABUAFQAlACUAJQATACUAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXABYAJQARACUAJQAlAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAWACUAEQAlABYAEQARABYAEQARABUAVwBRAFEAUQBRAFEAUQBRAFEAUQBRAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAEcARwArACsAVwBXAFcAVwBXAFcAKwArAFcAVwBXAFcAVwBXACsAKwBXAFcAVwBXAFcAVwArACsAVwBXAFcAKwArACsAGgAbACUAJQAlABsAGwArAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwAEAAQABAAQAB0AKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsADQANAA0AKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAAQAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAA0AUABQAFAAUAArACsAKwArAFAAUABQAFAAUABQAFAAUAANAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwAeACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAKwArAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUAArACsAKwBQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwANAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAB4AUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAUABQAFAAUABQAAQABAAEACsABAAEACsAKwArACsAKwAEAAQABAAEAFAAUABQAFAAKwBQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEACsAKwArACsABABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAA0ADQANAA0ADQANAA0ADQAeACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAArACsAKwArAFAAUABQAFAAUAANAA0ADQANAA0ADQAUACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsADQANAA0ADQANAA0ADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAAQABAAEAAQAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUAArAAQABAANACsAKwBQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAB4AHgAeAB4AHgArACsAKwArACsAKwAEAAQABAAEAAQABAAEAA0ADQAeAB4AHgAeAB4AKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgANAA0ADQANACsAKwArACsAKwArACsAKwArACsAKwAeACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsASwBLAEsASwBLAEsASwBLAEsASwANAA0ADQANAFAABAAEAFAAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAeAA4AUAArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAADQANAB4ADQAEAAQABAAEAB4ABAAEAEsASwBLAEsASwBLAEsASwBLAEsAUAAOAFAADQANAA0AKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAANAA0AHgANAA0AHgAEACsAUABQAFAAUABQAFAAUAArAFAAKwBQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAA0AKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsABAAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQACsABAAEAFAABAAEAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABAArACsAUAArACsAKwArACsAKwAEACsAKwArACsAKwBQAFAAUABQAFAABAAEACsAKwAEAAQABAAEAAQABAAEACsAKwArAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwArACsABAAEAAQABAAEAAQABABQAFAAUABQAA0ADQANAA0AHgBLAEsASwBLAEsASwBLAEsASwBLAA0ADQArAB4ABABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAAQABAAEAFAAUAAeAFAAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAArACsABAAEAAQABAAEAAQABAAEAAQADgANAA0AEwATAB4AHgAeAA0ADQANAA0ADQANAA0ADQANAA0ADQANAA0ADQANAFAAUABQAFAABAAEACsAKwAEAA0ADQAeAFAAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKwArACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBcAFwADQANAA0AKgBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAKwArAFAAKwArAFAAUABQAFAAUABQAFAAUAArAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQAKwAEAAQAKwArAAQABAAEAAQAUAAEAFAABAAEAA0ADQANACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAArACsABAAEAAQABAAEAAQABABQAA4AUAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAFAABAAEAAQABAAOAB4ADQANAA0ADQAOAB4ABAArACsAKwArACsAKwArACsAUAAEAAQABAAEAAQABAAEAAQABAAEAAQAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAA0ADQANAFAADgAOAA4ADQANACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEACsABAAEAAQABAAEAAQABAAEAFAADQANAA0ADQANACsAKwArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwAOABMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAArACsAKwAEACsABAAEACsABAAEAAQABAAEAAQABABQAAQAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAKwBQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQAKwAEAAQAKwAEAAQABAAEAAQAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAaABoAGgAaAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsADQANAA0ADQANACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAASABIAEgAQwBDAEMAUABQAFAAUABDAFAAUABQAEgAQwBIAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAASABDAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwAJAAkACQAJAAkACQAJABYAEQArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABIAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwANAA0AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEAAQABAANACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAA0ADQANAB4AHgAeAB4AHgAeAFAAUABQAFAADQAeACsAKwArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAANAA0AHgAeACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwAEAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAARwBHABUARwAJACsAKwArACsAKwArACsAKwArACsAKwAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACsAKwArACsAKwArACsAKwBXAFcAVwBXAFcAVwBXAFcAVwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUQBRAFEAKwArACsAKwArACsAKwArACsAKwArACsAKwBRAFEAUQBRACsAKwArACsAKwArACsAKwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUAArACsAHgAEAAQADQAEAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArAB4AHgAeAB4AHgAeAB4AKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAAQABAAEAAQABAAeAB4AHgAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAB4AHgAEAAQABAAEAAQABAAEAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQAHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwBQAFAAKwArAFAAKwArAFAAUAArACsAUABQAFAAUAArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAUAArAFAAUABQAFAAUABQAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAHgAeAFAAUABQAFAAUAArAFAAKwArACsAUABQAFAAUABQAFAAUAArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeACsAKwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4ABAAeAB4AHgAeAB4AHgAeAB4AHgAeAAQAHgAeAA0ADQANAA0AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAAQABAAEAAQAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArAAQABAAEAAQABAAEAAQAKwAEAAQAKwAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwAEAAQABAAEAAQABAAEAFAAUABQAFAAUABQAFAAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwBQAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArABsAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArAB4AHgAeAB4ABAAEAAQABAAEAAQABABQACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArABYAFgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAGgBQAFAAUAAaAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAKwBQACsAKwBQACsAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwBQACsAUAArACsAKwArACsAKwBQACsAKwArACsAUAArAFAAKwBQACsAUABQAFAAKwBQAFAAKwBQACsAKwBQACsAUAArAFAAKwBQACsAUAArAFAAUAArAFAAKwArAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUAArAFAAUABQAFAAKwBQACsAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAUABQAFAAKwBQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8AJQAlACUAHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB4AHgAeACUAJQAlAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAJQAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAB4AHgAlACUAJQAlACUAHgAlACUAJQAlACUAIAAgACAAJQAlACAAJQAlACAAIAAgACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACEAIQAhACEAIQAlACUAIAAgACUAJQAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlACUAIAAlACUAJQAlACAAIAAgACUAIAAgACAAJQAlACUAJQAlACUAJQAgACUAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAlAB4AJQAeACUAJQAlACUAJQAgACUAJQAlACUAHgAlAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAJQAlACUAJQAgACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACAAIAAgACUAJQAlACAAIAAgACAAIAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABcAFwAXABUAFQAVAB4AHgAeAB4AJQAlACUAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAgACUAJQAlACUAJQAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAgACUAJQAgACUAJQAlACUAJQAlACUAJQAgACAAIAAgACAAIAAgACAAJQAlACUAJQAlACUAIAAlACUAJQAlACUAJQAlACUAJQAgACAAIAAgACAAIAAgACAAIAAgACUAJQAgACAAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAgACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAlACAAIAAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAgACAAIAAlACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwArAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACUAVwBXACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAA=="), _t = Array.isArray(ft) ? function(A) {
      for (var t = A.length, e = [], a = 0; a < t; a += 4)
        e.push(A[a + 3] << 24 | A[a + 2] << 16 | A[a + 1] << 8 | A[a]);
      return e;
    }(ft) : new Uint32Array(ft), ge = Array.isArray(ft) ? function(A) {
      for (var t = A.length, e = [], a = 0; a < t; a += 2)
        e.push(A[a + 1] << 8 | A[a]);
      return e;
    }(ft) : new Uint16Array(ft), we = Tt(ge, 12, _t[4] / 2), ut = _t[5] === 2 ? Tt(ge, (24 + _t[4]) / 2) : (ft = _t, ge = Math.ceil((24 + _t[4]) / 4), ft.slice ? ft.slice(ge, ut) : new Uint32Array(Array.prototype.slice.call(ft, ge, ut))), new ne(_t[0], _t[1], _t[2], _t[3], we, ut)), Ut = [Ce, 36], Qe = [1, 2, 3, 5], UA = [te, 8], HA = [Le, Ft], TA = Qe.concat(UA), WA = [Ar, Te, Ot, Ve, lr], nt = [$e, Ze], tt = (Lt.prototype.slice = function() {
      return YA.apply(void 0, this.codePoints.slice(this.start, this.end));
    }, Lt);
    function Lt(A, t, e, a) {
      this.codePoints = A, this.required = t === "!", this.start = e, this.end = a;
    }
    function Fe(A, t) {
      var e = at(A), a = (t = Se(e, t))[0], g = t[1], v = t[2], x = e.length, q = 0, T = 0;
      return { next: function() {
        if (x <= T)
          return { done: !0, value: null };
        for (var lA = lt; T < x && (lA = function(BA, mA, FA, It, NA) {
          if (FA[It] === 0)
            return lt;
          var IA = It - 1;
          if (Array.isArray(NA) && NA[IA] === !0)
            return lt;
          var zA = IA - 1, RA = 1 + IA, GA = mA[IA], It = 0 <= zA ? mA[zA] : 0, NA = mA[RA];
          if (GA === 2 && NA === 3)
            return lt;
          if (Qe.indexOf(GA) !== -1)
            return "!";
          if (Qe.indexOf(NA) !== -1 || UA.indexOf(NA) !== -1)
            return lt;
          if (He(IA, mA) === 8)
            return "÷";
          if (mr.get(BA[IA]) === 11 || (GA === De || GA === cr) && mr.get(BA[RA]) === 11 || GA === 7 || NA === 7 || GA === 9 || [te, Ze, $e].indexOf(GA) === -1 && NA === 9 || [Ue, ke, wr, Ge, ve].indexOf(NA) !== -1 || He(IA, mA) === me || Be(23, me, IA, mA) || Be([Ue, ke], ar, IA, mA) || Be(12, 12, IA, mA))
            return lt;
          if (GA === te)
            return "÷";
          if (GA === 23 || NA === 23)
            return lt;
          if (NA === 16 || GA === 16)
            return "÷";
          if ([Ze, $e, ar].indexOf(NA) !== -1 || GA === 14 || It === 36 && nt.indexOf(GA) !== -1 || GA === ve && NA === 36 || NA === vr || Ut.indexOf(NA) !== -1 && GA === dt || Ut.indexOf(GA) !== -1 && NA === dt || GA === Le && [ye, De, cr].indexOf(NA) !== -1 || [ye, De, cr].indexOf(GA) !== -1 && NA === Ft || Ut.indexOf(GA) !== -1 && HA.indexOf(NA) !== -1 || HA.indexOf(GA) !== -1 && Ut.indexOf(NA) !== -1 || [Le, Ft].indexOf(GA) !== -1 && (NA === dt || [me, $e].indexOf(NA) !== -1 && mA[1 + RA] === dt) || [me, $e].indexOf(GA) !== -1 && NA === dt || GA === dt && [dt, ve, Ge].indexOf(NA) !== -1)
            return lt;
          if ([dt, ve, Ge, Ue, ke].indexOf(NA) !== -1)
            for (var Qt = IA; 0 <= Qt; ) {
              if ((jt = mA[Qt]) === dt)
                return lt;
              if ([ve, Ge].indexOf(jt) === -1)
                break;
              Qt--;
            }
          if ([Le, Ft].indexOf(NA) !== -1)
            for (var jt, Qt = [Ue, ke].indexOf(GA) !== -1 ? zA : IA; 0 <= Qt; ) {
              if ((jt = mA[Qt]) === dt)
                return lt;
              if ([ve, Ge].indexOf(jt) === -1)
                break;
              Qt--;
            }
          if (Ar === GA && [Ar, Te, Ve, lr].indexOf(NA) !== -1 || [Te, Ve].indexOf(GA) !== -1 && [Te, Ot].indexOf(NA) !== -1 || [Ot, lr].indexOf(GA) !== -1 && NA === Ot || WA.indexOf(GA) !== -1 && [vr, Ft].indexOf(NA) !== -1 || WA.indexOf(NA) !== -1 && GA === Le || Ut.indexOf(GA) !== -1 && Ut.indexOf(NA) !== -1 || GA === Ge && Ut.indexOf(NA) !== -1 || Ut.concat(dt).indexOf(GA) !== -1 && NA === me && Kr.indexOf(BA[RA]) === -1 || Ut.concat(dt).indexOf(NA) !== -1 && GA === ke)
            return lt;
          if (GA === 41 && NA === 41) {
            for (var de = FA[IA], Wt = 1; 0 < de && mA[--de] === 41; )
              Wt++;
            if (Wt % 2 != 0)
              return lt;
          }
          return GA === De && NA === cr ? lt : "÷";
        }(e, g, a, ++T, v)) === lt; )
          ;
        if (lA === lt && T !== x)
          return { done: !0, value: null };
        var cA = new tt(e, lA, q, T);
        return q = T, { value: cA, done: !1 };
      } };
    }
    function Vt(A) {
      return 48 <= A && A <= 57;
    }
    function tr(A) {
      return Vt(A) || 65 <= A && A <= 70 || 97 <= A && A <= 102;
    }
    function br(A) {
      return A === 10 || A === 9 || A === 32;
    }
    function er(A) {
      return 97 <= (e = t = A) && e <= 122 || 65 <= (t = t) && t <= 90 || 128 <= A || A === 95;
      var t, e;
    }
    function tn(A) {
      return er(A) || Vt(A) || A === 45;
    }
    function rr(A, t) {
      return A === 92 && t !== 10;
    }
    function Cr(A, t, e) {
      return A === 45 ? er(t) || rr(t, e) : !!er(A) || A === 92 && t !== 10;
    }
    function pe(A, t, e) {
      return A === 43 || A === 45 ? !!Vt(t) || t === 46 && Vt(e) : Vt(A === 46 ? t : A);
    }
    var wn = { type: 2 }, mn = { type: 3 }, o = { type: 4 }, p = { type: 13 }, C = { type: 8 }, i = { type: 21 }, r = { type: 9 }, n = { type: 10 }, s = { type: 11 }, c = { type: 12 }, l = { type: 14 }, d = { type: 23 }, B = { type: 1 }, h = { type: 25 }, f = { type: 24 }, m = { type: 26 }, w = { type: 27 }, U = { type: 28 }, I = { type: 29 }, S = { type: 31 }, L = { type: 32 }, N = (j.prototype.write = function(A) {
      this._value = this._value.concat(at(A));
    }, j.prototype.read = function() {
      for (var A = [], t = this.consumeToken(); t !== L; )
        A.push(t), t = this.consumeToken();
      return A;
    }, j.prototype.consumeToken = function() {
      var A = this.consumeCodePoint();
      switch (A) {
        case 34:
          return this.consumeStringToken(34);
        case 35:
          var t = this.peekCodePoint(0), e = this.peekCodePoint(1), a = this.peekCodePoint(2);
          if (tn(t) || rr(e, a)) {
            var g = Cr(t, e, a) ? 2 : 1;
            return { type: 5, value: this.consumeName(), flags: g };
          }
          break;
        case 36:
          if (this.peekCodePoint(0) === 61)
            return this.consumeCodePoint(), p;
          break;
        case 39:
          return this.consumeStringToken(39);
        case 40:
          return wn;
        case 41:
          return mn;
        case 42:
          if (this.peekCodePoint(0) === 61)
            return this.consumeCodePoint(), l;
          break;
        case 43:
          if (pe(A, this.peekCodePoint(0), this.peekCodePoint(1)))
            return this.reconsumeCodePoint(A), this.consumeNumericToken();
          break;
        case 44:
          return o;
        case 45:
          var a = A, g = this.peekCodePoint(0), x = this.peekCodePoint(1);
          if (pe(a, g, x))
            return this.reconsumeCodePoint(A), this.consumeNumericToken();
          if (Cr(a, g, x))
            return this.reconsumeCodePoint(A), this.consumeIdentLikeToken();
          if (g === 45 && x === 62)
            return this.consumeCodePoint(), this.consumeCodePoint(), f;
          break;
        case 46:
          if (pe(A, this.peekCodePoint(0), this.peekCodePoint(1)))
            return this.reconsumeCodePoint(A), this.consumeNumericToken();
          break;
        case 47:
          if (this.peekCodePoint(0) === 42)
            for (this.consumeCodePoint(); ; ) {
              var v = this.consumeCodePoint();
              if (v === 42 && (v = this.consumeCodePoint()) === 47)
                return this.consumeToken();
              if (v === -1)
                return this.consumeToken();
            }
          break;
        case 58:
          return m;
        case 59:
          return w;
        case 60:
          if (this.peekCodePoint(0) === 33 && this.peekCodePoint(1) === 45 && this.peekCodePoint(2) === 45)
            return this.consumeCodePoint(), this.consumeCodePoint(), h;
          break;
        case 64:
          var x = this.peekCodePoint(0), q = this.peekCodePoint(1), T = this.peekCodePoint(2);
          if (Cr(x, q, T))
            return { type: 7, value: this.consumeName() };
          break;
        case 91:
          return U;
        case 92:
          if (rr(A, this.peekCodePoint(0)))
            return this.reconsumeCodePoint(A), this.consumeIdentLikeToken();
          break;
        case 93:
          return I;
        case 61:
          if (this.peekCodePoint(0) === 61)
            return this.consumeCodePoint(), C;
          break;
        case 123:
          return s;
        case 125:
          return c;
        case 117:
        case 85:
          return q = this.peekCodePoint(0), T = this.peekCodePoint(1), q !== 43 || !tr(T) && T !== 63 || (this.consumeCodePoint(), this.consumeUnicodeRangeToken()), this.reconsumeCodePoint(A), this.consumeIdentLikeToken();
        case 124:
          if (this.peekCodePoint(0) === 61)
            return this.consumeCodePoint(), r;
          if (this.peekCodePoint(0) === 124)
            return this.consumeCodePoint(), i;
          break;
        case 126:
          if (this.peekCodePoint(0) === 61)
            return this.consumeCodePoint(), n;
          break;
        case -1:
          return L;
      }
      return br(A) ? (this.consumeWhiteSpace(), S) : Vt(A) ? (this.reconsumeCodePoint(A), this.consumeNumericToken()) : er(A) ? (this.reconsumeCodePoint(A), this.consumeIdentLikeToken()) : { type: 6, value: YA(A) };
    }, j.prototype.consumeCodePoint = function() {
      var A = this._value.shift();
      return A === void 0 ? -1 : A;
    }, j.prototype.reconsumeCodePoint = function(A) {
      this._value.unshift(A);
    }, j.prototype.peekCodePoint = function(A) {
      return A >= this._value.length ? -1 : this._value[A];
    }, j.prototype.consumeUnicodeRangeToken = function() {
      for (var A = [], t = this.consumeCodePoint(); tr(t) && A.length < 6; )
        A.push(t), t = this.consumeCodePoint();
      for (var e = !1; t === 63 && A.length < 6; )
        A.push(t), t = this.consumeCodePoint(), e = !0;
      if (e)
        return { type: 30, start: parseInt(YA.apply(void 0, A.map(function(v) {
          return v === 63 ? 48 : v;
        })), 16), end: parseInt(YA.apply(void 0, A.map(function(v) {
          return v === 63 ? 70 : v;
        })), 16) };
      var a = parseInt(YA.apply(void 0, A), 16);
      if (this.peekCodePoint(0) === 45 && tr(this.peekCodePoint(1))) {
        this.consumeCodePoint();
        for (var t = this.consumeCodePoint(), g = []; tr(t) && g.length < 6; )
          g.push(t), t = this.consumeCodePoint();
        return { type: 30, start: a, end: parseInt(YA.apply(void 0, g), 16) };
      }
      return { type: 30, start: a, end: a };
    }, j.prototype.consumeIdentLikeToken = function() {
      var A = this.consumeName();
      return A.toLowerCase() === "url" && this.peekCodePoint(0) === 40 ? (this.consumeCodePoint(), this.consumeUrlToken()) : this.peekCodePoint(0) === 40 ? (this.consumeCodePoint(), { type: 19, value: A }) : { type: 20, value: A };
    }, j.prototype.consumeUrlToken = function() {
      var A = [];
      if (this.consumeWhiteSpace(), this.peekCodePoint(0) === -1)
        return { type: 22, value: "" };
      var t, e = this.peekCodePoint(0);
      if (e === 39 || e === 34)
        return e = this.consumeStringToken(this.consumeCodePoint()), e.type === 0 && (this.consumeWhiteSpace(), this.peekCodePoint(0) === -1 || this.peekCodePoint(0) === 41) ? (this.consumeCodePoint(), { type: 22, value: e.value }) : (this.consumeBadUrlRemnants(), d);
      for (; ; ) {
        var a = this.consumeCodePoint();
        if (a === -1 || a === 41)
          return { type: 22, value: YA.apply(void 0, A) };
        if (br(a))
          return this.consumeWhiteSpace(), this.peekCodePoint(0) === -1 || this.peekCodePoint(0) === 41 ? (this.consumeCodePoint(), { type: 22, value: YA.apply(void 0, A) }) : (this.consumeBadUrlRemnants(), d);
        if (a === 34 || a === 39 || a === 40 || 0 <= (t = a) && t <= 8 || t === 11 || 14 <= t && t <= 31 || t === 127)
          return this.consumeBadUrlRemnants(), d;
        if (a === 92) {
          if (!rr(a, this.peekCodePoint(0)))
            return this.consumeBadUrlRemnants(), d;
          A.push(this.consumeEscapedCodePoint());
        } else
          A.push(a);
      }
    }, j.prototype.consumeWhiteSpace = function() {
      for (; br(this.peekCodePoint(0)); )
        this.consumeCodePoint();
    }, j.prototype.consumeBadUrlRemnants = function() {
      for (; ; ) {
        var A = this.consumeCodePoint();
        if (A === 41 || A === -1)
          return;
        rr(A, this.peekCodePoint(0)) && this.consumeEscapedCodePoint();
      }
    }, j.prototype.consumeStringSlice = function(A) {
      for (var t = ""; 0 < A; ) {
        var e = Math.min(5e4, A);
        t += YA.apply(void 0, this._value.splice(0, e)), A -= e;
      }
      return this._value.shift(), t;
    }, j.prototype.consumeStringToken = function(A) {
      for (var t = "", e = 0; ; ) {
        var a, g = this._value[e];
        if (g === -1 || g === void 0 || g === A)
          return { type: 0, value: t += this.consumeStringSlice(e) };
        if (g === 10)
          return this._value.splice(0, e), B;
        g !== 92 || (a = this._value[e + 1]) !== -1 && a !== void 0 && (a === 10 ? (t += this.consumeStringSlice(e), e = -1, this._value.shift()) : rr(g, a) && (t += this.consumeStringSlice(e), t += YA(this.consumeEscapedCodePoint()), e = -1)), e++;
      }
    }, j.prototype.consumeNumber = function() {
      var A = [], t = 4;
      for ((e = this.peekCodePoint(0)) !== 43 && e !== 45 || A.push(this.consumeCodePoint()); Vt(this.peekCodePoint(0)); )
        A.push(this.consumeCodePoint());
      var e = this.peekCodePoint(0), a = this.peekCodePoint(1);
      if (e === 46 && Vt(a))
        for (A.push(this.consumeCodePoint(), this.consumeCodePoint()), t = 8; Vt(this.peekCodePoint(0)); )
          A.push(this.consumeCodePoint());
      e = this.peekCodePoint(0);
      var a = this.peekCodePoint(1), g = this.peekCodePoint(2);
      if ((e === 69 || e === 101) && ((a === 43 || a === 45) && Vt(g) || Vt(a)))
        for (A.push(this.consumeCodePoint(), this.consumeCodePoint()), t = 8; Vt(this.peekCodePoint(0)); )
          A.push(this.consumeCodePoint());
      return [function(v) {
        var x = 0, q = 1;
        v[x] !== 43 && v[x] !== 45 || (v[x] === 45 && (q = -1), x++);
        for (var T = []; Vt(v[x]); )
          T.push(v[x++]);
        var lA = T.length ? parseInt(YA.apply(void 0, T), 10) : 0;
        v[x] === 46 && x++;
        for (var cA = []; Vt(v[x]); )
          cA.push(v[x++]);
        var BA = cA.length, mA = BA ? parseInt(YA.apply(void 0, cA), 10) : 0;
        v[x] !== 69 && v[x] !== 101 || x++;
        var FA = 1;
        v[x] !== 43 && v[x] !== 45 || (v[x] === 45 && (FA = -1), x++);
        for (var MA = []; Vt(v[x]); )
          MA.push(v[x++]);
        var DA = MA.length ? parseInt(YA.apply(void 0, MA), 10) : 0;
        return q * (lA + mA * Math.pow(10, -BA)) * Math.pow(10, FA * DA);
      }(A), t];
    }, j.prototype.consumeNumericToken = function() {
      var g = this.consumeNumber(), A = g[0], t = g[1], e = this.peekCodePoint(0), a = this.peekCodePoint(1), g = this.peekCodePoint(2);
      return Cr(e, a, g) ? { type: 15, number: A, flags: t, unit: this.consumeName() } : e === 37 ? (this.consumeCodePoint(), { type: 16, number: A, flags: t }) : { type: 17, number: A, flags: t };
    }, j.prototype.consumeEscapedCodePoint = function() {
      var A, t = this.consumeCodePoint();
      if (tr(t)) {
        for (var e = YA(t); tr(this.peekCodePoint(0)) && e.length < 6; )
          e += YA(this.consumeCodePoint());
        br(this.peekCodePoint(0)) && this.consumeCodePoint();
        var a = parseInt(e, 16);
        return a === 0 || 55296 <= (A = a) && A <= 57343 || 1114111 < a ? 65533 : a;
      }
      return t === -1 ? 65533 : t;
    }, j.prototype.consumeName = function() {
      for (var A = ""; ; ) {
        var t = this.consumeCodePoint();
        if (tn(t))
          A += YA(t);
        else {
          if (!rr(t, this.peekCodePoint(0)))
            return this.reconsumeCodePoint(t), A;
          A += YA(this.consumeEscapedCodePoint());
        }
      }
    }, j);
    function j() {
      this._value = [];
    }
    var Z = (W.create = function(A) {
      var t = new N();
      return t.write(A), new W(t.read());
    }, W.parseValue = function(A) {
      return W.create(A).parseComponentValue();
    }, W.parseValues = function(A) {
      return W.create(A).parseComponentValues();
    }, W.prototype.parseComponentValue = function() {
      for (var A = this.consumeToken(); A.type === 31; )
        A = this.consumeToken();
      if (A.type === 32)
        throw new SyntaxError("Error parsing CSS component value, unexpected EOF");
      this.reconsumeToken(A);
      for (var t = this.consumeComponentValue(); (A = this.consumeToken()).type === 31; )
        ;
      if (A.type === 32)
        return t;
      throw new SyntaxError("Error parsing CSS component value, multiple values found when expecting only one");
    }, W.prototype.parseComponentValues = function() {
      for (var A = []; ; ) {
        var t = this.consumeComponentValue();
        if (t.type === 32)
          return A;
        A.push(t), A.push();
      }
    }, W.prototype.consumeComponentValue = function() {
      var A = this.consumeToken();
      switch (A.type) {
        case 11:
        case 28:
        case 2:
          return this.consumeSimpleBlock(A.type);
        case 19:
          return this.consumeFunction(A);
      }
      return A;
    }, W.prototype.consumeSimpleBlock = function(A) {
      for (var t = { type: A, values: [] }, e = this.consumeToken(); ; ) {
        if (e.type === 32 || nA(e, A))
          return t;
        this.reconsumeToken(e), t.values.push(this.consumeComponentValue()), e = this.consumeToken();
      }
    }, W.prototype.consumeFunction = function(A) {
      for (var t = { name: A.value, values: [], type: 18 }; ; ) {
        var e = this.consumeToken();
        if (e.type === 32 || e.type === 3)
          return t;
        this.reconsumeToken(e), t.values.push(this.consumeComponentValue());
      }
    }, W.prototype.consumeToken = function() {
      var A = this._tokens.shift();
      return A === void 0 ? L : A;
    }, W.prototype.reconsumeToken = function(A) {
      this._tokens.unshift(A);
    }, W);
    function W(A) {
      this._tokens = A;
    }
    function V(A) {
      return A.type === 15;
    }
    function y(A) {
      return A.type === 17;
    }
    function P(A) {
      return A.type === 20;
    }
    function _(A) {
      return A.type === 0;
    }
    function Y(A, t) {
      return P(A) && A.value === t;
    }
    function $(A) {
      return A.type !== 31;
    }
    function hA(A) {
      return A.type !== 31 && A.type !== 4;
    }
    function z(A) {
      var t = [], e = [];
      return A.forEach(function(a) {
        if (a.type === 4) {
          if (e.length === 0)
            throw new Error("Error parsing function args, zero tokens for arg");
          return t.push(e), void (e = []);
        }
        a.type !== 31 && e.push(a);
      }), e.length && t.push(e), t;
    }
    function k(A) {
      return A.type === 17 || A.type === 15;
    }
    function F(A) {
      return A.type === 16 || k(A);
    }
    function R(A) {
      return 1 < A.length ? [A[0], A[1]] : [A[0]];
    }
    function E(g, t, e) {
      var a = g[0], g = g[1];
      return [Q(a, t), Q(g !== void 0 ? g : a, e)];
    }
    function G(A) {
      return A.type === 15 && (A.unit === "deg" || A.unit === "grad" || A.unit === "rad" || A.unit === "turn");
    }
    function M(A) {
      switch (A.filter(P).map(function(t) {
        return t.value;
      }).join(" ")) {
        case "to bottom right":
        case "to right bottom":
        case "left top":
        case "top left":
          return [b, b];
        case "to top":
        case "bottom":
          return O(0);
        case "to bottom left":
        case "to left bottom":
        case "right top":
        case "top right":
          return [b, u];
        case "to right":
        case "left":
          return O(90);
        case "to top left":
        case "to left top":
        case "right bottom":
        case "bottom right":
          return [u, u];
        case "to bottom":
        case "top":
          return O(180);
        case "to top right":
        case "to right top":
        case "left bottom":
        case "bottom left":
          return [u, b];
        case "to left":
        case "right":
          return O(270);
      }
      return 0;
    }
    function oA(A) {
      return (255 & A) == 0;
    }
    function X(g) {
      var t = 255 & g, e = 255 & g >> 8, a = 255 & g >> 16, g = 255 & g >> 24;
      return t < 255 ? "rgba(" + g + "," + a + "," + e + "," + t / 255 + ")" : "rgb(" + g + "," + a + "," + e + ")";
    }
    function fA(A, t) {
      if (A.type === 17)
        return A.number;
      if (A.type !== 16)
        return 0;
      var e = t === 3 ? 1 : 255;
      return t === 3 ? A.number / 100 * e : Math.round(A.number / 100 * e);
    }
    var nA = function(A, t) {
      return t === 11 && A.type === 12 || t === 28 && A.type === 29 || t === 2 && A.type === 3;
    }, b = { type: 17, number: 0, flags: 4 }, D = { type: 16, number: 50, flags: 4 }, u = { type: 16, number: 100, flags: 4 }, Q = function(A, t) {
      if (A.type === 16)
        return A.number / 100 * t;
      if (V(A))
        switch (A.unit) {
          case "rem":
          case "em":
            return 16 * A.number;
          default:
            return A.number;
        }
      return A.number;
    }, H = function(A, t) {
      if (t.type === 15)
        switch (t.unit) {
          case "deg":
            return Math.PI * t.number / 180;
          case "grad":
            return Math.PI / 200 * t.number;
          case "rad":
            return t.number;
          case "turn":
            return 2 * Math.PI * t.number;
        }
      throw new Error("Unsupported angle type");
    }, O = function(A) {
      return Math.PI * A / 180;
    }, eA = function(A, t) {
      if (t.type === 18) {
        var e = yt[t.name];
        if (e === void 0)
          throw new Error('Attempting to parse an unsupported color function "' + t.name + '"');
        return e(A, t.values);
      }
      if (t.type === 5) {
        if (t.value.length === 3) {
          var a = t.value.substring(0, 1), g = t.value.substring(1, 2), v = t.value.substring(2, 3);
          return sA(parseInt(a + a, 16), parseInt(g + g, 16), parseInt(v + v, 16), 1);
        }
        if (t.value.length === 4) {
          var a = t.value.substring(0, 1), g = t.value.substring(1, 2), v = t.value.substring(2, 3), x = t.value.substring(3, 4);
          return sA(parseInt(a + a, 16), parseInt(g + g, 16), parseInt(v + v, 16), parseInt(x + x, 16) / 255);
        }
        if (t.value.length === 6)
          return a = t.value.substring(0, 2), g = t.value.substring(2, 4), v = t.value.substring(4, 6), sA(parseInt(a, 16), parseInt(g, 16), parseInt(v, 16), 1);
        if (t.value.length === 8)
          return a = t.value.substring(0, 2), g = t.value.substring(2, 4), v = t.value.substring(4, 6), x = t.value.substring(6, 8), sA(parseInt(a, 16), parseInt(g, 16), parseInt(v, 16), parseInt(x, 16) / 255);
      }
      return t.type === 20 && (t = $A[t.value.toUpperCase()], t !== void 0) ? t : $A.TRANSPARENT;
    }, sA = function(A, t, e, a) {
      return (A << 24 | t << 16 | e << 8 | Math.round(255 * a) << 0) >>> 0;
    }, qA = function(A, t) {
      if (t = t.filter(hA), t.length === 3) {
        var g = t.map(fA), e = g[0], a = g[1], g = g[2];
        return sA(e, a, g, 1);
      }
      return t.length !== 4 ? 0 : (t = t.map(fA), e = t[0], a = t[1], g = t[2], t = t[3], sA(e, a, g, t));
    };
    function pA(A, t, e) {
      return e < 0 && (e += 1), 1 <= e && --e, e < 1 / 6 ? (t - A) * e * 6 + A : e < 0.5 ? t : e < 2 / 3 ? 6 * (t - A) * (2 / 3 - e) + A : A;
    }
    function yA(A, t) {
      return eA(A, Z.create(t).parseComponentValue());
    }
    function wA(A, t) {
      return A = eA(A, t[0]), (t = t[1]) && F(t) ? { color: A, stop: t } : { color: A, stop: null };
    }
    function SA(A, t) {
      var e = A[0], a = A[A.length - 1];
      e.stop === null && (e.stop = b), a.stop === null && (a.stop = u);
      for (var g = [], v = 0, x = 0; x < A.length; x++) {
        var q = A[x].stop;
        q !== null ? (v < (q = Q(q, t)) ? g.push(q) : g.push(v), v = q) : g.push(null);
      }
      for (var T = null, x = 0; x < g.length; x++) {
        var lA = g[x];
        if (lA === null)
          T === null && (T = x);
        else if (T !== null) {
          for (var cA = x - T, BA = (lA - g[T - 1]) / (1 + cA), mA = 1; mA <= cA; mA++)
            g[T + mA - 1] = BA * mA;
          T = null;
        }
      }
      return A.map(function(FA, MA) {
        return { color: FA.color, stop: Math.max(Math.min(1, g[MA] / t), 0) };
      });
    }
    function xA(A, T, q) {
      var a = typeof A == "number" ? A : (x = T / 2, a = (v = q) / 2, x = Q((g = A)[0], T) - x, v = a - Q(g[1], v), (Math.atan2(v, x) + 2 * Math.PI) % (2 * Math.PI)), g = Math.abs(T * Math.sin(a)) + Math.abs(q * Math.cos(a)), v = T / 2, x = q / 2, T = g / 2, q = Math.sin(a - Math.PI / 2) * T, T = Math.cos(a - Math.PI / 2) * T;
      return [g, v - T, v + T, x - q, x + q];
    }
    function KA(A, t) {
      return Math.sqrt(A * A + t * t);
    }
    function iA(A, t, e, a, g) {
      return [[0, 0], [0, t], [A, 0], [A, t]].reduce(function(v, x) {
        var q = x[0], T = x[1], T = KA(e - q, a - T);
        return (g ? T < v.optimumDistance : T > v.optimumDistance) ? { optimumCorner: x, optimumDistance: T } : v;
      }, { optimumDistance: g ? 1 / 0 : -1 / 0, optimumCorner: null }).optimumCorner;
    }
    var jA = function(v, a) {
      var g = a.filter(hA), x = g[0], q = g[1], e = g[2], a = g[3], g = (x.type === 17 ? O(x.number) : H(v, x)) / (2 * Math.PI), v = F(q) ? q.number / 100 : 0, x = F(e) ? e.number / 100 : 0, q = a !== void 0 && F(a) ? Q(a, 1) : 1;
      return v == 0 ? sA(255 * x, 255 * x, 255 * x, 1) : (e = x <= 0.5 ? x * (1 + v) : x + v - x * v, a = 2 * x - e, v = pA(a, e, g + 1 / 3), x = pA(a, e, g), g = pA(a, e, g - 1 / 3), sA(255 * v, 255 * x, 255 * g, q));
    }, yt = { hsl: jA, hsla: jA, rgb: qA, rgba: qA }, $A = { ALICEBLUE: 4042850303, ANTIQUEWHITE: 4209760255, AQUA: 16777215, AQUAMARINE: 2147472639, AZURE: 4043309055, BEIGE: 4126530815, BISQUE: 4293182719, BLACK: 255, BLANCHEDALMOND: 4293643775, BLUE: 65535, BLUEVIOLET: 2318131967, BROWN: 2771004159, BURLYWOOD: 3736635391, CADETBLUE: 1604231423, CHARTREUSE: 2147418367, CHOCOLATE: 3530104575, CORAL: 4286533887, CORNFLOWERBLUE: 1687547391, CORNSILK: 4294499583, CRIMSON: 3692313855, CYAN: 16777215, DARKBLUE: 35839, DARKCYAN: 9145343, DARKGOLDENROD: 3095837695, DARKGRAY: 2846468607, DARKGREEN: 6553855, DARKGREY: 2846468607, DARKKHAKI: 3182914559, DARKMAGENTA: 2332068863, DARKOLIVEGREEN: 1433087999, DARKORANGE: 4287365375, DARKORCHID: 2570243327, DARKRED: 2332033279, DARKSALMON: 3918953215, DARKSEAGREEN: 2411499519, DARKSLATEBLUE: 1211993087, DARKSLATEGRAY: 793726975, DARKSLATEGREY: 793726975, DARKTURQUOISE: 13554175, DARKVIOLET: 2483082239, DEEPPINK: 4279538687, DEEPSKYBLUE: 12582911, DIMGRAY: 1768516095, DIMGREY: 1768516095, DODGERBLUE: 512819199, FIREBRICK: 2988581631, FLORALWHITE: 4294635775, FORESTGREEN: 579543807, FUCHSIA: 4278255615, GAINSBORO: 3705462015, GHOSTWHITE: 4177068031, GOLD: 4292280575, GOLDENROD: 3668254975, GRAY: 2155905279, GREEN: 8388863, GREENYELLOW: 2919182335, GREY: 2155905279, HONEYDEW: 4043305215, HOTPINK: 4285117695, INDIANRED: 3445382399, INDIGO: 1258324735, IVORY: 4294963455, KHAKI: 4041641215, LAVENDER: 3873897215, LAVENDERBLUSH: 4293981695, LAWNGREEN: 2096890111, LEMONCHIFFON: 4294626815, LIGHTBLUE: 2916673279, LIGHTCORAL: 4034953471, LIGHTCYAN: 3774873599, LIGHTGOLDENRODYELLOW: 4210742015, LIGHTGRAY: 3553874943, LIGHTGREEN: 2431553791, LIGHTGREY: 3553874943, LIGHTPINK: 4290167295, LIGHTSALMON: 4288707327, LIGHTSEAGREEN: 548580095, LIGHTSKYBLUE: 2278488831, LIGHTSLATEGRAY: 2005441023, LIGHTSLATEGREY: 2005441023, LIGHTSTEELBLUE: 2965692159, LIGHTYELLOW: 4294959359, LIME: 16711935, LIMEGREEN: 852308735, LINEN: 4210091775, MAGENTA: 4278255615, MAROON: 2147483903, MEDIUMAQUAMARINE: 1724754687, MEDIUMBLUE: 52735, MEDIUMORCHID: 3126187007, MEDIUMPURPLE: 2473647103, MEDIUMSEAGREEN: 1018393087, MEDIUMSLATEBLUE: 2070474495, MEDIUMSPRINGGREEN: 16423679, MEDIUMTURQUOISE: 1221709055, MEDIUMVIOLETRED: 3340076543, MIDNIGHTBLUE: 421097727, MINTCREAM: 4127193855, MISTYROSE: 4293190143, MOCCASIN: 4293178879, NAVAJOWHITE: 4292783615, NAVY: 33023, OLDLACE: 4260751103, OLIVE: 2155872511, OLIVEDRAB: 1804477439, ORANGE: 4289003775, ORANGERED: 4282712319, ORCHID: 3664828159, PALEGOLDENROD: 4008225535, PALEGREEN: 2566625535, PALETURQUOISE: 2951671551, PALEVIOLETRED: 3681588223, PAPAYAWHIP: 4293907967, PEACHPUFF: 4292524543, PERU: 3448061951, PINK: 4290825215, PLUM: 3718307327, POWDERBLUE: 2967529215, PURPLE: 2147516671, REBECCAPURPLE: 1714657791, RED: 4278190335, ROSYBROWN: 3163525119, ROYALBLUE: 1097458175, SADDLEBROWN: 2336560127, SALMON: 4202722047, SANDYBROWN: 4104413439, SEAGREEN: 780883967, SEASHELL: 4294307583, SIENNA: 2689740287, SILVER: 3233857791, SKYBLUE: 2278484991, SLATEBLUE: 1784335871, SLATEGRAY: 1887473919, SLATEGREY: 1887473919, SNOW: 4294638335, SPRINGGREEN: 16744447, STEELBLUE: 1182971135, TAN: 3535047935, TEAL: 8421631, THISTLE: 3636451583, TOMATO: 4284696575, TRANSPARENT: 0, TURQUOISE: 1088475391, VIOLET: 4001558271, WHEAT: 4125012991, WHITE: 4294967295, WHITESMOKE: 4126537215, YELLOW: 4294902015, YELLOWGREEN: 2597139199 }, st = { name: "background-clip", initialValue: "border-box", prefix: !1, type: 1, parse: function(A, t) {
      return t.map(function(e) {
        if (P(e))
          switch (e.value) {
            case "padding-box":
              return 1;
            case "content-box":
              return 2;
          }
        return 0;
      });
    } }, kt = { name: "background-color", initialValue: "transparent", prefix: !1, type: 3, format: "color" }, jA = function(A, t) {
      var e = O(180), a = [];
      return z(t).forEach(function(g, v) {
        if (v === 0) {
          if (v = g[0], v.type === 20 && ["top", "left", "right", "bottom"].indexOf(v.value) !== -1)
            return void (e = M(g));
          if (G(v))
            return void (e = (H(A, v) + O(270)) % O(360));
        }
        g = wA(A, g), a.push(g);
      }), { angle: e, stops: a, type: 1 };
    }, gt = "closest-side", bt = "farthest-side", ht = "closest-corner", ct = "farthest-corner", xt = "ellipse", Pt = "contain", qA = function(A, t) {
      var e = 0, a = 3, g = [], v = [];
      return z(t).forEach(function(x, q) {
        var T = !0;
        q === 0 ? T = x.reduce(function(lA, cA) {
          if (P(cA))
            switch (cA.value) {
              case "center":
                return v.push(D), !1;
              case "top":
              case "left":
                return v.push(b), !1;
              case "right":
              case "bottom":
                return v.push(u), !1;
            }
          else if (F(cA) || k(cA))
            return v.push(cA), !1;
          return lA;
        }, T) : q === 1 && (T = x.reduce(function(lA, cA) {
          if (P(cA))
            switch (cA.value) {
              case "circle":
                return e = 0, !1;
              case xt:
                return !(e = 1);
              case Pt:
              case gt:
                return a = 0, !1;
              case bt:
                return !(a = 1);
              case ht:
                return !(a = 2);
              case "cover":
              case ct:
                return !(a = 3);
            }
          else if (k(cA) || F(cA))
            return (a = Array.isArray(a) ? a : []).push(cA), !1;
          return lA;
        }, T)), T && (x = wA(A, x), g.push(x));
      }), { size: a, shape: e, stops: g, position: v, type: 2 };
    }, JA = function(A, t) {
      if (t.type === 22) {
        var e = { url: t.value, type: 0 };
        return A.cache.addImage(t.value), e;
      }
      if (t.type !== 18)
        throw new Error("Unsupported image type " + t.type);
      if (e = oe[t.name], e === void 0)
        throw new Error('Attempting to parse an unsupported image function "' + t.name + '"');
      return e(A, t.values);
    }, ee, oe = { "linear-gradient": function(A, t) {
      var e = O(180), a = [];
      return z(t).forEach(function(g, v) {
        if (v === 0) {
          if (v = g[0], v.type === 20 && v.value === "to")
            return void (e = M(g));
          if (G(v))
            return void (e = H(A, v));
        }
        g = wA(A, g), a.push(g);
      }), { angle: e, stops: a, type: 1 };
    }, "-moz-linear-gradient": jA, "-ms-linear-gradient": jA, "-o-linear-gradient": jA, "-webkit-linear-gradient": jA, "radial-gradient": function(A, t) {
      var e = 0, a = 3, g = [], v = [];
      return z(t).forEach(function(x, q) {
        var T, lA = !0;
        q === 0 && (T = !1, lA = x.reduce(function(cA, BA) {
          if (T)
            if (P(BA))
              switch (BA.value) {
                case "center":
                  return v.push(D), cA;
                case "top":
                case "left":
                  return v.push(b), cA;
                case "right":
                case "bottom":
                  return v.push(u), cA;
              }
            else
              (F(BA) || k(BA)) && v.push(BA);
          else if (P(BA))
            switch (BA.value) {
              case "circle":
                return e = 0, !1;
              case xt:
                return !(e = 1);
              case "at":
                return !(T = !0);
              case gt:
                return a = 0, !1;
              case "cover":
              case bt:
                return !(a = 1);
              case Pt:
              case ht:
                return !(a = 2);
              case ct:
                return !(a = 3);
            }
          else if (k(BA) || F(BA))
            return (a = Array.isArray(a) ? a : []).push(BA), !1;
          return cA;
        }, lA)), lA && (x = wA(A, x), g.push(x));
      }), { size: a, shape: e, stops: g, position: v, type: 2 };
    }, "-moz-radial-gradient": qA, "-ms-radial-gradient": qA, "-o-radial-gradient": qA, "-webkit-radial-gradient": qA, "-webkit-gradient": function(A, t) {
      var e = O(180), a = [], g = 1;
      return z(t).forEach(function(T, x) {
        var q, T = T[0];
        if (x === 0) {
          if (P(T) && T.value === "linear")
            return void (g = 1);
          if (P(T) && T.value === "radial")
            return void (g = 2);
        }
        T.type === 18 && (T.name === "from" ? (q = eA(A, T.values[0]), a.push({ stop: b, color: q })) : T.name === "to" ? (q = eA(A, T.values[0]), a.push({ stop: u, color: q })) : T.name !== "color-stop" || (T = T.values.filter(hA)).length === 2 && (q = eA(A, T[1]), T = T[0], y(T) && a.push({ stop: { type: 16, number: 100 * T.number, flags: T.flags }, color: q })));
      }), g === 1 ? { angle: (e + O(180)) % O(360), stops: a, type: g } : { size: 3, shape: 0, stops: a, position: [], type: g };
    } }, be = { name: "background-image", initialValue: "none", type: 1, prefix: !1, parse: function(A, t) {
      if (t.length === 0)
        return [];
      var e = t[0];
      return e.type === 20 && e.value === "none" ? [] : t.filter(function(a) {
        return hA(a) && !((a = a).type === 20 && a.value === "none" || a.type === 18 && !oe[a.name]);
      }).map(function(a) {
        return JA(A, a);
      });
    } }, Ke = { name: "background-origin", initialValue: "border-box", prefix: !1, type: 1, parse: function(A, t) {
      return t.map(function(e) {
        if (P(e))
          switch (e.value) {
            case "padding-box":
              return 1;
            case "content-box":
              return 2;
          }
        return 0;
      });
    } }, Yt = { name: "background-position", initialValue: "0% 0%", type: 1, prefix: !1, parse: function(A, t) {
      return z(t).map(function(e) {
        return e.filter(F);
      }).map(R);
    } }, K = { name: "background-repeat", initialValue: "repeat", prefix: !1, type: 1, parse: function(A, t) {
      return z(t).map(function(e) {
        return e.filter(P).map(function(a) {
          return a.value;
        }).join(" ");
      }).map(aA);
    } }, aA = function(A) {
      switch (A) {
        case "no-repeat":
          return 1;
        case "repeat-x":
        case "repeat no-repeat":
          return 2;
        case "repeat-y":
        case "no-repeat repeat":
          return 3;
        default:
          return 0;
      }
    };
    (qA = ee = ee || {}).AUTO = "auto", qA.CONTAIN = "contain";
    function gA(A, t) {
      return P(A) && A.value === "normal" ? 1.2 * t : A.type === 17 ? t * A.number : F(A) ? Q(A, t) : t;
    }
    var tA, AA, dA = { name: "background-size", initialValue: "0", prefix: !(qA.COVER = "cover"), type: 1, parse: function(A, t) {
      return z(t).map(function(e) {
        return e.filter(QA);
      });
    } }, QA = function(A) {
      return P(A) || F(A);
    }, qA = function(A) {
      return { name: "border-" + A + "-color", initialValue: "transparent", prefix: !1, type: 3, format: "color" };
    }, bA = qA("top"), EA = qA("right"), _A = qA("bottom"), et = qA("left"), qA = function(A) {
      return { name: "border-radius-" + A, initialValue: "0 0", prefix: !1, type: 1, parse: function(t, e) {
        return R(e.filter(F));
      } };
    }, VA = qA("top-left"), it = qA("top-right"), mt = qA("bottom-right"), qt = qA("bottom-left"), qA = function(A) {
      return { name: "border-" + A + "-style", initialValue: "solid", prefix: !1, type: 2, parse: function(t, e) {
        switch (e) {
          case "none":
            return 0;
          case "dashed":
            return 2;
          case "dotted":
            return 3;
          case "double":
            return 4;
        }
        return 1;
      } };
    }, se = qA("top"), ae = qA("right"), xr = qA("bottom"), Mt = qA("left"), qA = function(A) {
      return { name: "border-" + A + "-width", initialValue: "0", type: 0, prefix: !1, parse: function(t, e) {
        return V(e) ? e.number : 0;
      } };
    }, ce = qA("top"), Ir = qA("right"), qe = qA("bottom"), Xt = qA("left"), ur = { name: "color", initialValue: "transparent", prefix: !1, type: 3, format: "color" }, yr = { name: "direction", initialValue: "ltr", prefix: !1, type: 2, parse: function(A, t) {
      return t !== "rtl" ? 0 : 1;
    } }, Qr = { name: "display", initialValue: "inline-block", prefix: !1, type: 1, parse: function(A, t) {
      return t.filter(P).reduce(function(e, a) {
        return e | hr(a.value);
      }, 0);
    } }, hr = function(A) {
      switch (A) {
        case "block":
        case "-webkit-box":
          return 2;
        case "inline":
          return 4;
        case "run-in":
          return 8;
        case "flow":
          return 16;
        case "flow-root":
          return 32;
        case "table":
          return 64;
        case "flex":
        case "-webkit-flex":
          return 128;
        case "grid":
        case "-ms-grid":
          return 256;
        case "ruby":
          return 512;
        case "subgrid":
          return 1024;
        case "list-item":
          return 2048;
        case "table-row-group":
          return 4096;
        case "table-header-group":
          return 8192;
        case "table-footer-group":
          return 16384;
        case "table-row":
          return 32768;
        case "table-cell":
          return 65536;
        case "table-column-group":
          return 131072;
        case "table-column":
          return 262144;
        case "table-caption":
          return 524288;
        case "ruby-base":
          return 1048576;
        case "ruby-text":
          return 2097152;
        case "ruby-base-container":
          return 4194304;
        case "ruby-text-container":
          return 8388608;
        case "contents":
          return 16777216;
        case "inline-block":
          return 33554432;
        case "inline-list-item":
          return 67108864;
        case "inline-table":
          return 134217728;
        case "inline-flex":
          return 268435456;
        case "inline-grid":
          return 536870912;
      }
      return 0;
    }, le = { name: "float", initialValue: "none", prefix: !1, type: 2, parse: function(A, t) {
      switch (t) {
        case "left":
          return 1;
        case "right":
          return 2;
        case "inline-start":
          return 3;
        case "inline-end":
          return 4;
      }
      return 0;
    } }, _r = { name: "letter-spacing", initialValue: "0", prefix: !1, type: 0, parse: function(A, t) {
      return t.type === 20 && t.value === "normal" || t.type !== 17 && t.type !== 15 ? 0 : t.number;
    } }, Er = { name: "line-break", initialValue: (qA = tA = tA || {}).NORMAL = "normal", prefix: !(qA.STRICT = "strict"), type: 2, parse: function(A, t) {
      return t !== "strict" ? tA.NORMAL : tA.STRICT;
    } }, Or = { name: "line-height", initialValue: "normal", prefix: !1, type: 4 }, fr = { name: "list-style-image", initialValue: "none", type: 0, prefix: !1, parse: function(A, t) {
      return t.type === 20 && t.value === "none" ? null : JA(A, t);
    } }, nr = { name: "list-style-position", initialValue: "outside", prefix: !1, type: 2, parse: function(A, t) {
      return t !== "inside" ? 1 : 0;
    } }, en = { name: "list-style-type", initialValue: "none", prefix: !1, type: 2, parse: function(A, t) {
      switch (t) {
        case "disc":
          return 0;
        case "circle":
          return 1;
        case "square":
          return 2;
        case "decimal":
          return 3;
        case "cjk-decimal":
          return 4;
        case "decimal-leading-zero":
          return 5;
        case "lower-roman":
          return 6;
        case "upper-roman":
          return 7;
        case "lower-greek":
          return 8;
        case "lower-alpha":
          return 9;
        case "upper-alpha":
          return 10;
        case "arabic-indic":
          return 11;
        case "armenian":
          return 12;
        case "bengali":
          return 13;
        case "cambodian":
          return 14;
        case "cjk-earthly-branch":
          return 15;
        case "cjk-heavenly-stem":
          return 16;
        case "cjk-ideographic":
          return 17;
        case "devanagari":
          return 18;
        case "ethiopic-numeric":
          return 19;
        case "georgian":
          return 20;
        case "gujarati":
          return 21;
        case "gurmukhi":
        case "hebrew":
          return 22;
        case "hiragana":
          return 23;
        case "hiragana-iroha":
          return 24;
        case "japanese-formal":
          return 25;
        case "japanese-informal":
          return 26;
        case "kannada":
          return 27;
        case "katakana":
          return 28;
        case "katakana-iroha":
          return 29;
        case "khmer":
          return 30;
        case "korean-hangul-formal":
          return 31;
        case "korean-hanja-formal":
          return 32;
        case "korean-hanja-informal":
          return 33;
        case "lao":
          return 34;
        case "lower-armenian":
          return 35;
        case "malayalam":
          return 36;
        case "mongolian":
          return 37;
        case "myanmar":
          return 38;
        case "oriya":
          return 39;
        case "persian":
          return 40;
        case "simp-chinese-formal":
          return 41;
        case "simp-chinese-informal":
          return 42;
        case "tamil":
          return 43;
        case "telugu":
          return 44;
        case "thai":
          return 45;
        case "tibetan":
          return 46;
        case "trad-chinese-formal":
          return 47;
        case "trad-chinese-informal":
          return 48;
        case "upper-armenian":
          return 49;
        case "disclosure-open":
          return 50;
        case "disclosure-closed":
          return 51;
        default:
          return -1;
      }
    } }, qA = function(A) {
      return { name: "margin-" + A, initialValue: "0", prefix: !1, type: 4 };
    }, Vn = qA("top"), rn = qA("right"), dr = qA("bottom"), Pr = qA("left"), je = { name: "overflow", initialValue: "visible", prefix: !1, type: 1, parse: function(A, t) {
      return t.filter(P).map(function(e) {
        switch (e.value) {
          case "hidden":
            return 1;
          case "scroll":
            return 2;
          case "clip":
            return 3;
          case "auto":
            return 4;
          default:
            return 0;
        }
      });
    } }, xe = { name: "overflow-wrap", initialValue: "normal", prefix: !1, type: 2, parse: function(A, t) {
      return t !== "break-word" ? "normal" : "break-word";
    } }, qA = function(A) {
      return { name: "padding-" + A, initialValue: "0", prefix: !1, type: 3, format: "length-percentage" };
    }, Xe = qA("top"), Cn = qA("right"), Mr = qA("bottom"), ot = qA("left"), Rr = { name: "text-align", initialValue: "left", prefix: !1, type: 2, parse: function(A, t) {
      switch (t) {
        case "right":
          return 2;
        case "center":
        case "justify":
          return 1;
        default:
          return 0;
      }
    } }, Nr = { name: "position", initialValue: "static", prefix: !1, type: 2, parse: function(A, t) {
      switch (t) {
        case "relative":
          return 1;
        case "absolute":
          return 2;
        case "fixed":
          return 3;
        case "sticky":
          return 4;
      }
      return 0;
    } }, Hr = { name: "text-shadow", initialValue: "none", type: 1, prefix: !1, parse: function(A, t) {
      return t.length === 1 && Y(t[0], "none") ? [] : z(t).map(function(e) {
        for (var a = { color: $A.TRANSPARENT, offsetX: b, offsetY: b, blur: b }, g = 0, v = 0; v < e.length; v++) {
          var x = e[v];
          k(x) ? (g === 0 ? a.offsetX = x : g === 1 ? a.offsetY = x : a.blur = x, g++) : a.color = eA(A, x);
        }
        return a;
      });
    } }, Gr = { name: "text-transform", initialValue: "none", prefix: !1, type: 2, parse: function(A, t) {
      switch (t) {
        case "uppercase":
          return 2;
        case "lowercase":
          return 1;
        case "capitalize":
          return 3;
      }
      return 0;
    } }, Sr = { name: "transform", initialValue: "none", prefix: !0, type: 0, parse: function(A, t) {
      if (t.type === 20 && t.value === "none" || t.type !== 18)
        return null;
      var e = nn[t.name];
      if (e === void 0)
        throw new Error('Attempting to parse an unsupported transform function "' + t.name + '"');
      return e(t.values);
    } }, nn = { matrix: function(A) {
      return A = A.filter(function(t) {
        return t.type === 17;
      }).map(function(t) {
        return t.number;
      }), A.length === 6 ? A : null;
    }, matrix3d: function(q) {
      var t = q.filter(function(T) {
        return T.type === 17;
      }).map(function(T) {
        return T.number;
      }), e = t[0], a = t[1];
      t[2], t[3];
      var g = t[4], v = t[5];
      t[6], t[7], t[8], t[9], t[10], t[11];
      var x = t[12], q = t[13];
      return t[14], t[15], t.length === 16 ? [e, a, g, v, x, q] : null;
    } }, qA = { type: 16, number: 50, flags: 4 }, ue = [qA, qA], he = { name: "transform-origin", initialValue: "50% 50%", prefix: !0, type: 1, parse: function(A, t) {
      return t = t.filter(F), t.length !== 2 ? ue : [t[0], t[1]];
    } }, _e = { name: "visible", initialValue: "none", prefix: !1, type: 2, parse: function(A, t) {
      switch (t) {
        case "hidden":
          return 1;
        case "collapse":
          return 2;
        default:
          return 0;
      }
    } };
    (qA = AA = AA || {}).NORMAL = "normal", qA.BREAK_ALL = "break-all";
    function wt(A, t) {
      return (A & t) != 0;
    }
    function gr(A, t, e) {
      return (A = A && A[Math.min(t, A.length - 1)]) ? e ? A.open : A.close : "";
    }
    var yn = { name: "word-break", initialValue: "normal", prefix: !(qA.KEEP_ALL = "keep-all"), type: 2, parse: function(A, t) {
      switch (t) {
        case "break-all":
          return AA.BREAK_ALL;
        case "keep-all":
          return AA.KEEP_ALL;
        default:
          return AA.NORMAL;
      }
    } }, on = { name: "z-index", initialValue: "auto", prefix: !1, type: 0, parse: function(A, t) {
      if (t.type === 20)
        return { auto: !0, order: 0 };
      if (y(t))
        return { auto: !1, order: t.number };
      throw new Error("Invalid z-index number parsed");
    } }, Qn = function(A, t) {
      if (t.type === 15)
        switch (t.unit.toLowerCase()) {
          case "s":
            return 1e3 * t.number;
          case "ms":
            return t.number;
        }
      throw new Error("Unsupported time type");
    }, Wo = { name: "opacity", initialValue: "1", type: 0, prefix: !1, parse: function(A, t) {
      return y(t) ? t.number : 1;
    } }, Jo = { name: "text-decoration-color", initialValue: "transparent", prefix: !1, type: 3, format: "color" }, zo = { name: "text-decoration-line", initialValue: "none", prefix: !1, type: 1, parse: function(A, t) {
      return t.filter(P).map(function(e) {
        switch (e.value) {
          case "underline":
            return 1;
          case "overline":
            return 2;
          case "line-through":
            return 3;
          case "none":
            return 4;
        }
        return 0;
      }).filter(function(e) {
        return e !== 0;
      });
    } }, Yo = { name: "font-family", initialValue: "", prefix: !1, type: 1, parse: function(A, t) {
      var e = [], a = [];
      return t.forEach(function(g) {
        switch (g.type) {
          case 20:
          case 0:
            e.push(g.value);
            break;
          case 17:
            e.push(g.number.toString());
            break;
          case 4:
            a.push(e.join(" ")), e.length = 0;
        }
      }), e.length && a.push(e.join(" ")), a.map(function(g) {
        return g.indexOf(" ") === -1 ? g : "'" + g + "'";
      });
    } }, Zo = { name: "font-size", initialValue: "0", prefix: !1, type: 3, format: "length" }, $o = { name: "font-weight", initialValue: "normal", type: 0, prefix: !1, parse: function(A, t) {
      return y(t) ? t.number : !P(t) || t.value !== "bold" ? 400 : 700;
    } }, As = { name: "font-variant", initialValue: "none", type: 1, prefix: !1, parse: function(A, t) {
      return t.filter(P).map(function(e) {
        return e.value;
      });
    } }, ts = { name: "font-style", initialValue: "normal", prefix: !1, type: 2, parse: function(A, t) {
      switch (t) {
        case "oblique":
          return "oblique";
        case "italic":
          return "italic";
        default:
          return "normal";
      }
    } }, es = { name: "content", initialValue: "none", type: 1, prefix: !1, parse: function(A, t) {
      if (t.length === 0)
        return [];
      var e = t[0];
      return e.type === 20 && e.value === "none" ? [] : t;
    } }, rs = { name: "counter-increment", initialValue: "none", prefix: !0, type: 1, parse: function(A, t) {
      if (t.length === 0)
        return null;
      var e = t[0];
      if (e.type === 20 && e.value === "none")
        return null;
      for (var a = [], g = t.filter($), v = 0; v < g.length; v++) {
        var x = g[v], q = g[v + 1];
        x.type === 20 && (q = q && y(q) ? q.number : 1, a.push({ counter: x.value, increment: q }));
      }
      return a;
    } }, ns = { name: "counter-reset", initialValue: "none", prefix: !0, type: 1, parse: function(A, t) {
      if (t.length === 0)
        return [];
      for (var e = [], a = t.filter($), g = 0; g < a.length; g++) {
        var v = a[g], x = a[g + 1];
        P(v) && v.value !== "none" && (x = x && y(x) ? x.number : 0, e.push({ counter: v.value, reset: x }));
      }
      return e;
    } }, is = { name: "duration", initialValue: "0s", prefix: !1, type: 1, parse: function(A, t) {
      return t.filter(V).map(function(e) {
        return Qn(A, e);
      });
    } }, os = { name: "quotes", initialValue: "none", prefix: !0, type: 1, parse: function(A, t) {
      if (t.length === 0)
        return null;
      var e = t[0];
      if (e.type === 20 && e.value === "none")
        return null;
      var a = [], g = t.filter(_);
      if (g.length % 2 != 0)
        return null;
      for (var v = 0; v < g.length; v += 2) {
        var x = g[v].value, q = g[v + 1].value;
        a.push({ open: x, close: q });
      }
      return a;
    } }, ss = { name: "box-shadow", initialValue: "none", type: 1, prefix: !1, parse: function(A, t) {
      return t.length === 1 && Y(t[0], "none") ? [] : z(t).map(function(e) {
        for (var a = { color: 255, offsetX: b, offsetY: b, blur: b, spread: b, inset: !1 }, g = 0, v = 0; v < e.length; v++) {
          var x = e[v];
          Y(x, "inset") ? a.inset = !0 : k(x) ? (g === 0 ? a.offsetX = x : g === 1 ? a.offsetY = x : g === 2 ? a.blur = x : a.spread = x, g++) : a.color = eA(A, x);
        }
        return a;
      });
    } }, as = { name: "paint-order", initialValue: "normal", prefix: !1, type: 1, parse: function(A, t) {
      var e = [];
      return t.filter(P).forEach(function(a) {
        switch (a.value) {
          case "stroke":
            e.push(1);
            break;
          case "fill":
            e.push(0);
            break;
          case "markers":
            e.push(2);
        }
      }), [0, 1, 2].forEach(function(a) {
        e.indexOf(a) === -1 && e.push(a);
      }), e;
    } }, cs = { name: "-webkit-text-stroke-color", initialValue: "currentcolor", prefix: !1, type: 3, format: "color" }, ls = { name: "-webkit-text-stroke-width", initialValue: "0", type: 0, prefix: !1, parse: function(A, t) {
      return V(t) ? t.number : 0;
    } }, us = (Fr.prototype.isVisible = function() {
      return 0 < this.display && 0 < this.opacity && this.visibility === 0;
    }, Fr.prototype.isTransparent = function() {
      return oA(this.backgroundColor);
    }, Fr.prototype.isTransformed = function() {
      return this.transform !== null;
    }, Fr.prototype.isPositioned = function() {
      return this.position !== 0;
    }, Fr.prototype.isPositionedWithZIndex = function() {
      return this.isPositioned() && !this.zIndex.auto;
    }, Fr.prototype.isFloating = function() {
      return this.float !== 0;
    }, Fr.prototype.isInlineLevel = function() {
      return wt(this.display, 4) || wt(this.display, 33554432) || wt(this.display, 268435456) || wt(this.display, 536870912) || wt(this.display, 67108864) || wt(this.display, 134217728);
    }, Fr);
    function Fr(A, t) {
      this.animationDuration = PA(A, is, t.animationDuration), this.backgroundClip = PA(A, st, t.backgroundClip), this.backgroundColor = PA(A, kt, t.backgroundColor), this.backgroundImage = PA(A, be, t.backgroundImage), this.backgroundOrigin = PA(A, Ke, t.backgroundOrigin), this.backgroundPosition = PA(A, Yt, t.backgroundPosition), this.backgroundRepeat = PA(A, K, t.backgroundRepeat), this.backgroundSize = PA(A, dA, t.backgroundSize), this.borderTopColor = PA(A, bA, t.borderTopColor), this.borderRightColor = PA(A, EA, t.borderRightColor), this.borderBottomColor = PA(A, _A, t.borderBottomColor), this.borderLeftColor = PA(A, et, t.borderLeftColor), this.borderTopLeftRadius = PA(A, VA, t.borderTopLeftRadius), this.borderTopRightRadius = PA(A, it, t.borderTopRightRadius), this.borderBottomRightRadius = PA(A, mt, t.borderBottomRightRadius), this.borderBottomLeftRadius = PA(A, qt, t.borderBottomLeftRadius), this.borderTopStyle = PA(A, se, t.borderTopStyle), this.borderRightStyle = PA(A, ae, t.borderRightStyle), this.borderBottomStyle = PA(A, xr, t.borderBottomStyle), this.borderLeftStyle = PA(A, Mt, t.borderLeftStyle), this.borderTopWidth = PA(A, ce, t.borderTopWidth), this.borderRightWidth = PA(A, Ir, t.borderRightWidth), this.borderBottomWidth = PA(A, qe, t.borderBottomWidth), this.borderLeftWidth = PA(A, Xt, t.borderLeftWidth), this.boxShadow = PA(A, ss, t.boxShadow), this.color = PA(A, ur, t.color), this.direction = PA(A, yr, t.direction), this.display = PA(A, Qr, t.display), this.float = PA(A, le, t.cssFloat), this.fontFamily = PA(A, Yo, t.fontFamily), this.fontSize = PA(A, Zo, t.fontSize), this.fontStyle = PA(A, ts, t.fontStyle), this.fontVariant = PA(A, As, t.fontVariant), this.fontWeight = PA(A, $o, t.fontWeight), this.letterSpacing = PA(A, _r, t.letterSpacing), this.lineBreak = PA(A, Er, t.lineBreak), this.lineHeight = PA(A, Or, t.lineHeight), this.listStyleImage = PA(A, fr, t.listStyleImage), this.listStylePosition = PA(A, nr, t.listStylePosition), this.listStyleType = PA(A, en, t.listStyleType), this.marginTop = PA(A, Vn, t.marginTop), this.marginRight = PA(A, rn, t.marginRight), this.marginBottom = PA(A, dr, t.marginBottom), this.marginLeft = PA(A, Pr, t.marginLeft), this.opacity = PA(A, Wo, t.opacity);
      var e = PA(A, je, t.overflow);
      this.overflowX = e[0], this.overflowY = e[1 < e.length ? 1 : 0], this.overflowWrap = PA(A, xe, t.overflowWrap), this.paddingTop = PA(A, Xe, t.paddingTop), this.paddingRight = PA(A, Cn, t.paddingRight), this.paddingBottom = PA(A, Mr, t.paddingBottom), this.paddingLeft = PA(A, ot, t.paddingLeft), this.paintOrder = PA(A, as, t.paintOrder), this.position = PA(A, Nr, t.position), this.textAlign = PA(A, Rr, t.textAlign), this.textDecorationColor = PA(A, Jo, (e = t.textDecorationColor) !== null && e !== void 0 ? e : t.color), this.textDecorationLine = PA(A, zo, (e = t.textDecorationLine) !== null && e !== void 0 ? e : t.textDecoration), this.textShadow = PA(A, Hr, t.textShadow), this.textTransform = PA(A, Gr, t.textTransform), this.transform = PA(A, Sr, t.transform), this.transformOrigin = PA(A, he, t.transformOrigin), this.visibility = PA(A, _e, t.visibility), this.webkitTextStrokeColor = PA(A, cs, t.webkitTextStrokeColor), this.webkitTextStrokeWidth = PA(A, ls, t.webkitTextStrokeWidth), this.wordBreak = PA(A, yn, t.wordBreak), this.zIndex = PA(A, on, t.zIndex);
    }
    for (var hs = function(A, t) {
      this.content = PA(A, es, t.content), this.quotes = PA(A, os, t.quotes);
    }, Ci = function(A, t) {
      this.counterIncrement = PA(A, rs, t.counterIncrement), this.counterReset = PA(A, ns, t.counterReset);
    }, PA = function(A, t, g) {
      var a = new N(), g = g != null ? g.toString() : t.initialValue;
      a.write(g);
      var v = new Z(a.read());
      switch (t.type) {
        case 2:
          var x = v.parseComponentValue();
          return t.parse(A, P(x) ? x.value : t.initialValue);
        case 0:
          return t.parse(A, v.parseComponentValue());
        case 1:
          return t.parse(A, v.parseComponentValues());
        case 4:
          return v.parseComponentValue();
        case 3:
          switch (t.format) {
            case "angle":
              return H(A, v.parseComponentValue());
            case "color":
              return eA(A, v.parseComponentValue());
            case "image":
              return JA(A, v.parseComponentValue());
            case "length":
              var q = v.parseComponentValue();
              return k(q) ? q : b;
            case "length-percentage":
              return q = v.parseComponentValue(), F(q) ? q : b;
            case "time":
              return Qn(A, v.parseComponentValue());
          }
      }
    }, qn = function(A, t) {
      return A = function(e) {
        switch (e.getAttribute("data-html2canvas-debug")) {
          case "all":
            return 1;
          case "clone":
            return 2;
          case "parse":
            return 3;
          case "render":
            return 4;
          default:
            return 0;
        }
      }(A), A === 1 || t === A;
    }, ir = function(A, t) {
      this.context = A, this.textNodes = [], this.elements = [], this.flags = 0, qn(t, 3), this.styles = new us(A, window.getComputedStyle(t, null)), Zn(t) && (this.styles.animationDuration.some(function(e) {
        return 0 < e;
      }) && (t.style.animationDuration = "0s"), this.styles.transform !== null && (t.style.transform = "none")), this.bounds = pt(this.context, t), qn(t, 4) && (this.flags |= 16);
    }, yi = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", sn = typeof Uint8Array > "u" ? [] : new Uint8Array(256), Fn = 0; Fn < yi.length; Fn++)
      sn[yi.charCodeAt(Fn)] = Fn;
    function Qi(A, t, e) {
      return A.slice ? A.slice(t, e) : new Uint16Array(Array.prototype.slice.call(A, t, e));
    }
    var fs = (Fi.prototype.get = function(A) {
      var t;
      if (0 <= A) {
        if (A < 55296 || 56319 < A && A <= 65535)
          return t = this.index[A >> 5], this.data[t = (t << 2) + (31 & A)];
        if (A <= 65535)
          return t = this.index[2048 + (A - 55296 >> 5)], this.data[t = (t << 2) + (31 & A)];
        if (A < this.highStart)
          return t = this.index[t = 2080 + (A >> 11)], t = this.index[t += A >> 5 & 63], this.data[t = (t << 2) + (31 & A)];
        if (A <= 1114111)
          return this.data[this.highValueIndex];
      }
      return this.errorValue;
    }, Fi);
    function Fi(A, t, e, a, g, v) {
      this.initialValue = A, this.errorValue = t, this.highStart = e, this.highValueIndex = a, this.index = g, this.data = v;
    }
    for (var Ui = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", ds = typeof Uint8Array > "u" ? [] : new Uint8Array(256), Un = 0; Un < Ui.length; Un++)
      ds[Ui.charCodeAt(Un)] = Un;
    function gs(A) {
      return Bs.get(A);
    }
    function ps(A) {
      var t = function(x) {
        for (var q = [], T = 0, lA = x.length; T < lA; ) {
          var cA, BA = x.charCodeAt(T++);
          55296 <= BA && BA <= 56319 && T < lA ? (64512 & (cA = x.charCodeAt(T++))) == 56320 ? q.push(((1023 & BA) << 10) + (1023 & cA) + 65536) : (q.push(BA), T--) : q.push(BA);
        }
        return q;
      }(A), e = t.length, a = 0, g = 0, v = t.map(gs);
      return { next: function() {
        if (e <= a)
          return { done: !0, value: null };
        for (var x = Oe; a < e && (x = function(T, FA) {
          var cA = FA - 2, BA = T[cA], mA = T[FA - 1], FA = T[FA];
          if (mA === 2 && FA === 3)
            return Oe;
          if (mA === 2 || mA === 3 || mA === 4 || FA === 2 || FA === 3 || FA === 4)
            return "÷";
          if (mA === xi && [xi, Xn, Ii, Ei].indexOf(FA) !== -1 || !(mA !== Ii && mA !== Xn || FA !== Xn && FA !== 10) || (mA === Ei || mA === 10) && FA === 10 || FA === 13 || FA === 5 || FA === 7 || mA === 1)
            return Oe;
          if (mA === 13 && FA === 14) {
            for (; BA === 5; )
              BA = T[--cA];
            if (BA === 14)
              return Oe;
          }
          if (mA === 15 && FA === 15) {
            for (var MA = 0; BA === 15; )
              MA++, BA = T[--cA];
            if (MA % 2 == 0)
              return Oe;
          }
          return "÷";
        }(v, ++a)) === Oe; )
          ;
        if (x === Oe && a !== e)
          return { done: !0, value: null };
        var q = (function() {
          for (var T = [], lA = 0; lA < arguments.length; lA++)
            T[lA] = arguments[lA];
          if (String.fromCodePoint)
            return String.fromCodePoint.apply(String, T);
          var cA = T.length;
          if (!cA)
            return "";
          for (var BA = [], mA = -1, FA = ""; ++mA < cA; ) {
            var MA = T[mA];
            MA <= 65535 ? BA.push(MA) : (MA -= 65536, BA.push(55296 + (MA >> 10), MA % 1024 + 56320)), (mA + 1 === cA || 16384 < BA.length) && (FA += String.fromCharCode.apply(String, BA), BA.length = 0);
          }
          return FA;
        }).apply(null, t.slice(g, a));
        return g = a, { value: q, done: !1 };
      } };
    }
    function vi(A) {
      return A[0] === 0 && A[1] === 255 && A[2] === 0 && A[3] === 255;
    }
    var jn, vn, We, or, Vr, bi, xi = 8, Xn = 9, Ii = 11, Ei = 12, Bs = (We = function(A) {
      var t, e, a, g, v = 0.75 * A.length, x = A.length, q = 0;
      A[A.length - 1] === "=" && (v--, A[A.length - 2] === "=" && v--);
      for (var v = new (typeof ArrayBuffer < "u" && typeof Uint8Array < "u" && Uint8Array.prototype.slice !== void 0 ? ArrayBuffer : Array)(v), T = Array.isArray(v) ? v : new Uint8Array(v), lA = 0; lA < x; lA += 4)
        t = sn[A.charCodeAt(lA)], e = sn[A.charCodeAt(lA + 1)], a = sn[A.charCodeAt(lA + 2)], g = sn[A.charCodeAt(lA + 3)], T[q++] = t << 2 | e >> 4, T[q++] = (15 & e) << 4 | a >> 2, T[q++] = (3 & a) << 6 | 63 & g;
      return v;
    }(jn = "AAAAAAAAAAAAEA4AGBkAAFAaAAACAAAAAAAIABAAGAAwADgACAAQAAgAEAAIABAACAAQAAgAEAAIABAACAAQAAgAEAAIABAAQABIAEQATAAIABAACAAQAAgAEAAIABAAVABcAAgAEAAIABAACAAQAGAAaABwAHgAgACIAI4AlgAIABAAmwCjAKgAsAC2AL4AvQDFAMoA0gBPAVYBWgEIAAgACACMANoAYgFkAWwBdAF8AX0BhQGNAZUBlgGeAaMBlQGWAasBswF8AbsBwwF0AcsBYwHTAQgA2wG/AOMBdAF8AekB8QF0AfkB+wHiAHQBfAEIAAMC5gQIAAsCEgIIAAgAFgIeAggAIgIpAggAMQI5AkACygEIAAgASAJQAlgCYAIIAAgACAAKBQoFCgUTBRMFGQUrBSsFCAAIAAgACAAIAAgACAAIAAgACABdAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABoAmgCrwGvAQgAbgJ2AggAHgEIAAgACADnAXsCCAAIAAgAgwIIAAgACAAIAAgACACKAggAkQKZAggAPADJAAgAoQKkAqwCsgK6AsICCADJAggA0AIIAAgACAAIANYC3gIIAAgACAAIAAgACABAAOYCCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAkASoB+QIEAAgACAA8AEMCCABCBQgACABJBVAFCAAIAAgACAAIAAgACAAIAAgACABTBVoFCAAIAFoFCABfBWUFCAAIAAgACAAIAAgAbQUIAAgACAAIAAgACABzBXsFfQWFBYoFigWKBZEFigWKBYoFmAWfBaYFrgWxBbkFCAAIAAgACAAIAAgACAAIAAgACAAIAMEFCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAMgFCADQBQgACAAIAAgACAAIAAgACAAIAAgACAAIAO4CCAAIAAgAiQAIAAgACABAAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAD0AggACAD8AggACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIANYFCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAMDvwAIAAgAJAIIAAgACAAIAAgACAAIAAgACwMTAwgACAB9BOsEGwMjAwgAKwMyAwsFYgE3A/MEPwMIAEUDTQNRAwgAWQOsAGEDCAAIAAgACAAIAAgACABpAzQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFIQUoBSwFCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABtAwgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABMAEwACAAIAAgACAAIABgACAAIAAgACAC/AAgACAAyAQgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACACAAIAAwAAgACAAIAAgACAAIAAgACAAIAAAARABIAAgACAAIABQASAAIAAgAIABwAEAAjgCIABsAqAC2AL0AigDQAtwC+IJIQqVAZUBWQqVAZUBlQGVAZUBlQGrC5UBlQGVAZUBlQGVAZUBlQGVAXsKlQGVAbAK6wsrDGUMpQzlDJUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAfAKAAuZA64AtwCJALoC6ADwAAgAuACgA/oEpgO6AqsD+AAIAAgAswMIAAgACAAIAIkAuwP5AfsBwwPLAwgACAAIAAgACADRA9kDCAAIAOED6QMIAAgACAAIAAgACADuA/YDCAAIAP4DyQAIAAgABgQIAAgAXQAOBAgACAAIAAgACAAIABMECAAIAAgACAAIAAgACAD8AAQBCAAIAAgAGgQiBCoECAExBAgAEAEIAAgACAAIAAgACAAIAAgACAAIAAgACAA4BAgACABABEYECAAIAAgATAQYAQgAVAQIAAgACAAIAAgACAAIAAgACAAIAFoECAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAOQEIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAB+BAcACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAEABhgSMBAgACAAIAAgAlAQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAwAEAAQABAADAAMAAwADAAQABAAEAAQABAAEAAQABHATAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAdQMIAAgACAAIAAgACAAIAMkACAAIAAgAfQMIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACACFA4kDCAAIAAgACAAIAOcBCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAIcDCAAIAAgACAAIAAgACAAIAAgACAAIAJEDCAAIAAgACADFAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABgBAgAZgQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAbAQCBXIECAAIAHkECAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABAAJwEQACjBKoEsgQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAC6BMIECAAIAAgACAAIAAgACABmBAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAxwQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAGYECAAIAAgAzgQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAigWKBYoFigWKBYoFigWKBd0FXwUIAOIF6gXxBYoF3gT5BQAGCAaKBYoFigWKBYoFigWKBYoFigWKBYoFigXWBIoFigWKBYoFigWKBYoFigWKBYsFEAaKBYoFigWKBYoFigWKBRQGCACKBYoFigWKBQgACAAIANEECAAIABgGigUgBggAJgYIAC4GMwaKBYoF0wQ3Bj4GigWKBYoFigWKBYoFigWKBYoFigWKBYoFigUIAAgACAAIAAgACAAIAAgAigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWLBf///////wQABAAEAAQABAAEAAQABAAEAAQAAwAEAAQAAgAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAQADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAUAAAAFAAUAAAAFAAUAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUAAQAAAAUABQAFAAUABQAFAAAAAAAFAAUAAAAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAFAAUAAQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABwAFAAUABQAFAAAABwAHAAcAAAAHAAcABwAFAAEAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAcABwAFAAUAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAAAAQABAAAAAAAAAAAAAAAFAAUABQAFAAAABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAcABwAHAAcAAAAHAAcAAAAAAAUABQAHAAUAAQAHAAEABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABwABAAUABQAFAAUAAAAAAAAAAAAAAAEAAQABAAEAAQABAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABwAFAAUAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUAAQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABQANAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAEAAQABAAEAAQABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAABQAHAAUABQAFAAAAAAAAAAcABQAFAAUABQAFAAQABAAEAAQABAAEAAQABAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUAAAAFAAUABQAFAAUAAAAFAAUABQAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAAAAAAAAAAAAUABQAFAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAUAAAAHAAcABwAFAAUABQAFAAUABQAFAAUABwAHAAcABwAFAAcABwAAAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAUABwAHAAUABQAFAAUAAAAAAAcABwAAAAAABwAHAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAABQAFAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABwAHAAcABQAFAAAAAAAAAAAABQAFAAAAAAAFAAUABQAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAFAAUABQAFAAUAAAAFAAUABwAAAAcABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAFAAUABwAFAAUABQAFAAAAAAAHAAcAAAAAAAcABwAFAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAcABwAAAAAAAAAHAAcABwAAAAcABwAHAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAABQAHAAcABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAHAAcABwAAAAUABQAFAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAcABQAHAAcABQAHAAcAAAAFAAcABwAAAAcABwAFAAUAAAAAAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAUABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAFAAcABwAFAAUABQAAAAUAAAAHAAcABwAHAAcABwAHAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAHAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABwAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAUAAAAFAAAAAAAAAAAABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABwAFAAUABQAFAAUAAAAFAAUAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABwAFAAUABQAFAAUABQAAAAUABQAHAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABQAFAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAcABQAFAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAHAAUABQAFAAUABQAFAAUABwAHAAcABwAHAAcABwAHAAUABwAHAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABwAHAAcABwAFAAUABwAHAAcAAAAAAAAAAAAHAAcABQAHAAcABwAHAAcABwAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAcABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAHAAUABQAFAAUABQAFAAUAAAAFAAAABQAAAAAABQAFAAUABQAFAAUABQAFAAcABwAHAAcABwAHAAUABQAFAAUABQAFAAUABQAFAAUAAAAAAAUABQAFAAUABQAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABwAFAAcABwAHAAcABwAFAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAUABQAFAAUABwAHAAUABQAHAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAcABQAFAAcABwAHAAUABwAFAAUABQAHAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABwAHAAcABwAHAAUABQAFAAUABQAFAAUABQAHAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAcABQAFAAUABQAFAAUABQAAAAAAAAAAAAUAAAAAAAAAAAAAAAAABQAAAAAABwAFAAUAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUAAAAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAABQAAAAAAAAAFAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAUABQAHAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAHAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAHAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAcABwAFAAUABQAFAAcABwAFAAUABwAHAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAcABwAFAAUABwAHAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAFAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAFAAUABQAAAAAABQAFAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAFAAcABwAAAAAAAAAAAAAABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAFAAcABwAFAAcABwAAAAcABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAFAAUABQAAAAUABQAAAAAAAAAAAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABwAFAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABQAFAAUABQAFAAUABQAFAAUABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAHAAcABQAHAAUABQAAAAAAAAAAAAAAAAAFAAAABwAHAAcABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAHAAcABwAAAAAABwAHAAAAAAAHAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAAAAAAFAAUABQAFAAUABQAFAAAAAAAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAUABQAFAAUABwAHAAUABQAFAAcABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAcABQAFAAUABQAFAAUABwAFAAcABwAFAAcABQAFAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAcABQAFAAUABQAAAAAABwAHAAcABwAFAAUABwAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAHAAUABQAFAAUABQAFAAUABQAHAAcABQAHAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAFAAcABwAFAAUABQAFAAUABQAHAAUAAAAAAAAAAAAAAAAAAAAAAAcABwAFAAUABQAFAAcABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAUABQAFAAUABQAHAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAAAAAAFAAUABwAHAAcABwAFAAAAAAAAAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABwAHAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAFAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAcABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAAAHAAUABQAFAAUABQAFAAUABwAFAAUABwAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUAAAAAAAAABQAAAAUABQAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAHAAcAAAAFAAUAAAAHAAcABQAHAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAAAAAAAAAAAAAAAAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAUABQAFAAAAAAAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAABQAFAAUABQAFAAUABQAAAAUABQAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAFAAUABQAFAAUADgAOAA4ADgAOAA4ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAAAAAAAAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAMAAwADAAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAAAAAAAAAAAAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAAAAAAAAAAAAsADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwACwAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAADgAOAA4AAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAAAA4ADgAOAA4ADgAOAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAAAA4AAAAOAAAAAAAAAAAAAAAAAA4AAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAADgAAAAAAAAAAAA4AAAAOAAAAAAAAAAAADgAOAA4AAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAAAA4ADgAOAA4ADgAOAA4ADgAOAAAADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4AAAAAAAAAAAAAAAAAAAAAAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAOAA4ADgAOAA4ADgAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAAAAAAAAA="), or = Array.isArray(We) ? function(A) {
      for (var t = A.length, e = [], a = 0; a < t; a += 4)
        e.push(A[a + 3] << 24 | A[a + 2] << 16 | A[a + 1] << 8 | A[a]);
      return e;
    }(We) : new Uint32Array(We), Vr = Array.isArray(We) ? function(A) {
      for (var t = A.length, e = [], a = 0; a < t; a += 2)
        e.push(A[a + 1] << 8 | A[a]);
      return e;
    }(We) : new Uint16Array(We), jn = Qi(Vr, 12, or[4] / 2), vn = or[5] === 2 ? Qi(Vr, (24 + or[4]) / 2) : (We = or, Vr = Math.ceil((24 + or[4]) / 4), We.slice ? We.slice(Vr, vn) : new Uint32Array(Array.prototype.slice.call(We, Vr, vn))), new fs(or[0], or[1], or[2], or[3], jn, vn)), Oe = "×", Wn = function(A, t, e, a, g) {
      var x = "http://www.w3.org/2000/svg", v = document.createElementNS(x, "svg"), x = document.createElementNS(x, "foreignObject");
      return v.setAttributeNS(null, "width", A.toString()), v.setAttributeNS(null, "height", t.toString()), x.setAttributeNS(null, "width", "100%"), x.setAttributeNS(null, "height", "100%"), x.setAttributeNS(null, "x", e.toString()), x.setAttributeNS(null, "y", a.toString()), x.setAttributeNS(null, "externalResourcesRequired", "true"), v.appendChild(x), x.appendChild(g), v;
    }, Hi = function(A) {
      return new Promise(function(t, e) {
        var a = new Image();
        a.onload = function() {
          return t(a);
        }, a.onerror = e, a.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(A));
      });
    }, fe = { get SUPPORT_RANGE_BOUNDS() {
      var A = function(t) {
        if (t.createRange) {
          var e = t.createRange();
          if (e.getBoundingClientRect) {
            var a = t.createElement("boundtest");
            if (a.style.height = "123px", a.style.display = "block", t.body.appendChild(a), e.selectNode(a), e = e.getBoundingClientRect(), e = Math.round(e.height), t.body.removeChild(a), e === 123)
              return !0;
          }
        }
        return !1;
      }(document);
      return Object.defineProperty(fe, "SUPPORT_RANGE_BOUNDS", { value: A }), A;
    }, get SUPPORT_WORD_BREAKING() {
      var A = fe.SUPPORT_RANGE_BOUNDS && function(t) {
        var e = t.createElement("boundtest");
        e.style.width = "50px", e.style.display = "block", e.style.fontSize = "12px", e.style.letterSpacing = "0px", e.style.wordSpacing = "0px", t.body.appendChild(e);
        var a = t.createRange();
        e.innerHTML = typeof "".repeat == "function" ? "&#128104;".repeat(10) : "";
        var g = e.firstChild, q = at(g.data).map(function(T) {
          return YA(T);
        }), v = 0, x = {}, q = q.every(function(T, lA) {
          a.setStart(g, v), a.setEnd(g, v + T.length);
          var cA = a.getBoundingClientRect();
          return v += T.length, T = cA.x > x.x || cA.y > x.y, x = cA, lA === 0 || T;
        });
        return t.body.removeChild(e), q;
      }(document);
      return Object.defineProperty(fe, "SUPPORT_WORD_BREAKING", { value: A }), A;
    }, get SUPPORT_SVG_DRAWING() {
      var A = function(g) {
        var e = new Image(), a = g.createElement("canvas"), g = a.getContext("2d");
        if (!g)
          return !1;
        e.src = "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg'></svg>";
        try {
          g.drawImage(e, 0, 0), a.toDataURL();
        } catch {
          return !1;
        }
        return !0;
      }(document);
      return Object.defineProperty(fe, "SUPPORT_SVG_DRAWING", { value: A }), A;
    }, get SUPPORT_FOREIGNOBJECT_DRAWING() {
      var A = typeof Array.from == "function" && typeof window.fetch == "function" ? function(t) {
        var e = t.createElement("canvas"), a = 100;
        e.width = a, e.height = a;
        var g = e.getContext("2d");
        if (!g)
          return Promise.reject(!1);
        g.fillStyle = "rgb(0, 255, 0)", g.fillRect(0, 0, a, a);
        var v = new Image(), x = e.toDataURL();
        return v.src = x, v = Wn(a, a, 0, 0, v), g.fillStyle = "red", g.fillRect(0, 0, a, a), Hi(v).then(function(q) {
          g.drawImage(q, 0, 0);
          var T = g.getImageData(0, 0, a, a).data;
          return g.fillStyle = "red", g.fillRect(0, 0, a, a), q = t.createElement("div"), q.style.backgroundImage = "url(" + x + ")", q.style.height = "100px", vi(T) ? Hi(Wn(a, a, 0, 0, q)) : Promise.reject(!1);
        }).then(function(q) {
          return g.drawImage(q, 0, 0), vi(g.getImageData(0, 0, a, a).data);
        }).catch(function() {
          return !1;
        });
      }(document) : Promise.resolve(!1);
      return Object.defineProperty(fe, "SUPPORT_FOREIGNOBJECT_DRAWING", { value: A }), A;
    }, get SUPPORT_CORS_IMAGES() {
      var A = new Image().crossOrigin !== void 0;
      return Object.defineProperty(fe, "SUPPORT_CORS_IMAGES", { value: A }), A;
    }, get SUPPORT_RESPONSE_TYPE() {
      var A = typeof new XMLHttpRequest().responseType == "string";
      return Object.defineProperty(fe, "SUPPORT_RESPONSE_TYPE", { value: A }), A;
    }, get SUPPORT_CORS_XHR() {
      var A = "withCredentials" in new XMLHttpRequest();
      return Object.defineProperty(fe, "SUPPORT_CORS_XHR", { value: A }), A;
    }, get SUPPORT_NATIVE_TEXT_SEGMENTATION() {
      var A = !(typeof Intl > "u" || !Intl.Segmenter);
      return Object.defineProperty(fe, "SUPPORT_NATIVE_TEXT_SEGMENTATION", { value: A }), A;
    } }, an = function(A, t) {
      this.text = A, this.bounds = t;
    }, ws = function(A, t) {
      var e = t.ownerDocument;
      if (e) {
        var a = e.createElement("html2canvaswrapper");
        if (a.appendChild(t.cloneNode(!0)), e = t.parentNode, e)
          return e.replaceChild(a, t), A = pt(A, a), a.firstChild && e.replaceChild(a.firstChild, a), A;
      }
      return XA.EMPTY;
    }, Si = function(A, t, e) {
      var a = A.ownerDocument;
      if (!a)
        throw new Error("Node has no owner document");
      return a = a.createRange(), a.setStart(A, t), a.setEnd(A, t + e), a;
    }, Jn = function(A) {
      if (fe.SUPPORT_NATIVE_TEXT_SEGMENTATION) {
        var t = new Intl.Segmenter(void 0, { granularity: "grapheme" });
        return Array.from(t.segment(A)).map(function(e) {
          return e.segment;
        });
      }
      return function(e) {
        for (var a, g = ps(e), v = []; !(a = g.next()).done; )
          a.value && v.push(a.value.slice());
        return v;
      }(A);
    }, ms = function(A, t) {
      return t.letterSpacing !== 0 ? Jn(A) : function(e, a) {
        if (fe.SUPPORT_NATIVE_TEXT_SEGMENTATION) {
          var g = new Intl.Segmenter(void 0, { granularity: "word" });
          return Array.from(g.segment(e)).map(function(v) {
            return v.segment;
          });
        }
        return ys(e, a);
      }(A, t);
    }, Cs = [32, 160, 4961, 65792, 65793, 4153, 4241], ys = function(A, t) {
      for (var e, a = Fe(A, { lineBreak: t.lineBreak, wordBreak: t.overflowWrap === "break-word" ? "break-word" : t.wordBreak }), g = []; !(e = a.next()).done; )
        (function() {
          var v, x;
          e.value && (v = e.value.slice(), v = at(v), x = "", v.forEach(function(q) {
            Cs.indexOf(q) === -1 ? x += YA(q) : (x.length && g.push(x), g.push(YA(q)), x = "");
          }), x.length && g.push(x));
        })();
      return g;
    }, Qs = function(A, t, e) {
      var a, g, v, x, q;
      this.text = Fs(t.data, e.textTransform), this.textBounds = (a = A, A = this.text, v = t, A = ms(A, g = e), x = [], q = 0, A.forEach(function(T) {
        var lA, cA, BA;
        g.textDecorationLine.length || 0 < T.trim().length ? fe.SUPPORT_RANGE_BOUNDS ? 1 < (BA = Si(v, q, T.length).getClientRects()).length ? (lA = Jn(T), cA = 0, lA.forEach(function(mA) {
          x.push(new an(mA, XA.fromDOMRectList(a, Si(v, cA + q, mA.length).getClientRects()))), cA += mA.length;
        })) : x.push(new an(T, XA.fromDOMRectList(a, BA))) : (BA = v.splitText(T.length), x.push(new an(T, ws(a, v))), v = BA) : fe.SUPPORT_RANGE_BOUNDS || (v = v.splitText(T.length)), q += T.length;
      }), x);
    }, Fs = function(A, t) {
      switch (t) {
        case 1:
          return A.toLowerCase();
        case 3:
          return A.replace(Us, vs);
        case 2:
          return A.toUpperCase();
        default:
          return A;
      }
    }, Us = /(^|\s|:|-|\(|\))([a-z])/g, vs = function(A, t, e) {
      return 0 < A.length ? t + e.toUpperCase() : A;
    }, ki = (rA(Li, bi = ir), Li);
    function Li(A, t) {
      return A = bi.call(this, A, t) || this, A.src = t.currentSrc || t.src, A.intrinsicWidth = t.naturalWidth, A.intrinsicHeight = t.naturalHeight, A.context.cache.addImage(A.src), A;
    }
    var Di, Ti = (rA(Ki, Di = ir), Ki);
    function Ki(A, t) {
      return A = Di.call(this, A, t) || this, A.canvas = t, A.intrinsicWidth = t.width, A.intrinsicHeight = t.height, A;
    }
    var _i, Oi = (rA(Pi, _i = ir), Pi);
    function Pi(g, t) {
      var e = _i.call(this, g, t) || this, a = new XMLSerializer(), g = pt(g, t);
      return t.setAttribute("width", g.width + "px"), t.setAttribute("height", g.height + "px"), e.svg = "data:image/svg+xml," + encodeURIComponent(a.serializeToString(t)), e.intrinsicWidth = t.width.baseVal.value, e.intrinsicHeight = t.height.baseVal.value, e.context.cache.addImage(e.svg), e;
    }
    var Mi, Ri = (rA(Ni, Mi = ir), Ni);
    function Ni(A, t) {
      return A = Mi.call(this, A, t) || this, A.value = t.value, A;
    }
    var Gi, zn = (rA(Vi, Gi = ir), Vi);
    function Vi(A, t) {
      return A = Gi.call(this, A, t) || this, A.start = t.start, A.reversed = typeof t.reversed == "boolean" && t.reversed === !0, A;
    }
    var qi, bs = [{ type: 15, flags: 0, unit: "px", number: 3 }], xs = [{ type: 16, flags: 0, number: 50 }], bn = "checkbox", xn = "radio", Is = "password", ji = 707406591, Yn = (rA(Xi, qi = ir), Xi);
    function Xi(A, t) {
      var e = qi.call(this, A, t) || this;
      switch (e.type = t.type.toLowerCase(), e.checked = t.checked, e.value = (t = (A = t).type === Is ? new Array(A.value.length + 1).join("•") : A.value).length === 0 ? A.placeholder || "" : t, e.type !== bn && e.type !== xn || (e.styles.backgroundColor = 3739148031, e.styles.borderTopColor = e.styles.borderRightColor = e.styles.borderBottomColor = e.styles.borderLeftColor = 2779096575, e.styles.borderTopWidth = e.styles.borderRightWidth = e.styles.borderBottomWidth = e.styles.borderLeftWidth = 1, e.styles.borderTopStyle = e.styles.borderRightStyle = e.styles.borderBottomStyle = e.styles.borderLeftStyle = 1, e.styles.backgroundClip = [0], e.styles.backgroundOrigin = [0], e.bounds = (t = e.bounds).width > t.height ? new XA(t.left + (t.width - t.height) / 2, t.top, t.height, t.height) : t.width < t.height ? new XA(t.left, t.top + (t.height - t.width) / 2, t.width, t.width) : t), e.type) {
        case bn:
          e.styles.borderTopRightRadius = e.styles.borderTopLeftRadius = e.styles.borderBottomRightRadius = e.styles.borderBottomLeftRadius = bs;
          break;
        case xn:
          e.styles.borderTopRightRadius = e.styles.borderTopLeftRadius = e.styles.borderBottomRightRadius = e.styles.borderBottomLeftRadius = xs;
      }
      return e;
    }
    var Wi, Ji = (rA(zi, Wi = ir), zi);
    function zi(A, t) {
      return A = Wi.call(this, A, t) || this, t = t.options[t.selectedIndex || 0], A.value = t && t.text || "", A;
    }
    var Yi, Zi = (rA($i, Yi = ir), $i);
    function $i(A, t) {
      return A = Yi.call(this, A, t) || this, A.value = t.value, A;
    }
    var Ao, to = (rA(eo, Ao = ir), eo);
    function eo(A, t) {
      var e, a, g = Ao.call(this, A, t) || this;
      g.src = t.src, g.width = parseInt(t.width, 10) || 0, g.height = parseInt(t.height, 10) || 0, g.backgroundColor = g.styles.backgroundColor;
      try {
        t.contentWindow && t.contentWindow.document && t.contentWindow.document.documentElement && (g.tree = so(A, t.contentWindow.document.documentElement), e = t.contentWindow.document.documentElement ? yA(A, getComputedStyle(t.contentWindow.document.documentElement).backgroundColor) : $A.TRANSPARENT, a = t.contentWindow.document.body ? yA(A, getComputedStyle(t.contentWindow.document.body).backgroundColor) : $A.TRANSPARENT, g.backgroundColor = oA(e) ? oA(a) ? g.styles.backgroundColor : a : e);
      } catch {
      }
      return g;
    }
    function ro(A) {
      return A.tagName === "VIDEO";
    }
    function no(A) {
      return A.tagName === "STYLE";
    }
    function io(A) {
      return 0 < A.tagName.indexOf("-");
    }
    var Es = ["OL", "UL", "MENU"], In = function(A, t, e, a) {
      for (var g = t.firstChild; g; g = x) {
        var v, x = g.nextSibling;
        ao(g) && 0 < g.data.trim().length ? e.textNodes.push(new Qs(A, g, e.styles)) : qr(g) && (ho(g) && g.assignedNodes ? g.assignedNodes().forEach(function(q) {
          return In(A, q, e, a);
        }) : (v = oo(A, g)).styles.isVisible() && (Hs(g, v, a) ? v.flags |= 4 : Ss(v.styles) && (v.flags |= 2), Es.indexOf(g.tagName) !== -1 && (v.flags |= 8), e.elements.push(v), g.slot, g.shadowRoot ? In(A, g.shadowRoot, v, a) : Hn(g) || co(g) || Sn(g) || In(A, g, v, a)));
      }
    }, oo = function(A, t) {
      return new (Ai(t) ? ki : lo(t) ? Ti : co(t) ? Oi : ks(t) ? Ri : Ls(t) ? zn : Ds(t) ? Yn : Sn(t) ? Ji : Hn(t) ? Zi : uo(t) ? to : ir)(A, t);
    }, so = function(A, t) {
      var e = oo(A, t);
      return e.flags |= 4, In(A, t, e, e), e;
    }, Hs = function(A, t, e) {
      return t.styles.isPositionedWithZIndex() || t.styles.opacity < 1 || t.styles.isTransformed() || $n(A) && e.styles.isTransparent();
    }, Ss = function(A) {
      return A.isPositioned() || A.isFloating();
    }, ao = function(A) {
      return A.nodeType === Node.TEXT_NODE;
    }, qr = function(A) {
      return A.nodeType === Node.ELEMENT_NODE;
    }, Zn = function(A) {
      return qr(A) && A.style !== void 0 && !En(A);
    }, En = function(A) {
      return typeof A.className == "object";
    }, ks = function(A) {
      return A.tagName === "LI";
    }, Ls = function(A) {
      return A.tagName === "OL";
    }, Ds = function(A) {
      return A.tagName === "INPUT";
    }, co = function(A) {
      return A.tagName === "svg";
    }, $n = function(A) {
      return A.tagName === "BODY";
    }, lo = function(A) {
      return A.tagName === "CANVAS";
    }, Ai = function(A) {
      return A.tagName === "IMG";
    }, uo = function(A) {
      return A.tagName === "IFRAME";
    }, Hn = function(A) {
      return A.tagName === "TEXTAREA";
    }, Sn = function(A) {
      return A.tagName === "SELECT";
    }, ho = function(A) {
      return A.tagName === "SLOT";
    }, Ts = (cn.prototype.getCounterValue = function(A) {
      return A = this.counters[A], A && A.length ? A[A.length - 1] : 1;
    }, cn.prototype.getCounterValues = function(A) {
      return A = this.counters[A], A || [];
    }, cn.prototype.pop = function(A) {
      var t = this;
      A.forEach(function(e) {
        return t.counters[e].pop();
      });
    }, cn.prototype.parse = function(a) {
      var t = this, e = a.counterIncrement, a = a.counterReset, g = !0;
      e !== null && e.forEach(function(x) {
        var q = t.counters[x.counter];
        q && x.increment !== 0 && (g = !1, q.length || q.push(1), q[Math.max(0, q.length - 1)] += x.increment);
      });
      var v = [];
      return g && a.forEach(function(x) {
        var q = t.counters[x.counter];
        v.push(x.counter), (q = q || (t.counters[x.counter] = [])).push(x.reset);
      }), v;
    }, cn);
    function cn() {
      this.counters = {};
    }
    function jr(A, t, e, a, g, v) {
      return A < t || e < A ? un(A, g, 0 < v.length) : a.integers.reduce(function(x, q, T) {
        for (; q <= A; )
          A -= q, x += a.values[T];
        return x;
      }, "") + v;
    }
    function fo(A, t, e, a) {
      for (var g = ""; e || A--, g = a(A) + g, t <= (A /= t) * t; )
        ;
      return g;
    }
    function Zt(A, t, e, a, g) {
      var v = e - t + 1;
      return (A < 0 ? "-" : "") + (fo(Math.abs(A), v, a, function(x) {
        return YA(Math.floor(x % v) + t);
      }) + g);
    }
    function kr(A, t, e) {
      e === void 0 && (e = ". ");
      var a = t.length;
      return fo(Math.abs(A), a, !1, function(g) {
        return t[Math.floor(g % a)];
      }) + e;
    }
    function pr(A, t, e, a, g, v) {
      if (A < -9999 || 9999 < A)
        return un(A, 4, 0 < g.length);
      var x = Math.abs(A), q = g;
      if (x === 0)
        return t[0] + q;
      for (var T = 0; 0 < x && T <= 4; T++) {
        var lA = x % 10;
        lA == 0 && wt(v, 1) && q !== "" ? q = t[lA] + q : 1 < lA || lA == 1 && T === 0 || lA == 1 && T === 1 && wt(v, 2) || lA == 1 && T === 1 && wt(v, 4) && 100 < A || lA == 1 && 1 < T && wt(v, 8) ? q = t[lA] + (0 < T ? e[T - 1] : "") + q : lA == 1 && 0 < T && (q = e[T - 1] + q), x = Math.floor(x / 10);
      }
      return (A < 0 ? a : "") + q;
    }
    var ln, go = { integers: [1e3, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1], values: ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"] }, po = { integers: [9e3, 8e3, 7e3, 6e3, 5e3, 4e3, 3e3, 2e3, 1e3, 900, 800, 700, 600, 500, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1], values: ["Ք", "Փ", "Ւ", "Ց", "Ր", "Տ", "Վ", "Ս", "Ռ", "Ջ", "Պ", "Չ", "Ո", "Շ", "Ն", "Յ", "Մ", "Ճ", "Ղ", "Ձ", "Հ", "Կ", "Ծ", "Խ", "Լ", "Ի", "Ժ", "Թ", "Ը", "Է", "Զ", "Ե", "Դ", "Գ", "Բ", "Ա"] }, Ks = { integers: [1e4, 9e3, 8e3, 7e3, 6e3, 5e3, 4e3, 3e3, 2e3, 1e3, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 19, 18, 17, 16, 15, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1], values: ["י׳", "ט׳", "ח׳", "ז׳", "ו׳", "ה׳", "ד׳", "ג׳", "ב׳", "א׳", "ת", "ש", "ר", "ק", "צ", "פ", "ע", "ס", "נ", "מ", "ל", "כ", "יט", "יח", "יז", "טז", "טו", "י", "ט", "ח", "ז", "ו", "ה", "ד", "ג", "ב", "א"] }, _s = { integers: [1e4, 9e3, 8e3, 7e3, 6e3, 5e3, 4e3, 3e3, 2e3, 1e3, 900, 800, 700, 600, 500, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1], values: ["ჵ", "ჰ", "ჯ", "ჴ", "ხ", "ჭ", "წ", "ძ", "ც", "ჩ", "შ", "ყ", "ღ", "ქ", "ფ", "ჳ", "ტ", "ს", "რ", "ჟ", "პ", "ო", "ჲ", "ნ", "მ", "ლ", "კ", "ი", "თ", "ჱ", "ზ", "ვ", "ე", "დ", "გ", "ბ", "ა"] }, ti = "마이너스", un = function(A, t, e) {
      var a = e ? ". " : "", g = e ? "、" : "", v = e ? ", " : "", x = e ? " " : "";
      switch (t) {
        case 0:
          return "•" + x;
        case 1:
          return "◦" + x;
        case 2:
          return "◾" + x;
        case 5:
          var q = Zt(A, 48, 57, !0, a);
          return q.length < 4 ? "0" + q : q;
        case 4:
          return kr(A, "〇一二三四五六七八九", g);
        case 6:
          return jr(A, 1, 3999, go, 3, a).toLowerCase();
        case 7:
          return jr(A, 1, 3999, go, 3, a);
        case 8:
          return Zt(A, 945, 969, !1, a);
        case 9:
          return Zt(A, 97, 122, !1, a);
        case 10:
          return Zt(A, 65, 90, !1, a);
        case 11:
          return Zt(A, 1632, 1641, !0, a);
        case 12:
        case 49:
          return jr(A, 1, 9999, po, 3, a);
        case 35:
          return jr(A, 1, 9999, po, 3, a).toLowerCase();
        case 13:
          return Zt(A, 2534, 2543, !0, a);
        case 14:
        case 30:
          return Zt(A, 6112, 6121, !0, a);
        case 15:
          return kr(A, "子丑寅卯辰巳午未申酉戌亥", g);
        case 16:
          return kr(A, "甲乙丙丁戊己庚辛壬癸", g);
        case 17:
        case 48:
          return pr(A, "零一二三四五六七八九", "十百千萬", "負", g, 14);
        case 47:
          return pr(A, "零壹貳參肆伍陸柒捌玖", "拾佰仟萬", "負", g, 15);
        case 42:
          return pr(A, "零一二三四五六七八九", "十百千萬", "负", g, 14);
        case 41:
          return pr(A, "零壹贰叁肆伍陆柒捌玖", "拾佰仟萬", "负", g, 15);
        case 26:
          return pr(A, "〇一二三四五六七八九", "十百千万", "マイナス", g, 0);
        case 25:
          return pr(A, "零壱弐参四伍六七八九", "拾百千万", "マイナス", g, 7);
        case 31:
          return pr(A, "영일이삼사오육칠팔구", "십백천만", ti, v, 7);
        case 33:
          return pr(A, "零一二三四五六七八九", "十百千萬", ti, v, 0);
        case 32:
          return pr(A, "零壹貳參四五六七八九", "拾百千", ti, v, 7);
        case 18:
          return Zt(A, 2406, 2415, !0, a);
        case 20:
          return jr(A, 1, 19999, _s, 3, a);
        case 21:
          return Zt(A, 2790, 2799, !0, a);
        case 22:
          return Zt(A, 2662, 2671, !0, a);
        case 22:
          return jr(A, 1, 10999, Ks, 3, a);
        case 23:
          return kr(A, "あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわゐゑをん");
        case 24:
          return kr(A, "いろはにほへとちりぬるをわかよたれそつねならむうゐのおくやまけふこえてあさきゆめみしゑひもせす");
        case 27:
          return Zt(A, 3302, 3311, !0, a);
        case 28:
          return kr(A, "アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヰヱヲン", g);
        case 29:
          return kr(A, "イロハニホヘトチリヌルヲワカヨタレソツネナラムウヰノオクヤマケフコエテアサキユメミシヱヒモセス", g);
        case 34:
          return Zt(A, 3792, 3801, !0, a);
        case 37:
          return Zt(A, 6160, 6169, !0, a);
        case 38:
          return Zt(A, 4160, 4169, !0, a);
        case 39:
          return Zt(A, 2918, 2927, !0, a);
        case 40:
          return Zt(A, 1776, 1785, !0, a);
        case 43:
          return Zt(A, 3046, 3055, !0, a);
        case 44:
          return Zt(A, 3174, 3183, !0, a);
        case 45:
          return Zt(A, 3664, 3673, !0, a);
        case 46:
          return Zt(A, 3872, 3881, !0, a);
        default:
          return Zt(A, 48, 57, !0, a);
      }
    }, Bo = "data-html2canvas-ignore", wo = (Pe.prototype.toIFrame = function(T, t) {
      var e = this, a = Ps(T, t);
      if (!a.contentWindow)
        return Promise.reject("Unable to find iframe window");
      var g = T.defaultView.pageXOffset, v = T.defaultView.pageYOffset, x = a.contentWindow, q = x.document, T = Rs(a).then(function() {
        return LA(e, void 0, void 0, function() {
          var lA, cA;
          return kA(this, function(BA) {
            switch (BA.label) {
              case 0:
                return this.scrolledElements.forEach(qs), x && (x.scrollTo(t.left, t.top), !/(iPad|iPhone|iPod)/g.test(navigator.userAgent) || x.scrollY === t.top && x.scrollX === t.left || (this.context.logger.warn("Unable to restore scroll position for cloned document"), this.context.windowBounds = this.context.windowBounds.add(x.scrollX - t.left, x.scrollY - t.top, 0, 0))), lA = this.options.onclone, (cA = this.clonedReferenceElement) === void 0 ? [2, Promise.reject("Error finding the " + this.referenceElement.nodeName + " in the cloned document")] : q.fonts && q.fonts.ready ? [4, q.fonts.ready] : [3, 2];
              case 1:
                BA.sent(), BA.label = 2;
              case 2:
                return /(AppleWebKit)/g.test(navigator.userAgent) ? [4, Ms(q)] : [3, 4];
              case 3:
                BA.sent(), BA.label = 4;
              case 4:
                return typeof lA == "function" ? [2, Promise.resolve().then(function() {
                  return lA(q, cA);
                }).then(function() {
                  return a;
                })] : [2, a];
            }
          });
        });
      });
      return q.open(), q.write(Gs(document.doctype) + "<html></html>"), Vs(this.referenceElement.ownerDocument, g, v), q.replaceChild(q.adoptNode(this.documentElement), q.documentElement), q.close(), T;
    }, Pe.prototype.createElementClone = function(A) {
      if (qn(A, 2), lo(A))
        return this.createCanvasClone(A);
      if (ro(A))
        return this.createVideoClone(A);
      if (no(A))
        return this.createStyleClone(A);
      var t = A.cloneNode(!1);
      return Ai(t) && (Ai(A) && A.currentSrc && A.currentSrc !== A.src && (t.src = A.currentSrc, t.srcset = ""), t.loading === "lazy" && (t.loading = "eager")), io(t) ? this.createCustomElementClone(t) : t;
    }, Pe.prototype.createCustomElementClone = function(A) {
      var t = document.createElement("html2canvascustomelement");
      return ei(A.style, t), t;
    }, Pe.prototype.createStyleClone = function(A) {
      try {
        var t = A.sheet;
        if (t && t.cssRules) {
          var e = [].slice.call(t.cssRules, 0).reduce(function(g, v) {
            return v && typeof v.cssText == "string" ? g + v.cssText : g;
          }, ""), a = A.cloneNode(!1);
          return a.textContent = e, a;
        }
      } catch (g) {
        if (this.context.logger.error("Unable to access cssRules property", g), g.name !== "SecurityError")
          throw g;
      }
      return A.cloneNode(!1);
    }, Pe.prototype.createCanvasClone = function(A) {
      var t;
      if (this.options.inlineImages && A.ownerDocument) {
        var e = A.ownerDocument.createElement("img");
        try {
          return e.src = A.toDataURL(), e;
        } catch {
          this.context.logger.info("Unable to inline canvas contents, canvas is tainted", A);
        }
      }
      e = A.cloneNode(!1);
      try {
        e.width = A.width, e.height = A.height;
        var a, g, v = A.getContext("2d"), x = e.getContext("2d");
        return x && (!this.options.allowTaint && v ? x.putImageData(v.getImageData(0, 0, A.width, A.height), 0, 0) : (!(a = (t = A.getContext("webgl2")) !== null && t !== void 0 ? t : A.getContext("webgl")) || ((g = a.getContextAttributes()) == null ? void 0 : g.preserveDrawingBuffer) === !1 && this.context.logger.warn("Unable to clone WebGL context as it has preserveDrawingBuffer=false", A), x.drawImage(A, 0, 0))), e;
      } catch {
        this.context.logger.info("Unable to clone canvas as it is tainted", A);
      }
      return e;
    }, Pe.prototype.createVideoClone = function(A) {
      var t = A.ownerDocument.createElement("canvas");
      t.width = A.offsetWidth, t.height = A.offsetHeight;
      var e = t.getContext("2d");
      try {
        return e && (e.drawImage(A, 0, 0, t.width, t.height), this.options.allowTaint || e.getImageData(0, 0, t.width, t.height)), t;
      } catch {
        this.context.logger.info("Unable to clone video as it is tainted", A);
      }
      return t = A.ownerDocument.createElement("canvas"), t.width = A.offsetWidth, t.height = A.offsetHeight, t;
    }, Pe.prototype.appendChildNode = function(A, t, e) {
      qr(t) && (t.tagName === "SCRIPT" || t.hasAttribute(Bo) || typeof this.options.ignoreElements == "function" && this.options.ignoreElements(t)) || this.options.copyStyles && qr(t) && no(t) || A.appendChild(this.cloneNode(t, e));
    }, Pe.prototype.cloneChildNodes = function(A, t, e) {
      for (var a, g = this, v = (A.shadowRoot || A).firstChild; v; v = v.nextSibling)
        qr(v) && ho(v) && typeof v.assignedNodes == "function" ? (a = v.assignedNodes()).length && a.forEach(function(x) {
          return g.appendChildNode(t, x, e);
        }) : this.appendChildNode(t, v, e);
    }, Pe.prototype.cloneNode = function(A, t) {
      if (ao(A))
        return document.createTextNode(A.data);
      if (!A.ownerDocument)
        return A.cloneNode(!1);
      var e = A.ownerDocument.defaultView;
      if (e && qr(A) && (Zn(A) || En(A))) {
        var a = this.createElementClone(A);
        a.style.transitionProperty = "none";
        var g = e.getComputedStyle(A), v = e.getComputedStyle(A, ":before"), x = e.getComputedStyle(A, ":after");
        return this.referenceElement === A && Zn(a) && (this.clonedReferenceElement = a), $n(a) && js(a), e = this.counters.parse(new Ci(this.context, g)), v = this.resolvePseudoContent(A, a, v, ln.BEFORE), io(A) && (t = !0), ro(A) || this.cloneChildNodes(A, a, t), v && a.insertBefore(v, a.firstChild), x = this.resolvePseudoContent(A, a, x, ln.AFTER), x && a.appendChild(x), this.counters.pop(e), (g && (this.options.copyStyles || En(A)) && !uo(A) || t) && ei(g, a), A.scrollTop === 0 && A.scrollLeft === 0 || this.scrolledElements.push([a, A.scrollLeft, A.scrollTop]), (Hn(A) || Sn(A)) && (Hn(a) || Sn(a)) && (a.value = A.value), a;
      }
      return A.cloneNode(!1);
    }, Pe.prototype.resolvePseudoContent = function(A, t, e, a) {
      var g = this;
      if (e) {
        var v = e.content, x = t.ownerDocument;
        if (x && v && v !== "none" && v !== "-moz-alt-content" && e.display !== "none") {
          this.counters.parse(new Ci(this.context, e));
          var q = new hs(this.context, e), T = x.createElement("html2canvaspseudoelement");
          return ei(e, T), q.content.forEach(function(lA) {
            if (lA.type === 0)
              T.appendChild(x.createTextNode(lA.value));
            else if (lA.type === 22) {
              var cA = x.createElement("img");
              cA.src = lA.value, cA.style.opacity = "1", T.appendChild(cA);
            } else if (lA.type === 18) {
              var BA, mA, FA, MA, DA;
              lA.name === "attr" ? (cA = lA.values.filter(P)).length && T.appendChild(x.createTextNode(A.getAttribute(cA[0].value) || "")) : lA.name === "counter" ? (FA = (mA = lA.values.filter(hA))[0], mA = mA[1], FA && P(FA) && (BA = g.counters.getCounterValue(FA.value), DA = mA && P(mA) ? en.parse(g.context, mA.value) : 3, T.appendChild(x.createTextNode(un(BA, DA, !1))))) : lA.name === "counters" && (FA = (BA = lA.values.filter(hA))[0], DA = BA[1], mA = BA[2], FA && P(FA) && (FA = g.counters.getCounterValues(FA.value), MA = mA && P(mA) ? en.parse(g.context, mA.value) : 3, DA = DA && DA.type === 0 ? DA.value : "", DA = FA.map(function(IA) {
                return un(IA, MA, !1);
              }).join(DA), T.appendChild(x.createTextNode(DA))));
            } else if (lA.type === 20)
              switch (lA.value) {
                case "open-quote":
                  T.appendChild(x.createTextNode(gr(q.quotes, g.quoteDepth++, !0)));
                  break;
                case "close-quote":
                  T.appendChild(x.createTextNode(gr(q.quotes, --g.quoteDepth, !1)));
                  break;
                default:
                  T.appendChild(x.createTextNode(lA.value));
              }
          }), T.className = ri + " " + ni, a = a === ln.BEFORE ? " " + ri : " " + ni, En(t) ? t.className.baseValue += a : t.className += a, T;
        }
      }
    }, Pe.destroy = function(A) {
      return !!A.parentNode && (A.parentNode.removeChild(A), !0);
    }, Pe);
    function Pe(A, t, e) {
      if (this.context = A, this.options = e, this.scrolledElements = [], this.referenceElement = t, this.counters = new Ts(), this.quoteDepth = 0, !t.ownerDocument)
        throw new Error("Cloned element does not have an owner document");
      this.documentElement = this.cloneNode(t.ownerDocument.documentElement, !1);
    }
    (qA = ln = ln || {})[qA.BEFORE = 0] = "BEFORE", qA[qA.AFTER = 1] = "AFTER";
    function Os(A) {
      return new Promise(function(t) {
        !A.complete && A.src ? (A.onload = t, A.onerror = t) : t();
      });
    }
    var Ps = function(A, t) {
      var e = A.createElement("iframe");
      return e.className = "html2canvas-container", e.style.visibility = "hidden", e.style.position = "fixed", e.style.left = "-10000px", e.style.top = "0px", e.style.border = "0", e.width = t.width.toString(), e.height = t.height.toString(), e.scrolling = "no", e.setAttribute(Bo, "true"), A.body.appendChild(e), e;
    }, Ms = function(A) {
      return Promise.all([].slice.call(A.images, 0).map(Os));
    }, Rs = function(A) {
      return new Promise(function(t, e) {
        var a = A.contentWindow;
        if (!a)
          return e("No window assigned for iframe");
        var g = a.document;
        a.onload = A.onload = function() {
          a.onload = A.onload = null;
          var v = setInterval(function() {
            0 < g.body.childNodes.length && g.readyState === "complete" && (clearInterval(v), t(A));
          }, 50);
        };
      });
    }, Ns = ["all", "d", "content"], ei = function(A, t) {
      for (var e = A.length - 1; 0 <= e; e--) {
        var a = A.item(e);
        Ns.indexOf(a) === -1 && t.style.setProperty(a, A.getPropertyValue(a));
      }
      return t;
    }, Gs = function(A) {
      var t = "";
      return A && (t += "<!DOCTYPE ", A.name && (t += A.name), A.internalSubset && (t += A.internalSubset), A.publicId && (t += '"' + A.publicId + '"'), A.systemId && (t += '"' + A.systemId + '"'), t += ">"), t;
    }, Vs = function(A, t, e) {
      A && A.defaultView && (t !== A.defaultView.pageXOffset || e !== A.defaultView.pageYOffset) && A.defaultView.scrollTo(t, e);
    }, qs = function(a) {
      var t = a[0], e = a[1], a = a[2];
      t.scrollLeft = e, t.scrollTop = a;
    }, ri = "___html2canvas___pseudoelement_before", ni = "___html2canvas___pseudoelement_after", mo = `{
    content: "" !important;
    display: none !important;
}`, js = function(A) {
      Xs(A, "." + ri + ":before" + mo + `
         .` + ni + ":after" + mo);
    }, Xs = function(A, t) {
      var e = A.ownerDocument;
      e && ((e = e.createElement("style")).textContent = t, A.appendChild(e));
    }, Co = (Je.getOrigin = function(A) {
      var t = Je._link;
      return t ? (t.href = A, t.href = t.href, t.protocol + t.hostname + t.port) : "about:blank";
    }, Je.isSameOrigin = function(A) {
      return Je.getOrigin(A) === Je._origin;
    }, Je.setContext = function(A) {
      Je._link = A.document.createElement("a"), Je._origin = Je.getOrigin(A.location.href);
    }, Je._origin = "about:blank", Je);
    function Je() {
    }
    var Ws = (Lr.prototype.addImage = function(A) {
      var t = Promise.resolve();
      return this.has(A) || (oi(A) || Zs(A)) && (this._cache[A] = this.loadImage(A)).catch(function() {
      }), t;
    }, Lr.prototype.match = function(A) {
      return this._cache[A];
    }, Lr.prototype.loadImage = function(A) {
      return LA(this, void 0, void 0, function() {
        var t, e, a, g, v = this;
        return kA(this, function(x) {
          switch (x.label) {
            case 0:
              return t = Co.isSameOrigin(A), e = !ii(A) && this._options.useCORS === !0 && fe.SUPPORT_CORS_IMAGES && !t, a = !ii(A) && !t && !oi(A) && typeof this._options.proxy == "string" && fe.SUPPORT_CORS_XHR && !e, t || this._options.allowTaint !== !1 || ii(A) || oi(A) || a || e ? (g = A, a ? [4, this.proxy(g)] : [3, 2]) : [2];
            case 1:
              g = x.sent(), x.label = 2;
            case 2:
              return this.context.logger.debug("Added image " + A.substring(0, 256)), [4, new Promise(function(q, T) {
                var lA = new Image();
                lA.onload = function() {
                  return q(lA);
                }, lA.onerror = T, ($s(g) || e) && (lA.crossOrigin = "anonymous"), lA.src = g, lA.complete === !0 && setTimeout(function() {
                  return q(lA);
                }, 500), 0 < v._options.imageTimeout && setTimeout(function() {
                  return T("Timed out (" + v._options.imageTimeout + "ms) loading image");
                }, v._options.imageTimeout);
              })];
            case 3:
              return [2, x.sent()];
          }
        });
      });
    }, Lr.prototype.has = function(A) {
      return this._cache[A] !== void 0;
    }, Lr.prototype.keys = function() {
      return Promise.resolve(Object.keys(this._cache));
    }, Lr.prototype.proxy = function(A) {
      var t = this, e = this._options.proxy;
      if (!e)
        throw new Error("No proxy defined");
      var a = A.substring(0, 256);
      return new Promise(function(g, v) {
        var x = fe.SUPPORT_RESPONSE_TYPE ? "blob" : "text", q = new XMLHttpRequest();
        q.onload = function() {
          var cA;
          q.status === 200 ? x == "text" ? g(q.response) : ((cA = new FileReader()).addEventListener("load", function() {
            return g(cA.result);
          }, !1), cA.addEventListener("error", function(BA) {
            return v(BA);
          }, !1), cA.readAsDataURL(q.response)) : v("Failed to proxy resource " + a + " with status code " + q.status);
        }, q.onerror = v;
        var T, lA = -1 < e.indexOf("?") ? "&" : "?";
        q.open("GET", e + lA + "url=" + encodeURIComponent(A) + "&responseType=" + x), x != "text" && q instanceof XMLHttpRequest && (q.responseType = x), t._options.imageTimeout && (T = t._options.imageTimeout, q.timeout = T, q.ontimeout = function() {
          return v("Timed out (" + T + "ms) proxying " + a);
        }), q.send();
      });
    }, Lr);
    function Lr(A, t) {
      this.context = A, this._options = t, this._cache = {};
    }
    var Js = /^data:image\/svg\+xml/i, zs = /^data:image\/.*;base64,/i, Ys = /^data:image\/.*/i, Zs = function(A) {
      return fe.SUPPORT_SVG_DRAWING || !Aa(A);
    }, ii = function(A) {
      return Ys.test(A);
    }, $s = function(A) {
      return zs.test(A);
    }, oi = function(A) {
      return A.substr(0, 4) === "blob";
    }, Aa = function(A) {
      return A.substr(-3).toLowerCase() === "svg" || Js.test(A);
    }, OA = (si.prototype.add = function(A, t) {
      return new si(this.x + A, this.y + t);
    }, si);
    function si(A, t) {
      this.type = 0, this.x = A, this.y = t;
    }
    function Xr(A, t, e) {
      return new OA(A.x + (t.x - A.x) * e, A.y + (t.y - A.y) * e);
    }
    var kn = (Ur.prototype.subdivide = function(x, t) {
      var e = Xr(this.start, this.startControl, x), v = Xr(this.startControl, this.endControl, x), a = Xr(this.endControl, this.end, x), g = Xr(e, v, x), v = Xr(v, a, x), x = Xr(g, v, x);
      return t ? new Ur(this.start, e, g, x) : new Ur(x, v, a, this.end);
    }, Ur.prototype.add = function(A, t) {
      return new Ur(this.start.add(A, t), this.startControl.add(A, t), this.endControl.add(A, t), this.end.add(A, t));
    }, Ur.prototype.reverse = function() {
      return new Ur(this.end, this.endControl, this.startControl, this.start);
    }, Ur);
    function Ur(A, t, e, a) {
      this.type = 1, this.start = A, this.startControl = t, this.endControl = e, this.end = a;
    }
    function Me(A) {
      return A.type === 1;
    }
    var Et, ta = function(Qt) {
      var t = Qt.styles, e = Qt.bounds, a = (IA = E(t.borderTopLeftRadius, e.width, e.height))[0], g = IA[1], v = (zA = E(t.borderTopRightRadius, e.width, e.height))[0], x = zA[1], q = (RA = E(t.borderBottomRightRadius, e.width, e.height))[0], T = RA[1], lA = (GA = E(t.borderBottomLeftRadius, e.width, e.height))[0], cA = GA[1];
      (It = []).push((a + v) / e.width), It.push((lA + q) / e.width), It.push((g + cA) / e.height), It.push((x + T) / e.height), 1 < (NA = Math.max.apply(Math, It)) && (a /= NA, g /= NA, v /= NA, x /= NA, q /= NA, T /= NA, lA /= NA, cA /= NA);
      var BA = e.width - v, mA = e.height - T, FA = e.width - q, MA = e.height - cA, DA = t.borderTopWidth, IA = t.borderRightWidth, zA = t.borderBottomWidth, RA = t.borderLeftWidth, GA = Q(t.paddingTop, Qt.bounds.width), It = Q(t.paddingRight, Qt.bounds.width), NA = Q(t.paddingBottom, Qt.bounds.width), Qt = Q(t.paddingLeft, Qt.bounds.width);
      this.topLeftBorderDoubleOuterBox = 0 < a || 0 < g ? Rt(e.left + RA / 3, e.top + DA / 3, a - RA / 3, g - DA / 3, Et.TOP_LEFT) : new OA(e.left + RA / 3, e.top + DA / 3), this.topRightBorderDoubleOuterBox = 0 < a || 0 < g ? Rt(e.left + BA, e.top + DA / 3, v - IA / 3, x - DA / 3, Et.TOP_RIGHT) : new OA(e.left + e.width - IA / 3, e.top + DA / 3), this.bottomRightBorderDoubleOuterBox = 0 < q || 0 < T ? Rt(e.left + FA, e.top + mA, q - IA / 3, T - zA / 3, Et.BOTTOM_RIGHT) : new OA(e.left + e.width - IA / 3, e.top + e.height - zA / 3), this.bottomLeftBorderDoubleOuterBox = 0 < lA || 0 < cA ? Rt(e.left + RA / 3, e.top + MA, lA - RA / 3, cA - zA / 3, Et.BOTTOM_LEFT) : new OA(e.left + RA / 3, e.top + e.height - zA / 3), this.topLeftBorderDoubleInnerBox = 0 < a || 0 < g ? Rt(e.left + 2 * RA / 3, e.top + 2 * DA / 3, a - 2 * RA / 3, g - 2 * DA / 3, Et.TOP_LEFT) : new OA(e.left + 2 * RA / 3, e.top + 2 * DA / 3), this.topRightBorderDoubleInnerBox = 0 < a || 0 < g ? Rt(e.left + BA, e.top + 2 * DA / 3, v - 2 * IA / 3, x - 2 * DA / 3, Et.TOP_RIGHT) : new OA(e.left + e.width - 2 * IA / 3, e.top + 2 * DA / 3), this.bottomRightBorderDoubleInnerBox = 0 < q || 0 < T ? Rt(e.left + FA, e.top + mA, q - 2 * IA / 3, T - 2 * zA / 3, Et.BOTTOM_RIGHT) : new OA(e.left + e.width - 2 * IA / 3, e.top + e.height - 2 * zA / 3), this.bottomLeftBorderDoubleInnerBox = 0 < lA || 0 < cA ? Rt(e.left + 2 * RA / 3, e.top + MA, lA - 2 * RA / 3, cA - 2 * zA / 3, Et.BOTTOM_LEFT) : new OA(e.left + 2 * RA / 3, e.top + e.height - 2 * zA / 3), this.topLeftBorderStroke = 0 < a || 0 < g ? Rt(e.left + RA / 2, e.top + DA / 2, a - RA / 2, g - DA / 2, Et.TOP_LEFT) : new OA(e.left + RA / 2, e.top + DA / 2), this.topRightBorderStroke = 0 < a || 0 < g ? Rt(e.left + BA, e.top + DA / 2, v - IA / 2, x - DA / 2, Et.TOP_RIGHT) : new OA(e.left + e.width - IA / 2, e.top + DA / 2), this.bottomRightBorderStroke = 0 < q || 0 < T ? Rt(e.left + FA, e.top + mA, q - IA / 2, T - zA / 2, Et.BOTTOM_RIGHT) : new OA(e.left + e.width - IA / 2, e.top + e.height - zA / 2), this.bottomLeftBorderStroke = 0 < lA || 0 < cA ? Rt(e.left + RA / 2, e.top + MA, lA - RA / 2, cA - zA / 2, Et.BOTTOM_LEFT) : new OA(e.left + RA / 2, e.top + e.height - zA / 2), this.topLeftBorderBox = 0 < a || 0 < g ? Rt(e.left, e.top, a, g, Et.TOP_LEFT) : new OA(e.left, e.top), this.topRightBorderBox = 0 < v || 0 < x ? Rt(e.left + BA, e.top, v, x, Et.TOP_RIGHT) : new OA(e.left + e.width, e.top), this.bottomRightBorderBox = 0 < q || 0 < T ? Rt(e.left + FA, e.top + mA, q, T, Et.BOTTOM_RIGHT) : new OA(e.left + e.width, e.top + e.height), this.bottomLeftBorderBox = 0 < lA || 0 < cA ? Rt(e.left, e.top + MA, lA, cA, Et.BOTTOM_LEFT) : new OA(e.left, e.top + e.height), this.topLeftPaddingBox = 0 < a || 0 < g ? Rt(e.left + RA, e.top + DA, Math.max(0, a - RA), Math.max(0, g - DA), Et.TOP_LEFT) : new OA(e.left + RA, e.top + DA), this.topRightPaddingBox = 0 < v || 0 < x ? Rt(e.left + Math.min(BA, e.width - IA), e.top + DA, BA > e.width + IA ? 0 : Math.max(0, v - IA), Math.max(0, x - DA), Et.TOP_RIGHT) : new OA(e.left + e.width - IA, e.top + DA), this.bottomRightPaddingBox = 0 < q || 0 < T ? Rt(e.left + Math.min(FA, e.width - RA), e.top + Math.min(mA, e.height - zA), Math.max(0, q - IA), Math.max(0, T - zA), Et.BOTTOM_RIGHT) : new OA(e.left + e.width - IA, e.top + e.height - zA), this.bottomLeftPaddingBox = 0 < lA || 0 < cA ? Rt(e.left + RA, e.top + Math.min(MA, e.height - zA), Math.max(0, lA - RA), Math.max(0, cA - zA), Et.BOTTOM_LEFT) : new OA(e.left + RA, e.top + e.height - zA), this.topLeftContentBox = 0 < a || 0 < g ? Rt(e.left + RA + Qt, e.top + DA + GA, Math.max(0, a - (RA + Qt)), Math.max(0, g - (DA + GA)), Et.TOP_LEFT) : new OA(e.left + RA + Qt, e.top + DA + GA), this.topRightContentBox = 0 < v || 0 < x ? Rt(e.left + Math.min(BA, e.width + RA + Qt), e.top + DA + GA, BA > e.width + RA + Qt ? 0 : v - RA + Qt, x - (DA + GA), Et.TOP_RIGHT) : new OA(e.left + e.width - (IA + It), e.top + DA + GA), this.bottomRightContentBox = 0 < q || 0 < T ? Rt(e.left + Math.min(FA, e.width - (RA + Qt)), e.top + Math.min(mA, e.height + DA + GA), Math.max(0, q - (IA + It)), T - (zA + NA), Et.BOTTOM_RIGHT) : new OA(e.left + e.width - (IA + It), e.top + e.height - (zA + NA)), this.bottomLeftContentBox = 0 < lA || 0 < cA ? Rt(e.left + RA + Qt, e.top + MA, Math.max(0, lA - (RA + Qt)), cA - (zA + NA), Et.BOTTOM_LEFT) : new OA(e.left + RA + Qt, e.top + e.height - (zA + NA));
    };
    (qA = Et = Et || {})[qA.TOP_LEFT = 0] = "TOP_LEFT", qA[qA.TOP_RIGHT = 1] = "TOP_RIGHT", qA[qA.BOTTOM_RIGHT = 2] = "BOTTOM_RIGHT", qA[qA.BOTTOM_LEFT = 3] = "BOTTOM_LEFT";
    function Ln(A) {
      return [A.topLeftBorderBox, A.topRightBorderBox, A.bottomRightBorderBox, A.bottomLeftBorderBox];
    }
    function Dn(A) {
      return [A.topLeftPaddingBox, A.topRightPaddingBox, A.bottomRightPaddingBox, A.bottomLeftPaddingBox];
    }
    function yo(A) {
      return A.type === 1;
    }
    function Qo(A, t) {
      return A.length === t.length && A.some(function(e, a) {
        return e === t[a];
      });
    }
    var Rt = function(A, t, e, a, g) {
      var v = (Math.sqrt(2) - 1) / 3 * 4, x = e * v, q = a * v, T = A + e, lA = t + a;
      switch (g) {
        case Et.TOP_LEFT:
          return new kn(new OA(A, lA), new OA(A, lA - q), new OA(T - x, t), new OA(T, t));
        case Et.TOP_RIGHT:
          return new kn(new OA(A, t), new OA(A + x, t), new OA(T, lA - q), new OA(T, lA));
        case Et.BOTTOM_RIGHT:
          return new kn(new OA(T, t), new OA(T, t + q), new OA(A + x, lA), new OA(A, lA));
        default:
          return Et.BOTTOM_LEFT, new kn(new OA(T, lA), new OA(T - x, lA), new OA(A, t + q), new OA(A, t));
      }
    }, ea = function(A, t, e) {
      this.offsetX = A, this.offsetY = t, this.matrix = e, this.type = 0, this.target = 6;
    }, Tn = function(A, t) {
      this.path = A, this.target = t, this.type = 1;
    }, ra = function(A) {
      this.opacity = A, this.type = 2, this.target = 6;
    }, Fo = function(A) {
      this.element = A, this.inlineLevel = [], this.nonInlineLevel = [], this.negativeZIndex = [], this.zeroOrAutoZIndexOrTransformedOrOpacity = [], this.positiveZIndex = [], this.nonPositionedFloats = [], this.nonPositionedInlineLevel = [];
    }, Uo = (vo.prototype.getEffects = function(A) {
      for (var t = [2, 3].indexOf(this.container.styles.position) === -1, e = this.parent, a = this.effects.slice(0); e; ) {
        var g, v, x = e.effects.filter(function(q) {
          return !yo(q);
        });
        t || e.container.styles.position !== 0 || !e.parent ? (a.unshift.apply(a, x), t = [2, 3].indexOf(e.container.styles.position) === -1, e.container.styles.overflowX !== 0 && (g = Ln(e.curves), v = Dn(e.curves), Qo(g, v) || a.unshift(new Tn(v, 6)))) : a.unshift.apply(a, x), e = e.parent;
      }
      return a.filter(function(q) {
        return wt(q.target, A);
      });
    }, vo);
    function vo(A, t) {
      var e, a;
      this.container = A, this.parent = t, this.effects = [], this.curves = new ta(this.container), this.container.styles.opacity < 1 && this.effects.push(new ra(this.container.styles.opacity)), this.container.styles.transform !== null && (t = this.container.bounds.left + this.container.styles.transformOrigin[0].number, e = this.container.bounds.top + this.container.styles.transformOrigin[1].number, a = this.container.styles.transform, this.effects.push(new ea(t, e, a))), this.container.styles.overflowX !== 0 && (e = Ln(this.curves), a = Dn(this.curves), Qo(e, a) ? this.effects.push(new Tn(e, 6)) : (this.effects.push(new Tn(e, 2)), this.effects.push(new Tn(a, 4))));
    }
    function bo(A, t) {
      switch (t) {
        case 0:
          return Re(A.topLeftBorderBox, A.topLeftPaddingBox, A.topRightBorderBox, A.topRightPaddingBox);
        case 1:
          return Re(A.topRightBorderBox, A.topRightPaddingBox, A.bottomRightBorderBox, A.bottomRightPaddingBox);
        case 2:
          return Re(A.bottomRightBorderBox, A.bottomRightPaddingBox, A.bottomLeftBorderBox, A.bottomLeftPaddingBox);
        default:
          return Re(A.bottomLeftBorderBox, A.bottomLeftPaddingBox, A.topLeftBorderBox, A.topLeftPaddingBox);
      }
    }
    function xo(e) {
      var t = e.bounds, e = e.styles;
      return t.add(e.borderLeftWidth, e.borderTopWidth, -(e.borderRightWidth + e.borderLeftWidth), -(e.borderTopWidth + e.borderBottomWidth));
    }
    function Kn(x) {
      var t = x.styles, e = x.bounds, a = Q(t.paddingLeft, e.width), g = Q(t.paddingRight, e.width), v = Q(t.paddingTop, e.width), x = Q(t.paddingBottom, e.width);
      return e.add(a + t.borderLeftWidth, v + t.borderTopWidth, -(t.borderRightWidth + t.borderLeftWidth + a + g), -(t.borderTopWidth + t.borderBottomWidth + v + x));
    }
    function ai(A, t, T) {
      var a = (g = Jr(A.styles.backgroundOrigin, t), v = A, g === 0 ? v.bounds : (g === 2 ? Kn : xo)(v)), g = (x = Jr(A.styles.backgroundClip, t), q = A, x === 0 ? q.bounds : (x === 2 ? Kn : xo)(q)), v = na(Jr(A.styles.backgroundSize, t), T, a), x = v[0], q = v[1], T = E(Jr(A.styles.backgroundPosition, t), a.width - x, a.height - q);
      return [ia(Jr(A.styles.backgroundRepeat, t), T, v, a, g), Math.round(a.left + T[0]), Math.round(a.top + T[1]), x, q];
    }
    function Wr(A) {
      return P(A) && A.value === ee.AUTO;
    }
    function _n(A) {
      return typeof A == "number";
    }
    var ci = function(A, t, e, a) {
      A.container.elements.forEach(function(g) {
        var v = wt(g.flags, 4), x = wt(g.flags, 2), q = new Uo(g, A);
        wt(g.styles.display, 2048) && a.push(q);
        var T, lA, cA, BA, mA = wt(g.flags, 8) ? [] : a;
        v || x ? (T = v || g.styles.isPositioned() ? e : t, x = new Fo(q), g.styles.isPositioned() || g.styles.opacity < 1 || g.styles.isTransformed() ? (lA = g.styles.zIndex.order) < 0 ? (cA = 0, T.negativeZIndex.some(function(FA, MA) {
          return lA > FA.element.container.styles.zIndex.order ? (cA = MA, !1) : 0 < cA;
        }), T.negativeZIndex.splice(cA, 0, x)) : 0 < lA ? (BA = 0, T.positiveZIndex.some(function(FA, MA) {
          return lA >= FA.element.container.styles.zIndex.order ? (BA = MA + 1, !1) : 0 < BA;
        }), T.positiveZIndex.splice(BA, 0, x)) : T.zeroOrAutoZIndexOrTransformedOrOpacity.push(x) : (g.styles.isFloating() ? T.nonPositionedFloats : T.nonPositionedInlineLevel).push(x), ci(q, x, v ? x : e, mA)) : ((g.styles.isInlineLevel() ? t.inlineLevel : t.nonInlineLevel).push(q), ci(q, t, e, mA)), wt(g.flags, 8) && Io(g, mA);
      });
    }, Io = function(A, t) {
      for (var e = A instanceof zn ? A.start : 1, a = A instanceof zn && A.reversed, g = 0; g < t.length; g++) {
        var v = t[g];
        v.container instanceof Ri && typeof v.container.value == "number" && v.container.value !== 0 && (e = v.container.value), v.listValue = un(e, v.container.styles.listStyleType, !0), e += a ? -1 : 1;
      }
    }, On = function(A, t) {
      var e = [];
      return Me(A) ? e.push(A.subdivide(0.5, !1)) : e.push(A), Me(t) ? e.push(t.subdivide(0.5, !0)) : e.push(t), e;
    }, Re = function(A, t, e, a) {
      var g = [];
      return Me(A) ? g.push(A.subdivide(0.5, !1)) : g.push(A), Me(e) ? g.push(e.subdivide(0.5, !0)) : g.push(e), Me(a) ? g.push(a.subdivide(0.5, !0).reverse()) : g.push(a), Me(t) ? g.push(t.subdivide(0.5, !1).reverse()) : g.push(t), g;
    }, na = function(BA, cA, e) {
      var a = cA[0], g = cA[1], v = cA[2], x = BA[0], q = BA[1];
      if (!x)
        return [0, 0];
      if (F(x) && q && F(q))
        return [Q(x, e.width), Q(q, e.height)];
      var T = _n(v);
      if (P(x) && (x.value === ee.CONTAIN || x.value === ee.COVER))
        return _n(v) ? e.width / e.height < v != (x.value === ee.COVER) ? [e.width, e.width / v] : [e.height * v, e.height] : [e.width, e.height];
      var lA = _n(a), cA = _n(g), BA = lA || cA;
      if (Wr(x) && (!q || Wr(q)))
        return lA && cA ? [a, g] : T || BA ? BA && T ? [lA ? a : g * v, cA ? g : a / v] : [lA ? a : e.width, cA ? g : e.height] : [e.width, e.height];
      if (T) {
        var mA = 0, FA = 0;
        return F(x) ? mA = Q(x, e.width) : F(q) && (FA = Q(q, e.height)), Wr(x) ? mA = FA * v : q && !Wr(q) || (FA = mA / v), [mA, FA];
      }
      if (mA = null, FA = null, F(x) ? mA = Q(x, e.width) : q && F(q) && (FA = Q(q, e.height)), (mA = (FA = mA !== null && (!q || Wr(q)) ? lA && cA ? mA / a * g : e.height : FA) !== null && Wr(x) ? lA && cA ? FA / g * a : e.width : mA) !== null && FA !== null)
        return [mA, FA];
      throw new Error("Unable to calculate background-size for element");
    }, Jr = function(A, t) {
      return t = A[t], t === void 0 ? A[0] : t;
    }, ia = function(A, t, e, a, g) {
      var v = t[0], x = t[1], q = e[0], T = e[1];
      switch (A) {
        case 2:
          return [new OA(Math.round(a.left), Math.round(a.top + x)), new OA(Math.round(a.left + a.width), Math.round(a.top + x)), new OA(Math.round(a.left + a.width), Math.round(T + a.top + x)), new OA(Math.round(a.left), Math.round(T + a.top + x))];
        case 3:
          return [new OA(Math.round(a.left + v), Math.round(a.top)), new OA(Math.round(a.left + v + q), Math.round(a.top)), new OA(Math.round(a.left + v + q), Math.round(a.height + a.top)), new OA(Math.round(a.left + v), Math.round(a.height + a.top))];
        case 1:
          return [new OA(Math.round(a.left + v), Math.round(a.top + x)), new OA(Math.round(a.left + v + q), Math.round(a.top + x)), new OA(Math.round(a.left + v + q), Math.round(a.top + x + T)), new OA(Math.round(a.left + v), Math.round(a.top + x + T))];
        default:
          return [new OA(Math.round(g.left), Math.round(g.top)), new OA(Math.round(g.left + g.width), Math.round(g.top)), new OA(Math.round(g.left + g.width), Math.round(g.height + g.top)), new OA(Math.round(g.left), Math.round(g.height + g.top))];
      }
    }, Eo = "Hidden Text", oa = (li.prototype.parseMetrics = function(A, t) {
      var e = this._document.createElement("div"), a = this._document.createElement("img"), g = this._document.createElement("span"), v = this._document.body;
      return e.style.visibility = "hidden", e.style.fontFamily = A, e.style.fontSize = t, e.style.margin = "0", e.style.padding = "0", e.style.whiteSpace = "nowrap", v.appendChild(e), a.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", a.width = 1, a.height = 1, a.style.margin = "0", a.style.padding = "0", a.style.verticalAlign = "baseline", g.style.fontFamily = A, g.style.fontSize = t, g.style.margin = "0", g.style.padding = "0", g.appendChild(this._document.createTextNode(Eo)), e.appendChild(g), e.appendChild(a), t = a.offsetTop - g.offsetTop + 2, e.removeChild(g), e.appendChild(this._document.createTextNode(Eo)), e.style.lineHeight = "normal", a.style.verticalAlign = "super", a = a.offsetTop - e.offsetTop + 2, v.removeChild(e), { baseline: t, middle: a };
    }, li.prototype.getMetrics = function(A, t) {
      var e = A + " " + t;
      return this._data[e] === void 0 && (this._data[e] = this.parseMetrics(A, t)), this._data[e];
    }, li);
    function li(A) {
      this._data = {}, this._document = A;
    }
    var Ho, qA = function(A, t) {
      this.context = A, this.options = t;
    }, sa = (rA(Dt, Ho = qA), Dt.prototype.applyEffects = function(A) {
      for (var t = this; this._activeEffects.length; )
        this.popEffect();
      A.forEach(function(e) {
        return t.applyEffect(e);
      });
    }, Dt.prototype.applyEffect = function(A) {
      this.ctx.save(), A.type === 2 && (this.ctx.globalAlpha = A.opacity), A.type === 0 && (this.ctx.translate(A.offsetX, A.offsetY), this.ctx.transform(A.matrix[0], A.matrix[1], A.matrix[2], A.matrix[3], A.matrix[4], A.matrix[5]), this.ctx.translate(-A.offsetX, -A.offsetY)), yo(A) && (this.path(A.path), this.ctx.clip()), this._activeEffects.push(A);
    }, Dt.prototype.popEffect = function() {
      this._activeEffects.pop(), this.ctx.restore();
    }, Dt.prototype.renderStack = function(A) {
      return LA(this, void 0, void 0, function() {
        return kA(this, function(t) {
          switch (t.label) {
            case 0:
              return A.element.container.styles.isVisible() ? [4, this.renderStackContent(A)] : [3, 2];
            case 1:
              t.sent(), t.label = 2;
            case 2:
              return [2];
          }
        });
      });
    }, Dt.prototype.renderNode = function(A) {
      return LA(this, void 0, void 0, function() {
        return kA(this, function(t) {
          switch (t.label) {
            case 0:
              return wt(A.container.flags, 16), A.container.styles.isVisible() ? [4, this.renderNodeBackgroundAndBorders(A)] : [3, 3];
            case 1:
              return t.sent(), [4, this.renderNodeContent(A)];
            case 2:
              t.sent(), t.label = 3;
            case 3:
              return [2];
          }
        });
      });
    }, Dt.prototype.renderTextWithLetterSpacing = function(A, t, e) {
      var a = this;
      t === 0 ? this.ctx.fillText(A.text, A.bounds.left, A.bounds.top + e) : Jn(A.text).reduce(function(g, v) {
        return a.ctx.fillText(v, g, A.bounds.top + e), g + a.ctx.measureText(v).width;
      }, A.bounds.left);
    }, Dt.prototype.createFontStyle = function(A) {
      var t = A.fontVariant.filter(function(g) {
        return g === "normal" || g === "small-caps";
      }).join(""), e = ha(A.fontFamily).join(", "), a = V(A.fontSize) ? "" + A.fontSize.number + A.fontSize.unit : A.fontSize.number + "px";
      return [[A.fontStyle, t, A.fontWeight, a, e].join(" "), e, a];
    }, Dt.prototype.renderTextNode = function(A, t) {
      return LA(this, void 0, void 0, function() {
        var e, a, g, v, x, q, T = this;
        return kA(this, function(lA) {
          return g = this.createFontStyle(t), e = g[0], a = g[1], g = g[2], this.ctx.font = e, this.ctx.direction = t.direction === 1 ? "rtl" : "ltr", this.ctx.textAlign = "left", this.ctx.textBaseline = "alphabetic", g = this.fontMetrics.getMetrics(a, g), v = g.baseline, x = g.middle, q = t.paintOrder, A.textBounds.forEach(function(cA) {
            q.forEach(function(BA) {
              switch (BA) {
                case 0:
                  T.ctx.fillStyle = X(t.color), T.renderTextWithLetterSpacing(cA, t.letterSpacing, v);
                  var mA = t.textShadow;
                  mA.length && cA.text.trim().length && (mA.slice(0).reverse().forEach(function(FA) {
                    T.ctx.shadowColor = X(FA.color), T.ctx.shadowOffsetX = FA.offsetX.number * T.options.scale, T.ctx.shadowOffsetY = FA.offsetY.number * T.options.scale, T.ctx.shadowBlur = FA.blur.number, T.renderTextWithLetterSpacing(cA, t.letterSpacing, v);
                  }), T.ctx.shadowColor = "", T.ctx.shadowOffsetX = 0, T.ctx.shadowOffsetY = 0, T.ctx.shadowBlur = 0), t.textDecorationLine.length && (T.ctx.fillStyle = X(t.textDecorationColor || t.color), t.textDecorationLine.forEach(function(FA) {
                    switch (FA) {
                      case 1:
                        T.ctx.fillRect(cA.bounds.left, Math.round(cA.bounds.top + v), cA.bounds.width, 1);
                        break;
                      case 2:
                        T.ctx.fillRect(cA.bounds.left, Math.round(cA.bounds.top), cA.bounds.width, 1);
                        break;
                      case 3:
                        T.ctx.fillRect(cA.bounds.left, Math.ceil(cA.bounds.top + x), cA.bounds.width, 1);
                    }
                  }));
                  break;
                case 1:
                  t.webkitTextStrokeWidth && cA.text.trim().length && (T.ctx.strokeStyle = X(t.webkitTextStrokeColor), T.ctx.lineWidth = t.webkitTextStrokeWidth, T.ctx.lineJoin = window.chrome ? "miter" : "round", T.ctx.strokeText(cA.text, cA.bounds.left, cA.bounds.top + v)), T.ctx.strokeStyle = "", T.ctx.lineWidth = 0, T.ctx.lineJoin = "miter";
              }
            });
          }), [2];
        });
      });
    }, Dt.prototype.renderReplacedElement = function(A, t, e) {
      var a;
      e && 0 < A.intrinsicWidth && 0 < A.intrinsicHeight && (a = Kn(A), t = Dn(t), this.path(t), this.ctx.save(), this.ctx.clip(), this.ctx.drawImage(e, 0, 0, A.intrinsicWidth, A.intrinsicHeight, a.left, a.top, a.width, a.height), this.ctx.restore());
    }, Dt.prototype.renderNodeContent = function(A) {
      return LA(this, void 0, void 0, function() {
        var t, e, a, g, v, x, q, T, lA, cA, BA, mA;
        return kA(this, function(FA) {
          switch (FA.label) {
            case 0:
              this.applyEffects(A.getEffects(4)), t = A.container, e = A.curves, a = t.styles, g = 0, v = t.textNodes, FA.label = 1;
            case 1:
              return g < v.length ? (x = v[g], [4, this.renderTextNode(x, a)]) : [3, 4];
            case 2:
              FA.sent(), FA.label = 3;
            case 3:
              return g++, [3, 1];
            case 4:
              if (!(t instanceof ki))
                return [3, 8];
              FA.label = 5;
            case 5:
              return FA.trys.push([5, 7, , 8]), [4, this.context.cache.match(t.src)];
            case 6:
              return lA = FA.sent(), this.renderReplacedElement(t, e, lA), [3, 8];
            case 7:
              return FA.sent(), this.context.logger.error("Error loading image " + t.src), [3, 8];
            case 8:
              if (t instanceof Ti && this.renderReplacedElement(t, e, t.canvas), !(t instanceof Oi))
                return [3, 12];
              FA.label = 9;
            case 9:
              return FA.trys.push([9, 11, , 12]), [4, this.context.cache.match(t.svg)];
            case 10:
              return lA = FA.sent(), this.renderReplacedElement(t, e, lA), [3, 12];
            case 11:
              return FA.sent(), this.context.logger.error("Error loading svg " + t.svg.substring(0, 255)), [3, 12];
            case 12:
              return t instanceof to && t.tree ? [4, new Dt(this.context, { scale: this.options.scale, backgroundColor: t.backgroundColor, x: 0, y: 0, width: t.width, height: t.height }).render(t.tree)] : [3, 14];
            case 13:
              x = FA.sent(), t.width && t.height && this.ctx.drawImage(x, 0, 0, t.width, t.height, t.bounds.left, t.bounds.top, t.bounds.width, t.bounds.height), FA.label = 14;
            case 14:
              if (t instanceof Yn && (T = Math.min(t.bounds.width, t.bounds.height), t.type === bn ? t.checked && (this.ctx.save(), this.path([new OA(t.bounds.left + 0.39363 * T, t.bounds.top + 0.79 * T), new OA(t.bounds.left + 0.16 * T, t.bounds.top + 0.5549 * T), new OA(t.bounds.left + 0.27347 * T, t.bounds.top + 0.44071 * T), new OA(t.bounds.left + 0.39694 * T, t.bounds.top + 0.5649 * T), new OA(t.bounds.left + 0.72983 * T, t.bounds.top + 0.23 * T), new OA(t.bounds.left + 0.84 * T, t.bounds.top + 0.34085 * T), new OA(t.bounds.left + 0.39363 * T, t.bounds.top + 0.79 * T)]), this.ctx.fillStyle = X(ji), this.ctx.fill(), this.ctx.restore()) : t.type === xn && t.checked && (this.ctx.save(), this.ctx.beginPath(), this.ctx.arc(t.bounds.left + T / 2, t.bounds.top + T / 2, T / 4, 0, 2 * Math.PI, !0), this.ctx.fillStyle = X(ji), this.ctx.fill(), this.ctx.restore())), aa(t) && t.value.length) {
                switch (cA = this.createFontStyle(a), BA = cA[0], T = cA[1], cA = this.fontMetrics.getMetrics(BA, T).baseline, this.ctx.font = BA, this.ctx.fillStyle = X(a.color), this.ctx.textBaseline = "alphabetic", this.ctx.textAlign = la(t.styles.textAlign), mA = Kn(t), q = 0, t.styles.textAlign) {
                  case 1:
                    q += mA.width / 2;
                    break;
                  case 2:
                    q += mA.width;
                }
                T = mA.add(q, 0, 0, -mA.height / 2 + 1), this.ctx.save(), this.path([new OA(mA.left, mA.top), new OA(mA.left + mA.width, mA.top), new OA(mA.left + mA.width, mA.top + mA.height), new OA(mA.left, mA.top + mA.height)]), this.ctx.clip(), this.renderTextWithLetterSpacing(new an(t.value, T), a.letterSpacing, cA), this.ctx.restore(), this.ctx.textBaseline = "alphabetic", this.ctx.textAlign = "left";
              }
              if (!wt(t.styles.display, 2048))
                return [3, 20];
              if (t.styles.listStyleImage === null)
                return [3, 19];
              if ((cA = t.styles.listStyleImage).type !== 0)
                return [3, 18];
              lA = void 0, cA = cA.url, FA.label = 15;
            case 15:
              return FA.trys.push([15, 17, , 18]), [4, this.context.cache.match(cA)];
            case 16:
              return lA = FA.sent(), this.ctx.drawImage(lA, t.bounds.left - (lA.width + 10), t.bounds.top), [3, 18];
            case 17:
              return FA.sent(), this.context.logger.error("Error loading list-style-image " + cA), [3, 18];
            case 18:
              return [3, 20];
            case 19:
              A.listValue && t.styles.listStyleType !== -1 && (BA = this.createFontStyle(a)[0], this.ctx.font = BA, this.ctx.fillStyle = X(a.color), this.ctx.textBaseline = "middle", this.ctx.textAlign = "right", mA = new XA(t.bounds.left, t.bounds.top + Q(t.styles.paddingTop, t.bounds.width), t.bounds.width, gA(a.lineHeight, a.fontSize.number) / 2 + 1), this.renderTextWithLetterSpacing(new an(A.listValue, mA), a.letterSpacing, gA(a.lineHeight, a.fontSize.number) / 2 + 2), this.ctx.textBaseline = "bottom", this.ctx.textAlign = "left"), FA.label = 20;
            case 20:
              return [2];
          }
        });
      });
    }, Dt.prototype.renderStackContent = function(A) {
      return LA(this, void 0, void 0, function() {
        var t, e, a, g, v, x, q, T, lA, cA, BA, mA, FA, MA, DA;
        return kA(this, function(IA) {
          switch (IA.label) {
            case 0:
              return wt(A.element.container.flags, 16), [4, this.renderNodeBackgroundAndBorders(A.element)];
            case 1:
              IA.sent(), t = 0, e = A.negativeZIndex, IA.label = 2;
            case 2:
              return t < e.length ? (DA = e[t], [4, this.renderStack(DA)]) : [3, 5];
            case 3:
              IA.sent(), IA.label = 4;
            case 4:
              return t++, [3, 2];
            case 5:
              return [4, this.renderNodeContent(A.element)];
            case 6:
              IA.sent(), a = 0, g = A.nonInlineLevel, IA.label = 7;
            case 7:
              return a < g.length ? (DA = g[a], [4, this.renderNode(DA)]) : [3, 10];
            case 8:
              IA.sent(), IA.label = 9;
            case 9:
              return a++, [3, 7];
            case 10:
              v = 0, x = A.nonPositionedFloats, IA.label = 11;
            case 11:
              return v < x.length ? (DA = x[v], [4, this.renderStack(DA)]) : [3, 14];
            case 12:
              IA.sent(), IA.label = 13;
            case 13:
              return v++, [3, 11];
            case 14:
              q = 0, T = A.nonPositionedInlineLevel, IA.label = 15;
            case 15:
              return q < T.length ? (DA = T[q], [4, this.renderStack(DA)]) : [3, 18];
            case 16:
              IA.sent(), IA.label = 17;
            case 17:
              return q++, [3, 15];
            case 18:
              lA = 0, cA = A.inlineLevel, IA.label = 19;
            case 19:
              return lA < cA.length ? (DA = cA[lA], [4, this.renderNode(DA)]) : [3, 22];
            case 20:
              IA.sent(), IA.label = 21;
            case 21:
              return lA++, [3, 19];
            case 22:
              BA = 0, mA = A.zeroOrAutoZIndexOrTransformedOrOpacity, IA.label = 23;
            case 23:
              return BA < mA.length ? (DA = mA[BA], [4, this.renderStack(DA)]) : [3, 26];
            case 24:
              IA.sent(), IA.label = 25;
            case 25:
              return BA++, [3, 23];
            case 26:
              FA = 0, MA = A.positiveZIndex, IA.label = 27;
            case 27:
              return FA < MA.length ? (DA = MA[FA], [4, this.renderStack(DA)]) : [3, 30];
            case 28:
              IA.sent(), IA.label = 29;
            case 29:
              return FA++, [3, 27];
            case 30:
              return [2];
          }
        });
      });
    }, Dt.prototype.mask = function(A) {
      this.ctx.beginPath(), this.ctx.moveTo(0, 0), this.ctx.lineTo(this.canvas.width, 0), this.ctx.lineTo(this.canvas.width, this.canvas.height), this.ctx.lineTo(0, this.canvas.height), this.ctx.lineTo(0, 0), this.formatPath(A.slice(0).reverse()), this.ctx.closePath();
    }, Dt.prototype.path = function(A) {
      this.ctx.beginPath(), this.formatPath(A), this.ctx.closePath();
    }, Dt.prototype.formatPath = function(A) {
      var t = this;
      A.forEach(function(e, a) {
        var g = Me(e) ? e.start : e;
        a === 0 ? t.ctx.moveTo(g.x, g.y) : t.ctx.lineTo(g.x, g.y), Me(e) && t.ctx.bezierCurveTo(e.startControl.x, e.startControl.y, e.endControl.x, e.endControl.y, e.end.x, e.end.y);
      });
    }, Dt.prototype.renderRepeat = function(A, t, e, a) {
      this.path(A), this.ctx.fillStyle = t, this.ctx.translate(e, a), this.ctx.fill(), this.ctx.translate(-e, -a);
    }, Dt.prototype.resizeImage = function(A, t, e) {
      if (A.width === t && A.height === e)
        return A;
      var a = ((a = this.canvas.ownerDocument) !== null && a !== void 0 ? a : document).createElement("canvas");
      return a.width = Math.max(1, t), a.height = Math.max(1, e), a.getContext("2d").drawImage(A, 0, 0, A.width, A.height, 0, 0, t, e), a;
    }, Dt.prototype.renderBackgroundImage = function(A) {
      return LA(this, void 0, void 0, function() {
        var t, e, a, g, v, x;
        return kA(this, function(q) {
          switch (q.label) {
            case 0:
              t = A.styles.backgroundImage.length - 1, e = function(T) {
                var lA, cA, BA, mA, FA, MA, DA, IA, zA, RA, GA, It, NA, Qt, jt, de, Wt;
                return kA(this, function(zr) {
                  switch (zr.label) {
                    case 0:
                      if (T.type !== 0)
                        return [3, 5];
                      lA = void 0, cA = T.url, zr.label = 1;
                    case 1:
                      return zr.trys.push([1, 3, , 4]), [4, a.context.cache.match(cA)];
                    case 2:
                      return lA = zr.sent(), [3, 4];
                    case 3:
                      return zr.sent(), a.context.logger.error("Error loading background-image " + cA), [3, 4];
                    case 4:
                      return lA && (BA = ai(A, t, [lA.width, lA.height, lA.width / lA.height]), MA = BA[0], GA = BA[1], It = BA[2], zA = BA[3], RA = BA[4], FA = a.ctx.createPattern(a.resizeImage(lA, zA, RA), "repeat"), a.renderRepeat(MA, FA, GA, It)), [3, 6];
                    case 5:
                      T.type === 1 ? (Wt = ai(A, t, [null, null, null]), MA = Wt[0], GA = Wt[1], It = Wt[2], zA = Wt[3], RA = Wt[4], jt = xA(T.angle, zA, RA), Qt = jt[0], BA = jt[1], DA = jt[2], de = jt[3], IA = jt[4], (Wt = document.createElement("canvas")).width = zA, Wt.height = RA, jt = Wt.getContext("2d"), mA = jt.createLinearGradient(BA, de, DA, IA), SA(T.stops, Qt).forEach(function(re) {
                        return mA.addColorStop(re.stop, X(re.color));
                      }), jt.fillStyle = mA, jt.fillRect(0, 0, zA, RA), 0 < zA && 0 < RA && (FA = a.ctx.createPattern(Wt, "repeat"), a.renderRepeat(MA, FA, GA, It))) : T.type === 2 && (de = ai(A, t, [null, null, null]), MA = de[0], DA = de[1], IA = de[2], zA = de[3], RA = de[4], Qt = T.position.length === 0 ? [D] : T.position, GA = Q(Qt[0], zA), It = Q(Qt[Qt.length - 1], RA), jt = function(re, Nt, Gt, Ie, Ee) {
                        var Yr, Pn, Mn, Rn, ze = 0, sr = 0;
                        switch (re.size) {
                          case 0:
                            re.shape === 0 ? ze = sr = Math.min(Math.abs(Nt), Math.abs(Nt - Ie), Math.abs(Gt), Math.abs(Gt - Ee)) : re.shape === 1 && (ze = Math.min(Math.abs(Nt), Math.abs(Nt - Ie)), sr = Math.min(Math.abs(Gt), Math.abs(Gt - Ee)));
                            break;
                          case 2:
                            re.shape === 0 ? ze = sr = Math.min(KA(Nt, Gt), KA(Nt, Gt - Ee), KA(Nt - Ie, Gt), KA(Nt - Ie, Gt - Ee)) : re.shape === 1 && (Yr = Math.min(Math.abs(Gt), Math.abs(Gt - Ee)) / Math.min(Math.abs(Nt), Math.abs(Nt - Ie)), Mn = (Pn = iA(Ie, Ee, Nt, Gt, !0))[0], Rn = Pn[1], sr = Yr * (ze = KA(Mn - Nt, (Rn - Gt) / Yr)));
                            break;
                          case 1:
                            re.shape === 0 ? ze = sr = Math.max(Math.abs(Nt), Math.abs(Nt - Ie), Math.abs(Gt), Math.abs(Gt - Ee)) : re.shape === 1 && (ze = Math.max(Math.abs(Nt), Math.abs(Nt - Ie)), sr = Math.max(Math.abs(Gt), Math.abs(Gt - Ee)));
                            break;
                          case 3:
                            re.shape === 0 ? ze = sr = Math.max(KA(Nt, Gt), KA(Nt, Gt - Ee), KA(Nt - Ie, Gt), KA(Nt - Ie, Gt - Ee)) : re.shape === 1 && (Yr = Math.max(Math.abs(Gt), Math.abs(Gt - Ee)) / Math.max(Math.abs(Nt), Math.abs(Nt - Ie)), Mn = (Pn = iA(Ie, Ee, Nt, Gt, !1))[0], Rn = Pn[1], sr = Yr * (ze = KA(Mn - Nt, (Rn - Gt) / Yr)));
                        }
                        return Array.isArray(re.size) && (ze = Q(re.size[0], Ie), sr = re.size.length === 2 ? Q(re.size[1], Ee) : ze), [ze, sr];
                      }(T, GA, It, zA, RA), Wt = jt[0], de = jt[1], 0 < Wt && 0 < de && (NA = a.ctx.createRadialGradient(DA + GA, IA + It, 0, DA + GA, IA + It, Wt), SA(T.stops, 2 * Wt).forEach(function(re) {
                        return NA.addColorStop(re.stop, X(re.color));
                      }), a.path(MA), a.ctx.fillStyle = NA, Wt !== de ? (Qt = A.bounds.left + 0.5 * A.bounds.width, jt = A.bounds.top + 0.5 * A.bounds.height, Wt = 1 / (de = de / Wt), a.ctx.save(), a.ctx.translate(Qt, jt), a.ctx.transform(1, 0, 0, de, 0, 0), a.ctx.translate(-Qt, -jt), a.ctx.fillRect(DA, Wt * (IA - jt) + jt, zA, RA * Wt), a.ctx.restore()) : a.ctx.fill())), zr.label = 6;
                    case 6:
                      return t--, [2];
                  }
                });
              }, a = this, g = 0, v = A.styles.backgroundImage.slice(0).reverse(), q.label = 1;
            case 1:
              return g < v.length ? (x = v[g], [5, e(x)]) : [3, 4];
            case 2:
              q.sent(), q.label = 3;
            case 3:
              return g++, [3, 1];
            case 4:
              return [2];
          }
        });
      });
    }, Dt.prototype.renderSolidBorder = function(A, t, e) {
      return LA(this, void 0, void 0, function() {
        return kA(this, function(a) {
          return this.path(bo(e, t)), this.ctx.fillStyle = X(A), this.ctx.fill(), [2];
        });
      });
    }, Dt.prototype.renderDoubleBorder = function(A, t, e, a) {
      return LA(this, void 0, void 0, function() {
        var g;
        return kA(this, function(v) {
          switch (v.label) {
            case 0:
              return t < 3 ? [4, this.renderSolidBorder(A, e, a)] : [3, 2];
            case 1:
              return v.sent(), [2];
            case 2:
              return g = function(x, q) {
                switch (q) {
                  case 0:
                    return Re(x.topLeftBorderBox, x.topLeftBorderDoubleOuterBox, x.topRightBorderBox, x.topRightBorderDoubleOuterBox);
                  case 1:
                    return Re(x.topRightBorderBox, x.topRightBorderDoubleOuterBox, x.bottomRightBorderBox, x.bottomRightBorderDoubleOuterBox);
                  case 2:
                    return Re(x.bottomRightBorderBox, x.bottomRightBorderDoubleOuterBox, x.bottomLeftBorderBox, x.bottomLeftBorderDoubleOuterBox);
                  default:
                    return Re(x.bottomLeftBorderBox, x.bottomLeftBorderDoubleOuterBox, x.topLeftBorderBox, x.topLeftBorderDoubleOuterBox);
                }
              }(a, e), this.path(g), this.ctx.fillStyle = X(A), this.ctx.fill(), g = function(x, q) {
                switch (q) {
                  case 0:
                    return Re(x.topLeftBorderDoubleInnerBox, x.topLeftPaddingBox, x.topRightBorderDoubleInnerBox, x.topRightPaddingBox);
                  case 1:
                    return Re(x.topRightBorderDoubleInnerBox, x.topRightPaddingBox, x.bottomRightBorderDoubleInnerBox, x.bottomRightPaddingBox);
                  case 2:
                    return Re(x.bottomRightBorderDoubleInnerBox, x.bottomRightPaddingBox, x.bottomLeftBorderDoubleInnerBox, x.bottomLeftPaddingBox);
                  default:
                    return Re(x.bottomLeftBorderDoubleInnerBox, x.bottomLeftPaddingBox, x.topLeftBorderDoubleInnerBox, x.topLeftPaddingBox);
                }
              }(a, e), this.path(g), this.ctx.fill(), [2];
          }
        });
      });
    }, Dt.prototype.renderNodeBackgroundAndBorders = function(A) {
      return LA(this, void 0, void 0, function() {
        var t, e, a, g, v, x, q, T, lA = this;
        return kA(this, function(cA) {
          switch (cA.label) {
            case 0:
              return this.applyEffects(A.getEffects(2)), t = A.container.styles, e = !oA(t.backgroundColor) || t.backgroundImage.length, a = [{ style: t.borderTopStyle, color: t.borderTopColor, width: t.borderTopWidth }, { style: t.borderRightStyle, color: t.borderRightColor, width: t.borderRightWidth }, { style: t.borderBottomStyle, color: t.borderBottomColor, width: t.borderBottomWidth }, { style: t.borderLeftStyle, color: t.borderLeftColor, width: t.borderLeftWidth }], g = ca(Jr(t.backgroundClip, 0), A.curves), e || t.boxShadow.length ? (this.ctx.save(), this.path(g), this.ctx.clip(), oA(t.backgroundColor) || (this.ctx.fillStyle = X(t.backgroundColor), this.ctx.fill()), [4, this.renderBackgroundImage(A.container)]) : [3, 2];
            case 1:
              cA.sent(), this.ctx.restore(), t.boxShadow.slice(0).reverse().forEach(function(BA) {
                lA.ctx.save();
                var mA, FA, MA, DA, IA = Ln(A.curves), zA = BA.inset ? 0 : 1e4, RA = (mA = -zA + (BA.inset ? 1 : -1) * BA.spread.number, FA = (BA.inset ? 1 : -1) * BA.spread.number, MA = BA.spread.number * (BA.inset ? -2 : 2), DA = BA.spread.number * (BA.inset ? -2 : 2), IA.map(function(GA, It) {
                  switch (It) {
                    case 0:
                      return GA.add(mA, FA);
                    case 1:
                      return GA.add(mA + MA, FA);
                    case 2:
                      return GA.add(mA + MA, FA + DA);
                    case 3:
                      return GA.add(mA, FA + DA);
                  }
                  return GA;
                }));
                BA.inset ? (lA.path(IA), lA.ctx.clip(), lA.mask(RA)) : (lA.mask(IA), lA.ctx.clip(), lA.path(RA)), lA.ctx.shadowOffsetX = BA.offsetX.number + zA, lA.ctx.shadowOffsetY = BA.offsetY.number, lA.ctx.shadowColor = X(BA.color), lA.ctx.shadowBlur = BA.blur.number, lA.ctx.fillStyle = BA.inset ? X(BA.color) : "rgba(0,0,0,1)", lA.ctx.fill(), lA.ctx.restore();
              }), cA.label = 2;
            case 2:
              x = v = 0, q = a, cA.label = 3;
            case 3:
              return x < q.length ? (T = q[x]).style !== 0 && !oA(T.color) && 0 < T.width ? T.style !== 2 ? [3, 5] : [4, this.renderDashedDottedBorder(T.color, T.width, v, A.curves, 2)] : [3, 11] : [3, 13];
            case 4:
              return cA.sent(), [3, 11];
            case 5:
              return T.style !== 3 ? [3, 7] : [4, this.renderDashedDottedBorder(T.color, T.width, v, A.curves, 3)];
            case 6:
              return cA.sent(), [3, 11];
            case 7:
              return T.style !== 4 ? [3, 9] : [4, this.renderDoubleBorder(T.color, T.width, v, A.curves)];
            case 8:
              return cA.sent(), [3, 11];
            case 9:
              return [4, this.renderSolidBorder(T.color, v, A.curves)];
            case 10:
              cA.sent(), cA.label = 11;
            case 11:
              v++, cA.label = 12;
            case 12:
              return x++, [3, 3];
            case 13:
              return [2];
          }
        });
      });
    }, Dt.prototype.renderDashedDottedBorder = function(A, t, e, a, g) {
      return LA(this, void 0, void 0, function() {
        var v, x, q, T, lA, cA, BA, mA, FA, MA, DA;
        return kA(this, function(IA) {
          return this.ctx.save(), FA = function(zA, RA) {
            switch (RA) {
              case 0:
                return On(zA.topLeftBorderStroke, zA.topRightBorderStroke);
              case 1:
                return On(zA.topRightBorderStroke, zA.bottomRightBorderStroke);
              case 2:
                return On(zA.bottomRightBorderStroke, zA.bottomLeftBorderStroke);
              default:
                return On(zA.bottomLeftBorderStroke, zA.topLeftBorderStroke);
            }
          }(a, e), v = bo(a, e), g === 2 && (this.path(v), this.ctx.clip()), cA = Me(v[0]) ? (x = v[0].start.x, v[0].start.y) : (x = v[0].x, v[0].y), BA = Me(v[1]) ? (q = v[1].end.x, v[1].end.y) : (q = v[1].x, v[1].y), T = Math.abs(e === 0 || e === 2 ? x - q : cA - BA), this.ctx.beginPath(), g === 3 ? this.formatPath(FA) : this.formatPath(v.slice(0, 2)), lA = t < 3 ? 3 * t : 2 * t, cA = t < 3 ? 2 * t : t, g === 3 && (cA = lA = t), BA = !0, T <= 2 * lA ? BA = !1 : T <= 2 * lA + cA ? (lA *= mA = T / (2 * lA + cA), cA *= mA) : (FA = Math.floor((T + cA) / (lA + cA)), mA = (T - FA * lA) / (FA - 1), cA = (FA = (T - (FA + 1) * lA) / FA) <= 0 || Math.abs(cA - mA) < Math.abs(cA - FA) ? mA : FA), BA && (g === 3 ? this.ctx.setLineDash([0, lA + cA]) : this.ctx.setLineDash([lA, cA])), g === 3 ? (this.ctx.lineCap = "round", this.ctx.lineWidth = t) : this.ctx.lineWidth = 2 * t + 1.1, this.ctx.strokeStyle = X(A), this.ctx.stroke(), this.ctx.setLineDash([]), g === 2 && (Me(v[0]) && (MA = v[3], DA = v[0], this.ctx.beginPath(), this.formatPath([new OA(MA.end.x, MA.end.y), new OA(DA.start.x, DA.start.y)]), this.ctx.stroke()), Me(v[1]) && (MA = v[1], DA = v[2], this.ctx.beginPath(), this.formatPath([new OA(MA.end.x, MA.end.y), new OA(DA.start.x, DA.start.y)]), this.ctx.stroke())), this.ctx.restore(), [2];
        });
      });
    }, Dt.prototype.render = function(A) {
      return LA(this, void 0, void 0, function() {
        return kA(this, function(t) {
          switch (t.label) {
            case 0:
              return this.options.backgroundColor && (this.ctx.fillStyle = X(this.options.backgroundColor), this.ctx.fillRect(this.options.x, this.options.y, this.options.width, this.options.height)), a = new Uo(e = A, null), g = new Fo(a), ci(a, g, g, e = []), Io(a.container, e), [4, this.renderStack(g)];
            case 1:
              return t.sent(), this.applyEffects([]), [2, this.canvas];
          }
          var e, a, g;
        });
      });
    }, Dt);
    function Dt(A, t) {
      return A = Ho.call(this, A, t) || this, A._activeEffects = [], A.canvas = t.canvas || document.createElement("canvas"), A.ctx = A.canvas.getContext("2d"), t.canvas || (A.canvas.width = Math.floor(t.width * t.scale), A.canvas.height = Math.floor(t.height * t.scale), A.canvas.style.width = t.width + "px", A.canvas.style.height = t.height + "px"), A.fontMetrics = new oa(document), A.ctx.scale(A.options.scale, A.options.scale), A.ctx.translate(-t.x, -t.y), A.ctx.textBaseline = "bottom", A._activeEffects = [], A.context.logger.debug("Canvas renderer initialized (" + t.width + "x" + t.height + ") with scale " + t.scale), A;
    }
    var So, aa = function(A) {
      return A instanceof Zi || A instanceof Ji || A instanceof Yn && A.type !== xn && A.type !== bn;
    }, ca = function(A, t) {
      switch (A) {
        case 0:
          return Ln(t);
        case 2:
          return [t.topLeftContentBox, t.topRightContentBox, t.bottomRightContentBox, t.bottomLeftContentBox];
        default:
          return Dn(t);
      }
    }, la = function(A) {
      switch (A) {
        case 1:
          return "center";
        case 2:
          return "right";
        default:
          return "left";
      }
    }, ua = ["-apple-system", "system-ui"], ha = function(A) {
      return /iPhone OS 15_(0|1)/.test(window.navigator.userAgent) ? A.filter(function(t) {
        return ua.indexOf(t) === -1;
      }) : A;
    }, fa = (rA(ui, So = qA), ui.prototype.render = function(A) {
      return LA(this, void 0, void 0, function() {
        var t;
        return kA(this, function(e) {
          switch (e.label) {
            case 0:
              return t = Wn(this.options.width * this.options.scale, this.options.height * this.options.scale, this.options.scale, this.options.scale, A), [4, da(t)];
            case 1:
              return t = e.sent(), this.options.backgroundColor && (this.ctx.fillStyle = X(this.options.backgroundColor), this.ctx.fillRect(0, 0, this.options.width * this.options.scale, this.options.height * this.options.scale)), this.ctx.drawImage(t, -this.options.x * this.options.scale, -this.options.y * this.options.scale), [2, this.canvas];
          }
        });
      });
    }, ui);
    function ui(A, t) {
      return A = So.call(this, A, t) || this, A.canvas = t.canvas || document.createElement("canvas"), A.ctx = A.canvas.getContext("2d"), A.options = t, A.canvas.width = Math.floor(t.width * t.scale), A.canvas.height = Math.floor(t.height * t.scale), A.canvas.style.width = t.width + "px", A.canvas.style.height = t.height + "px", A.ctx.scale(A.options.scale, A.options.scale), A.ctx.translate(-t.x, -t.y), A.context.logger.debug("EXPERIMENTAL ForeignObject renderer initialized (" + t.width + "x" + t.height + " at " + t.x + "," + t.y + ") with scale " + t.scale), A;
    }
    var da = function(A) {
      return new Promise(function(t, e) {
        var a = new Image();
        a.onload = function() {
          t(a);
        }, a.onerror = e, a.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(A));
      });
    }, ga = (Dr.prototype.debug = function() {
      for (var A = [], t = 0; t < arguments.length; t++)
        A[t] = arguments[t];
      this.enabled && (typeof window < "u" && window.console && typeof console.debug == "function" ? console.debug.apply(console, ZA([this.id, this.getTime() + "ms"], A)) : this.info.apply(this, A));
    }, Dr.prototype.getTime = function() {
      return Date.now() - this.start;
    }, Dr.prototype.info = function() {
      for (var A = [], t = 0; t < arguments.length; t++)
        A[t] = arguments[t];
      this.enabled && typeof window < "u" && window.console && typeof console.info == "function" && console.info.apply(console, ZA([this.id, this.getTime() + "ms"], A));
    }, Dr.prototype.warn = function() {
      for (var A = [], t = 0; t < arguments.length; t++)
        A[t] = arguments[t];
      this.enabled && (typeof window < "u" && window.console && typeof console.warn == "function" ? console.warn.apply(console, ZA([this.id, this.getTime() + "ms"], A)) : this.info.apply(this, A));
    }, Dr.prototype.error = function() {
      for (var A = [], t = 0; t < arguments.length; t++)
        A[t] = arguments[t];
      this.enabled && (typeof window < "u" && window.console && typeof console.error == "function" ? console.error.apply(console, ZA([this.id, this.getTime() + "ms"], A)) : this.info.apply(this, A));
    }, Dr.instances = {}, Dr);
    function Dr(e) {
      var t = e.id, e = e.enabled;
      this.id = t, this.enabled = e, this.start = Date.now();
    }
    var pa = (hi.instanceCount = 1, hi);
    function hi(A, t) {
      this.windowBounds = t, this.instanceName = "#" + hi.instanceCount++, this.logger = new ga({ id: this.instanceName, enabled: A.logging }), this.cache = (t = A.cache) !== null && t !== void 0 ? t : new Ws(this, A);
    }
    typeof window < "u" && Co.setContext(window);
    var Ba = function(A, t) {
      return LA(void 0, void 0, void 0, function() {
        var e, a, g, v, x, q, T, lA, cA, BA, mA, FA, MA, DA, IA, zA;
        return kA(this, function(RA) {
          switch (RA.label) {
            case 0:
              if (!A || typeof A != "object")
                return [2, Promise.reject("Invalid element provided as first argument")];
              if (!(e = A.ownerDocument))
                throw new Error("Element is not attached to a Document");
              if (!(a = e.defaultView))
                throw new Error("Document is not attached to a Window");
              return MA = { allowTaint: (DA = t.allowTaint) !== null && DA !== void 0 && DA, imageTimeout: (BA = t.imageTimeout) !== null && BA !== void 0 ? BA : 15e3, proxy: t.proxy, useCORS: (mA = t.useCORS) !== null && mA !== void 0 && mA }, DA = vA({ logging: (FA = t.logging) === null || FA === void 0 || FA, cache: t.cache }, MA), BA = { windowWidth: (BA = t.windowWidth) !== null && BA !== void 0 ? BA : a.innerWidth, windowHeight: (mA = t.windowHeight) !== null && mA !== void 0 ? mA : a.innerHeight, scrollX: (FA = t.scrollX) !== null && FA !== void 0 ? FA : a.pageXOffset, scrollY: (MA = t.scrollY) !== null && MA !== void 0 ? MA : a.pageYOffset }, mA = new XA(BA.scrollX, BA.scrollY, BA.windowWidth, BA.windowHeight), FA = new pa(DA, mA), BA = (MA = t.foreignObjectRendering) !== null && MA !== void 0 && MA, MA = { allowTaint: (DA = t.allowTaint) !== null && DA !== void 0 && DA, onclone: t.onclone, ignoreElements: t.ignoreElements, inlineImages: BA, copyStyles: BA }, FA.logger.debug("Starting document clone with size " + mA.width + "x" + mA.height + " scrolled to " + -mA.left + "," + -mA.top), DA = new wo(FA, A, MA), (MA = DA.clonedReferenceElement) ? [4, DA.toIFrame(e, mA)] : [2, Promise.reject("Unable to find element in cloned iframe")];
            case 1:
              return g = RA.sent(), IA = $n(MA) || MA.tagName === "HTML" ? function(GA) {
                var It = GA.body, NA = GA.documentElement;
                if (!It || !NA)
                  throw new Error("Unable to get document size");
                return GA = Math.max(Math.max(It.scrollWidth, NA.scrollWidth), Math.max(It.offsetWidth, NA.offsetWidth), Math.max(It.clientWidth, NA.clientWidth)), NA = Math.max(Math.max(It.scrollHeight, NA.scrollHeight), Math.max(It.offsetHeight, NA.offsetHeight), Math.max(It.clientHeight, NA.clientHeight)), new XA(0, 0, GA, NA);
              }(MA.ownerDocument) : pt(FA, MA), v = IA.width, x = IA.height, q = IA.left, T = IA.top, lA = wa(FA, MA, t.backgroundColor), IA = { canvas: t.canvas, backgroundColor: lA, scale: (IA = (IA = t.scale) !== null && IA !== void 0 ? IA : a.devicePixelRatio) !== null && IA !== void 0 ? IA : 1, x: ((IA = t.x) !== null && IA !== void 0 ? IA : 0) + q, y: ((IA = t.y) !== null && IA !== void 0 ? IA : 0) + T, width: (IA = t.width) !== null && IA !== void 0 ? IA : Math.ceil(v), height: (IA = t.height) !== null && IA !== void 0 ? IA : Math.ceil(x) }, BA ? (FA.logger.debug("Document cloned, using foreign object rendering"), [4, new fa(FA, IA).render(MA)]) : [3, 3];
            case 2:
              return cA = RA.sent(), [3, 5];
            case 3:
              return FA.logger.debug("Document cloned, element located at " + q + "," + T + " with size " + v + "x" + x + " using computed rendering"), FA.logger.debug("Starting DOM parsing"), zA = so(FA, MA), lA === zA.styles.backgroundColor && (zA.styles.backgroundColor = $A.TRANSPARENT), FA.logger.debug("Starting renderer for element at " + IA.x + "," + IA.y + " with size " + IA.width + "x" + IA.height), [4, new sa(FA, IA).render(zA)];
            case 4:
              cA = RA.sent(), RA.label = 5;
            case 5:
              return (zA = t.removeContainer) !== null && zA !== void 0 && !zA || wo.destroy(g) || FA.logger.error("Cannot detach cloned iframe as it is not in the DOM anymore"), FA.logger.debug("Finished rendering"), [2, cA];
          }
        });
      });
    }, wa = function(A, t, x) {
      var a = t.ownerDocument, g = a.documentElement ? yA(A, getComputedStyle(a.documentElement).backgroundColor) : $A.TRANSPARENT, v = a.body ? yA(A, getComputedStyle(a.body).backgroundColor) : $A.TRANSPARENT, x = typeof x == "string" ? yA(A, x) : x === null ? $A.TRANSPARENT : 4294967295;
      return t === a.documentElement ? oA(g) ? oA(v) ? x : v : g : x;
    };
    return function(A, t) {
      return Ba(A, t = t === void 0 ? {} : t);
    };
  });
})(Vo);
var Pa = Vo.exports;
const Ma = /* @__PURE__ */ Ro(Pa);
var qo = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(CA) {
  return typeof CA;
} : function(CA) {
  return CA && typeof Symbol == "function" && CA.constructor === Symbol && CA !== Symbol.prototype ? "symbol" : typeof CA;
}, mi = Object.assign || function(CA) {
  for (var J = 1; J < arguments.length; J++) {
    var uA = arguments[J];
    for (var rA in uA)
      Object.prototype.hasOwnProperty.call(uA, rA) && (CA[rA] = uA[rA]);
  }
  return CA;
}, Gn = function(J) {
  var uA = typeof J > "u" ? "undefined" : qo(J);
  return uA === "undefined" ? "undefined" : uA === "string" || J instanceof String ? "string" : uA === "number" || J instanceof Number ? "number" : uA === "function" || J instanceof Function ? "function" : J && J.constructor === Array ? "array" : J && J.nodeType === 1 ? "element" : uA === "object" ? "object" : "unknown";
}, gn = function(J, uA) {
  var rA = document.createElement(J);
  if (uA.className && (rA.className = uA.className), uA.innerHTML) {
    rA.innerHTML = uA.innerHTML;
    for (var vA = rA.getElementsByTagName("script"), LA = vA.length; LA-- > 0; null)
      vA[LA].parentNode.removeChild(vA[LA]);
  }
  for (var kA in uA.style)
    rA.style[kA] = uA.style[kA];
  return rA;
}, Ra = function CA(J, uA) {
  for (var rA = J.nodeType === 3 ? document.createTextNode(J.nodeValue) : J.cloneNode(!1), vA = J.firstChild; vA; vA = vA.nextSibling)
    (uA === !0 || vA.nodeType !== 1 || vA.nodeName !== "SCRIPT") && rA.appendChild(CA(vA, uA));
  return J.nodeType === 1 && (J.nodeName === "CANVAS" ? (rA.width = J.width, rA.height = J.height, rA.getContext("2d").drawImage(J, 0, 0)) : (J.nodeName === "TEXTAREA" || J.nodeName === "SELECT") && (rA.value = J.value), rA.addEventListener("load", function() {
    rA.scrollTop = J.scrollTop, rA.scrollLeft = J.scrollLeft;
  }, !0)), rA;
}, Ko = function(J, uA) {
  if (Gn(J) === "number")
    return J * 72 / 96 / uA;
  var rA = {};
  for (var vA in J)
    rA[vA] = J[vA] * 72 / 96 / uA;
  return rA;
}, _o = function(J, uA) {
  return Math.floor(J * uA / 72 * 96);
}, di = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function Na() {
  throw new Error("Dynamic requires are not currently supported by rollup-plugin-commonjs");
}
function Ga(CA, J) {
  return J = { exports: {} }, CA(J, J.exports), J.exports;
}
var Va = Ga(function(CA, J) {
  /*!
   * @overview es6-promise - a tiny implementation of Promises/A+.
   * @copyright Copyright (c) 2014 Yehuda Katz, Tom Dale, Stefan Penner and contributors (Conversion to ES6 API by Jake Archibald)
   * @license   Licensed under MIT license
   *            See https://raw.githubusercontent.com/stefanpenner/es6-promise/master/LICENSE
   * @version   v4.2.5+7f2b526d
   */
  (function(uA, rA) {
    CA.exports = rA();
  })(di, function() {
    function uA(UA) {
      var HA = typeof UA;
      return UA !== null && (HA === "object" || HA === "function");
    }
    function rA(UA) {
      return typeof UA == "function";
    }
    var vA = void 0;
    Array.isArray ? vA = Array.isArray : vA = function(UA) {
      return Object.prototype.toString.call(UA) === "[object Array]";
    };
    var LA = vA, kA = 0, ZA = void 0, XA = void 0, At = function(HA, TA) {
      zt[kA] = HA, zt[kA + 1] = TA, kA += 2, kA === 2 && (XA ? XA(ie) : Be());
    };
    function pt(UA) {
      XA = UA;
    }
    function at(UA) {
      At = UA;
    }
    var YA = typeof window < "u" ? window : void 0, Ht = YA || {}, $t = Ht.MutationObserver || Ht.WebKitMutationObserver, Ae = typeof self > "u" && typeof process < "u" && {}.toString.call(process) === "[object process]", vt = typeof Uint8ClampedArray < "u" && typeof importScripts < "u" && typeof MessageChannel < "u";
    function Bt() {
      return function() {
        return process.nextTick(ie);
      };
    }
    function St() {
      return typeof ZA < "u" ? function() {
        ZA(ie);
      } : Kt();
    }
    function Tt() {
      var UA = 0, HA = new $t(ie), TA = document.createTextNode("");
      return HA.observe(TA, { characterData: !0 }), function() {
        TA.data = UA = ++UA % 2;
      };
    }
    function ne() {
      var UA = new MessageChannel();
      return UA.port1.onmessage = ie, function() {
        return UA.port2.postMessage(0);
      };
    }
    function Kt() {
      var UA = setTimeout;
      return function() {
        return UA(ie, 1);
      };
    }
    var zt = new Array(1e3);
    function ie() {
      for (var UA = 0; UA < kA; UA += 2) {
        var HA = zt[UA], TA = zt[UA + 1];
        HA(TA), zt[UA] = void 0, zt[UA + 1] = void 0;
      }
      kA = 0;
    }
    function Ne() {
      try {
        var UA = Function("return this")().require("vertx");
        return ZA = UA.runOnLoop || UA.runOnContext, St();
      } catch {
        return Kt();
      }
    }
    var Be = void 0;
    Ae ? Be = Bt() : $t ? Be = Tt() : vt ? Be = ne() : YA === void 0 && typeof Na == "function" ? Be = Ne() : Be = Kt();
    function He(UA, HA) {
      var TA = this, WA = new this.constructor(ut);
      WA[we] === void 0 && ye(WA);
      var nt = TA._state;
      if (nt) {
        var tt = arguments[nt - 1];
        At(function() {
          return De(nt, WA, tt, TA._result);
        });
      } else
        Le(TA, WA, UA, HA);
      return WA;
    }
    function Se(UA) {
      var HA = this;
      if (UA && typeof UA == "object" && UA.constructor === HA)
        return UA;
      var TA = new HA(ut);
      return me(TA, UA), TA;
    }
    var we = Math.random().toString(36).substring(2);
    function ut() {
    }
    var ft = void 0, _t = 1, ge = 2, te = { error: null };
    function Ze() {
      return new TypeError("You cannot resolve a promise with itself");
    }
    function $e() {
      return new TypeError("A promises callback cannot return that same promise.");
    }
    function Ue(UA) {
      try {
        return UA.then;
      } catch (HA) {
        return te.error = HA, te;
      }
    }
    function ke(UA, HA, TA, WA) {
      try {
        UA.call(HA, TA, WA);
      } catch (nt) {
        return nt;
      }
    }
    function wr(UA, HA, TA) {
      At(function(WA) {
        var nt = !1, tt = ke(TA, HA, function(Lt) {
          nt || (nt = !0, HA !== Lt ? me(WA, Lt) : dt(WA, Lt));
        }, function(Lt) {
          nt || (nt = !0, Ft(WA, Lt));
        }, "Settle: " + (WA._label || " unknown promise"));
        !nt && tt && (nt = !0, Ft(WA, tt));
      }, UA);
    }
    function vr(UA, HA) {
      HA._state === _t ? dt(UA, HA._result) : HA._state === ge ? Ft(UA, HA._result) : Le(HA, void 0, function(TA) {
        return me(UA, TA);
      }, function(TA) {
        return Ft(UA, TA);
      });
    }
    function ar(UA, HA, TA) {
      HA.constructor === UA.constructor && TA === He && HA.constructor.resolve === Se ? vr(UA, HA) : TA === te ? (Ft(UA, te.error), te.error = null) : TA === void 0 ? dt(UA, HA) : rA(TA) ? wr(UA, HA, TA) : dt(UA, HA);
    }
    function me(UA, HA) {
      UA === HA ? Ft(UA, Ze()) : uA(HA) ? ar(UA, HA, Ue(HA)) : dt(UA, HA);
    }
    function Ge(UA) {
      UA._onerror && UA._onerror(UA._result), ve(UA);
    }
    function dt(UA, HA) {
      UA._state === ft && (UA._result = HA, UA._state = _t, UA._subscribers.length !== 0 && At(ve, UA));
    }
    function Ft(UA, HA) {
      UA._state === ft && (UA._state = ge, UA._result = HA, At(Ge, UA));
    }
    function Le(UA, HA, TA, WA) {
      var nt = UA._subscribers, tt = nt.length;
      UA._onerror = null, nt[tt] = HA, nt[tt + _t] = TA, nt[tt + ge] = WA, tt === 0 && UA._state && At(ve, UA);
    }
    function ve(UA) {
      var HA = UA._subscribers, TA = UA._state;
      if (HA.length !== 0) {
        for (var WA = void 0, nt = void 0, tt = UA._result, Lt = 0; Lt < HA.length; Lt += 3)
          WA = HA[Lt], nt = HA[Lt + TA], WA ? De(TA, WA, nt, tt) : nt(tt);
        UA._subscribers.length = 0;
      }
    }
    function Ce(UA, HA) {
      try {
        return UA(HA);
      } catch (TA) {
        return te.error = TA, te;
      }
    }
    function De(UA, HA, TA, WA) {
      var nt = rA(TA), tt = void 0, Lt = void 0, Fe = void 0, Vt = void 0;
      if (nt) {
        if (tt = Ce(TA, WA), tt === te ? (Vt = !0, Lt = tt.error, tt.error = null) : Fe = !0, HA === tt) {
          Ft(HA, $e());
          return;
        }
      } else
        tt = WA, Fe = !0;
      HA._state !== ft || (nt && Fe ? me(HA, tt) : Vt ? Ft(HA, Lt) : UA === _t ? dt(HA, tt) : UA === ge && Ft(HA, tt));
    }
    function cr(UA, HA) {
      try {
        HA(function(WA) {
          me(UA, WA);
        }, function(WA) {
          Ft(UA, WA);
        });
      } catch (TA) {
        Ft(UA, TA);
      }
    }
    var Ve = 0;
    function lr() {
      return Ve++;
    }
    function ye(UA) {
      UA[we] = Ve++, UA._state = void 0, UA._result = void 0, UA._subscribers = [];
    }
    function Ar() {
      return new Error("Array Methods must be provided an Array");
    }
    var Te = function() {
      function UA(HA, TA) {
        this._instanceConstructor = HA, this.promise = new HA(ut), this.promise[we] || ye(this.promise), LA(TA) ? (this.length = TA.length, this._remaining = TA.length, this._result = new Array(this.length), this.length === 0 ? dt(this.promise, this._result) : (this.length = this.length || 0, this._enumerate(TA), this._remaining === 0 && dt(this.promise, this._result))) : Ft(this.promise, Ar());
      }
      return UA.prototype._enumerate = function(TA) {
        for (var WA = 0; this._state === ft && WA < TA.length; WA++)
          this._eachEntry(TA[WA], WA);
      }, UA.prototype._eachEntry = function(TA, WA) {
        var nt = this._instanceConstructor, tt = nt.resolve;
        if (tt === Se) {
          var Lt = Ue(TA);
          if (Lt === He && TA._state !== ft)
            this._settledAt(TA._state, WA, TA._result);
          else if (typeof Lt != "function")
            this._remaining--, this._result[WA] = TA;
          else if (nt === Ut) {
            var Fe = new nt(ut);
            ar(Fe, TA, Lt), this._willSettleAt(Fe, WA);
          } else
            this._willSettleAt(new nt(function(Vt) {
              return Vt(TA);
            }), WA);
        } else
          this._willSettleAt(tt(TA), WA);
      }, UA.prototype._settledAt = function(TA, WA, nt) {
        var tt = this.promise;
        tt._state === ft && (this._remaining--, TA === ge ? Ft(tt, nt) : this._result[WA] = nt), this._remaining === 0 && dt(tt, this._result);
      }, UA.prototype._willSettleAt = function(TA, WA) {
        var nt = this;
        Le(TA, void 0, function(tt) {
          return nt._settledAt(_t, WA, tt);
        }, function(tt) {
          return nt._settledAt(ge, WA, tt);
        });
      }, UA;
    }();
    function Ot(UA) {
      return new Te(this, UA).promise;
    }
    function Ct(UA) {
      var HA = this;
      return LA(UA) ? new HA(function(TA, WA) {
        for (var nt = UA.length, tt = 0; tt < nt; tt++)
          HA.resolve(UA[tt]).then(TA, WA);
      }) : new HA(function(TA, WA) {
        return WA(new TypeError("You must pass an array to race."));
      });
    }
    function Kr(UA) {
      var HA = this, TA = new HA(ut);
      return Ft(TA, UA), TA;
    }
    function lt() {
      throw new TypeError("You must pass a resolver function as the first argument to the promise constructor");
    }
    function mr() {
      throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.");
    }
    var Ut = function() {
      function UA(HA) {
        this[we] = lr(), this._result = this._state = void 0, this._subscribers = [], ut !== HA && (typeof HA != "function" && lt(), this instanceof UA ? cr(this, HA) : mr());
      }
      return UA.prototype.catch = function(TA) {
        return this.then(null, TA);
      }, UA.prototype.finally = function(TA) {
        var WA = this, nt = WA.constructor;
        return rA(TA) ? WA.then(function(tt) {
          return nt.resolve(TA()).then(function() {
            return tt;
          });
        }, function(tt) {
          return nt.resolve(TA()).then(function() {
            throw tt;
          });
        }) : WA.then(TA, TA);
      }, UA;
    }();
    Ut.prototype.then = He, Ut.all = Ot, Ut.race = Ct, Ut.resolve = Se, Ut.reject = Kr, Ut._setScheduler = pt, Ut._setAsap = at, Ut._asap = At;
    function Qe() {
      var UA = void 0;
      if (typeof di < "u")
        UA = di;
      else if (typeof self < "u")
        UA = self;
      else
        try {
          UA = Function("return this")();
        } catch {
          throw new Error("polyfill failed because global object is unavailable in this environment");
        }
      var HA = UA.Promise;
      if (HA) {
        var TA = null;
        try {
          TA = Object.prototype.toString.call(HA.resolve());
        } catch {
        }
        if (TA === "[object Promise]" && !HA.cast)
          return;
      }
      UA.Promise = Ut;
    }
    return Ut.polyfill = Qe, Ut.Promise = Ut, Ut;
  });
}), Ye = Va.Promise, rt = function CA(J) {
  var uA = mi(CA.convert(Ye.resolve()), JSON.parse(JSON.stringify(CA.template))), rA = CA.convert(Ye.resolve(), uA);
  return rA = rA.setProgress(1, CA, 1, [CA]), rA = rA.set(J), rA;
};
rt.prototype = Object.create(Ye.prototype);
rt.prototype.constructor = rt;
rt.convert = function(J, uA) {
  return J.__proto__ = uA || rt.prototype, J;
};
rt.template = {
  prop: {
    src: null,
    container: null,
    overlay: null,
    canvas: null,
    img: null,
    pdf: null,
    pageSize: null
  },
  progress: {
    val: 0,
    state: null,
    n: 0,
    stack: []
  },
  opt: {
    filename: "file.pdf",
    margin: [0, 0, 0, 0],
    image: { type: "jpeg", quality: 0.95 },
    enableLinks: !0,
    html2canvas: {},
    jsPDF: {}
  }
};
rt.prototype.from = function(J, uA) {
  function rA(vA) {
    switch (Gn(vA)) {
      case "string":
        return "string";
      case "element":
        return vA.nodeName.toLowerCase === "canvas" ? "canvas" : "element";
      default:
        return "unknown";
    }
  }
  return this.then(function() {
    switch (uA = uA || rA(J), uA) {
      case "string":
        return this.set({ src: gn("div", { innerHTML: J }) });
      case "element":
        return this.set({ src: J });
      case "canvas":
        return this.set({ canvas: J });
      case "img":
        return this.set({ img: J });
      default:
        return this.error("Unknown source type.");
    }
  });
};
rt.prototype.to = function(J) {
  switch (J) {
    case "container":
      return this.toContainer();
    case "canvas":
      return this.toCanvas();
    case "img":
      return this.toImg();
    case "pdf":
      return this.toPdf();
    default:
      return this.error("Invalid target.");
  }
};
rt.prototype.toContainer = function() {
  var J = [function() {
    return this.prop.src || this.error("Cannot duplicate - no source HTML.");
  }, function() {
    return this.prop.pageSize || this.setPageSize();
  }];
  return this.thenList(J).then(function() {
    var rA = {
      position: "fixed",
      overflow: "hidden",
      zIndex: 1e3,
      left: 0,
      right: 0,
      bottom: 0,
      top: 0,
      backgroundColor: "rgba(0,0,0,0.8)"
    }, vA = {
      position: "absolute",
      width: this.prop.pageSize.inner.width + this.prop.pageSize.unit,
      left: 0,
      right: 0,
      top: 0,
      height: "auto",
      margin: "auto",
      backgroundColor: "white"
    };
    rA.opacity = 0;
    var LA = Ra(this.prop.src, this.opt.html2canvas.javascriptEnabled);
    this.prop.overlay = gn("div", { className: "html2pdf__overlay", style: rA }), this.prop.container = gn("div", { className: "html2pdf__container", style: vA }), this.prop.container.appendChild(LA), this.prop.overlay.appendChild(this.prop.container), document.body.appendChild(this.prop.overlay);
  });
};
rt.prototype.toCanvas = function() {
  var J = [function() {
    return document.body.contains(this.prop.container) || this.toContainer();
  }];
  return this.thenList(J).then(function() {
    var rA = mi({}, this.opt.html2canvas);
    return delete rA.onrendered, Ma(this.prop.container, rA);
  }).then(function(rA) {
    var vA = this.opt.html2canvas.onrendered || function() {
    };
    vA(rA), this.prop.canvas = rA, document.body.removeChild(this.prop.overlay);
  });
};
rt.prototype.toImg = function() {
  var J = [function() {
    return this.prop.canvas || this.toCanvas();
  }];
  return this.thenList(J).then(function() {
    var rA = this.prop.canvas.toDataURL("image/" + this.opt.image.type, this.opt.image.quality);
    this.prop.img = document.createElement("img"), this.prop.img.src = rA;
  });
};
rt.prototype.toPdf = function() {
  var J = [function() {
    return this.prop.canvas || this.toCanvas();
  }];
  return this.thenList(J).then(function() {
    var rA = this.prop.canvas, vA = this.opt, LA = rA.height, kA = Math.floor(rA.width * this.prop.pageSize.inner.ratio), ZA = Math.ceil(LA / kA), XA = this.prop.pageSize.inner.height, At = document.createElement("canvas"), pt = At.getContext("2d");
    At.width = rA.width, At.height = kA, this.prop.pdf = this.prop.pdf || new wi(vA.jsPDF);
    for (var at = 0; at < ZA; at++) {
      at === ZA - 1 && LA % kA !== 0 && (At.height = LA % kA, XA = At.height * this.prop.pageSize.inner.width / At.width);
      var YA = At.width, Ht = At.height;
      pt.fillStyle = "white", pt.fillRect(0, 0, YA, Ht), pt.drawImage(rA, 0, at * kA, YA, Ht, 0, 0, YA, Ht), at && this.prop.pdf.addPage();
      var $t = At.toDataURL("image/" + vA.image.type, vA.image.quality);
      this.prop.pdf.addImage($t, vA.image.type, vA.margin[1], vA.margin[0], this.prop.pageSize.inner.width, XA);
    }
  });
};
rt.prototype.output = function(J, uA, rA) {
  return rA = rA || "pdf", rA.toLowerCase() === "img" || rA.toLowerCase() === "image" ? this.outputImg(J, uA) : this.outputPdf(J, uA);
};
rt.prototype.outputPdf = function(J, uA) {
  var rA = [function() {
    return this.prop.pdf || this.toPdf();
  }];
  return this.thenList(rA).then(function() {
    return this.prop.pdf.output(J, uA);
  });
};
rt.prototype.outputImg = function(J, uA) {
  var rA = [function() {
    return this.prop.img || this.toImg();
  }];
  return this.thenList(rA).then(function() {
    switch (J) {
      case void 0:
      case "img":
        return this.prop.img;
      case "datauristring":
      case "dataurlstring":
        return this.prop.img.src;
      case "datauri":
      case "dataurl":
        return document.location.href = this.prop.img.src;
      default:
        throw 'Image output type "' + J + '" is not supported.';
    }
  });
};
rt.prototype.save = function(J) {
  var uA = [function() {
    return this.prop.pdf || this.toPdf();
  }];
  return this.thenList(uA).set(J ? { filename: J } : null).then(function() {
    this.prop.pdf.save(this.opt.filename);
  });
};
rt.prototype.set = function(J) {
  if (Gn(J) !== "object")
    return this;
  var uA = Object.keys(J || {}).map(function(rA) {
    if (rA in rt.template.prop)
      return function() {
        this.prop[rA] = J[rA];
      };
    switch (rA) {
      case "margin":
        return this.setMargin.bind(this, J.margin);
      case "jsPDF":
        return function() {
          return this.opt.jsPDF = J.jsPDF, this.setPageSize();
        };
      case "pageSize":
        return this.setPageSize.bind(this, J.pageSize);
      default:
        return function() {
          this.opt[rA] = J[rA];
        };
    }
  }, this);
  return this.then(function() {
    return this.thenList(uA);
  });
};
rt.prototype.get = function(J, uA) {
  return this.then(function() {
    var vA = J in rt.template.prop ? this.prop[J] : this.opt[J];
    return uA ? uA(vA) : vA;
  });
};
rt.prototype.setMargin = function(J) {
  return this.then(function() {
    switch (Gn(J)) {
      case "number":
        J = [J, J, J, J];
      case "array":
        if (J.length === 2 && (J = [J[0], J[1], J[0], J[1]]), J.length === 4)
          break;
      default:
        return this.error("Invalid margin array.");
    }
    this.opt.margin = J;
  }).then(this.setPageSize);
};
rt.prototype.setPageSize = function(J) {
  return this.then(function() {
    J = J || wi.getPageSize(this.opt.jsPDF), J.hasOwnProperty("inner") || (J.inner = {
      width: J.width - this.opt.margin[1] - this.opt.margin[3],
      height: J.height - this.opt.margin[0] - this.opt.margin[2]
    }, J.inner.px = {
      width: _o(J.inner.width, J.k),
      height: _o(J.inner.height, J.k)
    }, J.inner.ratio = J.inner.height / J.inner.width), this.prop.pageSize = J;
  });
};
rt.prototype.setProgress = function(J, uA, rA, vA) {
  return J != null && (this.progress.val = J), uA != null && (this.progress.state = uA), rA != null && (this.progress.n = rA), vA != null && (this.progress.stack = vA), this.progress.ratio = this.progress.val / this.progress.state, this;
};
rt.prototype.updateProgress = function(J, uA, rA, vA) {
  return this.setProgress(J ? this.progress.val + J : null, uA || null, rA ? this.progress.n + rA : null, vA ? this.progress.stack.concat(vA) : null);
};
rt.prototype.then = function(J, uA) {
  var rA = this;
  return this.thenCore(J, uA, function(LA, kA) {
    return rA.updateProgress(null, null, 1, [LA]), Ye.prototype.then.call(this, function(XA) {
      return rA.updateProgress(null, LA), XA;
    }).then(LA, kA).then(function(XA) {
      return rA.updateProgress(1), XA;
    });
  });
};
rt.prototype.thenCore = function(J, uA, rA) {
  rA = rA || Ye.prototype.then;
  var vA = this;
  J && (J = J.bind(vA)), uA && (uA = uA.bind(vA));
  var LA = Ye.toString().indexOf("[native code]") !== -1 && Ye.name === "Promise", kA = LA ? vA : rt.convert(mi({}, vA), Ye.prototype), ZA = rA.call(kA, J, uA);
  return rt.convert(ZA, vA.__proto__);
};
rt.prototype.thenExternal = function(J, uA) {
  return Ye.prototype.then.call(this, J, uA);
};
rt.prototype.thenList = function(J) {
  var uA = this;
  return J.forEach(function(vA) {
    uA = uA.thenCore(vA);
  }), uA;
};
rt.prototype.catch = function(CA) {
  CA && (CA = CA.bind(this));
  var J = Ye.prototype.catch.call(this, CA);
  return rt.convert(J, this);
};
rt.prototype.catchExternal = function(J) {
  return Ye.prototype.catch.call(this, J);
};
rt.prototype.error = function(J) {
  return this.then(function() {
    throw new Error(J);
  });
};
rt.prototype.using = rt.prototype.set;
rt.prototype.saveAs = rt.prototype.save;
rt.prototype.export = rt.prototype.output;
rt.prototype.run = rt.prototype.then;
wi.getPageSize = function(CA, J, uA) {
  if ((typeof CA > "u" ? "undefined" : qo(CA)) === "object") {
    var rA = CA;
    CA = rA.orientation, J = rA.unit || J, uA = rA.format || uA;
  }
  J = J || "mm", uA = uA || "a4", CA = ("" + (CA || "P")).toLowerCase();
  var vA = ("" + uA).toLowerCase(), LA = {
    a0: [2383.94, 3370.39],
    a1: [1683.78, 2383.94],
    a2: [1190.55, 1683.78],
    a3: [841.89, 1190.55],
    a4: [595.28, 841.89],
    a5: [419.53, 595.28],
    a6: [297.64, 419.53],
    a7: [209.76, 297.64],
    a8: [147.4, 209.76],
    a9: [104.88, 147.4],
    a10: [73.7, 104.88],
    b0: [2834.65, 4008.19],
    b1: [2004.09, 2834.65],
    b2: [1417.32, 2004.09],
    b3: [1000.63, 1417.32],
    b4: [708.66, 1000.63],
    b5: [498.9, 708.66],
    b6: [354.33, 498.9],
    b7: [249.45, 354.33],
    b8: [175.75, 249.45],
    b9: [124.72, 175.75],
    b10: [87.87, 124.72],
    c0: [2599.37, 3676.54],
    c1: [1836.85, 2599.37],
    c2: [1298.27, 1836.85],
    c3: [918.43, 1298.27],
    c4: [649.13, 918.43],
    c5: [459.21, 649.13],
    c6: [323.15, 459.21],
    c7: [229.61, 323.15],
    c8: [161.57, 229.61],
    c9: [113.39, 161.57],
    c10: [79.37, 113.39],
    dl: [311.81, 623.62],
    letter: [612, 792],
    "government-letter": [576, 756],
    legal: [612, 1008],
    "junior-legal": [576, 360],
    ledger: [1224, 792],
    tabloid: [792, 1224],
    "credit-card": [153, 243]
  };
  switch (J) {
    case "pt":
      var kA = 1;
      break;
    case "mm":
      var kA = 72 / 25.4;
      break;
    case "cm":
      var kA = 72 / 2.54;
      break;
    case "in":
      var kA = 72;
      break;
    case "px":
      var kA = 72 / 96;
      break;
    case "pc":
      var kA = 12;
      break;
    case "em":
      var kA = 12;
      break;
    case "ex":
      var kA = 6;
      break;
    default:
      throw "Invalid unit: " + J;
  }
  if (LA.hasOwnProperty(vA))
    var ZA = LA[vA][1] / kA, XA = LA[vA][0] / kA;
  else
    try {
      var ZA = uA[1], XA = uA[0];
    } catch {
      throw new Error("Invalid format: " + uA);
    }
  if (CA === "p" || CA === "portrait") {
    if (CA = "p", XA > ZA) {
      var At = XA;
      XA = ZA, ZA = At;
    }
  } else if (CA === "l" || CA === "landscape") {
    if (CA = "l", ZA > XA) {
      var At = XA;
      XA = ZA, ZA = At;
    }
  } else
    throw "Invalid orientation: " + CA;
  var pt = { width: XA, height: ZA, unit: J, k: kA };
  return pt;
};
var qa = {
  toContainer: rt.prototype.toContainer
};
rt.template.opt.pagebreak = {
  mode: ["css", "legacy"],
  before: [],
  after: [],
  avoid: []
};
rt.prototype.toContainer = function() {
  return qa.toContainer.call(this).then(function() {
    var uA = this.prop.container, rA = this.prop.pageSize.inner.px.height, vA = [].concat(this.opt.pagebreak.mode), LA = {
      avoidAll: vA.indexOf("avoid-all") !== -1,
      css: vA.indexOf("css") !== -1,
      legacy: vA.indexOf("legacy") !== -1
    }, kA = {}, ZA = this;
    ["before", "after", "avoid"].forEach(function(pt) {
      var at = LA.avoidAll && pt === "avoid";
      kA[pt] = at ? [] : [].concat(ZA.opt.pagebreak[pt] || []), kA[pt].length > 0 && (kA[pt] = Array.prototype.slice.call(uA.querySelectorAll(kA[pt].join(", "))));
    });
    var XA = uA.querySelectorAll(".html2pdf__page-break");
    XA = Array.prototype.slice.call(XA);
    var At = uA.querySelectorAll("*");
    Array.prototype.forEach.call(At, function(at) {
      var YA = {
        before: !1,
        after: LA.legacy && XA.indexOf(at) !== -1,
        avoid: LA.avoidAll
      };
      if (LA.css) {
        var Ht = window.getComputedStyle(at), $t = ["always", "page", "left", "right"], Ae = ["avoid", "avoid-page"];
        YA = {
          before: YA.before || $t.indexOf(Ht.breakBefore || Ht.pageBreakBefore) !== -1,
          after: YA.after || $t.indexOf(Ht.breakAfter || Ht.pageBreakAfter) !== -1,
          avoid: YA.avoid || Ae.indexOf(Ht.breakInside || Ht.pageBreakInside) !== -1
        };
      }
      Object.keys(YA).forEach(function(Kt) {
        YA[Kt] = YA[Kt] || kA[Kt].indexOf(at) !== -1;
      });
      var vt = at.getBoundingClientRect();
      if (YA.avoid && !YA.before) {
        var Bt = Math.floor(vt.top / rA), St = Math.floor(vt.bottom / rA), Tt = Math.abs(vt.bottom - vt.top) / rA;
        St !== Bt && Tt <= 1 && (YA.before = !0);
      }
      if (YA.before) {
        var ne = gn("div", { style: {
          display: "block",
          height: rA - vt.top % rA + "px"
        } });
        at.parentNode.insertBefore(ne, at);
      }
      if (YA.after) {
        var ne = gn("div", { style: {
          display: "block",
          height: rA - vt.bottom % rA + "px"
        } });
        at.parentNode.insertBefore(ne, at.nextSibling);
      }
    });
  });
};
var Bi = [], jo = {
  toContainer: rt.prototype.toContainer,
  toPdf: rt.prototype.toPdf
};
rt.prototype.toContainer = function() {
  return jo.toContainer.call(this).then(function() {
    if (this.opt.enableLinks) {
      var uA = this.prop.container, rA = uA.querySelectorAll("a"), vA = Ko(uA.getBoundingClientRect(), this.prop.pageSize.k);
      Bi = [], Array.prototype.forEach.call(rA, function(LA) {
        for (var kA = LA.getClientRects(), ZA = 0; ZA < kA.length; ZA++) {
          var XA = Ko(kA[ZA], this.prop.pageSize.k);
          XA.left -= vA.left, XA.top -= vA.top;
          var At = Math.floor(XA.top / this.prop.pageSize.inner.height) + 1, pt = this.opt.margin[0] + XA.top % this.prop.pageSize.inner.height, at = this.opt.margin[1] + XA.left;
          Bi.push({ page: At, top: pt, left: at, clientRect: XA, link: LA });
        }
      }, this);
    }
  });
};
rt.prototype.toPdf = function() {
  return jo.toPdf.call(this).then(function() {
    if (this.opt.enableLinks) {
      Bi.forEach(function(rA) {
        this.prop.pdf.setPage(rA.page), this.prop.pdf.link(rA.left, rA.top, rA.clientRect.width, rA.clientRect.height, { url: rA.link.href });
      }, this);
      var uA = this.prop.pdf.internal.getNumberOfPages();
      this.prop.pdf.setPage(uA);
    }
  });
};
var Xo = function CA(J, uA) {
  var rA = new CA.Worker(uA);
  return J ? rA.from(J).save() : rA;
};
Xo.Worker = rt;
const ja = (CA) => CA / 4 * 3, Xa = (CA) => CA / 3 * 4, Wa = Xa(841.92) + 1;
async function Ja(CA, J = {}) {
  const uA = {
    fileName: "file.pdf",
    marginPt: 60,
    orientation: "portrait",
    htmlScale: 1,
    footer: !0,
    ...J
  };
  return new Promise((rA) => {
    let vA = uA.fileName;
    vA.endsWith(".pdf") || (vA += ".pdf");
    const LA = {
      margin: uA.marginPt,
      filename: vA,
      image: { type: "jpeg", quality: 0.95 },
      html2canvas: { dpi: 192, scale: 2, useCORS: !0 },
      jsPDF: {
        orientation: uA.orientation,
        unit: "pt",
        format: "a4"
      },
      pagebreak: { avoid: ".no-break" },
      // Custom params
      htmlScale: uA.htmlScale
    };
    let kA = Xo().set(LA).from(CA).toPdf();
    J.footer && (kA = kA.get("pdf").then((ZA) => {
      const XA = ZA.internal.getNumberOfPages();
      for (let At = 1; At <= XA; At++)
        ZA.setPage(At), ZA.setFontSize(10), ZA.setTextColor(200), ZA.text(
          `Page ${At} of ${XA}`,
          ZA.internal.pageSize.getWidth() - LA.margin,
          ZA.internal.pageSize.getHeight() - LA.margin / 2,
          "right"
        ), ZA.text(
          LA.filename.replace(".pdf", ""),
          LA.margin,
          ZA.internal.pageSize.getHeight() - LA.margin / 2
        );
    })), kA.save().then(rA);
  });
}
function Oo(CA, J, uA) {
  const rA = CA.slice();
  return rA[26] = J[uA], rA[28] = uA, rA;
}
function za(CA) {
  let J;
  return {
    c() {
      J = No(
        /*safeName*/
        CA[3]
      );
    },
    m(uA, rA) {
      pn(uA, J, rA);
    },
    p(uA, rA) {
      rA & /*safeName*/
      8 && Go(
        J,
        /*safeName*/
        uA[3]
      );
    },
    d(uA) {
      uA && Bn(J);
    }
  };
}
function Ya(CA) {
  let J;
  return {
    c() {
      J = No(
        /*safeButtonText*/
        CA[6]
      );
    },
    m(uA, rA) {
      pn(uA, J, rA);
    },
    p(uA, rA) {
      rA & /*safeButtonText*/
      64 && Go(
        J,
        /*safeButtonText*/
        uA[6]
      );
    },
    d(uA) {
      uA && Bn(J);
    }
  };
}
function Po(CA) {
  let J, uA = Do({ length: (
    /*pageCount*/
    CA[0]
  ) }), rA = [];
  for (let vA = 0; vA < uA.length; vA += 1)
    rA[vA] = Mo(Oo(CA, uA, vA));
  return {
    c() {
      for (let vA = 0; vA < rA.length; vA += 1)
        rA[vA].c();
      J = ka();
    },
    m(vA, LA) {
      for (let kA = 0; kA < rA.length; kA += 1)
        rA[kA] && rA[kA].m(vA, LA);
      pn(vA, J, LA);
    },
    p(vA, LA) {
      if (LA & /*getDividerStyle, pageCount*/
      16385) {
        uA = Do({ length: (
          /*pageCount*/
          vA[0]
        ) });
        let kA;
        for (kA = 0; kA < uA.length; kA += 1) {
          const ZA = Oo(vA, uA, kA);
          rA[kA] ? rA[kA].p(ZA, LA) : (rA[kA] = Mo(ZA), rA[kA].c(), rA[kA].m(J.parentNode, J));
        }
        for (; kA < rA.length; kA += 1)
          rA[kA].d(1);
        rA.length = uA.length;
      }
    },
    d(vA) {
      vA && Bn(J), La(rA, vA);
    }
  };
}
function Mo(CA) {
  let J;
  return {
    c() {
      J = Zr("div"), Br(J, "class", "divider svelte-jaf3i5"), Br(
        J,
        "style",
        /*getDividerStyle*/
        CA[14](
          /*idx*/
          CA[28]
        )
      ), To(
        J,
        "last",
        /*idx*/
        CA[28] === /*pageCount*/
        CA[0] - 1
      );
    },
    m(uA, rA) {
      pn(uA, J, rA);
    },
    p(uA, rA) {
      rA & /*pageCount*/
      1 && To(
        J,
        "last",
        /*idx*/
        uA[28] === /*pageCount*/
        uA[0] - 1
      );
    },
    d(uA) {
      uA && Bn(J);
    }
  };
}
function Za(CA) {
  let J;
  const uA = (
    /*#slots*/
    CA[18].default
  ), rA = Da(
    uA,
    CA,
    /*$$scope*/
    CA[20],
    null
  );
  return {
    c() {
      rA && rA.c();
    },
    m(vA, LA) {
      rA && rA.m(vA, LA), J = !0;
    },
    p(vA, LA) {
      rA && rA.p && (!J || LA & /*$$scope*/
      1048576) && Ta(
        rA,
        uA,
        vA,
        /*$$scope*/
        vA[20],
        J ? _a(
          uA,
          /*$$scope*/
          vA[20],
          LA,
          null
        ) : Ka(
          /*$$scope*/
          vA[20]
        ),
        null
      );
    },
    i(vA) {
      J || ($r(rA, vA), J = !0);
    },
    o(vA) {
      An(rA, vA), J = !1;
    },
    d(vA) {
      rA && rA.d(vA);
    }
  };
}
function $a(CA) {
  let J, uA;
  return J = new /*BlockComponent*/
  CA[11]({
    props: {
      type: "container",
      props: { layout: "grid" },
      styles: {
        normal: { height: `${/*gridMinHeight*/
        CA[4]}px` }
      },
      context: "grid",
      $$slots: { default: [Za] },
      $$scope: { ctx: CA }
    }
  }), {
    c() {
      hn(J.$$.fragment);
    },
    m(rA, vA) {
      fn(J, rA, vA), uA = !0;
    },
    p(rA, vA) {
      const LA = {};
      vA & /*gridMinHeight*/
      16 && (LA.styles = {
        normal: { height: `${/*gridMinHeight*/
        rA[4]}px` }
      }), vA & /*$$scope*/
      1048576 && (LA.$$scope = { dirty: vA, ctx: rA }), J.$set(LA);
    },
    i(rA) {
      uA || ($r(J.$$.fragment, rA), uA = !0);
    },
    o(rA) {
      An(J.$$.fragment, rA), uA = !1;
    },
    d(rA) {
      dn(J, rA);
    }
  };
}
function Ac(CA) {
  let J, uA, rA, vA, LA, kA, ZA, XA, At, pt, at, YA, Ht, $t, Ae;
  vA = new Ua({
    props: {
      size: "M",
      $$slots: { default: [za] },
      $$scope: { ctx: CA }
    }
  }), kA = new va({
    props: {
      disabled: (
        /*rendering*/
        CA[1]
      ),
      cta: !0,
      $$slots: { default: [Ya] },
      $$scope: { ctx: CA }
    }
  }), kA.$on(
    "click",
    /*generatePDF*/
    CA[13]
  );
  let vt = (
    /*pageCount*/
    CA[0] > 1 && Po(CA)
  );
  return at = new ba({
    props: {
      popoverRoot: !1,
      $$slots: { default: [$a] },
      $$scope: { ctx: CA }
    }
  }), {
    c() {
      J = Zr("div"), uA = Zr("div"), rA = Zr("div"), hn(vA.$$.fragment), LA = fi(), hn(kA.$$.fragment), ZA = fi(), XA = Zr("div"), vt && vt.c(), At = fi(), pt = Zr("div"), hn(at.$$.fragment), Br(rA, "class", "title svelte-jaf3i5"), Br(pt, "class", "spectrum spectrum--medium spectrum--light pageContent svelte-jaf3i5"), Br(XA, "class", "page svelte-jaf3i5"), Br(
        XA,
        "style",
        /*pageStyle*/
        CA[5]
      ), Br(uA, "class", "container svelte-jaf3i5"), Br(J, "class", "wrapper svelte-jaf3i5"), xa(
        J,
        "--margin",
        /*marginPt*/
        CA[12] + "pt"
      );
    },
    m(Bt, St) {
      pn(Bt, J, St), Tr(J, uA), Tr(uA, rA), fn(vA, rA, null), Tr(rA, LA), fn(kA, rA, null), Tr(uA, ZA), Tr(uA, XA), vt && vt.m(XA, null), Tr(XA, At), Tr(XA, pt), fn(at, pt, null), CA[19](pt), Ht = !0, $t || (Ae = Ia(YA = /*styleable*/
      CA[9].call(
        null,
        uA,
        /*$component*/
        CA[7].styles
      )), $t = !0);
    },
    p(Bt, St) {
      const Tt = {};
      St & /*$$scope, safeName*/
      1048584 && (Tt.$$scope = { dirty: St, ctx: Bt }), vA.$set(Tt);
      const ne = {};
      St & /*rendering*/
      2 && (ne.disabled = /*rendering*/
      Bt[1]), St & /*$$scope, safeButtonText*/
      1048640 && (ne.$$scope = { dirty: St, ctx: Bt }), kA.$set(ne), /*pageCount*/
      Bt[0] > 1 ? vt ? vt.p(Bt, St) : (vt = Po(Bt), vt.c(), vt.m(XA, At)) : vt && (vt.d(1), vt = null);
      const Kt = {};
      St & /*$$scope, gridMinHeight*/
      1048592 && (Kt.$$scope = { dirty: St, ctx: Bt }), at.$set(Kt), (!Ht || St & /*pageStyle*/
      32) && Br(
        XA,
        "style",
        /*pageStyle*/
        Bt[5]
      ), YA && Ea(YA.update) && St & /*$component*/
      128 && YA.update.call(
        null,
        /*$component*/
        Bt[7].styles
      );
    },
    i(Bt) {
      Ht || ($r(vA.$$.fragment, Bt), $r(kA.$$.fragment, Bt), $r(at.$$.fragment, Bt), Ht = !0);
    },
    o(Bt) {
      An(vA.$$.fragment, Bt), An(kA.$$.fragment, Bt), An(at.$$.fragment, Bt), Ht = !1;
    },
    d(Bt) {
      Bt && Bn(J), dn(vA), dn(kA), vt && vt.d(), dn(at), CA[19](null), $t = !1, Ae();
    }
  };
}
function tc(CA) {
  let J, uA;
  return J = new /*Block*/
  CA[10]({
    props: {
      $$slots: { default: [Ac] },
      $$scope: { ctx: CA }
    }
  }), {
    c() {
      hn(J.$$.fragment);
    },
    m(rA, vA) {
      fn(J, rA, vA), uA = !0;
    },
    p(rA, [vA]) {
      const LA = {};
      vA & /*$$scope, $component, pageStyle, ref, gridMinHeight, pageCount, rendering, safeButtonText, safeName*/
      1048831 && (LA.$$scope = { dirty: vA, ctx: rA }), J.$set(LA);
    },
    i(rA) {
      uA || ($r(J.$$.fragment, rA), uA = !0);
    },
    o(rA) {
      An(J.$$.fragment, rA), uA = !1;
    },
    d(rA) {
      dn(J, rA);
    }
  };
}
const gi = 40;
function ec(CA, J, uA) {
  let rA, vA, LA, kA, ZA, XA, { $$slots: At = {}, $$scope: pt } = J;
  const at = ko("component");
  Qa(CA, at, (ut) => uA(7, XA = ut));
  const { styleable: YA, Block: Ht, BlockComponent: $t } = ko("sdk");
  let { fileName: Ae } = J, { buttonText: vt } = J;
  const Bt = Lo * gi, St = Wa - Bt, Tt = ja(St / 2);
  let ne = !1, Kt = 1, zt, ie;
  const Ne = async () => {
    uA(1, ne = !0), await Ha(), Be();
    try {
      await Ja(zt, {
        fileName: rA,
        marginPt: Tt,
        footer: !0
      });
    } catch (ut) {
      console.error("Error rendering PDF", ut);
    }
    uA(1, ne = !1);
  }, Be = () => {
    const ut = document.getElementsByClassName("grid-child");
    for (let ft of ut) {
      if (!(ft instanceof HTMLElement))
        return;
      const _t = window.getComputedStyle(ft);
      ft.style.setProperty("grid-column-end", _t.gridColumnEnd, "important");
    }
  }, He = (ut) => {
    const ft = (ut + 1) * Bt + St / 2;
    return `--idx:"${ut + 1}"; --top:${ft}px;`;
  }, Se = () => {
    if (!ie)
      return;
    const ut = parseInt(ie.dataset.requiredRows || "1"), ft = Math.max(1, Math.ceil(ut / gi));
    (ft > Kt || !ie.classList.contains("highlight")) && uA(0, Kt = ft);
  };
  Fa(() => {
    const ut = new MutationObserver(Se);
    let ft = null;
    const _t = () => (ie = zt == null ? void 0 : zt.getElementsByClassName("grid")[0], ie ? (ut.observe(ie, {
      attributes: !0,
      attributeFilter: ["data-required-rows", "class"]
    }), Se(), !0) : !1);
    return _t() || (ft = new MutationObserver(() => {
      _t() && (ft == null || ft.disconnect());
    }), ft.observe(zt, { childList: !0, subtree: !0 })), () => {
      ft == null || ft.disconnect(), ut.disconnect();
    };
  });
  function we(ut) {
    Sa[ut ? "unshift" : "push"](() => {
      zt = ut, uA(2, zt);
    });
  }
  return CA.$$set = (ut) => {
    "fileName" in ut && uA(15, Ae = ut.fileName), "buttonText" in ut && uA(16, vt = ut.buttonText), "$$scope" in ut && uA(20, pt = ut.$$scope);
  }, CA.$$.update = () => {
    CA.$$.dirty & /*fileName*/
    32768 && uA(3, rA = Ae || "Report"), CA.$$.dirty & /*buttonText*/
    65536 && uA(6, vA = vt || "Download PDF"), CA.$$.dirty & /*pageCount*/
    1 && uA(17, LA = Kt * Bt + St), CA.$$.dirty & /*heightPx*/
    131072 && uA(5, kA = `--height:${LA}px; --margin:${Tt}pt;`), CA.$$.dirty & /*pageCount*/
    1 && uA(4, ZA = Kt * gi * Lo);
  }, [
    Kt,
    ne,
    zt,
    rA,
    ZA,
    kA,
    vA,
    XA,
    at,
    YA,
    Ht,
    $t,
    Tt,
    Ne,
    He,
    Ae,
    vt,
    LA,
    At,
    we,
    pt
  ];
}
class ic extends ma {
  constructor(J) {
    super(), Ca(this, J, ec, tc, ya, { fileName: 15, buttonText: 16 });
  }
}
export {
  ic as default
};
