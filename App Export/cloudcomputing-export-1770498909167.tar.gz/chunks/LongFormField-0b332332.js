import { S as N, i as R, s as D, e as X, b as k, d as U, f as M, g as le, B as Y, o as w, aa as ne, w as ie, ac as E, y as q, z, n as y, A as B, k as O, ae as fe, ai as H, c as T, m as V, aj as v, p as A, ab as te, u as j, v as L, ad as ae, al as ue } from "./index-e79f0bb2.js";
import { T as de } from "./TextArea-4567cc6e.js";
import { F as se } from "./Field-269dd13f.js";
import "./Placeholder-527c0fd1.js";
import "./InnerForm-04bc2863.js";
function oe(n) {
  let e, l;
  return {
    c() {
      e = X("div"), l = X("textarea"), l.disabled = !0, k(
        l,
        "id",
        /*id*/
        n[0]
      ), k(
        e,
        "style",
        /*styleString*/
        n[3]
      ), k(e, "class", "svelte-1888jbe"), U(
        e,
        "disabled",
        /*disabled*/
        n[1]
      );
    },
    m(f, i) {
      M(f, e, i), le(e, l), n[9](l);
    },
    p(f, [i]) {
      i & /*id*/
      1 && k(
        l,
        "id",
        /*id*/
        f[0]
      ), i & /*styleString*/
      8 && k(
        e,
        "style",
        /*styleString*/
        f[3]
      ), i & /*disabled*/
      2 && U(
        e,
        "disabled",
        /*disabled*/
        f[1]
      );
    },
    i: Y,
    o: Y,
    d(f) {
      f && w(e), n[9](null);
    }
  };
}
function re(n, e, l) {
  let f, { height: i = null } = e, { scroll: t = !0 } = e, { easyMDEOptions: a = null } = e, { mde: c = null } = e, { id: o = null } = e, { fullScreenOffset: m = null } = e, { disabled: u = !1 } = e, h;
  ne(async () => {
    l(4, i = i || "200px");
    const { default: r } = await import("./easymde-d6ac3448.js").then((g) => g.e);
    l(5, c = new r({
      element: h,
      spellChecker: !1,
      status: !1,
      unorderedListStyle: "-",
      maxHeight: t ? i : void 0,
      minHeight: t ? void 0 : i,
      ...a
    }));
  }), ie(() => {
    c == null || c.toTextArea();
  });
  const d = (r) => {
    let g = "";
    return g += `--fullscreen-offset-x:${(r == null ? void 0 : r.x) || "0px"};`, g += `--fullscreen-offset-y:${(r == null ? void 0 : r.y) || "0px"};`, g;
  };
  function b(r) {
    E[r ? "unshift" : "push"](() => {
      h = r, l(2, h);
    });
  }
  return n.$$set = (r) => {
    "height" in r && l(4, i = r.height), "scroll" in r && l(6, t = r.scroll), "easyMDEOptions" in r && l(7, a = r.easyMDEOptions), "mde" in r && l(5, c = r.mde), "id" in r && l(0, o = r.id), "fullScreenOffset" in r && l(8, m = r.fullScreenOffset), "disabled" in r && l(1, u = r.disabled);
  }, n.$$.update = () => {
    n.$$.dirty & /*fullScreenOffset*/
    256 && l(3, f = d(m));
  }, [
    o,
    u,
    h,
    f,
    i,
    c,
    t,
    a,
    m,
    b
  ];
}
class ce extends N {
  constructor(e) {
    super(), R(this, e, re, oe, D, {
      height: 4,
      scroll: 6,
      easyMDEOptions: 7,
      mde: 5,
      id: 0,
      fullScreenOffset: 8,
      disabled: 1
    });
  }
}
function W(n) {
  let e, l, f;
  function i(a) {
    n[9](a);
  }
  let t = {
    scroll: !0,
    height: (
      /*height*/
      n[1]
    ),
    id: (
      /*id*/
      n[3]
    ),
    fullScreenOffset: (
      /*fullScreenOffset*/
      n[4]
    ),
    disabled: (
      /*disabled*/
      n[5]
    ),
    easyMDEOptions: {
      initialValue: (
        /*value*/
        n[0]
      ),
      placeholder: (
        /*placeholder*/
        n[2]
      ),
      toolbar: (
        /*disabled*/
        n[5] || /*readonly*/
        n[6] ? !1 : void 0
      ),
      .../*easyMDEOptions*/
      n[7]
    }
  };
  return (
    /*mde*/
    n[8] !== void 0 && (t.mde = /*mde*/
    n[8]), e = new ce({ props: t }), E.push(() => H(e, "mde", i)), {
      c() {
        T(e.$$.fragment);
      },
      m(a, c) {
        V(e, a, c), f = !0;
      },
      p(a, c) {
        const o = {};
        c & /*height*/
        2 && (o.height = /*height*/
        a[1]), c & /*id*/
        8 && (o.id = /*id*/
        a[3]), c & /*fullScreenOffset*/
        16 && (o.fullScreenOffset = /*fullScreenOffset*/
        a[4]), c & /*disabled*/
        32 && (o.disabled = /*disabled*/
        a[5]), c & /*value, placeholder, disabled, readonly, easyMDEOptions*/
        229 && (o.easyMDEOptions = {
          initialValue: (
            /*value*/
            a[0]
          ),
          placeholder: (
            /*placeholder*/
            a[2]
          ),
          toolbar: (
            /*disabled*/
            a[5] || /*readonly*/
            a[6] ? !1 : void 0
          ),
          .../*easyMDEOptions*/
          a[7]
        }), !l && c & /*mde*/
        256 && (l = !0, o.mde = /*mde*/
        a[8], v(() => l = !1)), e.$set(o);
      },
      i(a) {
        f || (O(e.$$.fragment, a), f = !0);
      },
      o(a) {
        y(e.$$.fragment, a), f = !1;
      },
      d(a) {
        A(e, a);
      }
    }
  );
}
function he(n) {
  let e = (
    /*height*/
    n[1]
  ), l, f, i = W(n);
  return {
    c() {
      i.c(), l = q();
    },
    m(t, a) {
      i.m(t, a), M(t, l, a), f = !0;
    },
    p(t, [a]) {
      a & /*height*/
      2 && D(e, e = /*height*/
      t[1]) ? (z(), y(i, 1, 1, Y), B(), i = W(t), i.c(), O(i, 1), i.m(l.parentNode, l)) : i.p(t, a);
    },
    i(t) {
      f || (O(i), f = !0);
    },
    o(t) {
      y(i), f = !1;
    },
    d(t) {
      t && w(l), i.d(t);
    }
  };
}
function me(n, e, l) {
  let { value: f = null } = e, { height: i = null } = e, { placeholder: t = null } = e, { id: a = null } = e, { fullScreenOffset: c = null } = e, { disabled: o = !1 } = e, { readonly: m = !1 } = e, { easyMDEOptions: u = {} } = e;
  const h = fe();
  let d, b;
  const r = (_) => {
    b && _ !== d && b.value(_);
  }, g = () => {
    d = b.value(), h("change", d);
  };
  function C(_) {
    b = _, l(8, b);
  }
  return n.$$set = (_) => {
    "value" in _ && l(0, f = _.value), "height" in _ && l(1, i = _.height), "placeholder" in _ && l(2, t = _.placeholder), "id" in _ && l(3, a = _.id), "fullScreenOffset" in _ && l(4, c = _.fullScreenOffset), "disabled" in _ && l(5, o = _.disabled), "readonly" in _ && l(6, m = _.readonly), "easyMDEOptions" in _ && l(7, u = _.easyMDEOptions);
  }, n.$$.update = () => {
    n.$$.dirty & /*value*/
    1 && r(f), n.$$.dirty & /*mde*/
    256 && (b == null || b.codemirror.on("blur", g)), n.$$.dirty & /*readonly, disabled, mde*/
    352 && (m || o) && (b == null || b.togglePreview());
  }, [
    f,
    i,
    t,
    a,
    c,
    o,
    m,
    u,
    b,
    C
  ];
}
class _e extends N {
  constructor(e) {
    super(), R(this, e, me, he, D, {
      value: 0,
      height: 1,
      placeholder: 2,
      id: 3,
      fullScreenOffset: 4,
      disabled: 5,
      readonly: 6,
      easyMDEOptions: 7
    });
  }
}
function be(n) {
  let e, l, f;
  return l = new _e({
    props: {
      value: (
        /*value*/
        n[0]
      ),
      placeholder: (
        /*placeholder*/
        n[1]
      ),
      height: (
        /*height*/
        n[4]
      ),
      id: (
        /*id*/
        n[5]
      ),
      fullScreenOffset: (
        /*fullScreenOffset*/
        n[6]
      ),
      disabled: (
        /*disabled*/
        n[2]
      ),
      easyMDEOptions: (
        /*easyMDEOptions*/
        n[7]
      ),
      readonly: (
        /*readonly*/
        n[3]
      )
    }
  }), l.$on(
    "change",
    /*change_handler*/
    n[8]
  ), {
    c() {
      e = X("div"), T(l.$$.fragment);
    },
    m(i, t) {
      M(i, e, t), V(l, e, null), f = !0;
    },
    p(i, [t]) {
      const a = {};
      t & /*value*/
      1 && (a.value = /*value*/
      i[0]), t & /*placeholder*/
      2 && (a.placeholder = /*placeholder*/
      i[1]), t & /*height*/
      16 && (a.height = /*height*/
      i[4]), t & /*id*/
      32 && (a.id = /*id*/
      i[5]), t & /*fullScreenOffset*/
      64 && (a.fullScreenOffset = /*fullScreenOffset*/
      i[6]), t & /*disabled*/
      4 && (a.disabled = /*disabled*/
      i[2]), t & /*easyMDEOptions*/
      128 && (a.easyMDEOptions = /*easyMDEOptions*/
      i[7]), t & /*readonly*/
      8 && (a.readonly = /*readonly*/
      i[3]), l.$set(a);
    },
    i(i) {
      f || (O(l.$$.fragment, i), f = !0);
    },
    o(i) {
      y(l.$$.fragment, i), f = !1;
    },
    d(i) {
      i && w(e), A(l);
    }
  };
}
function ge(n, e, l) {
  let { value: f = "" } = e, { placeholder: i = null } = e, { disabled: t = !1 } = e, { readonly: a = !1 } = e, { height: c = null } = e, { id: o = null } = e, { fullScreenOffset: m = null } = e, { easyMDEOptions: u = null } = e;
  function h(d) {
    te.call(this, n, d);
  }
  return n.$$set = (d) => {
    "value" in d && l(0, f = d.value), "placeholder" in d && l(1, i = d.placeholder), "disabled" in d && l(2, t = d.disabled), "readonly" in d && l(3, a = d.readonly), "height" in d && l(4, c = d.height), "id" in d && l(5, o = d.id), "fullScreenOffset" in d && l(6, m = d.fullScreenOffset), "easyMDEOptions" in d && l(7, u = d.easyMDEOptions);
  }, [
    f,
    i,
    t,
    a,
    c,
    o,
    m,
    u,
    h
  ];
}
class Oe extends N {
  constructor(e) {
    super(), R(this, e, ge, be, D, {
      value: 0,
      placeholder: 1,
      disabled: 2,
      readonly: 3,
      height: 4,
      id: 5,
      fullScreenOffset: 6,
      easyMDEOptions: 7
    });
  }
}
function Z(n) {
  let e, l, f, i;
  const t = [Se, ye], a = [];
  function c(o, m) {
    return (
      /*useRichText*/
      o[12] ? 0 : 1
    );
  }
  return e = c(n), l = a[e] = t[e](n), {
    c() {
      l.c(), f = q();
    },
    m(o, m) {
      a[e].m(o, m), M(o, f, m), i = !0;
    },
    p(o, m) {
      let u = e;
      e = c(o), e === u ? a[e].p(o, m) : (z(), y(a[u], 1, 1, () => {
        a[u] = null;
      }), B(), l = a[e], l ? l.p(o, m) : (l = a[e] = t[e](o), l.c()), O(l, 1), l.m(f.parentNode, f));
    },
    i(o) {
      i || (O(l), i = !0);
    },
    o(o) {
      y(l), i = !1;
    },
    d(o) {
      o && w(f), a[e].d(o);
    }
  };
}
function ye(n) {
  let e, l;
  return e = new de({
    props: {
      value: (
        /*fieldState*/
        n[9].value
      ),
      disabled: (
        /*fieldState*/
        n[9].disabled
      ),
      readonly: (
        /*fieldState*/
        n[9].readonly
      ),
      error: (
        /*fieldState*/
        n[9].error
      ),
      id: (
        /*fieldState*/
        n[9].fieldId
      ),
      placeholder: (
        /*placeholder*/
        n[2]
      ),
      minHeight: (
        /*height*/
        n[11]
      )
    }
  }), e.$on(
    "change",
    /*handleChange*/
    n[18]
  ), {
    c() {
      T(e.$$.fragment);
    },
    m(f, i) {
      V(e, f, i), l = !0;
    },
    p(f, i) {
      const t = {};
      i & /*fieldState*/
      512 && (t.value = /*fieldState*/
      f[9].value), i & /*fieldState*/
      512 && (t.disabled = /*fieldState*/
      f[9].disabled), i & /*fieldState*/
      512 && (t.readonly = /*fieldState*/
      f[9].readonly), i & /*fieldState*/
      512 && (t.error = /*fieldState*/
      f[9].error), i & /*fieldState*/
      512 && (t.id = /*fieldState*/
      f[9].fieldId), i & /*placeholder*/
      4 && (t.placeholder = /*placeholder*/
      f[2]), i & /*height*/
      2048 && (t.minHeight = /*height*/
      f[11]), e.$set(t);
    },
    i(f) {
      l || (O(e.$$.fragment, f), l = !0);
    },
    o(f) {
      y(e.$$.fragment, f), l = !1;
    },
    d(f) {
      A(e, f);
    }
  };
}
function Se(n) {
  let e, l;
  return e = new Oe({
    props: {
      value: (
        /*fieldState*/
        n[9].value
      ),
      disabled: (
        /*fieldState*/
        n[9].disabled
      ),
      readonly: (
        /*fieldState*/
        n[9].readonly
      ),
      error: (
        /*fieldState*/
        n[9].error
      ),
      id: (
        /*fieldState*/
        n[9].fieldId
      ),
      placeholder: (
        /*placeholder*/
        n[2]
      ),
      height: (
        /*height*/
        n[11]
      ),
      fullScreenOffset: {
        x: (
          /*$layout*/
          n[13].screenXOffset
        ),
        y: (
          /*$layout*/
          n[13].screenYOffset
        )
      },
      easyMDEOptions: {
        hideIcons: (
          /*$context*/
          n[14].device.mobile ? ["side-by-side", "guide"] : []
        )
      }
    }
  }), e.$on(
    "change",
    /*handleChange*/
    n[18]
  ), {
    c() {
      T(e.$$.fragment);
    },
    m(f, i) {
      V(e, f, i), l = !0;
    },
    p(f, i) {
      const t = {};
      i & /*fieldState*/
      512 && (t.value = /*fieldState*/
      f[9].value), i & /*fieldState*/
      512 && (t.disabled = /*fieldState*/
      f[9].disabled), i & /*fieldState*/
      512 && (t.readonly = /*fieldState*/
      f[9].readonly), i & /*fieldState*/
      512 && (t.error = /*fieldState*/
      f[9].error), i & /*fieldState*/
      512 && (t.id = /*fieldState*/
      f[9].fieldId), i & /*placeholder*/
      4 && (t.placeholder = /*placeholder*/
      f[2]), i & /*height*/
      2048 && (t.height = /*height*/
      f[11]), i & /*$layout*/
      8192 && (t.fullScreenOffset = {
        x: (
          /*$layout*/
          f[13].screenXOffset
        ),
        y: (
          /*$layout*/
          f[13].screenYOffset
        )
      }), i & /*$context*/
      16384 && (t.easyMDEOptions = {
        hideIcons: (
          /*$context*/
          f[14].device.mobile ? ["side-by-side", "guide"] : []
        )
      }), e.$set(t);
    },
    i(f) {
      l || (O(e.$$.fragment, f), l = !0);
    },
    o(f) {
      y(e.$$.fragment, f), l = !1;
    },
    d(f) {
      A(e, f);
    }
  };
}
function ke(n) {
  let e, l, f = (
    /*fieldState*/
    n[9] && Z(n)
  );
  return {
    c() {
      f && f.c(), e = q();
    },
    m(i, t) {
      f && f.m(i, t), M(i, e, t), l = !0;
    },
    p(i, t) {
      /*fieldState*/
      i[9] ? f ? (f.p(i, t), t & /*fieldState*/
      512 && O(f, 1)) : (f = Z(i), f.c(), O(f, 1), f.m(e.parentNode, e)) : f && (z(), y(f, 1, 1, () => {
        f = null;
      }), B());
    },
    i(i) {
      l || (O(f), l = !0);
    },
    o(i) {
      y(f), l = !1;
    },
    d(i) {
      i && w(e), f && f.d(i);
    }
  };
}
function Ee(n) {
  let e, l, f, i, t;
  function a(u) {
    n[22](u);
  }
  function c(u) {
    n[23](u);
  }
  function o(u) {
    n[24](u);
  }
  let m = {
    label: (
      /*label*/
      n[1]
    ),
    field: (
      /*field*/
      n[0]
    ),
    disabled: (
      /*disabled*/
      n[3]
    ),
    readonly: (
      /*readonly*/
      n[4]
    ),
    validation: (
      /*validation*/
      n[5]
    ),
    defaultValue: (
      /*defaultValue*/
      n[6]
    ),
    helpText: (
      /*helpText*/
      n[7]
    ),
    type: "longform",
    $$slots: { default: [ke] },
    $$scope: { ctx: n }
  };
  return (
    /*fieldState*/
    n[9] !== void 0 && (m.fieldState = /*fieldState*/
    n[9]), /*fieldApi*/
    n[10] !== void 0 && (m.fieldApi = /*fieldApi*/
    n[10]), /*fieldSchema*/
    n[8] !== void 0 && (m.fieldSchema = /*fieldSchema*/
    n[8]), e = new se({ props: m }), E.push(() => H(e, "fieldState", a)), E.push(() => H(e, "fieldApi", c)), E.push(() => H(e, "fieldSchema", o)), {
      c() {
        T(e.$$.fragment);
      },
      m(u, h) {
        V(e, u, h), t = !0;
      },
      p(u, [h]) {
        const d = {};
        h & /*label*/
        2 && (d.label = /*label*/
        u[1]), h & /*field*/
        1 && (d.field = /*field*/
        u[0]), h & /*disabled*/
        8 && (d.disabled = /*disabled*/
        u[3]), h & /*readonly*/
        16 && (d.readonly = /*readonly*/
        u[4]), h & /*validation*/
        32 && (d.validation = /*validation*/
        u[5]), h & /*defaultValue*/
        64 && (d.defaultValue = /*defaultValue*/
        u[6]), h & /*helpText*/
        128 && (d.helpText = /*helpText*/
        u[7]), h & /*$$scope, fieldState, placeholder, height, $layout, $context, useRichText*/
        67140100 && (d.$$scope = { dirty: h, ctx: u }), !l && h & /*fieldState*/
        512 && (l = !0, d.fieldState = /*fieldState*/
        u[9], v(() => l = !1)), !f && h & /*fieldApi*/
        1024 && (f = !0, d.fieldApi = /*fieldApi*/
        u[10], v(() => f = !1)), !i && h & /*fieldSchema*/
        256 && (i = !0, d.fieldSchema = /*fieldSchema*/
        u[8], v(() => i = !1)), e.$set(d);
      },
      i(u) {
        t || (O(e.$$.fragment, u), t = !0);
      },
      o(u) {
        y(e.$$.fragment, u), t = !1;
      },
      d(u) {
        A(e, u);
      }
    }
  );
}
function De(n, e, l) {
  let f, i, t, a, { field: c } = e, { label: o } = e, { placeholder: m } = e, { disabled: u = !1 } = e, { readonly: h = !1 } = e, { validation: d } = e, { defaultValue: b = "" } = e, { format: r = "auto" } = e, { onChange: g } = e, { helpText: C = null } = e, _, I, S;
  const P = j("context");
  L(n, P, (s) => l(14, a = s));
  const G = j("component");
  L(n, G, (s) => l(21, i = s));
  const J = j("layout");
  L(n, J, (s) => l(13, t = s));
  const K = ue(i);
  ae("component", K);
  let Q;
  const p = (s) => {
    const F = I.setValue(s.detail);
    g && F && g({ value: s.detail });
  };
  function x(s) {
    _ = s, l(9, _);
  }
  function $(s) {
    I = s, l(10, I);
  }
  function ee(s) {
    S = s, l(8, S);
  }
  return n.$$set = (s) => {
    "field" in s && l(0, c = s.field), "label" in s && l(1, o = s.label), "placeholder" in s && l(2, m = s.placeholder), "disabled" in s && l(3, u = s.disabled), "readonly" in s && l(4, h = s.readonly), "validation" in s && l(5, d = s.validation), "defaultValue" in s && l(6, b = s.defaultValue), "format" in s && l(19, r = s.format), "onChange" in s && l(20, g = s.onChange), "helpText" in s && l(7, C = s.helpText);
  }, n.$$.update = () => {
    var s, F;
    n.$$.dirty & /*format, fieldSchema*/
    524544 && l(12, f = r === "rich" || r !== "plain" && (S == null ? void 0 : S.useRichText)), n.$$.dirty & /*$component*/
    2097152 && (l(11, Q = ((F = (s = i.styles) == null ? void 0 : s.normal) == null ? void 0 : F.height) || "150px"), K.set({
      ...i,
      styles: {
        ...i.styles,
        normal: {
          ...i.styles.normal,
          height: void 0
        }
      }
    }));
  }, [
    c,
    o,
    m,
    u,
    h,
    d,
    b,
    C,
    S,
    _,
    I,
    Q,
    f,
    t,
    a,
    P,
    G,
    J,
    p,
    r,
    g,
    i,
    x,
    $,
    ee
  ];
}
class Ce extends N {
  constructor(e) {
    super(), R(this, e, De, Ee, D, {
      field: 0,
      label: 1,
      placeholder: 2,
      disabled: 3,
      readonly: 4,
      validation: 5,
      defaultValue: 6,
      format: 19,
      onChange: 20,
      helpText: 7
    });
  }
}
export {
  Ce as default
};
